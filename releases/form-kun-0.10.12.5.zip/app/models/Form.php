<?php
namespace Models;

use Core\Database;

class Form
{
    public const STORAGE_DATABASE = 'database';
    public const STORAGE_MAIL_ONLY = 'mail_only';
    public const DEFAULT_MAIL_ATTACHMENT_MAX_BYTES = 10 * 1024 * 1024;
    public const MIN_MAIL_ATTACHMENT_MAX_BYTES = 1 * 1024 * 1024;
    public const MAX_MAIL_ATTACHMENT_MAX_BYTES = 25 * 1024 * 1024;
    public const RETENTION_WARN = 'warn';
    public const RETENTION_DELETE = 'delete';
    public const DEFAULT_RETENTION_DAYS = 14;
    public const MIN_RETENTION_DAYS = 0;
    public const MAX_RETENTION_DAYS = 3650;

    public static function defaultAdminMailTemplate(): string
    {
        return "フォーム「{{__form_title__}}」に新しい送信がありました。\n受信日時: {{__submitted_at__}}\nIP: {{__ip__}}\n\n{{__all__}}";
    }

    /**
     * @param mixed $raw
     * @return array<int, string>
     */
    public static function replyFieldKeys($raw): array
    {
        if (is_array($raw)) {
            $values = $raw;
        } else {
            $string = trim((string) $raw);
            if ($string === '') {
                return [];
            }
            $decoded = json_decode($string, true);
            $values = is_array($decoded) ? $decoded : [$string];
        }

        $normalized = [];
        foreach ($values as $value) {
            $fieldKey = trim((string) $value);
            if ($fieldKey === '' || in_array($fieldKey, $normalized, true)) {
                continue;
            }
            $normalized[] = $fieldKey;
        }

        return $normalized;
    }

    /**
     * @param array<int, string> $fieldKeys
     */
    public static function encodeReplyFieldKeys(array $fieldKeys): ?string
    {
        $normalized = self::replyFieldKeys($fieldKeys);
        if ($normalized === []) {
            return null;
        }
        if (count($normalized) === 1) {
            return $normalized[0];
        }

        return json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: null;
    }

    public static function all(): array
    {
        return Database::fetchAll('SELECT * FROM forms ORDER BY id DESC');
    }

    /**
     * ログインユーザーに応じたフォーム一覧（viewer は付与フォームのみ）。
     */
    public static function allForCurrentUser(): array
    {
        if (\Core\Auth::isViewer()) {
            return self::allByIds(\Core\Auth::viewerFormIds());
        }
        return self::all();
    }

    /**
     * @param int[] $ids
     */
    public static function allByIds(array $ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn(int $id): bool => $id > 0)));
        if ($ids === []) {
            return [];
        }
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        return Database::fetchAll(
            "SELECT * FROM forms WHERE id IN ($placeholders) ORDER BY id DESC",
            $ids
        );
    }

    public static function allActive(): array
    {
        return Database::fetchAll(
            "SELECT f.*
             FROM forms f
             LEFT JOIN form_embed_settings fes ON fes.form_id = f.id
             WHERE f.status = 'active' AND COALESCE(fes.public_page_hidden, 0) = 0
             ORDER BY f.updated_at DESC, f.id DESC"
        );
    }

    public static function count(): int
    {
        $row = Database::fetchOne('SELECT COUNT(*) AS c FROM forms');
        return (int) ($row['c'] ?? 0);
    }

    public static function find(int $id): ?array
    {
        return Database::fetchOne('SELECT * FROM forms WHERE id = ?', [$id]);
    }

    public static function findBySlug(string $slug): ?array
    {
        return Database::fetchOne('SELECT * FROM forms WHERE slug = ?', [$slug]);
    }

    public static function findActiveBySlug(string $slug): ?array
    {
        return Database::fetchOne(
            "SELECT f.*
             FROM forms f
             LEFT JOIN form_embed_settings fes ON fes.form_id = f.id
             WHERE f.slug = ? AND f.status = 'active' AND COALESCE(fes.public_page_hidden, 0) = 0",
            [$slug]
        );
    }

    public static function findActiveByPublicUuid(string $publicUuid): ?array
    {
        if (!\is_uuid_v4($publicUuid)) {
            return null;
        }
        return Database::fetchOne(
            "SELECT * FROM forms WHERE public_uuid = ? AND status IN ('active', 'hidden')",
            [strtolower($publicUuid)]
        );
    }

    /** Webhook 用（下書き・停止中フォームでも ID 取得のため UUID で引く）。 */
    public static function findByPublicUuid(string $publicUuid): ?array
    {
        if (!\is_uuid_v4($publicUuid)) {
            return null;
        }
        return Database::fetchOne(
            'SELECT * FROM forms WHERE public_uuid = ?',
            [strtolower($publicUuid)]
        );
    }

    /**
     * 添付保存用の public_uuid を返す（未設定なら付与して保存）。
     */
    public static function requirePublicUuid(array $form): string
    {
        $uuid = trim((string) ($form['public_uuid'] ?? ''));
        if ($uuid !== '' && is_uuid_v4($uuid)) {
            return strtolower($uuid);
        }

        $uuid = \uuid_v4();
        Database::execute(
            'UPDATE forms SET public_uuid = ? WHERE id = ?',
            [$uuid, (int) $form['id']]
        );
        return $uuid;
    }

    /**
     * 公開状態（DB 値）を管理画面表示用ラベルへ（フォーム編集の「公開状態」プルダウンと同じ文言）。
     */
    public static function statusLabel(string $status): string
    {
        return match ($status) {
            'draft' => '下書き',
            'active' => '公開中',
            'hidden' => '非表示',
            'archived' => '停止',
            default => $status,
        };
    }

    public static function create(array $data): int
    {
        $now = date('Y-m-d H:i:s');
        Database::execute(
            'INSERT INTO forms (
                slug, public_uuid, title, meta_html, custom_css, custom_js, header_html, footer_html, input_page_title, show_input_page_title, description, show_title, show_description, confirm_page_title, show_confirm_page_title, confirm_button_text, submit_button_text, back_button_text, confirm_message, thanks_page_title, show_thanks_page_title, thanks_message, thanks_button_text, thanks_button_url,
                admin_emails, mail_subject_admin, mail_template_admin,
                mail_transport, mail_from_email, mail_from_name, mail_smtp_host, mail_smtp_port, mail_smtp_secure, mail_smtp_username, mail_smtp_password, mail_smtp_timeout, mail_smtp_ehlo_host, mail_smtp_verify_peer, mail_smtp_verify_peer_name, mail_smtp_allow_self_signed,
                reply_enabled, reply_from_field_key, reply_subject, reply_template,
                line_notify_enabled, line_custom_enabled, line_channel_access_token, line_channel_secret, line_push_to_id, line_message_template, line_notify_include_images,
                publish_schedule_enabled, publish_rules, unpublish_rules, closed_page_title, show_closed_page_title, closed_message, closed_button_text, closed_button_url,
                status, created_at, updated_at
            ) VALUES (
                ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,
                ?,?,?,
                ?,?,?,?,?,?,?,?,?,?,?,?,?,
                ?,?,?,?,
                ?,?,?,?,?,?,?,
                ?,?,?,?,?,?,?,?,
                ?,?,?
            )',
            [
                $data['slug'],
                $data['public_uuid'] ?? \uuid_v4(),
                $data['title'],
                $data['meta_html'] ?? null,
                $data['custom_css'] ?? null,
                $data['custom_js'] ?? null,
                $data['header_html'] ?? null,
                $data['footer_html'] ?? null,
                $data['input_page_title'] ?? null,
                !empty($data['show_input_page_title']) ? 1 : 0,
                $data['description'] ?? null,
                !empty($data['show_title']) ? 1 : 0,
                !empty($data['show_description']) ? 1 : 0,
                $data['confirm_page_title'] ?? null,
                !empty($data['show_confirm_page_title']) ? 1 : 0,
                $data['confirm_button_text'] ?? null,
                $data['submit_button_text'] ?? null,
                $data['back_button_text'] ?? null,
                $data['confirm_message'] ?? null,
                $data['thanks_page_title'] ?? null,
                !empty($data['show_thanks_page_title']) ? 1 : 0,
                $data['thanks_message'] ?? null,
                $data['thanks_button_text'] ?? null,
                $data['thanks_button_url'] ?? null,
                $data['admin_emails'] ?? null,
                $data['mail_subject_admin'] ?? null,
                $data['mail_template_admin'] ?? null,
                $data['mail_transport'] ?? null,
                $data['mail_from_email'] ?? null,
                $data['mail_from_name'] ?? null,
                $data['mail_smtp_host'] ?? null,
                $data['mail_smtp_port'] ?? null,
                $data['mail_smtp_secure'] ?? null,
                $data['mail_smtp_username'] ?? null,
                $data['mail_smtp_password'] ?? null,
                $data['mail_smtp_timeout'] ?? null,
                $data['mail_smtp_ehlo_host'] ?? null,
                !empty($data['mail_smtp_verify_peer']) ? 1 : 0,
                !empty($data['mail_smtp_verify_peer_name']) ? 1 : 0,
                !empty($data['mail_smtp_allow_self_signed']) ? 1 : 0,
                !empty($data['reply_enabled']) ? 1 : 0,
                $data['reply_from_field_key'] ?? null,
                $data['reply_subject'] ?? null,
                $data['reply_template'] ?? null,
                !empty($data['line_notify_enabled']) ? 1 : 0,
                !empty($data['line_custom_enabled']) ? 1 : 0,
                $data['line_channel_access_token'] ?? null,
                $data['line_channel_secret'] ?? null,
                $data['line_push_to_id'] ?? null,
                $data['line_message_template'] ?? null,
                !empty($data['line_notify_include_images']) ? 1 : 0,
                !empty($data['publish_schedule_enabled']) ? 1 : 0,
                $data['publish_rules'] ?? null,
                $data['unpublish_rules'] ?? null,
                $data['closed_page_title'] ?? null,
                !empty($data['show_closed_page_title']) ? 1 : 0,
                $data['closed_message'] ?? null,
                $data['closed_button_text'] ?? null,
                $data['closed_button_url'] ?? null,
                $data['status'] ?? 'draft',
                $now,
                $now,
            ]
        );
        $id = Database::lastInsertId();
        self::saveDeliverySettings($id, $data);
        self::saveRetentionSettings($id, $data + [
            'submission_retention_days' => self::DEFAULT_RETENTION_DAYS,
            'submission_retention_action' => self::RETENTION_WARN,
            'submission_retention_enabled' => 1,
        ]);
        return $id;
    }

    public static function update(int $id, array $data): void
    {
        $now = date('Y-m-d H:i:s');
        Database::execute(
            'UPDATE forms SET
                slug = ?, title = ?, meta_html = ?, custom_css = ?, custom_js = ?, header_html = ?, footer_html = ?, input_page_title = ?, show_input_page_title = ?, description = ?, show_title = ?, show_description = ?, confirm_page_title = ?, show_confirm_page_title = ?, confirm_button_text = ?, submit_button_text = ?, back_button_text = ?, confirm_message = ?, thanks_page_title = ?, show_thanks_page_title = ?, thanks_message = ?, thanks_button_text = ?, thanks_button_url = ?,
                admin_emails = ?, mail_subject_admin = ?, mail_template_admin = ?,
                mail_transport = ?, mail_from_email = ?, mail_from_name = ?, mail_smtp_host = ?, mail_smtp_port = ?, mail_smtp_secure = ?, mail_smtp_username = ?, mail_smtp_password = ?, mail_smtp_timeout = ?, mail_smtp_ehlo_host = ?, mail_smtp_verify_peer = ?, mail_smtp_verify_peer_name = ?, mail_smtp_allow_self_signed = ?,
                reply_enabled = ?, reply_from_field_key = ?, reply_subject = ?, reply_template = ?,
                line_notify_enabled = ?, line_custom_enabled = ?, line_channel_access_token = ?, line_channel_secret = ?, line_push_to_id = ?, line_message_template = ?, line_notify_include_images = ?,
                publish_schedule_enabled = ?, publish_rules = ?, unpublish_rules = ?, closed_page_title = ?, show_closed_page_title = ?, closed_message = ?, closed_button_text = ?, closed_button_url = ?,
                status = ?, updated_at = ?
              WHERE id = ?',
            [
                $data['slug'],
                $data['title'],
                $data['meta_html'] ?? null,
                $data['custom_css'] ?? null,
                $data['custom_js'] ?? null,
                $data['header_html'] ?? null,
                $data['footer_html'] ?? null,
                $data['input_page_title'] ?? null,
                !empty($data['show_input_page_title']) ? 1 : 0,
                $data['description'] ?? null,
                !empty($data['show_title']) ? 1 : 0,
                !empty($data['show_description']) ? 1 : 0,
                $data['confirm_page_title'] ?? null,
                !empty($data['show_confirm_page_title']) ? 1 : 0,
                $data['confirm_button_text'] ?? null,
                $data['submit_button_text'] ?? null,
                $data['back_button_text'] ?? null,
                $data['confirm_message'] ?? null,
                $data['thanks_page_title'] ?? null,
                !empty($data['show_thanks_page_title']) ? 1 : 0,
                $data['thanks_message'] ?? null,
                $data['thanks_button_text'] ?? null,
                $data['thanks_button_url'] ?? null,
                $data['admin_emails'] ?? null,
                $data['mail_subject_admin'] ?? null,
                $data['mail_template_admin'] ?? null,
                $data['mail_transport'] ?? null,
                $data['mail_from_email'] ?? null,
                $data['mail_from_name'] ?? null,
                $data['mail_smtp_host'] ?? null,
                $data['mail_smtp_port'] ?? null,
                $data['mail_smtp_secure'] ?? null,
                $data['mail_smtp_username'] ?? null,
                $data['mail_smtp_password'] ?? null,
                $data['mail_smtp_timeout'] ?? null,
                $data['mail_smtp_ehlo_host'] ?? null,
                !empty($data['mail_smtp_verify_peer']) ? 1 : 0,
                !empty($data['mail_smtp_verify_peer_name']) ? 1 : 0,
                !empty($data['mail_smtp_allow_self_signed']) ? 1 : 0,
                !empty($data['reply_enabled']) ? 1 : 0,
                $data['reply_from_field_key'] ?? null,
                $data['reply_subject'] ?? null,
                $data['reply_template'] ?? null,
                !empty($data['line_notify_enabled']) ? 1 : 0,
                !empty($data['line_custom_enabled']) ? 1 : 0,
                $data['line_channel_access_token'] ?? null,
                $data['line_channel_secret'] ?? null,
                $data['line_push_to_id'] ?? null,
                $data['line_message_template'] ?? null,
                !empty($data['line_notify_include_images']) ? 1 : 0,
                !empty($data['publish_schedule_enabled']) ? 1 : 0,
                $data['publish_rules'] ?? null,
                $data['unpublish_rules'] ?? null,
                $data['closed_page_title'] ?? null,
                !empty($data['show_closed_page_title']) ? 1 : 0,
                $data['closed_message'] ?? null,
                $data['closed_button_text'] ?? null,
                $data['closed_button_url'] ?? null,
                $data['status'] ?? 'draft',
                $now,
                $id,
            ]
        );
        self::saveDeliverySettings($id, $data);
        if (array_key_exists('submission_retention_days', $data)
            || array_key_exists('submission_retention_action', $data)
            || array_key_exists('submission_retention_enabled', $data)) {
            self::saveRetentionSettings($id, $data);
        }
    }

    public static function normalizeRetentionDays($value): int
    {
        $days = is_numeric($value) ? (int) $value : self::DEFAULT_RETENTION_DAYS;
        return max(self::MIN_RETENTION_DAYS, min(self::MAX_RETENTION_DAYS, $days));
    }

    public static function normalizeRetentionAction($value): string
    {
        return (string) $value === self::RETENTION_DELETE ? self::RETENTION_DELETE : self::RETENTION_WARN;
    }

    public static function retentionEnabled(array $form): bool
    {
        return !array_key_exists('submission_retention_enabled', $form)
            || $form['submission_retention_enabled'] === null
            || (int) $form['submission_retention_enabled'] === 1;
    }

    public static function retentionDays(array $form): int
    {
        return self::normalizeRetentionDays($form['submission_retention_days'] ?? null);
    }

    public static function retentionDeletes(array $form): bool
    {
        return self::normalizeRetentionAction($form['submission_retention_action'] ?? null) === self::RETENTION_DELETE;
    }

    /**
     * この日時より前に受信した送信は保存期間を過ぎている（Y-m-d H:i:s）。
     */
    public static function retentionCutoff(array $form, ?int $now = null): string
    {
        return date('Y-m-d H:i:s', ($now ?? time()) - self::retentionDays($form) * 86400);
    }

    public static function isSubmissionExpired(array $form, string $submittedAt, ?string $cutoff = null): bool
    {
        return $submittedAt !== '' && $submittedAt < ($cutoff ?? self::retentionCutoff($form));
    }

    public static function countExpiredSubmissions(array $form): int
    {
        if (!self::retentionEnabled($form)) {
            return 0;
        }
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS c FROM submissions WHERE form_id = ? AND submitted_at < ?',
            [(int) $form['id'], self::retentionCutoff($form)]
        );
        return (int) ($row['c'] ?? 0);
    }

    private static function saveRetentionSettings(int $id, array $data): void
    {
        Database::execute(
            'UPDATE forms SET submission_retention_days = ?, submission_retention_action = ?, submission_retention_enabled = ? WHERE id = ?',
            [
                self::normalizeRetentionDays($data['submission_retention_days'] ?? null),
                self::normalizeRetentionAction($data['submission_retention_action'] ?? null),
                self::retentionEnabled($data) ? 1 : 0,
                $id,
            ]
        );
    }

    public static function isMailOnly(array $form): bool
    {
        return (string) ($form['submission_storage_mode'] ?? self::STORAGE_DATABASE) === self::STORAGE_MAIL_ONLY;
    }

    public static function normalizeAttachmentMaxBytes($value): int
    {
        $bytes = is_numeric($value) ? (int) $value : self::DEFAULT_MAIL_ATTACHMENT_MAX_BYTES;
        return max(self::MIN_MAIL_ATTACHMENT_MAX_BYTES, min(self::MAX_MAIL_ATTACHMENT_MAX_BYTES, $bytes));
    }

    public static function smtpFingerprint(array $form): string
    {
        $emails = array_values(array_filter(array_map('trim', preg_split('/[,;]+/', (string) ($form['admin_emails'] ?? '')) ?: [])));
        sort($emails);
        return hash('sha256', implode("\0", [
            strtolower(trim((string) ($form['mail_transport'] ?? ''))),
            strtolower(trim((string) ($form['mail_from_email'] ?? ''))),
            trim((string) ($form['mail_from_name'] ?? '')),
            strtolower(trim((string) ($form['mail_smtp_host'] ?? ''))),
            (string) (int) ($form['mail_smtp_port'] ?? 0),
            strtolower(trim((string) ($form['mail_smtp_secure'] ?? ''))),
            trim((string) ($form['mail_smtp_username'] ?? '')),
            (string) ($form['mail_smtp_password'] ?? ''),
            (string) (int) ($form['mail_smtp_timeout'] ?? 0),
            trim((string) ($form['mail_smtp_ehlo_host'] ?? '')),
            !empty($form['mail_smtp_verify_peer']) ? '1' : '0',
            !empty($form['mail_smtp_verify_peer_name']) ? '1' : '0',
            !empty($form['mail_smtp_allow_self_signed']) ? '1' : '0',
            implode(',', $emails),
        ]));
    }

    public static function smtpTestIsCurrent(array $form): bool
    {
        $stored = trim((string) ($form['smtp_test_fingerprint'] ?? ''));
        return $stored !== '' && trim((string) ($form['smtp_tested_at'] ?? '')) !== ''
            && hash_equals($stored, self::smtpFingerprint($form));
    }

    public static function markSmtpTested(int $id): void
    {
        $form = self::find($id);
        if ($form === null) {
            throw new \RuntimeException('フォームが見つかりません。');
        }
        Database::execute(
            'UPDATE forms SET smtp_tested_at = ?, smtp_test_fingerprint = ?, updated_at = ? WHERE id = ?',
            [date('Y-m-d H:i:s'), self::smtpFingerprint($form), date('Y-m-d H:i:s'), $id]
        );
    }

    private static function saveDeliverySettings(int $id, array $data): void
    {
        $mode = (string) ($data['submission_storage_mode'] ?? self::STORAGE_DATABASE);
        if (!in_array($mode, [self::STORAGE_DATABASE, self::STORAGE_MAIL_ONLY], true)) {
            $mode = self::STORAGE_DATABASE;
        }
        $testedAt = trim((string) ($data['smtp_tested_at'] ?? ''));
        $fingerprint = trim((string) ($data['smtp_test_fingerprint'] ?? ''));
        Database::execute(
            'UPDATE forms SET submission_storage_mode = ?, mail_attachment_max_bytes = ?, smtp_tested_at = ?, smtp_test_fingerprint = ? WHERE id = ?',
            [$mode, self::normalizeAttachmentMaxBytes($data['mail_attachment_max_bytes'] ?? null), $testedAt !== '' ? $testedAt : null, $fingerprint !== '' ? $fingerprint : null, $id]
        );
    }

    /**
     * @param array<string, mixed> $formData
     * @param array<int, array<string, mixed>> $inputPages
     * @param array<int, array<string, mixed>> $fieldGroups
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $branchRules
     * @param array<string, mixed>|null $actor
     */
    public static function createWithRelations(
        array $formData,
        array $inputPages,
        array $fieldGroups,
        array $fields,
        array $branchRules,
        string $versionAction,
        ?array $actor = null
    ): int {
        return Database::transaction(function () use ($formData, $inputPages, $fieldGroups, $fields, $branchRules, $versionAction, $actor): int {
            $id = self::create($formData);
            FormInputPage::replaceForForm($id, $inputPages, false);
            FormFieldGroup::replaceForForm($id, $fieldGroups, false);
            FormField::replaceForForm($id, $fields, false);
            FormBranchRule::replaceForForm($id, $branchRules, false);
            FormVersion::createSnapshot($id, $versionAction, $actor);
            return $id;
        });
    }

    /**
     * @param array<string, mixed> $formData
     * @param array<int, array<string, mixed>> $inputPages
     * @param array<int, array<string, mixed>> $fieldGroups
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $branchRules
     * @param array<string, mixed>|null $actor
     */
    public static function updateWithRelations(
        int $id,
        array $formData,
        array $inputPages,
        array $fieldGroups,
        array $fields,
        array $branchRules,
        string $versionAction,
        ?array $actor = null
    ): void {
        Database::transaction(function () use ($id, $formData, $inputPages, $fieldGroups, $fields, $branchRules, $versionAction, $actor): void {
            if ($versionAction === FormVersion::ACTION_RESTORE) {
                $current = self::find($id) ?? [];
                $formData['mail_smtp_password'] = (string) ($current['mail_smtp_password'] ?? '');
                $formData['smtp_tested_at'] = $current['smtp_tested_at'] ?? null;
                $formData['smtp_test_fingerprint'] = $current['smtp_test_fingerprint'] ?? null;
                $formData['line_channel_access_token'] = (string) ($current['line_channel_access_token'] ?? '');
                $formData['line_channel_secret'] = (string) ($current['line_channel_secret'] ?? '');
            }
            self::update($id, $formData);
            FormInputPage::replaceForForm($id, $inputPages, false);
            FormFieldGroup::replaceForForm($id, $fieldGroups, false);
            FormField::replaceForForm($id, $fields, false);
            FormBranchRule::replaceForForm($id, $branchRules, false);
            if ($versionAction === FormVersion::ACTION_UPDATE) {
                FormVersion::createSnapshotForUpdate($id, $actor);
            } else {
                FormVersion::createSnapshot($id, $versionAction, $actor);
            }
        });
    }

    /**
     * @param array<string, mixed>|null $actor
     */
    public static function duplicate(int $id, ?array $actor = null): int
    {
        return Database::transaction(function () use ($id, $actor): int {
            $source = self::find($id);
            if ($source === null) {
                throw new \RuntimeException('複製元のフォームが見つかりません。');
            }

            $copy = $source;
            $copy['slug'] = self::generateCopySlug((string) ($source['slug'] ?? 'form'));
            $copy['public_uuid'] = \uuid_v4();
            $copy['title'] = mb_substr(trim((string) ($source['title'] ?? 'フォーム')) . ' のコピー', 0, 200);
            $copy['status'] = 'draft';
            $copy['submission_storage_mode'] = self::STORAGE_DATABASE;
            $copy['smtp_tested_at'] = null;
            $copy['smtp_test_fingerprint'] = null;
            $copy['line_custom_enabled'] = 0;
            $copy['line_channel_access_token'] = null;
            $copy['line_channel_secret'] = null;
            $copy['line_push_to_id'] = null;
            $copy['line_setup_checklist'] = null;

            $newId = self::create($copy);
            FormInputPage::duplicateForForm($id, $newId);
            FormFieldGroup::duplicateForForm($id, $newId);
            FormField::duplicateForForm($id, $newId);
            FormBranchRule::duplicateForForm($id, $newId);
            FormVersion::createSnapshot($newId, FormVersion::ACTION_DUPLICATE, $actor);

            return $newId;
        });
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM forms WHERE id = ?', [$id]);
    }

    public static function isSlugAvailable(string $slug, ?int $excludeId = null): bool
    {
        if ($excludeId === null) {
            $row = Database::fetchOne('SELECT id FROM forms WHERE slug = ?', [$slug]);
        } else {
            $row = Database::fetchOne('SELECT id FROM forms WHERE slug = ? AND id <> ?', [$slug, $excludeId]);
        }
        return $row === null;
    }

    private static function generateCopySlug(string $sourceSlug): string
    {
        $base = preg_replace('/[^a-zA-Z0-9_-]+/', '-', trim($sourceSlug)) ?: 'form';
        $base = trim($base, '-_');
        if ($base === '') {
            $base = 'form';
        }

        for ($i = 1; $i <= 999; $i++) {
            $suffix = $i === 1 ? '-copy' : '-copy-' . $i;
            $candidate = mb_substr($base, 0, 64 - strlen($suffix)) . $suffix;
            if (self::isSlugAvailable($candidate)) {
                return $candidate;
            }
        }

        return \uuid_v4();
    }

    public const LINE_SETUP_CHECKLIST_CREATE_MESSAGING_API_CHANNEL = 'create_messaging_api_channel';
    public const LINE_SETUP_CHECKLIST_ENABLE_MESSAGING_API = 'enable_messaging_api';
    public const LINE_SETUP_CHECKLIST_SET_CHANNEL_SECRET = 'set_channel_secret';
    public const LINE_SETUP_CHECKLIST_ISSUE_CHANNEL_ACCESS_TOKEN = 'issue_channel_access_token';
    public const LINE_SETUP_CHECKLIST_SET_CHANNEL_ACCESS_TOKEN = 'set_channel_access_token';
    public const LINE_SETUP_CHECKLIST_SET_WEBHOOK_URL = 'set_webhook_url';
    public const LINE_SETUP_CHECKLIST_ENABLE_WEBHOOK = 'enable_webhook';
    public const LINE_SETUP_CHECKLIST_VERIFY_WEBHOOK_URL = 'verify_webhook_url';
    public const LINE_SETUP_CHECKLIST_ALLOW_GROUP_MULTIPERSON_CHAT = 'allow_group_multiperson_chat';
    public const LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP = 'line_talk_send_setup';
    public const LINE_SETUP_CHECKLIST_SET_LINE_PUSH_TO_ID = 'set_line_push_to_id';
    public const LINE_SETUP_CHECKLIST_LINE_TALK_NOTIFY_TEST = 'line_talk_notify_test';

    /** lineSetupChecklistAssertManualCheckAllowed 等の InvalidArgumentException メッセージ（HTTP 応答マッピングと一致させる） */
    public const LINE_SETUP_CHECKLIST_EX_PREVIOUS_INCOMPLETE = 'Previous checklist items are incomplete.';
    public const LINE_SETUP_CHECKLIST_EX_MANUAL_UNCHECK = 'Manual checklist item cannot be unchecked.';
    public const LINE_SETUP_CHECKLIST_EX_INVALID_FORM_ITEM = 'Invalid LINE setup checklist item.';
    public const LINE_SETUP_CHECKLIST_EX_INVALID_SITE_ITEM = 'Invalid LINE site setup checklist item.';

    /**
     * @return list<string>
     */
    public static function lineFormSetupChecklistItemKeys(): array
    {
        return \Core\LineSiteConfig::siteChecklistItemKeys();
    }

    /**
     * @return list<string>
     */
    public static function lineSetupChecklistItemKeys(): array
    {
        return self::lineFormSetupChecklistItemKeys();
    }

    /**
     * @return list<array{key: string, label: string, help?: string, check_hint?: string, external_url?: string, external_label?: string, manual_check?: bool, auto_checked_when?: string}>
     */
    public static function lineSetupChecklistAllItemDefinitions(): array
    {
        return [
            [
                'key' => self::LINE_SETUP_CHECKLIST_CREATE_MESSAGING_API_CHANNEL,
                'label' => 'LINE公式アカウントを作成する',
                'check_hint' => '登録を完了しました',
                'external_url' => 'https://developers.line.biz/console/',
                'external_label' => 'LINE公式アカウント作成',
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_ENABLE_MESSAGING_API,
                'label' => 'Messaging APIを利用する',
                'check_hint' => '設定を完了しました',
                'help' => 'LINE公式アカウントの設定画面 > Messaging APIに移動して、「Messaging APIを利用する」を選択します',
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_SET_CHANNEL_SECRET,
                'label' => 'チャネルシークレットを設定する',
                'manual_check' => false,
                'auto_checked_when' => 'line_channel_secret_configured',
                'help' => 'LINE公式アカウントの設定画面 > Messaging APIに移動して、Channel secretを取得。入力欄に入力して「保存」ボタンをクリックしてください。',
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_ISSUE_CHANNEL_ACCESS_TOKEN,
                'label' => 'チャネルアクセストークンの発行',
                'check_hint' => 'トークンを発行しました',
                'help' => 'LINE DEVELOPERから作成したチャネルを選択してください。「Messaging API設定」に移動して「チャネルアクセストークン（長期）」を発行してください',
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_SET_CHANNEL_ACCESS_TOKEN,
                'label' => 'チャネルアクセストークンを設定する',
                'manual_check' => false,
                'auto_checked_when' => 'line_channel_access_token_configured',
                'help' => '発行した Channel access token を入力欄に貼り付け、「保存」ボタンをクリックしてください。',
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_SET_WEBHOOK_URL,
                'label' => 'Webhook URLの設定',
                'check_hint' => '更新ボタンをクリックしました',
                'check_hint_after_extra' => true,
                'help' => 'LINE DEVELOPERページの「Messaging API設定」に移動して「編集」ボタンをクリックしてください。以下のURLを入力欄に入力して「更新」ボタンをクリックしてください',
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_ENABLE_WEBHOOK,
                'label' => 'Webhook の利用をONにする',
                'check_hint' => 'Webhook の利用をONにしました',
                'help' => 'LINE DEVELOPERページの「Messaging API設定」に移動して「Webhook の利用」を ON にしてください',
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_VERIFY_WEBHOOK_URL,
                'label' => 'Webhook URLの検証をする',
                'check_hint' => '成功のステータスが確認ができました',
                'help' => 'LINE DEVELOPERページの「Messaging API設定」に移動して「Webhook URL」の下にある「検証」ボタンをクリックしてください',
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_ALLOW_GROUP_MULTIPERSON_CHAT,
                'label' => 'グループトーク・複数人トークへの参加を許可する',
                'help' => 'LINE DEVELOPERページの「Messaging API設定」に移動して「グループトーク・複数人トークへの参加を許可する」の「編集」ボタンをクリックしてください。',
                'help_sub' => 'LINE公式アカウントの設定画面から「グループ・複数人トークへの参加を許可する」をONにしてください。',
                'check_hint' => '設定を変更しました',
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP,
                'label' => 'LINEトークへの送信先ID取得',
                'manual_check' => false,
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_SET_LINE_PUSH_TO_ID,
                'label' => '送信先IDの設定',
                'manual_check' => false,
                'auto_checked_when' => 'line_push_to_id_configured',
                'help' => 'Webhook で記録した ID を入力欄に貼り付け、「保存」ボタンをクリックしてください。',
            ],
            [
                'key' => self::LINE_SETUP_CHECKLIST_LINE_TALK_NOTIFY_TEST,
                'label' => 'LINEトークへの通知テスト',
                'help' => '設定された送信先にテストメッセージを送ります。「テスト送信」をクリックしてテストメッセージを送信してください。',
                'check_hint' => 'テストメッセージを確認しました',
                'check_hint_after_extra' => true,
            ],
        ];
    }

    /**
     * @return list<array{key: string, label: string, help?: string, check_hint?: string, external_url?: string, external_label?: string, manual_check?: bool, auto_checked_when?: string}>
     */
    public static function lineSetupChecklistItemDefinitions(): array
    {
        $allowed = array_fill_keys(self::lineFormSetupChecklistItemKeys(), true);
        $items = [];
        foreach (\Core\LineSiteConfig::siteChecklistItemDefinitions() as $item) {
            $key = (string) ($item['key'] ?? '');
            if ($key !== '' && isset($allowed[$key])) {
                $items[] = $item;
            }
        }

        return $items;
    }

    public static function lineSetupChecklistItemIsManual(string $itemKey): bool
    {
        foreach (self::lineSetupChecklistAllItemDefinitions() as $item) {
            if (($item['key'] ?? '') === $itemKey) {
                return ($item['manual_check'] ?? true) !== false;
            }
        }

        return true;
    }

    /**
     * @param array<string, bool> $state lineSetupChecklistStateForDisplay 相当
     * @param list<array<string, mixed>> $items
     */
    public static function lineSetupChecklistItemIsUnlocked(string $itemKey, array $state, array $items): bool
    {
        $priorComplete = true;
        foreach ($items as $item) {
            $key = (string) ($item['key'] ?? '');
            if ($key === '') {
                continue;
            }
            if ($key === $itemKey) {
                return $priorComplete;
            }
            if (empty($state[$key])) {
                $priorComplete = false;
            }
        }

        return true;
    }

    /**
     * @param array<string, bool> $state
     * @param list<array<string, mixed>> $items
     */
    public static function lineSetupChecklistAssertManualCheckAllowed(string $itemKey, bool $checked, array $state, array $items): void
    {
        if (!self::lineSetupChecklistItemIsManual($itemKey)) {
            return;
        }
        if (!$checked) {
            throw new \InvalidArgumentException(self::LINE_SETUP_CHECKLIST_EX_MANUAL_UNCHECK);
        }
        if (!self::lineSetupChecklistItemIsUnlocked($itemKey, $state, $items)) {
            throw new \InvalidArgumentException(self::LINE_SETUP_CHECKLIST_EX_PREVIOUS_INCOMPLETE);
        }
    }

    /**
     * @param array<string, bool> $state lineSetupChecklistStateForDisplay 相当
     */
    public static function lineSetupChecklistIsComplete(array $state): bool
    {
        $keys = self::lineSetupChecklistItemKeys();
        if ($keys === []) {
            return false;
        }
        foreach ($keys as $key) {
            if (empty($state[$key])) {
                return false;
            }
        }

        return true;
    }

    /**
     * DB 行（prepareFormForEdit 前）からチェックリスト完了を判定する。
     *
     * @param array<string, mixed> $form forms 行
     */
    public static function lineSetupChecklistIsCompleteForFormRow(array $form): bool
    {
        if (empty($form['line_custom_enabled'])) {
            return \Core\LineSiteConfig::isSetupComplete();
        }

        return self::lineSetupChecklistIsComplete(self::lineSetupChecklistStateForDisplay($form));
    }

    /**
     * 手動チェック JSON と auto_checked_when 項目（credential 設定済み等）をマージした表示用状態。
     *
     * @param array<string, mixed> $form prepareFormForEdit 相当（*_configured フラグ含む）
     * @return array<string, bool>
     */
    public static function lineSetupChecklistStateForDisplay(array $form): array
    {
        $state = self::decodeLineSetupChecklist($form['line_setup_checklist'] ?? null);
        foreach (self::lineSetupChecklistItemDefinitions() as $item) {
            $key = (string) ($item['key'] ?? '');
            $whenField = trim((string) ($item['auto_checked_when'] ?? ''));
            if ($key === '' || $whenField === '') {
                continue;
            }
            if (!empty($form[$whenField])) {
                $state[$key] = true;
            } else {
                unset($state[$key]);
            }
        }
        if (!empty($form['line_custom_enabled'])) {
            $fid = (int) ($form['id'] ?? 0);
            if (LineWebhookTarget::existsForForm($fid, ['user', 'group', 'room'])) {
                $state[self::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP] = true;
            } else {
                unset($state[self::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP]);
            }
        }

        return $state;
    }

    /** @deprecated サイト共通 targets を LineWebhookTarget::existsForSite で参照 */
    public static function lineTalkSendSetupWebhookIdObtained(int $formId): bool
    {
        return LineWebhookTarget::existsForForm($formId, ['user', 'group', 'room']);
    }

    /**
     * フォーム個別 LINE 連携向け。トーク送信先の有無で line_talk_send_setup を同期する。
     *
     * @param list<string> $types 空のときは user / group / room すべてを対象にする
     */
    public static function syncLineTalkSendSetupChecklistForFormTypes(int $formId, array $types): void
    {
        $formId = max(0, $formId);
        $checkTypes = $types;
        if ($checkTypes === []) {
            $checkTypes = ['user', 'group', 'room'];
        }
        $checked = LineWebhookTarget::existsForForm($formId, $checkTypes);
        self::updateLineSetupChecklistItem($formId, self::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP, $checked);
    }

    public static function syncLineTalkSendSetupChecklistForFormPanel(int $formId, string $panelId): bool
    {
        $types = $panelId === 'line-talk-group' ? ['group', 'room'] : ['user'];
        self::syncLineTalkSendSetupChecklistForFormTypes($formId, $types);

        return LineWebhookTarget::existsForForm($formId, $types);
    }

    /**
     * @param mixed $raw
     * @return array<string, bool>
     */
    public static function decodeLineSetupChecklist($raw): array
    {
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
        } elseif (is_array($raw)) {
            $decoded = $raw;
        } else {
            $decoded = [];
        }
        if (!is_array($decoded)) {
            return [];
        }
        $allowed = array_fill_keys(self::lineSetupChecklistItemKeys(), true);
        $normalized = [];
        foreach ($decoded as $key => $value) {
            $key = (string) $key;
            if (!isset($allowed[$key]) || !$value) {
                continue;
            }
            $normalized[$key] = true;
        }

        return $normalized;
    }

    public static function updateLineSetupChecklistItem(int $formId, string $itemKey, bool $checked): void
    {
        if (!in_array($itemKey, self::lineSetupChecklistItemKeys(), true)) {
            throw new \InvalidArgumentException(self::LINE_SETUP_CHECKLIST_EX_INVALID_FORM_ITEM);
        }
        $form = self::find($formId);
        if (!$form) {
            throw new \RuntimeException('Form not found.');
        }
        $displayForm = $form;
        $displayForm['line_channel_secret_configured'] = trim((string) ($form['line_channel_secret'] ?? '')) !== '' ? 1 : 0;
        $displayForm['line_channel_access_token_configured'] = trim((string) ($form['line_channel_access_token'] ?? '')) !== '' ? 1 : 0;
        $displayForm['line_push_to_id_configured'] = trim((string) ($form['line_push_to_id'] ?? '')) !== '' ? 1 : 0;
        $persistedManual = self::decodeLineSetupChecklist($form['line_setup_checklist'] ?? null);
        $displayFormForAssert = $displayForm;
        $displayFormForAssert['line_setup_checklist'] = $persistedManual;
        self::lineSetupChecklistAssertManualCheckAllowed(
            $itemKey,
            $checked,
            self::lineSetupChecklistStateForDisplay($displayFormForAssert),
            self::lineSetupChecklistItemDefinitions()
        );
        $state = self::decodeLineSetupChecklist($form['line_setup_checklist'] ?? null);
        if ($checked) {
            $state[$itemKey] = true;
        } else {
            unset($state[$itemKey]);
        }
        $json = $state === [] ? null : json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        Database::execute(
            'UPDATE forms SET line_setup_checklist = ?, updated_at = ? WHERE id = ?',
            [$json, date('Y-m-d H:i:s'), $formId]
        );
    }

    public static function resetLineAccountLink(int $formId): void
    {
        $form = self::find($formId);
        if ($form === null) {
            throw new \RuntimeException('Form not found.');
        }
        \Core\LineAccountScope::form($form)->resetAccountLink();
    }
}
