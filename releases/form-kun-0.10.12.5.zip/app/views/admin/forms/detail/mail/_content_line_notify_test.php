<?php /** チェックリスト is-extra: LINEトークへの通知テスト */
$lineNotifyTestContext = (string) ($lineNotifyTestContext ?? 'form');
$formId = (int) ($form['id'] ?? 0);
if ($lineNotifyTestContext === 'site') {
    $lineNotifyTestUrl = base_path('/admin/settings/line/test-line');
    $canTest = \Core\LineSiteConfig::isPushToIdConfigured()
        && \Core\LineSiteConfig::isChannelAccessTokenConfigured();
} else {
    $lineNotifyTestUrl = $formId > 0
        ? base_path('/admin/forms/' . $formId . '/line/test-line')
        : '';
    if (!empty($form['line_custom_enabled'])) {
        $scope = \Core\LineAccountScope::form($form);
        $hasPush = trim((string) $scope->pushToId()) !== '';
        // 編集画面では prepareFormForEdit が token を空にマスクするが、configured フラグは残る
        $hasToken = trim((string) $scope->channelAccessToken()) !== ''
            || !empty($form['line_channel_access_token_configured']);
        $canTest = $hasPush && $hasToken;
    } else {
        $scope = \Core\LineAccountScope::site();
        $canTest = trim((string) $scope->pushToId()) !== ''
            && trim((string) $scope->channelAccessToken()) !== '';
    }
}
?>
<div data-module="c-lineNotifyTestPush01"<?= $lineNotifyTestUrl !== '' ? ' data-test-url="' . e($lineNotifyTestUrl) . '"' : '' ?> data-csrf-name="_token">
    <div class="area is-actions">
        <?php
        admin_m_btn01_button_wrap('テスト送信', [
            'type' => 'button',
            'class' => 'is-primary',
            'disabled' => $canTest ? null : true,
        ]);
        ?>
    </div>
</div>
