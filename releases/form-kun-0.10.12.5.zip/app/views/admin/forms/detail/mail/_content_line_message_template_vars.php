<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — 使用可能な変数一覧 */ ?>
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('件名・本文で使用可能な変数')); ?>
    </div>
    <div class="area is-field">
        <?php admin_c_copy_tag_list01(['{{field_key}}', '{{__all__}}', '{{__form_title__}}', '{{__submitted_at__}}', '{{__ip__}}']); ?>
        <p class="text is-help"><code>{{__all__}}</code> 使用時、画像ファイル項目は条件が揃えば <strong>ファイル名の次行に署名 URL</strong> が付きます（DB 保存・メール送信のみのいずれも可。フォームが <strong>https</strong> で公開されていれば有効。http のみの環境では URL は付きません）。メールのみはサーバーの PHP temp ディレクトリへの書き込みも必要です。上の「<strong>画像をメッセージに含める</strong>」を<strong>オン</strong>にすると、さらに続けて image メッセージ（プレビュー）も送られます。<strong>オフ</strong>のときはテキストに URL のみで image Push は行いません（<code>{{__all__}}</code> は閉じ <code>}}</code> まで正確に）。</p>
    </div>
    <?php admin_m_input_set01_close(); ?>
