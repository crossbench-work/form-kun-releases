<?php
/** c-formBlock01 / チェックリスト is-extra: LINE通知 — Webhook URL（表示のみ） */
/** @var bool $lineWebhookHideTitle チェックリスト内など見出しを省略する */
$lineWebhookHideTitle = !empty($lineWebhookHideTitle);
$lineWebhookHideHelp = !empty($lineWebhookHideHelp);
?>
    <?php admin_m_input_set01_open(); ?>
    <?php if (!$lineWebhookHideTitle): ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('Webhook URL')); ?>
    </div>
    <?php endif; ?>
    <div class="area is-field">
        <?php
        $webhookUrl = isset($lineWebhookScope) && $lineWebhookScope instanceof \Core\LineAccountScope
            ? $lineWebhookScope->webhookUrl()
            : \Core\LineSiteConfig::webhookUrl();
        ?>
        <?php admin_c_copy_tag_list01([$webhookUrl]); ?>
        <?php if (!$lineWebhookHideHelp): ?>
        <?php if (isset($lineWebhookScope) && $lineWebhookScope instanceof \Core\LineAccountScope && !$lineWebhookScope->isSite()): ?>
        <p class="text is-help is-sub">このフォーム専用の Webhook パスです。サイト設定の base URL（HTTPS）が土台になります。LINE Developers の Webhook URL に登録してください。</p>
        <?php else: ?>
        <p class="text is-help is-sub">サイト設定の base URL（HTTPS）を LINE Developers の Webhook URL に登録してください。</p>
        <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php admin_m_input_set01_close(); ?>
