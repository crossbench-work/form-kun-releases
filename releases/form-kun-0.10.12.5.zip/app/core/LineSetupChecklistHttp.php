<?php
namespace Core;

use Models\Form;

/**
 * LINE セットアップチェックリストの JSON POST 用: InvalidArgumentException をユーザー向け文言へ。
 */
final class LineSetupChecklistHttp
{
    public static function jsonMessageForInvalidArgument(\InvalidArgumentException $e): string
    {
        $msg = trim($e->getMessage());
        if ($msg === Form::LINE_SETUP_CHECKLIST_EX_PREVIOUS_INCOMPLETE) {
            return '先に完了していないチェック項目があります。';
        }
        if ($msg === Form::LINE_SETUP_CHECKLIST_EX_MANUAL_UNCHECK) {
            return '手動でチェックした項目は、ここからチェックを外せません。';
        }
        if ($msg === Form::LINE_SETUP_CHECKLIST_EX_INVALID_FORM_ITEM || $msg === Form::LINE_SETUP_CHECKLIST_EX_INVALID_SITE_ITEM) {
            return '不正なチェック項目です。';
        }

        return '不正なチェック項目です。';
    }
}
