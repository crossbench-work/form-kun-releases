<?php
namespace Core;

class LineSubmissionNotifier
{
    private const MAX_TEXT_LENGTH = 5000;

    /**
     * @param array<string, mixed> $form
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    public static function notify(array $form, array $fields, array $values, ?int $submissionId, array $mailOnlyAttachments = []): void
    {
        try {
            self::notifyInternal($form, $fields, $values, $submissionId, $mailOnlyAttachments);
        } catch (\Throwable $e) {
            error_log('[formkun] line notify failed for form ' . (int) ($form['id'] ?? 0));
        }
    }

    /** @param array<string, mixed> $form */
    public static function sendTest(array $form): bool
    {
        $scope = LineAccountScope::forNotification($form);
        $token = $scope->channelAccessToken();
        $to = $scope->pushToId();
        if ($token === '' || $to === '') {
            return false;
        }

        $text = "[ふぉーむくん] LINE通知テスト\nこのメッセージを受信できた場合、現在の設定で LINE Push できます。";

        return LineMessagingClient::pushText($token, $to, $text);
    }

    /**
     * 表示設定テンプレートをサンプル値でレンダリングして Push（テスト用）。
     *
     * @param array<string, mixed> $form DB 行（token / push_to_id 含む）
     * @param array<int, array<string, mixed>> $fields
     * @param string $templateFromRequest 画面上のテンプレ（空なら DB / デフォルトへフォールバック）
     */
    public static function sendMessageTest(array $form, array $fields, string $templateFromRequest): bool
    {
        $scope = LineAccountScope::forNotification($form);
        $token = $scope->channelAccessToken();
        $to = $scope->pushToId();
        if ($token === '' || $to === '') {
            return false;
        }

        $values = self::sampleValuesForLineMessageTest($fields);
        $fileResolver = new LineNotifyFileResolver(null, []);
        $text = self::buildPushText($form, $fields, $values, null, $templateFromRequest, $fileResolver);
        if ($text === '') {
            return false;
        }

        $template = self::resolveLineMessageTemplate($form, $templateFromRequest);
        $includeImages = self::lineNotifyIncludeImages($form);
        [$textMessages, $imageMessages] = self::composePushMessageSets(
            $text,
            $template,
            $fileResolver,
            $fields,
            $includeImages
        );
        if ($textMessages === []) {
            return false;
        }

        if (!LineMessagingClient::pushMessages($token, $to, $textMessages)) {
            return false;
        }

        if ($imageMessages !== [] && !LineMessagingClient::pushMessages($token, $to, $imageMessages)) {
            return false;
        }

        return true;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<string, mixed>
     */
    public static function sampleValuesForLineMessageTest(array $fields): array
    {
        $values = [];
        foreach ($fields as $field) {
            $type = (string) ($field['type'] ?? '');
            if (\Models\FormField::isDisplayOnlyType($type)) {
                continue;
            }
            $key = (string) ($field['field_key'] ?? '');
            if ($key === '') {
                continue;
            }
            if ($type === 'checkbox') {
                $values[$key] = ['（サンプル）'];
            } elseif ($type === 'file') {
                $values[$key] = 'sample.txt';
            } else {
                $values[$key] = '（サンプル）';
            }
        }

        return $values;
    }

    /**
     * @param array<string, mixed> $form
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    private static function buildPushText(
        array $form,
        array $fields,
        array $values,
        ?int $submissionId,
        ?string $templateOverride = null,
        ?LineNotifyFileResolver $fileResolver = null
    ): string {
        $formId = (int) ($form['id'] ?? 0);
        $submissionUrl = self::submissionUrl($formId, $submissionId);

        $context = [
            'submitted_at' => date('Y-m-d H:i:s'),
            'form_title' => (string) ($form['title'] ?? ''),
            'ip' => client_ip(),
        ];

        $template = self::resolveLineMessageTemplate($form, $templateOverride);

        if ($fileResolver !== null) {
            $context['line_public_file_urls'] = $fileResolver->publicUrlsByFieldKey($fields);
        }

        $text = Mailer::renderTemplate($template, $fields, $values, $context);
        $text = str_replace('{{__submission_url__}}', $submissionUrl, $text);
        if (mb_strlen($text) > self::MAX_TEXT_LENGTH) {
            $text = mb_substr($text, 0, self::MAX_TEXT_LENGTH);
        }

        return $text;
    }

    /**
     * @param array<string, mixed> $form
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    private static function notifyInternal(array $form, array $fields, array $values, ?int $submissionId, array $mailOnlyAttachments = []): void
    {
        if (empty($form['line_notify_enabled'])) {
            return;
        }

        $scope = LineAccountScope::forNotification($form);
        if (!$scope->isSetupComplete()) {
            return;
        }

        $token = $scope->channelAccessToken();
        $to = $scope->pushToId();
        if ($token === '' || $to === '') {
            return;
        }

        $formId = (int) ($form['id'] ?? 0);
        $template = self::resolveLineMessageTemplate($form, null);
        $fileResolver = new LineNotifyFileResolver($submissionId, $mailOnlyAttachments);
        $text = self::buildPushText($form, $fields, $values, $submissionId, null, $fileResolver);
        if ($text === '') {
            return;
        }

        $includeImages = self::lineNotifyIncludeImages($form);
        if ($includeImages) {
            self::logPublicUrlSummary($fields, $fileResolver);
        }

        [$textMessages, $imageMessages] = self::composePushMessageSets(
            $text,
            $template,
            $fileResolver,
            $fields,
            $includeImages
        );
        if ($textMessages === []) {
            return;
        }

        if (!LineMessagingClient::pushMessages($token, $to, $textMessages)) {
            error_log('[formkun] line push rejected for form ' . $formId);

            return;
        }

        if ($imageMessages !== [] && !LineMessagingClient::pushMessages($token, $to, $imageMessages)) {
            error_log('[formkun] line image push rejected for form ' . $formId);
        }
    }

    /**
     * @param array<string, mixed> $form
     */
    private static function resolveLineMessageTemplate(array $form, ?string $templateOverride): string
    {
        $template = $templateOverride !== null ? trim($templateOverride) : '';
        if ($template === '') {
            $template = trim((string) ($form['line_message_template'] ?? ''));
        }
        if ($template === '') {
            $template = trim((string) ($form['mail_template_admin'] ?? ''));
        }
        if ($template === '') {
            $template = \Models\Form::defaultAdminMailTemplate();
        }

        return $template;
    }

    public static function templateContainsAll(string $template): bool
    {
        return str_contains($template, '{{__all__}}');
    }

    /**
     * @param array<string, mixed> $form
     */
    private static function lineNotifyIncludeImages(array $form): bool
    {
        return !empty($form['line_notify_include_images']);
    }

    /**
     * @return array{0:list<array<string, mixed>>, 1:list<array<string, mixed>>} text 用・image 用（別 Push）
     */
    private static function composePushMessageSets(
        string $text,
        string $template,
        LineNotifyFileResolver $fileResolver,
        array $fields,
        bool $includeImages
    ): array {
        $textMessages = [
            ['type' => 'text', 'text' => $text],
        ];
        $imageMessages = [];
        if (!self::templateContainsAll($template) || !$includeImages) {
            return [$textMessages, $imageMessages];
        }

        $imageMessages = $fileResolver->imageMessages();

        if ($imageMessages === [] && $fileResolver->hasInlineCandidates($fields)) {
            if (!LinePublicFileAccess::isReady()) {
                error_log('[formkun] line image push skipped: no https public base url or signing key');
            } else {
                error_log('[formkun] line image push empty: staging_or_signed_url_failed');
            }
        }

        return [$textMessages, $imageMessages];
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     */
    private static function logPublicUrlSummary(array $fields, LineNotifyFileResolver $fileResolver): void
    {
        $fileFieldCount = 0;
        foreach ($fields as $field) {
            if ((string) ($field['type'] ?? '') === 'file') {
                $fileFieldCount++;
            }
        }
        if ($fileFieldCount === 0) {
            return;
        }
        if ($fileResolver->resolvedUrls() !== []) {
            return;
        }
        $https = LinePublicFileAccess::publicBaseUrl() !== null ? 1 : 0;
        $key = LinePublicFileAccess::signingKey() !== '' ? 1 : 0;
        error_log('[formkun] line notify: inline_file_fields=' . $fileFieldCount . ' public_urls=0 https=' . $https . ' key=' . $key);
    }

    private static function submissionUrl(int $formId, ?int $submissionId): string
    {
        if ($formId <= 0) {
            return '';
        }
        if ($submissionId !== null && $submissionId > 0) {
            return url('/admin/forms/submissions/' . $submissionId);
        }

        return url('/admin/forms/' . $formId . '/submissions');
    }
}
