<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
require_once APP_COMPONENTS_DIR . '/m-alert01/m-alert01.php';
require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php';

$formId = (int) $form['id'];
$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
$listPath = '/admin/forms/' . $formId . '/submissions';
$importPath = $listPath . '/import/' . $token;
$duplicateCount = count($analysis['duplicates']);
$hasMailOnlyRows = !empty(array_filter($rows ?? [], static fn(array $row): bool => \Models\Submission::isMailOnlyMetadata($row)));
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'href' => base_path($listPath)],
    ['label' => 'インポート', 'href' => base_path($listPath . '/import')],
    ['label' => 'プレビュー', 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_large_title01('インポートのプレビュー'); ?>
                            </div>
                            <div class="area is-field">
                                <?php admin_m_alert01('この画面は確認用です。「インポートする」を押すまで DB には登録されません。', 'info'); ?>
                                <?php foreach ($analysis['warnings'] as $warning): ?>
                                    <?php admin_m_alert01($warning, 'warning'); ?>
                                <?php endforeach; ?>
                                <?php if (($unknownLabels ?? []) !== []): ?>
                                    <?php admin_m_alert01('このフォームにない項目は取り込みません: ' . implode('、', $unknownLabels), 'warning'); ?>
                                <?php endif; ?>
                            </div>
                            <div class="area is-field">
                                <p>
                                    ファイル: <?= e($fileName) ?><?php if ($archive['exported_at'] !== ''): ?>（エクスポート日時 <?= e($archive['exported_at']) ?>）<?php endif; ?><br>
                                    送信 <?= number_format($total) ?>件（データを追加します <?= number_format($newCount) ?> 件・既にデータが存在します <?= number_format($duplicateCount) ?> 件）、
                                    添付ファイル <?= number_format($analysis['file_count']) ?>件（<?= e(\Core\Validator::formatBytes((int) $analysis['file_bytes'])) ?>）
                                </p>
                                <?php if ($duplicateCount > 0): ?>
                                    <p class="text is-help">受信日時・IP アドレス・User-Agent がすべて一致する送信がすでにある場合は「既にデータが存在します」と表示し、インポートしません。</p>
                                <?php endif; ?>
                            </div>
                            <div class="area is-actions" data-module="m-toolbar01">
                                <form method="post" action="<?= e(base_path($importPath . '/discard')) ?>">
                                    <?= \Core\Csrf::field() ?>
                                    <button type="submit" class="btn">破棄</button>
                                </form>
                                <?php if ($canImport): ?>
                                    <form method="post" action="<?= e(base_path($importPath . '/commit')) ?>"
                                          onsubmit="return confirm('データを追加します <?= (int) $newCount ?> 件をインポートします。よろしいですか？');">
                                        <?= \Core\Csrf::field() ?>
                                        <button type="submit" class="btn is-primary"<?= $newCount === 0 ? ' disabled' : '' ?>>インポートする</button>
                                    </form>
                                <?php else: ?>
                                    <span data-module="m-text01" data-type="muted">インポートの実行は admin のみ行えます。</span>
                                <?php endif; ?>
                            </div>

                            <div class="area is-field">
                                <?php admin_m_table01_open(); ?>
                                    <thead>
                                        <tr>
                                            <th>データ</th>
                                            <th class="is-submitted-at">受信日時</th>
                                            <th class="is-workflow-status">状態</th>
                                            <?php if ($hasMailOnlyRows): ?>
                                                <th>保存方式</th>
                                                <th>SMTP配送</th>
                                                <th>添付</th>
                                            <?php endif; ?>
                                            <?php foreach ($previewKeys as $key):
                                                $label = '';
                                                foreach ($fields as $f) {
                                                    if ($f['field_key'] === $key) {
                                                        $label = (string) $f['label'];
                                                        break;
                                                    }
                                                }
                                            ?>
                                                <th><?= e($label !== '' ? $label : $key) ?></th>
                                            <?php endforeach; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($rows as $row):
                                        $detailUrl = base_path($importPath . '/submissions/' . (int) ($row['archive_index'] ?? 0) . ($page > 1 ? '?page=' . (int) $page : ''));
                                        $workflowStatus = (string) ($row['workflow_status'] ?? \Models\Submission::WORKFLOW_PENDING);
                                    ?>
                                        <tr>
                                            <td><?= !empty($row['duplicate']) ? '既にデータが存在します' : 'データを追加します' ?></td>
                                            <td class="is-submitted-at"><a href="<?= e($detailUrl) ?>"><?= e($row['submitted_at']) ?></a></td>
                                            <td class="is-workflow-status"><?= e(\Models\Submission::workflowStatusLabel($workflowStatus)) ?></td>
                                            <?php if ($hasMailOnlyRows): ?>
                                                <?php if (\Models\Submission::isMailOnlyMetadata($row)): ?>
                                                    <td>SMTPメールのみ</td>
                                                    <td><?= e(\Models\Submission::mailDeliveryStatusLabel((string) ($row['mail_delivery_status'] ?? 'success'))) ?></td>
                                                    <td><?= number_format((int) ($row['attachment_count'] ?? 0)) ?>件 / <?= e(\Core\Validator::formatBytes((int) ($row['attachment_total_bytes'] ?? 0))) ?></td>
                                                <?php else: ?>
                                                    <td>DB保存</td><td>—</td><td>—</td>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php
                                                $listPreviewRow = $row;
                                                $listPreviewSource = 'import';
                                                $importPreviewToken = (string) $token;
                                                $importPreviewFormId = $formId;
                                                require __DIR__ . '/_list_preview_cells.php';
                                            ?>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                <?php admin_m_table01_close(); ?>

                                <?php if ($totalPages > 1): ?>
                                <?php admin_c_pagination01_open(); ?>
                                    <?php $base = base_path($importPath); ?>
                                    <?php if ($page > 1): ?>
                                        <a href="<?= e($base . '?page=' . ($page - 1)) ?>">‹ 前へ</a>
                                    <?php else: ?>
                                        <span class="disabled">‹ 前へ</span>
                                    <?php endif; ?>
                                    <?php for ($p = max(1, $page - 3); $p <= min($totalPages, $page + 3); $p++): ?>
                                        <?php if ($p === $page): ?>
                                            <span class="current"><?= $p ?></span>
                                        <?php else: ?>
                                            <a href="<?= e($base . '?page=' . $p) ?>"><?= $p ?></a>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                    <?php if ($page < $totalPages): ?>
                                        <a href="<?= e($base . '?page=' . ($page + 1)) ?>">次へ ›</a>
                                    <?php else: ?>
                                        <span class="disabled">次へ ›</span>
                                    <?php endif; ?>
                                <?php admin_c_pagination01_close(); ?>
                                <?php endif; ?>
                            </div>
<?php admin_c_form_block01_close(); ?>
