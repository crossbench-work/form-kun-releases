<?php
/**
 * 受信履歴・インポートプレビュー一覧の項目プレビュー列（先頭3項目）のセル。
 *
 * 必須: $previewKeys, $fields, $listPreviewRow
 * db: $listPreviewSource = 'db'（既定）, $previews, $previewFiles
 * import: $listPreviewSource = 'import', $importPreviewToken, $importPreviewFormId
 */
$listPreviewSource = $listPreviewSource ?? 'db';
foreach ($previewKeys as $key):
    $fieldDef = null;
    foreach ($fields as $f) {
        if ($f['field_key'] === $key) {
            $fieldDef = $f;
            break;
        }
    }
    $fieldType = (string) ($fieldDef['type'] ?? '');
    ?>
    <td>
    <?php if ($fieldType === 'file'): ?>
        <?php if ($listPreviewSource === 'import'): ?>
            <?php
                $cellFiles = [];
                foreach ($listPreviewRow['files'] ?? [] as $fileIndex => $fl) {
                    if (!is_array($fl) || (string) ($fl['field_key'] ?? '') !== $key) {
                        continue;
                    }
                    $cellFiles[] = $fl + ['preview_file_index' => $fileIndex];
                }
            ?>
            <?php if ($cellFiles === []): ?>
                <span data-module="m-text01" data-type="muted">—</span>
            <?php else: ?>
                <div class="m-submissionFilePreview01">
                    <?php foreach ($cellFiles as $fl): ?>
                        <?php
                            $fileIndex = (int) ($fl['preview_file_index'] ?? 0);
                            $fileUrl = admin_import_preview_file_url(
                                (int) $importPreviewFormId,
                                (string) $importPreviewToken,
                                (int) ($listPreviewRow['archive_index'] ?? 0),
                                $fileIndex
                            );
                            $fileName = (string) ($fl['original_name'] ?? 'file');
                        ?>
                        <?php if (is_safe_inline_submission_file($fl)): ?>
                            <a class="m-submissionFilePreview01__thumbLink" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener noreferrer" title="<?= e($fileName) ?>">
                                <img class="m-submissionFilePreview01__thumb" src="<?= e($fileUrl) ?>" alt="<?= e($fileName) ?>" loading="lazy" width="48" height="48">
                            </a>
                        <?php else: ?>
                            <a class="m-submissionFilePreview01__link" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener noreferrer"><?= e($fileName) ?></a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <?php $cellFiles = ($previewFiles ?? [])[(int) $listPreviewRow['id']][$key] ?? []; ?>
            <?php if ($cellFiles === []): ?>
                <span data-module="m-text01" data-type="muted">—</span>
            <?php else: ?>
                <div class="m-submissionFilePreview01">
                    <?php foreach ($cellFiles as $fl): ?>
                        <?php
                            $fileUrl = admin_submission_file_url((int) $fl['id']);
                            $fileName = (string) ($fl['original_name'] ?? 'file');
                        ?>
                        <?php if (is_safe_inline_submission_file($fl)): ?>
                            <a class="m-submissionFilePreview01__thumbLink" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener noreferrer" title="<?= e($fileName) ?>">
                                <img class="m-submissionFilePreview01__thumb" src="<?= e($fileUrl) ?>" alt="<?= e($fileName) ?>" loading="lazy" width="48" height="48">
                            </a>
                        <?php else: ?>
                            <a class="m-submissionFilePreview01__link" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener noreferrer"><?= e($fileName) ?></a>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php else:
        if ($listPreviewSource === 'import') {
            $v = (string) (($listPreviewRow['values'] ?? [])[$key] ?? '');
        } else {
            $v = $previews[(int) $listPreviewRow['id']][$key] ?? '';
        }
        if ($fieldType === 'address') {
            $v = format_address_value_display($v);
        } elseif ($fieldType === 'text_pair') {
            $v = format_text_pair_value_display($v, \Models\FormField::decodeTextPairLabels($fieldDef['options_json'] ?? null));
        } elseif ($fieldType === 'text_multi') {
            $v = format_text_multi_value_display($v, \Models\FormField::decodeTextMultiItems($fieldDef['options_json'] ?? null, true));
        } elseif ($fieldType === \Models\FormField::TYPE_MATRIX) {
            $v = format_matrix_value_display($v, \Models\FormField::decodeMatrixSettings($fieldDef['options_json'] ?? null));
        }
        $v = (string) $v;
        $titleAttr = $v !== '' ? ' title="' . e($v) . '"' : '';
        ?>
        <span<?= $titleAttr ?>><?= e($v) ?></span>
    <?php endif; ?>
    </td>
<?php endforeach; ?>
