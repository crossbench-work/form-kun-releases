<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
require_once APP_COMPONENTS_DIR . '/m-checkbox01/m-checkbox01.php';
require_once APP_COMPONENTS_DIR . '/m-alert01/m-alert01.php';

$formId = (int) $form['id'];
$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
$listPath = '/admin/forms/' . $formId . '/submissions';
$exportPath = $listPath . '/export';
$periodQuery = array_filter(['from' => (string) $from, 'to' => (string) $to], static fn(string $v): bool => $v !== '');
$exportPageUrl = $exportPath . ($periodQuery !== [] ? '?' . http_build_query($periodQuery) : '');
$hasMailOnlyRows = !empty(array_filter($rows ?? [], static fn(array $row): bool => \Models\Submission::isMailOnlyMetadata($row)));
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'href' => base_path($listPath)],
    ['label' => 'エクスポート', 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-field">
                                <?php if (!empty($exportNotice)): ?>
                                    <?php
                                    $exportBasePath = $exportPath . '/' . $exportNotice['token'];
                                    $exportDownloadUrl = base_path($exportBasePath . '/download');
                                    $exportCount = number_format((int) $exportNotice['count']);
                                    ?>
                                    <div <?= admin_m_alert01_attrs('success') ?>>
                                        <p>
                                            <?= $exportCount ?>件のエクスポートを準備しました（<?= e($exportNotice['filename']) ?>）。
                                            ダウンロードが始まらない場合は<a href="<?= e($exportDownloadUrl) ?>">こちら</a>からダウンロードしてください。
                                        </p>
                                        <?php if (empty($exportNotice['downloaded'])): ?>
                                            <iframe src="<?= e($exportDownloadUrl) ?>" title="エクスポートのダウンロード" hidden></iframe>
                                        <?php endif; ?>
                                        <div data-module="m-toolbar01">
                                            <form method="post"
                                                  action="<?= e(base_path($exportBasePath . '/delete')) ?>"
                                                  onsubmit="return confirm('エクスポートした <?= e($exportCount) ?> 件の送信を削除します。添付ファイルも削除され、元に戻せません。よろしいですか？');">
                                                <?= \Core\Csrf::field() ?>
                                                <button class="btn is-danger is-sm" type="submit">エクスポートした <?= e($exportCount) ?> 件を削除</button>
                                            </form>
                                            <a class="btn is-sm" href="<?= e(base_path($exportPageUrl)) ?>">閉じる</a>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php require __DIR__ . '/_retention_notice.php'; ?>

                                <?php if (!empty($periodError)): ?>
                                    <?php admin_m_alert01($periodError, 'danger'); ?>
                                <?php endif; ?>

                                <form method="get" action="<?= e(base_path($exportPath)) ?>" data-module="m-toolbar01" data-auto-submit="change">
                                    <?php admin_m_bold_title01(e('期間'), 'submissions-export-from'); ?>
                                    <?php admin_m_input01_open(); ?>
                                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-export-from', [
                                            'type' => 'date',
                                            'id' => 'submissions-export-from',
                                            'name' => 'from',
                                            'value' => (string) $from,
                                        ])); ?>
                                    <?php admin_m_input01_close(); ?>
                                    <?php admin_m_bold_title01(e('〜'), 'submissions-export-to'); ?>
                                    <?php admin_m_input01_open(); ?>
                                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-export-to', [
                                            'type' => 'date',
                                            'id' => 'submissions-export-to',
                                            'name' => 'to',
                                            'value' => (string) $to,
                                        ])); ?>
                                    <?php admin_m_input01_close(); ?>
                                    <button class="btn is-primary" type="button" data-target="submissions-export-open"<?= (int) $total === 0 ? ' disabled' : '' ?>>エクスポート</button>
                                    <?php if ($from !== '' || $to !== ''): ?>
                                        <a class="btn" href="<?= e(base_path($exportPath)) ?>">クリア</a>
                                    <?php endif; ?>
                                    <span class="spacer"></span>
                                    <span data-module="m-text01" data-type="muted">該当 <?= number_format($total) ?>件<?= ($from === '' && $to === '') ? '（全期間）' : '' ?></span>
                                </form>

                                <?php if (empty($rows)): ?>
                                    <p data-module="m-text01" data-type="muted">該当する送信がありません。</p>
                                <?php else: ?>
                                    <?php admin_m_table01_open(); ?>
                                        <thead>
                                            <tr>
                                                <th class="is-submitted-at">受信日時</th>
                                                <th class="is-workflow-status">状態</th>
                                                <?php if ($hasMailOnlyRows): ?>
                                                    <th>保存方式</th>
                                                    <th>添付</th>
                                                <?php endif; ?>
                                                <?php foreach ($previewKeys as $key):
                                                    $label = '';
                                                    foreach ($fields as $f) { if ($f['field_key'] === $key) { $label = $f['label']; break; } }
                                                ?>
                                                    <th><?= e($label ?: $key) ?></th>
                                                <?php endforeach; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($rows as $r):
                                            $workflowStatus = (string) ($r['workflow_status'] ?? \Models\Submission::WORKFLOW_PENDING);
                                        ?>
                                            <tr>
                                                <td class="is-submitted-at">
                                                    <?php if (!empty($retentionEnabled) && \Models\Form::isSubmissionExpired($form, (string) $r['submitted_at'], $retentionCutoff)): ?>
                                                        <?php admin_m_warning_mark01($retentionWarningText); ?>
                                                    <?php endif; ?>
                                                    <a href="<?= e(base_path('/admin/forms/submissions/' . $r['id'])) ?>">
                                                        <?= e($r['submitted_at']) ?>
                                                    </a>
                                                </td>
                                                <td class="is-workflow-status"><?= e(\Models\Submission::workflowStatusLabel($workflowStatus)) ?></td>
                                                <?php if ($hasMailOnlyRows): ?>
                                                    <?php if (\Models\Submission::isMailOnlyMetadata($r)): ?>
                                                        <td>SMTPメールのみ</td>
                                                        <td><?= number_format((int) ($r['attachment_count'] ?? 0)) ?>件 / <?= e(\Core\Validator::formatBytes((int) ($r['attachment_total_bytes'] ?? 0))) ?></td>
                                                    <?php else: ?>
                                                        <td>DB保存</td><td>—</td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php foreach ($previewKeys as $key):
                                                    $fieldDef = null;
                                                    foreach ($fields as $f) {
                                                        if ($f['field_key'] === $key) {
                                                            $fieldDef = $f;
                                                            break;
                                                        }
                                                    }
                                                    $fieldType = (string) ($fieldDef['type'] ?? '');
                                                ?>
                                                    <td>
                                                    <?php if ($fieldType === 'file'): ?>
                                                        <?php $cellFiles = ($previewFiles ?? [])[(int) $r['id']][$key] ?? []; ?>
                                                        <?php if ($cellFiles === []): ?>
                                                            <span data-module="m-text01" data-type="muted">—</span>
                                                        <?php else: ?>
                                                            <?= e(implode('、', array_map(static fn(array $fl): string => (string) ($fl['original_name'] ?? 'file'), $cellFiles))) ?>
                                                        <?php endif; ?>
                                                    <?php else:
                                                        $v = $previews[(int) $r['id']][$key] ?? '';
                                                        if ($fieldType === 'address') {
                                                            $v = format_address_value_display($v);
                                                        } elseif ($fieldType === 'text_pair') {
                                                            $v = format_text_pair_value_display($v, \Models\FormField::decodeTextPairLabels($fieldDef['options_json'] ?? null));
                                                        } elseif ($fieldType === 'text_multi') {
                                                            $v = format_text_multi_value_display($v, \Models\FormField::decodeTextMultiItems($fieldDef['options_json'] ?? null, true));
                                                        } elseif ($fieldType === \Models\FormField::TYPE_MATRIX) {
                                                            $v = format_matrix_value_display($v, \Models\FormField::decodeMatrixSettings($fieldDef['options_json'] ?? null));
                                                        }
                                                        $v = (string) $v;
                                                        $titleAttr = $v !== '' ? ' title="' . e($v) . '"' : '';
                                                    ?>
                                                        <span<?= $titleAttr ?>><?= e($v) ?></span>
                                                    <?php endif; ?>
                                                    </td>
                                                <?php endforeach; ?>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    <?php admin_m_table01_close(); ?>

                                    <?php if ($totalPages > 1): ?>
                                    <?php admin_c_pagination01_open(); ?>
                                        <?php
                                            $qs = static function (int $p) use ($periodQuery): string {
                                                return '?' . http_build_query($periodQuery + ['page' => $p]);
                                            };
                                            $base = base_path($exportPath);
                                        ?>
                                        <?php if ($page > 1): ?>
                                            <a href="<?= e($base . $qs($page - 1)) ?>">‹ 前へ</a>
                                        <?php else: ?>
                                            <span class="disabled">‹ 前へ</span>
                                        <?php endif; ?>

                                        <?php for ($p = max(1, $page - 3); $p <= min($totalPages, $page + 3); $p++): ?>
                                            <?php if ($p === $page): ?>
                                                <span class="current"><?= $p ?></span>
                                            <?php else: ?>
                                                <a href="<?= e($base . $qs($p)) ?>"><?= $p ?></a>
                                            <?php endif; ?>
                                        <?php endfor; ?>

                                        <?php if ($page < $totalPages): ?>
                                            <a href="<?= e($base . $qs($page + 1)) ?>">次へ ›</a>
                                        <?php else: ?>
                                            <span class="disabled">次へ ›</span>
                                        <?php endif; ?>
                                    <?php admin_c_pagination01_close(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>

<?php if ((int) $total > 0): ?>
<?php
$periodLabel = ($from === '' && $to === '')
    ? '全期間'
    : str_replace('-', '/', (string) $from) . '〜' . str_replace('-', '/', (string) $to);
?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('submissions-export-close'); ?>
    <?php admin_c_modal01_dialog_open('submissions-export-modal-title'); ?>
        <?php admin_c_modal01_header_open(); ?>
            <h2 id="submissions-export-modal-title">エクスポート</h2>
            <button type="button" class="btn is-sm" data-target="submissions-export-close">閉じる</button>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path($exportPath)) ?>">
                <?= \Core\Csrf::field() ?>
                <input type="hidden" name="from" value="<?= e((string) $from) ?>">
                <input type="hidden" name="to" value="<?= e((string) $to) ?>">
                <div class="area is-field">
                    <p>期間: <?= e($periodLabel) ?>（<?= number_format((int) $total) ?>件）</p>
                </div>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('ファイル名'), 'submissions-export-filename'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-export-filename', [
                            'type' => 'text',
                            'id' => 'submissions-export-filename',
                            'name' => 'export_filename',
                            'maxlength' => 100,
                            'placeholder' => '空欄なら 期間_フォーム名',
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">拡張子（.csv / .zip）は自動で付きます。</p>
                </div>
                <div class="area is-field">
                    <?php admin_m_checkbox01('添付ファイルも含める（ZIP）', [
                        'name' => 'include_files',
                        'value' => '1',
                    ]); ?>
                    <p class="text is-help">あとでインポート（復元）する場合は ZIP でエクスポートしてください。ZIP には復元用データ（<?= e(\Core\SubmissionArchive::MANIFEST_NAME) ?>）が入ります。</p>
                </div>
                <?php admin_c_modal01_actions_open(); ?>
                    <button type="button" class="btn" data-target="submissions-export-close">キャンセル</button>
                    <button type="submit" class="btn is-primary">エクスポート</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php endif; ?>
<?php admin_c_form_block01_close(); ?>
