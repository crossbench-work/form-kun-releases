<?php
/**
 * 受信履歴・エクスポートページ共通: 保存期間を過ぎた送信の注意書き。
 * 変数: $form, $retentionEnabled, $retentionCutoff, $retentionDays, $retentionDeletes, $expiredCount
 * 行の警告マーク用に $retentionWarningText を定義する。
 */
require_once APP_COMPONENTS_DIR . '/m-alert01/m-alert01.php';
require_once APP_COMPONENTS_DIR . '/m-warningMark01/m-warningMark01.php';

$submissionReadOnly = !empty($submission_read_only);
$retentionDaysInt = (int) $retentionDays;
if ($submissionReadOnly) {
    $retentionWarningText = '保存期間（' . $retentionDaysInt . '日）を過ぎています。'
        . ($retentionDeletes ? '定期処理で削除される予定です。' : '');
} else {
    $retentionWarningText = '保存期間（' . $retentionDaysInt . '日）を過ぎています。'
        . ($retentionDeletes ? '定期処理で削除されるため、必要ならエクスポートしてください。' : 'エクスポートしてください。');
}
?>
<?php if (!empty($retentionEnabled) && (int) $expiredCount > 0): ?>
    <div <?= admin_m_alert01_attrs('warning') ?>>
        <p>
            <?php admin_m_warning_mark01($retentionWarningText); ?>
            保存期間（<?= $retentionDaysInt ?>日）を過ぎた送信が <?= number_format((int) $expiredCount) ?>件あります。
            <?= $retentionDeletes ? 'この送信は定期処理で添付ファイルとともに削除されます。' : '' ?>
            <?php if (!$submissionReadOnly): ?>
                <?php
                $retentionExportUrl = base_path('/admin/forms/' . (int) $form['id'] . '/submissions/export?' . http_build_query(['to' => substr((string) $retentionCutoff, 0, 10)]));
                ?>
                <a href="<?= e($retentionExportUrl) ?>">エクスポートする</a>
            <?php endif; ?>
        </p>
    </div>
<?php endif; ?>
