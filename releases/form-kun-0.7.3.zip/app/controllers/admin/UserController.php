<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\Csrf;
use Core\SiteResource;
use Core\View;
use Models\Form;
use Models\User;
use Models\UserFormGrant;

class UserController
{
    public function __construct()
    {
        Auth::requireRole('admin');
    }

    public function index(): void
    {
        $users = User::all();
        $resource = SiteResource::snapshot();
        (new View())->render('admin/users/index', [
            'title' => 'ユーザー管理',
            'users' => $users,
            'storage_resource' => $resource,
        ], 'admin');
    }

    public function createForm(): void
    {
        (new View())->render('admin/users/edit', $this->editViewData([
            'title' => 'ユーザー新規作成',
            'user'  => ['id' => null, 'username' => '', 'display_name' => '', 'email' => '', 'role' => 'editor'],
            'errors'=> [],
            'isNew' => true,
        ]), 'admin');
    }

    public function store(): void
    {
        Csrf::verify();

        $username    = trim((string) ($_POST['username'] ?? ''));
        $displayName = trim((string) ($_POST['display_name'] ?? ''));
        $email       = trim((string) ($_POST['email'] ?? ''));
        $role        = self::normalizeRole($_POST['role'] ?? '');
        $password    = (string) ($_POST['password'] ?? '');
        $passwordConf= (string) ($_POST['password_confirm'] ?? '');
        $grantedForms = self::grantsFromPost();

        $errors = $this->validate($username, $password, $passwordConf, null);
        $errors = array_merge($errors, $this->validateEmailDuplicate($email, null));
        if ($displayName === '') $displayName = $username;

        if (!empty($errors)) {
            (new View())->render('admin/users/edit', $this->editViewData([
                'title' => 'ユーザー新規作成',
                'user'  => ['id' => null, 'username' => $username, 'display_name' => $displayName, 'email' => $email, 'role' => $role],
                'errors'=> $errors,
                'isNew' => true,
                'granted_forms' => $grantedForms,
            ]), 'admin');
            return;
        }

        $newId = User::create($username, $password, $displayName, $role, $email !== '' ? $email : null);
        self::syncFormGrantsForRole($newId, $role, $grantedForms);
        flash('success', 'ユーザーを作成しました。');
        redirect('/admin/users');
    }

    public function edit(int $id): void
    {
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }
        (new View())->render('admin/users/edit', $this->editViewData([
            'title' => 'ユーザー編集',
            'user'  => $user,
            'errors'=> [],
            'isNew' => false,
            'granted_forms' => UserFormGrant::grantsForUser($id),
        ]), 'admin');
    }

    public function update(int $id): void
    {
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }

        Csrf::verify();
        $displayName = trim((string) ($_POST['display_name'] ?? ''));
        $email       = trim((string) ($_POST['email'] ?? ''));
        $role        = self::normalizeRole($_POST['role'] ?? '');
        $password    = (string) ($_POST['password'] ?? '');
        $passwordConf= (string) ($_POST['password_confirm'] ?? '');
        $grantedForms = self::grantsFromPost();

        $errors = $this->validate($user['username'], $password, $passwordConf, $id, false);
        $errors = array_merge($errors, $this->validateEmailDuplicate($email, $id));

        // 自分自身を editor に降格しようとする場合、admin が他に居なければ拒否
        if ((int) Auth::id() === $id && $role !== 'admin') {
            $remaining = $this->countOtherAdmins($id);
            if ($remaining === 0) {
                $errors[] = '他に admin 権限のユーザーがいないため、自身の権限を変更できません。';
            }
        }

        if (!empty($errors)) {
            (new View())->render('admin/users/edit', $this->editViewData([
                'title' => 'ユーザー編集',
                'user'  => array_merge($user, ['display_name' => $displayName, 'email' => $email, 'role' => $role]),
                'errors'=> $errors,
                'isNew' => false,
                'granted_forms' => $grantedForms,
            ]), 'admin');
            return;
        }

        if ($displayName === '') $displayName = $user['username'];
        User::update($id, $displayName, $role, $password !== '' ? $password : null, $email !== '' ? $email : null);
        self::syncFormGrantsForRole($id, $role, $grantedForms);
        if ((int) Auth::id() === $id) {
            Auth::refreshCurrentUser();
        }
        flash('success', 'ユーザーを更新しました。');
        redirect('/admin/users');
    }

    public function destroy(int $id): void
    {
        Csrf::verify();
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }

        if ((int) Auth::id() === $id) {
            flash('danger', 'ログイン中の自分自身は削除できません。');
            redirect('/admin/users');
        }

        if ($user['role'] === 'admin' && $this->countOtherAdmins($id) === 0) {
            flash('danger', '最後の admin ユーザーは削除できません。');
            redirect('/admin/users');
        }

        User::delete($id);
        flash('success', 'ユーザーを削除しました。');
        redirect('/admin/users');
    }

    private function validate(string $username, string $password, string $passwordConf, ?int $excludeId, bool $requirePassword = true): array
    {
        $errors = [];
        if ($excludeId === null) {
            // 新規作成時のみ username を厳密に検査（編集時は不変）
            if (!preg_match('/\A[a-zA-Z0-9_.\-]{3,64}\z/', $username)) {
                $errors[] = 'ユーザー名は半角英数字・記号(_.-)で3〜64文字で入力してください。';
            } elseif (User::findByUsername($username) !== null) {
                $errors[] = 'そのユーザー名は既に使われています。';
            }
        }

        if ($requirePassword || $password !== '') {
            if (mb_strlen($password) < 8) {
                $errors[] = 'パスワードは8文字以上で設定してください。';
            }
            if ($password !== $passwordConf) {
                $errors[] = '確認用パスワードが一致しません。';
            }
        }

        return $errors;
    }

    /**
     * @return string[] エラーメッセージ
     */
    private function validateEmailDuplicate(string $email, ?int $excludeUserId): array
    {
        $errors = [];
        if ($email === '') {
            return $errors;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'メールアドレスの形式が正しくありません。';
            return $errors;
        }
        $other = User::findByEmail($email);
        if ($other !== null && ($excludeUserId === null || (int) $other['id'] !== $excludeUserId)) {
            $errors[] = 'そのメールアドレスは既に使われています。';
        }
        return $errors;
    }

    private function countOtherAdmins(int $excludeId): int
    {
        $row = \Core\Database::fetchOne(
            "SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND id <> ?",
            [$excludeId]
        );
        return (int) ($row['c'] ?? 0);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function editViewData(array $data): array
    {
        if (!isset($data['forms'])) {
            $data['forms'] = Form::all();
        }
        if (!isset($data['granted_forms'])) {
            $uid = (int) ($data['user']['id'] ?? 0);
            $data['granted_forms'] = $uid > 0 ? UserFormGrant::grantsForUser($uid) : [];
        }
        return $data;
    }

    private static function normalizeRole(mixed $raw): string
    {
        return in_array($raw, ['admin', 'editor', 'viewer'], true) ? (string) $raw : 'editor';
    }

    /**
     * @return array<int, string> form_id => view|edit
     */
    private static function grantsFromPost(): array
    {
        $rawIds = $_POST['form_ids'] ?? [];
        if (!is_array($rawIds)) {
            return [];
        }
        $accessRaw = $_POST['form_access'] ?? [];
        if (!is_array($accessRaw)) {
            $accessRaw = [];
        }
        $grants = [];
        foreach ($rawIds as $v) {
            $id = (int) $v;
            if ($id <= 0 || isset($grants[$id])) {
                continue;
            }
            $level = (string) ($accessRaw[$id] ?? $accessRaw[(string) $id] ?? 'view');
            if (!in_array($level, ['view', 'edit'], true)) {
                $level = 'view';
            }
            $grants[$id] = $level;
        }
        return $grants;
    }

    /**
     * @param array<int, string> $grants
     */
    private static function syncFormGrantsForRole(int $userId, string $role, array $grants): void
    {
        if ($role === 'viewer') {
            UserFormGrant::syncForUser($userId, $grants);
            return;
        }
        UserFormGrant::clearForUser($userId);
    }

    private function notFound(): void
    {
        http_response_code(404);
        echo '<!doctype html><meta charset="utf-8"><title>404</title><h1>404</h1>';
        exit;
    }
}
