<?php
namespace Core;

/**
 * 旧 DB（schema.sql 追加前に作成されたデータベース）向けの軽量マイグレーション。
 * 初回リクエスト時に不足列・不足テーブルを補います。
 */
class SchemaPatch
{
    private static bool $done = false;

    public static function ensureLatest(): void
    {
        if (self::$done) {
            return;
        }
        self::$done = true;

        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasEmail = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'users', 'email']
            );
            if ((int) ($hasEmail['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE users ADD COLUMN email VARCHAR(255) DEFAULT NULL AFTER display_name'
                );
            }

            self::tryAlterUniqueEmail();

            self::ensureFormFieldsRegexText();

            self::ensureFormFieldsTypeEnumAddress();

            self::ensureFormFieldsTypeEnumTextPair();

            self::ensureFormFieldsTypeEnumTextMulti();
            self::ensureFormFieldsTypeEnumMatrix();
            self::ensureFormFieldsTypeEnumPostalCode();
            self::ensureFormFieldsTypeEnumDisplayItems();
            self::ensureFormFieldsVisible();
            self::ensureFormFieldsMinLength();
            self::ensureFormFieldsExactLength();

            self::ensureFormsDisplayFlags();

            self::ensureFormsPageTitles();
            self::ensureFormInputPages();
            self::ensureFormFieldsInputPageKey();
            self::ensureFormFieldGroups();
            self::ensureFormFieldTemplates();
            self::ensureFormVersions();
            self::ensureFieldLabelDisplayFlags();
            self::ensureFormBranchRules();
            self::ensureFormBranchRuleTargetType();
            self::ensureFormsMetaSettings();
            self::ensureFormsMailSettings();
            self::ensureMailOnlySubmission();
            self::ensureFormsReplyFieldKeyStorage();
            self::ensureFormsPublishSchedule();
            self::ensureFormsUnpublishRules();

            self::ensureAppSettingsTable();
            self::ensureAppSettingsCreatedAtColumn();

            self::ensureLoginAttemptsUsernameIndex();

            self::ensureFormsPublicUuid();
            self::ensureSubmissionFilesFileUuid();
            self::ensureSubmissionsWorkflowStatus();
            self::ensureMailOnlySubmissionMetadata();
            self::ensureFormEmbedApiTables();
            self::ensureFormsSubmissionRetention();

            self::ensureUsersRoleViewer();
            self::ensureUserFormGrantsTable();
            self::ensureUserFormGrantsAccessLevel();

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'password_reset_tokens']
            );
            if ((int) ($hasTbl['c'] ?? 0) === 0) {
                Database::execute(
                    'CREATE TABLE password_reset_tokens (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL,
                        token_hash CHAR(64) NOT NULL,
                        expires_at DATETIME NOT NULL,
                        created_at DATETIME NOT NULL,
                        UNIQUE KEY uk_token_hash (token_hash),
                        KEY idx_user_id (user_id),
                        CONSTRAINT fk_pwreset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch failed: ' . $e->getMessage());
        }
    }

    private static function tryAlterUniqueEmail(): void
    {
        try {
            Database::execute('ALTER TABLE users ADD UNIQUE KEY uk_users_email (email)');
        } catch (\Throwable $e) {
            $m = $e->getMessage();
            if (stripos($m, 'Duplicate') !== false || stripos($m, '1061') !== false || stripos($m, 'already exists') !== false) {
                return;
            }
            error_log('[formkun] SchemaPatch uk_users_email: ' . $m);
        }
    }

    /**
     * form_fields.regex を複数パターン（JSON）格納用に TEXT へ拡張。
     */
    public static function ensureFormFieldsRegexText(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT DATA_TYPE AS t FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'regex']
            );
            if (!$col) {
                return;
            }
            $type = strtolower((string) ($col['t'] ?? ''));
            if ($type === 'varchar') {
                Database::execute('ALTER TABLE form_fields MODIFY regex TEXT DEFAULT NULL');
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.regex: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に address（住所）を追加。
     */
    public static function ensureFormFieldsTypeEnumAddress(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || strpos($ct, 'address') !== false) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','address',
                    'radio','checkbox','select','date','time','file'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type address: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に text_pair（1行テキスト2入力）を追加。
     */
    public static function ensureFormFieldsTypeEnumTextPair(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || strpos($ct, 'text_pair') !== false) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','address','text_pair',
                    'radio','checkbox','select','date','time','file'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type text_pair: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に text_multi（1行テキスト複数入力）を追加。
     */
    public static function ensureFormFieldsTypeEnumTextMulti(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || strpos($ct, 'text_multi') !== false) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','address','text_pair','text_multi',
                    'radio','checkbox','select','date','time','file'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type text_multi: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に matrix を追加。
     */
    public static function ensureFormFieldsTypeEnumMatrix(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || strpos($ct, 'matrix') !== false) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','address','text_pair','text_multi','matrix',
                    'radio','checkbox','select','date','time','file',
                    'heading','description','divider'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type matrix: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に postal_code を追加。
     */
    public static function ensureFormFieldsTypeEnumPostalCode(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || strpos($ct, 'postal_code') !== false) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','postal_code','address','text_pair','text_multi','matrix',
                    'radio','checkbox','select','date','time','file',
                    'heading','description','divider'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type postal_code: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に表示専用項目（見出し・説明文・罫線）を追加。
     */
    public static function ensureFormFieldsTypeEnumDisplayItems(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || (strpos($ct, 'heading') !== false && strpos($ct, 'description') !== false && strpos($ct, 'divider') !== false)) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','postal_code','address','text_pair','text_multi','matrix',
                    'radio','checkbox','select','date','time','file',
                    'heading','description','divider'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type display_items: ' . $e->getMessage());
        }
    }

    /**
     * form_fields に visible 列を追加。
     */
    public static function ensureFormFieldsVisible(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasVisible = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'visible']
            );
            if ((int) ($hasVisible['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE form_fields ADD COLUMN visible TINYINT(1) NOT NULL DEFAULT 1 AFTER label'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.visible: ' . $e->getMessage());
        }
    }

    public static function ensureFormFieldsMinLength(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'min_length']
            );
            if ((int) ($col['c'] ?? 0) > 0) {
                return;
            }
            Database::execute('ALTER TABLE form_fields ADD COLUMN min_length INT DEFAULT NULL AFTER required');
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.min_length: ' . $e->getMessage());
        }
    }

    public static function ensureFormFieldsExactLength(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'exact_length']
            );
            if ((int) ($col['c'] ?? 0) > 0) {
                return;
            }
            Database::execute('ALTER TABLE form_fields ADD COLUMN exact_length INT DEFAULT NULL AFTER max_length');
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.exact_length: ' . $e->getMessage());
        }
    }

    /**
     * forms に公開フォーム側のタイトル・説明文表示フラグを追加。
     */
    public static function ensureFormsDisplayFlags(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasShowTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'show_title']
            );
            if ((int) ($hasShowTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN show_title TINYINT(1) NOT NULL DEFAULT 1 AFTER description'
                );
            }

            $hasShowDescription = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'show_description']
            );
            if ((int) ($hasShowDescription['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN show_description TINYINT(1) NOT NULL DEFAULT 1 AFTER show_title'
                );
            }

            $hasConfirmButtonText = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'confirm_button_text']
            );
            if ((int) ($hasConfirmButtonText['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN confirm_button_text VARCHAR(200) DEFAULT NULL AFTER show_description'
                );
            }

            $hasSubmitButtonText = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'submit_button_text']
            );
            if ((int) ($hasSubmitButtonText['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN submit_button_text VARCHAR(200) DEFAULT NULL AFTER confirm_button_text'
                );
            }

            $hasBackButtonText = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'back_button_text']
            );
            if ((int) ($hasBackButtonText['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN back_button_text VARCHAR(200) DEFAULT NULL AFTER submit_button_text'
                );
            }

            $hasConfirmMessage = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'confirm_message']
            );
            if ((int) ($hasConfirmMessage['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN confirm_message TEXT DEFAULT NULL AFTER back_button_text'
                );
            }

            $hasThanksButtonText = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'thanks_button_text']
            );
            if ((int) ($hasThanksButtonText['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN thanks_button_text VARCHAR(200) DEFAULT NULL AFTER thanks_message'
                );
            }

            $hasThanksButtonUrl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'thanks_button_url']
            );
            if ((int) ($hasThanksButtonUrl['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN thanks_button_url VARCHAR(500) DEFAULT NULL AFTER thanks_button_text'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms display flags: ' . $e->getMessage());
        }
    }

    /**
     * forms に入力 / 確認 / 完了画面ごとのタイトル列を追加。
     */
    public static function ensureFormsPageTitles(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasInputPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'input_page_title']
            );
            if ((int) ($hasInputPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN input_page_title VARCHAR(200) DEFAULT NULL AFTER title'
                );
            }

            $hasShowInputPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'show_input_page_title']
            );
            if ((int) ($hasShowInputPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN show_input_page_title TINYINT(1) NOT NULL DEFAULT 1 AFTER input_page_title'
                );
            }

            $hasConfirmPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'confirm_page_title']
            );
            if ((int) ($hasConfirmPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN confirm_page_title VARCHAR(200) DEFAULT NULL AFTER show_description'
                );
            }

            $hasShowConfirmPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'show_confirm_page_title']
            );
            if ((int) ($hasShowConfirmPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN show_confirm_page_title TINYINT(1) NOT NULL DEFAULT 1 AFTER confirm_page_title'
                );
            }

            $hasThanksPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'thanks_page_title']
            );
            if ((int) ($hasThanksPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN thanks_page_title VARCHAR(200) DEFAULT NULL AFTER confirm_message'
                );
            }

            $hasShowThanksPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'show_thanks_page_title']
            );
            if ((int) ($hasShowThanksPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN show_thanks_page_title TINYINT(1) NOT NULL DEFAULT 1 AFTER thanks_page_title'
                );
            }

            Database::execute(
                "UPDATE forms
                    SET input_page_title = title
                  WHERE (input_page_title IS NULL OR input_page_title = '')
                    AND title IS NOT NULL AND title <> ''"
            );
            Database::execute(
                "UPDATE forms
                    SET show_input_page_title = 1
                  WHERE show_input_page_title IS NULL OR show_input_page_title NOT IN (0, 1)"
            );
            Database::execute(
                "UPDATE forms
                    SET confirm_page_title = '入力内容のご確認'
                  WHERE confirm_page_title IS NULL OR confirm_page_title = ''"
            );
            Database::execute(
                "UPDATE forms
                    SET show_confirm_page_title = 1
                  WHERE show_confirm_page_title IS NULL OR show_confirm_page_title NOT IN (0, 1)"
            );
            Database::execute(
                "UPDATE forms
                    SET thanks_page_title = '送信が完了しました'
                  WHERE thanks_page_title IS NULL OR thanks_page_title = ''"
            );
            Database::execute(
                "UPDATE forms
                    SET show_thanks_page_title = 1
                  WHERE show_thanks_page_title IS NULL OR show_thanks_page_title NOT IN (0, 1)"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms page titles: ' . $e->getMessage());
        }
    }

    /**
     * forms に公開フォーム用の meta 情報列を追加。
     */
    public static function ensureFormsMetaSettings(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasMetaHtml = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'meta_html']
            );
            if ((int) ($hasMetaHtml['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN meta_html TEXT DEFAULT NULL AFTER title'
                );
            }

            $hasCustomCss = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'custom_css']
            );
            if ((int) ($hasCustomCss['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN custom_css TEXT DEFAULT NULL AFTER meta_html'
                );
            }

            $hasCustomJs = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'custom_js']
            );
            if ((int) ($hasCustomJs['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN custom_js TEXT DEFAULT NULL AFTER custom_css'
                );
            }

            $hasHeaderHtml = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'header_html']
            );
            if ((int) ($hasHeaderHtml['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN header_html TEXT DEFAULT NULL AFTER custom_js'
                );
            }

            $hasFooterHtml = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'footer_html']
            );
            if ((int) ($hasFooterHtml['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN footer_html TEXT DEFAULT NULL AFTER header_html'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms meta settings: ' . $e->getMessage());
        }
    }

    /**
     * forms にフォーム単位の通知メール設定列を追加。
     */
    public static function ensureFormsMailSettings(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $columns = [
                'mail_transport' => 'ALTER TABLE forms ADD COLUMN mail_transport VARCHAR(10) DEFAULT NULL AFTER mail_template_admin',
                'mail_from_email' => 'ALTER TABLE forms ADD COLUMN mail_from_email VARCHAR(255) DEFAULT NULL AFTER mail_transport',
                'mail_from_name' => 'ALTER TABLE forms ADD COLUMN mail_from_name VARCHAR(255) DEFAULT NULL AFTER mail_from_email',
                'mail_smtp_host' => 'ALTER TABLE forms ADD COLUMN mail_smtp_host VARCHAR(255) DEFAULT NULL AFTER mail_from_name',
                'mail_smtp_port' => 'ALTER TABLE forms ADD COLUMN mail_smtp_port INT DEFAULT NULL AFTER mail_smtp_host',
                'mail_smtp_secure' => 'ALTER TABLE forms ADD COLUMN mail_smtp_secure VARCHAR(10) DEFAULT NULL AFTER mail_smtp_port',
                'mail_smtp_username' => 'ALTER TABLE forms ADD COLUMN mail_smtp_username VARCHAR(255) DEFAULT NULL AFTER mail_smtp_secure',
                'mail_smtp_password' => 'ALTER TABLE forms ADD COLUMN mail_smtp_password VARCHAR(255) DEFAULT NULL AFTER mail_smtp_username',
                'mail_smtp_timeout' => 'ALTER TABLE forms ADD COLUMN mail_smtp_timeout INT DEFAULT NULL AFTER mail_smtp_password',
                'mail_smtp_ehlo_host' => 'ALTER TABLE forms ADD COLUMN mail_smtp_ehlo_host VARCHAR(255) DEFAULT NULL AFTER mail_smtp_timeout',
                'mail_smtp_verify_peer' => 'ALTER TABLE forms ADD COLUMN mail_smtp_verify_peer TINYINT(1) NOT NULL DEFAULT 1 AFTER mail_smtp_ehlo_host',
                'mail_smtp_verify_peer_name' => 'ALTER TABLE forms ADD COLUMN mail_smtp_verify_peer_name TINYINT(1) NOT NULL DEFAULT 1 AFTER mail_smtp_verify_peer',
                'mail_smtp_allow_self_signed' => 'ALTER TABLE forms ADD COLUMN mail_smtp_allow_self_signed TINYINT(1) NOT NULL DEFAULT 0 AFTER mail_smtp_verify_peer_name',
            ];

            foreach ($columns as $column => $sql) {
                $hasColumn = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'forms', $column]
                );
                if ((int) ($hasColumn['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms mail settings: ' . $e->getMessage());
        }
    }

    public static function ensureFormsReplyFieldKeyStorage(): void
    {
        try {
            $column = Database::fetchOne("SHOW COLUMNS FROM forms LIKE 'reply_from_field_key'");
            $type = strtolower((string) ($column['Type'] ?? ''));
            if ($type !== '' && strpos($type, 'text') === false) {
                Database::execute('ALTER TABLE forms MODIFY reply_from_field_key TEXT DEFAULT NULL');
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms reply field key storage: ' . $e->getMessage());
        }
    }

    public static function ensureFormsPublishSchedule(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $columns = [
                'publish_schedule_enabled' => 'ALTER TABLE forms ADD COLUMN publish_schedule_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER reply_template',
                'publish_rules' => 'ALTER TABLE forms ADD COLUMN publish_rules TEXT DEFAULT NULL AFTER publish_schedule_enabled',
                'closed_page_title' => 'ALTER TABLE forms ADD COLUMN closed_page_title VARCHAR(200) DEFAULT NULL AFTER publish_rules',
                'show_closed_page_title' => 'ALTER TABLE forms ADD COLUMN show_closed_page_title TINYINT(1) NOT NULL DEFAULT 1 AFTER closed_page_title',
                'closed_message' => 'ALTER TABLE forms ADD COLUMN closed_message TEXT DEFAULT NULL AFTER show_closed_page_title',
                'closed_button_text' => 'ALTER TABLE forms ADD COLUMN closed_button_text VARCHAR(200) DEFAULT NULL AFTER closed_message',
                'closed_button_url' => 'ALTER TABLE forms ADD COLUMN closed_button_url VARCHAR(500) DEFAULT NULL AFTER closed_button_text',
            ];

            foreach ($columns as $column => $sql) {
                $hasColumn = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'forms', $column]
                );
                if ((int) ($hasColumn['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms publish schedule: ' . $e->getMessage());
        }
    }

    public static function ensureFormsUnpublishRules(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasColumn = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'unpublish_rules']
            );
            if ((int) ($hasColumn['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN unpublish_rules TEXT DEFAULT NULL AFTER publish_rules'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms unpublish rules: ' . $e->getMessage());
        }
    }

    private static function ensureAppSettingsTable(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'app_settings']
            );
            if ((int) ($hasTbl['c'] ?? 0) > 0) {
                return;
            }

            Database::execute(
                'CREATE TABLE app_settings (
                    setting_key VARCHAR(64) NOT NULL PRIMARY KEY,
                    setting_value TEXT NOT NULL,
                    created_at DATETIME NOT NULL,
                    updated_at DATETIME NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch app_settings: ' . $e->getMessage());
        }
    }

    private static function ensureFormInputPages(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'form_input_pages']
            );
            if ((int) ($hasTbl['c'] ?? 0) === 0) {
                Database::execute(
                    'CREATE TABLE form_input_pages (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        form_id INT NOT NULL,
                        page_key VARCHAR(64) NOT NULL,
                        sort_order INT NOT NULL DEFAULT 0,
                        title VARCHAR(200) DEFAULT NULL,
                        show_title TINYINT(1) NOT NULL DEFAULT 1,
                        description TEXT DEFAULT NULL,
                        button_text VARCHAR(200) DEFAULT NULL,
                        back_button_text VARCHAR(200) DEFAULT NULL,
                        created_at DATETIME NOT NULL,
                        updated_at DATETIME NOT NULL,
                        UNIQUE KEY uk_form_input_page (form_id, page_key),
                        KEY idx_form_input_page_sort (form_id, sort_order),
                        CONSTRAINT fk_form_input_pages_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
                );
            }

            $hasBackButtonText = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_input_pages', 'back_button_text']
            );
            if ((int) ($hasBackButtonText['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE form_input_pages ADD COLUMN back_button_text VARCHAR(200) DEFAULT NULL AFTER button_text'
                );
            }

            $now = date('Y-m-d H:i:s');
            $forms = Database::fetchAll(
                'SELECT id, input_page_title, show_input_page_title, description, confirm_button_text FROM forms'
            );
            foreach ($forms as $form) {
                $exists = Database::fetchOne(
                    'SELECT id FROM form_input_pages WHERE form_id = ? AND page_key = ?',
                    [(int) $form['id'], 'input-1']
                );
                if ($exists !== null) {
                    continue;
                }
                Database::execute(
                    'INSERT INTO form_input_pages (
                        form_id, page_key, sort_order, title, show_title, description, button_text, back_button_text, created_at, updated_at
                     ) VALUES (?,?,?,?,?,?,?,?,?,?)',
                    [
                        (int) $form['id'],
                        'input-1',
                        1,
                        $form['input_page_title'] ?? null,
                        !array_key_exists('show_input_page_title', $form) || !empty($form['show_input_page_title']) ? 1 : 0,
                        $form['description'] ?? null,
                        $form['confirm_button_text'] ?? null,
                        '戻る',
                        $now,
                        $now,
                    ]
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_input_pages: ' . $e->getMessage());
        }
    }

    private static function ensureFormFieldsInputPageKey(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'input_page_key']
            );
            if ((int) ($hasCol['c'] ?? 0) === 0) {
                Database::execute(
                    "ALTER TABLE form_fields ADD COLUMN input_page_key VARCHAR(64) NOT NULL DEFAULT 'input-1' AFTER form_id"
                );
            }
            Database::execute("UPDATE form_fields SET input_page_key = 'input-1' WHERE input_page_key = ''");

            $hasIdx = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ?',
                [$schema, 'form_fields', 'idx_form_sort']
            );
            if ((int) ($hasIdx['c'] ?? 0) > 0) {
                try {
                    Database::execute('ALTER TABLE form_fields DROP KEY idx_form_sort');
                } catch (\Throwable) {
                }
            }
            try {
                Database::execute('ALTER TABLE form_fields ADD KEY idx_form_sort (form_id, input_page_key, sort_order)');
            } catch (\Throwable $e) {
                $m = $e->getMessage();
                if (stripos($m, 'Duplicate') === false && stripos($m, '1061') === false && stripos($m, 'already exists') === false) {
                    error_log('[formkun] SchemaPatch idx_form_sort input_page_key: ' . $m);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.input_page_key: ' . $e->getMessage());
        }
    }

    private static function ensureFormFieldGroups(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasParentGroup = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'parent_group_key']
            );
            if ((int) ($hasParentGroup['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE form_fields ADD COLUMN parent_group_key VARCHAR(64) DEFAULT NULL AFTER input_page_key'
                );
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'form_field_groups']
            );
            if ((int) ($hasTbl['c'] ?? 0) === 0) {
                Database::execute(
                    "CREATE TABLE form_field_groups (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        form_id INT NOT NULL,
                        input_page_key VARCHAR(64) NOT NULL DEFAULT 'input-1',
                        parent_group_key VARCHAR(64) DEFAULT NULL,
                        sort_order INT NOT NULL DEFAULT 0,
                        group_key VARCHAR(64) NOT NULL,
                        label VARCHAR(200) NOT NULL,
                        show_label TINYINT(1) NOT NULL DEFAULT 1,
                        description VARCHAR(500) DEFAULT NULL,
                        visible TINYINT(1) NOT NULL DEFAULT 1,
                        created_at DATETIME NOT NULL,
                        updated_at DATETIME NOT NULL,
                        UNIQUE KEY uk_form_field_group (form_id, group_key),
                        KEY idx_form_field_group_sort (form_id, input_page_key, parent_group_key, sort_order),
                        CONSTRAINT fk_form_field_groups_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_field_groups: ' . $e->getMessage());
        }
    }

    private static function ensureFieldLabelDisplayFlags(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $targets = [
                'form_fields' => 'label',
                'form_field_groups' => 'label',
            ];
            foreach ($targets as $table => $afterColumn) {
                $hasCol = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, $table, 'show_label']
                );
                if ((int) ($hasCol['c'] ?? 0) === 0) {
                    Database::execute(
                        sprintf('ALTER TABLE %s ADD COLUMN show_label TINYINT(1) NOT NULL DEFAULT 1 AFTER %s', $table, $afterColumn)
                    );
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch field show_label: ' . $e->getMessage());
        }
    }

    private static function ensureFormBranchRules(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'form_branch_rules']
            );
            if ((int) ($hasTbl['c'] ?? 0) > 0) {
                $hasTriggerPageKey = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'form_branch_rules', 'trigger_page_key']
                );
                if ((int) ($hasTriggerPageKey['c'] ?? 0) === 0) {
                    Database::execute(
                        "ALTER TABLE form_branch_rules ADD COLUMN trigger_page_key VARCHAR(64) NOT NULL DEFAULT 'input-1' AFTER sort_order"
                    );
                }
                try {
                    Database::execute('ALTER TABLE form_branch_rules ADD KEY idx_form_branch_page_sort (form_id, trigger_page_key, sort_order)');
                } catch (\Throwable $e) {
                    $m = $e->getMessage();
                    if (stripos($m, 'Duplicate') === false && stripos($m, '1061') === false && stripos($m, 'already exists') === false) {
                        error_log('[formkun] SchemaPatch idx_form_branch_page_sort: ' . $m);
                    }
                }
                return;
            }

            Database::execute(
                "CREATE TABLE form_branch_rules (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    form_id INT NOT NULL,
                    rule_key VARCHAR(64) NOT NULL,
                    sort_order INT NOT NULL DEFAULT 0,
                    trigger_page_key VARCHAR(64) NOT NULL DEFAULT 'input-1',
                    source_field_key VARCHAR(64) NOT NULL,
                    operator VARCHAR(32) NOT NULL DEFAULT 'equals',
                    expected_value VARCHAR(255) NOT NULL,
                    action_type VARCHAR(32) NOT NULL,
                    target_type VARCHAR(16) NOT NULL DEFAULT 'field',
                    target_key VARCHAR(64) NOT NULL,
                    enabled TINYINT(1) NOT NULL DEFAULT 1,
                    created_at DATETIME NOT NULL,
                    updated_at DATETIME NOT NULL,
                    UNIQUE KEY uk_form_branch_rule (form_id, rule_key),
                    KEY idx_form_branch_sort (form_id, sort_order),
                    KEY idx_form_branch_page_sort (form_id, trigger_page_key, sort_order),
                    KEY idx_form_branch_source (form_id, source_field_key),
                    CONSTRAINT fk_form_branch_rules_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_branch_rules: ' . $e->getMessage());
        }
    }

    private static function ensureFormFieldTemplates(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'form_field_templates']
            );
            if ((int) ($hasTbl['c'] ?? 0) > 0) {
                return;
            }

            Database::execute(
                'CREATE TABLE form_field_templates (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(200) NOT NULL,
                    fields_json MEDIUMTEXT NOT NULL,
                    field_groups_json MEDIUMTEXT NOT NULL,
                    created_at DATETIME NOT NULL,
                    updated_at DATETIME NOT NULL,
                    KEY idx_form_field_templates_updated (updated_at, id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_field_templates: ' . $e->getMessage());
        }
    }

    private static function ensureFormVersions(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'form_versions']
            );
            if ((int) ($hasTbl['c'] ?? 0) === 0) {
                Database::execute(
                    'CREATE TABLE form_versions (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        form_id INT NOT NULL,
                        version_number INT NOT NULL,
                        action_type VARCHAR(32) NOT NULL,
                        created_by_user_id INT DEFAULT NULL,
                        created_by_name VARCHAR(100) DEFAULT NULL,
                        snapshot_json MEDIUMTEXT NOT NULL,
                        created_at DATETIME NOT NULL,
                        pinned TINYINT(1) NOT NULL DEFAULT 0,
                        UNIQUE KEY uk_form_versions_number (form_id, version_number),
                        KEY idx_form_versions_created (form_id, created_at, id),
                        KEY idx_form_versions_user (created_by_user_id),
                        CONSTRAINT fk_form_versions_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE,
                        CONSTRAINT fk_form_versions_user FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
                );
            }

            $hasPinned = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_versions', 'pinned']
            );
            if ((int) ($hasPinned['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE form_versions ADD COLUMN pinned TINYINT(1) NOT NULL DEFAULT 0 AFTER created_at'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_versions: ' . $e->getMessage());
        }
    }

    private static function ensureFormBranchRuleTargetType(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $hasTargetType = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_branch_rules', 'target_type']
            );
            if ((int) ($hasTargetType['c'] ?? 0) === 0) {
                Database::execute(
                    "ALTER TABLE form_branch_rules ADD COLUMN target_type VARCHAR(16) NOT NULL DEFAULT 'field' AFTER action_type"
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_branch_rules.target_type: ' . $e->getMessage());
        }
    }

    /**
     * 旧定義の app_settings（created_at が無い 3 列のみ）に created_at を追加する。
     */
    private static function ensureAppSettingsCreatedAtColumn(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'app_settings']
            );
            if ((int) ($hasTbl['c'] ?? 0) === 0) {
                return;
            }

            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'app_settings', 'created_at']
            );
            if ((int) ($hasCol['c'] ?? 0) > 0) {
                return;
            }

            Database::execute(
                'ALTER TABLE app_settings ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER setting_value'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch app_settings created_at: ' . $e->getMessage());
        }
    }

    private static function ensureFormsPublicUuid(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'public_uuid']
            );
            if ((int) ($hasCol['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN public_uuid CHAR(36) DEFAULT NULL AFTER slug'
                );
            }

            $rows = Database::fetchAll('SELECT id, public_uuid FROM forms');
            foreach ($rows as $row) {
                $current = trim((string) ($row['public_uuid'] ?? ''));
                if ($current !== '' && is_uuid_v4($current)) {
                    continue;
                }
                Database::execute(
                    'UPDATE forms SET public_uuid = ? WHERE id = ?',
                    [\uuid_v4(), (int) $row['id']]
                );
            }

            try {
                Database::execute(
                    'ALTER TABLE forms MODIFY public_uuid CHAR(36) NOT NULL'
                );
            } catch (\Throwable $e) {
                error_log('[formkun] SchemaPatch forms.public_uuid NOT NULL: ' . $e->getMessage());
            }

            try {
                Database::execute('ALTER TABLE forms ADD UNIQUE KEY uk_forms_public_uuid (public_uuid)');
            } catch (\Throwable $e) {
                $m = $e->getMessage();
                if (stripos($m, 'Duplicate') === false && stripos($m, '1061') === false && stripos($m, 'already exists') === false) {
                    error_log('[formkun] SchemaPatch uk_forms_public_uuid: ' . $m);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms.public_uuid: ' . $e->getMessage());
        }
    }

    private static function ensureSubmissionFilesFileUuid(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'submission_files', 'file_uuid']
            );
            if ((int) ($hasCol['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE submission_files ADD COLUMN file_uuid CHAR(36) DEFAULT NULL AFTER field_key'
                );
            }

            try {
                Database::execute(
                    'ALTER TABLE submission_files ADD UNIQUE KEY uk_submission_files_file_uuid (file_uuid)'
                );
            } catch (\Throwable $e) {
                $m = $e->getMessage();
                if (stripos($m, 'Duplicate') === false && stripos($m, '1061') === false && stripos($m, 'already exists') === false) {
                    error_log('[formkun] SchemaPatch uk_submission_files_file_uuid: ' . $m);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch submission_files.file_uuid: ' . $e->getMessage());
        }
    }

    private static function ensureSubmissionsWorkflowStatus(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'submissions', 'workflow_status']
            );
            if ((int) ($hasCol['c'] ?? 0) === 0) {
                Database::execute(
                    "ALTER TABLE submissions ADD COLUMN workflow_status VARCHAR(32) NOT NULL DEFAULT 'pending' AFTER submitted_at"
                );
            }

            $hasIdx = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ?',
                [$schema, 'submissions', 'idx_form_workflow']
            );
            if ((int) ($hasIdx['c'] ?? 0) === 0) {
                try {
                    Database::execute(
                        'ALTER TABLE submissions ADD KEY idx_form_workflow (form_id, workflow_status, submitted_at)'
                    );
                } catch (\Throwable $e) {
                    $m = $e->getMessage();
                    if (stripos($m, 'Duplicate') === false && stripos($m, '1061') === false && stripos($m, 'already exists') === false) {
                        error_log('[formkun] SchemaPatch idx_form_workflow: ' . $m);
                    }
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch submissions.workflow_status: ' . $e->getMessage());
        }
    }

    private static function ensureMailOnlySubmissionMetadata(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $columns = [
                'storage_mode' => "ALTER TABLE submissions ADD COLUMN storage_mode VARCHAR(20) NOT NULL DEFAULT 'database' AFTER workflow_status",
                'delivery_route' => 'ALTER TABLE submissions ADD COLUMN delivery_route VARCHAR(16) DEFAULT NULL AFTER storage_mode',
                'mail_delivery_status' => 'ALTER TABLE submissions ADD COLUMN mail_delivery_status VARCHAR(16) DEFAULT NULL AFTER delivery_route',
                'mail_error_code' => 'ALTER TABLE submissions ADD COLUMN mail_error_code VARCHAR(64) DEFAULT NULL AFTER mail_delivery_status',
                'attachment_count' => 'ALTER TABLE submissions ADD COLUMN attachment_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER mail_error_code',
                'attachment_total_bytes' => 'ALTER TABLE submissions ADD COLUMN attachment_total_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER attachment_count',
            ];
            foreach ($columns as $column => $sql) {
                $exists = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'submissions', $column]
                );
                if ((int) ($exists['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch mail-only submission metadata failed');
        }
    }

    private static function ensureLoginAttemptsUsernameIndex(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $exists = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ?',
                [$schema, 'login_attempts', 'idx_username_time']
            );
            if ((int) ($exists['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE login_attempts ADD KEY idx_username_time (username, attempted_at)'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch login_attempts username index: ' . $e->getMessage());
        }
    }

    private static function ensureFormEmbedApiTables(): void
    {
        try {
            Database::execute(
                'CREATE TABLE IF NOT EXISTS form_embed_settings (
                    form_id INT NOT NULL PRIMARY KEY,
                    enabled TINYINT(1) NOT NULL DEFAULT 0,
                    public_page_hidden TINYINT(1) NOT NULL DEFAULT 0,
                    allowed_origins_json TEXT DEFAULT NULL,
                    completion_url VARCHAR(500) DEFAULT NULL,
                    japan_only_enabled TINYINT(1) NOT NULL DEFAULT 0,
                    turnstile_enabled TINYINT(1) NOT NULL DEFAULT 0,
                    turnstile_site_key VARCHAR(255) DEFAULT NULL,
                    turnstile_secret_key VARCHAR(255) DEFAULT NULL,
                    recaptcha_enabled TINYINT(1) NOT NULL DEFAULT 0,
                    recaptcha_site_key VARCHAR(255) DEFAULT NULL,
                    recaptcha_secret_key VARCHAR(255) DEFAULT NULL,
                    recaptcha_v3_enabled TINYINT(1) NOT NULL DEFAULT 0,
                    recaptcha_v3_site_key VARCHAR(255) DEFAULT NULL,
                    recaptcha_v3_secret_key VARCHAR(255) DEFAULT NULL,
                    recaptcha_v3_min_score DECIMAL(3,2) NOT NULL DEFAULT 0.50,
                    rate_limit_count INT NOT NULL DEFAULT 10,
                    rate_limit_window_seconds INT NOT NULL DEFAULT 600,
                    created_at DATETIME NOT NULL,
                    updated_at DATETIME NOT NULL,
                    CONSTRAINT fk_form_embed_settings_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            $columns = [
                'public_page_hidden' => 'ALTER TABLE form_embed_settings ADD COLUMN public_page_hidden TINYINT(1) NOT NULL DEFAULT 0 AFTER enabled',
                'completion_url' => 'ALTER TABLE form_embed_settings ADD COLUMN completion_url VARCHAR(500) DEFAULT NULL AFTER allowed_origins_json',
                'japan_only_enabled' => 'ALTER TABLE form_embed_settings ADD COLUMN japan_only_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER allowed_origins_json',
                'recaptcha_enabled' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER turnstile_secret_key',
                'recaptcha_site_key' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_site_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_enabled',
                'recaptcha_secret_key' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_secret_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_site_key',
                'recaptcha_v3_enabled' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_v3_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER recaptcha_secret_key',
                'recaptcha_v3_site_key' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_v3_site_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_v3_enabled',
                'recaptcha_v3_secret_key' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_v3_secret_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_v3_site_key',
                'recaptcha_v3_min_score' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_v3_min_score DECIMAL(3,2) NOT NULL DEFAULT 0.50 AFTER recaptcha_v3_secret_key',
            ];
            foreach ($columns as $column => $sql) {
                $exists = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'form_embed_settings', $column]
                );
                if ((int) ($exists['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
            Database::execute(
                'CREATE TABLE IF NOT EXISTS ip_country_cache (
                    ip VARCHAR(45) NOT NULL PRIMARY KEY,
                    country_code CHAR(2) NOT NULL,
                    checked_at DATETIME NOT NULL,
                    KEY idx_ip_country_checked (checked_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
            Database::execute(
                'CREATE TABLE IF NOT EXISTS public_api_rate_limits (
                    form_id INT NOT NULL,
                    ip VARCHAR(45) NOT NULL,
                    window_started_at INT UNSIGNED NOT NULL,
                    attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
                    updated_at DATETIME NOT NULL,
                    PRIMARY KEY (form_id, ip),
                    KEY idx_public_api_rate_updated (updated_at),
                    CONSTRAINT fk_public_api_rate_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form embed API tables: ' . $e->getMessage());
        }
    }

    private static function ensureMailOnlySubmission(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $columns = [
                'submission_storage_mode' => "ALTER TABLE forms ADD COLUMN submission_storage_mode VARCHAR(20) NOT NULL DEFAULT 'database' AFTER mail_smtp_allow_self_signed",
                'mail_attachment_max_bytes' => 'ALTER TABLE forms ADD COLUMN mail_attachment_max_bytes INT NOT NULL DEFAULT 10485760 AFTER submission_storage_mode',
                'smtp_tested_at' => 'ALTER TABLE forms ADD COLUMN smtp_tested_at DATETIME DEFAULT NULL AFTER mail_attachment_max_bytes',
                'smtp_test_fingerprint' => 'ALTER TABLE forms ADD COLUMN smtp_test_fingerprint CHAR(64) DEFAULT NULL AFTER smtp_tested_at',
            ];
            foreach ($columns as $column => $sql) {
                $exists = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'forms', $column]
                );
                if ((int) ($exists['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
            Database::execute(
                'CREATE TABLE IF NOT EXISTS mail_delivery_audits (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    form_id INT NOT NULL,
                    route VARCHAR(16) NOT NULL,
                    delivery_status VARCHAR(16) NOT NULL,
                    error_code VARCHAR(64) DEFAULT NULL,
                    attachment_count INT UNSIGNED NOT NULL DEFAULT 0,
                    attachment_total_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
                    created_at DATETIME NOT NULL,
                    KEY idx_mail_audit_created (created_at),
                    KEY idx_mail_audit_form_created (form_id, created_at),
                    CONSTRAINT fk_mail_delivery_audits_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
            Database::execute(
                "UPDATE form_versions
                 SET snapshot_json = JSON_REMOVE(snapshot_json, '$.form.mail_smtp_password')
                 WHERE JSON_VALID(snapshot_json) = 1
                   AND JSON_CONTAINS_PATH(snapshot_json, 'one', '$.form.mail_smtp_password') = 1"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch mail-only submission failed');
        }
    }

    private static function ensureFormsSubmissionRetention(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $columns = [
                'submission_retention_days' => 'ALTER TABLE forms ADD COLUMN submission_retention_days INT NOT NULL DEFAULT 14 AFTER mail_attachment_max_bytes',
                'submission_retention_action' => "ALTER TABLE forms ADD COLUMN submission_retention_action VARCHAR(10) NOT NULL DEFAULT 'warn' AFTER submission_retention_days",
                'submission_retention_enabled' => 'ALTER TABLE forms ADD COLUMN submission_retention_enabled TINYINT(1) NOT NULL DEFAULT 1 AFTER submission_retention_action',
            ];
            foreach ($columns as $column => $sql) {
                $exists = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'forms', $column]
                );
                if ((int) ($exists['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch submission retention failed: ' . $e->getMessage());
        }
    }

    private static function ensureUsersRoleViewer(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $row = Database::fetchOne(
                'SELECT COLUMN_TYPE AS t FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'users', 'role']
            );
            $type = (string) ($row['t'] ?? '');
            if ($type !== '' && stripos($type, 'viewer') === false) {
                Database::execute(
                    "ALTER TABLE users MODIFY role ENUM('admin','editor','viewer') NOT NULL DEFAULT 'editor'"
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch users.role viewer: ' . $e->getMessage());
        }
    }

    private static function ensureUserFormGrantsTable(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'user_form_grants']
            );
            if ((int) ($hasTbl['c'] ?? 0) > 0) {
                return;
            }
            Database::execute(
                'CREATE TABLE user_form_grants (
                    user_id INT NOT NULL,
                    form_id INT NOT NULL,
                    access_level ENUM(\'view\',\'edit\') NOT NULL DEFAULT \'view\',
                    PRIMARY KEY (user_id, form_id),
                    KEY idx_user_form_grants_form (form_id),
                    CONSTRAINT fk_user_form_grants_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    CONSTRAINT fk_user_form_grants_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch user_form_grants: ' . $e->getMessage());
        }
    }

    private static function ensureUserFormGrantsAccessLevel(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'user_form_grants', 'access_level']
            );
            if ((int) ($hasCol['c'] ?? 0) > 0) {
                return;
            }
            Database::execute(
                "ALTER TABLE user_form_grants ADD COLUMN access_level ENUM('view','edit') NOT NULL DEFAULT 'view' AFTER form_id"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch user_form_grants.access_level: ' . $e->getMessage());
        }
    }
}
