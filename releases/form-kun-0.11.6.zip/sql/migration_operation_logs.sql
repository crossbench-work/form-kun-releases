-- =================================================================
-- 既存データベース向け：操作ログ（管理画面の操作履歴）用マイグレーション
-- phpMyAdmin などで 1 回だけ実行してください。
-- テーブル作成済みで列だけ足りない場合は、末尾の ALTER のみ実行してください
-- （既にある場合はエラーになるのでその行をスキップ）。
-- =================================================================

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS operation_logs (
    id             BIGINT AUTO_INCREMENT PRIMARY KEY,
    actor_type     ENUM('user','system') NOT NULL DEFAULT 'user',
    actor_id       INT DEFAULT NULL,
    actor_username VARCHAR(64) DEFAULT NULL,
    action         VARCHAR(64) NOT NULL,
    target_type    VARCHAR(64) DEFAULT NULL,
    target_id      VARCHAR(64) DEFAULT NULL,
    target_name    VARCHAR(255) DEFAULT NULL,
    summary        VARCHAR(500) DEFAULT NULL,
    detail_json    TEXT DEFAULT NULL,
    client_ip      VARCHAR(45) DEFAULT NULL,
    created_at     DATETIME NOT NULL,
    KEY idx_operation_logs_created (created_at),
    KEY idx_operation_logs_action (action, created_at),
    KEY idx_operation_logs_actor (actor_type, actor_id, created_at),
    CONSTRAINT fk_operation_logs_actor FOREIGN KEY (actor_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- フェーズ2 で追加した列（テーブル作成済みの環境向け）
ALTER TABLE operation_logs
    ADD COLUMN target_name VARCHAR(255) DEFAULT NULL AFTER target_id;

ALTER TABLE operation_logs
    ADD COLUMN summary VARCHAR(500) DEFAULT NULL AFTER target_name;

-- フェーズ4 で target_id を設定キー（文字列）も格納できるよう拡張（テーブル作成済みの環境向け）
ALTER TABLE operation_logs
    MODIFY target_id VARCHAR(64) DEFAULT NULL;
