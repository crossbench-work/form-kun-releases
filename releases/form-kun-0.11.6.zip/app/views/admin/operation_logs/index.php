<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-pagination01/c-pagination01.php';
require_once APP_COMPONENTS_DIR . '/c-halfModal01/c-halfModal01.php';

$listPath = '/admin/operation-logs';
$listQuery = [];
if ($kind !== '') {
    $listQuery['kind'] = $kind;
}
if ($action !== '') {
    $listQuery['action'] = $action;
}
if ($from !== '') {
    $listQuery['from'] = $from;
}
if ($to !== '') {
    $listQuery['to'] = $to;
}
if ((int) $page > 1) {
    $listQuery['page'] = (int) $page;
}
$listUrl = base_path($listPath);
$hasFilter = $kind !== '' || $action !== '' || $from !== '' || $to !== '';
?>

<div data-module="m-submissionListToolbar01">
    <div data-module="m-toolbar01">
        <h1 class="title" style="margin:0;">操作ログ</h1>
        <div class="spacer"></div>
        <span data-module="m-text01" data-type="muted"><?= number_format($total) ?>件</span>
        <span class="m-submissionListToolbar01__divider" aria-hidden="true"></span>
        <span class="m-submissionListToolbar01__group">
            <button type="button"
                    class="btn is-icon<?= $hasFilter ? ' is-active' : '' ?>"
                    data-target="operation-logs-search-open"
                    aria-label="検索"
                    title="検索"
                    aria-pressed="<?= $hasFilter ? 'true' : 'false' ?>">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
            </button>
            <?php if ($hasFilter): ?>
            <a class="btn is-icon"
               href="<?= e($listUrl) ?>"
               aria-label="リセット"
               title="リセット">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
            </a>
            <?php endif; ?>
        </span>
    </div>
</div>

<?php admin_c_form_block01_open(); ?>
<div class="area is-field">
    <?php if (empty($rows)): ?>
        <p data-module="m-text01" data-type="muted">該当する操作ログがありません。</p>
    <?php else: ?>
        <?php admin_m_table01_open(); ?>
        <?php admin_m_table01_thead([
            ['label' => '日時', 'class' => 'is-updated-at'],
            ['label' => '種別'],
            ['label' => '実行者'],
            ['label' => 'アクション'],
            ['label' => '対象'],
            ['label' => '概要'],
            ['label' => 'IP'],
        ]); ?>
        <tbody>
            <?php foreach ($rows as $row): ?>
                <?php
                    $kindType = (string) ($row['actor_type'] ?? 'user');
                    $actorUsername = trim((string) ($row['actor_username'] ?? ''));
                    $targetName = trim((string) ($row['target_name'] ?? ''));
                    $targetId = trim((string) ($row['target_id'] ?? ''));
                    $targetLabel = $targetName !== '' ? $targetName : ($targetId !== '' ? $targetId : '—');
                ?>
                <tr>
                    <td class="is-updated-at"><a href="<?= e(base_path('/admin/operation-logs/' . (int) $row['id'])) ?>"><?= e((string) ($row['created_at'] ?? '')) ?></a></td>
                    <td><?php
                        admin_m_badge01(
                            $kindType === 'system' ? 'システム' : 'ユーザー',
                            $kindType === 'system' ? 'system' : 'user'
                        );
                    ?></td>
                    <td><?php
                        if ($actorUsername !== '') {
                            echo '<code>' . e($actorUsername) . '</code>';
                        } elseif ($kindType === 'system') {
                            echo '—';
                        } else {
                            echo '（不明）';
                        }
                    ?></td>
                    <td><code><?= e((string) ($row['action'] ?? '')) ?></code></td>
                    <td><?= e($targetLabel) ?></td>
                    <td><?= e((string) ($row['summary'] ?? '')) ?></td>
                    <td><?= e((string) ($row['client_ip'] ?? '')) !== '' ? e((string) $row['client_ip']) : '—' ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <?php admin_m_table01_close(); ?>
    <?php endif; ?>
</div>

<?php if (!empty($rows) && (int) $totalPages > 1): ?>
<?php admin_c_pagination01_open(); ?>
    <?php
        $qs = static function (int $p) use ($kind, $action, $from, $to): string {
            $params = ['page' => $p];
            if ($kind !== '')   $params['kind'] = $kind;
            if ($action !== '') $params['action'] = $action;
            if ($from !== '')   $params['from'] = $from;
            if ($to !== '')     $params['to'] = $to;
            return '?' . http_build_query($params);
        };
        $base = $listUrl;
    ?>
    <?php if ($page > 1): ?>
        <a href="<?= e($base . $qs($page - 1)) ?>">‹ 前へ</a>
    <?php else: ?>
        <span class="disabled">‹ 前へ</span>
    <?php endif; ?>

    <?php for ($p = max(1, $page - 3); $p <= min($totalPages, $page + 3); $p++): ?>
        <?php if ($p === $page): ?>
            <span class="current"><?= $p ?></span>
        <?php else: ?>
            <a href="<?= e($base . $qs($p)) ?>"><?= $p ?></a>
        <?php endif; ?>
    <?php endfor; ?>

    <?php if ($page < $totalPages): ?>
        <a href="<?= e($base . $qs($page + 1)) ?>">次へ ›</a>
    <?php else: ?>
        <span class="disabled">次へ ›</span>
    <?php endif; ?>
<?php admin_c_pagination01_close(); ?>
<?php endif; ?>

<?php admin_c_halfModal01_open(['hidden' => true]); ?>
    <?php admin_c_halfModal01_backdrop('operation-logs-search-close'); ?>
    <?php admin_c_halfModal01_panel_open('operation-logs-search-modal-title'); ?>
        <?php admin_c_halfModal01_header_open(); ?>
            <h2 id="operation-logs-search-modal-title">検索</h2>
            <button type="button" class="btn is-sm" data-target="operation-logs-search-close">閉じる</button>
        <?php admin_c_halfModal01_header_close(); ?>
        <?php admin_c_halfModal01_body_open(); ?>
            <form method="get" action="<?= e($listUrl) ?>" id="operation-logs-search-form">
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('種別'), 'operation-logs-kind'); ?>
                    <?php admin_m_input01_open(); ?>
                        <select id="operation-logs-kind"
                                name="kind"
                                <?= admin_m_bold_title01_aria_labelledby_attr('operation-logs-kind') ?>>
                            <option value="">すべて</option>
                            <option value="user"<?= $kind === 'user' ? ' selected' : '' ?>>ユーザー</option>
                            <option value="system"<?= $kind === 'system' ? ' selected' : '' ?>>システム</option>
                        </select>
                    <?php admin_m_input01_close(); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('アクション'), 'operation-logs-action'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('operation-logs-action', [
                            'type' => 'text',
                            'id' => 'operation-logs-action',
                            'name' => 'action',
                            'value' => (string) $action,
                            'placeholder' => '例: form.',
                            'maxlength' => 64,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('期間（開始日）'), 'operation-logs-from'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('operation-logs-from', [
                            'type' => 'date',
                            'id' => 'operation-logs-from',
                            'name' => 'from',
                            'value' => (string) $from,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('期間（終了日）'), 'operation-logs-to'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('operation-logs-to', [
                            'type' => 'date',
                            'id' => 'operation-logs-to',
                            'name' => 'to',
                            'value' => (string) $to,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
                <div class="c-halfModal01__actions is-centered">
                    <button type="submit" class="btn is-primary">絞り込む</button>
                    <a class="btn"
                       href="<?= e($listUrl) ?>"
                       <?php if (!$hasFilter): ?>aria-disabled="true" tabindex="-1"<?php endif; ?>>リセット</a>
                </div>
            </form>
        <?php admin_c_halfModal01_body_close(); ?>
    <?php admin_c_halfModal01_panel_close(); ?>
<?php admin_c_halfModal01_close(); ?>

<?php admin_c_form_block01_close(); ?>
