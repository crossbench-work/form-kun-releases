<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';

$log = $log ?? [];
$createdAt = (string) ($log['created_at'] ?? '');
$kindType = (string) ($log['actor_type'] ?? 'user');
$actorUsername = trim((string) ($log['actor_username'] ?? ''));
$action = (string) ($log['action'] ?? '');
$targetType = trim((string) ($log['target_type'] ?? ''));
$targetId = trim((string) ($log['target_id'] ?? ''));
$targetName = trim((string) ($log['target_name'] ?? ''));
$summary = (string) ($log['summary'] ?? '');
$clientIp = (string) ($log['client_ip'] ?? '');

$targetParts = [];
if ($targetType !== '') {
    $targetParts[] = '<code>' . e($targetType) . '</code>';
}
if ($targetId !== '') {
    $targetParts[] = e($targetId);
}
if ($targetName !== '') {
    $targetParts[] = e($targetName);
}

/**
 * detail_json の値を1セル分の表示に整形する。
 */
$renderDetailValue = static function ($value): string {
    if (is_string($value)) {
        return e($value);
    }
    $encoded = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($encoded === false) {
        return '';
    }
    return '<pre style="white-space:pre-wrap;word-break:break-all;margin:0;"><code>' . e($encoded) . '</code></pre>';
};

$detail = [];
$rawDetail = (string) ($log['detail_json'] ?? '');
if ($rawDetail !== '') {
    $decoded = json_decode($rawDetail, true);
    if (is_array($decoded) && $decoded !== []) {
        $detail = $decoded;
    }
}
?>

<?php admin_c_breadcrumb01([
    ['label' => '操作ログ', 'href' => base_path('/admin/operation-logs')],
    ['label' => $createdAt, 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-field">
                                <?php admin_m_table01_open('is-kv'); ?>
                                    <tr><th>ID</th><td><?= e((string) ($log['id'] ?? '')) ?></td></tr>
                                    <tr><th>日時</th><td><?= e($createdAt) ?></td></tr>
                                    <tr><th>種別</th><td><?php
                                        admin_m_badge01(
                                            $kindType === 'system' ? 'システム' : 'ユーザー',
                                            $kindType === 'system' ? 'system' : 'user'
                                        );
                                    ?></td></tr>
                                    <tr><th>実行者</th><td><?php
                                        if ($kindType === 'user' && $actorUsername !== '') {
                                            echo '<code>' . e($actorUsername) . '</code>';
                                            if ($actorRole !== null && $actorRole !== '') {
                                                echo '（' . e($actorRole) . '）';
                                            }
                                        } elseif ($kindType === 'user') {
                                            echo '（不明）';
                                        } else {
                                            echo '—';
                                        }
                                    ?></td></tr>
                                    <tr><th>アクション</th><td><code><?= e($action) ?></code></td></tr>
                                    <tr><th>対象</th><td><?= $targetParts !== [] ? implode(' / ', $targetParts) : '—' ?></td></tr>
                                    <tr><th>概要</th><td><?= $summary !== '' ? e($summary) : '—' ?></td></tr>
                                    <tr><th>IPアドレス</th><td><?= $clientIp !== '' ? e($clientIp) : '—' ?></td></tr>
                                <?php admin_m_table01_close(); ?>
                            </div>
<?php admin_c_form_block01_close(); ?>

<?php if ($detail !== []): ?>
<?php admin_c_form_block01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_large_title01('詳細'); ?>
                            </div>
                            <div class="area is-field">
                                <?php admin_m_table01_open('is-kv'); ?>
                                <?php foreach ($detail as $key => $value): ?>
                                    <tr>
                                        <th><span data-module="m-text01" data-type="muted"><?= e((string) $key) ?></span></th>
                                        <td><?= $renderDetailValue($value) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php admin_m_table01_close(); ?>
                            </div>
<?php admin_c_form_block01_close(); ?>
<?php endif; ?>
