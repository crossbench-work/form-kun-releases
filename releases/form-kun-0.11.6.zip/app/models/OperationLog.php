<?php
namespace Models;

use Core\Auth;
use Core\Database;

/**
 * 操作ログ（operation_logs）の記録。
 *
 * - user() は管理画面ログイン中のユーザー、system() は cron 等のシステム実行者として記録する。
 * - 記録に失敗しても元の処理を止めない（try/catch で握りつぶし、error_log に出すだけ）。
 * - summary は人が読める日本語。対象が分かる情報（ユーザー名・フォーム名など）を含める。
 * - detail_json にフォームの送信内容（入力値）や機密情報（パスワード・トークン・公開鍵等）を
 *   入れないこと。識別に必要な最小限のメタデータだけを渡す前提の設計。
 * - ログは自動削除しない。
 *
 * 使い方:
 *   OperationLog::user('user.create', [
 *       'summary'     => 'ユーザー「foo」を作成しました',
 *       'target_type' => 'user',
 *       'target_id'   => 3,
 *       'target_name' => 'foo',
 *       'detail'      => ['role' => 'editor'],
 *   ]);
 */
class OperationLog
{
    /**
     * ログイン中ユーザーの操作として記録する。
     * ログイン成功／ログアウト／ユーザー管理などの操作に使う（ログイン失敗は記録しない）。
     *
     * target_id はフォームやユーザーの ID（数値）と設定キー（文字列）の両方を格納できる（VARCHAR(64)）。
     *
     * @param array{summary?: string, target_type?: string, target_id?: int|string, target_name?: string, detail?: array} $context
     */
    public static function user(string $action, array $context = []): void
    {
        $username = null;
        $user = Auth::user();
        if ($user !== null) {
            $username = (string) ($user['username'] ?? '');
        }
        self::record('user', $username, $action, $context);
    }

    /**
     * システム（cron 等）の操作として記録する。実行者・IP は NULL になる。
     *
     * @param array{summary?: string, target_type?: string, target_id?: int|string, target_name?: string, detail?: array} $context
     */
    public static function system(string $action, array $context = []): void
    {
        self::record('system', null, $action, $context);
    }

    /**
     * @param array{summary?: string, target_type?: string, target_id?: int|string, target_name?: string, detail?: array} $context
     */
    private static function record(string $actorType, ?string $actorUsername, string $action, array $context): void
    {
        try {
            $summary = trim((string) ($context['summary'] ?? ''));
            $targetType = trim((string) ($context['target_type'] ?? ''));
            $targetId = $context['target_id'] ?? null;
            $targetName = trim((string) ($context['target_name'] ?? ''));
            $detail = $context['detail'] ?? null;

            $targetIdValue = null;
            if ($targetId !== null && $targetId !== '' && (is_int($targetId) || is_string($targetId))) {
                $targetIdValue = mb_substr((string) $targetId, 0, 64);
            }

            $detailJson = null;
            if (is_array($detail) && $detail !== []) {
                $encoded = json_encode($detail, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                if ($encoded !== false && $encoded !== null) {
                    // detail は入力値・機密情報を含めない前提。防御として長さのみ丸める。
                    $detailJson = mb_substr($encoded, 0, 4000);
                }
            }

            $actorId = null;
            $actorUsernameValue = null;
            if ($actorType === 'user') {
                $actorId = Auth::id();
                if ($actorUsername !== null && $actorUsername !== '') {
                    $actorUsernameValue = $actorUsername;
                }
            }

            Database::execute(
                'INSERT INTO operation_logs (actor_type, actor_id, actor_username, action, target_type, target_id, target_name, summary, detail_json, client_ip, created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                [
                    $actorType,
                    $actorId,
                    $actorUsernameValue !== null ? mb_substr($actorUsernameValue, 0, 64) : null,
                    mb_substr($action, 0, 64),
                    $targetType !== '' ? mb_substr($targetType, 0, 64) : null,
                    $targetIdValue,
                    $targetName !== '' ? mb_substr($targetName, 0, 255) : null,
                    $summary !== '' ? mb_substr($summary, 0, 500) : null,
                    $detailJson,
                    $actorType === 'user' ? client_ip() : null,
                    date('Y-m-d H:i:s'),
                ]
            );
        } catch (\Throwable $e) {
            // 記録の失敗で元の処理を変えない。detail・summary の内容は入力由来でない前提だが、安全のため例外メッセージは出さない。
            error_log('[formkun] operation log write failed');
        }
    }

    /**
     * 1件を取得する。見つからない場合は null。
     *
     * @return array<string, mixed>|null
     */
    public static function find(int $id): ?array
    {
        $row = Database::fetchOne('SELECT * FROM operation_logs WHERE id = ?', [$id]);
        return $row;
    }

    /**
     * 閲覧画面用の検索。新しい順（created_at DESC, id DESC）で返す。
     *
     * @return array{rows: array<int, array<string, mixed>>, total: int}
     */
    public static function search(
        ?string $kind,
        ?string $actionPrefix,
        ?string $from,
        ?string $to,
        int $page = 1,
        int $perPage = 50
    ): array {
        $where = [];
        $params = [];
        if ($kind !== null && $kind !== '') {
            $where[] = 'actor_type = ?';
            $params[] = $kind;
        }
        if ($actionPrefix !== null && $actionPrefix !== '') {
            $where[] = 'action LIKE ?';
            $params[] = $actionPrefix . '%';
        }
        if ($from !== null && $from !== '') {
            $where[] = 'created_at >= ?';
            $params[] = $from . ' 00:00:00';
        }
        if ($to !== null && $to !== '') {
            $where[] = 'created_at <= ?';
            $params[] = $to . ' 23:59:59';
        }
        $sqlWhere = $where !== [] ? ' WHERE ' . implode(' AND ', $where) : '';

        $totalRow = Database::fetchOne(
            'SELECT COUNT(*) AS c FROM operation_logs' . $sqlWhere,
            $params
        );
        $total = (int) ($totalRow['c'] ?? 0);

        $page = max(1, $page);
        $perPage = max(1, $perPage);
        $offset = ($page - 1) * $perPage;

        $rows = Database::fetchAll(
            'SELECT * FROM operation_logs' . $sqlWhere
            . ' ORDER BY created_at DESC, id DESC LIMIT ' . $perPage . ' OFFSET ' . $offset,
            $params
        );

        return ['rows' => $rows, 'total' => $total];
    }
}
