<?php
/**
 * 保存期間を過ぎた送信の強制削除（cron から実行する）。
 * 対象は保存期間を「設定する」かつ、期間を過ぎた履歴を「削除する」に設定したフォームだけ。
 *
 * 使い方:
 *   php app/cli/purge_expired_submissions.php            削除する
 *   php app/cli/purge_expired_submissions.php --dry-run  削除せず件数だけ表示する（スケジュール判定をスキップ）
 *   php app/cli/purge_expired_submissions.php --force    スケジュール判定をスキップして削除する
 *
 * cron の例（1 時間に 1 回起動し、実行間隔は管理画面の設定で判定）:
 *   0 * * * * php /path/to/app/cli/purge_expired_submissions.php >> /path/to/purge.log 2>&1
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

define('FORMKUN_BOOT', true);
define('FORMKUN_AREA', 'cli');
require dirname(__DIR__) . '/bootstrap.php';

use Core\Database;
use Core\SubmissionPurgeSchedule;
use Core\SubmissionRetention;
use Models\Form;
use Models\OperationLog;

$args = array_slice($argv ?? [], 1);
$dryRun = in_array('--dry-run', $args, true);
$force = in_array('--force', $args, true);
$now = time();
$totalDeleted = 0;

if (!$force && !$dryRun) {
    if (!SubmissionPurgeSchedule::isEnabled()) {
        fwrite(STDOUT, "定期削除は管理画面で無効になっています。\n");
        exit(0);
    }
    if (!SubmissionPurgeSchedule::isDue($now)) {
        fwrite(STDOUT, "スケジュール上、まだ実行時刻ではありません。\n");
        exit(0);
    }
}

// 処理開始（スケジュール判定を通過した実行のみ記録）
OperationLog::system('cron.submission_purge.start', [
    'summary' => '送信履歴の定期削除を開始しました',
    'detail'  => $dryRun ? ['dry_run' => true] : [],
]);

try {
    $forms = Database::fetchAll(
        'SELECT * FROM forms WHERE submission_retention_enabled = 1 AND submission_retention_action = ? ORDER BY id ASC',
        [Form::RETENTION_DELETE]
    );
    foreach ($forms as $form) {
        $formId = (int) $form['id'];
        $cutoff = Form::retentionCutoff($form, $now);
        $label = '[form ' . $formId . '] ' . (string) ($form['title'] ?? '') . '（保存期間 ' . Form::retentionDays($form) . '日、' . $cutoff . ' より前）';

        if ($dryRun) {
            $count = SubmissionRetention::countExpired($form, $now);
            fwrite(STDOUT, $label . ': 削除対象 ' . $count . "件\n");
            $totalDeleted += $count;
            continue;
        }

        $deleted = SubmissionRetention::purgeExpired($form, $now);
        fwrite(STDOUT, $label . ': ' . $deleted . "件削除\n");
        $totalDeleted += $deleted;
    }
} catch (\Throwable $e) {
    error_log('[formkun] purge expired submissions failed: ' . $e->getMessage());
    fwrite(STDERR, '削除処理に失敗しました: ' . $e->getMessage() . "\n");
    // 異常終了も可能な範囲で記録する（エラーの要約のみ。機密情報・送信内容は入れない）
    $failDetail = [
        'success' => false,
        'deleted' => $totalDeleted,
        'forms'   => isset($forms) ? count($forms) : 0,
        'error'   => mb_substr($e->getMessage(), 0, 200),
    ];
    if ($dryRun) {
        $failDetail['dry_run'] = true;
    }
    OperationLog::system('cron.submission_purge.end', [
        'summary' => '送信履歴の定期削除が異常終了しました',
        'detail'  => $failDetail,
    ]);
    exit(1);
}

if (!$dryRun) {
    SubmissionPurgeSchedule::markRun($now);
}

fwrite(STDOUT, ($dryRun ? '削除対象の合計: ' : '削除した合計: ') . $totalDeleted . '件（対象フォーム ' . count($forms) . "件）\n");

$endDetail = [
    'success' => true,
    'deleted' => $totalDeleted,
    'forms'   => count($forms),
];
if ($dryRun) {
    $endDetail['dry_run'] = true;
}
OperationLog::system('cron.submission_purge.end', [
    'summary' => '送信履歴の定期削除を終了しました',
    'detail'  => $endDetail,
]);
exit(0);
