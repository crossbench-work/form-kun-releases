<?php
namespace Controllers\Admin;

use Core\AppUpdater;
use Core\Auth;
use Core\Csrf;
use Models\OperationLog;

class SystemUpdateController
{
    public function __construct()
    {
        Auth::requireCanAccessSettings();
    }

    public function index(): void
    {
        Auth::requireRole('admin');
        redirect('/admin/settings#app-update');
    }

    public function run(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $wantsJson = Csrf::wantsJsonResponse();

        if (!AppUpdater::isServerUpdateAllowed()) {
            $message = 'サーバーからの更新が無効です。';
            flash('danger', $message);
            if ($wantsJson) {
                header('Content-Type: application/json; charset=UTF-8');
                echo json_encode(['ok' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
                exit;
            }
            redirect('/admin/settings#app-update');
        }

        $version = trim((string) ($_POST['version'] ?? ''));
        if ($version === '') {
            $message = 'バージョンを指定してください。';
            flash('danger', $message);
            if ($wantsJson) {
                header('Content-Type: application/json; charset=UTF-8');
                echo json_encode(['ok' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
                exit;
            }
            redirect('/admin/settings#app-update');
        }

        $versionBefore = AppUpdater::currentVersion();
        $result = AppUpdater::applyRelease($version);
        if ($result['ok']) {
            unset($_SESSION['formkun_update_apply_version']);
            OperationLog::user('system.update', [
                'summary'     => 'アプリをバージョン ' . $version . ' へ更新しました',
                'target_type' => 'setting',
                'target_id'   => 'app_version',
                'detail'      => [
                    'version_from' => $versionBefore,
                    'version_to'   => AppUpdater::currentVersion(),
                    'requested'    => $version,
                ],
            ]);
        }
        $message = (string) ($result['message'] ?? '');
        flash($result['ok'] ? 'success' : 'danger', $message);
        if ($wantsJson) {
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode(['ok' => (bool) $result['ok'], 'message' => $message], JSON_UNESCAPED_UNICODE);
            exit;
        }
        redirect('/admin/settings#app-update');
    }

    public function check(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        if (!AppUpdater::isServerUpdateAllowed()) {
            flash('danger', 'サーバーからの更新が無効です。');
            redirect('/admin/settings#app-update');
        }

        $result = AppUpdater::fetchManifest();
        if (!$result['ok']) {
            flash('danger', $result['message']);
            redirect('/admin/settings#app-update');
        }

        $latest = (string) ($result['manifest']['latest'] ?? '');
        $current = AppUpdater::currentVersion();
        if ($latest === '' || version_compare($latest, $current, '<=')) {
            unset($_SESSION['formkun_update_apply_version']);
            flash('success', 'お使いのバージョンは最新です（' . $current . '）。');
        } else {
            $_SESSION['formkun_update_apply_version'] = $latest;
            flash('info', '新しいバージョン ' . $latest . ' があります。「更新する」から適用できます。');
        }
        OperationLog::user('system.update_check', [
            'summary'     => 'アプリの更新を確認しました（現在: ' . $current . ($latest !== '' ? '、最新: ' . $latest : '') . '）',
            'target_type' => 'setting',
            'target_id'   => 'app_version',
            'detail'      => ['current_version' => $current, 'latest_version' => $latest],
        ]);
        redirect('/admin/settings#app-update');
    }

    public function upload(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $file = $_FILES['update_zip'] ?? null;
        if (!is_array($file)) {
            $file = null;
        }

        $versionBefore = AppUpdater::currentVersion();
        $result = AppUpdater::applyUploadedZip($file, '');
        if ($result['ok']) {
            OperationLog::user('system.update_upload', [
                'summary'     => 'ZIP をアップロードしてアプリを更新しました',
                'target_type' => 'setting',
                'target_id'   => 'app_version',
                'detail'      => [
                    'version_from' => $versionBefore,
                    'version_to'   => AppUpdater::currentVersion(),
                ],
            ]);
        }
        flash($result['ok'] ? 'success' : 'danger', $result['message']);
        redirect('/admin/settings#app-update');
    }
}
