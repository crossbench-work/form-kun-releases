<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\Csrf;
use Core\FileTypePolicy;
use Core\FileStorage;
use Core\View;
use Models\Form;
use Models\FormField;
use Models\OperationLog;
use Models\Submission;

class SubmissionController
{
    private const PER_PAGE_OPTIONS = [10, 20, 50, 100];
    private const PER_PAGE_DEFAULT = 20;

    public function __construct()
    {
        Auth::requireLogin();
    }

    public function index(int $formId): void
    {
        Auth::requireFormAccess($formId);
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $q    = isset($_GET['q']) ? trim((string) $_GET['q']) : '';
        $from = isset($_GET['from']) ? trim((string) $_GET['from']) : '';
        $to   = isset($_GET['to']) ? trim((string) $_GET['to']) : '';
        $statusFilter = isset($_GET['status']) ? trim((string) $_GET['status']) : '';
        if ($statusFilter !== '' && !Submission::isValidWorkflowStatus($statusFilter)) {
            $statusFilter = '';
        }
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $perPage = self::perPageFromRequest();

        $result = Submission::search(
            $formId,
            $q ?: null,
            $from ?: null,
            $to ?: null,
            $page,
            $perPage,
            $statusFilter !== '' ? $statusFilter : null
        );
        $totalPages = max(1, (int) ceil($result['total'] / $perPage));

        (new View())->render('admin/forms/submissions/index', array_merge([
            'title'   => '送信履歴: ' . $form['title'],
            'form'    => $form,
            'rows'    => $result['rows'],
            'total'   => $result['total'],
            'page'    => $page,
            'totalPages' => $totalPages,
            'perPage' => $perPage,
            'q'       => $q,
            'from'    => $from,
            'to'      => $to,
            'statusFilter' => $statusFilter,
            'workflowStatusOptions' => Submission::allowedWorkflowStatuses(),
            'submission_read_only' => !Auth::canWriteSubmissions($formId),
        ], self::listPreviewData($formId, $result['rows']), self::retentionData($form)), 'admin');
    }

    /**
     * エクスポート専用ページ。期間で絞り込んだ送信を一覧表示し、その全件をエクスポートする。
     */
    public function exportPage(int $formId): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $from = trim((string) ($_GET['from'] ?? ''));
        $to   = trim((string) ($_GET['to'] ?? ''));
        $periodError = null;
        if (($from !== '' && !self::isValidDate($from)) || ($to !== '' && !self::isValidDate($to))) {
            $periodError = '期間の日付が正しくないため、すべての送信を表示しています。';
            $from = $to = '';
        } elseif ($from !== '' && $to !== '' && $from > $to) {
            $periodError = '開始日は終了日以前の日付にしてください。すべての送信を表示しています。';
            $from = $to = '';
        }

        $page = max(1, (int) ($_GET['page'] ?? 1));
        $perPage = self::perPageFromRequest();
        $result = Submission::search($formId, null, $from ?: null, $to ?: null, $page, $perPage);

        (new View())->render('admin/forms/submissions/export', array_merge([
            'title'   => 'エクスポート: ' . $form['title'],
            'form'    => $form,
            'rows'    => $result['rows'],
            'total'   => $result['total'],
            'page'    => $page,
            'totalPages' => max(1, (int) ceil($result['total'] / $perPage)),
            'perPage' => $perPage,
            'from'    => $from,
            'to'      => $to,
            'periodError' => $periodError,
            'exportNotice' => self::exportNotice($formId, trim((string) ($_GET['export'] ?? ''))),
        ], self::listPreviewData($formId, $result['rows']), self::retentionData($form)), 'admin');
    }

    /**
     * 保存期間の警告表示用（期限日時・期限切れ件数・設定）。
     *
     * @param array<string, mixed> $form
     * @return array{retentionEnabled:bool, retentionCutoff:string, retentionDays:int, retentionDeletes:bool, expiredCount:int}
     */
    private static function retentionData(array $form): array
    {
        return [
            'retentionEnabled' => Form::retentionEnabled($form),
            'retentionCutoff' => Form::retentionCutoff($form),
            'retentionDays' => Form::retentionDays($form),
            'retentionDeletes' => Form::retentionDeletes($form),
            'expiredCount' => Form::countExpiredSubmissions($form),
        ];
    }

    /**
     * 一覧のプレビュー列（先頭 3 項目の値と添付）を用意する。
     *
     * @param array<int, array<string, mixed>> $rows
     * @return array{fields: array, previewKeys: list<string>, previews: array, previewFiles: array}
     */
    private static function listPreviewData(int $formId, array $rows): array
    {
        $fields = FormField::orderedSubmittableForForm($formId, true);
        $previewKeys = array_slice(array_map(fn($f) => $f['field_key'], $fields), 0, 3);
        $previews = [];
        $previewFiles = [];
        if (!empty($rows)) {
            $ids = array_map(fn($r) => (int) $r['id'], $rows);
            $in = implode(',', array_fill(0, count($ids), '?'));
            $values = \Core\Database::fetchAll(
                "SELECT submission_id, field_key, value FROM submission_values WHERE submission_id IN ($in)",
                $ids
            );
            foreach ($values as $r) {
                $previews[(int) $r['submission_id']][$r['field_key']] = $r['value'];
            }
            $previewFiles = Submission::filesGroupedBySubmission($ids);
        }

        return [
            'fields' => $fields,
            'previewKeys' => $previewKeys,
            'previews' => $previews,
            'previewFiles' => $previewFiles,
        ];
    }

    /**
     * エクスポートページの URL（base_path なし）。
     */
    private static function exportPageUrl(
        int $formId,
        string $from = '',
        string $to = '',
        ?string $token = null,
        int $page = 0,
        int $perPage = 0
    ): string {
        $query = array_filter([
            'from' => $from,
            'to' => $to,
            'export' => $token,
            'page' => $page > 1 ? $page : null,
            'per_page' => $perPage > 0 ? $perPage : null,
        ], static fn($v): bool => $v !== null && $v !== '');
        return '/admin/forms/' . $formId . '/submissions/export' . ($query !== [] ? '?' . http_build_query($query) : '');
    }

    private static function perPageFromRequest(?int $raw = null): int
    {
        if ($raw !== null && $raw > 0) {
            $value = $raw;
        } else {
            $value = (int) ($_GET['per_page'] ?? self::PER_PAGE_DEFAULT);
        }

        return in_array($value, self::PER_PAGE_OPTIONS, true) ? $value : self::PER_PAGE_DEFAULT;
    }

    public function show(int $id): void
    {
        $sub = Submission::find($id);
        if (!$sub) { $this->notFound(); return; }
        Auth::requireFormAccess((int) $sub['form_id']);
        $form = Form::find((int) $sub['form_id']);
        if (!$form) { $this->notFound(); return; }
        $fields = FormField::orderedSubmittableForForm((int) $form['id'], true);
        $values = Submission::valuesFor($id);
        $files  = Submission::filesFor($id);

        // ファイルキーのインデックス
        $filesByKey = [];
        foreach ($files as $f) {
            $filesByKey[$f['field_key']][] = $f;
        }

        (new View())->render('admin/forms/submissions/show', [
            'title' => '送信内容詳細',
            'form'  => $form,
            'sub'   => $sub,
            'fields'=> $fields,
            'values'=> $values,
            'filesByKey' => $filesByKey,
            'workflowStatusOptions' => Submission::allowedWorkflowStatuses(),
            'submission_read_only' => !Auth::canWriteSubmissions((int) $form['id']),
        ], 'admin');
    }

    public function updateStatus(int $id): void
    {
        Csrf::verify();
        $sub = Submission::find($id);
        if (!$sub) {
            $this->notFound();
            return;
        }
        Auth::requireFormAccess((int) $sub['form_id']);
        Auth::requireCanWriteSubmissions((int) $sub['form_id']);

        $status = trim((string) ($_POST['status'] ?? ''));
        if (!Submission::isValidWorkflowStatus($status)) {
            flash('error', '無効な状態です。');
            redirect($this->safeRedirectAfterStatusChange($sub));
            return;
        }

        Submission::updateWorkflowStatus($id, $status);
        $statusForm = Form::find((int) $sub['form_id']);
        OperationLog::user('submission.status_update', [
            'summary'     => 'フォーム「' . (string) ($statusForm['title'] ?? '') . '」の送信（ID: ' . $id . '）の状態を「' . Submission::workflowStatusLabel($status) . '」に更新しました',
            'target_type' => 'form',
            'target_id'   => (int) $sub['form_id'],
            'target_name' => (string) ($statusForm['title'] ?? ''),
            'detail'      => ['submission_id' => $id, 'status' => $status],
        ]);
        flash('success', '状態を「' . Submission::workflowStatusLabel($status) . '」に更新しました。');
        redirect($this->safeRedirectAfterStatusChange($sub));
    }

    public function destroy(int $id): void
    {
        Csrf::verify();
        $sub = Submission::find($id);
        if (!$sub) { $this->notFound(); return; }
        Auth::requireFormAccess((int) $sub['form_id']);
        Auth::requireCanWriteSubmissions((int) $sub['form_id']);
        $formId = (int) $sub['form_id'];
        Submission::delete($id);
        $deletedForm = Form::find($formId);
        OperationLog::user('submission.delete', [
            'summary'     => 'フォーム「' . (string) ($deletedForm['title'] ?? '') . '」の送信（ID: ' . $id . '）を削除しました',
            'target_type' => 'form',
            'target_id'   => $formId,
            'target_name' => (string) ($deletedForm['title'] ?? ''),
            'detail'      => ['submission_id' => $id],
        ]);
        flash('success', '送信を削除しました。');
        redirect('/admin/forms/' . $formId . '/submissions');
    }

    public function bulkDelete(int $formId): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        Csrf::verify();
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $submissions = $this->selectedSubmissionsForFormOrRedirect($formId);
        if ($submissions === null) {
            return;
        }

        $submissionIds = array_map(static fn(array $submission): int => (int) $submission['id'], $submissions);
        Submission::bulkDelete($submissionIds);

        OperationLog::user('submission.bulk_delete', [
            'summary'     => 'フォーム「' . (string) $form['title'] . '」の送信 ' . count($submissionIds) . ' 件を削除しました',
            'target_type' => 'form',
            'target_id'   => $formId,
            'target_name' => (string) $form['title'],
            'detail'      => ['count' => count($submissionIds)],
        ]);

        flash('success', count($submissionIds) . '件の送信を削除しました。');
        redirect($this->safeSubmissionsIndexRedirect($formId));
    }

    public function exportCsv(int $formId): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        Csrf::verify();
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $submissions = $this->selectedSubmissionsForFormOrRedirect($formId);
        if ($submissions === null) {
            return;
        }

        $filename = $this->exportFilename($form, '', '', $submissions, (string) ($_POST['export_filename'] ?? ''));
        OperationLog::user('submission.export_csv', [
            'summary'     => 'フォーム「' . (string) $form['title'] . '」の送信 ' . count($submissions) . ' 件を CSV エクスポートしました',
            'target_type' => 'form',
            'target_id'   => $formId,
            'target_name' => (string) $form['title'],
            'detail'      => ['count' => count($submissions)],
        ]);
        $this->redirectToPreparedExport($formId, $submissions, $filename, false, '', '');
    }

    /**
     * エクスポートページで指定した期間（空欄なら全期間）の送信を ZIP（CSV + 復元用 JSON、任意で添付）で書き出す。
     */
    public function exportByPeriod(int $formId): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        Csrf::verify();
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $from = trim((string) ($_POST['from'] ?? ''));
        $to   = trim((string) ($_POST['to'] ?? ''));
        $includeAttachments = !empty($_POST['include_files']);
        $perPage = self::perPageFromRequest(isset($_POST['per_page']) ? (int) $_POST['per_page'] : null);

        if (($from !== '' && !self::isValidDate($from)) || ($to !== '' && !self::isValidDate($to))) {
            flash('error', 'エクスポート期間の日付が正しくありません。');
            redirect(self::exportPageUrl($formId, '', '', null, 0, $perPage));
        }
        if ($from !== '' && $to !== '' && $from > $to) {
            flash('error', 'エクスポート期間の開始日は終了日以前の日付にしてください。');
            redirect(self::exportPageUrl($formId, '', '', null, 0, $perPage));
        }
        $backUrl = self::exportPageUrl($formId, $from, $to, null, 0, $perPage);

        $submissions = $this->selectedSubmissionsForExportOrRedirect($formId, $from, $to, $perPage);
        if ($submissions === null) {
            return;
        }

        $maxRows = max(1, (int) config('submissions.export_max_rows', 10000));
        $selectedCount = count($submissions);
        if ($selectedCount > $maxRows) {
            flash('error', '選択した送信が ' . number_format($selectedCount) . ' 件あり、一度にエクスポートできる上限（'
                . number_format($maxRows) . ' 件）を超えています。');
            redirect($backUrl);
        }

        if (!class_exists(\ZipArchive::class)) {
            flash('error', 'サーバーが ZIP 作成に対応していないため、エクスポートできません。');
            redirect($backUrl);
        }
        if ($includeAttachments) {
            $totalBytes = \Core\SubmissionArchive::zipEntries($submissions)['total_bytes'];
            $maxBytes = \Core\SubmissionArchive::maxZipAttachmentBytes();
            if ($totalBytes > $maxBytes) {
                flash('error', '添付ファイルの合計（約 ' . number_format((int) ceil($totalBytes / 1048576)) . 'MB）が、一度にエクスポートできる上限（約 '
                    . number_format((int) floor($maxBytes / 1048576)) . 'MB）を超えています。期間を絞るか、添付ファイルを含めずにエクスポートしてください。');
                redirect($backUrl);
            }
        }

        $filename = $this->exportFilename($form, $from, $to, $submissions, (string) ($_POST['export_filename'] ?? ''));
        OperationLog::user('submission.export_zip', [
            'summary'     => 'フォーム「' . (string) $form['title'] . '」の送信 ' . count($submissions) . ' 件を ZIP エクスポートしました',
            'target_type' => 'form',
            'target_id'   => $formId,
            'target_name' => (string) $form['title'],
            'detail'      => [
                'count'              => count($submissions),
                'period_from'        => $from,
                'period_to'          => $to,
                'include_attachments' => $includeAttachments ? 1 : 0,
            ],
        ]);
        $this->redirectToPreparedExport($formId, $submissions, $filename, true, $from, $to, $includeAttachments);
    }

    /**
     * 準備済みエクスポートのファイルを返す。一覧の案内ブロックから自動または手動で呼ばれる。
     */
    public function downloadExport(int $formId, string $token): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        $job = self::findExport($formId, $token);
        if ($job === null) {
            self::plainError(404, 'エクスポートの有効期限が切れたか、見つかりません。送信履歴画面からもう一度エクスポートしてください。');
        }
        $submissions = self::existingExportSubmissions($formId, $job);
        if ($submissions === []) {
            self::plainError(404, 'エクスポート対象の送信はすでに削除されています。');
        }

        $_SESSION[self::EXPORT_SESSION_KEY][$token]['downloaded_at'] = time();
        // 大きな ZIP の送信中も一覧画面の操作がセッションロックで待たされないようにする。
        session_write_close();
        @set_time_limit(300);

        if (!empty($job['with_files'])) {
            $includeAttachments = array_key_exists('include_attachments', $job)
                ? !empty($job['include_attachments'])
                : true;
            $this->sendSubmissionsZip($formId, $submissions, (string) $job['filename'], $includeAttachments);
        }

        while (ob_get_level() > 0) { ob_end_clean(); }
        self::sendDownloadHeaders('text/csv; charset=UTF-8', $job['filename'] . '.csv');
        $output = fopen('php://output', 'wb');
        if ($output === false) {
            self::plainError(500, 'CSVを出力できませんでした。');
        }
        $this->writeSubmissionsCsv($output, $formId, $submissions);
        fclose($output);
        exit;
    }

    /**
     * ダウンロード済みのエクスポート対象を削除する（添付ファイルも削除される）。
     */
    public function deleteExport(int $formId, string $token): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        Csrf::verify();
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $job = self::findExport($formId, $token);
        if ($job === null) {
            flash('error', 'エクスポートの有効期限が切れたか、見つかりません。');
            redirect(self::exportPageUrl($formId));
        }
        $from = (string) ($job['from'] ?? '');
        $to = (string) ($job['to'] ?? '');
        if (empty($job['downloaded_at'])) {
            flash('error', 'まだダウンロードされていないため削除できません。ファイルをダウンロードしてから削除してください。');
            redirect(self::exportPageUrl($formId, $from, $to, $token));
        }

        $ids = array_map(static fn(array $s): int => (int) $s['id'], self::existingExportSubmissions($formId, $job));
        if ($ids !== []) {
            Submission::bulkDelete($ids);
        }
        unset($_SESSION[self::EXPORT_SESSION_KEY][$token]);
        flash('success', count($ids) . '件の送信と添付ファイルを削除しました。');
        redirect(self::exportPageUrl($formId, $from, $to));
    }

    /**
     * 一覧の案内ブロック用。現在のフォームに属する有効なエクスポート履歴を返す。
     *
     * @return array{token:string, count:int, filename:string, downloaded:bool}|null
     */
    private static function exportNotice(int $formId, string $token): ?array
    {
        $job = self::findExport($formId, $token);
        if ($job === null) {
            return null;
        }
        return [
            'token' => $token,
            'count' => count($job['submission_ids']),
            'filename' => $job['filename'] . (!empty($job['with_files']) ? '.zip' : '.csv'),
            'downloaded' => !empty($job['downloaded_at']),
        ];
    }

    private const EXPORT_SESSION_KEY = '_submission_exports';
    private const EXPORT_TTL_SECONDS = 60;
    private const EXPORT_MAX_JOBS = 5;

    /**
     * @param array<int, array<string, mixed>> $submissions
     */
    private function redirectToPreparedExport(
        int $formId,
        array $submissions,
        string $filename,
        bool $withFiles,
        string $from,
        string $to,
        bool $includeAttachments = false
    ): void {
        self::pruneExports();
        $token = bin2hex(random_bytes(16));
        $jobs = (array) ($_SESSION[self::EXPORT_SESSION_KEY] ?? []);
        $jobs[$token] = [
            'form_id' => $formId,
            'submission_ids' => array_map(static fn(array $s): int => (int) $s['id'], $submissions),
            'filename' => $filename,
            'with_files' => $withFiles,
            'include_attachments' => $includeAttachments,
            'from' => $from,
            'to' => $to,
            'created_at' => time(),
            'downloaded_at' => null,
        ];
        $_SESSION[self::EXPORT_SESSION_KEY] = array_slice($jobs, -self::EXPORT_MAX_JOBS, null, true);

        redirect(self::exportPageUrl($formId, $from, $to, $token));
    }

    /**
     * @return array<string, mixed>|null
     */
    private static function findExport(int $formId, string $token): ?array
    {
        if (preg_match('/\A[0-9a-f]{32}\z/', $token) !== 1) {
            return null;
        }
        self::pruneExports();
        $job = $_SESSION[self::EXPORT_SESSION_KEY][$token] ?? null;
        if (!is_array($job) || (int) ($job['form_id'] ?? 0) !== $formId) {
            return null;
        }
        return $job;
    }

    private static function pruneExports(): void
    {
        $jobs = $_SESSION[self::EXPORT_SESSION_KEY] ?? null;
        if (!is_array($jobs)) {
            return;
        }
        $cutoff = time() - self::EXPORT_TTL_SECONDS;
        foreach ($jobs as $token => $job) {
            if (!is_array($job) || (int) ($job['created_at'] ?? 0) < $cutoff) {
                unset($jobs[$token]);
            }
        }
        $_SESSION[self::EXPORT_SESSION_KEY] = $jobs;
    }

    /**
     * @param array<string, mixed> $job
     * @return array<int, array<string, mixed>>
     */
    private static function existingExportSubmissions(int $formId, array $job): array
    {
        $ids = Submission::normalizeIds((array) ($job['submission_ids'] ?? []));
        if ($ids === []) {
            return [];
        }
        $rows = Submission::findByIdsForForm($formId, $ids);
        usort($rows, static function (array $a, array $b): int {
            return [(string) $a['submitted_at'], (int) $a['id']] <=> [(string) $b['submitted_at'], (int) $b['id']];
        });
        return $rows;
    }

    private static function plainError(int $status, string $message): never
    {
        while (ob_get_level() > 0) { ob_end_clean(); }
        http_response_code($status);
        header('Content-Type: text/plain; charset=UTF-8');
        echo $message;
        exit;
    }

    /**
     * CSV と添付ファイル本体を ZIP にまとめて送信する。CSV のファイル項目には ZIP 内のパスを記載する。
     *
     * @param array<int, array<string, mixed>> $submissions
     */
    private function sendSubmissionsZip(int $formId, array $submissions, string $baseName, bool $includeAttachments = true): never
    {
        if (!class_exists(\ZipArchive::class)) {
            self::plainError(500, 'サーバーが ZIP 作成に対応していないため、添付ファイルを含めてエクスポートできません。');
        }

        $entries = [];
        $mailOnlyIds = [];
        if ($includeAttachments) {
            ['entries' => $entries, 'total_bytes' => $totalBytes, 'mail_only_ids' => $mailOnlyIds] = \Core\SubmissionArchive::zipEntries($submissions);
            if ($totalBytes > \Core\SubmissionArchive::maxZipAttachmentBytes()) {
                self::plainError(413, '添付ファイルの合計が、一度にエクスポートできる上限を超えています。期間を絞ってください。');
            }
        } else {
            foreach ($submissions as $submission) {
                if (Submission::isMailOnlyMetadata($submission)) {
                    $mailOnlyIds[(int) $submission['id']] = true;
                }
            }
        }

        $zipPath = tempnam(sys_get_temp_dir(), 'fk-export-');
        $csvPath = tempnam(sys_get_temp_dir(), 'fk-export-csv-');
        if ($zipPath === false || $csvPath === false) {
            http_response_code(500);
            echo 'ZIPを作成できませんでした。';
            exit;
        }

        try {
            $csv = fopen($csvPath, 'wb');
            if ($csv === false) {
                throw new \RuntimeException('CSV の一時ファイルを開けません。');
            }
            $this->writeSubmissionsCsv($csv, $formId, $submissions, $includeAttachments
                ? static function (array $file) use ($entries, $mailOnlyIds): string {
                $name = trim((string) ($file['original_name'] ?? ''));
                if (isset($mailOnlyIds[(int) ($file['submission_id'] ?? 0)])) {
                    return $name;
                }
                $entry = $entries[(int) ($file['id'] ?? 0)] ?? null;
                return $entry !== null ? $entry['name'] : $name . '（ファイルなし）';
            }
                : null);
            fclose($csv);

            $zip = new \ZipArchive();
            if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
                throw new \RuntimeException('ZIP を作成できません。');
            }
            $zip->addFile($csvPath, $baseName . '.csv');
            $zip->addFromString(\Core\SubmissionArchive::MANIFEST_NAME, \Core\SubmissionArchive::exportManifestJson($formId, $submissions, $entries, $mailOnlyIds));
            if ($includeAttachments) {
                foreach ($entries as $entry) {
                    $zip->addFile($entry['abs'], $entry['name']);
                }
            }
            if (!$zip->close()) {
                throw new \RuntimeException('ZIP の書き込みに失敗しました。');
            }

            while (ob_get_level() > 0) { ob_end_clean(); }
            self::sendDownloadHeaders('application/zip', $baseName . '.zip');
            header('Content-Length: ' . filesize($zipPath));
            readfile($zipPath);
        } catch (\Throwable $e) {
            error_log('[form-kun] submissions zip export failed: ' . $e->getMessage());
            if (!headers_sent()) {
                http_response_code(500);
                echo 'ZIPを作成できませんでした。';
            }
        } finally {
            @unlink($csvPath);
            @unlink($zipPath);
        }
        exit;
    }

    /**
     * @param resource $output
     * @param array<int, array<string, mixed>> $submissions
     * @param (callable(array<string, mixed>): string)|null $fileCell 添付 1 件を CSV のセル文字列にする（既定は元ファイル名）
     */
    private function writeSubmissionsCsv($output, int $formId, array $submissions, ?callable $fileCell = null): void
    {
        $submissionIds = array_map(static fn(array $submission): int => (int) $submission['id'], $submissions);
        $fields = FormField::orderedSubmittableForForm($formId, true);
        $valuesBySubmission = Submission::valuesGroupedBySubmission($submissionIds);
        $filesBySubmission = Submission::filesGroupedBySubmission($submissionIds);

        fwrite($output, "\xEF\xBB\xBF");
        $header = ['送信ID', '受信日時', '状態', 'IPアドレス'];
        $header[] = 'User-Agent';
        $header[] = '保存方式';
        $header[] = 'SMTP配送結果';
        $header[] = '添付件数';
        $header[] = '添付合計容量';
        foreach ($fields as $field) {
            $label = trim((string) ($field['label'] ?? ''));
            $header[] = $label !== '' ? $label : (string) ($field['field_key'] ?? '');
        }
        fputcsv($output, self::sanitizeCsvRow($header));

        foreach ($submissions as $submission) {
            $submissionId = (int) $submission['id'];
            $workflowStatus = (string) ($submission['workflow_status'] ?? Submission::WORKFLOW_PENDING);
            $row = [
                (string) $submissionId,
                (string) ($submission['submitted_at'] ?? ''),
                Submission::workflowStatusLabel($workflowStatus),
                (string) ($submission['ip'] ?? ''),
                (string) ($submission['user_agent'] ?? ''),
                Submission::isMailOnlyMetadata($submission) ? 'SMTPメールのみ' : 'DB保存',
                Submission::mailDeliveryStatusLabel((string) ($submission['mail_delivery_status'] ?? '')),
                (string) (int) ($submission['attachment_count'] ?? 0),
                (string) (int) ($submission['attachment_total_bytes'] ?? 0),
            ];
            foreach ($fields as $field) {
                $row[] = $this->formatSubmissionCsvFieldValue(
                    $field,
                    $submissionId,
                    $valuesBySubmission,
                    $filesBySubmission,
                    $fileCell
                );
            }
            fputcsv($output, self::sanitizeCsvRow($row));
        }
    }

    private static function sendDownloadHeaders(string $contentType, string $filename): void
    {
        header('Content-Type: ' . $contentType);
        header('Content-Disposition: attachment; filename="' . self::asciiFallback($filename)
            . '"; filename*=UTF-8\'\'' . rawurlencode($filename));
        header('X-Content-Type-Options: nosniff');
    }

    private static function isValidDate(string $value): bool
    {
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        return $date !== false && $date->format('Y-m-d') === $value;
    }

    public function download(int $fileId): void
    {
        $file = Submission::findFile($fileId);
        if (!$file) { $this->notFound(); return; }
        $sub = Submission::find((int) ($file['submission_id'] ?? 0));
        if (!$sub) { $this->notFound(); return; }
        Auth::requireFormAccess((int) $sub['form_id']);
        $abs = FileStorage::absolutePath($file['stored_path']);
        if (!is_file($abs)) {
            http_response_code(404);
            echo 'File not found';
            exit;
        }

        $name = (string) $file['original_name'];
        $serving = submission_file_serving_mime($file, $abs);
        $requestedInline = isset($_GET['inline']) && (string) $_GET['inline'] !== '' && (string) $_GET['inline'] !== '0';
        $inline = $requestedInline && $serving['inline_ok'];
        $mime = $serving['mime_matches'] ? $serving['mime'] : 'application/octet-stream';

        while (ob_get_level() > 0) { ob_end_clean(); }
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($abs));
        $disposition = $inline ? 'inline' : 'attachment';
        header('Content-Disposition: ' . $disposition . '; filename="' . self::asciiFallback($name)
            . '"; filename*=UTF-8\'\'' . rawurlencode($name));
        header('X-Content-Type-Options: nosniff');
        header('Content-Security-Policy: sandbox');
        readfile($abs);
        exit;
    }

    private static function asciiFallback(string $name): string
    {
        $ascii = preg_replace('/[^\x20-\x7e]/', '_', $name) ?? 'download';
        return str_replace('"', '_', $ascii);
    }

    /**
     * @param array<int, scalar|null> $row
     * @return array<int, string>
     */
    private static function sanitizeCsvRow(array $row): array
    {
        return array_map(static function ($value): string {
            $cell = (string) ($value ?? '');
            if (preg_match('/\A(?:[=+\-@\x09\x0A\x0D]|[＝＋－＠])/u', $cell) === 1) {
                return "'" . $cell;
            }
            return $cell;
        }, $row);
    }

    /**
     * @param array<string, mixed> $sub
     */
    private function safeRedirectAfterStatusChange(array $sub): string
    {
        $formId = (int) $sub['form_id'];
        $subId = (int) $sub['id'];
        $fallbackList = '/admin/forms/' . $formId . '/submissions';
        $fallbackShow = '/admin/forms/submissions/' . $subId;

        $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
        if ($referer === '') {
            return $fallbackShow;
        }

        $path = parse_url($referer, PHP_URL_PATH);
        if (!is_string($path) || $path === '') {
            return $fallbackShow;
        }

        $base = rtrim((string) config('site.base_path', ''), '/');
        if ($base !== '' && str_starts_with($path, $base)) {
            $path = substr($path, strlen($base)) ?: '/';
        }

        $allowedPrefixes = [
            '/admin/forms/' . $formId . '/submissions',
            '/admin/forms/submissions/' . $subId,
        ];
        foreach ($allowedPrefixes as $prefix) {
            if ($path === $prefix || str_starts_with($path, $prefix . '?')) {
                $query = parse_url($referer, PHP_URL_QUERY);
                return $path . (is_string($query) && $query !== '' ? '?' . $query : '');
            }
        }

        return $fallbackShow;
    }

    /**
     * @return array<int, array<string, mixed>>|null
     */
    private function selectedSubmissionsForFormOrRedirect(int $formId): ?array
    {
        $submissionIds = Submission::normalizeIds($_POST['submission_ids'] ?? []);
        if ($submissionIds === []) {
            flash('error', '送信を選択してください。');
            redirect($this->safeSubmissionsIndexRedirect($formId));
        }

        $submissions = Submission::findByIdsForForm($formId, $submissionIds);
        if (count($submissions) !== count($submissionIds)) {
            flash('error', '選択した送信の一部が見つからないか、このフォームに属していません。');
            redirect($this->safeSubmissionsIndexRedirect($formId));
        }

        return $submissions;
    }

    /**
     * @return array<int, array<string, mixed>>|null
     */
    private function selectedSubmissionsForExportOrRedirect(int $formId, string $from, string $to, int $perPage): ?array
    {
        $backUrl = self::exportPageUrl($formId, $from, $to, null, 0, $perPage);
        $submissionIds = Submission::normalizeIds($_POST['submission_ids'] ?? []);
        if ($submissionIds === []) {
            flash('error', '送信を選択してください。');
            redirect($backUrl);
        }

        $submissions = Submission::findByIdsForForm($formId, $submissionIds);
        if (count($submissions) !== count($submissionIds)) {
            flash('error', '選択した送信の一部が見つからないか、このフォームに属していません。');
            redirect($backUrl);
        }

        return $submissions;
    }

    private function safeSubmissionsIndexRedirect(int $formId): string
    {
        $fallback = '/admin/forms/' . $formId . '/submissions';
        $candidates = [];
        $postedRedirect = trim((string) ($_POST['redirect_to'] ?? ''));
        if ($postedRedirect !== '') {
            $candidates[] = $postedRedirect;
        }
        $referer = trim((string) ($_SERVER['HTTP_REFERER'] ?? ''));
        if ($referer !== '') {
            $candidates[] = $referer;
        }

        foreach ($candidates as $candidate) {
            $path = parse_url($candidate, PHP_URL_PATH);
            if (!is_string($path) || $path === '') {
                continue;
            }

            $base = rtrim((string) config('site.base_path', ''), '/');
            if ($base !== '' && str_starts_with($path, $base)) {
                $path = substr($path, strlen($base)) ?: '/';
            }

            if ($path !== $fallback) {
                continue;
            }

            $query = parse_url($candidate, PHP_URL_QUERY);
            return $path . (is_string($query) && $query !== '' ? '?' . $query : '');
        }

        return $fallback;
    }

    /**
     * @param array<string, mixed> $form
     */
    /**
     * 拡張子を除いたダウンロード名。入力が空なら「期間_フォーム名」とし、期間の空欄は対象データの最初・最後の受信日で補う。
     *
     * @param array<string, mixed> $form
     * @param array<int, array<string, mixed>> $submissions
     */
    private function exportFilename(array $form, string $from, string $to, array $submissions, string $input): string
    {
        $input = preg_replace('/\.(csv|zip)\z/i', '', trim($input)) ?? '';
        $custom = self::filenameSafe($input);
        if ($custom !== '') {
            return $custom;
        }

        $dates = array_map(static fn(array $s): string => substr((string) ($s['submitted_at'] ?? ''), 0, 10), $submissions);
        $dates = array_values(array_filter($dates, static fn(string $d): bool => self::isValidDate($d)));
        sort($dates);
        $start = $from !== '' ? $from : ($dates[0] ?? date('Y-m-d'));
        $end = $to !== '' ? $to : ($dates[count($dates) - 1] ?? date('Y-m-d'));
        $period = str_replace('-', '', $start) . ($start !== $end ? '-' . str_replace('-', '', $end) : '');

        $title = self::filenameSafe((string) ($form['title'] ?? ''));
        return $period . '_' . ($title !== '' ? $title : 'form-' . (int) ($form['id'] ?? 0));
    }

    /**
     * ダウンロード名に使えない文字（区切り文字・制御文字・Windows の禁止文字・先頭のドット）を除く。
     */
    private static function filenameSafe(string $name): string
    {
        $name = preg_replace('/[\x00-\x1f\x7f\/\\\\:*?"<>|]/u', '_', $name) ?? '';
        $name = trim(ltrim($name, '. '));
        return mb_substr($name, 0, 100, 'UTF-8');
    }

    /**
     * @param array<string, mixed> $field
     * @param array<int, array<string, string>> $valuesBySubmission
     * @param array<int, array<string, list<array<string, mixed>>>> $filesBySubmission
     */
    private function formatSubmissionCsvFieldValue(
        array $field,
        int $submissionId,
        array $valuesBySubmission,
        array $filesBySubmission,
        ?callable $fileCell = null
    ): string {
        $fieldKey = (string) ($field['field_key'] ?? '');
        $fieldType = (string) ($field['type'] ?? '');

        if ($fieldType === 'file') {
            $files = $filesBySubmission[$submissionId][$fieldKey] ?? [];
            $names = [];
            foreach ($files as $file) {
                $name = $fileCell !== null
                    ? trim($fileCell($file))
                    : trim((string) ($file['original_name'] ?? ''));
                if ($name !== '') {
                    $names[] = $name;
                }
            }
            return implode("\n", $names);
        }

        $value = (string) ($valuesBySubmission[$submissionId][$fieldKey] ?? '');
        return match ($fieldType) {
            'address' => format_address_value_display($value),
            'text_pair' => format_text_pair_value_display($value, FormField::decodeTextPairLabels($field['options_json'] ?? null)),
            'text_multi' => format_text_multi_value_display($value, FormField::decodeTextMultiItems($field['options_json'] ?? null, true)),
            FormField::TYPE_MATRIX => format_matrix_value_display($value, FormField::decodeMatrixSettings($field['options_json'] ?? null)),
            default => $value,
        };
    }

    private function notFound(): void
    {
        http_response_code(404);
        echo '<!doctype html><meta charset="utf-8"><title>404</title><h1>404</h1>';
        exit;
    }
}
