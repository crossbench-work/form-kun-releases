<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\Csrf;
use Core\View;
use Core\WebAuthnService;
use Models\OperationLog;
use Models\User;
use Models\UserWebauthnCredential;

class AccountController
{
    public function index(): void
    {
        Auth::requireLogin();
        $id = (int) Auth::id();
        $user = User::find($id);
        if (!$user) {
            Auth::logout();
            redirect('/admin/login');
        }

        (new View())->render('admin/account/index', [
            'title' => 'アカウント設定',
            'user' => $user,
            'passkeys' => WebAuthnService::available() ? UserWebauthnCredential::listForUser($id) : [],
            'webauthnAvailable' => WebAuthnService::available(),
        ], 'admin');
    }

    public function update(): void
    {
        Auth::requireLogin();
        Csrf::verify();

        $id = (int) Auth::id();
        $user = User::find($id);
        if (!$user) {
            redirect('/admin/login');
        }

        $displayName = trim((string) ($_POST['display_name'] ?? ''));
        $email = trim((string) ($_POST['email'] ?? ''));

        $errors = [];
        if ($displayName === '') {
            $displayName = (string) $user['username'];
        }
        if ($email !== '') {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors[] = 'メールアドレスの形式が正しくありません。';
            } else {
                $other = User::findByEmail($email);
                if ($other !== null && (int) $other['id'] !== $id) {
                    $errors[] = 'そのメールアドレスは既に使われています。';
                }
            }
        }

        if ($errors !== []) {
            (new View())->render('admin/account/index', [
                'title' => 'アカウント設定',
                'user' => array_merge($user, ['display_name' => $displayName, 'email' => $email]),
                'passkeys' => WebAuthnService::available() ? UserWebauthnCredential::listForUser($id) : [],
                'webauthnAvailable' => WebAuthnService::available(),
                'errors' => $errors,
            ], 'admin');
            return;
        }

        User::updateSelf($id, $displayName, $email !== '' ? $email : null);
        Auth::refreshCurrentUser();
        OperationLog::user('account.update', [
            'summary'     => 'ユーザー「' . (string) $user['username'] . '」のアカウント情報を更新しました',
            'target_type' => 'user',
            'target_id'   => $id,
            'target_name' => (string) $user['username'],
        ]);
        flash('success', 'アカウント情報を更新しました。');
        redirect('/admin/account');
    }
}
