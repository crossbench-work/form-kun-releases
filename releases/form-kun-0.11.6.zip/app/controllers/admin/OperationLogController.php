<?php
namespace Controllers\Admin;

use Core\Auth;
use Models\OperationLog;

/**
 * 操作ログの閲覧（admin のみ）。閲覧自体は操作ログに記録しない。
 */
class OperationLogController
{
    public function __construct()
    {
        Auth::requireRole('admin');
    }

    public function index(): void
    {
        $kind = trim((string) ($_GET['kind'] ?? ''));
        if (!in_array($kind, ['user', 'system'], true)) {
            $kind = '';
        }
        $action = trim((string) ($_GET['action'] ?? ''));
        if (mb_strlen($action) > 64) {
            $action = mb_substr($action, 0, 64);
        }
        $from = trim((string) ($_GET['from'] ?? ''));
        $to = trim((string) ($_GET['to'] ?? ''));
        if (($from !== '' && !self::isValidDate($from)) || ($to !== '' && !self::isValidDate($to))) {
            $from = $to = '';
        } elseif ($from !== '' && $to !== '' && $from > $to) {
            $from = $to = '';
        }

        $perPage = 50;
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $result = OperationLog::search($kind, $action, $from, $to, $page, $perPage);
        $totalPages = max(1, (int) ceil($result['total'] / $perPage));
        $page = min($page, $totalPages);

        (new \Core\View())->render('admin/operation_logs/index', [
            'title'      => '操作ログ',
            'rows'       => $result['rows'],
            'total'      => $result['total'],
            'page'       => $page,
            'totalPages' => $totalPages,
            'perPage'    => $perPage,
            'kind'       => $kind,
            'action'     => $action,
            'from'       => $from,
            'to'         => $to,
        ], 'admin');
    }

    public function show(int $id): void
    {
        $log = OperationLog::find($id);
        if ($log === null) {
            http_response_code(404);
            echo '<!doctype html><meta charset="utf-8"><title>404</title><h1>404</h1>';
            return;
        }

        // 実行者のロールは operation_logs に無いため users を参照する（削除済みなら null のまま）。
        $actorRole = null;
        if ((string) ($log['actor_type'] ?? '') === 'user' && (int) ($log['actor_id'] ?? 0) > 0) {
            $actor = \Models\User::find((int) $log['actor_id']);
            $actorRole = $actor !== null ? (string) $actor['role'] : null;
        }

        (new \Core\View())->render('admin/operation_logs/show', [
            'title'     => '操作ログ',
            'log'       => $log,
            'actorRole' => $actorRole,
        ], 'admin');
    }

    private static function isValidDate(string $value): bool
    {
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        return $date !== false && $date->format('Y-m-d') === $value;
    }
}
