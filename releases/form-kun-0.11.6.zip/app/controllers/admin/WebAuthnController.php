<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\Csrf;
use Core\WebAuthnService;
use Models\FormVersion;
use Models\OperationLog;
use Models\User;
use Models\UserWebauthnCredential;

class WebAuthnController
{
    public function loginOptions(): void
    {
        $this->requireWebAuthn();
        Csrf::verifyRequest();

        $body = json_request_body() ?? [];
        $username = trim((string) ($body['username'] ?? ''));
        $ip = client_ip();

        if ($username === '') {
            json_response(['error' => 'ログインIDを入力してください。'], 400);
        }

        if (Auth::isLockedOut($ip, $username)) {
            json_response(['error' => '連続してログインに失敗しています。しばらく時間をおいてから再度お試しください。'], 429);
        }

        $user = User::findByUsername($username);
        if (!$user) {
            json_response(['error' => 'このログインIDにはパスキーが登録されていません。'], 404);
        }

        $service = new WebAuthnService();
        $options = $service->buildLoginOptions($user);
        if ($options === null) {
            json_response(['error' => 'このログインIDにはパスキーが登録されていません。'], 404);
        }

        json_response($options);
    }

    public function loginVerify(): void
    {
        $this->requireWebAuthn();
        Csrf::verifyRequest();

        $body = json_request_body() ?? [];
        $username = trim((string) ($body['username'] ?? ''));
        $credential = $body['credential'] ?? null;
        $ip = client_ip();

        if ($username === '' || !is_array($credential)) {
            json_response(['error' => 'リクエストが不正です。'], 400);
        }

        if (Auth::isLockedOut($ip, $username)) {
            json_response(['error' => '連続してログインに失敗しています。しばらく時間をおいてから再度お試しください。'], 429);
        }

        $user = User::findByUsername($username);
        if (!$user) {
            Auth::recordAttempt($ip, $username, false);
            json_response(['error' => 'パスキーによるログインに失敗しました。'], 401);
        }

        try {
            $service = new WebAuthnService();
            $service->verifyLogin($user, $credential);
        } catch (\Throwable $e) {
            Auth::recordAttempt($ip, $username, false);
            json_response(['error' => $this->publicWebAuthnMessage($e)], 401);
        }

        Auth::login($user);
        Auth::recordAttempt($ip, $username, true);
        User::recordLogin((int) $user['id']);
        FormVersion::createLifecycleSnapshots(FormVersion::ACTION_LOGIN, Auth::user());

        $redirect = $_SESSION['_intended'] ?? null;
        unset($_SESSION['_intended']);
        if (!is_string($redirect) || $redirect === '') {
            $redirect = base_path('/admin/');
        }

        session_write_close();
        json_response(['redirect' => $redirect]);
    }

    public function registerOptions(): void
    {
        $this->requireWebAuthn();
        Auth::requireLogin();
        Csrf::verifyRequest();

        $user = User::find((int) Auth::id());
        if (!$user) {
            json_response(['error' => 'ユーザーが見つかりません。'], 404);
        }

        $service = new WebAuthnService();
        json_response($service->buildRegistrationOptions($user));
    }

    public function registerVerify(): void
    {
        $this->requireWebAuthn();
        Auth::requireLogin();
        Csrf::verifyRequest();

        $body = json_request_body() ?? [];
        $credential = $body['credential'] ?? null;
        $name = isset($body['name']) ? trim((string) $body['name']) : null;

        if (!is_array($credential)) {
            json_response(['error' => 'リクエストが不正です。'], 400);
        }

        $user = User::find((int) Auth::id());
        if (!$user) {
            json_response(['error' => 'ユーザーが見つかりません。'], 404);
        }

        try {
            $service = new WebAuthnService();
            $service->verifyRegistration($user, $credential, $name);
        } catch (\Throwable $e) {
            json_response(['error' => $this->publicWebAuthnMessage($e)], 400);
        }

        json_response(['ok' => true]);
    }

    public function deleteCredential(int $id): void
    {
        $this->requireWebAuthn();
        Auth::requireLogin();
        Csrf::verifyRequest();

        $row = UserWebauthnCredential::find($id);
        if ($row === null) {
            json_response(['error' => 'パスキーが見つかりません。'], 404);
        }

        $ownerId = (int) $row['user_id'];
        $selfId = (int) Auth::id();
        if ($ownerId !== $selfId && !Auth::isAdmin()) {
            json_response(['error' => 'この操作を行う権限がありません。'], 403);
        }

        UserWebauthnCredential::delete($id);

        $owner = User::find($ownerId);
        if ($owner !== null) {
            OperationLog::user('webauthn.credential.delete', [
                'summary'     => 'ユーザー「' . (string) $owner['username'] . '」のパスキー（ID: ' . $id . '）を削除しました',
                'target_type' => 'user',
                'target_id'   => $ownerId,
                'target_name' => (string) $owner['username'],
                'detail'      => ['credential_id' => $id],
            ]);
        }

        if (Csrf::wantsJsonResponse()) {
            json_response(['ok' => true]);
        }

        flash('success', 'パスキーを削除しました。');
        if (Auth::isAdmin() && $ownerId !== $selfId) {
            redirect('/admin/users/' . $ownerId . '/edit');
        }
        redirect('/admin/account');
    }

    private function requireWebAuthn(): void
    {
        if (!WebAuthnService::available()) {
            json_response(['error' => 'パスキー機能は利用できません。'], 503);
        }
    }

    private function publicWebAuthnMessage(\Throwable $e): string
    {
        if ($e instanceof \InvalidArgumentException) {
            return $e->getMessage();
        }
        error_log('[formkun] WebAuthn: ' . $e->getMessage());

        return 'パスキーの処理に失敗しました。もう一度お試しください。';
    }
}
