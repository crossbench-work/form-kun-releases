<?php
namespace Core;

use Models\AppSetting;

/**
 * 受信履歴 purge CLI の実行間隔（app_settings）。OS cron は短い固定間隔で CLI を起動し、ここで実行可否を判定する。
 */
class SubmissionPurgeSchedule
{
    public const MODE_DAILY = 'daily';
    public const MODE_INTERVAL = 'interval';

    public const DEFAULT_ENABLED = true;
    public const DEFAULT_MODE = self::MODE_DAILY;
    public const DEFAULT_DAILY_HOUR = 3;
    public const DEFAULT_DAILY_MINUTE = 0;
    public const DEFAULT_INTERVAL_HOURS = 24;

    public const MIN_DAILY_HOUR = 0;
    public const MAX_DAILY_HOUR = 23;
    public const MIN_DAILY_MINUTE = 0;
    public const MAX_DAILY_MINUTE = 59;
    public const MIN_INTERVAL_HOURS = 1;
    public const MAX_INTERVAL_HOURS = 168;

    /** @return array{enabled: bool, mode: string, daily_hour: int, daily_minute: int, interval_hours: int, last_run_at: ?string} */
    public static function settings(): array
    {
        $enabledRaw = AppSetting::get(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_ENABLED);
        $enabled = $enabledRaw === null
            ? self::DEFAULT_ENABLED
            : ($enabledRaw === '1');

        $mode = AppSetting::get(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_MODE);
        if ($mode !== self::MODE_DAILY && $mode !== self::MODE_INTERVAL) {
            $mode = self::DEFAULT_MODE;
        }

        $dailyHour = self::normalizeDailyHour(AppSetting::get(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_DAILY_HOUR));
        $dailyMinute = self::normalizeDailyMinute(AppSetting::get(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_DAILY_MINUTE));
        $intervalHours = self::normalizeIntervalHours(AppSetting::get(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_INTERVAL_HOURS));

        $lastRunAt = AppSetting::get(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_LAST_RUN_AT);
        $lastRunAt = $lastRunAt !== null && trim($lastRunAt) !== '' ? trim($lastRunAt) : null;

        return [
            'enabled' => $enabled,
            'mode' => $mode,
            'daily_hour' => $dailyHour,
            'daily_minute' => $dailyMinute,
            'interval_hours' => $intervalHours,
            'last_run_at' => $lastRunAt,
        ];
    }

    public static function isEnabled(): bool
    {
        return self::settings()['enabled'];
    }

    public static function isDue(?int $now = null): bool
    {
        $now = $now ?? time();
        $settings = self::settings();
        if (!$settings['enabled']) {
            return false;
        }

        if ($settings['mode'] === self::MODE_INTERVAL) {
            $lastRunAt = $settings['last_run_at'];
            if ($lastRunAt === null) {
                return true;
            }

            $lastTs = strtotime($lastRunAt);
            if ($lastTs === false) {
                return true;
            }

            $intervalSeconds = $settings['interval_hours'] * 3600;

            return ($now - $lastTs) >= $intervalSeconds;
        }

        // 毎日モード: 今日の実行時刻（daily_hour:daily_minute）を過ぎていて、last_run_at がその実行時刻より前なら実行する。
        // 実行時刻の前に手動実行（--force 等）で last_run_at が当日になっていても、実行時刻が来ればその日のスケジュール実行は行われる。
        $todayRunTs = strtotime(
            date('Y-m-d', $now) . ' ' . sprintf('%02d:%02d', $settings['daily_hour'], $settings['daily_minute'])
        );
        if ($todayRunTs === false || $now < $todayRunTs) {
            return false;
        }

        $lastRunAt = $settings['last_run_at'];
        if ($lastRunAt === null) {
            return true;
        }

        $lastTs = strtotime($lastRunAt);
        if ($lastTs === false) {
            return true;
        }

        return $lastTs < $todayRunTs;
    }

    public static function markRun(?int $now = null): void
    {
        $now = $now ?? time();
        AppSetting::set(
            AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_LAST_RUN_AT,
            date('Y-m-d H:i:s', $now)
        );
    }

    public static function normalizeDailyHour(?string $raw): int
    {
        if ($raw === null || trim($raw) === '') {
            return self::DEFAULT_DAILY_HOUR;
        }
        $v = filter_var(trim($raw), FILTER_VALIDATE_INT);
        if ($v === false || $v < self::MIN_DAILY_HOUR || $v > self::MAX_DAILY_HOUR) {
            return self::DEFAULT_DAILY_HOUR;
        }

        return (int) $v;
    }

    public static function normalizeDailyMinute(?string $raw): int
    {
        if ($raw === null || trim($raw) === '') {
            return self::DEFAULT_DAILY_MINUTE;
        }
        $v = filter_var(trim($raw), FILTER_VALIDATE_INT);
        if ($v === false || $v < self::MIN_DAILY_MINUTE || $v > self::MAX_DAILY_MINUTE) {
            return self::DEFAULT_DAILY_MINUTE;
        }

        return (int) $v;
    }

    public static function normalizeIntervalHours(?string $raw): int
    {
        if ($raw === null || trim($raw) === '') {
            return self::DEFAULT_INTERVAL_HOURS;
        }
        $v = filter_var(trim($raw), FILTER_VALIDATE_INT);
        if ($v === false || $v < self::MIN_INTERVAL_HOURS || $v > self::MAX_INTERVAL_HOURS) {
            return self::DEFAULT_INTERVAL_HOURS;
        }

        return (int) $v;
    }

    public static function normalizeMode(?string $raw): string
    {
        $raw = trim((string) $raw);
        if ($raw === self::MODE_INTERVAL) {
            return self::MODE_INTERVAL;
        }

        return self::MODE_DAILY;
    }
}
