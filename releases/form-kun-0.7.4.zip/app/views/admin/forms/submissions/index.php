<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
require_once APP_COMPONENTS_DIR . '/c-halfModal01/c-halfModal01.php';
$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
$bulkFormId = 'submission-bulk-action-form';
$listPath = '/admin/forms/' . (int) $form['id'] . '/submissions';
$listQuery = [];
if ($q !== '') {
    $listQuery['q'] = $q;
}
if ($from !== '') {
    $listQuery['from'] = $from;
}
if ($to !== '') {
    $listQuery['to'] = $to;
}
if (($statusFilter ?? '') !== '') {
    $listQuery['status'] = $statusFilter;
}
if ((int) $page > 1) {
    $listQuery['page'] = (int) $page;
}
$listQuery['per_page'] = (int) ($perPage ?? 20);
$listRedirect = $listPath . ($listQuery !== [] ? '?' . http_build_query($listQuery) : '');
$hasMailOnlyRows = !empty(array_filter($rows ?? [], static fn(array $row): bool => \Models\Submission::isMailOnlyMetadata($row)));
$submissionReadOnly = !empty($submission_read_only);
$submissionsListUrl = base_path('/admin/forms/' . (int) $form['id'] . '/submissions');
$hasSubmissionSearchFilter = $q !== '' || $from !== '' || $to !== '' || ($statusFilter ?? '') !== '';
$exportPeriod = array_filter(['from' => (string) $from, 'to' => (string) $to], static fn(string $v): bool => $v !== '');
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-field">
                                <?php require __DIR__ . '/_retention_notice.php'; ?>
                                <div data-target="submissionsListLive01">
                                <div data-module="m-submissionListToolbar01">
                                    <div data-module="m-toolbar01">
                                        <span data-module="m-text01" data-type="muted"><?= number_format($total) ?>件</span>
                                        <?php $perPageSelectId = 'submissions-list-per-page'; require __DIR__ . '/_per_page_select.php'; ?>
                                        <span class="m-submissionListToolbar01__divider" aria-hidden="true"></span>
                                        <span class="m-submissionListToolbar01__group">
                                            <button type="button"
                                                    class="btn is-icon<?= $hasSubmissionSearchFilter ? ' is-active' : '' ?>"
                                                    data-target="submissions-search-open"
                                                    aria-label="検索"
                                                    title="検索"
                                                    aria-pressed="<?= $hasSubmissionSearchFilter ? 'true' : 'false' ?>">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                                            </button>
                                            <?php if ($hasSubmissionSearchFilter): ?>
                                            <a class="btn is-icon"
                                               href="<?= e($submissionsListUrl) ?>"
                                               aria-label="リセット"
                                               title="リセット">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                                            </a>
                                            <?php endif; ?>
                                        </span>
                                        <?php if (!$submissionReadOnly): ?>
                                        <span class="m-submissionListToolbar01__divider" aria-hidden="true"></span>
                                        <span class="m-submissionListToolbar01__group">
                                            <a class="btn is-iconLabel"
                                               href="<?= e(base_path($listPath . '/export' . ($exportPeriod !== [] ? '?' . http_build_query($exportPeriod) : ''))) ?>"
                                               aria-label="書出し">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
                                                <span>書出し</span>
                                            </a>
                                            <a class="btn is-iconLabel"
                                               href="<?= e(base_path($listPath . '/import')) ?>"
                                               aria-label="読込み">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                                                <span>読込み</span>
                                            </a>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <?php if (empty($rows)): ?>
                                    <p data-module="m-text01" data-type="muted">該当する送信がありません。</p>
                                <?php else: ?>
                                    <?php if (!$submissionReadOnly): ?>
                                    <form method="post"
                                          action="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/submissions/bulk-delete')) ?>"
                                          id="<?= e($bulkFormId) ?>"
                                          data-module="m-submissionBulkAction01"
                                          data-delete-action="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/submissions/bulk-delete')) ?>"
                                          data-export-action="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/submissions/export-csv')) ?>">
                                        <?= \Core\Csrf::field() ?>
                                        <input type="hidden" name="redirect_to" value="<?= e($listRedirect) ?>">
                                        <div data-module="m-toolbar01" data-target="m-submissionBulkAction01__toolbar" hidden>
                                            <span data-module="m-text01" data-type="muted" data-target="m-submissionBulkAction01__count">0件選択中</span>
                                            <?php admin_m_input01_open(); ?>
                                                <select name="bulk_action"
                                                        class="m-inout01__input"
                                                        aria-label="一括操作を選択"
                                                        data-target="m-submissionBulkAction01__action"
                                                        style="width:auto;min-width:150px">
                                                    <option value="">一括操作を選択</option>
                                                    <option value="delete">削除</option>
                                                    <option value="export_csv">CSV書き出し</option>
                                                </select>
                                            <?php admin_m_input01_close(); ?>
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input([
                                                    'type' => 'text',
                                                    'name' => 'export_filename',
                                                    'maxlength' => 100,
                                                    'placeholder' => 'ファイル名（空欄なら 期間_フォーム名）',
                                                    'aria-label' => 'CSV書き出しのファイル名',
                                                    'style' => 'width:280px',
                                                    'data-target' => 'm-submissionBulkAction01__filename',
                                                    'hidden' => true,
                                                ]); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <button class="btn" type="submit" data-target="m-submissionBulkAction01__submit" disabled>実行</button>
                                        </div>
                                    </form>
                                    <?php endif; ?>

                                    <?php admin_m_table01_open('is-submissionList'); ?>
                                        <thead>
                                            <tr>
                                                <?php if (!$submissionReadOnly): ?>
                                                <th class="is-bulk-checkbox">
                                                    <input type="checkbox"
                                                           value="1"
                                                           aria-label="一覧の送信をすべて選択"
                                                           data-target="m-submissionBulkAction01__selectAll"
                                                           data-bulk-form="<?= e($bulkFormId) ?>">
                                                </th>
                                                <?php endif; ?>
                                                <th class="is-submitted-at">受信日時</th>
                                                <th class="is-workflow-status">状態</th>
                                                <?php if ($hasMailOnlyRows): ?>
                                                    <th>保存方式</th>
                                                    <th>SMTP配送</th>
                                                    <th>添付</th>
                                                <?php endif; ?>
                                                <?php foreach ($previewKeys as $key):
                                                    $label = '';
                                                    foreach ($fields as $f) { if ($f['field_key'] === $key) { $label = $f['label']; break; } }
                                                ?>
                                                    <th><?= e($label ?: $key) ?></th>
                                                <?php endforeach; ?>
                                                <th class="is-actions" aria-label="操作"></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($rows as $r):
                                            $workflowStatus = (string) ($r['workflow_status'] ?? \Models\Submission::WORKFLOW_PENDING);
                                        ?>
                                            <tr>
                                                <?php if (!$submissionReadOnly): ?>
                                                <td class="is-bulk-checkbox">
                                                    <input type="checkbox"
                                                           name="submission_ids[]"
                                                           value="<?= e((string) $r['id']) ?>"
                                                           form="<?= e($bulkFormId) ?>"
                                                           aria-label="送信ID <?= e((string) $r['id']) ?> を選択"
                                                           data-target="m-submissionBulkAction01__checkbox"
                                                           data-bulk-form="<?= e($bulkFormId) ?>">
                                                </td>
                                                <?php endif; ?>
                                                <td class="is-submitted-at" data-sp-label="受信日時">
                                                    <?php if (!empty($retentionEnabled) && \Models\Form::isSubmissionExpired($form, (string) $r['submitted_at'], $retentionCutoff)): ?>
                                                        <?php admin_m_warning_mark01($retentionWarningText); ?>
                                                    <?php endif; ?>
                                                    <a href="<?= e(base_path('/admin/forms/submissions/' . $r['id'])) ?>">
                                                        <?= e($r['submitted_at']) ?>
                                                    </a>
                                                </td>
                                                <td class="is-workflow-status" data-sp-label="状態">
                                                    <?php if ($submissionReadOnly): ?>
                                                        <?php admin_m_badge01(\Models\Submission::workflowStatusLabel($workflowStatus), $workflowStatus); ?>
                                                    <?php else: ?>
                                                    <form method="post" action="<?= e(base_path('/admin/forms/submissions/' . $r['id'] . '/status')) ?>" data-module="m-submissionWorkflowStatus01">
                                                        <?= \Core\Csrf::field() ?>
                                                        <select name="status" data-target="m-submissionWorkflowStatus01__select" class="is-<?= e($workflowStatus) ?>" aria-label="状態を変更" onchange="this.form.submit()">
                                                            <?php foreach ($workflowStatusOptions as $statusOpt): ?>
                                                                <option value="<?= e($statusOpt) ?>"<?= $workflowStatus === $statusOpt ? ' selected' : '' ?>>
                                                                    <?= e(\Models\Submission::workflowStatusLabel($statusOpt)) ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </form>
                                                    <?php endif; ?>
                                                </td>
                                                <?php if ($hasMailOnlyRows): ?>
                                                    <?php if (\Models\Submission::isMailOnlyMetadata($r)): ?>
                                                        <td class="is-spField" data-sp-label="保存方式"><span class="is-spFieldValue">SMTPメールのみ</span></td>
                                                        <td class="is-spField" data-sp-label="SMTP配送"><span class="is-spFieldValue"><?= e(\Models\Submission::mailDeliveryStatusLabel((string) ($r['mail_delivery_status'] ?? 'success'))) ?></span></td>
                                                        <td class="is-spField" data-sp-label="添付"><span class="is-spFieldValue"><?= number_format((int) ($r['attachment_count'] ?? 0)) ?>件 / <?= e(\Core\Validator::formatBytes((int) ($r['attachment_total_bytes'] ?? 0))) ?></span></td>
                                                    <?php else: ?>
                                                        <td class="is-spField" data-sp-label="保存方式"><span class="is-spFieldValue">DB保存</span></td><td class="is-spField" data-sp-label="SMTP配送"><span class="is-spFieldValue">—</span></td><td class="is-spField" data-sp-label="添付"><span class="is-spFieldValue">—</span></td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php
                                                    $listPreviewRow = $r;
                                                    require __DIR__ . '/_list_preview_cells.php';
                                                ?>
                                                <td class="is-actions">
                                                    <details class="c-tableActionMenu01">
                                                        <summary class="c-tableActionMenu01__toggle" aria-label="操作">
                                                            <span aria-hidden="true">⋯</span>
                                                        </summary>
                                                        <div class="c-tableActionMenu01__menu" role="menu" aria-label="操作">
                                                            <a role="menuitem" href="<?= e(base_path('/admin/forms/submissions/' . $r['id'])) ?>">詳細</a>
                                                            <?php if (!$submissionReadOnly): ?>
                                                            <form method="post"
                                                                  action="<?= e(base_path('/admin/forms/submissions/' . $r['id'] . '/delete')) ?>"
                                                                  onsubmit="return confirm('この送信を削除しますか？');">
                                                                <?= \Core\Csrf::field() ?>
                                                                <?php admin_m_delete_btn01('admin-submission-delete-' . $r['id'], '削除', '削除', 'submit', '削除'); ?>
                                                            </form>
                                                            <?php endif; ?>
                                                        </div>
                                                    </details>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    <?php admin_m_table01_close(); ?>

                                    <?php if ($totalPages > 1): ?>
                                    <?php admin_c_pagination01_open(); ?>
                                        <?php
                                            $qs = function (int $p) use ($q, $from, $to, $statusFilter) {
                                                $params = ['page' => $p];
                                                if ($q !== '')    $params['q'] = $q;
                                                if ($from !== '') $params['from'] = $from;
                                                if ($to !== '')   $params['to'] = $to;
                                                if (($statusFilter ?? '') !== '') {
                                                    $params['status'] = $statusFilter;
                                                }
                                                return '?' . http_build_query($params);
                                            };
                                            $base = base_path('/admin/forms/' . $form['id'] . '/submissions');
                                        ?>
                                        <?php if ($page > 1): ?>
                                            <a href="<?= e($base . $qs($page - 1)) ?>">‹ 前へ</a>
                                        <?php else: ?>
                                            <span class="disabled">‹ 前へ</span>
                                        <?php endif; ?>

                                        <?php for ($p = max(1, $page - 3); $p <= min($totalPages, $page + 3); $p++): ?>
                                            <?php if ($p === $page): ?>
                                                <span class="current"><?= $p ?></span>
                                            <?php else: ?>
                                                <a href="<?= e($base . $qs($p)) ?>"><?= $p ?></a>
                                            <?php endif; ?>
                                        <?php endfor; ?>

                                        <?php if ($page < $totalPages): ?>
                                            <a href="<?= e($base . $qs($page + 1)) ?>">次へ ›</a>
                                        <?php else: ?>
                                            <span class="disabled">次へ ›</span>
                                        <?php endif; ?>
                                    <?php admin_c_pagination01_close(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                                </div>
                            </div>

<?php admin_c_halfModal01_open(['hidden' => true]); ?>
    <?php admin_c_halfModal01_backdrop('submissions-search-close'); ?>
    <?php admin_c_halfModal01_panel_open('submissions-search-modal-title'); ?>
        <?php admin_c_halfModal01_header_open(); ?>
            <h2 id="submissions-search-modal-title">検索</h2>
            <button type="button" class="btn is-sm" data-target="submissions-search-close">閉じる</button>
        <?php admin_c_halfModal01_header_close(); ?>
        <?php admin_c_halfModal01_body_open(); ?>
            <form method="get" action="<?= e($submissionsListUrl) ?>" id="submissions-search-form">
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('キーワード'), 'submissions-search-q'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-search-q', [
                            'type' => 'text',
                            'id' => 'submissions-search-q',
                            'name' => 'q',
                            'value' => (string) $q,
                            'placeholder' => '送信内容を検索',
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('期間'), 'submissions-from'); ?>
                    <div class="c-halfModal01__dateRange">
                        <?php admin_m_input01_open(); ?>
                            <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-from', [
                                'type' => 'date',
                                'id' => 'submissions-from',
                                'name' => 'from',
                                'value' => (string) $from,
                            ])); ?>
                        <?php admin_m_input01_close(); ?>
                        <span class="c-halfModal01__dateRangeSep" aria-hidden="true">〜</span>
                        <?php admin_m_input01_open(); ?>
                            <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-to', [
                                'type' => 'date',
                                'id' => 'submissions-to',
                                'name' => 'to',
                                'value' => (string) $to,
                            ])); ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                </div>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('状態'), 'submissions-search-status'); ?>
                    <?php admin_m_input01_open(); ?>
                        <select name="status"
                                id="submissions-search-status"
                                class="m-inout01__input"
                                aria-label="状態で絞り込み">
                            <option value="">すべて</option>
                            <?php foreach ($workflowStatusOptions as $statusOpt): ?>
                                <option value="<?= e($statusOpt) ?>"<?= ($statusFilter ?? '') === $statusOpt ? ' selected' : '' ?>>
                                    <?= e(\Models\Submission::workflowStatusLabel($statusOpt)) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    <?php admin_m_input01_close(); ?>
                </div>
                <div class="c-halfModal01__actions is-centered">
                    <a class="btn"
                       href="<?= e($submissionsListUrl) ?>"
                       <?php if (!$hasSubmissionSearchFilter): ?>aria-disabled="true" tabindex="-1"<?php endif; ?>>リセット</a>
                </div>
            </form>
        <?php admin_c_halfModal01_body_close(); ?>
    <?php admin_c_halfModal01_panel_close(); ?>
<?php admin_c_halfModal01_close(); ?>

<?php admin_c_form_block01_close(); ?>
