(function () {
  'use strict';

  function currentBase() {
    return typeof window.FORMKUN_BASE === 'string' ? String(window.FORMKUN_BASE).replace(/\/?$/, '') : '';
  }

  function readJsonAttribute(el, name, fallback) {
    var raw = el.getAttribute(name);
    if (!raw) {
      return fallback;
    }
    try {
      var parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : fallback;
    } catch (e) {
      return fallback;
    }
  }

  var cssEscape = window.CSS && typeof window.CSS.escape === 'function'
    ? window.CSS.escape
    : function (value) { return String(value).replace(/["\\]/g, '\\$&'); };

  function valuesFor(form, name) {
    var values = [];
    form.querySelectorAll('[name="' + cssEscape(name) + '"], [name^="' + cssEscape(name) + '["]').forEach(function (input) {
      if ((input.type === 'checkbox' || input.type === 'radio') && !input.checked) return;
      if (input.disabled) return;
      values.push(String(input.value || '').trim());
    });
    return values;
  }

  function bindBranchRules(form) {
    if (!form || form.getAttribute('data-branch-bound') === '1') {
      return;
    }

    var rules = readJsonAttribute(form, 'data-branch-rules', []);
    if (rules.length === 0) {
      return;
    }

    var controlled = readJsonAttribute(form, 'data-branch-controlled-fields', []);
    var controlledGroups = readJsonAttribute(form, 'data-branch-controlled-groups', []);

    function sync() {
      var visible = {};
      rules.forEach(function (rule) {
        if (valuesFor(form, rule.source_field_key).indexOf(String(rule.expected_value || '').trim()) !== -1) {
          visible[String(rule.target_type || 'field') + ':' + rule.target_key] = true;
        }
      });

      controlledGroups.forEach(function (groupKey) {
        var box = form.querySelector('[data-group-key="' + cssEscape(groupKey) + '"]');
        if (!box) return;
        var show = !!visible['group:' + groupKey];
        box.hidden = !show;
        if ('inert' in HTMLElement.prototype) {
          box.inert = !show;
        }
        box.disabled = !show;
        box.querySelectorAll('input, textarea, select').forEach(function (input) {
          input.disabled = !show;
        });
      });

      controlled.forEach(function (fieldKey) {
        var box = form.querySelector('[data-field-key="' + cssEscape(fieldKey) + '"]');
        if (!box) return;
        var show = !!visible['field:' + fieldKey];
        box.hidden = !show;
        if ('inert' in HTMLElement.prototype) {
          box.inert = !show;
        }
        box.querySelectorAll('input, textarea, select').forEach(function (input) {
          input.disabled = !show;
        });
      });
    }

    form.addEventListener('input', sync);
    form.addEventListener('change', sync);
    form.setAttribute('data-branch-bound', '1');
    sync();
  }

  function init(root) {
    var scope = root && root.querySelectorAll ? root : document;
    if (scope.matches && scope.matches('form[data-module="c-formSet01"]')) {
      bindBranchRules(scope);
    }
    scope.querySelectorAll('form[data-module="c-formSet01"]').forEach(bindBranchRules);
  }

  window.FormKunPublicForm = {
    init: init
  };

  document.addEventListener('click', function (e) {
    var btn = e.target && e.target.closest ? e.target.closest('.js-zip-lookup') : null;
    if (!btn) {
      return;
    }
    var wrap = btn.closest ? btn.closest('[data-form-address]') : null;
    if (!wrap) {
      return;
    }
    e.preventDefault();
    var p1 = wrap.querySelector('.input-postal-part1');
    var p2 = wrap.querySelector('.input-postal-part2');
    var prefSel = wrap.querySelector('.input-prefecture');
    var cityInp = wrap.querySelector('.input-city');
    if (!p1 || !p2 || !prefSel || !cityInp) {
      return;
    }
    var zip = ((p1.value || '') + (p2.value || '')).replace(/\D/g, '');
    if (zip.length !== 7) {
      window.alert('郵便番号は7桁の数字で入力してください。');
      return;
    }
    var url = currentBase() + '/api/postal/lookup?zip=' + encodeURIComponent(zip);
    fetch(url, { credentials: 'same-origin' })
      .then(function (r) {
        if (!r.ok) {
          throw new Error('http');
        }
        return r.json();
      })
      .then(function (data) {
        if (data && data.ok && (data.prefecture || data.city)) {
          if (data.prefecture) {
            prefSel.value = data.prefecture;
          }
          cityInp.value = data.city || '';
        } else {
          window.alert((data && data.message) || '該当する住所が見つかりません。');
        }
      })
      .catch(function () {
        window.alert('住所検索に失敗しました。');
      });
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      init(document);
    });
  } else {
    init(document);
  }
})();
