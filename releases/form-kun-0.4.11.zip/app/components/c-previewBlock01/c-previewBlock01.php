<?php
/**
 * フォーム編集画面の固定プレビュー c-previewBlock01。
 * スタイルは同ディレクトリの _c-previewBlock01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_preview_block01')) {
    function admin_c_preview_block01(string $inputUrl, string $confirmUrl, string $thanksUrl): void
    {
        ?>
        <aside data-module="c-previewBlock01" aria-label="プレビュー画面" hidden
            data-preview-input-url="<?= e($inputUrl) ?>"
            data-preview-confirm-url="<?= e($confirmUrl) ?>"
            data-preview-thanks-url="<?= e($thanksUrl) ?>">
            <div class="wrapper">
                <div class="block is-header">
                    <p class="title">プレビュー</p>
                    <p class="text" data-target="p-formEdit01__previewStatus">読み込み中...</p>
                </div>
                <div class="block is-frame">
                    <div class="preview" data-module="c-formSet01" data-target="p-formEdit01__previewCanvas" role="document" aria-label="フォームプレビュー"></div>
                </div>
            </div>
        </aside>
        <?php
    }
}
