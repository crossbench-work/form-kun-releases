<?php
namespace Models;

use Core\Database;
use Core\FieldKey;

class FormBranchRule
{
    public const ACTION_SHOW_FIELD = 'show_field';
    public const ACTION_GO_TO_SCREEN = 'go_to_screen';
    public const OP_EQUALS = 'equals';
    public const SCREEN_CONFIRM = 'confirm';
    public const SCREEN_THANKS = 'thanks';
    public const TARGET_FIELD = 'field';
    public const TARGET_GROUP = 'group';

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function forForm(int $formId): array
    {
        $rows = Database::fetchAll(
            'SELECT * FROM form_branch_rules WHERE form_id = ? ORDER BY sort_order ASC, id ASC',
            [$formId]
        );
        return self::normalizeRules($rows);
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     */
    public static function replaceForForm(int $formId, array $rules): void
    {
        $rules = self::normalizeRules($rules);
        Database::transaction(function () use ($formId, $rules): void {
            Database::execute('DELETE FROM form_branch_rules WHERE form_id = ?', [$formId]);
            $now = date('Y-m-d H:i:s');
            foreach ($rules as $i => $rule) {
                Database::execute(
                    'INSERT INTO form_branch_rules (
                        form_id, rule_key, sort_order, trigger_page_key, source_field_key, operator,
                        expected_value, action_type, target_type, target_key, enabled, created_at, updated_at
                     ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    [
                        $formId,
                        (string) $rule['rule_key'],
                        $i + 1,
                        (string) $rule['trigger_page_key'],
                        (string) $rule['source_field_key'],
                        (string) $rule['operator'],
                        (string) $rule['expected_value'],
                        (string) $rule['action_type'],
                        (string) $rule['target_type'],
                        (string) $rule['target_key'],
                        !empty($rule['enabled']) ? 1 : 0,
                        $now,
                        $now,
                    ]
                );
            }
        });
    }

    public static function duplicateForForm(int $sourceFormId, int $targetFormId): void
    {
        $rows = Database::fetchAll(
            'SELECT * FROM form_branch_rules WHERE form_id = ? ORDER BY sort_order ASC, id ASC',
            [$sourceFormId]
        );
        $now = date('Y-m-d H:i:s');
        foreach ($rows as $row) {
            Database::execute(
                'INSERT INTO form_branch_rules (
                    form_id, rule_key, sort_order, trigger_page_key, source_field_key, operator,
                    expected_value, action_type, target_type, target_key, enabled, created_at, updated_at
                 ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
                [
                    $targetFormId,
                    (string) ($row['rule_key'] ?? ''),
                    (int) ($row['sort_order'] ?? 0),
                    (string) ($row['trigger_page_key'] ?? FormInputPage::DEFAULT_KEY),
                    (string) ($row['source_field_key'] ?? ''),
                    (string) ($row['operator'] ?? self::OP_EQUALS),
                    (string) ($row['expected_value'] ?? ''),
                    (string) ($row['action_type'] ?? ''),
                    self::sanitizeTargetType((string) ($row['target_type'] ?? self::TARGET_FIELD)),
                    (string) ($row['target_key'] ?? ''),
                    !empty($row['enabled']) ? 1 : 0,
                    $now,
                    $now,
                ]
            );
        }
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, array<string, mixed>>
     */
    public static function normalizeRules(array $rules): array
    {
        $out = [];
        $used = [];
        foreach (array_values($rules) as $i => $rule) {
            if (!is_array($rule)) {
                continue;
            }
            $source = trim((string) ($rule['source_field_key'] ?? ''));
            $target = trim((string) ($rule['target_key'] ?? ''));
            $expected = trim((string) ($rule['expected_value'] ?? ''));
            $triggerPageKey = FormInputPage::sanitizePageKey((string) ($rule['trigger_page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($triggerPageKey === '') {
                $triggerPageKey = FormInputPage::DEFAULT_KEY;
            }
            $actionType = self::sanitizeActionType((string) ($rule['action_type'] ?? ''));
            $targetType = $actionType === self::ACTION_SHOW_FIELD
                ? self::sanitizeTargetType((string) ($rule['target_type'] ?? self::TARGET_FIELD))
                : self::TARGET_FIELD;
            if ($source === '' || $target === '' || $expected === '' || $actionType === '') {
                continue;
            }
            $ruleKey = self::sanitizeRuleKey((string) ($rule['rule_key'] ?? ''));
            if ($ruleKey === '' || isset($used[$ruleKey])) {
                $ruleKey = self::generateRuleKey($used, $i + 1);
            }
            $used[$ruleKey] = true;
            $out[] = [
                'id' => isset($rule['id']) ? (int) $rule['id'] : null,
                'rule_key' => $ruleKey,
                'sort_order' => count($out) + 1,
                'trigger_page_key' => $triggerPageKey,
                'source_field_key' => $source,
                'operator' => self::OP_EQUALS,
                'expected_value' => $expected,
                'action_type' => $actionType,
                'target_type' => $targetType,
                'target_key' => $target,
                'enabled' => !array_key_exists('enabled', $rule) || !empty($rule['enabled']) ? 1 : 0,
            ];
        }
        return $out;
    }

    public static function sanitizeRuleKey(string $key): string
    {
        $key = trim($key);
        return preg_match('/\A[a-zA-Z0-9_\-]{1,64}\z/', $key) ? $key : '';
    }

    public static function sanitizeActionType(string $actionType): string
    {
        return in_array($actionType, [self::ACTION_SHOW_FIELD, self::ACTION_GO_TO_SCREEN], true) ? $actionType : '';
    }

    public static function sanitizeTargetType(string $targetType): string
    {
        return in_array($targetType, [self::TARGET_FIELD, self::TARGET_GROUP], true) ? $targetType : self::TARGET_FIELD;
    }

    /**
     * @param array<string, bool> $used
     */
    private static function generateRuleKey(array $used, int $seed): string
    {
        $n = max(1, $seed);
        do {
            $key = 'branch-' . $n;
            $n++;
        } while (isset($used[$key]));
        return $key;
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @param array<string, mixed> $values
     * @return array{visible_field_keys: array<int, string>, visible_group_keys: array<int, string>, next_screen_key: ?string, matched_rule_keys: array<int, string>}
     */
    public static function evaluate(array $rules, array $values, ?string $triggerPageKey = null): array
    {
        $visibleFieldKeys = [];
        $visibleGroupKeys = [];
        $nextScreenKey = null;
        $matchedRuleKeys = [];

        foreach (self::normalizeRules($rules) as $rule) {
            if (empty($rule['enabled'])) {
                continue;
            }
            if ($triggerPageKey !== null && (string) $rule['trigger_page_key'] !== $triggerPageKey) {
                continue;
            }
            if (!self::matches($rule, $values)) {
                continue;
            }
            $matchedRuleKeys[] = (string) $rule['rule_key'];
            if ($rule['action_type'] === self::ACTION_SHOW_FIELD) {
                if (($rule['target_type'] ?? self::TARGET_FIELD) === self::TARGET_GROUP) {
                    $visibleGroupKeys[] = (string) $rule['target_key'];
                } else {
                    $visibleFieldKeys[] = (string) $rule['target_key'];
                }
                continue;
            }
            if (
                $rule['action_type'] === self::ACTION_GO_TO_SCREEN
                && $nextScreenKey === null
                && ($triggerPageKey === null || (string) $rule['target_key'] !== $triggerPageKey)
            ) {
                $nextScreenKey = (string) $rule['target_key'];
            }
        }

        return [
            'visible_field_keys' => array_values(array_unique($visibleFieldKeys)),
            'visible_group_keys' => array_values(array_unique($visibleGroupKeys)),
            'next_screen_key' => $nextScreenKey,
            'matched_rule_keys' => $matchedRuleKeys,
        ];
    }

    /**
     * @param array<string, mixed> $rule
     * @param array<string, mixed> $values
     */
    public static function matches(array $rule, array $values): bool
    {
        $source = (string) ($rule['source_field_key'] ?? '');
        $expected = trim((string) ($rule['expected_value'] ?? ''));
        $actual = $values[$source] ?? '';
        if (is_array($actual)) {
            $flat = [];
            array_walk_recursive($actual, static function ($value) use (&$flat): void {
                $flat[] = trim((string) $value);
            });
            return in_array($expected, $flat, true);
        }
        return trim((string) $actual) === $expected;
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, string>
     */
    public static function duplicateTargetWarnings(array $rules): array
    {
        $seen = [];
        $warnings = [];
        foreach (self::normalizeRules($rules) as $rule) {
            $key = (string) $rule['trigger_page_key'] . ':' . (string) $rule['action_type'] . ':' . (string) ($rule['target_type'] ?? self::TARGET_FIELD) . ':' . (string) $rule['target_key'];
            if (!isset($seen[$key])) {
                $seen[$key] = 0;
            }
            $seen[$key]++;
        }
        foreach ($seen as $key => $count) {
            if ($count <= 1) {
                continue;
            }
            [, $actionType, $targetType, $targetKey] = explode(':', $key, 4);
            $label = $actionType === self::ACTION_SHOW_FIELD
                ? ($targetType === self::TARGET_GROUP ? 'グループ' : '項目')
                : 'ページ';
            $warnings[] = '分岐処理: 同じ' . $label . '（' . $targetKey . '）が複数のルールで設定されています。';
        }
        return $warnings;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $pages
     * @return array<int, string>
     */
    public static function validateRules(array $rules, array $fields, array $pages, array $groups = []): array
    {
        $errors = [];
        $fieldKeys = [];
        $sourceFieldKeys = [];
        $fieldPageKeys = [];
        foreach ($fields as $field) {
            $fieldKey = (string) ($field['field_key'] ?? '');
            $fieldKeys[] = $fieldKey;
            if (!FormField::isDisplayOnlyType((string) ($field['type'] ?? ''))) {
                $sourceFieldKeys[] = $fieldKey;
            }
            $fieldPageKeys[$fieldKey] = (string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY);
        }
        $groupKeys = [];
        foreach ($groups as $group) {
            $groupKey = (string) ($group['group_key'] ?? '');
            if ($groupKey !== '') {
                $groupKeys[] = $groupKey;
            }
        }
        $screenKeys = [self::SCREEN_CONFIRM, self::SCREEN_THANKS];
        $pageKeys = [];
        foreach ($pages as $page) {
            $pageKey = (string) ($page['page_key'] ?? '');
            $pageKeys[] = $pageKey;
            $screenKeys[] = $pageKey;
        }

        foreach (self::normalizeRules($rules) as $i => $rule) {
            $no = $i + 1;
            $triggerPageKey = (string) $rule['trigger_page_key'];
            if (!in_array($triggerPageKey, $pageKeys, true)) {
                $errors[] = "分岐処理{$no}: 対象ページが存在しません。";
            }
            if (!FieldKey::isValid((string) $rule['source_field_key'])) {
                $errors[] = "分岐処理{$no}: 条件元のフィールドキーが不正です。";
            } elseif (!in_array((string) $rule['source_field_key'], $sourceFieldKeys, true)) {
                $errors[] = "分岐処理{$no}: 条件元の項目が存在しません。";
            } elseif (($fieldPageKeys[(string) $rule['source_field_key']] ?? '') !== $triggerPageKey) {
                $errors[] = "分岐処理{$no}: 条件元の項目は対象ページ内から選択してください。";
            }

            if ($rule['action_type'] === self::ACTION_SHOW_FIELD) {
                if (($rule['target_type'] ?? self::TARGET_FIELD) === self::TARGET_GROUP) {
                    if (!in_array((string) $rule['target_key'], $groupKeys, true)) {
                        $errors[] = "分岐処理{$no}: 表示対象のグループが存在しません。";
                    }
                } elseif (!in_array((string) $rule['target_key'], $fieldKeys, true)) {
                    $errors[] = "分岐処理{$no}: 表示対象の項目が存在しません。";
                }
            } elseif ($rule['action_type'] === self::ACTION_GO_TO_SCREEN) {
                if (!in_array((string) $rule['target_key'], $screenKeys, true)) {
                    $errors[] = "分岐処理{$no}: 遷移先の画面が存在しません。";
                } elseif ((string) $rule['target_key'] === $triggerPageKey) {
                    $errors[] = "分岐処理{$no}: 対象ページ自身へは遷移できません。";
                }
            } else {
                $errors[] = "分岐処理{$no}: アクションが不正です。";
            }
        }

        return $errors;
    }
}
