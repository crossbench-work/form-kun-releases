<?php
namespace Models;

use Core\Database;

class Form
{
    public static function all(): array
    {
        return Database::fetchAll('SELECT * FROM forms ORDER BY id DESC');
    }

    public static function count(): int
    {
        $row = Database::fetchOne('SELECT COUNT(*) AS c FROM forms');
        return (int) ($row['c'] ?? 0);
    }

    public static function find(int $id): ?array
    {
        return Database::fetchOne('SELECT * FROM forms WHERE id = ?', [$id]);
    }

    public static function findBySlug(string $slug): ?array
    {
        return Database::fetchOne('SELECT * FROM forms WHERE slug = ?', [$slug]);
    }

    public static function findActiveBySlug(string $slug): ?array
    {
        return Database::fetchOne(
            "SELECT * FROM forms WHERE slug = ? AND status = 'active'",
            [$slug]
        );
    }

    /**
     * 添付保存用の public_uuid を返す（未設定なら付与して保存）。
     */
    public static function requirePublicUuid(array $form): string
    {
        $uuid = trim((string) ($form['public_uuid'] ?? ''));
        if ($uuid !== '' && is_uuid_v4($uuid)) {
            return strtolower($uuid);
        }

        $uuid = \uuid_v4();
        Database::execute(
            'UPDATE forms SET public_uuid = ? WHERE id = ?',
            [$uuid, (int) $form['id']]
        );
        return $uuid;
    }

    /**
     * 公開状態（DB 値）を管理画面表示用ラベルへ（フォーム編集の「公開状態」プルダウンと同じ文言）。
     */
    public static function statusLabel(string $status): string
    {
        return match ($status) {
            'draft' => '下書き',
            'active' => '公開中',
            'archived' => '停止',
            default => $status,
        };
    }

    public static function create(array $data): int
    {
        $now = date('Y-m-d H:i:s');
        Database::execute(
            'INSERT INTO forms (
                slug, public_uuid, title, meta_html, custom_css, custom_js, header_html, footer_html, input_page_title, show_input_page_title, description, show_title, show_description, confirm_page_title, show_confirm_page_title, confirm_button_text, submit_button_text, back_button_text, confirm_message, thanks_page_title, show_thanks_page_title, thanks_message, thanks_button_text, thanks_button_url,
                admin_emails, mail_subject_admin, mail_template_admin,
                mail_transport, mail_from_email, mail_from_name, mail_smtp_host, mail_smtp_port, mail_smtp_secure, mail_smtp_username, mail_smtp_password, mail_smtp_timeout, mail_smtp_ehlo_host, mail_smtp_verify_peer, mail_smtp_verify_peer_name, mail_smtp_allow_self_signed,
                reply_enabled, reply_from_field_key, reply_subject, reply_template,
                status, created_at, updated_at
            ) VALUES (
                ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,
                ?,?,?,
                ?,?,?,?,?,?,?,?,?,?,?,?,?,
                ?,?,?,?,
                ?,?,?
            )',
            [
                $data['slug'],
                $data['public_uuid'] ?? \uuid_v4(),
                $data['title'],
                $data['meta_html'] ?? null,
                $data['custom_css'] ?? null,
                $data['custom_js'] ?? null,
                $data['header_html'] ?? null,
                $data['footer_html'] ?? null,
                $data['input_page_title'] ?? null,
                !empty($data['show_input_page_title']) ? 1 : 0,
                $data['description'] ?? null,
                !empty($data['show_title']) ? 1 : 0,
                !empty($data['show_description']) ? 1 : 0,
                $data['confirm_page_title'] ?? null,
                !empty($data['show_confirm_page_title']) ? 1 : 0,
                $data['confirm_button_text'] ?? null,
                $data['submit_button_text'] ?? null,
                $data['back_button_text'] ?? null,
                $data['confirm_message'] ?? null,
                $data['thanks_page_title'] ?? null,
                !empty($data['show_thanks_page_title']) ? 1 : 0,
                $data['thanks_message'] ?? null,
                $data['thanks_button_text'] ?? null,
                $data['thanks_button_url'] ?? null,
                $data['admin_emails'] ?? null,
                $data['mail_subject_admin'] ?? null,
                $data['mail_template_admin'] ?? null,
                $data['mail_transport'] ?? null,
                $data['mail_from_email'] ?? null,
                $data['mail_from_name'] ?? null,
                $data['mail_smtp_host'] ?? null,
                $data['mail_smtp_port'] ?? null,
                $data['mail_smtp_secure'] ?? null,
                $data['mail_smtp_username'] ?? null,
                $data['mail_smtp_password'] ?? null,
                $data['mail_smtp_timeout'] ?? null,
                $data['mail_smtp_ehlo_host'] ?? null,
                !empty($data['mail_smtp_verify_peer']) ? 1 : 0,
                !empty($data['mail_smtp_verify_peer_name']) ? 1 : 0,
                !empty($data['mail_smtp_allow_self_signed']) ? 1 : 0,
                !empty($data['reply_enabled']) ? 1 : 0,
                $data['reply_from_field_key'] ?? null,
                $data['reply_subject'] ?? null,
                $data['reply_template'] ?? null,
                $data['status'] ?? 'draft',
                $now,
                $now,
            ]
        );
        return Database::lastInsertId();
    }

    public static function update(int $id, array $data): void
    {
        $now = date('Y-m-d H:i:s');
        Database::execute(
            'UPDATE forms SET
                slug = ?, title = ?, meta_html = ?, custom_css = ?, custom_js = ?, header_html = ?, footer_html = ?, input_page_title = ?, show_input_page_title = ?, description = ?, show_title = ?, show_description = ?, confirm_page_title = ?, show_confirm_page_title = ?, confirm_button_text = ?, submit_button_text = ?, back_button_text = ?, confirm_message = ?, thanks_page_title = ?, show_thanks_page_title = ?, thanks_message = ?, thanks_button_text = ?, thanks_button_url = ?,
                admin_emails = ?, mail_subject_admin = ?, mail_template_admin = ?,
                mail_transport = ?, mail_from_email = ?, mail_from_name = ?, mail_smtp_host = ?, mail_smtp_port = ?, mail_smtp_secure = ?, mail_smtp_username = ?, mail_smtp_password = ?, mail_smtp_timeout = ?, mail_smtp_ehlo_host = ?, mail_smtp_verify_peer = ?, mail_smtp_verify_peer_name = ?, mail_smtp_allow_self_signed = ?,
                reply_enabled = ?, reply_from_field_key = ?, reply_subject = ?, reply_template = ?,
                status = ?, updated_at = ?
              WHERE id = ?',
            [
                $data['slug'],
                $data['title'],
                $data['meta_html'] ?? null,
                $data['custom_css'] ?? null,
                $data['custom_js'] ?? null,
                $data['header_html'] ?? null,
                $data['footer_html'] ?? null,
                $data['input_page_title'] ?? null,
                !empty($data['show_input_page_title']) ? 1 : 0,
                $data['description'] ?? null,
                !empty($data['show_title']) ? 1 : 0,
                !empty($data['show_description']) ? 1 : 0,
                $data['confirm_page_title'] ?? null,
                !empty($data['show_confirm_page_title']) ? 1 : 0,
                $data['confirm_button_text'] ?? null,
                $data['submit_button_text'] ?? null,
                $data['back_button_text'] ?? null,
                $data['confirm_message'] ?? null,
                $data['thanks_page_title'] ?? null,
                !empty($data['show_thanks_page_title']) ? 1 : 0,
                $data['thanks_message'] ?? null,
                $data['thanks_button_text'] ?? null,
                $data['thanks_button_url'] ?? null,
                $data['admin_emails'] ?? null,
                $data['mail_subject_admin'] ?? null,
                $data['mail_template_admin'] ?? null,
                $data['mail_transport'] ?? null,
                $data['mail_from_email'] ?? null,
                $data['mail_from_name'] ?? null,
                $data['mail_smtp_host'] ?? null,
                $data['mail_smtp_port'] ?? null,
                $data['mail_smtp_secure'] ?? null,
                $data['mail_smtp_username'] ?? null,
                $data['mail_smtp_password'] ?? null,
                $data['mail_smtp_timeout'] ?? null,
                $data['mail_smtp_ehlo_host'] ?? null,
                !empty($data['mail_smtp_verify_peer']) ? 1 : 0,
                !empty($data['mail_smtp_verify_peer_name']) ? 1 : 0,
                !empty($data['mail_smtp_allow_self_signed']) ? 1 : 0,
                !empty($data['reply_enabled']) ? 1 : 0,
                $data['reply_from_field_key'] ?? null,
                $data['reply_subject'] ?? null,
                $data['reply_template'] ?? null,
                $data['status'] ?? 'draft',
                $now,
                $id,
            ]
        );
    }

    public static function duplicate(int $id): int
    {
        return Database::transaction(function () use ($id): int {
            $source = self::find($id);
            if ($source === null) {
                throw new \RuntimeException('複製元のフォームが見つかりません。');
            }

            $copy = $source;
            $copy['slug'] = self::generateCopySlug((string) ($source['slug'] ?? 'form'));
            $copy['public_uuid'] = \uuid_v4();
            $copy['title'] = mb_substr(trim((string) ($source['title'] ?? 'フォーム')) . ' のコピー', 0, 200);
            $copy['status'] = 'draft';

            $newId = self::create($copy);
            FormInputPage::duplicateForForm($id, $newId);
            FormFieldGroup::duplicateForForm($id, $newId);
            FormField::duplicateForForm($id, $newId);
            FormBranchRule::duplicateForForm($id, $newId);

            return $newId;
        });
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM forms WHERE id = ?', [$id]);
    }

    public static function isSlugAvailable(string $slug, ?int $excludeId = null): bool
    {
        if ($excludeId === null) {
            $row = Database::fetchOne('SELECT id FROM forms WHERE slug = ?', [$slug]);
        } else {
            $row = Database::fetchOne('SELECT id FROM forms WHERE slug = ? AND id <> ?', [$slug, $excludeId]);
        }
        return $row === null;
    }

    private static function generateCopySlug(string $sourceSlug): string
    {
        $base = preg_replace('/[^a-zA-Z0-9_-]+/', '-', trim($sourceSlug)) ?: 'form';
        $base = trim($base, '-_');
        if ($base === '') {
            $base = 'form';
        }

        for ($i = 1; $i <= 999; $i++) {
            $suffix = $i === 1 ? '-copy' : '-copy-' . $i;
            $candidate = mb_substr($base, 0, 64 - strlen($suffix)) . $suffix;
            if (self::isSlugAvailable($candidate)) {
                return $candidate;
            }
        }

        return \uuid_v4();
    }
}
