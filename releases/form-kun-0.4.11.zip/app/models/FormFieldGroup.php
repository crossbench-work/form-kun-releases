<?php
namespace Models;

use Core\Database;

class FormFieldGroup
{
    public static function sanitizeGroupKey(string $key): string
    {
        $key = trim($key);
        return preg_match('/\A[a-zA-Z0-9_\-]{1,64}\z/', $key) ? $key : '';
    }

    public static function forForm(int $formId, bool $includeHidden = false): array
    {
        $groups = Database::fetchAll(
            'SELECT * FROM form_field_groups WHERE form_id = ? ORDER BY input_page_key ASC, parent_group_key ASC, sort_order ASC, id ASC',
            [$formId]
        );

        return array_values(array_filter(array_map([self::class, 'normalizeGroup'], $groups), static function ($group) use ($includeHidden): bool {
            return is_array($group) && ($includeHidden || !empty($group['visible']));
        }));
    }

    /**
     * @param array<int, array<string, mixed>> $groups
     * @return array<int, array<string, mixed>>
     */
    public static function forInputPage(array $groups, string $pageKey): array
    {
        return array_values(array_filter($groups, static function ($group) use ($pageKey): bool {
            return (string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY) === $pageKey;
        }));
    }

    /**
     * @param array<int, array<string, mixed>> $groups
     */
    public static function replaceForForm(int $formId, array $groups): void
    {
        Database::transaction(function () use ($formId, $groups): void {
            Database::execute('DELETE FROM form_field_groups WHERE form_id = ?', [$formId]);
            $now = date('Y-m-d H:i:s');
            foreach (array_values($groups) as $i => $group) {
                $groupKey = self::sanitizeGroupKey((string) ($group['group_key'] ?? ''));
                if ($groupKey === '') {
                    continue;
                }
                $parentGroupKey = self::sanitizeGroupKey((string) ($group['parent_group_key'] ?? ''));
                if ($parentGroupKey === '' || $parentGroupKey === $groupKey) {
                    $parentGroupKey = null;
                }
                Database::execute(
                    'INSERT INTO form_field_groups (
                        form_id, input_page_key, parent_group_key, sort_order, group_key,
                        label, show_label, description, visible, created_at, updated_at
                     ) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                    [
                        $formId,
                        FormField::sanitizeInputPageKey((string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY)),
                        $parentGroupKey,
                        isset($group['sort_order']) && is_numeric($group['sort_order']) ? (int) $group['sort_order'] : $i + 1,
                        $groupKey,
                        trim((string) ($group['label'] ?? '')),
                        !array_key_exists('show_label', $group) || !empty($group['show_label']) ? 1 : 0,
                        trim((string) ($group['description'] ?? '')) !== '' ? trim((string) $group['description']) : null,
                        !array_key_exists('visible', $group) || !empty($group['visible']) ? 1 : 0,
                        $now,
                        $now,
                    ]
                );
            }
        });
    }

    public static function duplicateForForm(int $sourceFormId, int $targetFormId): void
    {
        $rows = Database::fetchAll(
            'SELECT * FROM form_field_groups WHERE form_id = ? ORDER BY input_page_key ASC, parent_group_key ASC, sort_order ASC, id ASC',
            [$sourceFormId]
        );
        $now = date('Y-m-d H:i:s');
        foreach ($rows as $row) {
            Database::execute(
                'INSERT INTO form_field_groups (
                    form_id, input_page_key, parent_group_key, sort_order, group_key,
                    label, show_label, description, visible, created_at, updated_at
                 ) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                [
                    $targetFormId,
                    FormField::sanitizeInputPageKey((string) ($row['input_page_key'] ?? FormInputPage::DEFAULT_KEY)),
                    self::sanitizeGroupKey((string) ($row['parent_group_key'] ?? '')) ?: null,
                    (int) ($row['sort_order'] ?? 0),
                    self::sanitizeGroupKey((string) ($row['group_key'] ?? '')),
                    (string) ($row['label'] ?? ''),
                    !array_key_exists('show_label', $row) || !empty($row['show_label']) ? 1 : 0,
                    $row['description'] ?? null,
                    !empty($row['visible']) ? 1 : 0,
                    $now,
                    $now,
                ]
            );
        }
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $groups
     * @return array<int, array{kind:string,item:array<string,mixed>}>
     */
    public static function childrenForParent(array $fields, array $groups, string $pageKey, ?string $parentGroupKey = null): array
    {
        $parentGroupKey = self::sanitizeGroupKey((string) $parentGroupKey) ?: null;
        $children = [];
        foreach ($groups as $group) {
            $groupParent = self::sanitizeGroupKey((string) ($group['parent_group_key'] ?? '')) ?: null;
            if ((string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY) === $pageKey && $groupParent === $parentGroupKey) {
                $children[] = ['kind' => 'group', 'item' => $group];
            }
        }
        foreach ($fields as $field) {
            $fieldParent = self::sanitizeGroupKey((string) ($field['parent_group_key'] ?? '')) ?: null;
            if ((string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY) === $pageKey && $fieldParent === $parentGroupKey) {
                $children[] = ['kind' => 'field', 'item' => $field];
            }
        }
        usort($children, static function (array $a, array $b): int {
            $ao = (int) ($a['item']['sort_order'] ?? 0);
            $bo = (int) ($b['item']['sort_order'] ?? 0);
            if ($ao === $bo) {
                return ($a['kind'] <=> $b['kind']);
            }
            return $ao <=> $bo;
        });

        return $children;
    }

    /**
     * @param array<string, mixed> $group
     * @return array<string, mixed>
     */
    public static function normalizeGroup(array $group): array
    {
        $group['input_page_key'] = FormField::sanitizeInputPageKey((string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
        $group['group_key'] = self::sanitizeGroupKey((string) ($group['group_key'] ?? ''));
        $parentGroupKey = self::sanitizeGroupKey((string) ($group['parent_group_key'] ?? ''));
        $group['parent_group_key'] = $parentGroupKey !== '' ? $parentGroupKey : null;
        $group['visible'] = !array_key_exists('visible', $group) || !empty($group['visible']) ? 1 : 0;
        $group['show_label'] = !array_key_exists('show_label', $group) || !empty($group['show_label']) ? 1 : 0;
        $group['description'] = (string) ($group['description'] ?? '');
        return $group;
    }
}
