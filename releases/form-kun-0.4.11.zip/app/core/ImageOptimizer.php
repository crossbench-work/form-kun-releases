<?php
namespace Core;

/**
 * アップロード画像のリサイズ・再圧縮（GD）。WebP は元より小さい場合のみ採用。
 */
class ImageOptimizer
{
  private const SUPPORTED_MIMES = [
    'image/jpeg' => 'jpeg',
    'image/png'  => 'png',
    'image/webp' => 'webp',
  ];

  public static function isAvailable(): bool
  {
    return extension_loaded('gd');
  }

  public static function canOptimizeMime(string $mime): bool
  {
    return isset(self::SUPPORTED_MIMES[strtolower($mime)]);
  }

  /**
   * @param array<string, mixed> $config upload.image 設定
   * @return array{mime_type:string, size:int, stored_ext:string}|null 最適化しない場合は null
   */
  public static function optimize(string $sourcePath, string $destBasePath, array $config): ?array
  {
    if (empty($config['enabled']) || !self::isAvailable() || !is_file($sourcePath)) {
      return null;
    }

    $mime = self::detectMime($sourcePath);
    if ($mime === null || !self::canOptimizeMime($mime)) {
      return null;
    }

    $maxW = max(1, (int) ($config['max_width'] ?? 1280));
    $maxH = max(1, (int) ($config['max_height'] ?? 1280));
    $jpegQ = max(1, min(100, (int) ($config['jpeg_quality'] ?? 82)));
    $webpQ = max(1, min(100, (int) ($config['webp_quality'] ?? 80)));
    $pngLevel = max(0, min(9, (int) ($config['png_compression'] ?? 6)));
    $tryWebp = !empty($config['try_webp']) && function_exists('imagewebp');

    $image = self::loadImage($sourcePath, $mime);
    if ($image === null) {
      return null;
    }

    try {
      if ($mime === 'image/jpeg') {
        $image = self::applyExifOrientation($sourcePath, $image) ?? $image;
      }

      [$image, $resized] = self::resizeDown($image, $maxW, $maxH);
      $originalSize = filesize($sourcePath) ?: PHP_INT_MAX;
      $candidates = [];

      $format = self::SUPPORTED_MIMES[$mime];
      $nativePath = $destBasePath . '.opt.' . $format;
      if (self::saveFormat($image, $format, $nativePath, $jpegQ, $pngLevel, $webpQ)) {
        $candidates[] = [
          'path' => $nativePath,
          'mime' => $mime,
          'ext'  => self::extForFormat($format),
        ];
      }

      if ($tryWebp) {
        $webpPath = $destBasePath . '.opt.webp';
        if (self::saveFormat($image, 'webp', $webpPath, $jpegQ, $pngLevel, $webpQ)) {
          $candidates[] = [
            'path' => $webpPath,
            'mime' => 'image/webp',
            'ext'  => '.webp',
          ];
        }
      }

      $best = null;
      $bestSize = PHP_INT_MAX;
      foreach ($candidates as $c) {
        if (!is_file($c['path'])) {
          continue;
        }
        $size = filesize($c['path']) ?: PHP_INT_MAX;
        if ($size < $bestSize) {
          $bestSize = $size;
          $best = $c;
        }
      }

      foreach ($candidates as $c) {
        if ($best === null || $c['path'] !== $best['path']) {
          @unlink($c['path']);
        }
      }

      imagedestroy($image);

      if ($best === null) {
        return null;
      }

      if (!$resized && $bestSize >= $originalSize) {
        @unlink($best['path']);
        return null;
      }

      return [
        'mime_type'   => $best['mime'],
        'size'        => $bestSize,
        'stored_ext'  => $best['ext'],
        'output_path' => $best['path'],
      ];
    } catch (\Throwable $e) {
      if (is_resource($image) || $image instanceof \GdImage) {
        imagedestroy($image);
      }
      error_log('[formkun] ImageOptimizer: ' . $e->getMessage());
      return null;
    }
  }

  private static function detectMime(string $path): ?string
  {
    if (!function_exists('finfo_open')) {
      return null;
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo === false) {
      return null;
    }
    $mime = finfo_file($finfo, $path);
    finfo_close($finfo);
    if ($mime === false || $mime === '') {
      return null;
    }
    return strtolower((string) $mime);
  }

  /** @return \GdImage|resource|null */
  private static function loadImage(string $path, string $mime)
  {
    return match ($mime) {
      'image/jpeg' => @imagecreatefromjpeg($path) ?: null,
      'image/png'  => @imagecreatefrompng($path) ?: null,
      'image/webp' => function_exists('imagecreatefromwebp') ? (@imagecreatefromwebp($path) ?: null) : null,
      default      => null,
    };
  }

  /** @param \GdImage|resource $image */
  private static function applyExifOrientation(string $path, $image)
  {
    if (!function_exists('exif_read_data')) {
      return $image;
    }
    $exif = @exif_read_data($path);
    if (!is_array($exif) || !isset($exif['Orientation'])) {
      return $image;
    }
    return match ((int) $exif['Orientation']) {
      2 => self::flipHorizontal($image),
      3 => imagerotate($image, 180, 0) ?: $image,
      4 => self::flipVertical($image),
      5 => self::rotateAndFlip($image, 270, true),
      6 => imagerotate($image, -90, 0) ?: $image,
      7 => self::rotateAndFlip($image, 90, true),
      8 => imagerotate($image, 90, 0) ?: $image,
      default => $image,
    };
  }

  /** @param \GdImage|resource $image */
  private static function flipHorizontal($image)
  {
    if (function_exists('imageflip')) {
      imageflip($image, IMG_FLIP_HORIZONTAL);
      return $image;
    }
    return $image;
  }

  /** @param \GdImage|resource $image */
  private static function flipVertical($image)
  {
    if (function_exists('imageflip')) {
      imageflip($image, IMG_FLIP_VERTICAL);
      return $image;
    }
    return $image;
  }

  /** @param \GdImage|resource $image */
  private static function rotateAndFlip($image, int $angle, bool $flipH)
  {
    $rotated = imagerotate($image, $angle, 0);
    if ($rotated === false) {
      return $image;
    }
    imagedestroy($image);
    if ($flipH) {
      return self::flipHorizontal($rotated);
    }
    return $rotated;
  }

  /**
   * @param \GdImage|resource $image
   * @return array{0:\GdImage|resource,1:bool}
   */
  private static function resizeDown($image, int $maxW, int $maxH): array
  {
    $w = imagesx($image);
    $h = imagesy($image);
    if ($w <= 0 || $h <= 0) {
      return [$image, false];
    }
    $scale = min($maxW / $w, $maxH / $h, 1.0);
    if ($scale >= 1.0) {
      return [$image, false];
    }
    $nw = max(1, (int) round($w * $scale));
    $nh = max(1, (int) round($h * $scale));
    $resized = imagecreatetruecolor($nw, $nh);
    if ($resized === false) {
      return [$image, false];
    }
    imagealphablending($resized, false);
    imagesavealpha($resized, true);
    $transparent = imagecolorallocatealpha($resized, 0, 0, 0, 127);
    if ($transparent !== false) {
      imagefill($resized, 0, 0, $transparent);
    }
    imagecopyresampled($resized, $image, 0, 0, 0, 0, $nw, $nh, $w, $h);
    imagedestroy($image);
    return [$resized, true];
  }

  private static function saveFormat($image, string $format, string $path, int $jpegQ, int $pngLevel, int $webpQ): bool
  {
    if ($format === 'png') {
      imagesavealpha($image, true);
    }
    $ok = match ($format) {
      'jpeg' => imagejpeg($image, $path, $jpegQ),
      'png'  => imagepng($image, $path, $pngLevel),
      'webp' => function_exists('imagewebp') ? imagewebp($image, $path, $webpQ) : false,
      default => false,
    };
    if ($ok) {
      @chmod($path, 0644);
    }
    return (bool) $ok;
  }

  private static function extForFormat(string $format): string
  {
    return match ($format) {
      'jpeg' => '.jpg',
      'png'  => '.png',
      'webp' => '.webp',
      default => '.bin',
    };
  }
}
