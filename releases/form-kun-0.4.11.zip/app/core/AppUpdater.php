<?php
namespace Core;

/**
 * manifest / 手動 ZIP からアプリ本体を更新（共有レンタル向け）。
 */
class AppUpdater
{
    private const LOG_FILE = 'update.log';

    public static function isEnabled(): bool
    {
        return effective_update_enabled();
    }

    public static function currentVersion(): string
    {
        $file = APP_DIR . '/version.php';
        if (is_file($file)) {
            $v = require $file;
            if (is_string($v) && $v !== '') {
                return $v;
            }
        }
        return '0.0.0';
    }

    /**
     * @return array{ok:bool,message:string,manifest?:array}
     */
    public static function fetchManifest(): array
    {
        if (!self::isEnabled()) {
            return ['ok' => false, 'message' => '更新機能が無効です。'];
        }
        $url = effective_update_manifest_url();
        if ($url === '') {
            return ['ok' => false, 'message' => 'manifest_url が未設定です。'];
        }
        try {
            self::assertAllowedUrl($url);
            $body = self::httpGet($url);
            $data = json_decode($body, true);
            if (!is_array($data) || empty($data['releases']) || !is_array($data['releases'])) {
                return ['ok' => false, 'message' => 'manifest の形式が不正です。'];
            }
            return ['ok' => true, 'message' => '', 'manifest' => $data];
        } catch (\Throwable $e) {
            self::log('manifest error: ' . $e->getMessage());
            return ['ok' => false, 'message' => 'manifest の取得に失敗しました。'];
        }
    }

    /**
     * @return array{ok:bool,message:string}
     */
    public static function applyRelease(string $version): array
    {
        if (!self::isEnabled()) {
            return ['ok' => false, 'message' => '更新機能が無効です。'];
        }
        if (!class_exists(\ZipArchive::class)) {
            return ['ok' => false, 'message' => 'ZipArchive 拡張が必要です。'];
        }

        $manifestResult = self::fetchManifest();
        if (!$manifestResult['ok']) {
            return ['ok' => false, 'message' => $manifestResult['message']];
        }
        $manifest = $manifestResult['manifest'];
        $release = null;
        foreach ($manifest['releases'] as $row) {
            if (is_array($row) && ($row['version'] ?? '') === $version) {
                $release = $row;
                break;
            }
        }
        if ($release === null) {
            return ['ok' => false, 'message' => '指定バージョンが manifest にありません。'];
        }

        $zipUrl = (string) ($release['zip_url'] ?? '');
        $expectedSha = strtolower((string) ($release['sha256'] ?? ''));
        if ($zipUrl === '' || $expectedSha === '') {
            return ['ok' => false, 'message' => 'リリース情報が不足しています。'];
        }

        self::acquireMaintenanceLock();
        $tmpZip = null;
        try {
            @set_time_limit(300);
            self::assertAllowedUrl($zipUrl);
            $tmpZip = self::downloadToTemp($zipUrl);
            $actualSha = hash_file('sha256', $tmpZip);
            if (!hash_equals($expectedSha, strtolower($actualSha))) {
                return ['ok' => false, 'message' => 'ZIP の sha256 が一致しません。'];
            }

            return self::applyFromZipFile($tmpZip, $version, basename(parse_url($zipUrl, PHP_URL_PATH) ?: 'release.zip'));
        } catch (\Throwable $e) {
            self::log('apply error: ' . $e->getMessage());
            return ['ok' => false, 'message' => '更新中にエラーが発生しました。'];
        } finally {
            if ($tmpZip !== null && is_file($tmpZip)) {
                @unlink($tmpZip);
            }
            self::releaseMaintenanceLock();
        }
    }

    /**
     * 管理者による手動 ZIP アップロード（update.enabled 不要）。
     *
     * @param array<string, mixed> $file $_FILES['update_zip']
     * @return array{ok:bool,message:string}
     */
    public static function applyUploadedZip(?array $file, string $versionHint = ''): array
    {
        if (!class_exists(\ZipArchive::class)) {
            return ['ok' => false, 'message' => 'ZipArchive 拡張が必要です。'];
        }

        $validation = self::validateUploadedZipFile($file);
        if ($validation !== null) {
            return ['ok' => false, 'message' => $validation];
        }

        $originalName = (string) ($file['name'] ?? 'upload.zip');
        $tmpBase = tempnam(sys_get_temp_dir(), 'formkun-upload-');
        if ($tmpBase === false) {
            return ['ok' => false, 'message' => '一時ファイルを作成できませんでした。'];
        }
        $tmpZip = $tmpBase . '.zip';
        @unlink($tmpBase);
        if (!move_uploaded_file((string) $file['tmp_name'], $tmpZip)) {
            return ['ok' => false, 'message' => 'アップロードファイルの保存に失敗しました。'];
        }

        self::acquireMaintenanceLock();
        try {
            @set_time_limit(300);
            return self::applyFromZipFile($tmpZip, $versionHint, $originalName);
        } catch (\Throwable $e) {
            self::log('manual upload error: ' . $e->getMessage());
            $msg = $e->getMessage();
            if ($msg === '' || str_contains($msg, 'RuntimeException')) {
                return ['ok' => false, 'message' => '更新中にエラーが発生しました。'];
            }
            return ['ok' => false, 'message' => $msg];
        } finally {
            if (is_file($tmpZip)) {
                @unlink($tmpZip);
            }
            self::releaseMaintenanceLock();
        }
    }

    /**
     * ZIP を staging に展開し PUBLIC_DIR へ反映する（ロックは呼び出し側が取得済みであること）。
     *
     * @return array{ok:bool,message:string}
     */
    public static function applyFromZipFile(string $zipPath, string $versionHint, string $zipBasename): array
    {
        if (!is_file($zipPath)) {
            return ['ok' => false, 'message' => 'ZIP ファイルが見つかりません。'];
        }

        $staging = PUBLIC_DIR . '/.update-staging-' . bin2hex(random_bytes(8));
        if (is_dir($staging)) {
            self::removeDirectory($staging);
        }
        mkdir($staging, 0755, true);

        try {
            $zip = new \ZipArchive();
            if ($zip->open($zipPath) !== true) {
                return ['ok' => false, 'message' => 'ZIP を開けませんでした。'];
            }
            try {
                self::safeExtractZip($zip, $staging);
            } finally {
                $zip->close();
            }

            $root = self::detectZipRoot($staging);
            if (!is_file($root . '/index.php') && !is_file($root . '/app/bootstrap.php')) {
                return ['ok' => false, 'message' => 'ZIP の構成が不正です（index.php または app/bootstrap.php がありません）。'];
            }

            $version = self::resolveVersion($versionHint, $zipBasename, $root);
            if ($version === '') {
                return ['ok' => false, 'message' => 'バージョンを特定できません。版を入力するか、form-kun-x.y.z.zip 形式のファイル名にしてください。'];
            }

            self::copyTree($root, PUBLIC_DIR, self::protectedPatterns());
            self::writeVersionFile($version);

            self::log('applied ' . $version . ' from zip ' . $zipBasename);
            return ['ok' => true, 'message' => 'バージョン ' . $version . ' へ更新しました。'];
        } catch (\Throwable $e) {
            self::log('applyFromZipFile: ' . $e->getMessage());
            $msg = trim($e->getMessage());
            if ($msg === '') {
                return ['ok' => false, 'message' => '更新中にエラーが発生しました。'];
            }
            return ['ok' => false, 'message' => $msg];
        } finally {
            self::removeDirectory($staging);
        }
    }

    public static function requirements(): array
    {
        return [
            'zip' => class_exists(\ZipArchive::class),
            'enabled' => self::isEnabled(),
            'manifest_url' => effective_update_manifest_url() !== '',
        ];
    }

    public static function manualUploadMaxBytes(): int
    {
        $n = (int) config('update.manual_upload_max_bytes', 64 * 1024 * 1024);
        return $n > 0 ? $n : 64 * 1024 * 1024;
    }

    public static function isMaintenanceActive(): bool
    {
        return is_file(self::lockPath());
    }

    public static function maintenanceBlocksRequest(): bool
    {
        if (!self::isMaintenanceActive()) {
            return false;
        }
        $uri = (string) ($_SERVER['REQUEST_URI'] ?? '');
        if (strpos($uri, '/admin/settings/update') !== false) {
            return false;
        }
        return true;
    }

    /**
     * @param array<string, mixed>|null $file $_FILES['update_zip'] 相当
     */
    public static function validateUploadedZipFile(?array $file): ?string
    {
        if ($file === null || $file === []) {
            $postMax = self::parseIniBytes((string) ini_get('post_max_size'));
            $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
            if ($postMax > 0 && $contentLength > $postMax) {
                return 'アップロードデータが PHP の post_max_size（' . self::formatBytes($postMax) . '）を超えています。';
            }
            return 'ZIP ファイルを選択してください。';
        }

        $err = (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_NO_FILE) {
            $postMax = self::parseIniBytes((string) ini_get('post_max_size'));
            $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
            if ($postMax > 0 && $contentLength > $postMax) {
                return 'アップロードデータが PHP の post_max_size（' . self::formatBytes($postMax) . '）を超えています。';
            }
            return 'ZIP ファイルを選択してください。';
        }
        if ($err === UPLOAD_ERR_INI_SIZE) {
            $iniMax = self::parseIniBytes((string) ini_get('upload_max_filesize'));
            return 'ZIP が PHP の upload_max_filesize（' . self::formatBytes($iniMax) . '）を超えています。';
        }
        if ($err === UPLOAD_ERR_FORM_SIZE) {
            return 'ZIP がフォームの送信上限を超えています。PHP の post_max_size（'
                . self::formatBytes(self::parseIniBytes((string) ini_get('post_max_size')))
                . '）を確認してください。';
        }
        if ($err !== UPLOAD_ERR_OK) {
            return 'ファイルのアップロードに失敗しました（エラーコード: ' . $err . '）。';
        }
        $tmp = (string) ($file['tmp_name'] ?? '');
        if ($tmp === '' || !is_uploaded_file($tmp)) {
            return 'アップロードファイルが無効です。';
        }

        $max = self::manualUploadMaxBytes();
        $size = (int) ($file['size'] ?? 0);
        if ($size <= 0) {
            return 'ZIP ファイルが空です。';
        }
        if ($size > $max) {
            return 'ZIP のサイズが上限（' . self::formatBytes($max) . '）を超えています。';
        }

        $name = (string) ($file['name'] ?? '');
        if (!preg_match('/\.zip$/i', $name)) {
            return 'ZIP ファイル（.zip）のみアップロードできます。';
        }

        return null;
    }

    private static function resolveVersion(string $hint, string $zipBasename, string $stagingDir): string
    {
        $hint = trim($hint);
        if ($hint !== '' && preg_match('/^[0-9A-Za-z][0-9A-Za-z._-]*$/', $hint)) {
            return $hint;
        }

        $base = basename($zipBasename);
        if (preg_match('/^form-kun-(.+)\.zip$/i', $base, $m)) {
            $fromName = trim((string) $m[1]);
            if ($fromName !== '' && preg_match('/^[0-9A-Za-z][0-9A-Za-z._-]*$/', $fromName)) {
                return $fromName;
            }
        }

        $versionFile = rtrim($stagingDir, '/') . '/app/version.php';
        if (is_file($versionFile)) {
            $v = require $versionFile;
            if (is_string($v) && $v !== '' && preg_match('/^[0-9A-Za-z][0-9A-Za-z._-]*$/', $v)) {
                return $v;
            }
        }

        return '';
    }

    private static function safeExtractZip(\ZipArchive $zip, string $destDir): void
    {
        $maxFiles = (int) config('update.manual_upload_max_files', 5000);
        if ($maxFiles < 1) {
            $maxFiles = 5000;
        }
        $maxBytes = self::manualUploadMaxBytes();
        $maxUncompressed = $maxBytes * 4;

        $count = $zip->numFiles;
        if ($count > $maxFiles) {
            throw new \RuntimeException('ZIP のファイル数が上限（' . $maxFiles . '）を超えています。');
        }

        $totalSize = 0;
        for ($i = 0; $i < $count; $i++) {
            $name = $zip->getNameIndex($i);
            if ($name === false) {
                continue;
            }
            $name = str_replace('\\', '/', $name);
            if (str_contains($name, "\0")) {
                throw new \RuntimeException('不正なパスを含む ZIP です。');
            }
            if ($name !== '' && ($name[0] === '/' || preg_match('#(^|/)\.\.(/|$)#', $name))) {
                throw new \RuntimeException('不正なパスを含む ZIP です。');
            }

            $stat = $zip->statIndex($i);
            if (!is_array($stat)) {
                continue;
            }
            $totalSize += (int) ($stat['size'] ?? 0);
            if ($totalSize > $maxUncompressed) {
                throw new \RuntimeException('ZIP の展開後サイズが上限を超えています。');
            }
        }

        if (!$zip->extractTo($destDir)) {
            throw new \RuntimeException('ZIP の展開に失敗しました。');
        }
    }

    private static function detectZipRoot(string $staging): string
    {
        $entries = array_values(array_diff(scandir($staging) ?: [], ['.', '..']));
        if (count($entries) === 1) {
            $only = $staging . '/' . $entries[0];
            if (is_dir($only) && (is_file($only . '/index.php') || is_file($only . '/app/bootstrap.php'))) {
                return $only;
            }
        }
        return $staging;
    }

    private static function writeVersionFile(string $version): void
    {
        $versionFile = APP_DIR . '/version.php';
        $escaped = str_replace("'", "\\'", $version);
        file_put_contents(
            $versionFile,
            "<?php\nif (!defined('FORMKUN_BOOT')) { http_response_code(404); exit; }\nreturn '" . $escaped . "';\n"
        );
    }

    private static function lockPath(): string
    {
        return PUBLIC_DIR . '/storage/maintenance.lock';
    }

    private static function acquireMaintenanceLock(): void
    {
        if (!is_dir(PUBLIC_DIR . '/storage')) {
            mkdir(PUBLIC_DIR . '/storage', 0755, true);
        }
        file_put_contents(self::lockPath(), date('c'));
    }

    private static function releaseMaintenanceLock(): void
    {
        $p = self::lockPath();
        if (is_file($p)) {
            @unlink($p);
        }
    }

    /** @return string[] */
    private static function protectedPatterns(): array
    {
        $file = APP_DIR . '/config/protected-paths.json';
        if (is_file($file)) {
            $json = json_decode((string) file_get_contents($file), true);
            if (is_array($json['never_overwrite_on_update'] ?? null)) {
                return $json['never_overwrite_on_update'];
            }
        }
        return ['app/config.local.php'];
    }

    /** @return string[] */
    private static function uploadsMergeFiles(): array
    {
        $file = APP_DIR . '/config/protected-paths.json';
        if (is_file($file)) {
            $json = json_decode((string) file_get_contents($file), true);
            if (is_array($json['uploads_merge_files'] ?? null)) {
                return $json['uploads_merge_files'];
            }
        }
        return ['.htaccess', 'index.html'];
    }

    private static function isUploadsDataDirectory(string $name): bool
    {
        if (preg_match('/^\d{6}$/', $name) === 1) {
            return true;
        }
        return is_uuid_v4($name);
    }

    private static function isProtectedRelative(string $rel): bool
    {
        $rel = str_replace('\\', '/', $rel);
        foreach (self::protectedPatterns() as $pattern) {
            $p = str_replace('\\', '/', $pattern);
            if ($rel === $p || str_starts_with($rel, rtrim($p, '/') . '/')) {
                return true;
            }
        }

        if ($rel !== 'uploads' && !str_starts_with($rel, 'uploads/')) {
            return false;
        }

        foreach (self::uploadsMergeFiles() as $file) {
            $file = ltrim(str_replace('\\', '/', (string) $file), '/');
            if ($rel === 'uploads/' . $file) {
                return false;
            }
        }

        if ($rel === 'uploads') {
            return false;
        }

        $rest = substr($rel, strlen('uploads/'));
        $first = explode('/', $rest, 2)[0];
        return self::isUploadsDataDirectory($first);
    }

    private static function copyTree(string $src, string $dest, array $protected): void
    {
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($src, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($it as $item) {
            $sub = $it->getSubPathname();
            $sub = str_replace('\\', '/', $sub);
            if (self::isProtectedRelative($sub)) {
                continue;
            }
            $target = $dest . '/' . $sub;
            if ($item->isDir()) {
                if (!is_dir($target)) {
                    mkdir($target, 0755, true);
                }
            } else {
                $dir = dirname($target);
                if (!is_dir($dir)) {
                    mkdir($dir, 0755, true);
                }
                copy($item->getPathname(), $target);
            }
        }
    }

    private static function removeDirectory(string $dir): void
    {
        if (!is_dir($dir)) {
            return;
        }
        $it = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it as $item) {
            if ($item->isDir()) {
                @rmdir($item->getPathname());
            } else {
                @unlink($item->getPathname());
            }
        }
        @rmdir($dir);
    }

    private static function formatBytes(int $bytes): string
    {
        if ($bytes >= 1024 * 1024) {
            return round($bytes / (1024 * 1024), 1) . ' MB';
        }
        if ($bytes >= 1024) {
            return round($bytes / 1024, 1) . ' KB';
        }
        return $bytes . ' B';
    }

    private static function parseIniBytes(string $value): int
    {
        $value = trim($value);
        if ($value === '' || $value === '-1') {
            return 0;
        }
        $unit = strtolower(substr($value, -1));
        $num = (float) $value;
        return (int) match ($unit) {
            'g' => $num * 1024 * 1024 * 1024,
            'm' => $num * 1024 * 1024,
            'k' => $num * 1024,
            default => $num,
        };
    }

    private static function assertAllowedUrl(string $url): void
    {
        $parts = parse_url($url);
        if (($parts['scheme'] ?? '') !== 'https') {
            throw new \RuntimeException('HTTPS のみ許可');
        }
        $host = strtolower((string) ($parts['host'] ?? ''));
        $allowed = config('update.allowed_hosts', ['raw.githubusercontent.com']);
        if (!is_array($allowed)) {
            $allowed = ['raw.githubusercontent.com'];
        }
        $ok = false;
        foreach ($allowed as $h) {
            if ($host === strtolower((string) $h)) {
                $ok = true;
                break;
            }
        }
        if (!$ok) {
            throw new \RuntimeException('許可されていないホスト');
        }
    }

    private static function httpGet(string $url): string
    {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_TIMEOUT => 60,
                CURLOPT_SSL_VERIFYPEER => true,
            ]);
            $body = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($body === false || $code < 200 || $code >= 300) {
                throw new \RuntimeException('HTTP ' . $code);
            }
            return (string) $body;
        }
        $ctx = stream_context_create([
            'http' => ['timeout' => 60],
            'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
        ]);
        $body = @file_get_contents($url, false, $ctx);
        if ($body === false) {
            throw new \RuntimeException('download failed');
        }
        return $body;
    }

    private static function downloadToTemp(string $url): string
    {
        $tmp = tempnam(sys_get_temp_dir(), 'formkun');
        if ($tmp === false) {
            throw new \RuntimeException('temp file');
        }
        $body = self::httpGet($url);
        file_put_contents($tmp, $body);
        return $tmp;
    }

    private static function log(string $line): void
    {
        $dir = PUBLIC_DIR . '/storage';
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }
        $path = $dir . '/' . self::LOG_FILE;
        @file_put_contents($path, date('c') . ' ' . $line . "\n", FILE_APPEND);
    }
}
