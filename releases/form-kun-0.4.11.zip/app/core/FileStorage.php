<?php
namespace Core;

class FileStorage
{
    /**
     * アップロードを uploads/{form_uuid}/{file_uuid}.ext に保存し、メタ情報を返す。
     *
     * @return array{stored_path:string, file_uuid:string, original_name:string, mime_type:string, size:int}|null
     */
    public static function directorySize(string $dir): int
    {
        if (!is_dir($dir)) {
            return 0;
        }

        $total = 0;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $total += (int) $file->getSize();
            }
        }
        return $total;
    }

    public static function store(array $entry, string $formUuid): ?array
    {
        if (!isset($entry['tmp_name']) || $entry['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($entry['tmp_name'])) {
            return null;
        }

        $incomingSize = (int) ($entry['size'] ?? 0);
        if (SiteResource::wouldExceedWithAdditionalBytes($incomingSize)) {
            throw new \RuntimeException('サイトの利用容量が上限に達しているため、ファイルをアップロードできません。');
        }

        $formUuid = self::normalizeUuid($formUuid);
        if ($formUuid === null) {
            throw new \InvalidArgumentException('フォーム UUID が不正です。');
        }

        $fileUuid = \uuid_v4();
        $dir = UPLOADS_DIR . DIRECTORY_SEPARATOR . $formUuid;
        if (!is_dir($dir)) {
            if (!@mkdir($dir, 0775, true) && !is_dir($dir)) {
                throw new \RuntimeException('uploads ディレクトリを作成できません: ' . $dir);
            }
        }

        $original = self::sanitizeName((string) ($entry['name'] ?? 'upload.bin'));
        $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        $tmpPath = $dir . DIRECTORY_SEPARATOR . $fileUuid . '.upload';

        if (!@move_uploaded_file($entry['tmp_name'], $tmpPath)) {
            throw new \RuntimeException('アップロードファイルの保存に失敗しました。');
        }
        @chmod($tmpPath, 0644);

        $imageConfig = (array) config('upload.image', []);
        $destBase = $dir . DIRECTORY_SEPARATOR . $fileUuid;
        $optimized = ImageOptimizer::optimize($tmpPath, $destBase, $imageConfig);

        if ($optimized !== null && isset($optimized['output_path']) && is_file($optimized['output_path'])) {
            $storedExt = (string) $optimized['stored_ext'];
            $absPath = $dir . DIRECTORY_SEPARATOR . $fileUuid . $storedExt;
            if (!@rename($optimized['output_path'], $absPath)) {
                @copy($optimized['output_path'], $absPath);
                @unlink($optimized['output_path']);
            }
            @unlink($tmpPath);
            $mime = (string) $optimized['mime_type'];
            $size = (int) $optimized['size'];
            $stored = $fileUuid . $storedExt;
        } else {
            $storedExt = $ext !== '' ? '.' . $ext : '';
            $stored = $fileUuid . $storedExt;
            $absPath = $dir . DIRECTORY_SEPARATOR . $stored;
            if (!@rename($tmpPath, $absPath)) {
                throw new \RuntimeException('アップロードファイルの保存に失敗しました。');
            }
            $mime = self::detectMime($absPath);
            $size = filesize($absPath) ?: 0;
        }

        foreach (glob($destBase . '.opt.*') ?: [] as $junk) {
            if (is_file($junk)) {
                @unlink($junk);
            }
        }

        return [
            'stored_path'   => $formUuid . '/' . $stored,
            'file_uuid'     => $fileUuid,
            'original_name' => $original,
            'mime_type'     => $mime,
            'size'          => $size,
        ];
    }

    public static function absolutePath(string $relPath): string
    {
        $rel = ltrim(str_replace(['..', "\0"], '', $relPath), '/\\');
        return UPLOADS_DIR . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
    }

    public static function delete(string $relPath): void
    {
        $abs = self::absolutePath($relPath);
        if (is_file($abs)) {
            @unlink($abs);
        }
    }

    private static function detectMime(string $path): string
    {
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo !== false) {
                $mime = finfo_file($finfo, $path);
                finfo_close($finfo);
                if ($mime !== false && $mime !== '') {
                    return (string) $mime;
                }
            }
        }
        return 'application/octet-stream';
    }

    private static function normalizeUuid(string $uuid): ?string
    {
        $uuid = strtolower(trim($uuid));
        return is_uuid_v4($uuid) ? $uuid : null;
    }

    private static function sanitizeName(string $name): string
    {
        $name = preg_replace('/[\\\\\/\x00-\x1f]/', '_', $name) ?? 'upload.bin';
        $name = preg_replace('/\s+/', '_', $name) ?? $name;
        if (strlen($name) > 200) {
            $name = substr($name, -200);
        }
        return $name;
    }
}
