<?php require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-inputSet01/m-inputSet01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-input01/m-input01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-boldTitle01/m-boldTitle01.php'; ?>
<?php
$FB_REGEX_CUSTOM = '__custom__';
$FB_REGEX_CHECKBOX_LIMIT = '__checkbox_limit__';
$regexPresetChoices = [
    '' => 'なし',
    '/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/u' => 'メールアドレス',
    '/\A(?:\+?\d[\d\-() ]*)\z/u' => '電話番号',
    '/\A[0-9]+\z/u' => '半角数字のみ',
    '/\A[a-zA-Z0-9]+\z/u' => '半角英数字のみ',
    '/\A[ぁ-んー]+\z/u' => 'ひらがなのみ',
    '/\A[ァ-ヶー　]+\z/u' => 'カタカナのみ（全角スペース可）',
    '/\A[a-zA-Z]+\z/u' => '半角英字のみ',
    $FB_REGEX_CUSTOM => 'カスタム（正規表現を入力）',
];
$renderTemplateEditor = static function (?array $template, string $action, string $titleId): void {
    $fields = is_array($template['fields'] ?? null) ? $template['fields'] : [];
    $fieldGroups = is_array($template['field_groups'] ?? null) ? $template['field_groups'] : [];
    $pageFields = $fields;
    $fieldTemplates = [];
    $inputPage = [
        'page_key' => \Models\FormInputPage::DEFAULT_KEY,
        'title' => '入力画面',
    ];
    ?>
    <form method="post" action="<?= e($action) ?>" data-template-editor-form="1">
        <?= \Core\Csrf::field() ?>
        <div class="block is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01('ラベル', $titleId); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input([
                            'type' => 'text',
                            'name' => 'title',
                            'id' => $titleId,
                            'value' => (string) ($template['title'] ?? ''),
                            'required' => true,
                            'maxlength' => 200,
                        ]); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="block is-title">
            <p data-module="m-borderTitle01">項目設定</p>
        </div>
        <div class="block is-field" data-module="m-formBuilder01">
            <?php include APP_DIR . '/views/admin/forms/detail/form/_content_items.php'; ?>
        </div>
        <div class="block is-field">
            <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary'], 'center'); ?>
        </div>
    </form>
    <?php
};
$renderBuiltinTemplatePreview = static function (array $template): void {
    $fields = is_array($template['fields'] ?? null) ? $template['fields'] : [];
    $fieldGroups = is_array($template['field_groups'] ?? null) ? $template['field_groups'] : [];
    $pageFields = $fields;
    $fieldTemplates = [];
    $isReadOnlyTemplatePreview = true;
    $inputPage = [
        'page_key' => \Models\FormInputPage::DEFAULT_KEY,
        'title' => '入力画面',
    ];
    ?>
    <p data-module="m-text01" data-type="muted">このテンプレートは編集・削除できません。フォーム編集画面の項目設定で使用できます。</p>
    <div class="block is-title">
        <p data-module="m-borderTitle01">項目設定</p>
    </div>
    <div class="block is-field" data-module="m-formBuilder01">
        <fieldset class="c-fieldTemplateList01__readonly" disabled>
            <?php include APP_DIR . '/views/admin/forms/detail/form/_content_items.php'; ?>
        </fieldset>
    </div>
    <?php
};
if (!function_exists('admin_settings_value_text01')) {
    function admin_settings_value_text01(string $label, string $id, string $value, string $helpHtml = '', string $actionHtml = ''): void
    {
        admin_m_input_set01_open();
        echo '<div class="area is-title">';
        admin_m_bold_title01(e($label), $id);
        echo '</div>';
        echo '<div class="area is-field">';
        echo '<p class="text is-value" id="' . e($id) . '">' . e($value) . '</p>';
        echo '</div>';
        if ($helpHtml !== '') {
            echo '<div class="area is-help">' . $helpHtml . '</div>';
        }
        if ($actionHtml !== '') {
            echo '<div class="area is-actions">' . $actionHtml . '</div>';
        }
        admin_m_input_set01_close();
    }
}

if (!function_exists('admin_settings_button_html01')) {
    /**
     * admin_settings_value_text01() の actionHtml に渡す m-btn01 ボタンを組み立てる。
     *
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_settings_button_html01(string $label, array $attrs): string
    {
        ob_start();
        admin_m_btn01_button_wrap($label, $attrs);
        return (string) ob_get_clean();
    }
}
?>
<div data-module="m-toolbar01">
    <h1 class="title" style="margin:0;">設定</h1>
    <div class="spacer"></div>
    <?php if (!empty($storage_resource) && is_array($storage_resource)): ?>
        <?php admin_c_progress01_resource_summary($storage_resource); ?>
    <?php endif; ?>
</div>

<div data-module="c-formEditTabs01" class="is-nested" data-tab-scope="settings">
    <div class="wrapper">
        <div class="block is-tabs" role="tablist" aria-orientation="vertical" aria-label="設定メニュー">
            <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                data-tab-panel="settings-basic" role="tab" aria-selected="true" tabindex="0">基本情報</div>
            <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                data-tab-panel="settings-config" role="tab" aria-selected="false" tabindex="-1">設定</div>
            <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                data-tab-panel="settings-templates" role="tab" aria-selected="false" tabindex="-1">テンプレート</div>
            <?php if (\Core\Auth::role() === 'admin'): ?>
                <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                    data-tab-panel="settings-version" role="tab" aria-selected="false" tabindex="-1">バージョン</div>
            <?php endif; ?>
        </div>
        <div class="block is-contents">
            <div data-target="c-formEditTabs01__contents" data-tab-panel="settings-basic" class="area is-contents" role="tabpanel"
                aria-label="基本情報">
                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('基本情報'); ?>
                            </div>
                            <div class="block is-field">
                                <?php
                                $baseUrl = (string) config('site.base_url', '');
                                admin_settings_value_text01('管理画面の表示名', 'settings_site_admin_name', (string) config('site.admin_name', ''));
                                admin_settings_value_text01(
                                    '公開サイトのベース URL',
                                    'settings_site_base_url',
                                    $baseUrl !== '' ? $baseUrl : '未設定（相対パスのみ）'
                                );
                                admin_settings_value_text01(
                                    'サブディレクトリ（base_path）',
                                    'settings_site_base_path',
                                    (string) config('site.base_path', ''),
                                    '<p class="text is-help">空ならドキュメントルート直下です。</p>'
                                );
                                admin_settings_value_text01('タイムゾーン', 'settings_site_timezone', (string) config('site.timezone', ''));
                                ?>
                            </div>
                <?php admin_c_form_block01_close(); ?>
            </div>

            <div data-target="c-formEditTabs01__contents" data-tab-panel="settings-config" class="area is-contents" role="tabpanel"
                aria-label="設定" hidden>
                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('設定'); ?>
                            </div>
                            <div class="block is-field">
                                <?php
                                $formLimitHelp = \Core\Auth::role() !== 'admin'
                                    ? '<p data-module="m-text01" data-type="muted">作成上限の変更は管理者のみ行えます。</p>'
                                    : '';
                                $formLimitAction = \Core\Auth::role() === 'admin'
                                    ? admin_settings_button_html01('編集', [
                                        'type' => 'button',
                                        'class' => 'is-sm',
                                        'data-target' => 'settings-max-forms-open',
                                    ])
                                    : '';
                                admin_settings_value_text01(
                                    '現在のフォーム数',
                                    'settings_form_count',
                                    (int) $form_count . ' 件 / 上限 ' . (int) $max_forms . ' 件',
                                    $formLimitHelp,
                                    $formLimitAction
                                );
                                $storageHelp = '';
                                if (!empty($storage_exceeded)) {
                                    $storageHelp .= '<p data-module="m-text01" data-type="danger">上限に達しています。公開フォームは利用できません。</p>';
                                } elseif (!empty($storage_warning)) {
                                    $storageHelp .= '<p data-module="m-text01" data-type="warning">上限に近づいています。</p>';
                                }
                                if (\Core\Auth::role() !== 'admin') {
                                    $storageHelp .= '<p data-module="m-text01" data-type="muted">上限の変更は管理者のみ行えます。</p>';
                                }
                                $storageAction = \Core\Auth::role() === 'admin'
                                    ? admin_settings_button_html01('編集', [
                                        'type' => 'button',
                                        'class' => 'is-sm',
                                        'data-target' => 'settings-max-storage-open',
                                    ])
                                    : '';
                                ?>
                            </div>
                <?php admin_c_form_block01_close(); ?>

                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('使用リソース'); ?>
                            </div>
                            <div class="block is-field">
                                <p class="text is-value" id="settings_storage_uploads">添付ファイル: <?= e(\Core\Validator::formatBytes((int) $storage_used_uploads)) ?></p>
                                <p class="text is-value" id="settings_storage_db">データベース: <?= e(\Core\Validator::formatBytes((int) $storage_used_db)) ?></p>
                                <p class="text is-value" id="settings_storage_total">合計: <?= e(\Core\Validator::formatBytes((int) $storage_used_total)) ?></p>
                                <?php if ($storageHelp !== ''): ?>
                                    <div class="area is-help"><?= $storageHelp ?></div>
                                <?php endif; ?>
                                <?php if ($storageAction !== ''): ?>
                                    <div class="area is-actions"><?= $storageAction ?></div>
                                <?php endif; ?>
                            </div>
                <?php admin_c_form_block01_close(); ?>
            </div>

            <div id="settings-templates" data-target="c-formEditTabs01__contents" data-tab-panel="settings-templates" class="area is-contents" role="tabpanel"
                aria-label="テンプレート" hidden>
                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('テンプレート'); ?>
                            </div>
                            <div class="block is-field">
                                <?php admin_c_field_template_list01_open(); ?>
                                    <?php if (!empty($field_templates)): ?>
                                        <?php foreach ($field_templates as $tpl): ?>
                                            <?php
                                            $isBuiltinTemplate = !empty($tpl['is_builtin']);
                                            $templateId = (string) ($tpl['id'] ?? '');
                                            $templateDbId = (int) $templateId;
                                            $templateTitle = trim((string) ($tpl['title'] ?? '')) !== '' ? (string) $tpl['title'] : '無題のテンプレート';
                                            ?>
                                            <details class="c-fieldTemplateList01__item">
                                                <summary class="summary">
                                                    <span class="title"><?= e($templateTitle) ?></span>
                                                    <?php if ($isBuiltinTemplate): ?>
                                                        <span class="text">標準テンプレート</span>
                                                    <?php else: ?>
                                                        <details class="menu">
                                                            <summary aria-label="テンプレート操作">…</summary>
                                                            <div class="menuBody">
                                                                <form method="post" action="<?= e(base_path('/admin/settings/templates/' . $templateDbId . '/delete')) ?>" onsubmit="return confirm('このテンプレートを削除しますか？');">
                                                                    <?= \Core\Csrf::field() ?>
                                                                    <button type="submit">削除</button>
                                                                </form>
                                                            </div>
                                                        </details>
                                                    <?php endif; ?>
                                                </summary>
                                                <div class="body">
                                                    <?php if ($isBuiltinTemplate): ?>
                                                        <?php $renderBuiltinTemplatePreview($tpl); ?>
                                                    <?php else: ?>
                                                        <?php $renderTemplateEditor($tpl, base_path('/admin/settings/templates/' . $templateDbId), 'field_template_title_' . $templateDbId); ?>
                                                    <?php endif; ?>
                                                </div>
                                            </details>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                    <div class="c-fieldTemplateList01__add" data-target="fieldTemplateCreateActions">
                                        <?php admin_m_btn01_open(); ?>
                                            <?php admin_m_btn01_button('＋ テンプレートを追加', [
                                                'type' => 'button',
                                                'class' => 'fb-description-add',
                                                'data-target' => 'fieldTemplateCreateOpen',
                                            ]); ?>
                                        <?php admin_m_btn01_close(); ?>
                                    </div>
                                    <template data-target="fieldTemplateCreateTemplate">
                                        <details class="c-fieldTemplateList01__item is-new">
                                            <summary class="summary">
                                                <span class="title">新規テンプレート</span>
                                            </summary>
                                            <div class="body">
                                                <?php $renderTemplateEditor(null, base_path('/admin/settings/templates'), 'field_template_title___templateKey__'); ?>
                                            </div>
                                        </details>
                                    </template>
                                <?php admin_c_field_template_list01_close(); ?>
                            </div>
                <?php admin_c_form_block01_close(); ?>
            </div>

            <?php if (\Core\Auth::role() === 'admin'): ?>
                <div data-target="c-formEditTabs01__contents" data-tab-panel="settings-version" class="area is-contents" role="tabpanel"
                    aria-label="バージョン" hidden>
                    <?php require __DIR__ . '/_content_app_update.php'; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php admin_c_field_type_modal01(); ?>
<?php admin_m_form_builder01_field_template(); ?>
<?php admin_m_form_builder01_group_template(); ?>

<?php if (\Core\Auth::role() === 'admin'): ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-max-forms-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-max-forms-modal-title'); ?>
        <?php admin_c_modal01_header_open(); ?>
            <h2 id="settings-max-forms-modal-title">フォームの作成上限</h2>
            <button type="button" class="btn is-sm" data-target="settings-max-forms-close">閉じる</button>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('フォームの作成上限'), 'max_forms_modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('max_forms_modal', [
                            'type' => 'number',
                            'name' => 'max_forms',
                            'id' => 'max_forms_modal',
                            'min' => 1,
                            'max' => 999999,
                            'step' => 1,
                            'value' => (string) (int) $max_forms,
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">1 以上の整数を指定してください。保存後、一覧の新規作成やこの上限を超える作成はできません。</p>
                </div>
                <?php admin_c_modal01_actions_open(); ?>
                    <button type="button" class="btn" data-target="settings-max-forms-close">キャンセル</button>
                    <button type="submit" class="btn is-primary">保存</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-max-storage-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-max-storage-modal-title'); ?>
        <?php admin_c_modal01_header_open(); ?>
            <h2 id="settings-max-storage-modal-title">使用リソースの上限</h2>
            <button type="button" class="btn is-sm" data-target="settings-max-storage-close">閉じる</button>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/site-resource')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('使用リソースの上限（MB）'), 'max_site_resource_mb_modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('max_site_resource_mb_modal', [
                            'type' => 'number',
                            'name' => 'max_site_resource_mb',
                            'id' => 'max_site_resource_mb_modal',
                            'min' => 1,
                            'max' => 1048576,
                            'step' => 1,
                            'value' => (string) (int) $storage_max_mb,
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">添付ファイルとデータベースの合計使用量の上限です。1 以上の整数（MB）を指定してください。</p>
                </div>
                <?php admin_c_modal01_actions_open(); ?>
                    <button type="button" class="btn" data-target="settings-max-storage-close">キャンセル</button>
                    <button type="submit" class="btn is-primary">保存</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php endif; ?>

