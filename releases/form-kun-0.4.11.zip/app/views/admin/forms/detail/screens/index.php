<?php
/** フォーム編集:「画面」タブパネル */
$inputPages = \Models\FormInputPage::normalizePages($inputPages ?? [], $form ?? []);
$screenTabs = [];
foreach ($inputPages as $i => $inputPage) {
    $screenTabs[] = [
        'panel' => 'screen-input-' . (string) $inputPage['page_key'],
        'label' => (string) ($inputPage['title'] ?: ('入力画面 ' . ($i + 1))),
        'selected' => $i === 0,
        'input' => true,
    ];
}
$screenTabs[] = ['panel' => 'screen-confirm', 'label' => '確認画面'];
$screenTabs[] = ['panel' => 'screen-thanks', 'label' => '完了画面'];
?>
<div data-target="c-formEditTabs01__contents" data-tab-panel="screens" class="area is-contents" role="tabpanel"
    aria-label="画面" hidden>
    <div data-module="c-formEditTabs01" class="is-nested" data-tab-scope="screens">
        <div class="wrapper">
            <div class="block is-tabs" role="tablist" aria-orientation="vertical" aria-label="画面の区分" data-target="inputPageTabs">
                <?php foreach ($screenTabs as $tab): ?>
                    <?php if (!empty($tab['input'])): ?>
                        <div class="c-inputPageTab01" data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                            data-input-page-tab="1" data-tab-panel="<?= e($tab['panel']) ?>" role="tab"
                            aria-selected="<?= !empty($tab['selected']) ? 'true' : 'false' ?>"
                            tabindex="<?= !empty($tab['selected']) ? '0' : '-1' ?>">
                            <span class="label" data-target="inputPageTabLabel"><?= e($tab['label']) ?></span>
                            <details class="menu" data-target="inputPageActionMenu">
                                <summary class="toggle" aria-label="入力画面操作"><span aria-hidden="true">⋯</span></summary>
                                <div class="items" role="menu" aria-label="入力画面操作">
                                    <button type="button" data-target="inputPageDuplicate" role="menuitem">複製</button>
                                    <button type="button" data-target="inputPageDelete" role="menuitem">削除</button>
                                </div>
                            </details>
                        </div>
                    <?php else: ?>
                        <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                            data-tab-panel="<?= e($tab['panel']) ?>" role="tab"
                            aria-selected="<?= !empty($tab['selected']) ? 'true' : 'false' ?>"
                            tabindex="<?= !empty($tab['selected']) ? '0' : '-1' ?>"><?= e($tab['label']) ?></div>
                    <?php endif; ?>
                <?php endforeach; ?>
                <?php admin_m_btn01_button_wrap('＋ 入力画面を追加', [
                    'data-target' => 'inputPageAdd',
                    'class' => 'is-text',
                ]); ?>
            </div>
            <div class="block is-contents" data-target="inputPagePanels">
        <?php require __DIR__ . '/../fields/index.php'; ?>
        <?php require __DIR__ . '/../confirm/index.php'; ?>
        <?php require __DIR__ . '/../thanks/index.php'; ?>
            </div>
        </div>
    </div>
</div>
