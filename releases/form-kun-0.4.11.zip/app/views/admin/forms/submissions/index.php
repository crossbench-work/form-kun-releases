<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';

$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-field">
                                <form method="get" action="<?= e(base_path('/admin/forms/' . $form['id'] . '/submissions')) ?>" data-module="m-toolbar01">
                                    <?php admin_m_input01_open(); ?>
                                        <?php admin_m_input01_input([
                                            'type' => 'text',
                                            'name' => 'q',
                                            'value' => (string) $q,
                                            'placeholder' => 'キーワード検索（送信内容）',
                                            'style' => 'width:280px',
                                        ]); ?>
                                    <?php admin_m_input01_close(); ?>
                                    <?php admin_m_bold_title01(e('期間'), 'submissions-from'); ?>
                                    <?php admin_m_input01_open(); ?>
                                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-from', [
                                            'type' => 'date',
                                            'id' => 'submissions-from',
                                            'name' => 'from',
                                            'value' => (string) $from,
                                        ])); ?>
                                    <?php admin_m_input01_close(); ?>
                                    <?php admin_m_bold_title01(e('〜'), 'submissions-to'); ?>
                                    <?php admin_m_input01_open(); ?>
                                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-to', [
                                            'type' => 'date',
                                            'id' => 'submissions-to',
                                            'name' => 'to',
                                            'value' => (string) $to,
                                        ])); ?>
                                    <?php admin_m_input01_close(); ?>
                                    <?php admin_m_input01_open(); ?>
                                        <select name="status" class="m-inout01__input" aria-label="状態で絞り込み" style="width:auto;min-width:120px">
                                            <option value="">状態: すべて</option>
                                            <?php foreach ($workflowStatusOptions as $statusOpt): ?>
                                                <option value="<?= e($statusOpt) ?>"<?= ($statusFilter ?? '') === $statusOpt ? ' selected' : '' ?>>
                                                    <?= e(\Models\Submission::workflowStatusLabel($statusOpt)) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php admin_m_input01_close(); ?>
                                    <button class="btn" type="submit">検索</button>
                                    <?php if ($q !== '' || $from !== '' || $to !== '' || ($statusFilter ?? '') !== ''): ?>
                                        <a class="btn" href="<?= e(base_path('/admin/forms/' . $form['id'] . '/submissions')) ?>">リセット</a>
                                    <?php endif; ?>
                                    <span class="spacer"></span>
                                    <span data-module="m-text01" data-type="muted"><?= number_format($total) ?>件</span>
                                </form>

                                <?php if (empty($rows)): ?>
                                    <p data-module="m-text01" data-type="muted">該当する送信がありません。</p>
                                <?php else: ?>
                                    <?php admin_m_table01_open(); ?>
                                        <thead>
                                            <tr>
                                                <th>受信日時</th>
                                                <th>状態</th>
                                                <?php foreach ($previewKeys as $key):
                                                    $label = '';
                                                    foreach ($fields as $f) { if ($f['field_key'] === $key) { $label = $f['label']; break; } }
                                                ?>
                                                    <th><?= e($label ?: $key) ?></th>
                                                <?php endforeach; ?>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($rows as $r):
                                            $workflowStatus = (string) ($r['workflow_status'] ?? \Models\Submission::WORKFLOW_PENDING);
                                        ?>
                                            <tr>
                                                <td>
                                                    <a href="<?= e(base_path('/admin/forms/submissions/' . $r['id'])) ?>">
                                                        <?= e($r['submitted_at']) ?>
                                                    </a>
                                                </td>
                                                <td class="is-workflow-status">
                                                    <form method="post" action="<?= e(base_path('/admin/forms/submissions/' . $r['id'] . '/status')) ?>" data-module="m-submissionWorkflowStatus01">
                                                        <?= \Core\Csrf::field() ?>
                                                        <select name="status" data-target="m-submissionWorkflowStatus01__select" class="is-<?= e($workflowStatus) ?>" aria-label="状態を変更" onchange="this.form.submit()">
                                                            <?php foreach ($workflowStatusOptions as $statusOpt): ?>
                                                                <option value="<?= e($statusOpt) ?>"<?= $workflowStatus === $statusOpt ? ' selected' : '' ?>>
                                                                    <?= e(\Models\Submission::workflowStatusLabel($statusOpt)) ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </form>
                                                </td>
                                                <?php foreach ($previewKeys as $key):
                                                    $fieldDef = null;
                                                    foreach ($fields as $f) {
                                                        if ($f['field_key'] === $key) {
                                                            $fieldDef = $f;
                                                            break;
                                                        }
                                                    }
                                                    $fieldType = (string) ($fieldDef['type'] ?? '');
                                                ?>
                                                    <td>
                                                    <?php if ($fieldType === 'file'): ?>
                                                        <?php
                                                            $cellFiles = ($previewFiles ?? [])[(int) $r['id']][$key] ?? [];
                                                        ?>
                                                        <?php if ($cellFiles === []): ?>
                                                            <span data-module="m-text01" data-type="muted">—</span>
                                                        <?php else: ?>
                                                            <div class="m-submissionFilePreview01">
                                                                <?php foreach ($cellFiles as $fl): ?>
                                                                    <?php
                                                                        $fileUrl = admin_submission_file_url((int) $fl['id']);
                                                                        $fileName = (string) ($fl['original_name'] ?? 'file');
                                                                    ?>
                                                                    <?php if (is_image_mime_type($fl['mime_type'] ?? '')): ?>
                                                                        <a class="m-submissionFilePreview01__thumbLink" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener noreferrer" title="<?= e($fileName) ?>">
                                                                            <img class="m-submissionFilePreview01__thumb" src="<?= e($fileUrl) ?>" alt="<?= e($fileName) ?>" loading="lazy" width="48" height="48">
                                                                        </a>
                                                                    <?php else: ?>
                                                                        <a class="m-submissionFilePreview01__link" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener noreferrer"><?= e($fileName) ?></a>
                                                                    <?php endif; ?>
                                                                <?php endforeach; ?>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php else:
                                                        $v = $previews[(int)$r['id']][$key] ?? '';
                                                        if ($fieldType === 'address') {
                                                            $v = format_address_value_display($v);
                                                        } elseif ($fieldType === 'text_pair') {
                                                            $v = format_text_pair_value_display($v, \Models\FormField::decodeTextPairLabels($fieldDef['options_json'] ?? null));
                                                        } elseif ($fieldType === 'text_multi') {
                                                            $v = format_text_multi_value_display($v, \Models\FormField::decodeTextMultiItems($fieldDef['options_json'] ?? null, true));
                                                        }
                                                        $v = mb_substr((string) $v, 0, 40);
                                                    ?>
                                                        <?= e($v) ?>
                                                    <?php endif; ?>
                                                    </td>
                                                <?php endforeach; ?>
                                                <td class="is-actions">
                                                    <details class="c-tableActionMenu01">
                                                        <summary class="c-tableActionMenu01__toggle" aria-label="操作">
                                                            <span aria-hidden="true">⋯</span>
                                                        </summary>
                                                        <div class="c-tableActionMenu01__menu" role="menu" aria-label="操作">
                                                            <a role="menuitem" href="<?= e(base_path('/admin/forms/submissions/' . $r['id'])) ?>">詳細</a>
                                                            <form method="post"
                                                                  action="<?= e(base_path('/admin/forms/submissions/' . $r['id'] . '/delete')) ?>"
                                                                  onsubmit="return confirm('この送信を削除しますか？');">
                                                                <?= \Core\Csrf::field() ?>
                                                                <?php admin_m_delete_btn01('admin-submission-delete-' . $r['id'], '削除', '削除', 'submit', '削除'); ?>
                                                            </form>
                                                        </div>
                                                    </details>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    <?php admin_m_table01_close(); ?>

                                    <?php if ($totalPages > 1): ?>
                                    <?php admin_c_pagination01_open(); ?>
                                        <?php
                                            $qs = function (int $p) use ($q, $from, $to, $statusFilter) {
                                                $params = ['page' => $p];
                                                if ($q !== '')    $params['q'] = $q;
                                                if ($from !== '') $params['from'] = $from;
                                                if ($to !== '')   $params['to'] = $to;
                                                if (($statusFilter ?? '') !== '') {
                                                    $params['status'] = $statusFilter;
                                                }
                                                return '?' . http_build_query($params);
                                            };
                                            $base = base_path('/admin/forms/' . $form['id'] . '/submissions');
                                        ?>
                                        <?php if ($page > 1): ?>
                                            <a href="<?= e($base . $qs($page - 1)) ?>">‹ 前へ</a>
                                        <?php else: ?>
                                            <span class="disabled">‹ 前へ</span>
                                        <?php endif; ?>

                                        <?php for ($p = max(1, $page - 3); $p <= min($totalPages, $page + 3); $p++): ?>
                                            <?php if ($p === $page): ?>
                                                <span class="current"><?= $p ?></span>
                                            <?php else: ?>
                                                <a href="<?= e($base . $qs($p)) ?>"><?= $p ?></a>
                                            <?php endif; ?>
                                        <?php endfor; ?>

                                        <?php if ($page < $totalPages): ?>
                                            <a href="<?= e($base . $qs($page + 1)) ?>">次へ ›</a>
                                        <?php else: ?>
                                            <span class="disabled">次へ ›</span>
                                        <?php endif; ?>
                                    <?php admin_c_pagination01_close(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
<?php admin_c_form_block01_close(); ?>
