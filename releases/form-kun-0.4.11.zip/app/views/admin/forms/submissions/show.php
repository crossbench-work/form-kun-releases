<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';

$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'href' => base_path('/admin/forms/' . (int) $form['id'] . '/submissions')],
    ['label' => (string) ($sub['submitted_at'] ?? ''), 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-field">
                                <?php admin_m_table01_open('is-kv'); ?>
                                    <tr><th>フォーム</th><td><?= e($form['title']) ?>（<code><?= e($form['slug']) ?></code>）</td></tr>
                                    <tr><th>受信日時</th><td><?= e($sub['submitted_at']) ?></td></tr>
                                    <tr>
                                        <th>状態</th>
                                        <td>
                                            <?php
                                                $workflowStatus = (string) ($sub['workflow_status'] ?? \Models\Submission::WORKFLOW_PENDING);
                                            ?>
                                            <form method="post" action="<?= e(base_path('/admin/forms/submissions/' . (int) $sub['id'] . '/status')) ?>" data-module="m-submissionWorkflowStatus01" class="is-detail">
                                                <?= \Core\Csrf::field() ?>
                                                <select name="status" data-target="m-submissionWorkflowStatus01__select" class="is-<?= e($workflowStatus) ?>" aria-label="状態を変更" onchange="this.form.submit()">
                                                    <?php foreach ($workflowStatusOptions as $statusOpt): ?>
                                                        <option value="<?= e($statusOpt) ?>"<?= $workflowStatus === $statusOpt ? ' selected' : '' ?>>
                                                            <?= e(\Models\Submission::workflowStatusLabel($statusOpt)) ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                </select>
                                            </form>
                                        </td>
                                    </tr>
                                    <tr><th>IPアドレス</th><td><?= e($sub['ip']) ?></td></tr>
                                    <tr><th>User-Agent</th><td><?= e($sub['user_agent']) ?></td></tr>
                                <?php admin_m_table01_close(); ?>
                            </div>
<?php admin_c_form_block01_close(); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_large_title01('入力内容'); ?>
                            </div>
                            <div class="area is-field">
                                <?php admin_m_table01_open('is-kv'); ?>
                                <?php foreach ($fields as $f):
                                    $key = $f['field_key'];
                                ?>
                                    <tr>
                                        <th><?= e($f['label']) ?><br><span data-module="m-text01" data-type="muted"><?= e($key) ?></span></th>
                                        <td>
                                        <?php if ($f['type'] === 'file'): ?>
                                            <?php $files = $filesByKey[$key] ?? []; ?>
                                            <?php if (empty($files)): ?>
                                                <span data-module="m-text01" data-type="muted">（ファイルなし）</span>
                                            <?php else: ?>
                                                <div class="m-submissionFilePreview01 is-detail">
                                                    <?php foreach ($files as $fl): ?>
                                                        <?php
                                                            $fileUrl = admin_submission_file_url((int) $fl['id']);
                                                            $fileName = (string) ($fl['original_name'] ?? 'file');
                                                        ?>
                                                        <div class="m-submissionFilePreview01__item">
                                                            <?php if (is_image_mime_type($fl['mime_type'] ?? '')): ?>
                                                                <a class="m-submissionFilePreview01__thumbLink" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener noreferrer" title="<?= e($fileName) ?>">
                                                                    <img class="m-submissionFilePreview01__thumb" src="<?= e($fileUrl) ?>" alt="<?= e($fileName) ?>" loading="lazy">
                                                                </a>
                                                            <?php else: ?>
                                                                <a class="m-submissionFilePreview01__link" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener noreferrer"><?= e($fileName) ?></a>
                                                            <?php endif; ?>
                                                            <span class="m-submissionFilePreview01__meta" data-module="m-text01" data-type="muted">
                                                                <?php if (!is_image_mime_type($fl['mime_type'] ?? '')): ?>
                                                                    <?= e($fileName) ?>
                                                                <?php endif; ?>
                                                                （<?= e(\Core\Validator::formatBytes((int) $fl['size'])) ?> / <?= e($fl['mime_type']) ?>）
                                                            </span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php else:
                                            $val = $values[$key] ?? '';
                                        ?>
                                            <?php if ($f['type'] === 'address'): ?>
                                                <?php $addrText = format_address_value_display($val); ?>
                                                <?= $addrText !== '' ? nl2br(e($addrText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
                                            <?php elseif ($f['type'] === 'text_pair'): ?>
                                                <?php $pairText = format_text_pair_value_display($val, \Models\FormField::decodeTextPairLabels($f['options_json'] ?? null)); ?>
                                                <?= $pairText !== '' ? nl2br(e($pairText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
                                            <?php elseif ($f['type'] === 'text_multi'): ?>
                                                <?php $multiText = format_text_multi_value_display($val, \Models\FormField::decodeTextMultiItems($f['options_json'] ?? null, true)); ?>
                                                <?= $multiText !== '' ? nl2br(e($multiText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
                                            <?php else: ?>
                                                <?= $val !== '' ? nl2br(e((string) $val)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>

                                <?php
                                    // フォーム項目に存在しないキー（過去に項目だった等）も表示
                                    $fieldKeys = array_map(fn($f) => $f['field_key'], $fields);
                                    foreach ($values as $k => $v):
                                        if (in_array($k, $fieldKeys, true)) continue;
                                ?>
                                    <tr>
                                        <th>(削除済み項目)<br><span data-module="m-text01" data-type="muted"><?= e($k) ?></span></th>
                                        <td><?= nl2br(e((string) $v)) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php admin_m_table01_close(); ?>
                            </div>
<?php admin_c_form_block01_close(); ?>
