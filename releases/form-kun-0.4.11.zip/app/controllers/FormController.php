<?php
namespace Controllers;

use Core\Csrf;
use Core\FileStorage;
use Core\Mailer;
use Core\SiteResource;
use Core\Validator;
use Core\View;
use Models\Form;
use Models\FormBranchRule;
use Models\FormField;
use Models\FormFieldGroup;
use Models\FormInputPage;
use Models\Submission;

class FormController
{
    private View $view;

    public function __construct()
    {
        $this->view = new View();
    }

    public function show(string $slug): void
    {
        $form = Form::findActiveBySlug($slug);
        if (!$form) {
            $this->notFound();
            return;
        }
        $fields = FormField::forForm((int) $form['id'], true);
        $fieldGroups = FormFieldGroup::forForm((int) $form['id'], true);
        $inputPages = FormInputPage::forForm((int) $form['id'], $form);
        $branchRules = FormBranchRule::forForm((int) $form['id']);
        if ($this->isSiteResourceBlocked()) {
            $this->renderShowBlocked($form, $fields, [], $inputPages[0] ?? null, $inputPages, $branchRules, $fieldGroups);
            return;
        }

        unset($_SESSION['_pending_submission']);
        $this->renderShow($form, $fields, [], [], $inputPages[0] ?? null, $inputPages, $branchRules, $fieldGroups);
    }

    public function confirm(string $slug): void
    {
        $form = Form::findActiveBySlug($slug);
        if (!$form) { $this->notFound(); return; }

        Csrf::verify();
        $fields = FormField::forForm((int) $form['id'], true);
        $fieldGroups = FormFieldGroup::forForm((int) $form['id'], true);
        $inputPages = FormInputPage::forForm((int) $form['id'], $form);
        $branchRules = FormBranchRule::forForm((int) $form['id']);
        $firstPage = $inputPages[0] ?? FormInputPage::defaultPage($form);
        $postedPageKey = FormInputPage::sanitizePageKey((string) ($_POST['input_page_key'] ?? ''));
        if ($postedPageKey === '' || FormInputPage::findPage($inputPages, $postedPageKey) === null) {
            $postedPageKey = (string) $firstPage['page_key'];
        }
        $inputPage = FormInputPage::findPage($inputPages, $postedPageKey) ?? $firstPage;
        if ($this->isSiteResourceBlocked()) {
            $this->renderShowBlocked($form, $fields, [], $inputPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }
        $pageFields = FormField::forInputPage($fields, (string) $inputPage['page_key']);
        $pending = $_SESSION['_pending_submission'] ?? null;
        $pendingValues = (is_array($pending) && (int) ($pending['form_id'] ?? 0) === (int) $form['id'])
            ? (array) ($pending['values'] ?? [])
            : [];
        $pendingFileMetas = (is_array($pending) && (int) ($pending['form_id'] ?? 0) === (int) $form['id'])
            ? (array) ($pending['file_metas'] ?? [])
            : [];
        $submittedFieldKeys = (is_array($pending) && (int) ($pending['form_id'] ?? 0) === (int) $form['id'])
            ? (array) ($pending['submitted_field_keys'] ?? [])
            : [];
        $pageHistory = (is_array($pending) && (int) ($pending['form_id'] ?? 0) === (int) $form['id'])
            ? array_values(array_filter(array_map('strval', (array) ($pending['page_history'] ?? [])), static fn($key): bool => $key !== ''))
            : [];
        if (!empty($_POST['_back_input'])) {
            $previousPageKey = array_pop($pageHistory);
            $previousPage = $previousPageKey !== null ? FormInputPage::findPage($inputPages, $previousPageKey) : null;
            if ($previousPage === null) {
                $previousPage = $firstPage;
                $pageHistory = [];
            }
            $_SESSION['_pending_submission'] = [
                'form_id' => (int) $form['id'],
                'values' => $pendingValues,
                'file_metas' => $pendingFileMetas,
                'submitted_field_keys' => $submittedFieldKeys,
                'last_page_key' => (string) ($previousPage['page_key'] ?? FormInputPage::DEFAULT_KEY),
                'page_history' => $pageHistory,
                'created_at' => is_array($pending) ? (int) ($pending['created_at'] ?? time()) : time(),
            ];
            Csrf::rotate();
            $this->renderShow($form, $fields, $pendingValues, [], $previousPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }
        $candidateValues = array_merge($pendingValues, $_POST);
        $currentPageKey = (string) ($inputPage['page_key'] ?? FormInputPage::DEFAULT_KEY);
        $visibleFields = self::visibleFields(self::applyBranchVisibility($pageFields, $branchRules, $candidateValues, $currentPageKey, $fieldGroups));

        // バリデーション
        $validator = new Validator();
        $files = self::buildFileMap($visibleFields);
        $result = $validator->validate($visibleFields, $_POST, $files);
        $mergedValues = array_merge($pendingValues, $result['values']);

        if (!empty($result['errors'])) {
            $this->renderShow($form, $fields, $mergedValues, $result['errors'], $inputPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }

        // ファイルは確認画面では一時保管にせず、サーバ側に即保存（再送信対策）。
        // 共有レンタルサーバーで PHP-FPM の tmp_name 永続化が当てにならないため。
        $formUuid = Form::requirePublicUuid($form);
        $fileMetas = [];
        $uploadErrors = [];
        foreach ($files as $key => $entry) {
            if (!$entry || $entry['error'] === UPLOAD_ERR_NO_FILE) {
                if (isset($pendingFileMetas[$key])) {
                    $fileMetas[$key] = $pendingFileMetas[$key];
                }
                continue;
            }
            try {
                if (isset($pendingFileMetas[$key]['stored_path'])) {
                    FileStorage::delete($pendingFileMetas[$key]['stored_path']);
                }
                $meta = FileStorage::store($entry, $formUuid);
                if ($meta) {
                    $fileMetas[$key] = $meta;
                }
            } catch (\RuntimeException $e) {
                $field = null;
                foreach ($visibleFields as $f) {
                    if (($f['field_key'] ?? '') === $key) {
                        $field = $f;
                        break;
                    }
                }
                $label = (string) ($field['label'] ?? $key);
                $uploadErrors[$key][] = $label . 'を保存できませんでした。' . $e->getMessage();
            }
        }
        if ($uploadErrors !== []) {
            $this->renderShow($form, $fields, $mergedValues, $uploadErrors, $inputPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }

        $mergedFileMetas = array_merge($pendingFileMetas, $fileMetas);
        $branchEvaluation = FormBranchRule::evaluate($branchRules, $mergedValues, $currentPageKey);
        $controlledKeys = self::branchControlledFieldKeys($branchRules, $currentPageKey);
        $hiddenGroupKeys = self::hiddenControlledGroupKeys($fieldGroups, self::branchControlledGroupKeys($branchRules, $currentPageKey), $branchEvaluation['visible_group_keys']);
        foreach ($pageFields as $pageField) {
            $fieldKey = (string) ($pageField['field_key'] ?? '');
            if ($fieldKey !== '' && self::fieldBelongsToGroup($pageField, $hiddenGroupKeys, $fieldGroups)) {
                $controlledKeys[] = $fieldKey;
            }
        }
        foreach ($controlledKeys as $controlledKey) {
            if (in_array($controlledKey, $branchEvaluation['visible_field_keys'], true)) {
                continue;
            }
            unset($mergedValues[$controlledKey], $mergedFileMetas[$controlledKey]);
            $submittedFieldKeys = array_values(array_filter($submittedFieldKeys, static function ($key) use ($controlledKey): bool {
                return (string) $key !== $controlledKey;
            }));
        }
        $nextPageKey = $branchEvaluation['next_screen_key']
            ?? FormInputPage::nextPageKey($inputPages, (string) $inputPage['page_key']);
        $submittedFieldKeys = array_values(array_unique(array_merge(
            array_map('strval', $submittedFieldKeys),
            array_map(static fn($field): string => (string) ($field['field_key'] ?? ''), $visibleFields)
        )));
        if ($pageHistory === [] || end($pageHistory) !== $currentPageKey) {
            $pageHistory[] = $currentPageKey;
        }
        // セッションに値を保管
        $_SESSION['_pending_submission'] = [
            'form_id'    => (int) $form['id'],
            'values'     => $mergedValues,
            'file_metas' => $mergedFileMetas,
            'submitted_field_keys' => $submittedFieldKeys,
            'last_page_key' => $currentPageKey,
            'page_history' => $pageHistory,
            'created_at' => time(),
        ];
        Csrf::rotate();

        if ($nextPageKey === FormBranchRule::SCREEN_THANKS) {
            $sid = Submission::create(
                (int) $form['id'],
                $mergedValues,
                $mergedFileMetas,
                client_ip(),
                $_SERVER['HTTP_USER_AGENT'] ?? ''
            );
            unset($_SESSION['_pending_submission']);
            $submittedFields = self::fieldsByKeys($fields, $submittedFieldKeys);
            $this->sendMails($form, $submittedFields, $mergedValues, $mergedFileMetas);
            $this->view->render('front/form/thanks', [
                'title' => trim((string) ($form['thanks_page_title'] ?? '')) !== ''
                    ? (string) $form['thanks_page_title']
                    : '送信が完了しました',
                'form'  => $form,
                'submissionId' => $sid,
            ], 'public');
            return;
        }

        if ($nextPageKey !== null && $nextPageKey !== FormBranchRule::SCREEN_CONFIRM) {
            $nextPage = FormInputPage::findPage($inputPages, $nextPageKey);
            if ($nextPage !== null) {
                $this->renderShow($form, $fields, $mergedValues, [], $nextPage, $inputPages, $branchRules, $fieldGroups);
                return;
            }
        }

        $submittedFields = self::fieldsByKeys($fields, $submittedFieldKeys);
        $this->view->render('front/form/confirm', [
            'title'  => trim((string) ($form['confirm_page_title'] ?? '')) !== ''
                ? (string) $form['confirm_page_title']
                : '入力内容のご確認',
            'form'   => $form,
            'fields' => $submittedFields,
            'values' => $mergedValues,
            'fileMetas' => $mergedFileMetas,
        ], 'public');
    }

    public function submit(string $slug): void
    {
        $form = Form::findActiveBySlug($slug);
        if (!$form) { $this->notFound(); return; }

        Csrf::verify();
        $fields = FormField::forForm((int) $form['id'], true);
        $fieldGroups = FormFieldGroup::forForm((int) $form['id'], true);
        $inputPages = FormInputPage::forForm((int) $form['id'], $form);
        $branchRules = FormBranchRule::forForm((int) $form['id']);
        $blocked = $this->isSiteResourceBlocked();
        $pending = $_SESSION['_pending_submission'] ?? null;
        if (!$pending || (int) $pending['form_id'] !== (int) $form['id']) {
            // セッション切れ
            redirect('/f/' . $slug);
        }
        // 30分以上経過したら破棄
        if (time() - (int) $pending['created_at'] > 60 * 30) {
            unset($_SESSION['_pending_submission']);
            redirect('/f/' . $slug);
        }

        $visibleFields = self::visibleFields($fields);
        $submittedFieldKeys = array_map('strval', (array) ($pending['submitted_field_keys'] ?? []));
        $submittedFields = $submittedFieldKeys !== [] ? self::fieldsByKeys($fields, $submittedFieldKeys) : $visibleFields;

        if ($blocked && empty($_POST['_back'])) {
            $this->renderConfirmBlocked($form, $fields, $pending);
            return;
        }

        // 戻るで再編集
        if (!empty($_POST['_back'])) {
            $values = $pending['values'];
            // 確認画面でアップ済みのファイルは戻ったらクリアする
            foreach ($pending['file_metas'] ?? [] as $meta) {
                FileStorage::delete($meta['stored_path']);
            }
            unset($_SESSION['_pending_submission']);
            $backPage = FormInputPage::findPage($inputPages, (string) ($pending['last_page_key'] ?? ''))
                ?? ($inputPages[count($inputPages) - 1] ?? null);
            if ($blocked) {
                $this->renderShowBlocked($form, $fields, $values, $backPage, $inputPages, $branchRules, $fieldGroups);
                return;
            }
            $this->renderShow($form, $fields, $values, [], $backPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }

        if ($blocked) {
            $this->renderConfirmBlocked($form, $fields, $pending);
            return;
        }

        // 保存
        $sid = Submission::create(
            (int) $form['id'],
            $pending['values'],
            $pending['file_metas'] ?? [],
            client_ip(),
            $_SERVER['HTTP_USER_AGENT'] ?? ''
        );
        unset($_SESSION['_pending_submission']);
        Csrf::rotate();

        // メール送信
        $this->sendMails($form, $submittedFields, $pending['values'], $pending['file_metas'] ?? []);

        $this->view->render('front/form/thanks', [
            'title' => trim((string) ($form['thanks_page_title'] ?? '')) !== ''
                ? (string) $form['thanks_page_title']
                : '送信が完了しました',
            'form'  => $form,
            'submissionId' => $sid,
        ], 'public');
    }

    /**
     * $_FILES の整形。
     */
    private static function buildFileMap(array $fields): array
    {
        $map = [];
        foreach ($fields as $f) {
            if ($f['type'] !== 'file') continue;
            $key = $f['field_key'];
            if (isset($_FILES[$key])) {
                $map[$key] = $_FILES[$key];
            }
        }
        return $map;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<int, array<string, mixed>>
     */
    private static function visibleFields(array $fields): array
    {
        return array_values(array_filter($fields, static function ($field): bool {
            return !empty($field['visible']);
        }));
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $rules
     * @param array<string, mixed> $values
     * @return array<int, array<string, mixed>>
     */
    private static function applyBranchVisibility(array $fields, array $rules, array $values, ?string $triggerPageKey = null, array $groups = []): array
    {
        $controlledKeys = self::branchControlledFieldKeys($rules, $triggerPageKey);
        $controlledGroupKeys = self::branchControlledGroupKeys($rules, $triggerPageKey);
        if ($controlledKeys === [] && $controlledGroupKeys === []) {
            return $fields;
        }
        $evaluation = FormBranchRule::evaluate($rules, $values, $triggerPageKey);
        $visibleKeys = $evaluation['visible_field_keys'];
        $hiddenGroupKeys = self::hiddenControlledGroupKeys($groups, $controlledGroupKeys, $evaluation['visible_group_keys']);
        return array_values(array_filter($fields, static function ($field) use ($controlledKeys, $visibleKeys, $hiddenGroupKeys, $groups): bool {
            $key = (string) ($field['field_key'] ?? '');
            if (in_array($key, $controlledKeys, true) && !in_array($key, $visibleKeys, true)) {
                return false;
            }
            return !self::fieldBelongsToGroup($field, $hiddenGroupKeys, $groups);
        }));
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, string>
     */
    private static function branchControlledFieldKeys(array $rules, ?string $triggerPageKey = null): array
    {
        $keys = [];
        foreach (FormBranchRule::normalizeRules($rules) as $rule) {
            if ($triggerPageKey !== null && (string) $rule['trigger_page_key'] !== $triggerPageKey) {
                continue;
            }
            if (!empty($rule['enabled']) && $rule['action_type'] === FormBranchRule::ACTION_SHOW_FIELD) {
                if (($rule['target_type'] ?? FormBranchRule::TARGET_FIELD) !== FormBranchRule::TARGET_FIELD) {
                    continue;
                }
                $keys[] = (string) $rule['target_key'];
            }
        }
        return array_values(array_unique($keys));
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, string>
     */
    private static function branchControlledGroupKeys(array $rules, ?string $triggerPageKey = null): array
    {
        $keys = [];
        foreach (FormBranchRule::normalizeRules($rules) as $rule) {
            if ($triggerPageKey !== null && (string) $rule['trigger_page_key'] !== $triggerPageKey) {
                continue;
            }
            if (
                !empty($rule['enabled'])
                && $rule['action_type'] === FormBranchRule::ACTION_SHOW_FIELD
                && ($rule['target_type'] ?? FormBranchRule::TARGET_FIELD) === FormBranchRule::TARGET_GROUP
            ) {
                $keys[] = (string) $rule['target_key'];
            }
        }
        return array_values(array_unique($keys));
    }

    /**
     * @param array<int, array<string, mixed>> $groups
     * @param array<int, string> $controlledGroupKeys
     * @param array<int, string> $visibleGroupKeys
     * @return array<int, string>
     */
    private static function hiddenControlledGroupKeys(array $groups, array $controlledGroupKeys, array $visibleGroupKeys): array
    {
        $hidden = [];
        foreach ($controlledGroupKeys as $groupKey) {
            if (!in_array($groupKey, $visibleGroupKeys, true)) {
                $hidden[] = $groupKey;
            }
        }
        foreach ($groups as $group) {
            if (empty($group['visible'])) {
                $hidden[] = (string) ($group['group_key'] ?? '');
            }
        }
        $hidden = array_values(array_unique(array_filter($hidden, static fn($key): bool => $key !== '')));
        $changed = true;
        while ($changed) {
            $changed = false;
            foreach ($groups as $group) {
                $groupKey = (string) ($group['group_key'] ?? '');
                $parentGroupKey = (string) ($group['parent_group_key'] ?? '');
                if ($groupKey !== '' && $parentGroupKey !== '' && in_array($parentGroupKey, $hidden, true) && !in_array($groupKey, $hidden, true)) {
                    $hidden[] = $groupKey;
                    $changed = true;
                }
            }
        }
        return $hidden;
    }

    /**
     * @param array<string, mixed> $field
     * @param array<int, string> $hiddenGroupKeys
     * @param array<int, array<string, mixed>> $groups
     */
    private static function fieldBelongsToGroup(array $field, array $hiddenGroupKeys, array $groups): bool
    {
        $parentGroupKey = (string) ($field['parent_group_key'] ?? '');
        if ($parentGroupKey === '') {
            return false;
        }
        if (in_array($parentGroupKey, $hiddenGroupKeys, true)) {
            return true;
        }
        $parentByGroup = [];
        foreach ($groups as $group) {
            $groupKey = (string) ($group['group_key'] ?? '');
            if ($groupKey !== '') {
                $parentByGroup[$groupKey] = (string) ($group['parent_group_key'] ?? '');
            }
        }
        $seen = [];
        while ($parentGroupKey !== '') {
            if (isset($seen[$parentGroupKey])) {
                return false;
            }
            $seen[$parentGroupKey] = true;
            if (in_array($parentGroupKey, $hiddenGroupKeys, true)) {
                return true;
            }
            $parentGroupKey = (string) ($parentByGroup[$parentGroupKey] ?? '');
        }
        return false;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, string> $keys
     * @return array<int, array<string, mixed>>
     */
    private static function fieldsByKeys(array $fields, array $keys): array
    {
        $keyMap = array_flip(array_filter(array_map('strval', $keys), static fn($key): bool => $key !== ''));
        return array_values(array_filter($fields, static function ($field) use ($keyMap): bool {
            $key = (string) ($field['field_key'] ?? '');
            return isset($keyMap[$key]) && !empty($field['visible']);
        }));
    }

    private function sendMails(array $form, array $fields, array $values, array $fileMetas): void
    {
        $context = [
            'submitted_at' => date('Y-m-d H:i:s'),
            'form_title'   => $form['title'],
            'ip'           => client_ip(),
        ];
        $mailConfig = $this->resolveFormMailConfig($form);

        // 管理者通知
        $admins = $form['admin_emails'] ?? '';
        $admins = array_filter(array_map('trim', preg_split('/[,;]+/', (string) $admins) ?: []));
        if (!empty($admins)) {
            $subject = !empty($form['mail_subject_admin'])
                ? $form['mail_subject_admin']
                : '[' . $form['title'] . '] 新規送信';
            $template = !empty($form['mail_template_admin'])
                ? $form['mail_template_admin']
                : "フォーム「{{__form_title__}}」に新しい送信がありました。\n受信日時: {{__submitted_at__}}\nIP: {{__ip__}}\n\n{{__all__}}";
            $body = Mailer::renderTemplate($template, $fields, $values, $context);
            Mailer::send($admins, $subject, $body, [], $mailConfig);
        }

        // 自動返信
        if (!empty($form['reply_enabled']) && !empty($form['reply_from_field_key'])) {
            $to = $values[$form['reply_from_field_key']] ?? null;
            if (is_array($to)) {
                $to = reset($to);
            }
            if (is_string($to) && filter_var($to, FILTER_VALIDATE_EMAIL)) {
                $subject  = (string) ($form['reply_subject'] ?? '送信ありがとうございました');
                $template = (string) ($form['reply_template'] ?? "お問い合わせいただきありがとうございました。\n以下の内容で受け付けました。\n\n{{__all__}}");
                $body = Mailer::renderTemplate($template, $fields, $values, $context);

                Mailer::send($to, $subject, $body, [], $mailConfig);
            }
        }
    }

    /**
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    private function resolveFormMailConfig(array $form): array
    {
        return [
            'transport' => (string) ($form['mail_transport'] ?? config('mail.transport', 'mail')),
            'from_email' => (string) ($form['mail_from_email'] ?? config('mail.from_email', 'noreply@example.com')),
            'from_name' => (string) ($form['mail_from_name'] ?? config('mail.from_name', '')),
            'smtp' => [
                'host' => (string) ($form['mail_smtp_host'] ?? config('mail.smtp.host', '')),
                'port' => (int) ($form['mail_smtp_port'] ?? config('mail.smtp.port', 25)),
                'secure' => (string) ($form['mail_smtp_secure'] ?? config('mail.smtp.secure', '')),
                'username' => (string) ($form['mail_smtp_username'] ?? config('mail.smtp.username', '')),
                'password' => (string) ($form['mail_smtp_password'] ?? config('mail.smtp.password', '')),
                'timeout' => (int) ($form['mail_smtp_timeout'] ?? config('mail.smtp.timeout', 10)),
                'ehlo_host' => (string) ($form['mail_smtp_ehlo_host'] ?? config('mail.smtp.ehlo_host', '')),
                'verify_peer' => !array_key_exists('mail_smtp_verify_peer', $form)
                    ? !empty(config('mail.smtp.verify_peer', true))
                    : !empty($form['mail_smtp_verify_peer']),
                'verify_peer_name' => !array_key_exists('mail_smtp_verify_peer_name', $form)
                    ? !empty(config('mail.smtp.verify_peer_name', true))
                    : !empty($form['mail_smtp_verify_peer_name']),
                'allow_self_signed' => !array_key_exists('mail_smtp_allow_self_signed', $form)
                    ? !empty(config('mail.smtp.allow_self_signed', false))
                    : !empty($form['mail_smtp_allow_self_signed']),
            ],
        ];
    }

    private function isSiteResourceBlocked(): bool
    {
        return SiteResource::isExceeded();
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     * @param array<string, list<string>> $errors
     */
    private function renderShow(array $form, array $fields, array $values = [], array $errors = [], ?array $inputPage = null, ?array $inputPages = null, ?array $branchRules = null, ?array $fieldGroups = null): void
    {
        $inputPages = $inputPages ?? FormInputPage::forForm((int) ($form['id'] ?? 0), $form);
        $branchRules = $branchRules ?? FormBranchRule::forForm((int) ($form['id'] ?? 0));
        $fieldGroups = $fieldGroups ?? FormFieldGroup::forForm((int) ($form['id'] ?? 0), true);
        $inputPage = $inputPage ?? ($inputPages[0] ?? FormInputPage::defaultPage($form));
        $inputPageTitle = trim((string) ($inputPage['title'] ?? '')) !== ''
            ? (string) $inputPage['title']
            : (string) ($form['title'] ?? 'フォーム');
        $inputPageKey = (string) ($inputPage['page_key'] ?? FormInputPage::DEFAULT_KEY);
        $firstPageKey = (string) (($inputPages[0]['page_key'] ?? null) ?: FormInputPage::DEFAULT_KEY);
        $inputPageFields = FormField::forInputPage($fields, $inputPageKey);
        $inputPageGroups = FormFieldGroup::forInputPage($fieldGroups, $inputPageKey);
        $branchEvaluation = FormBranchRule::evaluate($branchRules, $values, $inputPageKey);
        $pending = $_SESSION['_pending_submission'] ?? null;
        $canBackInput = is_array($pending)
            && (int) ($pending['form_id'] ?? 0) === (int) ($form['id'] ?? 0)
            && $inputPageKey !== $firstPageKey
            && count((array) ($pending['page_history'] ?? [])) > 0;

        $this->view->render('front/form/show', [
            'title'      => $inputPageTitle,
            'form'       => $form,
            'fields'     => $fields,
            'inputPages' => $inputPages,
            'inputPage'  => $inputPage,
            'inputPageFields' => $inputPageFields,
            'fieldGroups' => $fieldGroups,
            'inputPageGroups' => $inputPageGroups,
            'branchRules' => $branchRules,
            'branchControlledFieldKeys' => self::branchControlledFieldKeys($branchRules, $inputPageKey),
            'branchControlledGroupKeys' => self::branchControlledGroupKeys($branchRules, $inputPageKey),
            'branchVisibleFieldKeys' => $branchEvaluation['visible_field_keys'],
            'branchVisibleGroupKeys' => $branchEvaluation['visible_group_keys'],
            'canBackInput' => $canBackInput,
            'values'     => $values,
            'errors'     => $errors,
        ], 'public');
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    private function renderShowBlocked(array $form, array $fields, array $values = [], ?array $inputPage = null, ?array $inputPages = null, ?array $branchRules = null, ?array $fieldGroups = null): void
    {
        $inputPages = $inputPages ?? FormInputPage::forForm((int) ($form['id'] ?? 0), $form);
        $branchRules = $branchRules ?? FormBranchRule::forForm((int) ($form['id'] ?? 0));
        $fieldGroups = $fieldGroups ?? FormFieldGroup::forForm((int) ($form['id'] ?? 0), true);
        $inputPage = $inputPage ?? ($inputPages[0] ?? FormInputPage::defaultPage($form));
        $inputPageTitle = trim((string) ($inputPage['title'] ?? '')) !== ''
            ? (string) $inputPage['title']
            : (string) ($form['title'] ?? 'フォーム');
        $inputPageKey = (string) ($inputPage['page_key'] ?? FormInputPage::DEFAULT_KEY);
        $firstPageKey = (string) (($inputPages[0]['page_key'] ?? null) ?: FormInputPage::DEFAULT_KEY);
        $inputPageFields = FormField::forInputPage($fields, $inputPageKey);
        $inputPageGroups = FormFieldGroup::forInputPage($fieldGroups, $inputPageKey);
        $branchEvaluation = FormBranchRule::evaluate($branchRules, $values, $inputPageKey);
        $pending = $_SESSION['_pending_submission'] ?? null;
        $canBackInput = is_array($pending)
            && (int) ($pending['form_id'] ?? 0) === (int) ($form['id'] ?? 0)
            && $inputPageKey !== $firstPageKey
            && count((array) ($pending['page_history'] ?? [])) > 0;

        $this->view->render('front/form/show', [
            'title'                 => $inputPageTitle,
            'form'                  => $form,
            'fields'                => $fields,
            'inputPages'            => $inputPages,
            'inputPage'             => $inputPage,
            'inputPageFields'       => $inputPageFields,
            'fieldGroups'           => $fieldGroups,
            'inputPageGroups'       => $inputPageGroups,
            'branchRules'           => $branchRules,
            'branchControlledFieldKeys' => self::branchControlledFieldKeys($branchRules, $inputPageKey),
            'branchControlledGroupKeys' => self::branchControlledGroupKeys($branchRules, $inputPageKey),
            'branchVisibleFieldKeys' => $branchEvaluation['visible_field_keys'],
            'branchVisibleGroupKeys' => $branchEvaluation['visible_group_keys'],
            'canBackInput'            => $canBackInput,
            'values'                => $values,
            'errors'                => [],
            'site_resource_blocked' => true,
        ], 'public');
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $pending
     */
    private function renderConfirmBlocked(array $form, array $fields, array $pending): void
    {
        $this->view->render('front/form/confirm', [
            'title'                 => trim((string) ($form['confirm_page_title'] ?? '')) !== ''
                ? (string) $form['confirm_page_title']
                : '入力内容のご確認',
            'form'                  => $form,
            'fields'                => $fields,
            'values'                => $pending['values'] ?? [],
            'fileMetas'             => $pending['file_metas'] ?? [],
            'site_resource_blocked' => true,
        ], 'public');
    }

    private function notFound(): void
    {
        http_response_code(404);
        (new View())->render('front/404', ['title' => 'Not Found'], 'public');
    }
}
