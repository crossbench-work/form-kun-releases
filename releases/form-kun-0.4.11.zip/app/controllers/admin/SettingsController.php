<?php
namespace Controllers\Admin;

use Core\AppUpdater;
use Core\Auth;
use Core\Csrf;
use Core\FieldKey;
use Core\SiteResource;
use Core\View;
use Models\AppSetting;
use Models\Form;
use Models\FormField;
use Models\FormFieldGroup;
use Models\FormFieldTemplate;

class SettingsController
{
    public function index(): void
    {
        Auth::requireLogin();

        $resource = SiteResource::snapshot();

        $data = [
            'title'               => '設定',
            'form_count'          => Form::count(),
            'max_forms'           => effective_max_forms(),
            'storage_used_uploads' => $resource['used_uploads'],
            'storage_used_db'     => $resource['used_db'],
            'storage_used_total'  => $resource['used_total'],
            'storage_max'         => $resource['max'],
            'storage_percent'     => $resource['percent'],
            'storage_warning'     => $resource['warning'],
            'storage_exceeded'    => $resource['exceeded'],
            'storage_max_mb'      => (int) max(1, (int) round($resource['max'] / 1024 / 1024)),
            'storage_resource'     => $resource,
            'field_templates'       => FormFieldTemplate::all(),
        ];

        if (Auth::role() === 'admin') {
            $showManifestUi = (bool) config('update.show_manifest_ui', false);
            $manifest = null;
            $manifestError = '';
            if ($showManifestUi && AppUpdater::isEnabled()) {
                $result = AppUpdater::fetchManifest();
                if ($result['ok']) {
                    $manifest = $result['manifest'];
                } else {
                    $manifestError = $result['message'];
                }
            }

            $data['show_manifest_ui'] = $showManifestUi;
            $data['currentVersion'] = AppUpdater::currentVersion();
            $data['requirements'] = AppUpdater::requirements();
            $data['manifest'] = $manifest;
            $data['manifestError'] = $manifestError;
            $data['update_enabled'] = effective_update_enabled();
            $data['update_manifest_url'] = effective_update_manifest_url();
            $data['update_enabled_db_set'] = self::appSettingIsSet(AppSetting::KEY_UPDATE_ENABLED);
            $data['update_manifest_url_db_set'] = self::appSettingIsSet(AppSetting::KEY_UPDATE_MANIFEST_URL);
            $data['releases_page_url'] = update_releases_page_url();
            $data['manual_upload_max_bytes'] = AppUpdater::manualUploadMaxBytes();
        }

        (new View())->render('admin/settings/index', $data, 'admin');
    }

    public function storeTemplate(): void
    {
        Auth::requireLogin();
        Csrf::verify();

        $payload = $this->collectTemplatePayload();
        FormFieldTemplate::create($payload['title'], $payload['fields'], $payload['field_groups']);
        flash('success', 'テンプレートを保存しました。');
        redirect('/admin/settings#settings-templates');
    }

    public function updateTemplate(int $id): void
    {
        Auth::requireLogin();
        Csrf::verify();

        if (FormFieldTemplate::find($id) === null) {
            flash('danger', 'テンプレートが見つかりません。');
            redirect('/admin/settings#settings-template-editor');
        }

        $payload = $this->collectTemplatePayload();
        FormFieldTemplate::update($id, $payload['title'], $payload['fields'], $payload['field_groups']);
        flash('success', 'テンプレートを保存しました。');
        redirect('/admin/settings#settings-templates');
    }

    public function deleteTemplate(int $id): void
    {
        Auth::requireLogin();
        Csrf::verify();
        FormFieldTemplate::delete($id);
        flash('success', 'テンプレートを削除しました。');
        redirect('/admin/settings#settings-templates');
    }

    public function templateJson(string $id): void
    {
        Auth::requireLogin();
        $template = FormFieldTemplate::findTemplate($id);
        if ($template === null) {
            http_response_code(404);
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode(['ok' => false, 'message' => 'テンプレートが見つかりません。'], JSON_UNESCAPED_UNICODE);
            return;
        }
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'ok' => true,
            'template' => [
                'id' => $template['id'],
                'title' => (string) $template['title'],
                'fields' => $template['fields'],
                'field_groups' => $template['field_groups'],
            ],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function update(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $raw = trim((string) ($_POST['max_forms'] ?? ''));
        $v = filter_var($raw, FILTER_VALIDATE_INT);
        if ($v === false || $v < 1 || $v > 999999) {
            flash('danger', 'フォームの作成上限は 1 から 999999 までの整数で入力してください。');
            redirect('/admin/settings');
        }

        AppSetting::set(AppSetting::KEY_MAX_FORMS, (string) $v);
        flash('success', 'フォームの作成上限を保存しました。');
        redirect('/admin/settings');
    }

    public function updateSiteResource(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $raw = trim((string) ($_POST['max_site_resource_mb'] ?? ''));
        $v = filter_var($raw, FILTER_VALIDATE_INT);
        if ($v === false || $v < 1 || $v > 1048576) {
            flash('danger', '使用リソースの上限は 1 から 1048576 MB までの整数で入力してください。');
            redirect('/admin/settings');
        }

        AppSetting::set(AppSetting::KEY_MAX_SITE_RESOURCE_BYTES, (string) ($v * 1024 * 1024));
        flash('success', '使用リソースの上限を保存しました。');
        redirect('/admin/settings');
    }

    public function updateUpdateConfig(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $enabled = isset($_POST['update_enabled']) && (string) $_POST['update_enabled'] === '1';
        $manifestUrl = trim((string) ($_POST['update_manifest_url'] ?? ''));

        if ($enabled && $manifestUrl === '') {
            flash('danger', '自己更新を有効にする場合は manifest URL を入力してください。');
            redirect('/admin/settings#app-update');
        }

        if ($manifestUrl !== '' && filter_var($manifestUrl, FILTER_VALIDATE_URL) === false) {
            flash('danger', 'manifest URL の形式が正しくありません。');
            redirect('/admin/settings#app-update');
        }

        if ($manifestUrl !== '' && parse_url($manifestUrl, PHP_URL_SCHEME) !== 'https') {
            flash('danger', 'manifest URL は HTTPS のみ利用できます。');
            redirect('/admin/settings#app-update');
        }

        AppSetting::set(AppSetting::KEY_UPDATE_ENABLED, $enabled ? '1' : '0');
        AppSetting::set(AppSetting::KEY_UPDATE_MANIFEST_URL, $manifestUrl);

        flash('success', 'アプリ更新の設定を保存しました。');
        redirect('/admin/settings#app-update');
    }

    /**
     * @return array{title:string, fields:array<int, array<string, mixed>>, field_groups:array<int, array<string, mixed>>}
     */
    private function collectTemplatePayload(): array
    {
        return [
            'title' => FormFieldTemplate::normalizeTitle((string) ($_POST['title'] ?? '')),
            'fields' => $this->collectTemplateFields(),
            'field_groups' => $this->collectTemplateGroups(),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function collectTemplateFields(): array
    {
        $raw = $_POST['fields'] ?? [];
        $fields = [];
        if (!is_array($raw)) {
            return [];
        }
        foreach ($raw as $f) {
            if (!is_array($f) || !empty($f['_remove'])) {
                continue;
            }
            $type = FormField::sanitizeType((string) ($f['type'] ?? 'text_multi'));
            $isDisplayOnly = FormField::isDisplayOnlyType($type);
            $required = (!$isDisplayOnly && !empty($f['required'])) ? 1 : 0;
            $regex = trim((string) ($f['regex_pattern'] ?? ''));
            if ($required !== 1 || $isDisplayOnly || in_array($type, ['radio', 'select'], true)) {
                $regex = '';
            }
            $regexStored = $regex !== '' ? FormField::encodeRegexPatterns([$regex]) : null;
            $fields[] = [
                'input_page_key' => FormField::sanitizeInputPageKey((string) ($f['input_page_key'] ?? 'input-1')),
                'parent_group_key' => FormFieldGroup::sanitizeGroupKey((string) ($f['parent_group_key'] ?? '')) ?: null,
                'sort_order' => isset($f['sort_order']) && is_numeric($f['sort_order']) ? (int) $f['sort_order'] : count($fields) + 1,
                'field_key' => trim((string) ($f['field_key'] ?? '')) !== '' ? trim((string) $f['field_key']) : FieldKey::generateUuidV4(),
                'label' => trim((string) ($f['label'] ?? '')),
                'show_label' => !empty($f['show_label']) ? 1 : 0,
                'visible' => !array_key_exists('visible', $f) || !empty($f['visible']) ? 1 : 0,
                'type' => $type,
                'required' => $required,
                'max_length' => isset($f['max_length']) && $f['max_length'] !== '' && !$isDisplayOnly && !in_array($type, ['radio', 'checkbox', 'select'], true) ? (int) $f['max_length'] : '',
                'regex' => $regexStored,
                'regex_pattern' => $regex,
                'help_text' => trim((string) ($f['help_text'] ?? '')),
                'help_text_is_html' => !empty($f['help_text_is_html']) ? 1 : 0,
                'placeholder' => (!$isDisplayOnly && !in_array($type, ['radio', 'checkbox', 'select', 'text_multi'], true)) ? trim((string) ($f['placeholder'] ?? '')) : '',
                'multi_text_items' => (string) ($f['multi_text_items'] ?? ''),
                'checkbox_limit_enabled' => ($type === 'checkbox' && $required === 1 && !empty($f['checkbox_limit_enabled'])) ? 1 : 0,
                'checkbox_min_selections' => isset($f['checkbox_min_selections']) ? (string) $f['checkbox_min_selections'] : '',
                'checkbox_max_selections' => isset($f['checkbox_max_selections']) ? (string) $f['checkbox_max_selections'] : '',
                'options' => (string) ($f['options'] ?? ''),
            ];
        }
        return $fields;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function collectTemplateGroups(): array
    {
        $raw = $_POST['field_groups'] ?? [];
        $groups = [];
        if (!is_array($raw)) {
            return [];
        }
        foreach ($raw as $i => $group) {
            if (!is_array($group) || !empty($group['_remove'])) {
                continue;
            }
            $groupKey = FormFieldGroup::sanitizeGroupKey((string) ($group['group_key'] ?? ''));
            if ($groupKey === '') {
                $groupKey = FieldKey::generateUuidV4();
            }
            $parentGroupKey = FormFieldGroup::sanitizeGroupKey((string) ($group['parent_group_key'] ?? ''));
            if ($parentGroupKey === $groupKey) {
                $parentGroupKey = '';
            }
            $groups[] = [
                'input_page_key' => FormField::sanitizeInputPageKey((string) ($group['input_page_key'] ?? 'input-1')),
                'parent_group_key' => $parentGroupKey !== '' ? $parentGroupKey : null,
                'sort_order' => isset($group['sort_order']) && is_numeric($group['sort_order']) ? (int) $group['sort_order'] : (int) $i + 1,
                'group_key' => $groupKey,
                'label' => trim((string) ($group['label'] ?? '')),
                'show_label' => !empty($group['show_label']) ? 1 : 0,
                'description' => trim((string) ($group['description'] ?? '')),
                'visible' => !array_key_exists('visible', $group) || !empty($group['visible']) ? 1 : 0,
            ];
        }
        return $groups;
    }

    private static function appSettingIsSet(string $key): bool
    {
        $raw = AppSetting::get($key);
        return $raw !== null && $raw !== '';
    }
}
