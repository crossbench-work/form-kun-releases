<?php

$showManifestUi = !empty($show_manifest_ui);
$latest = is_array($manifest ?? null) ? (string) ($manifest['latest'] ?? '') : '';
$releases = is_array($manifest ?? null) ? ($manifest['releases'] ?? []) : [];
$requirements = is_array($requirements ?? null) ? $requirements : [];
$releasesPageUrl = (string) ($releases_page_url ?? update_releases_page_url());
$manualUploadMaxBytes = (int) ($manual_upload_max_bytes ?? \Core\AppUpdater::manualUploadMaxBytes());
$currentVersionStr = (string) ($currentVersion ?? '');
$canApplyFromServer = !empty($requirements['enabled']) && !empty($requirements['zip']);
?>
<div id="app-update">
<?php if ($showManifestUi): ?>
<?php admin_c_form_block01_open(); ?>
            <div class="block is-title">
                <?php admin_m_large_title01('サーバーから更新'); ?>
            </div>
            <div class="block is-field">
                <form method="post" action="<?= e(base_path('/admin/settings/update-config')) ?>">
                    <?= \Core\Csrf::field() ?>
                    <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title">
                        <?php admin_m_bold_title01(e('自己更新'), 'update_enabled'); ?>
                    </div>
                    <div class="area is-field">
                        <?php admin_m_checkbox01('有効にする', admin_m_input01_attrs_with_bound_label('update_enabled', [
                            'name' => 'update_enabled',
                            'id' => 'update_enabled',
                            'value' => '1',
                            'checked' => !empty($update_enabled),
                        ])); ?>
                    </div>
                    <?php if (empty($update_enabled_db_set)): ?>
                        <div class="area is-help">
                            <p class="text is-help">未保存のときは config.local.php の <code>update.enabled</code> が使われます。</p>
                        </div>
                    <?php endif; ?>
                    <?php admin_m_input_set01_close(); ?>

                    <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title">
                        <?php admin_m_bold_title01(e('manifest URL'), 'update_manifest_url'); ?>
                    </div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('update_manifest_url', [
                            'type' => 'url',
                            'name' => 'update_manifest_url',
                            'id' => 'update_manifest_url',
                            'value' => (string) ($update_manifest_url ?? ''),
                            'placeholder' => 'https://raw.githubusercontent.com/.../manifest.json',
                            'autocomplete' => 'off',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                    <?php if (empty($update_manifest_url_db_set)): ?>
                        <div class="area is-help">
                            <p class="text is-help">未保存のときは config.local.php の <code>update.manifest_url</code> が使われます。</p>
                        </div>
                    <?php endif; ?>
                    <?php admin_m_input_set01_close(); ?>

                    <p class="text is-help">HTTPS の manifest のみ利用できます。ZIP には環境設定を含めません。</p>
                    <div class="area is-actions">
                        <button type="submit" class="btn is-primary">更新設定を保存</button>
                    </div>
                </form>
            </div>
<?php admin_c_form_block01_close(); ?>

<?php admin_c_form_block01_open(); ?>
            <div class="block is-title">
                <?php admin_m_large_title01('リリース'); ?>
            </div>
            <div class="block is-field">
                <?php
                admin_settings_value_text01('現在のバージョン', 'settings_update_current_version', $currentVersionStr);
                if ($latest !== '' && $latest !== $currentVersionStr) {
                    admin_settings_value_text01('最新リリース', 'settings_update_latest_version', $latest);
                }
                admin_settings_value_text01('ZipArchive', 'settings_update_ziparchive', !empty($requirements['zip']) ? '利用可' : '不可（サーバー拡張が必要）');
                if ($releasesPageUrl !== '') {
                    admin_m_input_set01_open();
                    echo '<div class="area is-title">';
                    admin_m_bold_title01(e('リリースのダウンロード'), 'settings_update_releases_url');
                    echo '</div>';
                    echo '<div class="area is-field">';
                    echo '<p class="text is-help"><a href="' . e($releasesPageUrl) . '" target="_blank" rel="noopener noreferrer">バージョン一覧ページを開く</a></p>';
                    echo '</div>';
                    admin_m_input_set01_close();
                }
                ?>

                <?php if (($manifestError ?? '') !== ''): ?>
                    <p data-module="m-text01" data-type="danger"><?= e($manifestError) ?></p>
                <?php endif; ?>

                <?php if (is_array($manifest) && $releases !== []): ?>
                    <?php if (!$canApplyFromServer): ?>
                        <p data-module="m-text01" data-type="muted">リリース一覧は参照のみです。「自己更新」を有効にするとサーバーから適用できます。</p>
                    <?php elseif ($canApplyFromServer && $latest !== '' && $latest !== $currentVersionStr): ?>
                        <div class="area is-actions">
                            <form method="post" action="<?= e(base_path('/admin/settings/update')) ?>" onsubmit="return confirm('バージョン <?= e($latest) ?> に更新します。よろしいですか？');">
                                <?= \Core\Csrf::field() ?>
                                <input type="hidden" name="version" value="<?= e($latest) ?>">
                                <button type="submit" class="btn is-primary">最新版（<?= e($latest) ?>）に更新</button>
                            </form>
                        </div>
                    <?php endif; ?>
                    <h3 class="title is-sm">利用可能なリリース（channel: <?= e((string) ($manifest['channel'] ?? '')) ?>）</h3>
                    <table class="m-table01">
                        <thead>
                            <tr><th>版</th><th>日付</th><th>メモ</th><th></th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($releases as $row): ?>
                                <?php if (!is_array($row)) continue; ?>
                                <tr>
                                    <td><code><?= e((string) ($row['version'] ?? '')) ?></code></td>
                                    <td><?= e((string) ($row['released_at'] ?? '')) ?></td>
                                    <td><?= e((string) ($row['notes'] ?? '')) ?></td>
                                    <td>
                                        <?php if ($canApplyFromServer && ($row['version'] ?? '') !== $currentVersionStr): ?>
                                            <form method="post" action="<?= e(base_path('/admin/settings/update')) ?>" onsubmit="return confirm('バージョン <?= e((string) $row['version']) ?> に更新します。よろしいですか？');">
                                                <?= \Core\Csrf::field() ?>
                                                <input type="hidden" name="version" value="<?= e((string) $row['version']) ?>">
                                                <button type="submit" class="btn is-primary is-sm">この版に更新</button>
                                            </form>
                                        <?php else: ?>
                                            <span data-module="m-text01" data-type="muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php elseif (($manifestError ?? '') === '' && trim((string) ($update_manifest_url ?? '')) === ''): ?>
                    <p data-module="m-text01" data-type="muted">manifest URL を設定して保存すると、リリース一覧を表示します。</p>
                <?php elseif (($manifestError ?? '') === ''): ?>
                    <p data-module="m-text01" data-type="muted">manifest を取得できませんでした。</p>
                <?php endif; ?>
            </div>
<?php admin_c_form_block01_close(); ?>
<?php endif; ?>

<div id="app-update-manual">
<?php admin_c_form_block01_open(); ?>
            <div class="block is-title">
                <?php admin_m_large_title01($showManifestUi ? '手動 ZIP で更新' : 'バージョン'); ?>
            </div>
            <div class="block is-field">
                <?php
                if (!$showManifestUi) {
                    admin_settings_value_text01('現在のバージョン', 'settings_update_manual_current_version', $currentVersionStr);
                    admin_settings_value_text01('ZipArchive', 'settings_update_manual_ziparchive', !empty($requirements['zip']) ? '利用可' : '不可（サーバー拡張が必要）');
                    if ($releasesPageUrl !== '') {
                        admin_m_input_set01_open();
                        echo '<div class="area is-title">';
                        admin_m_bold_title01(e('リリースのダウンロード'), 'settings_update_releases_url');
                        echo '</div>';
                        echo '<div class="area is-field">';
                        echo '<p class="text is-help"><a href="' . e($releasesPageUrl) . '" target="_blank" rel="noopener noreferrer">バージョン一覧ページを開く</a></p>';
                        echo '</div>';
                        admin_m_input_set01_close();
                    }
                }
                ?>
                <?php if (empty($requirements['zip'])): ?>
                    <p data-module="m-text01" data-type="danger">ZipArchive 拡張が無効のため、手動アップロードは利用できません。</p>
                <?php else: ?>
                    <form method="post" action="<?= e(base_path('/admin/settings/update-upload')) ?>" enctype="multipart/form-data" data-module="c-updateUpload01" data-max-bytes="<?= (int) $manualUploadMaxBytes ?>">
                        <?= \Core\Csrf::field() ?>
                        <?php admin_c_update_upload01_zone(); ?>
                        <div class="area is-actions">
                            <?php admin_m_btn01_button_wrap('ZIP を適用して更新', [
                                'type' => 'submit',
                                'class' => 'is-primary',
                                'data-target' => 'c-updateUpload01__submit',
                            ]); ?>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
<?php admin_c_form_block01_close(); ?>
</div>
</div>
