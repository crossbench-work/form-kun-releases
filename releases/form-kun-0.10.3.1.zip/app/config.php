<?php
// app/config.php
// 直接アクセスを防止
if (!defined('FORMKUN_BOOT')) {
    http_response_code(404);
    exit;
}

$config = [
    // production / staging / local。debug の画面表示は local のときだけ許可する。
    'environment' => 'production',
    // environment=local と併用したときだけPHPエラーと未捕捉例外を画面表示する。
    'debug'      => false,

    // データベース接続情報
    'db' => [
        'host'     => 'localhost',
        'port'     => 3306,
        'name'     => 'formkun',
        'user'     => 'formkun',
        'password' => 'change-me',
        'charset'  => 'utf8mb4',
    ],

    // サイト基本設定
    'site' => [
        // 公開URL（末尾スラッシュなし）。例: https://example.com
        'base_url'   => '',
        // サブディレクトリ運用時はここに（例: '/formkun'）。ドキュメントルート直下なら ''
        'base_path'  => '',
        // 管理画面のサイト名表示
        'admin_name' => 'ふぉーむくん',
        // タイムゾーン
        'timezone'   => 'Asia/Tokyo',
        // ロケール
        'locale'     => 'ja_JP.UTF-8',
    ],

    // メール送信設定
    'mail' => [
        // mail() / mb_send_mail() を使う場合は mail、SMTP サーバーへ直接送る場合は smtp
        'transport' => 'mail',
        // From に使うメールアドレス（管理者通知や自動返信の差出人）
        'from_email' => 'noreply@example.com',
        'from_name'  => 'ふぉーむくん',
        'smtp' => [
            'enabled' => false,
            'host' => '127.0.0.1',
            'port' => 1025,
            // '', 'ssl', 'tls' のいずれか
            'secure' => '',
            'username' => '',
            'password' => '',
            'timeout' => 10,
            'ehlo_host' => 'localhost',
            'verify_peer' => true,
            'verify_peer_name' => true,
            'allow_self_signed' => false,
        ],
        // パスワード再設定メール（{{reset_url}} を置換）
        'password_reset_subject' => '[ふぉーむくん] パスワード再設定のご案内',
        'password_reset_body'    => "管理画面へログインするパスワードを再設定するには、次のURLにアクセスしてください（1時間以内）。\n\n{{reset_url}}\n\n心当たりがない場合はこのメールを無視してください。",
    ],

    // 運用上限（管理画面の設定で DB に保存した値があればそちらを優先）
    'limits' => [
        // 作成できるフォーム数の既定上限（1 以上）
        'max_forms' => 50,
        // 添付ファイル + DB の合計使用量の既定上限（bytes）
        'max_site_resource_bytes' => 2 * 1024 * 1024 * 1024,
        // ダッシュボード警告を出す使用率（0.0〜1.0）
        'resource_warning_ratio' => 0.8,
    ],

    // 送信履歴の期間エクスポート
    'submissions' => [
        // 一度にエクスポートできる最大件数
        'export_max_rows' => 10000,
        // 添付ファイルを ZIP に含めるときの合計容量の上限（bytes）
        'export_max_attachment_bytes' => 500 * 1024 * 1024,
        // インポートでアップロードできる ZIP の最大サイズ（bytes）。PHP の upload_max_filesize / post_max_size も適用される
        'import_max_bytes' => 500 * 1024 * 1024,
    ],

    // ファイルアップロード設定
    'upload' => [
        // bytes 単位の上限（既定 5MB）
        'max_size' => 5 * 1024 * 1024,
        // 許可拡張子（小文字）
        'allowed_extensions' => [
            'jpg', 'jpeg', 'png', 'gif', 'webp',
            'pdf', 'txt', 'csv',
            'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
            'zip',
        ],
        // 画像添付のサーバー側リサイズ・軽量化（GD 必須）
        'image' => [
            'enabled'           => true,
            'max_width'         => 1280,
            'max_height'        => 1280,
            'jpeg_quality'      => 82,
            'webp_quality'      => 80,
            'png_compression'   => 6,
            'try_webp'          => true,
        ],
    ],

    // セッション設定
    'session' => [
        'name'     => 'FORMKUNSESSID',
        'lifetime' => 60 * 60 * 4, // 4時間
        // Cookie の Secure フラグ。null のとき実際の HTTPS 接続のみ true（推奨）
        // true/false で固定も可（HTTP のローカルでは false が必要なことがあります）
        'cookie_secure' => null,
        // true のときだけ X-Forwarded-Proto: https を Secure 判定に使う（TLS 終端プロキシの背後用）
        // 既定 false（ヘッダは偽装可能なため。ローカルで誤って Secure Cookie になりログインできなくなるのを防ぐ）
        'trust_forwarded_proto' => false,
    ],

    // アプリ自己更新（本番の値は config.local.php のみ。ZIP には含めない）
    'update' => [
        'enabled' => true,
        'manifest_url' => 'https://crossbench-work.github.io/form-kun-releases/releases/manifest.json',
        'allowed_hosts' => ['crossbench-work.github.io'],
        'manual_upload_max_bytes' => 64 * 1024 * 1024,
        'manual_upload_max_files' => 5000,
        'show_manifest_ui' => true,
        'releases_page_url' => 'https://crossbench-work.github.io/form-kun-releases/',
    ],

    // セキュリティ
    'security' => [
        // 管理画面ログインの連続失敗ロック（同IPからの試行）
        'login_max_attempts'    => 5,
        'login_lockout_seconds' => 600, // 10分
        // 同一ユーザー名への分散IP攻撃を抑止（直近の成功後の失敗だけを集計）
        'login_username_max_attempts' => 10,
        'login_username_lockout_seconds' => 600,
        // パスワード再設定リンクの有効時間（秒）
        'password_reset_ttl_seconds'       => 3600,
        // 「パスワードを忘れた」送信（同一ブラウザセッションあたり・約1時間）
        'password_reset_forgot_max_per_hour' => 5,
        // 公開フォーム（/f/{slug}）の確認・送信回数の上限（同一IP・フォームごと）
        'public_form_rate_limit_count'          => 20,
        'public_form_rate_limit_window_seconds' => 600,
    ],

    // Embed API の送信元IP国判定（本番トークンは config.local.php のみ）
    'ip_geolocation' => [
        'ipinfo_token' => '',
        'timeout_seconds' => 5,
        'cache_ttl_seconds' => 86400,
    ],

    // LINE 通知（`{{__all__}}` 画像 Push 用の署名付き公開 URL。鍵は config.local.php のみ）
    'line' => [
        'public_file_signing_key' => '',
        'public_file_ttl_seconds' => 604800,
    ],
];

// ローカル用上書き（Git に含めない）：このファイルを複製して編集
// env/local/config.local.php または config.local.example.php を参照
$localPath = __DIR__ . '/config.local.php';
if (is_file($localPath)) {
    $local = require $localPath;
    if (is_array($local)) {
        $config = array_replace_recursive($config, $local);
    }
}

return $config;
