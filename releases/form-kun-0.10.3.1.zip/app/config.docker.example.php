<?php
/**
 * Docker（docker-compose）用の設定例。
 *
 * コンテナ内から DB に繋ぐときホスト名はサービス名の「db」です。
 *
 *   cp src/app/config.docker.example.php env/local/config.local.php
 *
 * ポートやパスワードを docker-compose.yml / .env と揃えてください。
 */
return [
    'environment' => 'local',
    'debug' => true,
    'db' => [
        'host'     => 'db',
        'port'     => 3306,
        'name'     => 'formkun',
        'user'     => 'formkun',
        'password' => 'formkun',
    ],
    'site' => [
        // ホストのブラウザからアクセスする URL（compose の HOST_WEB_PORT と一致）
        'base_url'  => 'http://localhost:8080',
        'base_path' => '',
    ],
    'mail' => [
        // compose 同梱の Mailpit で受信する（Web UI: http://localhost:MAILPIT_WEB_PORT）
        'transport' => 'smtp',
        'smtp' => [
            'enabled' => true,
            'host' => 'mailpit',
            'port' => 1025,
            'secure' => '',
            'username' => '',
            'password' => '',
            'timeout' => 10,
            'ehlo_host' => 'localhost',
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
        ],
    ],
];
