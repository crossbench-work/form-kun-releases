<h1 class="title">アカウント設定</h1>

<?php if (!empty($errors)): ?>
    <div data-module="m-alert01" class="is-danger">
        <ul><?php foreach ($errors as $msg): ?><li><?= e($msg) ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<form method="post" action="<?= e(base_path('/admin/account')) ?>" class="block is-contents">
    <?= \Core\Csrf::field() ?>

    <?php require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php'; ?>
    <?php admin_c_form_block01_open(); ?>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01(e('ログインID'), 'account-username'); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('account-username', [
                            'type' => 'text',
                            'id' => 'account-username',
                            'value' => (string) $user['username'],
                            'disabled' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>

        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01(e('表示名'), 'account-display_name'); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('account-display_name', [
                            'type' => 'text',
                            'id' => 'account-display_name',
                            'name' => 'display_name',
                            'value' => (string) ($user['display_name'] ?? ''),
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>

        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01(e('メールアドレス（任意）'), 'account-email'); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('account-email', [
                            'type' => 'email',
                            'id' => 'account-email',
                            'name' => 'email',
                            'value' => (string) ($user['email'] ?? ''),
                            'autocomplete' => 'email',
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">「パスワードを忘れたとき」に再設定リンクを送るために使用します。</p>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>

        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01(e('ロール'), 'account-role'); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('account-role', [
                            'type' => 'text',
                            'id' => 'account-role',
                            'value' => (string) \Core\Auth::roleLabel(),
                            'disabled' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
    <?php admin_c_form_block01_close(); ?>

    <div class="area is-actions">
        <?php admin_m_btn01_button_wrap('保存する', ['type' => 'submit', 'class' => 'is-primary']); ?>
    </div>
</form>

<?php if (!empty($webauthnAvailable)): ?>
    <section class="block is-contents" data-module="adminAccountPasskeys01" style="margin-top: 2rem;">
        <h2 class="title is-sub">パスキー</h2>
        <p class="text is-help">この端末やパスワードマネージャーに登録したパスキーで、ログインIDを入力したうえでログインできます。</p>

        <div data-admin-webauthn-message hidden data-module="m-alert01" class="is-danger" style="margin-top: 12px;"></div>

        <div class="area is-actions" style="margin-top: 12px;">
            <?php admin_m_btn01_button_wrap('パスキーを追加', [
                'type' => 'button',
                'class' => 'is-primary',
                'data-admin-webauthn' => 'register',
                'data-passkey-name-input' => 'account-passkey-name',
            ]); ?>
        </div>

        <div class="area is-field" style="margin-top: 12px;">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01(e('表示名（任意）'), 'account-passkey-name'); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('account-passkey-name', [
                            'type' => 'text',
                            'id' => 'account-passkey-name',
                            'name' => 'passkey_name',
                            'placeholder' => '例: MacBook の Touch ID',
                            'maxlength' => 100,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>

        <?php if (!empty($passkeys)): ?>
            <table data-module="m-table01" class="is-compact" style="margin-top: 16px;">
                <thead>
                    <tr>
                        <th>名前</th>
                        <th>登録日時</th>
                        <th>最終利用</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($passkeys as $pk): ?>
                        <tr>
                            <td><?= e($pk['name'] !== null && $pk['name'] !== '' ? (string) $pk['name'] : '（名称なし）') ?></td>
                            <td><?= e((string) ($pk['created_at'] ?? '')) ?></td>
                            <td><?= e((string) ($pk['last_used_at'] ?? '—')) ?></td>
                            <td>
                                <?php admin_m_btn01_button_wrap('削除', [
                                    'type' => 'button',
                                    'class' => 'is-danger is-sm',
                                    'data-admin-webauthn' => 'delete',
                                    'data-credential-id' => (string) (int) $pk['id'],
                                ]); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text is-help" style="margin-top: 12px;">登録されているパスキーはありません。</p>
        <?php endif; ?>
    </section>

    <script>
    window.FORMKUN_CSRF = <?= json_encode(\Core\Csrf::token(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE | JSON_HEX_APOS) ?>;
    </script>
    <script defer src="<?= e(base_path('/assets/js/admin-auth-webauthn.js')) ?>"></script>
<?php endif; ?>
