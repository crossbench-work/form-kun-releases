<?php /** 設定 → LINE 連携（サイト共通） */
use Core\LineSiteConfig;
use Models\Form;
use Models\LineWebhookTarget;

$lineSiteForm = array_merge(['id' => 0], LineSiteConfig::viewContext());
$lineCredentialErrors = $line_credential_errors ?? [];
$lineSetupChecklistState = LineSiteConfig::lineSetupChecklistStateForDisplay();
$lineSetupChecklistPostUrl = base_path('/admin/settings/line/setup-checklist');
$lineTalkSetupChecklistSyncUrl = base_path('/admin/settings/line/talk-setup-checklist');
$lineWebhookTargetDeleteUrl = base_path('/admin/settings/line/webhook-targets/delete');
$userHasWebhookId = LineWebhookTarget::existsForSite(['user']);
$lineAccountLinkComplete = LineSiteConfig::isSetupComplete();
?>
<form method="post" action="#" id="settings-line-form">
    <?= \Core\Csrf::field() ?>
    <?php admin_c_form_block01_open(); ?>
    <div class="area is-title">
        <?php admin_m_large_title01('LINE 連携'); ?>
    </div>
    <div class="block is-lineAccountLink">
    <?php if (!$lineAccountLinkComplete): ?>
    <div class="area is-title">
        <?php admin_m_left_border_title01('アカウント連携の設定'); ?>
    </div>
    <?php endif; ?>
    <div class="area is-field">
        <?php
        if ($lineAccountLinkComplete) {
            require __DIR__ . '/_content_line_account_linked_compact.php';
        } else {
        admin_c_line_setup_checklist01(
            LineSiteConfig::siteChecklistItemDefinitions(),
            $lineSetupChecklistState,
            $lineSetupChecklistPostUrl,
            true,
            static function (string $itemKey) use ($lineSiteForm, $lineCredentialErrors): void {
                if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_SECRET) {
                    $lineCredentialHideTitle = true;
                    $lineCredentialContext = 'site';
                    $form = $lineSiteForm;
                    require APP_DIR . '/views/admin/forms/detail/mail/_content_line_channel_secret.php';

                    return;
                }
                if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_ACCESS_TOKEN) {
                    $lineCredentialHideTitle = true;
                    $lineCredentialContext = 'site';
                    $form = $lineSiteForm;
                    require APP_DIR . '/views/admin/forms/detail/mail/_content_line_channel_access_token.php';

                    return;
                }
                if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_WEBHOOK_URL) {
                    $lineWebhookHideTitle = true;
                    require APP_DIR . '/views/admin/forms/detail/mail/_content_line_webhook_url.php';

                    return;
                }
                if ($itemKey === Form::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP) {
                    $lineTalkSetupContext = 'site';
                    require APP_DIR . '/views/admin/forms/detail/mail/_content_line_talk_setup.php';

                    return;
                }
                if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_LINE_PUSH_TO_ID) {
                    $linePushToIdHideTitle = true;
                    $linePushToIdHideHelp = true;
                    $linePushToIdInlineSave = true;
                    $linePushToIdContext = 'site';
                    $form = $lineSiteForm;
                    require APP_DIR . '/views/admin/forms/detail/mail/_content_line_push_to_id.php';

                    return;
                }
                if ($itemKey === Form::LINE_SETUP_CHECKLIST_LINE_TALK_NOTIFY_TEST) {
                    $lineNotifyTestContext = 'site';
                    $form = $lineSiteForm;
                    require APP_DIR . '/views/admin/forms/detail/mail/_content_line_notify_test.php';

                    return;
                }
            }
        );
        }
        ?>
    </div>
    </div>
    <div class="block is-lineAccountUnlink">
    <div class="area is-title">
        <?php admin_m_left_border_title01('アカウント連携の解除'); ?>
    </div>
    <div class="area is-field">
        <?php
        $lineAccountUnlinkUrl = base_path('/admin/settings/line/account-unlink');
        require APP_DIR . '/views/admin/forms/detail/mail/_content_line_account_unlink.php';
        ?>
    </div>
    </div>
    <?php admin_c_form_block01_close(); ?>
</form>
