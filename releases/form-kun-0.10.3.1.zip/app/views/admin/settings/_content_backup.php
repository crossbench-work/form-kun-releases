                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('エクスポート'); ?>
                            </div>
                            <form method="post" action="<?= e(base_path('/admin/settings/backup/export')) ?>">
                                <?= \Core\Csrf::field() ?>
                                <div class="block is-field">
                                    <p data-module="m-text01" data-type="muted">フォーム・送信・添付ファイル・ユーザー・サイト設定をすべて含む ZIP を作成します。ZIP はパスワードで暗号化され、復元時に同じパスワードが必要です。</p>
                                </div>
                                <div class="block is-field">
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01(e('パスワード') . ' <span data-module="m-required01" data-type="required">必須</span>', 'backup_password'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('backup_password', [
                                                    'type' => 'password',
                                                    'name' => 'backup_password',
                                                    'id' => 'backup_password',
                                                    'autocomplete' => 'new-password',
                                                    'required' => true,
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div class="block is-field">
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01(e('パスワード（確認）') . ' <span data-module="m-required01" data-type="required">必須</span>', 'backup_password_confirm'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('backup_password_confirm', [
                                                    'type' => 'password',
                                                    'name' => 'backup_password_confirm',
                                                    'id' => 'backup_password_confirm',
                                                    'autocomplete' => 'new-password',
                                                    'required' => true,
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div class="block is-actions">
                                    <?php admin_m_btn01_button_wrap('バックアップをダウンロード', ['type' => 'submit', 'class' => 'is-primary']); ?>
                                </div>
                            </form>
                <?php admin_c_form_block01_close(); ?>

                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('インポート'); ?>
                            </div>
                            <form method="post" action="<?= e(base_path('/admin/settings/backup/import')) ?>" enctype="multipart/form-data"
                                onsubmit="return confirm('現在のデータはすべて削除され、バックアップの内容に置き換わります。元に戻せません。復元後はログアウトします。よろしいですか？');">
                                <?= \Core\Csrf::field() ?>
                                <div class="block is-field">
                                    <p data-module="m-text01" data-type="danger">現在のデータ（フォーム・送信・添付ファイル・ユーザー・サイト設定）はすべて削除され、バックアップの内容に置き換わります。元に戻せません。</p>
                                </div>
                                <div class="block is-field">
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01(e('バックアップ ZIP') . ' <span data-module="m-required01" data-type="required">必須</span>', 'backup_file'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('backup_file', [
                                                    'type' => 'file',
                                                    'name' => 'backup_file',
                                                    'id' => 'backup_file',
                                                    'accept' => 'application/zip,.zip',
                                                    'required' => true,
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <p class="text is-help">上限 <?= number_format((int) floor(max(1, (int) config('submissions.import_max_bytes', 500 * 1024 * 1024)) / 1048576)) ?>MB。</p>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div class="block is-field">
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01(e('パスワード') . ' <span data-module="m-required01" data-type="required">必須</span>', 'restore_password'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('restore_password', [
                                                    'type' => 'password',
                                                    'name' => 'restore_password',
                                                    'id' => 'restore_password',
                                                    'autocomplete' => 'off',
                                                    'required' => true,
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div class="block is-actions">
                                    <?php admin_m_btn01_button_wrap('バックアップから復元', ['type' => 'submit', 'class' => 'is-primary']); ?>
                                </div>
                            </form>
                <?php admin_c_form_block01_close(); ?>
