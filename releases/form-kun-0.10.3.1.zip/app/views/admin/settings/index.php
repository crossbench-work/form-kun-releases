<?php require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-inputSet01/m-inputSet01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-input01/m-input01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-boldTitle01/m-boldTitle01.php'; ?>
<?php
$FB_REGEX_CUSTOM = '__custom__';
$FB_REGEX_CHECKBOX_LIMIT = '__checkbox_limit__';
$regexPresetChoices = [
    '' => 'なし',
    '/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/u' => 'メールアドレス',
    '/\A(?:\+?\d[\d\-() ]*)\z/u' => '電話番号',
    '/\A[0-9]+\z/u' => '半角数字のみ',
    '/\A[a-zA-Z0-9]+\z/u' => '半角英数字のみ',
    '/\A[ぁ-んー]+\z/u' => 'ひらがなのみ',
    '/\A[ァ-ヶー　]+\z/u' => 'カタカナのみ（全角スペース可）',
    '/\A[a-zA-Z]+\z/u' => '半角英字のみ',
    $FB_REGEX_CUSTOM => 'カスタム（正規表現を入力）',
];
$renderTemplateEditor = static function (?array $template, string $action, string $titleId): void {
    $fields = is_array($template['fields'] ?? null) ? $template['fields'] : [];
    $fieldGroups = is_array($template['field_groups'] ?? null) ? $template['field_groups'] : [];
    $pageFields = $fields;
    $fieldTemplates = [];
    $inputPage = [
        'page_key' => \Models\FormInputPage::DEFAULT_KEY,
        'title' => '入力画面',
    ];
    ?>
    <form method="post" action="<?= e($action) ?>" data-template-editor-form="1">
        <?= \Core\Csrf::field() ?>
        <div class="block is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01('ラベル', $titleId); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input([
                            'type' => 'text',
                            'name' => 'title',
                            'id' => $titleId,
                            'value' => (string) ($template['title'] ?? ''),
                            'required' => true,
                            'maxlength' => 200,
                        ]); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="block is-title">
            <p data-module="m-borderTitle01">項目設定</p>
        </div>
        <div class="block is-field" data-module="m-formBuilder01">
            <?php include APP_DIR . '/views/admin/forms/detail/form/_content_items.php'; ?>
        </div>
        <div class="block is-field">
            <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary'], 'center'); ?>
        </div>
    </form>
    <?php
};
$renderBuiltinTemplatePreview = static function (array $template): void {
    $fields = is_array($template['fields'] ?? null) ? $template['fields'] : [];
    $fieldGroups = is_array($template['field_groups'] ?? null) ? $template['field_groups'] : [];
    $pageFields = $fields;
    $fieldTemplates = [];
    $isReadOnlyTemplatePreview = true;
    $inputPage = [
        'page_key' => \Models\FormInputPage::DEFAULT_KEY,
        'title' => '入力画面',
    ];
    ?>
    <p data-module="m-text01" data-type="muted">このテンプレートは編集・削除できません。フォーム編集画面の項目設定で使用できます。</p>
    <div class="block is-title">
        <p data-module="m-borderTitle01">項目設定</p>
    </div>
    <div class="block is-field" data-module="m-formBuilder01">
        <fieldset class="c-fieldTemplateList01__readonly" disabled>
            <?php include APP_DIR . '/views/admin/forms/detail/form/_content_items.php'; ?>
        </fieldset>
    </div>
    <?php
};
if (!function_exists('admin_settings_value_text01')) {
    function admin_settings_value_text01(string $label, string $id, string $value, string $helpHtml = '', string $actionHtml = ''): void
    {
        admin_m_input_set01_open();
        echo '<div class="area is-title">';
        admin_m_bold_title01(e($label), $id);
        echo '</div>';
        echo '<div class="area is-field">';
        echo '<p class="text is-value" id="' . e($id) . '">' . e($value) . '</p>';
        echo '</div>';
        if ($helpHtml !== '') {
            echo '<div class="area is-help">' . $helpHtml . '</div>';
        }
        if ($actionHtml !== '') {
            echo '<div class="area is-actions">' . $actionHtml . '</div>';
        }
        admin_m_input_set01_close();
    }
}

if (!function_exists('admin_settings_button_html01')) {
    /**
     * admin_settings_value_text01() の actionHtml に渡す m-btn01 ボタンを組み立てる。
     *
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_settings_button_html01(string $label, array $attrs): string
    {
        ob_start();
        admin_m_btn01_button_wrap($label, $attrs);
        return (string) ob_get_clean();
    }
}
?>
<div data-module="m-toolbar01">
    <h1 class="title" style="margin:0;">設定</h1>
    <div class="spacer"></div>
    <?php if (!empty($storage_resource) && is_array($storage_resource)): ?>
        <?php admin_c_progress01_resource_summary($storage_resource); ?>
    <?php endif; ?>
</div>

<div data-module="c-formEditTabs01" class="is-nested" data-tab-scope="settings">
    <div class="wrapper">
        <div class="block is-tabs" role="tablist" aria-orientation="vertical" aria-label="設定メニュー">
            <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                data-tab-panel="settings-basic" role="tab" aria-selected="true" tabindex="0">基本情報</div>
            <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                data-tab-panel="settings-config" role="tab" aria-selected="false" tabindex="-1">設定</div>
            <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                data-tab-panel="settings-templates" role="tab" aria-selected="false" tabindex="-1">テンプレート</div>
            <?php if (\Core\Auth::role() === 'admin'): ?>
                <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                    data-tab-panel="settings-backup" role="tab" aria-selected="false" tabindex="-1">バックアップ</div>
                <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                    data-tab-panel="settings-line" role="tab" aria-selected="false" tabindex="-1">LINE 連携</div>
                <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                    data-tab-panel="settings-version" role="tab" aria-selected="false" tabindex="-1">バージョン</div>
            <?php endif; ?>
        </div>
        <div class="block is-contents">
            <div data-target="c-formEditTabs01__contents" data-tab-panel="settings-basic" class="area is-contents" role="tabpanel"
                aria-label="基本情報">
<?php admin_c_form_block01_open(); ?>
            <div class="block is-title">
                                <?php admin_m_large_title01('基本情報'); ?>
            </div>
            <div class="block is-field">
                <?php
                $baseUrl = (string) config('site.base_url', '');
                admin_settings_value_text01('管理画面の表示名', 'settings_site_admin_name', (string) config('site.admin_name', ''));
                admin_settings_value_text01(
                    '公開サイトのベース URL',
                    'settings_site_base_url',
                    $baseUrl !== '' ? $baseUrl : '未設定（相対パスのみ）'
                );
                admin_settings_value_text01(
                    'サブディレクトリ（base_path）',
                    'settings_site_base_path',
                    (string) config('site.base_path', ''),
                    '<p class="text is-help">空ならドキュメントルート直下です。</p>'
                );
                admin_settings_value_text01('タイムゾーン', 'settings_site_timezone', (string) config('site.timezone', ''));
                ?>
            </div>
<?php admin_c_form_block01_close(); ?>
            </div>

            <div data-target="c-formEditTabs01__contents" data-tab-panel="settings-config" class="area is-contents" role="tabpanel"
                aria-label="設定" hidden>
<?php admin_c_form_block01_open(); ?>
            <div class="block is-title">
                                <?php admin_m_large_title01('設定'); ?>
            </div>
            <div class="block is-field">
                <?php
                $formLimitHelp = \Core\Auth::role() !== 'admin'
                                    ? '<p data-module="m-text01" data-type="muted">作成上限の変更は管理者のみ行えます。</p>'
                    : '';
                $formLimitAction = \Core\Auth::role() === 'admin'
                    ? admin_settings_button_html01('編集', [
                        'type' => 'button',
                        'class' => 'is-sm',
                        'data-target' => 'settings-max-forms-open',
                    ])
                    : '';
                admin_settings_value_text01(
                    '現在のフォーム数',
                    'settings_form_count',
                    (int) $form_count . ' 件 / 上限 ' . (int) $max_forms . ' 件',
                    $formLimitHelp,
                    $formLimitAction
                );
                $storageHelp = '';
                if (!empty($storage_exceeded)) {
                                    $storageHelp .= '<p data-module="m-text01" data-type="danger">上限に達しています。公開フォームは利用できません。</p>';
                } elseif (!empty($storage_warning)) {
                                    $storageHelp .= '<p data-module="m-text01" data-type="warning">上限に近づいています。</p>';
                }
                if (\Core\Auth::role() !== 'admin') {
                                    $storageHelp .= '<p data-module="m-text01" data-type="muted">上限の変更は管理者のみ行えます。</p>';
                }
                $storageAction = \Core\Auth::role() === 'admin'
                    ? admin_settings_button_html01('編集', [
                        'type' => 'button',
                        'class' => 'is-sm',
                        'data-target' => 'settings-max-storage-open',
                    ])
                    : '';
                                ?>
                            </div>
                <?php admin_c_form_block01_close(); ?>

                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('公開中のフォーム一覧'); ?>
                            </div>
                            <?php if (\Core\Auth::role() === 'admin'): ?>
                            <form method="post" action="<?= e(base_path('/admin/settings/display')) ?>">
                                <?= \Core\Csrf::field() ?>
                                <div class="block is-field">
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('表示', 'show_active_forms_list'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_checkbox01('公開中のフォーム一覧を表示する', admin_m_input01_attrs_with_bound_label('show_active_forms_list', [
                                                'name' => 'show_active_forms_list',
                                                'id' => 'show_active_forms_list',
                                                'value' => '1',
                                                'checked' => !empty($show_active_forms_list),
                                            ])); ?>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>

                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('リダイレクト URL', 'active_forms_list_redirect_url'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('active_forms_list_redirect_url', [
                                                    'type' => 'text',
                                                    'name' => 'active_forms_list_redirect_url',
                                                    'id' => 'active_forms_list_redirect_url',
                                                    'value' => (string) ($active_forms_list_redirect_url ?? ''),
                                                    'placeholder' => '/ または https://example.com/',
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <p class="text is-help">一覧を表示しないとき / にアクセスした場合の遷移先。空のときは 404。</p>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div class="block is-actions">
                                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                                </div>
                            </form>
                            <?php endif; ?>
                <?php admin_c_form_block01_close(); ?>

                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('祝日情報'); ?>
                            </div>
                            <?php
                            $holidaysStatus = (string) ($holidays_status ?? 'missing');
                            $holidaysStatusMessage = trim((string) ($holidays_status_message ?? ''));
                            if ($holidaysStatusMessage !== ''): ?>
                            <div class="block is-field">
                                <?php
                                $holidaysAlertType = $holidaysStatus === 'error' ? 'danger' : 'warning';
                                admin_m_alert01($holidaysStatusMessage, $holidaysAlertType);
                                ?>
                            </div>
                            <?php endif; ?>
                            <div class="block is-field">
                                <?php
                                $holidaysFetchedAt = trim((string) ($holidays_fetched_at ?? ''));
                                admin_settings_value_text01(
                                    '最終取得日時',
                                    'settings_holidays_fetched_at',
                                    $holidaysFetchedAt !== '' ? $holidaysFetchedAt : '未取得'
                                );
                admin_settings_value_text01(
                                    '登録件数',
                                    'settings_holidays_count',
                                    (int) ($holidays_count ?? 0) . ' 件'
                                );
                                ?>
                                <p data-module="m-text01" data-type="muted">Holidays JP API（去年・今年・来年）から取得した祝日データです。公開/非公開条件の祝日判定で利用します。</p>
                            </div>
                            <?php if (\Core\Auth::role() === 'admin'): ?>
                            <form method="post" action="<?= e(base_path('/admin/settings/holidays')) ?>">
                                <?= \Core\Csrf::field() ?>
                                <div class="block is-field">
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('自動取得間隔', 'holidays_jp_fetch_interval_days'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('holidays_jp_fetch_interval_days', [
                                                    'type' => 'number',
                                                    'name' => 'holidays_jp_fetch_interval_days',
                                                    'id' => 'holidays_jp_fetch_interval_days',
                                                    'min' => 1,
                                                    'max' => 3650,
                                                    'step' => 1,
                                                    'value' => (string) (int) ($holidays_fetch_interval_days ?? 365),
                                                    'required' => true,
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <span class="text is-help">日</span>
                                            <p class="text is-help">最終取得からこの日数を超えると管理画面に更新を促すメッセージを表示します。初回のみ自動取得します。</p>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div class="block is-actions">
                                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                                </div>
                            </form>
                            <form method="post" action="<?= e(base_path('/admin/settings/holidays/fetch')) ?>">
                                <?= \Core\Csrf::field() ?>
                                <div class="block is-actions">
                                    <?php admin_m_btn01_button_wrap('祝日情報を取得する', ['type' => 'submit']); ?>
                                </div>
                            </form>
                            <?php endif; ?>
                <?php admin_c_form_block01_close(); ?>

                <?php if (\Core\Auth::role() === 'admin'): ?>
                <?php
                $purgeScheduleEnabled = !empty($submission_purge_schedule_enabled);
                $purgeScheduleMode = (string) ($submission_purge_schedule_mode ?? \Core\SubmissionPurgeSchedule::MODE_DAILY);
                $purgeScheduleDaily = (int) ($submission_purge_schedule_daily_hour ?? \Core\SubmissionPurgeSchedule::DEFAULT_DAILY_HOUR);
                $purgeScheduleInterval = (int) ($submission_purge_schedule_interval_hours ?? \Core\SubmissionPurgeSchedule::DEFAULT_INTERVAL_HOURS);
                $purgeScheduleLastRun = trim((string) ($submission_purge_schedule_last_run_at ?? ''));
                ?>
                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('受信履歴の定期削除'); ?>
                            </div>
                            <div class="block is-field">
                                <?php admin_settings_value_text01(
                                    '最終実行日時',
                                    'settings_submission_purge_last_run_at',
                                    $purgeScheduleLastRun !== '' ? $purgeScheduleLastRun : '未実行',
                                    '<p data-module="m-text01" data-type="muted">保存期間を「設定する」かつ「削除する」にしたフォームの、期間を過ぎた受信履歴を cron から削除します。フォーム編集で保存期間を変更したときの即時削除とは別です。サーバー（Docker ローカルでは web コンテナ）の cron が CLI を定期的に起動している必要があります。</p>'
                                ); ?>
                            </div>
                            <form method="post" action="<?= e(base_path('/admin/settings/submission-purge-schedule')) ?>" data-purge-schedule-form="1">
                                <?= \Core\Csrf::field() ?>
                                <div class="block is-field">
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('定期削除', 'submission_purge_schedule_enabled'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_checkbox01('定期削除を有効にする', admin_m_input01_attrs_with_bound_label('submission_purge_schedule_enabled', [
                                                'name' => 'submission_purge_schedule_enabled',
                                                'id' => 'submission_purge_schedule_enabled',
                                                'value' => '1',
                                                'checked' => $purgeScheduleEnabled,
                                            ])); ?>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div data-purge-schedule-detail<?= $purgeScheduleEnabled ? '' : ' hidden' ?>>
                                    <div class="block is-field">
                                        <?php admin_m_input_set01_open(); ?>
                                            <div class="area is-title">
                                                <?php admin_m_bold_title01('実行間隔', 'submission_purge_schedule_mode'); ?>
                                            </div>
                                            <div class="area is-field">
                                                <?php admin_m_radiobtn01('毎日', [
                                                    'name' => 'submission_purge_schedule_mode',
                                                    'value' => \Core\SubmissionPurgeSchedule::MODE_DAILY,
                                                    'checked' => $purgeScheduleMode !== \Core\SubmissionPurgeSchedule::MODE_INTERVAL,
                                                ]); ?>
                                                <?php admin_m_radiobtn01('一定時間ごと', [
                                                    'name' => 'submission_purge_schedule_mode',
                                                    'value' => \Core\SubmissionPurgeSchedule::MODE_INTERVAL,
                                                    'checked' => $purgeScheduleMode === \Core\SubmissionPurgeSchedule::MODE_INTERVAL,
                                                ]); ?>
                                            </div>
                                        <?php admin_m_input_set01_close(); ?>
                                    </div>
                                    <div class="block is-field" data-purge-schedule-daily<?= $purgeScheduleMode === \Core\SubmissionPurgeSchedule::MODE_INTERVAL ? ' hidden' : '' ?>>
                                        <?php admin_m_input_set01_open(); ?>
                                            <div class="area is-title">
                                                <?php admin_m_bold_title01('実行時刻', 'submission_purge_schedule_daily_hour'); ?>
                                            </div>
                                            <div class="area is-field">
                                                <?php admin_m_input01_open('is-inline'); ?>
                                                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submission_purge_schedule_daily_hour', [
                                                        'type' => 'number',
                                                        'name' => 'submission_purge_schedule_daily_hour',
                                                        'id' => 'submission_purge_schedule_daily_hour',
                                                        'min' => \Core\SubmissionPurgeSchedule::MIN_DAILY_HOUR,
                                                        'max' => \Core\SubmissionPurgeSchedule::MAX_DAILY_HOUR,
                                                        'step' => 1,
                                                        'value' => (string) $purgeScheduleDaily,
                                                        'required' => true,
                                                    ])); ?>
                                                <?php admin_m_input01_close(); ?>
                                                <span class="text is-help">時（0〜23、サーバーのタイムゾーン）</span>
                                            </div>
                                        <?php admin_m_input_set01_close(); ?>
                                    </div>
                                    <div class="block is-field" data-purge-schedule-interval<?= $purgeScheduleMode === \Core\SubmissionPurgeSchedule::MODE_INTERVAL ? '' : ' hidden' ?>>
                                        <?php admin_m_input_set01_open(); ?>
                                            <div class="area is-title">
                                                <?php admin_m_bold_title01('実行間隔', 'submission_purge_schedule_interval_hours'); ?>
                                            </div>
                                            <div class="area is-field">
                                                <?php admin_m_input01_open('is-inline'); ?>
                                                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submission_purge_schedule_interval_hours', [
                                                        'type' => 'number',
                                                        'name' => 'submission_purge_schedule_interval_hours',
                                                        'id' => 'submission_purge_schedule_interval_hours',
                                                        'min' => \Core\SubmissionPurgeSchedule::MIN_INTERVAL_HOURS,
                                                        'max' => \Core\SubmissionPurgeSchedule::MAX_INTERVAL_HOURS,
                                                        'step' => 1,
                                                        'value' => (string) $purgeScheduleInterval,
                                                        'required' => true,
                                                    ])); ?>
                                                <?php admin_m_input01_close(); ?>
                                                <span class="text is-help">時間（1〜168）</span>
                                            </div>
                                        <?php admin_m_input_set01_close(); ?>
                                    </div>
                                </div>
                                <div class="block is-actions">
                                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                                </div>
                            </form>
                <?php admin_c_form_block01_close(); ?>
                <?php endif; ?>

                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('使用リソース'); ?>
                            </div>
                            <div class="block is-field">
                                <p class="text is-value" id="settings_storage_uploads">添付ファイル: <?= e(\Core\Validator::formatBytes((int) $storage_used_uploads)) ?></p>
                                <p class="text is-value" id="settings_storage_db">データベース: <?= e(\Core\Validator::formatBytes((int) $storage_used_db)) ?></p>
                                <p class="text is-value" id="settings_storage_total">合計: <?= e(\Core\Validator::formatBytes((int) $storage_used_total)) ?></p>
                                <?php if ($storageHelp !== ''): ?>
                                    <div class="area is-help"><?= $storageHelp ?></div>
                                <?php endif; ?>
                                <?php if ($storageAction !== ''): ?>
                                    <div class="area is-actions"><?= $storageAction ?></div>
                                <?php endif; ?>
                            </div>
                <?php admin_c_form_block01_close(); ?>

                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('バージョン管理'); ?>
                            </div>
                            <form method="post" action="<?= e(base_path('/admin/settings/versioning')) ?>">
                                <?= \Core\Csrf::field() ?>
                                <div class="block is-field">
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('保存間隔', 'form_version_interval_minutes'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('form_version_interval_minutes', [
                                                    'type' => 'number',
                                                    'name' => 'form_version_interval_minutes',
                                                    'id' => 'form_version_interval_minutes',
                                                    'min' => 0,
                                                    'max' => 10080,
                                                    'step' => 1,
                                                    'value' => (string) (int) ($form_version_interval_minutes ?? \Models\FormVersion::DEFAULT_INTERVAL_MINUTES),
                                                    'required' => true,
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <p class="text is-help">分おきに保存。0 を指定すると間隔保存しません。</p>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>

                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('保存時', 'form_version_save_on_save'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_checkbox01('保存時にバージョン情報を保存する', admin_m_input01_attrs_with_bound_label('form_version_save_on_save', [
                                                'name' => 'form_version_save_on_save',
                                                'id' => 'form_version_save_on_save',
                                                'value' => '1',
                                                'checked' => !empty($form_version_save_on_save),
                                            ])); ?>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>

                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('ログイン時', 'form_version_save_on_login'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_checkbox01('ログイン時に自動保存する', admin_m_input01_attrs_with_bound_label('form_version_save_on_login', [
                                                'name' => 'form_version_save_on_login',
                                                'id' => 'form_version_save_on_login',
                                                'value' => '1',
                                                'checked' => !empty($form_version_save_on_login),
                                            ])); ?>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>

                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('ログアウト時', 'form_version_save_on_logout'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_checkbox01('ログアウト時に自動保存する', admin_m_input01_attrs_with_bound_label('form_version_save_on_logout', [
                                                'name' => 'form_version_save_on_logout',
                                                'id' => 'form_version_save_on_logout',
                                                'value' => '1',
                                                'checked' => !empty($form_version_save_on_logout),
                                            ])); ?>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>

                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('保存回数', 'form_version_retention_limit'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('form_version_retention_limit', [
                                                    'type' => 'number',
                                                    'name' => 'form_version_retention_limit',
                                                    'id' => 'form_version_retention_limit',
                                                    'min' => 1,
                                                    'max' => 10000,
                                                    'step' => 1,
                                                    'value' => (string) (int) ($form_version_retention_limit ?? \Models\FormVersion::DEFAULT_RETENTION_LIMIT),
                                                    'required' => true,
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <p class="text is-help">保存回数を超えた場合は、未ピン留めの古いバージョンから削除します。</p>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div class="block is-actions">
                                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                                </div>
                            </form>
                <?php admin_c_form_block01_close(); ?>
            </div>

            <div id="line-settings" data-target="c-formEditTabs01__contents" data-tab-panel="settings-line" class="area is-contents" role="tabpanel"
                aria-label="LINE 連携" hidden>
                <?php require __DIR__ . '/_content_line.php'; ?>
            </div>

            <div id="settings-templates" data-target="c-formEditTabs01__contents" data-tab-panel="settings-templates" class="area is-contents" role="tabpanel"
                aria-label="テンプレート" hidden>
                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('テンプレート'); ?>
                            </div>
                            <div class="block is-field">
                                <?php admin_c_field_template_list01_open(); ?>
                                    <?php if (!empty($field_templates)): ?>
                                        <?php foreach ($field_templates as $tpl): ?>
                                            <?php
                                            $isBuiltinTemplate = !empty($tpl['is_builtin']);
                                            $templateId = (string) ($tpl['id'] ?? '');
                                            $templateDbId = (int) $templateId;
                                            $templateTitle = trim((string) ($tpl['title'] ?? '')) !== '' ? (string) $tpl['title'] : '無題のテンプレート';
                                            ?>
                                            <details class="c-fieldTemplateList01__item">
                                                <summary class="summary">
                                                    <span class="title"><?= e($templateTitle) ?></span>
                                                    <?php if ($isBuiltinTemplate): ?>
                                                        <span class="text">標準テンプレート</span>
                                                    <?php else: ?>
                                                        <details class="menu">
                                                            <summary aria-label="テンプレート操作">…</summary>
                                                            <div class="menuBody">
                                                                <form method="post" action="<?= e(base_path('/admin/settings/templates/' . $templateDbId . '/delete')) ?>" onsubmit="return confirm('このテンプレートを削除しますか？');">
                                                                    <?= \Core\Csrf::field() ?>
                                                                    <button type="submit">削除</button>
                                                                </form>
                                                            </div>
                                                        </details>
                                                    <?php endif; ?>
                                                </summary>
                                                <div class="body">
                                                    <?php if ($isBuiltinTemplate): ?>
                                                        <?php $renderBuiltinTemplatePreview($tpl); ?>
                                                    <?php else: ?>
                                                        <?php $renderTemplateEditor($tpl, base_path('/admin/settings/templates/' . $templateDbId), 'field_template_title_' . $templateDbId); ?>
                                                    <?php endif; ?>
                                                </div>
                                            </details>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                    <div class="c-fieldTemplateList01__add" data-target="fieldTemplateCreateActions">
                                        <?php admin_m_btn01_open(); ?>
                                            <?php admin_m_btn01_button('＋ テンプレートを追加', [
                                                'type' => 'button',
                                                'class' => 'fb-description-add',
                                                'data-target' => 'fieldTemplateCreateOpen',
                                            ]); ?>
                                        <?php admin_m_btn01_close(); ?>
                                    </div>
                                    <template data-target="fieldTemplateCreateTemplate">
                                        <details class="c-fieldTemplateList01__item is-new">
                                            <summary class="summary">
                                                <span class="title">新規テンプレート</span>
                                            </summary>
                                            <div class="body">
                                                <?php $renderTemplateEditor(null, base_path('/admin/settings/templates'), 'field_template_title___templateKey__'); ?>
                                            </div>
                                        </details>
                                    </template>
                                <?php admin_c_field_template_list01_close(); ?>
                            </div>
                <?php admin_c_form_block01_close(); ?>
            </div>

            <?php if (\Core\Auth::role() === 'admin'): ?>
                <div id="settings-backup" data-target="c-formEditTabs01__contents" data-tab-panel="settings-backup" class="area is-contents" role="tabpanel"
                    aria-label="バックアップ" hidden>
                    <?php require __DIR__ . '/_content_backup.php'; ?>
                </div>
            <?php endif; ?>

            <?php if (\Core\Auth::role() === 'admin'): ?>
                <div data-target="c-formEditTabs01__contents" data-tab-panel="settings-version" class="area is-contents" role="tabpanel"
                    aria-label="バージョン" hidden>
                    <?php require __DIR__ . '/_content_app_update.php'; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php admin_c_field_type_modal01(); ?>
<?php admin_m_form_builder01_field_template(); ?>
<?php admin_m_form_builder01_group_template(); ?>

<?php if (\Core\Auth::role() === 'admin'): ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-max-forms-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-max-forms-modal-title'); ?>
        <?php admin_c_modal01_header_open(); ?>
            <h2 id="settings-max-forms-modal-title">フォームの作成上限</h2>
            <button type="button" class="btn is-sm" data-target="settings-max-forms-close">閉じる</button>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('フォームの作成上限'), 'max_forms_modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('max_forms_modal', [
                            'type' => 'number',
                            'name' => 'max_forms',
                            'id' => 'max_forms_modal',
                            'min' => 1,
                            'max' => 999999,
                            'step' => 1,
                            'value' => (string) (int) $max_forms,
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">1 以上の整数を指定してください。保存後、一覧の新規作成やこの上限を超える作成はできません。</p>
                </div>
                <?php admin_c_modal01_actions_open(); ?>
                    <button type="button" class="btn" data-target="settings-max-forms-close">キャンセル</button>
                    <button type="submit" class="btn is-primary">保存</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-max-storage-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-max-storage-modal-title'); ?>
        <?php admin_c_modal01_header_open(); ?>
            <h2 id="settings-max-storage-modal-title">使用リソースの上限</h2>
            <button type="button" class="btn is-sm" data-target="settings-max-storage-close">閉じる</button>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/site-resource')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('使用リソースの上限（MB）'), 'max_site_resource_mb_modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('max_site_resource_mb_modal', [
                            'type' => 'number',
                            'name' => 'max_site_resource_mb',
                            'id' => 'max_site_resource_mb_modal',
                            'min' => 1,
                            'max' => 1048576,
                            'step' => 1,
                            'value' => (string) (int) $storage_max_mb,
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">添付ファイルとデータベースの合計使用量の上限です。1 以上の整数（MB）を指定してください。</p>
                </div>
                <?php admin_c_modal01_actions_open(); ?>
                    <button type="button" class="btn" data-target="settings-max-storage-close">キャンセル</button>
                    <button type="submit" class="btn is-primary">保存</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php endif; ?>
