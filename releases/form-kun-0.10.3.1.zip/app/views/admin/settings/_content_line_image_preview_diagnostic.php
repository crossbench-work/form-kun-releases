<?php /** 設定 → LINE 連携: {{__all__}} 画像プレビュー診断 */
use Core\LineImagePreviewDiagnostic;

$lineImageDiag = LineImagePreviewDiagnostic::statusForDisplay();
$lineImageDiagUrl = base_path('/admin/settings/line/diagnose-image-preview');
$okMark = static fn(bool $ok): string => $ok ? 'OK' : '要確認';
?>
<div class="block is-lineImagePreviewDiagnostic">
    <div class="area is-title">
        <?php admin_m_bold_title01('LINE 画像プレビュー診断（{{__all__}}）'); ?>
    </div>
    <div class="area is-field">
<?php
$baseSourceLabel = ['config' => 'config の site.base_url', 'request' => 'アクセス中の https URL から自動'][(string) ($lineImageDiag['public_base_url_source'] ?? '')] ?? '決められません（https で開いてください）';
$keySourceLabel = ['config' => 'config で指定', 'db' => '自動生成（データベース保存）'][(string) ($lineImageDiag['signing_key_source'] ?? '')] ?? '未設定';
?>
        <p class="text is-help">設定は不要です。フォーム送信時の https URL と自動生成した署名鍵で、LINE の「ファイル添付」の下に画像 URL を載せます（config.local.php で上書きも可能）。</p>
        <p class="text is-help">アプリ版: <?= e((string) ($lineImageDiag['app_version'] ?? '')) ?> / temp 書込: <?= e($okMark(!empty($lineImageDiag['temp_writable']))) ?></p>
        <p class="text is-help">公開 URL: <?= e((string) ($lineImageDiag['public_base_url'] ?? '') !== '' ? (string) $lineImageDiag['public_base_url'] : '—') ?>（<?= e($baseSourceLabel) ?>）</p>
        <p class="text is-help">署名鍵: <?= e($okMark(!empty($lineImageDiag['signing_key_set']))) ?>（<?= e($keySourceLabel) ?>）</p>
        <div data-module="c-lineImagePreviewDiagnostic01" data-test-url="<?= e($lineImageDiagUrl) ?>" data-csrf-name="_token">
            <div class="area is-actions">
                <?php
                admin_m_btn01_button_wrap('診断実行', [
                    'type' => 'button',
                    'class' => 'is-primary',
                ]);
                ?>
            </div>
            <p class="text is-help" data-target="line-image-diag-result" hidden></p>
        </div>
    </div>
</div>
