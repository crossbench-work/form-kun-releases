<?php

$showManifestUi = !empty($show_manifest_ui);
$latest = is_array($manifest ?? null) ? (string) ($manifest['latest'] ?? '') : '';
$requirements = is_array($requirements ?? null) ? $requirements : [];
$releasesPageUrl = (string) ($releases_page_url ?? update_releases_page_url());
$manualUploadMaxBytes = (int) ($manual_upload_max_bytes ?? \Core\AppUpdater::manualUploadMaxBytes());
$currentVersionStr = (string) ($currentVersion ?? '');
$serverUpdateAllowed = !empty($requirements['server_update']);
$hasZip = !empty($requirements['zip']);
$hasUpdate = $latest !== '' && version_compare($latest, $currentVersionStr, '>');
$canConfirmUpdate = $serverUpdateAllowed && $hasZip;
?>
<div id="app-update">
<?php if ($showManifestUi): ?>
<?php admin_c_form_block01_open(); ?>
            <div class="block is-title">
                <?php admin_m_large_title01('サーバーから更新'); ?>
            </div>
            <div class="block is-field">
                <?php
                admin_settings_value_text01('現在のバージョン', 'settings_update_current_version', $currentVersionStr);
                if ($latest !== '') {
                    admin_settings_value_text01('最新リリース', 'settings_update_latest_version', $latest);
                }
                admin_settings_value_text01('ZipArchive', 'settings_update_ziparchive', $hasZip ? '利用可' : '不可（サーバー拡張が必要）');
                if ($releasesPageUrl !== '') {
                    admin_m_input_set01_open();
                    echo '<div class="area is-title">';
                    admin_m_bold_title01(e('リリースのダウンロード'), 'settings_update_releases_url');
                    echo '</div>';
                    echo '<div class="area is-field">';
                    echo '<p class="text is-help"><a href="' . e($releasesPageUrl) . '" target="_blank" rel="noopener noreferrer">バージョン一覧ページを開く</a></p>';
                    echo '</div>';
                    admin_m_input_set01_close();
                }
                ?>

                <?php if (($manifestError ?? '') !== ''): ?>
                    <p data-module="m-text01" data-type="danger"><?= e($manifestError) ?></p>
                <?php endif; ?>

                <?php if (!$serverUpdateAllowed): ?>
                    <p data-module="m-text01" data-type="muted">サーバーからの更新は無効です。<code>config.local.php</code> の <code>update.enabled</code> を確認してください。</p>
                <?php elseif (!$hasZip): ?>
                    <p data-module="m-text01" data-type="danger">ZipArchive 拡張が無効のため、サーバーからの更新は利用できません。</p>
                <?php elseif ($hasUpdate): ?>
                    <div class="area is-actions">
                        <form method="post" action="<?= e(base_path('/admin/settings/update')) ?>" onsubmit="return confirm('バージョン <?= e($latest) ?> に更新します。よろしいですか？');">
                            <?= \Core\Csrf::field() ?>
                            <input type="hidden" name="version" value="<?= e($latest) ?>">
                            <button type="submit" class="btn is-primary">更新を確認</button>
                        </form>
                    </div>
                    <p class="text is-help">ZIP には環境設定を含めません。更新前にバックアップを推奨します。</p>
                <?php elseif ($canConfirmUpdate): ?>
                    <div class="area is-actions">
                        <form method="post" action="<?= e(base_path('/admin/settings/update-check')) ?>">
                            <?= \Core\Csrf::field() ?>
                            <button type="submit" class="btn is-primary">更新を確認</button>
                        </form>
                    </div>
                <?php endif; ?>
            </div>
<?php admin_c_form_block01_close(); ?>
<?php endif; ?>

<div id="app-update-manual">
<?php admin_c_form_block01_open(); ?>
            <div class="block is-title">
                <?php admin_m_large_title01($showManifestUi ? '手動 ZIP で更新' : 'バージョン'); ?>
            </div>
            <div class="block is-field">
                <?php
                if (!$showManifestUi) {
                    admin_settings_value_text01('現在のバージョン', 'settings_update_manual_current_version', $currentVersionStr);
                    admin_settings_value_text01('ZipArchive', 'settings_update_manual_ziparchive', $hasZip ? '利用可' : '不可（サーバー拡張が必要）');
                    if ($releasesPageUrl !== '') {
                        admin_m_input_set01_open();
                        echo '<div class="area is-title">';
                        admin_m_bold_title01(e('リリースのダウンロード'), 'settings_update_releases_url');
                        echo '</div>';
                        echo '<div class="area is-field">';
                        echo '<p class="text is-help"><a href="' . e($releasesPageUrl) . '" target="_blank" rel="noopener noreferrer">バージョン一覧ページを開く</a></p>';
                        echo '</div>';
                        admin_m_input_set01_close();
                    }
                }
                ?>
                <?php if (!$hasZip): ?>
                    <p data-module="m-text01" data-type="danger">ZipArchive 拡張が無効のため、手動アップロードは利用できません。</p>
                <?php else: ?>
                    <form method="post" action="<?= e(base_path('/admin/settings/update-upload')) ?>" enctype="multipart/form-data" data-module="c-updateUpload01" data-max-bytes="<?= (int) $manualUploadMaxBytes ?>">
                        <?= \Core\Csrf::field() ?>
                        <?php admin_c_update_upload01_zone(); ?>
                        <div class="area is-actions">
                            <?php admin_m_btn01_button_wrap('ZIP を適用して更新', [
                                'type' => 'submit',
                                'class' => 'is-primary',
                                'data-target' => 'c-updateUpload01__submit',
                            ]); ?>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
<?php admin_c_form_block01_close(); ?>
</div>
</div>
