<?php /** 設定 → LINE 連携: チェックリスト全完了後のコンパクト表示 */
/** @var array<string, mixed> $lineSiteForm */
/** @var array<string, list<string>> $lineCredentialErrors */
/** @var string $lineTalkSetupChecklistSyncUrl */
/** @var string $lineWebhookTargetDeleteUrl */
?>
<div data-module="c-lineAccountLinkedCompact01">
    <div class="block is-status">
        <span class="mark is-check" aria-hidden="true">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </span>
        <p class="text is-statusLabel">アカウント連携済</p>
    </div>

    <div class="block is-section">
        <div class="area is-field">
            <?php
            $lineCredentialFieldKey = 'line_channel_secret';
            $lineCredentialLabel = 'チャネルシークレット';
            $lineCredentialHideTitle = false;
            $lineCredentialContext = 'site';
            $form = $lineSiteForm;
            require APP_DIR . '/views/admin/forms/detail/mail/_content_line_credential_field.php';
            ?>
        </div>
    </div>

    <div class="block is-section">
        <div class="area is-field">
            <?php
            $lineCredentialFieldKey = 'line_channel_access_token';
            $lineCredentialLabel = 'チャネルアクセストークン';
            $lineCredentialHideTitle = false;
            $lineCredentialContext = 'site';
            $form = $lineSiteForm;
            require APP_DIR . '/views/admin/forms/detail/mail/_content_line_credential_field.php';
            ?>
        </div>
    </div>

    <div class="block is-section">
        <div class="area is-field">
            <?php
            $lineWebhookHideTitle = false;
            $lineWebhookHideHelp = true;
            require APP_DIR . '/views/admin/forms/detail/mail/_content_line_webhook_url.php';
            ?>
        </div>
    </div>

    <div class="block is-section">
        <div class="area is-title">
            <?php admin_m_bold_title01(e('LINEトークへの送信先ID取得')); ?>
        </div>
        <div class="area is-field">
            <?php
            $lineTalkSetupContext = 'site';
            $lineTalkSetupCompact = true;
            require APP_DIR . '/views/admin/forms/detail/mail/_content_line_talk_setup.php';
            ?>
        </div>
    </div>

    <div class="block is-section">
        <div class="area is-field">
            <?php
            $linePushToIdHideTitle = false;
            $linePushToIdHideHelp = true;
            $linePushToIdInlineSave = true;
            $linePushToIdCompactTitle = '送信先ID';
            $linePushToIdContext = 'site';
            $form = $lineSiteForm;
            require APP_DIR . '/views/admin/forms/detail/mail/_content_line_push_to_id.php';
            ?>
        </div>
    </div>

    <div class="block is-section">
        <div class="area is-title">
            <?php admin_m_bold_title01(e('通知テスト')); ?>
        </div>
        <div class="area is-field">
            <?php
            $lineNotifyTestContext = 'site';
            $form = $lineSiteForm;
            require APP_DIR . '/views/admin/forms/detail/mail/_content_line_notify_test.php';
            ?>
        </div>
    </div>
</div>
