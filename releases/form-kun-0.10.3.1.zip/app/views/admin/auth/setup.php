<form method="post" action="<?= e(base_path('/admin/setup')) ?>" class="block is-contents">
    <?= \Core\Csrf::field() ?>
    <div class="area is-title">
        <h2 class="title">初期セットアップ</h2>
    </div>
    <div class="area is-description">
        <p data-module="m-text01" data-type="muted">最初の管理者アカウントを作成します。</p>
    </div>
    <?php if (!empty($errors)): ?>
        <div class="area is-alert">
            <div data-module="m-alert01" class="is-danger">
                <ul>
                <?php foreach ($errors as $e): ?><li><?= e($e) ?></li><?php endforeach; ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('ユーザー名'), 'username'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('username', [
                    'type' => 'text',
                    'id' => 'username',
                    'name' => 'username',
                    'value' => (string) ($old['username'] ?? ''),
                    'required' => true,
                ])); ?>
                <?php admin_m_input01_close(); ?>
                <p class="text is-help">半角英数字・記号(_.-)で 3〜64 文字</p>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('表示名（任意）'), 'display_name'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('display_name', [
                    'type' => 'text',
                    'id' => 'display_name',
                    'name' => 'display_name',
                    'value' => (string) ($old['display_name'] ?? ''),
                ])); ?>
                <?php admin_m_input01_close(); ?>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('メールアドレス（任意・推奨）'), 'email'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('email', [
                    'type' => 'email',
                    'id' => 'email',
                    'name' => 'email',
                    'value' => (string) ($old['email'] ?? ''),
                    'autocomplete' => 'email',
                ])); ?>
                <?php admin_m_input01_close(); ?>
                <p class="text is-help">パスワードを忘れたときに再設定メールを送るために使用します。</p>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('パスワード'), 'password'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('password', [
                    'type' => 'password',
                    'id' => 'password',
                    'name' => 'password',
                    'required' => true,
                ])); ?>
                <?php admin_m_input01_close(); ?>
                <p class="text is-help">8文字以上を推奨</p>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('パスワード（確認）'), 'password_confirm'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('password_confirm', [
                    'type' => 'password',
                    'id' => 'password_confirm',
                    'name' => 'password_confirm',
                    'required' => true,
                ])); ?>
                <?php admin_m_input01_close(); ?>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>
    <div class="area is-actions">
        <?php admin_m_btn01_button_wrap('管理者を作成する', ['type' => 'submit', 'class' => 'is-primary']); ?>
    </div>
</form>
