<?php
$webauthnAvailable = \Core\WebAuthnService::available();
?>
<form method="post" action="<?= e(base_path('/admin/login')) ?>" class="block is-contents" id="admin-login-form">
    <?= \Core\Csrf::field() ?>
    <div class="area is-title">
        <h2 class="title">ログイン</h2>
    </div>

    <?php if ($webauthnAvailable): ?>
        <div class="area is-field" data-module="adminAuthPasskey01">
            <div data-admin-webauthn-message hidden data-module="m-alert01" class="is-danger" style="margin-bottom: 12px;"></div>
            <?php admin_m_btn01_button_wrap('パスキーでログイン', [
                'type' => 'button',
                'data-admin-webauthn' => 'login',
                'data-username-input' => 'username',
            ]); ?>
            <p class="text is-help" style="margin-top: 12px; text-align: center;">または</p>
        </div>
    <?php endif; ?>

    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('ログインID'), 'username'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('username', [
                    'type' => 'text',
                    'id' => 'username',
                    'name' => 'username',
                    'autocomplete' => 'username',
                    'required' => true,
                ])); ?>
                <?php admin_m_input01_close(); ?>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('パスワード'), 'password'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('password', [
                    'type' => 'password',
                    'id' => 'password',
                    'name' => 'password',
                    'autocomplete' => 'current-password',
                    'required' => true,
                ])); ?>
                <?php admin_m_input01_close(); ?>
            </div>
        <?php admin_m_input_set01_close(); ?>
        <p class="text is-help is-authForgot">
            <a href="<?= e(base_path('/admin/forgot-password')) ?>">パスワードをお忘れの場合</a>
        </p>
    </div>
    <div class="area is-actions">
        <?php admin_m_btn01_button_wrap('ログイン', ['type' => 'submit', 'class' => 'is-primary']); ?>
    </div>
</form>
<?php if ($webauthnAvailable): ?>
<script>
window.FORMKUN_BASE = <?= json_encode(base_path(''), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE | JSON_HEX_APOS) ?>;
window.FORMKUN_CSRF = <?= json_encode(\Core\Csrf::token(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE | JSON_HEX_APOS) ?>;
</script>
<script defer src="<?= e(base_path('/assets/js/admin-auth-webauthn.js')) ?>"></script>
<?php endif; ?>
