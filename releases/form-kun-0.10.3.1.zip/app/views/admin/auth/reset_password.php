<form method="post" action="<?= e(base_path('/admin/reset-password')) ?>" class="block is-contents">
    <?= \Core\Csrf::field() ?>
    <input type="hidden" name="token" value="<?= e($token) ?>">
    <div class="area is-title">
        <h2 class="title">新しいパスワードを設定</h2>
    </div>
    <?php if (!empty($errors)): ?>
        <div class="area is-alert">
            <div data-module="m-alert01" class="is-danger">
                <ul><?php foreach ($errors as $msg): ?><li><?= e($msg) ?></li><?php endforeach; ?></ul>
            </div>
        </div>
    <?php endif; ?>
    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('新しいパスワード'), 'password'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('password', [
                    'type' => 'password',
                    'id' => 'password',
                    'name' => 'password',
                    'autocomplete' => 'new-password',
                    'required' => true,
                    'minlength' => 8,
                ])); ?>
                <?php admin_m_input01_close(); ?>
                <p class="text is-help">8文字以上</p>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('新しいパスワード（確認）'), 'password_confirm'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('password_confirm', [
                    'type' => 'password',
                    'id' => 'password_confirm',
                    'name' => 'password_confirm',
                    'autocomplete' => 'new-password',
                    'required' => true,
                ])); ?>
                <?php admin_m_input01_close(); ?>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>
    <div class="area is-actions">
        <?php admin_m_btn01_button_wrap('設定する', ['type' => 'submit', 'class' => 'is-primary']); ?>
    </div>
</form>
