<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
?>
<div data-module="m-toolbar01">
    <h1 class="title" style="margin:0;">ユーザー管理</h1>
    <div class="spacer"></div>
    <?php if (!empty($storage_resource) && is_array($storage_resource)): ?>
        <?php admin_c_progress01_resource_summary($storage_resource); ?>
    <?php endif; ?>
</div>

<?php admin_c_form_block01_open(); ?>
<div class="area is-field">
    <?php if (empty($users)): ?>
        <p data-module="m-text01" data-type="muted">ユーザーがありません。</p>
    <?php else: ?>
        <?php admin_m_table01_open(); ?>
        <?php admin_m_table01_thead([
            ['label' => 'ユーザー名'],
            ['label' => '表示名'],
            ['label' => 'メール'],
            ['label' => '権限', 'class' => 'is-workflow-status'],
            ['label' => '最終ログイン', 'class' => 'is-updated-at'],
            ['label' => '', 'class' => 'is-actions'],
        ]); ?>
        <tbody>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><code><?= e($u['username']) ?></code></td>
                    <td><?= e($u['display_name'] ?? '') ?></td>
                    <td><?= e($u['email'] ?? '') !== '' ? e($u['email']) : '—' ?></td>
                    <td class="is-workflow-status"><?php
                        $roleLabel = match ((string) $u['role']) {
                            'admin' => 'admin',
                            'editor' => 'editor',
                            'viewer' => 'viewer',
                            default => (string) $u['role'],
                        };
                        admin_m_badge01($roleLabel, (string) $u['role']);
                    ?></td>
                    <td class="is-updated-at"><?= e($u['last_login_at'] ?? '-') ?></td>
                    <td class="is-actions">
                        <details class="c-tableActionMenu01">
                            <summary class="c-tableActionMenu01__toggle" aria-label="操作">
                                <span aria-hidden="true">⋯</span>
                            </summary>
                            <div class="c-tableActionMenu01__menu" role="menu" aria-label="操作">
                                <a role="menuitem" href="<?= e(base_path('/admin/users/' . $u['id'] . '/edit')) ?>">編集</a>
                                <?php if ((int) $u['id'] !== (int) \Core\Auth::id()): ?>
                                    <form method="post"
                                        action="<?= e(base_path('/admin/users/' . $u['id'] . '/delete')) ?>"
                                        onsubmit="return confirm('このユーザーを削除しますか？');">
                                        <?= \Core\Csrf::field() ?>
                                        <?php admin_m_delete_btn01('admin-user-delete-' . $u['id'], '削除', '削除', 'submit', '削除'); ?>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </details>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <?php admin_m_table01_close(); ?>
    <?php endif; ?>
</div>
<div class="area is-actions">
    <?php admin_m_btn01_link_wrap('＋ 新規作成', base_path('/admin/users/new'), ['class' => 'is-primary']); ?>
</div>
<?php admin_c_form_block01_close(); ?>
