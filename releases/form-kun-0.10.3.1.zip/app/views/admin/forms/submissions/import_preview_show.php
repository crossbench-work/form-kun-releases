<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
require_once APP_COMPONENTS_DIR . '/m-alert01/m-alert01.php';

$formId = (int) $form['id'];
$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
$listPath = '/admin/forms/' . $formId . '/submissions';
$importPath = $listPath . '/import';
$previewPath = $importPath . '/' . $token . ($backPage > 1 ? '?page=' . (int) $backPage : '');
$workflowStatus = (string) ($sub['workflow_status'] ?? \Models\Submission::WORKFLOW_PENDING);
$dataLabel = !empty($duplicate) ? '既にデータが存在します' : 'データを追加します';
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'href' => base_path($listPath)],
    ['label' => 'インポート', 'href' => base_path($importPath)],
    ['label' => 'プレビュー', 'href' => base_path($previewPath)],
    ['label' => (string) ($sub['submitted_at'] ?? ''), 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-field">
                                <?php admin_m_alert01('プレビュー（未インポート）。「インポートする」を押すまで DB には登録されません。', 'info'); ?>
                            </div>
                            <div class="area is-field">
                                <?php admin_m_table01_open('is-kv'); ?>
                                    <tr><th>フォーム</th><td><?= e($form['title']) ?>（<code><?= e($form['slug']) ?></code>）</td></tr>
                                    <tr><th>データ</th><td><?= e($dataLabel) ?></td></tr>
                                    <tr><th>受信日時</th><td><?= e((string) ($sub['submitted_at'] ?? '')) ?></td></tr>
                                    <tr><th>状態</th><td><?= e(\Models\Submission::workflowStatusLabel($workflowStatus)) ?></td></tr>
                                    <tr><th>IPアドレス</th><td><?= e((string) ($sub['ip'] ?? '')) ?></td></tr>
                                    <tr><th>User-Agent</th><td><?= e((string) ($sub['user_agent'] ?? '')) ?></td></tr>
                                    <?php if (\Models\Submission::isMailOnlyMetadata($sub)): ?>
                                        <tr><th>保存方式</th><td>送信内容・添付ファイルを保存せず、SMTPメールのみ送信</td></tr>
                                        <tr><th>送信経路</th><td><?= e(\Models\Submission::deliveryRouteLabel((string) ($sub['delivery_route'] ?? ''))) ?></td></tr>
                                        <tr><th>SMTP配送結果</th><td><?= e(\Models\Submission::mailDeliveryStatusLabel((string) ($sub['mail_delivery_status'] ?? 'success'))) ?></td></tr>
                                        <tr><th>自動返信結果</th><td><?= ($sub['mail_error_code'] ?? null) === 'reply_delivery_failed' ? '失敗' : '成功または対象なし' ?></td></tr>
                                        <tr><th>添付</th><td><?= number_format((int) ($sub['attachment_count'] ?? 0)) ?>件 / <?= e(\Core\Validator::formatBytes((int) ($sub['attachment_total_bytes'] ?? 0))) ?></td></tr>
                                    <?php endif; ?>
                                <?php admin_m_table01_close(); ?>
                            </div>
                            <div class="area is-actions">
                                <a class="btn" href="<?= e(base_path($previewPath)) ?>">プレビュー一覧へ戻る</a>
                            </div>
<?php admin_c_form_block01_close(); ?>

<?php if (\Models\Submission::isMailOnlyMetadata($sub)): ?>
    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title"><?php admin_m_large_title01('入力内容'); ?></div>
        <div class="area is-field">
            <p data-module="m-text01" data-type="muted">この送信はSMTPメールのみで受け付けたため、入力内容・添付ファイル・ファイル名は保存していません。</p>
        </div>
    <?php admin_c_form_block01_close(); ?>
<?php else: ?>
<?php admin_c_form_block01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_large_title01('入力内容'); ?>
                            </div>
                            <div class="area is-field">
                                <?php admin_m_table01_open('is-kv'); ?>
                                <?php foreach ($fields as $f):
                                    $key = $f['field_key'];
                                ?>
                                    <tr>
                                        <th><?= e($f['label']) ?><br><span data-module="m-text01" data-type="muted"><?= e($key) ?></span></th>
                                        <td>
                                        <?php if ($f['type'] === 'file'): ?>
                                            <?php $files = $filesByKey[$key] ?? []; ?>
                                            <?php if (empty($files)): ?>
                                                <span data-module="m-text01" data-type="muted">（ファイルなし）</span>
                                            <?php else: ?>
                                                <div class="m-submissionFilePreview01 is-detail">
                                                    <?php foreach ($files as $fl): ?>
                                                        <?php
                                                            $fileIndex = (int) ($fl['preview_file_index'] ?? 0);
                                                            $fileUrl = admin_import_preview_file_url($formId, (string) $token, (int) $archiveIndex, $fileIndex);
                                                            $fileName = (string) ($fl['original_name'] ?? 'file');
                                                        ?>
                                                        <div class="m-submissionFilePreview01__item">
                                                            <?php if (is_safe_inline_submission_file($fl)): ?>
                                                                <a class="m-submissionFilePreview01__thumbLink" href="<?= e($fileUrl) ?>" target="_blank" rel="noopener noreferrer" title="<?= e($fileName) ?>">
                                                                    <img class="m-submissionFilePreview01__thumb" src="<?= e($fileUrl) ?>" alt="<?= e($fileName) ?>" loading="lazy">
                                                                </a>
                                                            <?php else: ?>
                                                                <a class="m-submissionFilePreview01__link" href="<?= e(admin_import_preview_file_url($formId, (string) $token, (int) $archiveIndex, $fileIndex, false)) ?>" target="_blank" rel="noopener noreferrer"><?= e($fileName) ?></a>
                                                            <?php endif; ?>
                                                            <span class="m-submissionFilePreview01__meta" data-module="m-text01" data-type="muted">
                                                                <?php if (!is_safe_inline_submission_file($fl)): ?>
                                                                    <?= e($fileName) ?>
                                                                <?php endif; ?>
                                                                （<?= e(\Core\Validator::formatBytes((int) ($fl['size'] ?? 0))) ?><?= ($fl['mime_type'] ?? '') !== '' ? ' / ' . e((string) $fl['mime_type']) : '' ?>）
                                                            </span>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php else:
                                            $val = $values[$key] ?? '';
                                        ?>
                                            <?php if ($f['type'] === 'address'): ?>
                                                <?php $addrText = format_address_value_display($val); ?>
                                                <?= $addrText !== '' ? nl2br(e($addrText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
                                            <?php elseif ($f['type'] === 'text_pair'): ?>
                                                <?php $pairText = format_text_pair_value_display($val, \Models\FormField::decodeTextPairLabels($f['options_json'] ?? null)); ?>
                                                <?= $pairText !== '' ? nl2br(e($pairText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
                                            <?php elseif ($f['type'] === 'text_multi'): ?>
                                                <?php $multiText = format_text_multi_value_display($val, \Models\FormField::decodeTextMultiItems($f['options_json'] ?? null, true)); ?>
                                                <?= $multiText !== '' ? nl2br(e($multiText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
                                            <?php elseif ($f['type'] === \Models\FormField::TYPE_MATRIX): ?>
                                                <?php $matrixText = format_matrix_value_display($val, \Models\FormField::decodeMatrixSettings($f['options_json'] ?? null)); ?>
                                                <?= $matrixText !== '' ? nl2br(e($matrixText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
                                            <?php else: ?>
                                                <?= $val !== '' ? nl2br(e((string) $val)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>

                                <?php
                                    $fieldKeys = array_map(static fn($f) => $f['field_key'], $fields);
                                    foreach ($values as $k => $v):
                                        if (in_array($k, $fieldKeys, true)) {
                                            continue;
                                        }
                                ?>
                                    <tr>
                                        <th>(削除済み項目)<br><span data-module="m-text01" data-type="muted"><?= e($k) ?></span></th>
                                        <td><?= nl2br(e((string) $v)) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php admin_m_table01_close(); ?>
                            </div>
<?php admin_c_form_block01_close(); ?>
<?php endif; ?>
