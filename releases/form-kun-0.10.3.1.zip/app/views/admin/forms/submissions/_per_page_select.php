<?php
/**
 * 表示件数セレクト（送信履歴・エクスポート共通）
 * 必須: $perPage, $perPageSelectId
 */
$perPage = (int) ($perPage ?? 20);
$perPageSelectId = (string) ($perPageSelectId ?? 'submissions-per-page');
?>
<?php admin_m_input01_open(); ?>
    <select id="<?= e($perPageSelectId) ?>"
            class="m-inout01__input"
            aria-label="表示件数"
            data-target="submissionsPerPage01__select">
        <?php foreach ([10, 20, 50, 100] as $option): ?>
            <option value="<?= (int) $option ?>"<?= $perPage === (int) $option ? ' selected' : '' ?>><?= (int) $option ?>件</option>
        <?php endforeach; ?>
    </select>
<?php admin_m_input01_close(); ?>
