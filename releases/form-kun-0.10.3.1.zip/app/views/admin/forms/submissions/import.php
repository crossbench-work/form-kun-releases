<?php
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php';

$formId = (int) $form['id'];
$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
$listPath = '/admin/forms/' . $formId . '/submissions';
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'href' => base_path($listPath)],
    ['label' => 'インポート', 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_large_title01('受信履歴のインポート'); ?>
                            </div>
                            <form method="post" action="<?= e(base_path($listPath . '/import')) ?>" enctype="multipart/form-data">
                                <?= \Core\Csrf::field() ?>
                                <div class="area is-field">
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('エクスポートした ZIP ファイル', 'submissions-import-file'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-import-file', [
                                                    'type' => 'file',
                                                    'name' => 'import_file',
                                                    'id' => 'submissions-import-file',
                                                    'accept' => 'application/zip,.zip',
                                                    'required' => true,
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <p class="text is-help">「添付ファイルも含める（ZIP）」でエクスポートしたファイルを指定してください（上限 <?= number_format((int) floor($maxBytes / 1048576)) ?>MB）。次の画面で内容を確認でき、確認しただけでは DB に登録されません。</p>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div class="area is-actions">
                                    <a class="btn" href="<?= e(base_path($listPath)) ?>">戻る</a>
                                    <button type="submit" class="btn is-primary">プレビュー</button>
                                </div>
                            </form>
<?php admin_c_form_block01_close(); ?>
