<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
require_once APP_COMPONENTS_DIR . '/c-halfModal01/c-halfModal01.php';
require_once APP_COMPONENTS_DIR . '/m-checkbox01/m-checkbox01.php';
require_once APP_COMPONENTS_DIR . '/m-alert01/m-alert01.php';

$formId = (int) $form['id'];
$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
$listPath = '/admin/forms/' . $formId . '/submissions';
$exportPath = $listPath . '/export';
$periodQuery = array_filter(['from' => (string) $from, 'to' => (string) $to], static fn(string $v): bool => $v !== '');
$periodQuery['per_page'] = (int) ($perPage ?? 20);
$exportListUrl = base_path($exportPath);
$exportPageUrl = $exportPath . ($periodQuery !== [] ? '?' . http_build_query($periodQuery) : '');
$hasExportPeriodFilter = $from !== '' || $to !== '';
$hasMailOnlyRows = !empty(array_filter($rows ?? [], static fn(array $row): bool => \Models\Submission::isMailOnlyMetadata($row)));
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'href' => base_path($listPath)],
    ['label' => 'エクスポート', 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-field">
                                <?php if (!empty($exportNotice)): ?>
                                    <?php
                                    $exportBasePath = $exportPath . '/' . $exportNotice['token'];
                                    $exportDownloadUrl = base_path($exportBasePath . '/download');
                                    $exportCount = number_format((int) $exportNotice['count']);
                                    ?>
                                    <div <?= admin_m_alert01_attrs('success') ?>>
                                        <p>
                                            <?= $exportCount ?>件のエクスポートを準備しました（<?= e($exportNotice['filename']) ?>）。
                                            ダウンロードが始まらない場合は<a href="<?= e($exportDownloadUrl) ?>">こちら</a>からダウンロードしてください。
                                        </p>
                                        <?php if (empty($exportNotice['downloaded'])): ?>
                                            <iframe src="<?= e($exportDownloadUrl) ?>" title="エクスポートのダウンロード" hidden></iframe>
                                        <?php endif; ?>
                                        <div data-module="m-toolbar01">
                                            <form method="post"
                                                  action="<?= e(base_path($exportBasePath . '/delete')) ?>"
                                                  onsubmit="return confirm('エクスポートした <?= e($exportCount) ?> 件の送信を削除します。添付ファイルも削除され、元に戻せません。よろしいですか？');">
                                                <?= \Core\Csrf::field() ?>
                                                <button class="btn is-danger is-sm" type="submit">エクスポートした <?= e($exportCount) ?> 件を削除</button>
                                            </form>
                                            <a class="btn is-sm" href="<?= e(base_path($exportPageUrl)) ?>">閉じる</a>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php $showRetentionListNotice = false; require __DIR__ . '/_retention_notice.php'; ?>

                                <div data-target="submissionsExportLive01">
                                <?php if (!empty($periodError)): ?>
                                    <?php admin_m_alert01($periodError, 'danger'); ?>
                                <?php endif; ?>

                                <div data-module="m-submissionListToolbar01">
                                    <div data-module="m-toolbar01">
                                        <span data-module="m-text01" data-type="muted"><?= number_format($total) ?>件</span>
                                        <?php $perPageSelectId = 'submissions-export-per-page'; require __DIR__ . '/_per_page_select.php'; ?>
                                        <span class="m-submissionListToolbar01__divider" aria-hidden="true"></span>
                                        <span class="m-submissionListToolbar01__group">
                                            <button type="button"
                                                    class="btn is-icon<?= $hasExportPeriodFilter ? ' is-active' : '' ?>"
                                                    data-target="submissions-export-period-open"
                                                    aria-label="検索"
                                                    title="検索"
                                                    aria-pressed="<?= $hasExportPeriodFilter ? 'true' : 'false' ?>">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                                            </button>
                                            <?php if ($hasExportPeriodFilter): ?>
                                            <a class="btn is-icon"
                                               href="<?= e($exportListUrl) ?>"
                                               aria-label="リセット"
                                               title="リセット">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
                                            </a>
                                            <?php endif; ?>
                                        </span>
                                        <span class="m-submissionListToolbar01__divider" aria-hidden="true"></span>
                                            <?php
                                            $exportOpenDisabled = (int) $total === 0 || !empty($rows);
                                            ?>
                                            <button class="btn is-primary is-iconLabel" type="button" data-target="submissions-export-open"<?= $exportOpenDisabled ? ' disabled' : '' ?> aria-label="書出し">
                                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
                                                <span>書出し</span>
                                            </button>
                                    </div>
                                </div>

                                <?php if (empty($rows)): ?>
                                    <p data-module="m-text01" data-type="muted">該当する送信がありません。</p>
                                <?php else: ?>
                                    <?php admin_m_table01_open('is-submissionList'); ?>
                                        <thead>
                                            <tr>
                                                <th class="is-bulk-checkbox">
                                                    <input type="checkbox"
                                                           value="1"
                                                           aria-label="一覧の送信をすべて選択"
                                                           data-target="submissionsExportSelect01__selectAll">
                                                </th>
                                                <th class="is-submitted-at">受信日時</th>
                                                <th class="is-workflow-status">状態</th>
                                                <?php if ($hasMailOnlyRows): ?>
                                                    <th>保存方式</th>
                                                    <th>SMTP配送</th>
                                                    <th>添付</th>
                                                <?php endif; ?>
                                                <?php foreach ($previewKeys as $key):
                                                    $label = '';
                                                    foreach ($fields as $f) { if ($f['field_key'] === $key) { $label = $f['label']; break; } }
                                                ?>
                                                    <th><?= e($label ?: $key) ?></th>
                                                <?php endforeach; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($rows as $r):
                                            $workflowStatus = (string) ($r['workflow_status'] ?? \Models\Submission::WORKFLOW_PENDING);
                                        ?>
                                            <tr>
                                                <td class="is-bulk-checkbox">
                                                    <input type="checkbox"
                                                           name="submission_ids[]"
                                                           value="<?= e((string) $r['id']) ?>"
                                                           form="submissions-export-modal-form"
                                                           aria-label="送信ID <?= e((string) $r['id']) ?> を選択"
                                                           data-target="submissionsExportSelect01__checkbox">
                                                </td>
                                                <td class="is-submitted-at" data-sp-label="受信日時">
                                                    <?php if (!empty($retentionEnabled) && \Models\Form::isSubmissionExpired($form, (string) $r['submitted_at'], $retentionCutoff)): ?>
                                                        <?php admin_m_warning_mark01($retentionWarningText); ?>
                                                    <?php endif; ?>
                                                    <a href="<?= e(base_path('/admin/forms/submissions/' . $r['id'])) ?>">
                                                        <?= e($r['submitted_at']) ?>
                                                    </a>
                                                </td>
                                                <td class="is-workflow-status" data-sp-label="状態">
                                                    <?php admin_m_badge01(\Models\Submission::workflowStatusLabel($workflowStatus), $workflowStatus); ?>
                                                </td>
                                                <?php if ($hasMailOnlyRows): ?>
                                                    <?php if (\Models\Submission::isMailOnlyMetadata($r)): ?>
                                                        <td class="is-spField" data-sp-label="保存方式"><span class="is-spFieldValue">SMTPメールのみ</span></td>
                                                        <td class="is-spField" data-sp-label="SMTP配送"><span class="is-spFieldValue"><?= e(\Models\Submission::mailDeliveryStatusLabel((string) ($r['mail_delivery_status'] ?? 'success'))) ?></span></td>
                                                        <td class="is-spField" data-sp-label="添付"><span class="is-spFieldValue"><?= number_format((int) ($r['attachment_count'] ?? 0)) ?>件 / <?= e(\Core\Validator::formatBytes((int) ($r['attachment_total_bytes'] ?? 0))) ?></span></td>
                                                    <?php else: ?>
                                                        <td class="is-spField" data-sp-label="保存方式"><span class="is-spFieldValue">DB保存</span></td><td class="is-spField" data-sp-label="SMTP配送"><span class="is-spFieldValue">—</span></td><td class="is-spField" data-sp-label="添付"><span class="is-spFieldValue">—</span></td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php
                                                    $listPreviewRow = $r;
                                                    require __DIR__ . '/_list_preview_cells.php';
                                                ?>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    <?php admin_m_table01_close(); ?>

                                    <?php if ($totalPages > 1): ?>
                                    <?php admin_c_pagination01_open(); ?>
                                        <?php
                                            $qs = static function (int $p) use ($periodQuery): string {
                                                return '?' . http_build_query($periodQuery + ['page' => $p]);
                                            };
                                            $base = base_path($exportPath);
                                        ?>
                                        <?php if ($page > 1): ?>
                                            <a href="<?= e($base . $qs($page - 1)) ?>">‹ 前へ</a>
                                        <?php else: ?>
                                            <span class="disabled">‹ 前へ</span>
                                        <?php endif; ?>

                                        <?php for ($p = max(1, $page - 3); $p <= min($totalPages, $page + 3); $p++): ?>
                                            <?php if ($p === $page): ?>
                                                <span class="current"><?= $p ?></span>
                                            <?php else: ?>
                                                <a href="<?= e($base . $qs($p)) ?>"><?= $p ?></a>
                                            <?php endif; ?>
                                        <?php endfor; ?>

                                        <?php if ($page < $totalPages): ?>
                                            <a href="<?= e($base . $qs($page + 1)) ?>">次へ ›</a>
                                        <?php else: ?>
                                            <span class="disabled">次へ ›</span>
                                        <?php endif; ?>
                                    <?php admin_c_pagination01_close(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                                </div>
                            </div>

<?php admin_c_halfModal01_open(['hidden' => true]); ?>
    <?php admin_c_halfModal01_backdrop('submissions-export-period-close'); ?>
    <?php admin_c_halfModal01_panel_open('submissions-export-period-modal-title'); ?>
        <?php admin_c_halfModal01_header_open(); ?>
            <h2 id="submissions-export-period-modal-title">検索</h2>
            <button type="button" class="btn is-sm" data-target="submissions-export-period-close">閉じる</button>
        <?php admin_c_halfModal01_header_close(); ?>
        <?php admin_c_halfModal01_body_open(); ?>
            <form method="get" action="<?= e($exportListUrl) ?>" id="submissions-export-period-form">
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('期間'), 'submissions-export-period-from'); ?>
                    <div class="c-halfModal01__dateRange">
                        <?php admin_m_input01_open(); ?>
                            <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-export-period-from', [
                                'type' => 'date',
                                'id' => 'submissions-export-period-from',
                                'name' => 'from',
                                'value' => (string) $from,
                            ])); ?>
                        <?php admin_m_input01_close(); ?>
                        <span class="c-halfModal01__dateRangeSep" aria-hidden="true">〜</span>
                        <?php admin_m_input01_open(); ?>
                            <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-export-period-to', [
                                'type' => 'date',
                                'id' => 'submissions-export-period-to',
                                'name' => 'to',
                                'value' => (string) $to,
                            ])); ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                </div>
                <div class="c-halfModal01__actions is-centered">
                    <a class="btn"
                       href="<?= e($exportListUrl) ?>"
                       <?php if (!$hasExportPeriodFilter): ?>aria-disabled="true" tabindex="-1"<?php endif; ?>>リセット</a>
                </div>
            </form>
        <?php admin_c_halfModal01_body_close(); ?>
    <?php admin_c_halfModal01_panel_close(); ?>
<?php admin_c_halfModal01_close(); ?>

<?php if ((int) $total > 0): ?>
<?php
$periodLabel = ($from === '' && $to === '')
    ? '全期間'
    : str_replace('-', '/', (string) $from) . '〜' . str_replace('-', '/', (string) $to);
?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('submissions-export-close'); ?>
    <?php admin_c_modal01_dialog_open('submissions-export-modal-title'); ?>
        <?php admin_c_modal01_header_open(); ?>
            <h2 id="submissions-export-modal-title">書出し</h2>
            <button type="button" class="btn is-sm" data-target="submissions-export-close">閉じる</button>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path($exportPath)) ?>" id="submissions-export-modal-form">
                <?= \Core\Csrf::field() ?>
                <input type="hidden" name="from" value="<?= e((string) $from) ?>">
                <input type="hidden" name="to" value="<?= e((string) $to) ?>">
                <input type="hidden" name="per_page" value="<?= e((string) ($perPage ?? 20)) ?>">
                <div class="area is-field">
                    <p>期間: <?= e($periodLabel) ?>（<span data-target="submissionsExportSelect01__modalCount">0</span>件を書出し）</p>
                </div>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('ファイル名'), 'submissions-export-filename'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-export-filename', [
                            'type' => 'text',
                            'id' => 'submissions-export-filename',
                            'name' => 'export_filename',
                            'maxlength' => 100,
                            'placeholder' => '空欄なら 期間_フォーム名',
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">拡張子は .zip（CSV と復元用 JSON <?= e(\Core\SubmissionArchive::MANIFEST_NAME) ?> を同梱）です。</p>
                </div>
                <div class="area is-field">
                    <?php admin_m_checkbox01('添付ファイルも含める', [
                        'name' => 'include_files',
                        'value' => '1',
                    ]); ?>
                    <p class="text is-help">チェックを付けると ZIP に添付ファイル本体も含めます。インポート（復元）ではこの ZIP ファイルを指定してください。</p>
                </div>
                <?php admin_c_modal01_actions_open(); ?>
                    <button type="button" class="btn" data-target="submissions-export-close">キャンセル</button>
                    <button type="submit" class="btn is-primary">書出し</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php endif; ?>
<?php admin_c_form_block01_close(); ?>
