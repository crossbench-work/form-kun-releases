<?php
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php';
require_once APP_COMPONENTS_DIR . '/m-checkbox01/m-checkbox01.php';
require_once APP_COMPONENTS_DIR . '/m-input01/m-input01.php';
require_once APP_COMPONENTS_DIR . '/m-boldTitle01/m-boldTitle01.php';

$formId = (int) $form['id'];
$exportPath = '/admin/forms/' . $formId . '/export';
$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
/** @var \Core\FormBundleExportOptions $options */
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'href' => base_path('/admin/forms/' . $formId . '/submissions')],
    ['label' => 'エクスポート', 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_large_title01('フォームのエクスポート'); ?>
                            </div>
                            <form method="post" action="<?= e(base_path($exportPath)) ?>" id="form-export-form">
                                <?= \Core\Csrf::field() ?>
                                <div class="area is-field">
                                    <p class="text is-help">フォーム定義（項目・入力画面・分岐）は常に ZIP に含まれます。SMTP パスワードと CAPTCHA シークレットは、下の暗号化パスワードを入力した場合のみ暗号化して同梱されます（LINE チャネル秘密はサイト設定のため含みません）。</p>
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('含める内容', 'form-export-options'); ?>
                                        </div>
                                        <div class="area is-field" id="form-export-options">
                                            <?php admin_m_checkbox01('送信履歴（DB）', [
                                                'name' => 'include_submissions',
                                                'value' => '1',
                                                'id' => 'form-export-include-submissions',
                                                'checked' => $options->includeSubmissions ? true : null,
                                            ]); ?>
                                            <?php admin_m_checkbox01('添付ファイル', [
                                                'name' => 'include_attachment_files',
                                                'value' => '1',
                                                'id' => 'form-export-include-attachments',
                                                'checked' => $options->includeAttachmentFiles ? true : null,
                                            ]); ?>
                                            <?php admin_m_checkbox01('SMTP・返信メール・管理者通知メール', [
                                                'name' => 'include_smtp',
                                                'value' => '1',
                                                'checked' => $options->includeSmtp ? true : null,
                                            ]); ?>
                                            <?php admin_m_checkbox01('LINE 通知設定', [
                                                'name' => 'include_line',
                                                'value' => '1',
                                                'checked' => $options->includeLine ? true : null,
                                            ]); ?>
                                            <?php admin_m_checkbox01('埋め込み API / CAPTCHA', [
                                                'name' => 'include_embed',
                                                'value' => '1',
                                                'checked' => $options->includeEmbed ? true : null,
                                            ]); ?>
                                            <p class="text is-help">埋め込みを含める場合、サイトキー等は平文 JSON に含まれます。シークレットキーは暗号化パスワードを指定したときのみ同梱されます。</p>
                                            <?php admin_m_checkbox01('カスタム meta / CSS / JS', [
                                                'name' => 'include_custom_assets',
                                                'value' => '1',
                                                'checked' => $options->includeCustomAssets ? true : null,
                                            ]); ?>
                                            <?php admin_m_checkbox01('公開・非公開スケジュール・終了画面', [
                                                'name' => 'include_publish_schedule',
                                                'value' => '1',
                                                'checked' => $options->includePublishSchedule ? true : null,
                                            ]); ?>
                                            <?php admin_m_checkbox01('送信データ保持・保存方式', [
                                                'name' => 'include_retention',
                                                'value' => '1',
                                                'checked' => $options->includeRetention ? true : null,
                                            ]); ?>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('秘密情報の暗号化（任意）', 'form-export-password'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('form-export-password', [
                                                    'type' => 'password',
                                                    'name' => 'export_password',
                                                    'id' => 'form-export-password',
                                                    'autocomplete' => 'new-password',
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <p class="text is-help">入力すると SMTP パスワードと CAPTCHA シークレットを暗号化して ZIP に含めます。インポート時に同じパスワードが必要です。空のままなら従来どおり秘密情報は含まれません。</p>
                                        </div>
                                        <div class="area is-field">
                                            <div class="area is-title">
                                                <?php admin_m_bold_title01('暗号化パスワード（確認）', 'form-export-password-confirm'); ?>
                                            </div>
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('form-export-password-confirm', [
                                                    'type' => 'password',
                                                    'name' => 'export_password_confirm',
                                                    'id' => 'form-export-password-confirm',
                                                    'autocomplete' => 'new-password',
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div class="area is-actions">
                                    <a class="btn" href="<?= e(base_path('/admin/forms')) ?>">戻る</a>
                                    <button type="submit" class="btn is-primary">ZIP をダウンロード</button>
                                </div>
                            </form>
                            <script>
                            (function () {
                                var subs = document.getElementById('form-export-include-submissions');
                                var attach = document.getElementById('form-export-include-attachments');
                                if (!subs || !attach) return;
                                function sync() {
                                    var on = subs.checked;
                                    attach.disabled = !on;
                                    if (!on) attach.checked = false;
                                }
                                subs.addEventListener('change', sync);
                                sync();
                            })();
                            </script>
<?php admin_c_form_block01_close(); ?>
