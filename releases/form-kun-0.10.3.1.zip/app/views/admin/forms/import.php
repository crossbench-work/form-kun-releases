<?php
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php';
require_once APP_COMPONENTS_DIR . '/m-input01/m-input01.php';
require_once APP_COMPONENTS_DIR . '/m-boldTitle01/m-boldTitle01.php';
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => 'インポート', 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_large_title01('フォームのインポート'); ?>
                            </div>
                            <form method="post"
                                action="<?= e(base_path('/admin/forms/import')) ?>"
                                enctype="multipart/form-data"
                                onsubmit="return confirm('ZIP を取り込むと新しい下書きフォームが作成されます。送信履歴は重複するものはスキップされます。よろしいですか？');">
                                <?= \Core\Csrf::field() ?>
                                <div class="area is-field">
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('エクスポートした ZIP ファイル', 'form-import-file'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('form-import-file', [
                                                    'type' => 'file',
                                                    'name' => 'import_file',
                                                    'id' => 'form-import-file',
                                                    'accept' => 'application/zip,.zip',
                                                    'required' => true,
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <p class="text is-help">フォーム一覧の「エクスポート」で保存した ZIP を指定してください（上限 <?= number_format((int) floor($maxBytes / 1048576)) ?>MB）。埋め込み設定は無効の下書きとして取り込まれます。</p>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                    <?php admin_m_input_set01_open(); ?>
                                        <div class="area is-title">
                                            <?php admin_m_bold_title01('インポート用パスワード', 'form-import-password'); ?>
                                        </div>
                                        <div class="area is-field">
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('form-import-password', [
                                                    'type' => 'password',
                                                    'name' => 'import_password',
                                                    'id' => 'form-import-password',
                                                    'autocomplete' => 'new-password',
                                                ])); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <p class="text is-help">エクスポート時に<strong>暗号化パスワード</strong>を設定した ZIP では、同じパスワードの入力が<strong>必須</strong>です（未入力・誤りではフォームも送信も取り込まれません）。暗号化していない ZIP では空のままで構いません。</p>
                                        </div>
                                    <?php admin_m_input_set01_close(); ?>
                                </div>
                                <div class="area is-actions">
                                    <a class="btn" href="<?= e(base_path('/admin/forms')) ?>">戻る</a>
                                    <button type="submit" class="btn is-primary">インポート</button>
                                </div>
                            </form>
<?php admin_c_form_block01_close(); ?>
