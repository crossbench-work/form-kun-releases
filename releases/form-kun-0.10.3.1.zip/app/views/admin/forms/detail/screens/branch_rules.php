<?php
/** フォーム編集: 分岐処理設定 */
$branchRules = \Models\FormBranchRule::normalizeRules($branchRules ?? []);
$fieldOptions = [];
$sourceFieldOptions = [];
$fieldOptionsByPage = [];
foreach ($fields ?? [] as $field) {
    $fieldKey = (string) ($field['field_key'] ?? '');
    if ($fieldKey === '') {
        continue;
    }
    $label = trim((string) ($field['label'] ?? '')) !== ''
        ? (string) $field['label'] . '（' . $fieldKey . '）'
        : $fieldKey;
    $fieldOptions[$fieldKey] = $label;
    if (\Models\FormField::isDisplayOnlyType((string) ($field['type'] ?? ''))) {
        continue;
    }
    $sourceFieldOptions[$fieldKey] = $label;
    $pageKey = (string) ($field['input_page_key'] ?? \Models\FormInputPage::DEFAULT_KEY);
    if (!isset($fieldOptionsByPage[$pageKey])) {
        $fieldOptionsByPage[$pageKey] = [];
    }
    $fieldOptionsByPage[$pageKey][$fieldKey] = $label;
}
$groupOptions = [];
foreach ($fieldGroups ?? [] as $group) {
    $groupKey = (string) ($group['group_key'] ?? '');
    if ($groupKey === '') {
        continue;
    }
    $label = trim((string) ($group['label'] ?? '')) !== ''
        ? 'グループ: ' . (string) $group['label'] . '（' . $groupKey . '）'
        : 'グループ: ' . $groupKey;
    $groupOptions[$groupKey] = $label;
}
$inputPageOptions = [];
foreach ($inputPages ?? [] as $page) {
    $pageKey = (string) ($page['page_key'] ?? '');
    if ($pageKey === '') {
        continue;
    }
    $inputPageOptions[$pageKey] = (string) ($page['title'] ?? $pageKey);
}
$screenOptions = $inputPageOptions;
$screenOptions[\Models\FormBranchRule::SCREEN_CONFIRM] = '確認画面';
$screenOptions[\Models\FormBranchRule::SCREEN_THANKS] = '完了画面';
$duplicateWarnings = \Models\FormBranchRule::duplicateTargetWarnings($branchRules);
$renderBranchRuleRow = static function (array $rule, $idx) use ($fieldOptions, $sourceFieldOptions, $fieldOptionsByPage, $groupOptions, $inputPageOptions, $screenOptions): void {
    $ruleKey = (string) ($rule['rule_key'] ?? ('branch-' . ((int) $idx + 1)));
    $actionType = (string) ($rule['action_type'] ?? \Models\FormBranchRule::ACTION_SHOW_FIELD);
    $targetType = (string) ($rule['target_type'] ?? \Models\FormBranchRule::TARGET_FIELD);
    $triggerPageKey = (string) ($rule['trigger_page_key'] ?? \Models\FormInputPage::DEFAULT_KEY);
    $sourceOptions = $fieldOptionsByPage[$triggerPageKey] ?? [];
    $sourceFieldKey = (string) ($rule['source_field_key'] ?? '');
    $targetKey = (string) ($rule['target_key'] ?? '');
    $triggerPageLabel = $inputPageOptions[$triggerPageKey] ?? $triggerPageKey;
    $sourceLabel = $sourceFieldKey !== '' ? ($sourceFieldOptions[$sourceFieldKey] ?? $sourceFieldKey) : '条件元未選択';
    $actionLabel = $actionType === \Models\FormBranchRule::ACTION_GO_TO_SCREEN ? 'ページへ移動する' : '項目/グループを表示する';
    $targetOptions = [];
    if ($actionType === \Models\FormBranchRule::ACTION_GO_TO_SCREEN) {
        foreach (array_diff_key($screenOptions, [$triggerPageKey => true]) as $value => $label) {
            $targetOptions[$value] = ['label' => $label, 'type' => 'screen'];
        }
    } else {
        foreach ($fieldOptions as $value => $label) {
            $targetOptions[$value] = ['label' => $label, 'type' => \Models\FormBranchRule::TARGET_FIELD];
        }
        foreach ($groupOptions as $value => $label) {
            $targetOptions[$value] = ['label' => $label, 'type' => \Models\FormBranchRule::TARGET_GROUP];
        }
    }
    $targetLabel = $targetKey !== '' ? ($targetOptions[$targetKey]['label'] ?? $targetKey) : '対象未選択';
    ?>
    <?php admin_c_form_editor_item01_open(['data-branch-rule-row' => true], true); ?>
        <div class="wrapper">
            <div class="block is-header">
                <?php admin_c_form_editor_item_header01_open(); ?>
                    <div class="area is-summary">
                        <div class="c-formEditorSummary01">
                            <div class="wrapper">
                                <div class="block is-contents">
                                    <p class="index" data-target="branchRuleSummaryIndex"><?= (int) $idx + 1 ?></p>
                                    <p class="label" data-target="branchRuleSummaryTriggerPage"><?= e($triggerPageLabel) ?></p>
                                    <p class="type" data-target="branchRuleSummarySource"><?= e($sourceLabel) ?></p>
                                    <p class="required" data-target="branchRuleSummaryAction"><?= e($actionLabel) ?></p>
                                    <p class="regex" data-target="branchRuleSummaryTarget">
                                        <svg width="12" height="12" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M20 6L9 17l-5-5"/></svg>
                                        <span data-target="branchRuleSummaryTargetLabel"><?= e($targetLabel) ?></span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="area is-delete">
                        <?php admin_m_delete_btn01('branchRuleRemove', 'この分岐を削除', 'この分岐を削除'); ?>
                    </div>
                <?php admin_c_form_editor_item_header01_close(); ?>
            </div>
            <div class="block is-body">
                <?php admin_c_form_editor_item_body01_open(); ?>
                    <input type="hidden" name="branch_rules[<?= e((string) $idx) ?>][rule_key]" value="<?= e($ruleKey) ?>" data-branch-rule-name="rule_key">
                    <input type="hidden" name="branch_rules[<?= e((string) $idx) ?>][_remove]" value="0" data-branch-rule-name="_remove" data-target="branchRuleRemoveFlag">
                    <input type="hidden" name="branch_rules[<?= e((string) $idx) ?>][target_type]" value="<?= e($targetType) ?>" data-branch-rule-name="target_type" data-target="branchRuleTargetType">
                    <div class="block is-contents">
                        <div class="c-formEditor__field">
                            <div class="wrapper">
                                <div class="block is-contents">
                                    <div class="block is-title">
                                        <label class="label" data-module="m-labelTitle01">対象ページ</label>
                                    </div>
                                    <div class="block is-field">
                                        <?php admin_m_input01_open(); ?>
                                            <?php admin_m_input01_select_open([
                                                'name' => 'branch_rules[' . $idx . '][trigger_page_key]',
                                                'data-branch-rule-name' => 'trigger_page_key',
                                                'data-target' => 'branchRuleTriggerPage',
                                            ]); ?>
                                                <?php foreach ($inputPageOptions as $value => $label): ?>
                                                    <?php admin_m_input01_option($value, $label, $triggerPageKey === $value); ?>
                                                <?php endforeach; ?>
                                            <?php admin_m_input01_select_close(); ?>
                                        <?php admin_m_input01_close(); ?>
                                    </div>
                                </div>
                                <div class="block is-contents">
                                    <div class="block is-title">
                                        <label class="label" data-module="m-labelTitle01">条件元</label>
                                    </div>
                                    <div class="block is-field">
                                        <?php admin_m_input01_open(); ?>
                                            <?php admin_m_input01_select_open([
                                                'name' => 'branch_rules[' . $idx . '][source_field_key]',
                                                'data-branch-rule-name' => 'source_field_key',
                                                'data-target' => 'branchRuleSourceField',
                                            ]); ?>
                                                <?php admin_m_input01_option('', '選択してください', (string) ($rule['source_field_key'] ?? '') === ''); ?>
                                                <?php foreach ($sourceOptions as $value => $label): ?>
                                                    <?php admin_m_input01_option($value, $label, (string) ($rule['source_field_key'] ?? '') === $value); ?>
                                                <?php endforeach; ?>
                                            <?php admin_m_input01_select_close(); ?>
                                        <?php admin_m_input01_close(); ?>
                                    </div>
                                </div>
                                <div class="block is-contents">
                                    <div class="block is-title">
                                        <label class="label" data-module="m-labelTitle01">値が一致</label>
                                    </div>
                                    <div class="block is-field">
                                        <?php admin_m_input01_open(); ?>
                                            <?php admin_m_input01_input([
                                                'type' => 'text',
                                                'name' => 'branch_rules[' . $idx . '][expected_value]',
                                                'value' => (string) ($rule['expected_value'] ?? ''),
                                                'data-branch-rule-name' => 'expected_value',
                                            ]); ?>
                                        <?php admin_m_input01_close(); ?>
                                    </div>
                                </div>
                                <div class="block is-contents">
                                    <div class="block is-title">
                                        <label class="label" data-module="m-labelTitle01">処理</label>
                                    </div>
                                    <div class="block is-field">
                                        <?php admin_m_input01_open(); ?>
                                            <?php admin_m_input01_select_open([
                                                'name' => 'branch_rules[' . $idx . '][action_type]',
                                                'data-branch-rule-name' => 'action_type',
                                                'data-target' => 'branchRuleActionType',
                                            ]); ?>
                                                <?php admin_m_input01_option(\Models\FormBranchRule::ACTION_SHOW_FIELD, '項目/グループを表示する', $actionType === \Models\FormBranchRule::ACTION_SHOW_FIELD); ?>
                                                <?php admin_m_input01_option(\Models\FormBranchRule::ACTION_GO_TO_SCREEN, 'ページへ移動する', $actionType === \Models\FormBranchRule::ACTION_GO_TO_SCREEN); ?>
                                            <?php admin_m_input01_select_close(); ?>
                                        <?php admin_m_input01_close(); ?>
                                    </div>
                                </div>
                                <div class="block is-contents">
                                    <div class="block is-title">
                                        <label class="label" data-module="m-labelTitle01">対象</label>
                                    </div>
                                    <div class="block is-field">
                                        <?php admin_m_input01_open(); ?>
                                            <?php admin_m_input01_select_open([
                                                'name' => 'branch_rules[' . $idx . '][target_key]',
                                                'data-branch-rule-name' => 'target_key',
                                                'data-target' => 'branchRuleTargetKey',
                                                'data-value' => (string) ($rule['target_key'] ?? ''),
                                            ]); ?>
                                                <?php admin_m_input01_option('', '選択してください', (string) ($rule['target_key'] ?? '') === ''); ?>
                                                <?php foreach ($targetOptions as $value => $option): ?>
                                                    <option value="<?= e($value) ?>" data-target-type="<?= e((string) $option['type']) ?>"<?= (string) ($rule['target_key'] ?? '') === $value ? ' selected' : '' ?>><?= e((string) $option['label']) ?></option>
                                                <?php endforeach; ?>
                                            <?php admin_m_input01_select_close(); ?>
                                        <?php admin_m_input01_close(); ?>
                                    </div>
                                </div>
                                <div class="block is-contents">
                                    <div class="block is-title">
                                        <label class="label" data-module="m-labelTitle01">有効</label>
                                    </div>
                                    <div class="block is-field">
                                        <label data-module="m-check01">
                                            <input type="checkbox" name="branch_rules[<?= e((string) $idx) ?>][enabled]" value="1" data-branch-rule-name="enabled" <?= !array_key_exists('enabled', $rule) || !empty($rule['enabled']) ? 'checked' : '' ?>>
                                            <span>有効にする</span>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php admin_c_form_editor_item_body01_close(); ?>
            </div>
        </div>
    <?php admin_c_form_editor_item01_close(); ?>
    <?php
};
?>
<div data-target="c-formEditTabs01__contents" data-tab-panel="branch" class="area is-contents" role="tabpanel"
    aria-label="分岐処理" hidden>
    <?php admin_c_form_block01_open(['data-module' => 'm-branchRule01']); ?>
        <div class="area is-title">
            <?php admin_m_large_title01('分岐処理'); ?>
        </div>
        <div class="area is-field">
            <?php if ($duplicateWarnings !== []): ?>
                <div data-module="m-alert01" class="is-warning" data-target="branchRuleDuplicateWarning">
                    <?php foreach ($duplicateWarnings as $warning): ?>
                        <p><?= e($warning) ?></p>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div data-module="m-alert01" class="is-warning" data-target="branchRuleDuplicateWarning" hidden></div>
            <?php endif; ?>
            <p data-module="m-text01">条件に一致した場合だけ項目を表示したり、次に移動するページを変更できます。条件は単一条件（値が一致）のみです。</p>
        </div>
        <div class="area is-field">
            <div class="c-formEditor c-formEditorList01" data-module="c-formEditorList01">
                <div class="wrapper">
                    <div class="block is-contents" data-target="branchRuleList">
                        <?php foreach ($branchRules as $i => $rule): ?>
                            <?php $renderBranchRuleRow($rule, (int) $i); ?>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="area is-actions">
            <?php admin_m_btn01_button_wrap('＋ 分岐を追加', ['data-target' => 'branchRuleAdd']); ?>
        </div>
    <?php admin_c_form_block01_close(); ?>

    <template data-target="branchRuleTemplate">
        <?php $renderBranchRuleRow([
            'rule_key' => '__RULE_KEY__',
            'trigger_page_key' => \Models\FormInputPage::DEFAULT_KEY,
            'source_field_key' => '',
            'expected_value' => '',
            'action_type' => \Models\FormBranchRule::ACTION_SHOW_FIELD,
            'target_type' => \Models\FormBranchRule::TARGET_FIELD,
            'target_key' => '',
            'enabled' => 1,
        ], '__INDEX__'); ?>
    </template>
</div>
