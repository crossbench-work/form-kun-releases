<?php
/** c-formBlock01 直下 .area.is-field の内側: 項目設定（m-formBuilder01 一覧） */
$renderFields = $pageFields ?? $fields;
$renderPageKey = (string) (($inputPage['page_key'] ?? null) ?: \Models\FormInputPage::DEFAULT_KEY);
$renderGroups = \Models\FormFieldGroup::forInputPage($fieldGroups ?? [], $renderPageKey);
$fieldTemplates = is_array($fieldTemplates ?? null) ? $fieldTemplates : [];
$isReadOnlyTemplatePreview = !empty($isReadOnlyTemplatePreview);
$renderFieldIndex = 0;
$renderGroupIndex = 0;
$renderGroupChildren = function (?string $parentGroupKey = null) use (&$renderGroupChildren, &$renderFieldIndex, &$renderGroupIndex, $renderFields, $renderGroups, $renderPageKey): void {
    foreach (\Models\FormFieldGroup::childrenForParent($renderFields, $renderGroups, $renderPageKey, $parentGroupKey) as $child) {
        if ($child['kind'] === 'group') {
            $group = $child['item'];
            $groupIdx = $renderGroupIndex++;
            include __DIR__ . '/_group_editor.php';
            continue;
        }
        $f = $child['item'];
        $idx = $renderFieldIndex++;
        include __DIR__ . '/_field_editor.php';
    }
};
?>
        <div class="c-formEditor c-formEditorList01<?= $isReadOnlyTemplatePreview ? ' is-readOnly' : '' ?>" data-module="c-formEditorList01">
            <div class="wrapper">
                <div class="block is-contents" data-target="m-formBuilder01__fields" data-input-page-key="<?= e($renderPageKey) ?>" data-parent-group-key="">
                    <?php $renderGroupChildren(null); ?>
                </div>
            </div>
        </div>
        <?php if (!$isReadOnlyTemplatePreview): ?>
            <div class="area is-actions">
                <?php admin_c_btn_set01_open(); ?>
                    <div class="area is-contents">
                        <?php admin_m_btn01_button_wrap('＋ 項目を追加', ['data-target' => 'm-formBuilder01__add']); ?>
                    </div>
                    <?php if (!empty($fieldTemplates ?? [])): ?>
                        <div class="area is-contents">
                            <?php admin_m_btn01_button_wrap('テンプレートを使用', [
                                'type' => 'button',
                                'data-target' => 'fieldTemplateApplyOpen',
                            ]); ?>
                        </div>
                    <?php endif; ?>
                <?php admin_c_btn_set01_close(); ?>
            </div>
        <?php endif; ?>
