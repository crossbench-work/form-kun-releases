<?php /** 時間外画面 — ボタン */ ?>
        <?php admin_m_input_set01_open(); ?>
        <div class="area is-title">
            <?php admin_m_bold_title01(e('ボタンテキスト'), 'closed_button_text'); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input01_open(); ?>
            <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('closed_button_text', [
                'type' => 'text',
                'id' => 'closed_button_text',
                'name' => 'closed_button_text',
                'value' => (string) ($form['closed_button_text'] ?? 'トップへ戻る'),
            ])); ?>
            <?php admin_m_input01_close(); ?>
        </div>
        <?php admin_m_input_set01_close(); ?>
        <?php admin_m_input_set01_open(); ?>
        <div class="area is-title">
            <?php admin_m_bold_title01(e('ボタンURL'), 'closed_button_url'); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input01_open(); ?>
            <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('closed_button_url', [
                'type' => 'text',
                'id' => 'closed_button_url',
                'name' => 'closed_button_url',
                'value' => (string) ($form['closed_button_url'] ?? '/'),
                'placeholder' => '/ または https://example.com/',
            ])); ?>
            <?php admin_m_input01_close(); ?>
        </div>
        <?php admin_m_input_set01_close(); ?>
