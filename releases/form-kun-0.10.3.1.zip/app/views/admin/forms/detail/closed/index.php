<?php
/** フォーム編集:「時間外画面」タブパネル */
?>
<div data-target="c-formEditTabs01__contents" data-tab-panel="screen-closed" class="area is-contents" role="tabpanel"
    aria-label="時間外画面" hidden data-publish-schedule-closed-panel="1"<?= empty($showClosedScreenTab ?? false) ? ' data-initial-hidden-tab="1"' : '' ?>>
    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title">
            <?php admin_m_large_title01('時間外画面'); ?>
        </div>
        <div class="area is-field">
            <?php require __DIR__ . '/_content_closed_page_title.php'; ?>
        </div>
        <?php admin_c_description_editor01('closed_blocks', $closedBlocks, 'simple'); ?>
        <div class="area is-field">
            <?php require __DIR__ . '/_content_closed_buttons.php'; ?>
        </div>
    <?php admin_c_form_block01_close(); ?>
</div>
