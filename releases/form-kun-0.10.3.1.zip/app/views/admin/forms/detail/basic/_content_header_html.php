<?php /** c-formBlock01 直下 .area.is-field の内側: 共通設定ブロック — 共通 header HTML（name=header_html） */ ?>
        <?php admin_m_input_set01_open(); ?>
        <div class="area is-title">
            <?php admin_m_bold_title01(e('header'), 'header_html'); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input01_open(); ?>
            <?php admin_m_input01_textarea(admin_m_input01_attrs_with_bound_label('header_html', [
                'id' => 'header_html',
                'name' => 'header_html',
                'rows' => 8,
                'placeholder' => '<p>フォーム上部に表示する共通HTML</p>',
            ]), (string) ($form['header_html'] ?? '')); ?>
            <?php admin_m_input01_close(); ?>
        </div>
        <div class="area is-help">
            <p class="text is-help">公開フォームの本文前に表示する共通HTMLを入力できます。</p>
        </div>
        <?php admin_m_input_set01_close(); ?>
