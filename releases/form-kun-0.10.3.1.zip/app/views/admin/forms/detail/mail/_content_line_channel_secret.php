<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — Channel secret */ ?>
    <?php
    $lineCredentialFieldKey = 'line_channel_secret';
    $lineCredentialLabel = 'Channel secret';
    require __DIR__ . '/_content_line_credential_field.php';
    ?>
