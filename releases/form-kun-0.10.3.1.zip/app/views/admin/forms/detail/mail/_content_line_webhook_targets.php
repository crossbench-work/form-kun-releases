<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — Webhook で取得した ID 一覧 */ ?>
    <?php
    require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
    use Models\LineWebhookTarget;
    $lineWebhookTargets = [];
    /** @var list<string>|null $lineWebhookTargetTypeFilter */
    $lineWebhookTargetTypeFilter = $lineWebhookTargetTypeFilter ?? null;
    $lineWebhookTargetsReady = !empty($lineWebhookTargetsReady);
    if (is_array($lineWebhookTargetTypeFilter) && $lineWebhookTargetTypeFilter !== []) {
        $lineWebhookTargets = LineWebhookTarget::listRecentForTypes($lineWebhookTargetTypeFilter, 20);
    } else {
        $lineWebhookTargets = LineWebhookTarget::listRecent(20);
    }
    $lineWebhookHideTitle = !empty($lineWebhookHideTitle);
    $lineWebhookHideTypeColumn = is_array($lineWebhookTargetTypeFilter)
        && count($lineWebhookTargetTypeFilter) === 1
        && ($lineWebhookTargetTypeFilter[0] ?? '') === 'user';
    $lineWebhookTargetTypeLabel = static function (string $type): string {
        return match ($type) {
            'group' => 'グループ',
            'room' => '複数人トーク',
            default => 'ユーザー',
        };
    };
    ?>
    <?php admin_m_input_set01_open(); ?>
    <?php if (!$lineWebhookHideTitle): ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('Webhook で取得した ID')); ?>
    </div>
    <?php endif; ?>
    <div class="area is-field">
        <?php if (!$lineWebhookTargetsReady): ?>
            <p class="text is-help">Channel secret を保存し、Webhook URL を登録してください。</p>
        <?php elseif ($lineWebhookTargets === []): ?>
            <?php if (!empty($lineWebhookShowMissingHint)): ?>
            <p class="text is-checkHint is-sub">IDが未取得です</p>
            <?php elseif (empty($lineWebhookHideLongEmptyHelp)): ?>
            <p class="text is-help">まだ ID は記録されていません。Channel secret を保存し、Webhook URL を登録したうえで LINE Developers の「Webhook の利用」を ON にしてください（OFF だと検証は成功してもイベントが届きません）。その後、公式アカウントを友だち追加するか、Bot をグループに招待するか、招待済みグループで Bot に 1 通メッセージを送ってください。</p>
            <?php endif; ?>
        <?php else: ?>
            <?php admin_m_table01_open(); ?>
            <?php
            $tableHead = [['label' => 'ID'], ['label' => '最終受信'], ['label' => '操作']];
            if (!$lineWebhookHideTypeColumn) {
                array_unshift($tableHead, ['label' => '種別']);
            }
            admin_m_table01_thead($tableHead);
            ?>
            <tbody>
                <?php foreach ($lineWebhookTargets as $row): ?>
                    <?php
                    $type = (string) ($row['target_type'] ?? '');
                    $typeLabel = $lineWebhookTargetTypeLabel($type);
                    $targetId = (string) ($row['target_id'] ?? '');
                    ?>
                    <tr>
                        <?php if (!$lineWebhookHideTypeColumn): ?>
                        <td><?= e($typeLabel) ?></td>
                        <?php endif; ?>
                        <td><code><?= e($targetId) ?></code></td>
                        <td><?= e((string) ($row['last_seen_at'] ?? '')) ?></td>
                        <td class="is-actions">
                            <span class="block is-rowActions">
                                <button type="button" class="btn is-icon is-copy" data-copy-text="<?= e($targetId) ?>" aria-label="IDをコピー" title="コピー">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true" focusable="false">
                                        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
                                        <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
                                    </svg>
                                </button>
                                <button type="button" data-module="m-lineWebhookTargetDelete01" data-line-target-type="<?= e($type) ?>" data-line-target-id="<?= e($targetId) ?>" aria-label="IDを削除" title="削除">
                                    <svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M3 6h18"/>
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M8 6V4h8v2"/>
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M19 6l-1 14H6L5 6"/>
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M10 11v6M14 11v6"/>
                                    </svg>
                                </button>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <?php admin_m_table01_close(); ?>
        <?php endif; ?>
    </div>
    <?php admin_m_input_set01_close(); ?>
