<?php /** c-formBlock01 直下 .area.is-field の内側: 自動返信 — 送信先メール項目（name=reply_from_field_key[]） */ ?>
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('送信先のメールアドレス項目'), 'reply_from_field_key'); ?>
    </div>
    <div class="area is-field" data-auto-reply-recipient data-selected='<?= e(json_encode($form['reply_from_field_keys'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '[]') ?>'>
        <input type="hidden" name="reply_from_field_key_present" value="1">
        <div data-target="autoReplyRecipientListWrap" <?= empty($replyFieldOptions) ? 'hidden' : '' ?>>
            <?php foreach (($replyFieldOptions ?? []) as $option): ?>
                <div data-target="autoReplyRecipientItem">
                    <?php admin_m_checkbox01($option['label'], [
                        'name' => 'reply_from_field_key[]',
                        'value' => $option['value'],
                        'checked' => in_array($option['value'], $form['reply_from_field_keys'] ?? [], true),
                    ]); ?>
                </div>
            <?php endforeach; ?>
        </div>
        <p class="text is-help" data-target="autoReplyRecipientEmptyText" <?= empty($replyFieldOptions) ? '' : 'hidden' ?>>入力画面にメールアドレス項目を設定してください</p>
    </div>
    <?php admin_m_input_set01_close(); ?>
