<?php /** LINE 連携: アカウント連携の解除（admin・設定画面） */
$lineAccountUnlinkUrl = (string) ($lineAccountUnlinkUrl ?? '');
if ($lineAccountUnlinkUrl === '') {
    $formId = (int) ($form['id'] ?? 0);
    $lineAccountUnlinkUrl = $formId > 0
        ? base_path('/admin/forms/' . $formId . '/line/account-unlink')
        : '';
}
?>
<div data-module="c-lineAccountUnlink01"<?= $lineAccountUnlinkUrl !== '' ? ' data-reset-url="' . e($lineAccountUnlinkUrl) . '"' : '' ?> data-csrf-name="_token">
    <p class="text is-help">Channel secret・トークン・送信先 ID・チェックリスト・Webhook で記録した ID を消去し、全フォームの LINE 通知をオフにします。各フォームの通知メッセージ本文は残ります。</p>
    <div class="area is-actions">
        <?php
        admin_m_btn01_button_wrap('アカウント連携を解除', [
            'type' => 'button',
            'class' => 'is-danger',
            'data-target' => 'c-lineAccountUnlink01__submit',
        ]);
        ?>
    </div>
</div>
