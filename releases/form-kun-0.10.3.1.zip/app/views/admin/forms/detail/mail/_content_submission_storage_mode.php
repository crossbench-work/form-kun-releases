<?php /** 通知設定 — 送信内容の保存方式 */ ?>
<?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01('送信内容の保存方式', 'submission_storage_mode'); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_radiobtn01('送信履歴をDBに保存する', [
            'name' => 'submission_storage_mode', 'value' => \Models\Form::STORAGE_DATABASE,
            'checked' => ($form['submission_storage_mode'] ?? \Models\Form::STORAGE_DATABASE) === \Models\Form::STORAGE_DATABASE,
        ]); ?>
        <?php admin_m_radiobtn01('送信内容・添付ファイルを送信履歴へ保存せず、SMTPメールだけ送信する', [
            'name' => 'submission_storage_mode', 'value' => \Models\Form::STORAGE_MAIL_ONLY,
            'checked' => ($form['submission_storage_mode'] ?? '') === \Models\Form::STORAGE_MAIL_ONLY,
        ]); ?>
        <p class="text is-help">メール送信のみでは管理者全宛先のSMTP受理を確認できた場合だけ完了します。入力内容・添付本体・ファイル名は保存しませんが、受付日時、対応状態、配送結果、IPアドレス、User-Agent、添付件数・合計容量は送信履歴へ保存します。SMTP応答が不明な場合、再送によりメールが重複する可能性があります。</p>
    </div>
<?php admin_m_input_set01_close(); ?>

<?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01('メール添付の合計上限', 'mail_attachment_max_mb'); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input01_open(); ?>
            <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('mail_attachment_max_mb', [
                'type' => 'number', 'name' => 'mail_attachment_max_mb', 'id' => 'mail_attachment_max_mb',
                'min' => 1, 'max' => 25, 'step' => 1,
                'value' => (string) max(1, (int) round((int) ($form['mail_attachment_max_bytes'] ?? 10485760) / 1024 / 1024)),
                'required' => true,
            ])); ?>
        <?php admin_m_input01_close(); ?>
        <p class="text is-help">MB（1〜25MB）。SMTPではMIME変換により実際のメールサイズが約1.4倍になります。</p>
    </div>
<?php admin_m_input_set01_close(); ?>

<div data-module="m-alert01" class="<?= !empty($form['smtp_test_is_current']) ? 'is-success' : 'is-warning' ?>">
    <span data-module="m-text01">
        <?= !empty($form['smtp_test_is_current'])
            ? '現在のSMTP設定はテスト済みです（' . e((string) ($form['smtp_tested_at'] ?? '')) . '）。'
            : 'メール送信のみモードを有効にするには、SMTPテストを成功させてください。テスト時に画面上の設定も保存されます。' ?>
    </span>
</div>
<?php if (empty($isNew) && \Core\Auth::role() === 'admin'): ?>
<div class="area is-actions">
    <button type="submit" class="btn" formaction="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/test-smtp')) ?>" formmethod="post" formnovalidate>設定を保存してSMTPテスト</button>
    <?php if (!empty(config('debug', false))): ?>
        <p class="text is-help">Dockerのローカル環境では、ホスト <code>mailpit</code>、ポート <code>1025</code>、暗号化なし、認証なしでテストできます。受信確認は <a href="http://localhost:8025" target="_blank" rel="noopener noreferrer">Mailpit</a> を開いてください。</p>
    <?php endif; ?>
</div>
<?php endif; ?>
