<?php
/**
 * LINE Channel secret / access token（項目ごとに保存・削除）
 *
 * @var string $lineCredentialFieldKey line_channel_secret | line_channel_access_token
 * @var string $lineCredentialLabel
 * @var array<string, mixed> $form
 * @var bool $lineCredentialHideTitle チェックリスト内など見出しを省略する
 */
$lineCredentialFieldKey = (string) ($lineCredentialFieldKey ?? '');
$lineCredentialLabel = (string) ($lineCredentialLabel ?? '');
$lineCredentialHideTitle = !empty($lineCredentialHideTitle);
$lineCredentialContext = (string) ($lineCredentialContext ?? 'form');
$formId = (int) ($form['id'] ?? 0);
$configured = !empty($form[$lineCredentialFieldKey . '_configured']);
$lineCredentialMask = '********';
$lineCredentialFieldErrors = ($lineCredentialErrors ?? [])[$lineCredentialFieldKey] ?? [];

if ($lineCredentialContext === 'site') {
    if ($lineCredentialFieldKey === 'line_channel_secret') {
        $lineCredentialSaveAction = base_path('/admin/settings/line/channel-secret');
        $lineCredentialDeleteAction = base_path('/admin/settings/line/channel-secret/delete');
    } else {
        $lineCredentialSaveAction = base_path('/admin/settings/line/channel-access-token');
        $lineCredentialDeleteAction = base_path('/admin/settings/line/channel-access-token/delete');
    }
} elseif ($lineCredentialFieldKey === 'line_channel_secret') {
    $lineCredentialSaveAction = base_path('/admin/forms/' . $formId . '/line/channel-secret');
    $lineCredentialDeleteAction = base_path('/admin/forms/' . $formId . '/line/channel-secret/delete');
} else {
    $lineCredentialSaveAction = base_path('/admin/forms/' . $formId . '/line/channel-access-token');
    $lineCredentialDeleteAction = base_path('/admin/forms/' . $formId . '/line/channel-access-token/delete');
}
?>
    <?php admin_m_input_set01_open(); ?>
    <?php if (!$lineCredentialHideTitle): ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e($lineCredentialLabel), $lineCredentialFieldKey); ?>
    </div>
    <?php endif; ?>
    <div class="area is-field">
        <div class="c-lineCredentialRow01">
        <?php admin_m_input01_open(); ?>
        <?php
        $inputAttrs = [
            'id' => $lineCredentialFieldKey,
            'autocomplete' => 'new-password',
        ];
        if ($configured) {
            $inputAttrs['type'] = 'text';
            $inputAttrs['readonly'] = true;
            $inputAttrs['value'] = $lineCredentialMask;
        } else {
            $inputAttrs['type'] = 'password';
            $inputAttrs['name'] = $lineCredentialFieldKey;
            $inputAttrs['value'] = '';
        }
        admin_m_input01_input(admin_m_input01_attrs_with_bound_label($lineCredentialFieldKey, $inputAttrs));
        ?>
        <?php admin_m_input01_close(); ?>
        <?php if ($formId > 0 || $lineCredentialContext === 'site'): ?>
            <?php if ($configured): ?>
                <button type="submit" class="btn is-small"
                    formaction="<?= e($lineCredentialDeleteAction) ?>"
                    formmethod="post" formnovalidate>削除</button>
            <?php else: ?>
                <button type="submit" class="btn is-small"
                    formaction="<?= e($lineCredentialSaveAction) ?>"
                    formmethod="post" formnovalidate>保存</button>
            <?php endif; ?>
        <?php endif; ?>
        </div>
        <?php if ($lineCredentialFieldErrors !== []): ?>
            <?php foreach ($lineCredentialFieldErrors as $lineCredentialErrorMsg): ?>
                <?php admin_m_alert01((string) $lineCredentialErrorMsg, 'danger'); ?>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <?php admin_m_input_set01_close(); ?>
