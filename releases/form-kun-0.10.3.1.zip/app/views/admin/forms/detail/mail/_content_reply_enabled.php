<?php /** c-formBlock01 直下 .area.is-field の内側: 自動返信 — 有効化（name=reply_enabled） */ ?>
    <input type="hidden" name="reply_enabled" value="0">
    <?php admin_m_checkbox01('自動返信を有効にする', [
        'name' => 'reply_enabled',
        'value' => '1',
        'checked' => !empty($form['reply_enabled']),
    ]); ?>
