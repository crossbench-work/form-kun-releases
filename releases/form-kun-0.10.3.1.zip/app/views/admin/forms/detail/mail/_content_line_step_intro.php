<?php
/**
 * LINE 通知タブの Step 見出し（$stepTitle, $stepHelp, 任意 $stepExternalUrl を呼び出し元でセット）
 */
$stepTitle = (string) ($stepTitle ?? '');
$stepHelp = (string) ($stepHelp ?? '');
$stepExternalUrl = trim((string) ($stepExternalUrl ?? ''));
$stepExternalLabel = trim((string) ($stepExternalLabel ?? 'LINE Developers'));
?>
<div class="area is-title">
    <?php admin_m_bold_title01(e($stepTitle)); ?>
</div>
<?php if ($stepExternalUrl !== ''): ?>
<div class="area is-field">
    <a class="link c-externalLink01" href="<?= e($stepExternalUrl) ?>" target="_blank" rel="noopener noreferrer">
        <?= e($stepExternalLabel) ?>
        <span class="icon is-external" aria-hidden="true"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg></span>
    </a>
</div>
<?php endif; ?>
<?php if ($stepHelp !== ''): ?>
<div class="area is-field">
    <p class="text is-help"><?= e($stepHelp) ?></p>
</div>
<?php endif; ?>
