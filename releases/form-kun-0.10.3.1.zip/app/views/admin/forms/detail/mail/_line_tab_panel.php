        <div data-target="c-formEditTabs01__contents" data-tab-panel="mail-line" class="area is-contents" role="tabpanel"
            aria-label="LINE通知" hidden>
            <?php
            use Core\LineSiteConfig;

            $lineNotifyEnabled = !empty($form['line_notify_enabled']);
            $lineAccountLinkComplete = LineSiteConfig::isSetupComplete();
            $lineFormId = (int) ($form['id'] ?? 0);
            $lineNotifySettingsSaveUrl = $lineFormId > 0
                ? base_path('/admin/forms/' . $lineFormId . '/line/notify-settings')
                : '';
            ?>
            <?php admin_c_form_block01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_large_title01('LINE通知'); ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_line_notify_enabled.php'; ?>
                </div>
                <div data-module="c-lineNotifyTab01"
                    data-line-account-link-complete="<?= $lineAccountLinkComplete ? '1' : '0' ?>"
                    <?= $lineNotifySettingsSaveUrl !== '' ? ' data-notify-settings-url="' . e($lineNotifySettingsSaveUrl) . '"' : '' ?>
                    data-csrf-name="_token"
                    <?= !$lineNotifyEnabled ? ' hidden' : '' ?>>
                    <div class="block is-lineNotifyUpper">
                    <div class="area is-field" data-target="c-lineNotifyTab01__messageFields"<?= !$lineNotifyEnabled || !$lineAccountLinkComplete ? ' hidden' : '' ?>>
                        <div data-module="c-lineNotifySettings01">
                            <?php require __DIR__ . '/_content_line_message_template.php'; ?>
                            <?php require __DIR__ . '/_content_line_message_template_vars.php'; ?>
                        </div>
                    </div>
                    <div class="area is-field" data-target="c-lineNotifyTab01__messageWait"<?= !$lineNotifyEnabled || $lineAccountLinkComplete ? ' hidden' : '' ?>>
                        <p class="text is-help"><a href="<?= e(base_path('/admin/settings#line-settings')) ?>">設定 → LINE 連携</a> でアカウント連携（送信先 ID・通知テスト含む）を完了後、通知メッセージを設定できます。</p>
                    </div>
                    <?php if (\Core\Auth::role() !== 'admin'): ?>
                    <div class="area is-field">
                        <?php admin_m_alert01('LINE チャネル・送信先 ID の設定は <a href="' . e(base_path('/admin/settings#line-settings')) . '">設定 → LINE 連携</a>（admin のみ）で行います。', 'info'); ?>
                    </div>
                    <?php endif; ?>
                    </div>
                </div>
            <?php admin_c_form_block01_close(); ?>
        </div>
