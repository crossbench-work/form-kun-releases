<?php /** c-formBlock01 直下 .area.is-field の内側: 通知設定 — 自己署名許可（name=mail_smtp_allow_self_signed） */ ?>
    <input type="hidden" name="mail_smtp_allow_self_signed" value="0">
    <?php admin_m_checkbox01('自己署名証明書を許可する', [
        'name' => 'mail_smtp_allow_self_signed',
        'value' => '1',
        'checked' => !empty($form['mail_smtp_allow_self_signed']),
    ]); ?>
    <p class="text is-help">ローカル開発や検証用 SMTP のみで使ってください。</p>
