<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — 有効化（name=line_notify_enabled） */ ?>
    <input type="hidden" name="line_notify_enabled" value="0">
    <?php admin_m_checkbox01('メッセージの受信時にLINEへ通知する', [
        'id' => 'line_notify_enabled',
        'name' => 'line_notify_enabled',
        'value' => '1',
        'checked' => !empty($form['line_notify_enabled']),
    ]); ?>
