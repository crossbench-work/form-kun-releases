<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — Channel access token */ ?>
    <?php
    $lineCredentialFieldKey = 'line_channel_access_token';
    $lineCredentialLabel = 'Channel access token';
    require __DIR__ . '/_content_line_credential_field.php';
    ?>
