<?php /** c-formBlock01 直下 .area.is-field の内側: 通知設定 — 証明書ホスト名検証（name=mail_smtp_verify_peer_name） */ ?>
    <input type="hidden" name="mail_smtp_verify_peer_name" value="0">
    <?php admin_m_checkbox01('証明書のホスト名を検証する', [
        'name' => 'mail_smtp_verify_peer_name',
        'value' => '1',
        'checked' => !empty($form['mail_smtp_verify_peer_name']),
    ]); ?>
