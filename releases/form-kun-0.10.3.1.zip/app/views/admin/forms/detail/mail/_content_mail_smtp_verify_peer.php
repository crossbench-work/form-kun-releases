<?php /** c-formBlock01 直下 .area.is-field の内側: 通知設定 — SSL証明書検証（name=mail_smtp_verify_peer） */ ?>
    <input type="hidden" name="mail_smtp_verify_peer" value="0">
    <?php admin_m_checkbox01('SSL 証明書を検証する', [
        'name' => 'mail_smtp_verify_peer',
        'value' => '1',
        'checked' => !empty($form['mail_smtp_verify_peer']),
    ]); ?>
