<?php /** c-formBlock01 直下 .area.is-field: フォーム用 LINE セットアップ（送信先・テスト） */ ?>
<?php
use Core\LineSiteConfig;
use Models\Form;

$formId = (int) ($form['id'] ?? 0);
$lineSetupChecklistState = Form::lineSetupChecklistStateForDisplay($form);
$lineSetupChecklistPostUrl = $formId > 0
    ? base_path('/admin/forms/' . $formId . '/line/setup-checklist')
    : '';
?>
<?php if (!LineSiteConfig::isSetupComplete()): ?>
    <p class="text is-help">先に <a href="<?= e(base_path('/admin/settings#line-settings')) ?>">設定 → LINE 連携</a> でチャネル設定と Webhook 送信先 ID の取得を完了してください。</p>
<?php endif; ?>
<?php
admin_c_line_setup_checklist01(
    Form::lineSetupChecklistItemDefinitions(),
    $lineSetupChecklistState,
    $lineSetupChecklistPostUrl,
    $formId > 0 && LineSiteConfig::isSetupComplete(),
    static function (string $itemKey) use ($form): void {
        if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_LINE_PUSH_TO_ID) {
            $linePushToIdHideTitle = true;
            $linePushToIdHideHelp = true;
            $linePushToIdInlineSave = true;
            require __DIR__ . '/_content_line_push_to_id.php';

            return;
        }
        if ($itemKey === Form::LINE_SETUP_CHECKLIST_LINE_TALK_NOTIFY_TEST) {
            require __DIR__ . '/_content_line_notify_test.php';

            return;
        }
    }
);
?>
