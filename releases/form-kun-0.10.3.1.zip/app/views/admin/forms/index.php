<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
?>
<div data-module="m-toolbar01">
    <h1 class="title" style="margin:0;">フォーム一覧</h1>
    <div class="spacer"></div>
    <?php if (!empty($storage_resource) && is_array($storage_resource)): ?>
        <?php admin_c_progress01_resource_summary($storage_resource); ?>
    <?php endif; ?>
</div>

<?php admin_c_form_block01_open(); ?>
<div class="area is-field">
    <?php if (empty($forms)): ?>
        <p data-module="m-text01" data-type="muted">まだフォームがありません。<?php if (empty($at_form_limit)): ?><?php endif; ?></p>
    <?php else: ?>
        <?php
            $anyFormManage = false;
            foreach ($forms as $fCheck) {
                if (\Core\Auth::canManageForm((int) $fCheck['id'])) {
                    $anyFormManage = true;
                    break;
                }
            }
        ?>
        <?php admin_m_table01_open('is-formList'); ?>
        <?php
            $thead = [
                ['label' => 'タイトル'],
                ['label' => 'URL'],
                ['label' => '状態', 'class' => 'is-workflow-status'],
                ['label' => '受信', 'class' => 'num is-reception-count'],
                ['label' => '更新日時', 'class' => 'is-updated-at'],
            ];
            if ($anyFormManage) {
                $thead[] = ['label' => '', 'class' => 'is-actions'];
            }
            admin_m_table01_thead($thead);
        ?>
        <tbody>
            <?php foreach ($forms as $f): ?>
                <tr>
                    <td class="is-formList-title">
                        <a href="<?= e(base_path('/admin/forms/' . $f['id'] . '/submissions')) ?>">
                            <strong><?= e($f['title']) ?></strong>
                        </a>
                    </td>
                    <td class="is-url is-formList-url">
                        <a href="<?= e(base_path('/f/' . $f['slug'])) ?>" target="_blank" rel="noopener noreferrer">
                            <code><?= e($f['slug']) ?></code>
                        </a>
                    </td>
                    <td class="is-workflow-status" data-sp-label="状態"><?php admin_m_badge01(\Models\Form::statusLabel((string) $f['status']), (string) $f['status']); ?></td>
                    <td class="num is-reception-count" data-sp-label="受信">
                        <?= number_format((int) ($f['cnt'] ?? 0)) ?>
                    </td>
                    <td class="is-updated-at" data-sp-label="更新日時"><?= e($f['updated_at']) ?></td>
                    <?php if (\Core\Auth::canManageForm((int) $f['id'])): ?>
                    <td class="is-actions">
                        <details class="c-tableActionMenu01">
                            <summary class="c-tableActionMenu01__toggle" aria-label="操作">
                                <span aria-hidden="true">⋯</span>
                            </summary>
                            <div class="c-tableActionMenu01__menu" role="menu" aria-label="操作">
                                <a role="menuitem" href="<?= e(base_path('/admin/forms/' . $f['id'] . '/edit')) ?>">編集</a>
                                <?php if (!\Core\Auth::isViewer()): ?>
                                <a role="menuitem" href="<?= e(base_path('/admin/forms/' . $f['id'] . '/versions')) ?>">バージョン管理</a>
                                <form method="post"
                                    action="<?= e(base_path('/admin/forms/' . $f['id'] . '/duplicate')) ?>"
                                    onsubmit="return confirm('このフォームを複製します。よろしいですか？');">
                                    <?= \Core\Csrf::field() ?>
                                    <button type="submit" role="menuitem">複製</button>
                                </form>
                                <a role="menuitem" href="<?= e(base_path('/admin/forms/' . $f['id'] . '/export')) ?>">エクスポート</a>
                                <?php endif; ?>
                                <a role="menuitem" href="<?= e(base_path('/admin/forms/' . $f['id'] . '/submissions')) ?>">送信履歴</a>
                                <?php if (!\Core\Auth::isViewer()): ?>
                                <form method="post"
                                    action="<?= e(base_path('/admin/forms/' . $f['id'] . '/delete')) ?>"
                                    onsubmit="return confirm('本当に削除しますか？関連する送信履歴も削除されます。');">
                                    <?= \Core\Csrf::field() ?>
                                    <?php admin_m_delete_btn01('admin-form-delete-' . $f['id'], '削除', '削除', 'submit', '削除'); ?>
                                </form>
                                <?php endif; ?>
                            </div>
                        </details>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
        <?php admin_m_table01_close(); ?>
    <?php endif; ?>
</div>
<?php if (!\Core\Auth::isViewer()): ?>
<div class="area is-actions">
    <?php if (!empty($at_form_limit)): ?>
        <?php admin_m_btn01_button_wrap('＋ 新規作成', [
            'type' => 'button',
            'class' => 'is-primary',
            'disabled' => true,
            'aria-disabled' => true,
        ]); ?>
    <?php else: ?>
        <?php admin_m_btn01_link_wrap('＋ 新規作成', base_path('/admin/forms/new'), ['class' => 'is-primary']); ?>
    <?php endif; ?>
    <?php admin_m_btn01_link_wrap('インポート', base_path('/admin/forms/import')); ?>
</div>
<?php endif; ?>
<?php admin_c_form_block01_close(); ?>
