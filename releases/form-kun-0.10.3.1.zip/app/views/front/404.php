<h1 class="title">404 Not Found</h1>
<p class="text">お探しのフォームは見つかりませんでした。URLが正しいか、もしくは公開状態かをご確認ください。</p>
<?php if (settings_show_active_forms_list()): ?>
<p><a class="link" href="<?= e(base_path('/')) ?>">トップへ戻る</a></p>
<?php endif; ?>
