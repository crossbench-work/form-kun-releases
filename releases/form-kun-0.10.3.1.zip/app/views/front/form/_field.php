<?php
/** @var array $field */
/** @var array $values */
/** @var array $errors */
$key   = $field['field_key'];
$label = $field['label'];
$type  = $field['type'];
$req   = (int) $field['required'] === 1;
$showLabel = !array_key_exists('show_label', $field) || !empty($field['show_label']);
$value = $values[$key] ?? '';
$hasExplicitValue = array_key_exists($key, $values);
$err   = $errors[$key] ?? [];
$addrErrParts = ($type === 'address') ? address_errors_normalize($err) : [];
$pairErrParts = ($type === 'text_pair') ? text_pair_errors_normalize($err) : [];
$multiErrParts = ($type === 'text_multi') ? text_multi_errors_normalize($err) : ['_root' => [], 'items' => []];
$opts  = \Core\Validator::decodeOptions($field['options_json'] ?? null);
$checkboxSettings = ($type === 'checkbox')
    ? \Models\FormField::decodeCheckboxSettings($field['options_json'] ?? null)
    : ['options' => [], 'min_selections' => '', 'max_selections' => ''];
$regexPatterns = \Models\FormField::decodeRegexPatterns($field['regex'] ?? null);
$pairLabels = ($type === 'text_pair')
    ? \Models\FormField::decodeTextPairLabels($field['options_json'] ?? null)
    : ['left_label' => '', 'right_label' => ''];
$pairPlaceholders = ($type === 'text_pair')
    ? \Models\FormField::decodeTextPairPlaceholders($field['placeholder'] ?? null)
    : ['left_placeholder' => '', 'right_placeholder' => ''];
$multiItems = ($type === 'text_multi')
    ? \Models\FormField::decodeTextMultiItems($field['options_json'] ?? null, true)
    : [];
$postalCodeSettings = ($type === \Models\FormField::TYPE_POSTAL_CODE)
    ? \Models\FormField::decodePostalCodeSettings($field['options_json'] ?? null)
    : ['postal_target_prefecture' => '', 'postal_target_city' => ''];
$fileSettings = ($type === 'file')
    ? \Models\FormField::decodeFileSettings($field['options_json'] ?? null)
    : ['allowed_extensions' => [], 'selection_mode' => \Models\FormField::FILE_SELECTION_CUSTOM, 'convert_to_jpeg' => 0];
$matrixSettings = ($type === \Models\FormField::TYPE_MATRIX)
    ? \Models\FormField::decodeMatrixSettings($field['options_json'] ?? null)
    : ['rows' => [], 'columns' => [], 'selection_type' => 'radio'];
$defaultSettings = in_array($type, ['textarea', 'number'], true)
    ? \Models\FormField::decodeDefaultValueSettings($field['options_json'] ?? null)
    : ['default_value' => ''];
$dateDefaultSettings = ($type === 'date')
    ? \Models\FormField::decodeDateDefaultSettings($field['options_json'] ?? null)
    : ['default_mode' => '', 'default_value' => ''];
$timeDefaultSettings = ($type === 'time')
    ? \Models\FormField::decodeTimeDefaultSettings($field['options_json'] ?? null)
    : ['default_mode' => '', 'default_value' => ''];
$radioSettings = ($type === 'radio')
    ? \Models\FormField::decodeChoiceSettings($field['options_json'] ?? null)
    : ['options' => [], 'default_value' => ''];
$matrixValueRows = ($type === \Models\FormField::TYPE_MATRIX) ? matrix_value_rows_normalize($value) : [];
$ph    = $field['placeholder'] ?? '';
$exactLength = !empty($field['exact_length']) ? (int) $field['exact_length'] : 0;
if ($exactLength > 0) {
    $minLengthAttr = ' minlength="' . $exactLength . '"';
    $maxLengthAttr = ' maxlength="' . $exactLength . '"';
} else {
    $minLengthAttr = !empty($field['min_length']) ? ' minlength="' . (int) $field['min_length'] . '"' : '';
    $maxLengthAttr = !empty($field['max_length']) ? ' maxlength="' . (int) $field['max_length'] . '"' : '';
}
$fieldJsonFlags = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
$branchControlledFieldKeys = $branchControlledFieldKeys ?? [];
$branchVisibleFieldKeys = $branchVisibleFieldKeys ?? [];
$branchHidden = in_array($key, $branchControlledFieldKeys, true) && !in_array($key, $branchVisibleFieldKeys, true);

$labelFor = $type === 'address'
    ? 'f_' . $key . '_postal3'
    : ($type === 'text_pair'
        ? 'f_' . $key . '_left'
        : ($type === 'text_multi' ? 'f_' . $key . '_0' : ($type === \Models\FormField::TYPE_MATRIX ? 'f_' . $key . '_0_0' : 'f_' . $key)));

$addrPostal = '';
$addrPref   = '';
$addrCity   = '';
$addrNumber = '';
$addrBuilding = '';
$pairLeft = '';
$pairRight = '';
$multiValues = [];
$postalCodeValue = '';
if ($type === 'address') {
    if (is_array($value)) {
        if (isset($value['prefecture']) || isset($value['city']) || isset($value['street'])
            || isset($value['number']) || isset($value['building'])) {
            $addrPostal = (string) ($value['postal'] ?? '');
            $addrPref   = (string) ($value['prefecture'] ?? '');
            $addrCity   = (string) ($value['city'] ?? '');
            $addrNumber = (string) ($value['number'] ?? '');
            $addrBuilding = (string) ($value['building'] ?? '');
            if ($addrNumber === '' && $addrBuilding === '' && isset($value['street'])) {
                $addrNumber = (string) ($value['street']);
            }
        } else {
            $addrPostal = (string) ($value['postal'] ?? '');
            $line1      = (string) ($value['line1'] ?? '');
            [$addrPref, $addrCity] = address_split_legacy_line1($line1);
            $addrNumber = (string) ($value['line2'] ?? '');
        }
    } elseif (is_string($value) && $value !== '') {
        $dec = json_decode($value, true);
        if (is_array($dec) && (isset($dec['postal']) || isset($dec['line1']) || isset($dec['line2'])
            || isset($dec['prefecture']) || isset($dec['city']) || isset($dec['street'])
            || isset($dec['number']) || isset($dec['building']))) {
            if (isset($dec['prefecture']) || isset($dec['city']) || isset($dec['street'])
                || isset($dec['number']) || isset($dec['building'])) {
                $addrPostal = (string) ($dec['postal'] ?? '');
                $addrPref   = (string) ($dec['prefecture'] ?? '');
                $addrCity   = (string) ($dec['city'] ?? '');
                $addrNumber = (string) ($dec['number'] ?? '');
                $addrBuilding = (string) ($dec['building'] ?? '');
                if ($addrNumber === '' && $addrBuilding === '' && isset($dec['street'])) {
                    $addrNumber = (string) ($dec['street']);
                }
            } else {
                $addrPostal = (string) ($dec['postal'] ?? '');
                $line1      = (string) ($dec['line1'] ?? '');
                [$addrPref, $addrCity] = address_split_legacy_line1($line1);
                $addrNumber = (string) ($dec['line2'] ?? '');
            }
        } else {
            $addrCity = $value;
        }
    }
}
if ($type === 'text_pair') {
    if (is_array($value)) {
        $pairLeft = (string) ($value['left'] ?? '');
        $pairRight = (string) ($value['right'] ?? '');
    } elseif (is_string($value) && $value !== '') {
        $dec = json_decode($value, true);
        if (is_array($dec) && (isset($dec['left']) || isset($dec['right']))) {
            $pairLeft = (string) ($dec['left'] ?? '');
            $pairRight = (string) ($dec['right'] ?? '');
        } else {
            $parts = preg_split('/\r\n|\r|\n/', $value) ?: [];
            $pairLeft = (string) ($parts[0] ?? '');
            $pairRight = (string) ($parts[1] ?? '');
        }
    }
}
if ($type === 'text_multi') {
    if (is_array($value)) {
        if (isset($value['items']) && is_array($value['items'])) {
            $multiValues = array_values(array_map(static fn($item): string => trim((string) $item), $value['items']));
        } else {
            $multiValues = array_values(array_map(static fn($item): string => trim((string) $item), $value));
        }
    } elseif (is_string($value) && $value !== '') {
        $dec = json_decode($value, true);
        if (is_array($dec)) {
            if (isset($dec['items']) && is_array($dec['items'])) {
                $multiValues = array_values(array_map(static fn($item): string => trim((string) $item), $dec['items']));
            } elseif (isset($dec['left']) || isset($dec['right'])) {
                $multiValues = [
                    trim((string) ($dec['left'] ?? '')),
                    trim((string) ($dec['right'] ?? '')),
                ];
            } else {
                $multiValues = array_values(array_map(static fn($item): string => trim((string) $item), $dec));
            }
        } else {
            $multiValues = preg_split('/\r\n|\r|\n/', $value) ?: [];
            $multiValues = array_values(array_map(static fn($item): string => trim((string) $item), $multiValues));
        }
    }
    if (!$hasExplicitValue) {
        foreach ($multiItems as $index => $multiItem) {
            if (!array_key_exists($index, $multiValues) || $multiValues[$index] === '') {
                $multiValues[$index] = (string) ($multiItem['default_value'] ?? '');
            }
        }
    }
}
if ($type === \Models\FormField::TYPE_POSTAL_CODE) {
    $postalCodeValue = is_array($value) ? '' : (string) $value;
}
if (!$hasExplicitValue && in_array($type, ['textarea', 'number'], true) && $defaultSettings['default_value'] !== '') {
    $value = $defaultSettings['default_value'];
}
if (!$hasExplicitValue && $type === 'date') {
    if ($dateDefaultSettings['default_mode'] === 'today') {
        $value = date('Y-m-d');
    } elseif ($dateDefaultSettings['default_mode'] === 'fixed') {
        $value = $dateDefaultSettings['default_value'];
    }
}
if (!$hasExplicitValue && $type === 'time') {
    if ($timeDefaultSettings['default_mode'] === 'now') {
        $value = date('H:i');
    } elseif ($timeDefaultSettings['default_mode'] === 'fixed') {
        $value = $timeDefaultSettings['default_value'];
    }
}
if (!$hasExplicitValue && $type === 'radio' && $radioSettings['default_value'] !== '') {
    $value = $radioSettings['default_value'];
}

$postal3 = '';
$postal4 = '';
if ($type === 'address' && $addrPostal !== '') {
    $pd = preg_replace('/\D/', '', $addrPostal);
    if (strlen($pd) >= 7) {
        $postal3 = substr($pd, 0, 3);
        $postal4 = substr($pd, 3, 4);
    } elseif (strlen($pd) > 3) {
        $postal3 = substr($pd, 0, 3);
        $postal4 = substr($pd, 3);
    } elseif ($pd !== '') {
        $postal3 = $pd;
    }
}

$prefOptions = japanese_prefectures();
?>
<?php if (\Models\FormField::isDisplayOnlyType((string) $type)): ?>
    <div class="area is-displayItem is-<?= e((string) $type) ?>" data-module="c-formDisplayItem01" data-field-key="<?= e($key) ?>"<?= $branchHidden ? ' hidden inert' : '' ?>>
        <?php if ($type === \Models\FormField::TYPE_HEADING): ?>
            <h2 class="title"><?= e(trim((string) ($field['help_text'] ?? '')) !== '' ? (string) $field['help_text'] : $label) ?></h2>
        <?php elseif ($type === \Models\FormField::TYPE_DESCRIPTION): ?>
            <div class="text is-description"><?= render_rich_text_html($field['help_text'] ?? '') ?></div>
        <?php elseif ($type === \Models\FormField::TYPE_DIVIDER): ?>
            <hr class="line" aria-label="<?= e($label) ?>">
        <?php endif; ?>
    </div>
    <?php return; ?>
<?php endif; ?>
<div
    class="area is-field <?= ($type !== 'address' && $type !== 'text_pair' && $type !== 'text_multi' && !empty($err)) ? 'is-error' : '' ?>"
    data-field-key="<?= e($key) ?>"
    data-field-type="<?= e((string) $type) ?>"
    data-field-label="<?= e((string) $label) ?>"
    data-field-required="<?= $req ? '1' : '0' ?>"
    data-field-min-length="<?= e((string) ((int) ($field['min_length'] ?? 0))) ?>"
    data-field-max-length="<?= e((string) ((int) ($field['max_length'] ?? 0))) ?>"
    data-field-exact-length="<?= e((string) ((int) ($field['exact_length'] ?? 0))) ?>"
    data-field-checkbox-min="<?= e((string) ($checkboxSettings['min_selections'] ?? '')) ?>"
    data-field-checkbox-max="<?= e((string) ($checkboxSettings['max_selections'] ?? '')) ?>"
    data-field-regex-patterns="<?= e((string) json_encode($regexPatterns, $fieldJsonFlags)) ?>"
    <?= $branchHidden ? ' hidden inert' : '' ?>
>
    <?php if ($showLabel): ?>
        <label for="<?= e($labelFor) ?>" class="label">
            <?= e($label) ?>
            <?php if ($req && $type !== 'address'): ?><span data-module="m-required01" data-type="required">必須</span><?php endif; ?>
        </label>
    <?php endif; ?>

    <?php if (!empty($field['help_text'])): ?>
        <div class="text is-help"><?= render_rich_text_html($field['help_text']) ?></div>
    <?php endif; ?>

    <?php switch ($type):
        case 'text':
        case 'email':
        case 'tel':
        case 'number':
        case 'time': ?>
            <input
                type="<?= e($type) ?>"
                id="f_<?= e($key) ?>"
                name="<?= e($key) ?>"
                value="<?= e(is_array($value) ? '' : $value) ?>"
                <?= $minLengthAttr ?>
                <?= $maxLengthAttr ?>
                placeholder="<?= e($ph) ?>"
                 <?= $req ? 'required' : '' ?>>
            <?php break; ?>

        <?php case 'date':
            $dateValue = is_array($value) ? '' : (string) $value;
            $dateDisplay = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateValue) ? str_replace('-', ' / ', $dateValue) : '';
            $datePlaceholder = $ph !== '' ? $ph : '年 / 月 / 日';
            ?>
            <div class="box is-dateField<?= $dateDisplay === '' ? ' is-empty' : '' ?>" data-date-field>
                <div
                    class="text is-dateDisplay"
                    data-target="publicDateFieldDisplay"
                    data-placeholder="<?= e($datePlaceholder) ?>"
                ><?= e($dateDisplay !== '' ? $dateDisplay : $datePlaceholder) ?></div>
                <input
                    type="date"
                    id="f_<?= e($key) ?>"
                    name="<?= e($key) ?>"
                    value="<?= e($dateValue) ?>"
                    data-target="publicDateFieldInput"
                    <?= $minLengthAttr ?>
                    <?= $maxLengthAttr ?>
                    <?= $req ? 'required' : '' ?>>
            </div>
            <?php break; ?>

        <?php case \Models\FormField::TYPE_POSTAL_CODE: ?>
            <div class="box is-textMulti" id="f_<?= e($key) ?>">
                <div class="box is-textMultiCol">
                    <input
                        type="text"
                        id="f_<?= e($key) ?>"
                        name="<?= e($key) ?>"
                        value="<?= e($postalCodeValue) ?>"
                        inputmode="numeric"
                        autocomplete="postal-code"
                        maxlength="8"
                        placeholder="<?= e($ph !== '' ? $ph : '123-4567') ?>"
                        aria-label="<?= e($label) ?>"
                        <?= $req ? 'required' : '' ?>
                        >
                    <button type="button"
                            class="btn is-secondary is-sm js-zip-lookup"
                            data-postal-code-field="1"
                            data-postal-target-prefecture="<?= e((string) $postalCodeSettings['postal_target_prefecture']) ?>"
                            data-postal-target-city="<?= e((string) $postalCodeSettings['postal_target_city']) ?>">住所検索</button>
                </div>
            </div>
            <?php break; ?>

        <?php case 'textarea': ?>
            <textarea
                id="f_<?= e($key) ?>"
                name="<?= e($key) ?>"
                rows="6"
                <?= $minLengthAttr ?>
                <?= $maxLengthAttr ?>
                placeholder="<?= e($ph) ?>"
                <?= $req ? 'required' : '' ?>><?= e(is_array($value) ? '' : $value) ?></textarea>
            <?php break; ?>

        <?php case 'address': ?>
            <div class="box is-address" id="f_<?= e($key) ?>" data-form-address>
                <?php foreach (($addrErrParts['_root'] ?? []) as $m): ?>
                    <p class="text is-error"><?= e($m) ?></p>
                <?php endforeach; ?>
                <div class="box is-addressRow <?= !empty($addrErrParts['postal']) ? 'is-error' : '' ?>">
                    <label class="label is-sublabel" for="f_<?= e($key) ?>_postal3">郵便番号</label>
                    <div class="area is-inline is-postal">
                        <input
                            type="text"
                            class="input-postal-part1"
                            id="f_<?= e($key) ?>_postal3"
                            name="<?= e($key) ?>[postal3]"
                            value="<?= e($postal3) ?>"
                            inputmode="numeric"
                            autocomplete="postal-code"
                            maxlength="3"
                            placeholder="123"
                            aria-label="郵便番号（上3桁）"
                            >
                        <span class="postal-hyphen" aria-hidden="true">-</span>
                        <input
                            type="text"
                            class="input-postal-part2"
                            id="f_<?= e($key) ?>_postal4"
                            name="<?= e($key) ?>[postal4]"
                            value="<?= e($postal4) ?>"
                            inputmode="numeric"
                            autocomplete="postal-code"
                            maxlength="4"
                            placeholder="4567"
                            aria-label="郵便番号（下4桁）"
                            >
                        <button type="button" class="btn is-secondary is-sm js-zip-lookup">住所検索</button>
                    </div>
                    <?php foreach (($addrErrParts['postal'] ?? []) as $m): ?>
                        <p class="text is-error"><?= e($m) ?></p>
                    <?php endforeach; ?>
                </div>
                <div class="box is-addressRow <?= !empty($addrErrParts['prefecture']) ? 'is-error' : '' ?>">
                    <label class="label is-sublabel <?= $req ? 'is-requiredRow' : '' ?>" for="f_<?= e($key) ?>_prefecture">
                        都道府県
                        <?php if ($req): ?><span data-module="m-required01" data-type="required">必須</span><?php endif; ?>
                    </label>
                    <select
                        class="input-prefecture"
                        id="f_<?= e($key) ?>_prefecture"
                        name="<?= e($key) ?>[prefecture]"
                        autocomplete="address-level1"
                        <?= $req ? 'required' : '' ?>>
                        <option value="">選択してください</option>
                        <?php foreach ($prefOptions as $pname): ?>
                            <option value="<?= e($pname) ?>" <?= ($addrPref === $pname) ? 'selected' : '' ?>><?= e($pname) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php foreach (($addrErrParts['prefecture'] ?? []) as $m): ?>
                        <p class="text is-error"><?= e($m) ?></p>
                    <?php endforeach; ?>
                </div>
                <div class="box is-addressRow <?= !empty($addrErrParts['city']) ? 'is-error' : '' ?>">
                    <label class="label is-sublabel <?= $req ? 'is-requiredRow' : '' ?>" for="f_<?= e($key) ?>_city">
                        市区町村
                        <?php if ($req): ?><span data-module="m-required01" data-type="required">必須</span><?php endif; ?>
                    </label>
                    <input
                        type="text"
                        class="input-city"
                        id="f_<?= e($key) ?>_city"
                        name="<?= e($key) ?>[city]"
                        value="<?= e($addrCity) ?>"
                        autocomplete="address-level2"
                        <?= $minLengthAttr ?>
                        <?= $maxLengthAttr ?>
                        placeholder="例: 千代田区千代田"
                        <?= $req ? 'required' : '' ?>>
                    <?php foreach (($addrErrParts['city'] ?? []) as $m): ?>
                        <p class="text is-error"><?= e($m) ?></p>
                    <?php endforeach; ?>
                </div>
                <div class="box is-addressRow <?= !empty($addrErrParts['number']) || !empty($addrErrParts['combined']) ? 'is-error' : '' ?>">
                    <label class="label is-sublabel <?= $req ? 'is-requiredRow' : '' ?>" for="f_<?= e($key) ?>_number">
                        番地
                        <?php if ($req): ?><span data-module="m-required01" data-type="required">必須</span><?php endif; ?>
                    </label>
                    <input
                        type="text"
                        class="input-number"
                        id="f_<?= e($key) ?>_number"
                        name="<?= e($key) ?>[number]"
                        value="<?= e($addrNumber) ?>"
                        autocomplete="street-address"
                        <?= $minLengthAttr ?>
                        <?= $maxLengthAttr ?>
                        placeholder="例: 1-2-3"
                        <?= $req ? 'required' : '' ?>>
                    <?php foreach (($addrErrParts['number'] ?? []) as $m): ?>
                        <p class="text is-error"><?= e($m) ?></p>
                    <?php endforeach; ?>
                    <?php foreach (($addrErrParts['combined'] ?? []) as $m): ?>
                        <p class="text is-error"><?= e($m) ?></p>
                    <?php endforeach; ?>
                </div>
                <div class="box is-addressRow">
                    <label class="label is-sublabel" for="f_<?= e($key) ?>_building">建物名・部屋番号</label>
                    <input
                        type="text"
                        class="input-building"
                        id="f_<?= e($key) ?>_building"
                        name="<?= e($key) ?>[building]"
                        value="<?= e($addrBuilding) ?>"
                        autocomplete="address-line2"
                        <?= $minLengthAttr ?>
                        <?= $maxLengthAttr ?>
                        placeholder="例: ○○マンション101">
                    <?php foreach (($addrErrParts['building'] ?? []) as $m): ?>
                        <p class="text is-error"><?= e($m) ?></p>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php break; ?>

        <?php case 'text_pair': ?>
            <div class="box is-textPair" id="f_<?= e($key) ?>">
                <?php foreach (($pairErrParts['_root'] ?? []) as $m): ?>
                    <p class="text is-error"><?= e($m) ?></p>
                <?php endforeach; ?>
                <div class="box is-textPairCol <?= !empty($pairErrParts['left']) ? 'is-error' : '' ?>">
                    <label class="label is-sublabel" for="f_<?= e($key) ?>_left">
                        <?= e($pairLabels['left_label'] !== '' ? $pairLabels['left_label'] : '入力欄1') ?>
                    </label>
                    <input
                        type="text"
                        id="f_<?= e($key) ?>_left"
                        name="<?= e($key) ?>[left]"
                        value="<?= e($pairLeft) ?>"
                        <?= $minLengthAttr ?>
                        <?= $maxLengthAttr ?>
                        placeholder="<?= e($pairPlaceholders['left_placeholder']) ?>"
                        aria-label="<?= e($pairLabels['left_label'] !== '' ? $pairLabels['left_label'] : '入力欄1') ?>"
                        <?= $req ? 'required' : '' ?>
                        >
                    <?php foreach (($pairErrParts['left'] ?? []) as $m): ?>
                        <p class="text is-error"><?= e($m) ?></p>
                    <?php endforeach; ?>
                </div>
                <div class="box is-textPairCol <?= !empty($pairErrParts['right']) ? 'is-error' : '' ?>">
                    <label class="label is-sublabel" for="f_<?= e($key) ?>_right">
                        <?= e($pairLabels['right_label'] !== '' ? $pairLabels['right_label'] : '入力欄2') ?>
                    </label>
                    <input
                        type="text"
                        id="f_<?= e($key) ?>_right"
                        name="<?= e($key) ?>[right]"
                        value="<?= e($pairRight) ?>"
                        <?= $minLengthAttr ?>
                        <?= $maxLengthAttr ?>
                        placeholder="<?= e($pairPlaceholders['right_placeholder']) ?>"
                        aria-label="<?= e($pairLabels['right_label'] !== '' ? $pairLabels['right_label'] : '入力欄2') ?>"
                        <?= $req ? 'required' : '' ?>
                        >
                    <?php foreach (($pairErrParts['right'] ?? []) as $m): ?>
                        <p class="text is-error"><?= e($m) ?></p>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php break; ?>

        <?php case 'text_multi': ?>
            <div class="box is-textMulti" id="f_<?= e($key) ?>">
                <?php foreach (($multiErrParts['_root'] ?? []) as $m): ?>
                    <p class="text is-error"><?= e($m) ?></p>
                <?php endforeach; ?>
                <?php foreach ($multiItems as $index => $multiItem): ?>
                    <?php
                        $multiItemLabel = trim((string) ($multiItem['label'] ?? ''));
                        $showMultiItemLabel = $multiItemLabel !== '';
                        $multiItemPlaceholder = (string) ($multiItem['placeholder'] ?? '');
                        $multiItemValue = (string) ($multiValues[$index] ?? '');
                        $multiItemErrors = $multiErrParts['items'][$index] ?? [];
                    ?>
                    <div class="box is-textMultiCol <?= !empty($multiItemErrors) ? 'is-error' : '' ?>">
                        <?php if ($showMultiItemLabel): ?>
                            <label class="label is-sublabel" for="f_<?= e($key) ?>_<?= $index ?>">
                                <?= e($multiItemLabel) ?>
                            </label>
                        <?php endif; ?>
                        <input
                            type="text"
                            id="f_<?= e($key) ?>_<?= $index ?>"
                            name="<?= e($key) ?>[items][]"
                            value="<?= e($multiItemValue) ?>"
                            <?= $minLengthAttr ?>
                            <?= $maxLengthAttr ?>
                            placeholder="<?= e($multiItemPlaceholder) ?>"
                            aria-label="<?= e(\Models\FormField::textMultiItemAriaLabel($multiItem, $index, (string) $label)) ?>"
                            <?= $req ? 'required' : '' ?>
                            >
                        <?php foreach ($multiItemErrors as $m): ?>
                            <p class="text is-error"><?= e($m) ?></p>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php break; ?>

        <?php case \Models\FormField::TYPE_MATRIX: ?>
            <div class="box is-matrix" id="f_<?= e($key) ?>">
                <table>
                    <thead>
                        <tr>
                            <th></th>
                            <?php foreach ($matrixSettings['columns'] as $columnLabel): ?>
                                <th><?= e($columnLabel) ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($matrixSettings['rows'] as $rowIndex => $rowLabel): ?>
                            <tr>
                                <th><?= e($rowLabel) ?></th>
                                <?php foreach ($matrixSettings['columns'] as $columnIndex => $columnLabel): ?>
                                    <?php $checked = (string) ($matrixValueRows[$rowLabel] ?? '') === (string) $columnLabel; ?>
                                    <td>
                                        <label class="label is-choice" for="f_<?= e($key) ?>_<?= $rowIndex ?>_<?= $columnIndex ?>">
                                            <input
                                                type="radio"
                                                id="f_<?= e($key) ?>_<?= $rowIndex ?>_<?= $columnIndex ?>"
                                                name="<?= e($key) ?>[rows][<?= e($rowLabel) ?>]"
                                                value="<?= e($columnLabel) ?>"
                                                <?= $checked ? 'checked' : '' ?>
                                                aria-label="<?= e($rowLabel . ' ' . $columnLabel) ?>">
                                        </label>
                                    </td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php break; ?>

        <?php case 'select': ?>
            <select id="f_<?= e($key) ?>" name="<?= e($key) ?>" <?= $req ? 'required' : '' ?>>
                <option value="">選択してください</option>
                <?php foreach ($opts as $opt): ?>
                    <option value="<?= e($opt) ?>" <?= ((string) $value === $opt) ? 'selected' : '' ?>>
                        <?= e($opt) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <?php break; ?>

        <?php case 'radio': ?>
            <div class="list is-choices">
            <?php foreach ($opts as $i => $opt): ?>
                <label class="label is-choice">
                    <input type="radio" name="<?= e($key) ?>" value="<?= e($opt) ?>"
                        <?= ((string) $value === $opt) ? 'checked' : '' ?>
                        <?= $req ? 'required' : '' ?>>
                    <span><?= e($opt) ?></span>
                </label>
            <?php endforeach; ?>
            </div>
            <?php break; ?>

        <?php case 'checkbox': ?>
            <div class="list is-choices">
            <?php
                $selected = is_array($value) ? $value : (is_string($value) ? explode("\n", $value) : []);
                foreach ($opts as $opt): ?>
                <label class="label is-choice">
                    <input type="checkbox" name="<?= e($key) ?>[]" value="<?= e($opt) ?>"
                        <?= in_array($opt, $selected, true) ? 'checked' : '' ?>>
                    <span><?= e($opt) ?></span>
                </label>
            <?php endforeach; ?>
            </div>
            <?php break; ?>

        <?php case 'file': ?>
            <?php
                $fileSelectionMode = \Models\FormField::normalizeFileSelectionMode((string) ($fileSettings['selection_mode'] ?? \Models\FormField::FILE_SELECTION_CUSTOM));
                $accept = $fileSelectionMode === \Models\FormField::FILE_SELECTION_IMAGE
                    ? implode(',', \Models\FormField::imageAcceptTokens())
                    : ($fileSettings['allowed_extensions'] !== [] ? implode(',', array_map(static fn($item): string => '.' . $item, $fileSettings['allowed_extensions'])) : '');
                $parseIniBytes = static function (string $value): int {
                    $value = trim($value);
                    if ($value === '') {
                        return 0;
                    }
                    $unit = strtolower(substr($value, -1));
                    $number = (float) $value;
                    $bytes = match ($unit) {
                        'g' => $number * 1024 * 1024 * 1024,
                        'm' => $number * 1024 * 1024,
                        'k' => $number * 1024,
                        default => $number,
                    };
                    return max(0, (int) floor($bytes));
                };
                $appUploadMax = (int) config('upload.max_size');
                $uploadIniMax = $parseIniBytes((string) ini_get('upload_max_filesize'));
                $postIniMax = $parseIniBytes((string) ini_get('post_max_size'));
                $effectiveUploadMaxCandidates = array_filter([$appUploadMax, $uploadIniMax, $postIniMax], static fn(int $bytes): bool => $bytes > 0);
                $effectiveUploadMax = $effectiveUploadMaxCandidates !== [] ? min($effectiveUploadMaxCandidates) : $appUploadMax;
                $clientUploadMax = max(1, $effectiveUploadMax - min(256 * 1024, max(0, (int) floor($effectiveUploadMax * 0.1))));
            ?>
            <input
                type="file"
                id="f_<?= e($key) ?>"
                name="<?= e($key) ?>"
                <?php if ($fileSelectionMode === \Models\FormField::FILE_SELECTION_IMAGE): ?>
                    data-file-selection-mode="image"
                    data-file-max-width="1200"
                    data-file-max-height="1200"
                    data-file-jpeg-quality="0.82"
                    data-file-max-size="<?= e((string) $clientUploadMax) ?>"
                <?php endif; ?>
                <?= $accept !== '' ? 'accept="' . e($accept) . '"' : '' ?>
                <?= $req ? 'required' : '' ?>
            >
            <p class="text is-help">最大 <?= e(\Core\Validator::formatBytes($effectiveUploadMax)) ?></p>
            <?php if ($fileSelectionMode === \Models\FormField::FILE_SELECTION_IMAGE): ?>
                <p class="text is-help">許可形式: 画像ファイル（.jpg, .jpeg, .png, .gif, .webp, .heic, .heif）</p>
            <?php elseif ($fileSettings['allowed_extensions'] !== []): ?>
                <p class="text is-help">許可形式: <?= e(implode(', ', array_map(static fn($item): string => '.' . $item, $fileSettings['allowed_extensions']))) ?></p>
            <?php endif; ?>
            <?php break; ?>
    <?php endswitch; ?>

    <?php if ($type !== 'address' && $type !== 'text_pair' && $type !== 'text_multi'): ?>
        <?php foreach ($err as $msg): ?>
            <p class="text is-error"><?= e($msg) ?></p>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
