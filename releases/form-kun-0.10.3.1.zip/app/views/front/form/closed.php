<?php $closedBlocks = decode_form_description_blocks($form['closed_message'] ?? '', true); ?>
<?php $hasClosedContent = false; ?>
<?php foreach ($closedBlocks as $closedBlock): ?>
    <?php if (!empty($closedBlock['visible']) && !empty($closedBlock['html'])): ?>
        <?php $hasClosedContent = true; ?>
        <?php break; ?>
    <?php endif; ?>
<?php endforeach; ?>
<?php $closedPageTitle = trim((string) ($form['closed_page_title'] ?? '')) !== '' ? (string) $form['closed_page_title'] : '現在、フォームをご利用いただけません'; ?>
<?php $closedButtonText = trim((string) ($form['closed_button_text'] ?? '')) !== '' ? (string) $form['closed_button_text'] : 'トップへ戻る'; ?>
<?php $closedButtonUrl = trim((string) ($form['closed_button_url'] ?? '')) !== '' ? (string) $form['closed_button_url'] : '/'; ?>
<section data-module="c-formSet01" data-form-step="closed">
    <?php if (!empty($form['show_closed_page_title']) && $closedPageTitle !== ''): ?>
    <h1 class="title"><?= e($closedPageTitle) ?></h1>
    <?php endif; ?>
    <?= render_form_description_blocks_at($closedBlocks, 0) ?>

<?php if (!$hasClosedContent): ?>
    <p class="text">現在、フォームをご利用いただけません。<br>
    公開時間内に再度お試しください。</p>
<?php endif; ?>

<div class="area is-actions is-centered">
    <a class="btn is-primary" href="<?= e(resolve_form_button_url($closedButtonUrl)) ?>"><?= e($closedButtonText) ?></a>
</div>
<?= render_form_description_blocks_at($closedBlocks, 1) ?>
</section>
