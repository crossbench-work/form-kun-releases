<!doctype html>
<html lang="ja">
<head>
<?php
$pageTitle = trim((string) ($title ?? 'フォーム'));
$metaHtml = trim((string) ($metaHtml ?? ($form['meta_html'] ?? '')));
$customCss = trim((string) ($customCss ?? ($form['custom_css'] ?? '')));
$customJs = trim((string) ($customJs ?? ($form['custom_js'] ?? '')));
$headerHtml = sanitize_rich_text_html($headerHtml ?? ($form['header_html'] ?? ''));
$footerHtml = sanitize_rich_text_html($footerHtml ?? ($form['footer_html'] ?? ''));
?>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=0.9">
<meta name="robots" content="noindex,nofollow">
<title><?= e($pageTitle !== '' ? $pageTitle : 'フォーム') ?></title>
<?php if ($metaHtml !== ''): ?>
<?= $metaHtml . "\n" ?>
<?php endif; ?>
<link rel="stylesheet" href="<?= e(base_path('/assets/css/public.css')) ?>">
<?php if ($customCss !== ''): ?>
<style data-form-custom-css="1">
<?= $customCss . "\n" ?>
</style>
<?php endif; ?>
</head>
<body>
<?php if ($headerHtml !== ''): ?>
<?= $headerHtml . "\n" ?>
<?php endif; ?>

<main class="container">
<?php foreach ((flash() ?? []) as $f): ?>
    <div data-module="m-alert01" class="is-<?= e($f['type']) ?>"><?= e($f['message']) ?></div>
<?php endforeach; ?>

<?= $content ?? '' ?>
<?php if ($footerHtml !== ''): ?>
<?= $footerHtml . "\n" ?>
<?php endif; ?>
</main>

<script>
window.FORMKUN_BASE = <?= json_encode(base_path(''), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE | JSON_HEX_APOS) ?>;
</script>
<script src="<?= e(base_path('/assets/js/vendor/heic2any.min.js')) ?>" defer></script>
<script src="<?= e(base_path('/assets/js/public-form.js')) ?>" defer></script>
<?php if ($customJs !== ''): ?>
<script>
<?= $customJs . "\n" ?>
</script>
<?php endif; ?>
</body>
</html>
