<?php
/**
 * 管理画面汎用モーダル c-modal01。
 * スタイルは同ディレクトリの _c-modal01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_modal01_open')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_modal01_attrs(array $attrs): string
    {
        $attrs['data-module'] = 'c-modal01';
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false) {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_modal01_open(array $attrs = []): void
    {
        echo '<div ' . admin_c_modal01_attrs($attrs) . '>';
    }

    function admin_c_modal01_close(): void
    {
        echo '</div>';
    }

    function admin_c_modal01_backdrop(string $closeTarget): void
    {
        echo '<div class="c-modal01__backdrop" data-target="' . e($closeTarget) . '"></div>';
    }

    function admin_c_modal01_dialog_open(string $labelledby): void
    {
        echo '<div class="c-modal01__dialog" role="dialog" aria-modal="true" aria-labelledby="' . e($labelledby) . '">';
    }

    function admin_c_modal01_dialog_close(): void
    {
        echo '</div>';
    }

    function admin_c_modal01_header_open(): void
    {
        echo '<div class="c-modal01__header">';
    }

    function admin_c_modal01_header_close(): void
    {
        echo '</div>';
    }

    function admin_c_modal01_body_open(): void
    {
        echo '<div class="c-modal01__body">';
    }

    function admin_c_modal01_body_close(): void
    {
        echo '</div>';
    }

    function admin_c_modal01_actions_open(): void
    {
        echo '<div class="c-modal01__actions">';
    }

    function admin_c_modal01_actions_close(): void
    {
        echo '</div>';
    }
}
