<?php
/**
 * 管理画面の小さな警告マーク m-warningMark01。
 * スタイルは同ディレクトリの _m-warningMark01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_warning_mark01')) {
    function admin_m_warning_mark01(string $message): void
    {
        echo '<span data-module="m-warningMark01" role="img" title="' . e($message) . '" aria-label="' . e($message) . '">!</span>';
    }
}
