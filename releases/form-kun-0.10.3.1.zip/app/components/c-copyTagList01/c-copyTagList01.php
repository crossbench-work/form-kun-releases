<?php
/**
 * コピー用タグ一覧 c-copyTagList01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _c-copyTagList01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_copy_tag_list01')) {
    /**
     * @param list<string> $tags
     */
    function admin_c_copy_tag_list01(array $tags): void
    {
        echo '<div data-module="c-copyTagList01"><div data-target="c-copyTagList01__items">';
        foreach ($tags as $tag) {
            $tag = (string) $tag;
            echo '<button type="button" data-target="c-copyTagList01__tag" data-copy-text="' . e($tag) . '"><code>' . e($tag) . '</code></button>';
        }
        echo '</div></div>';
    }
}
