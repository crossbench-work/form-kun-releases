<?php
/**
 * 管理画面本文レイアウト l-adminBody01。
 * スタイルは同ディレクトリの _l-adminBody01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_l_admin_body01_open')) {
    function admin_l_admin_body01_open(): void
    {
        echo '<main data-module="l-adminBody01"><div class="wrapper">';
    }

    function admin_l_admin_body01_close(): void
    {
        echo '</div></main>';
    }
}
