<?php
/**
 * 管理画面の小ラベル見出し m-labelTitle01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _m-labelTitle01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_label_title01')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_label_title01_attrs(array $attrs): string
    {
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_label_title01(string $text, ?string $for = null, array $attrs = []): void
    {
        admin_m_label_title01_html(e($text), $for, $attrs);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_label_title01_html(string $html, ?string $for = null, array $attrs = []): void
    {
        $attrs['data-module'] = 'm-labelTitle01';
        if ($for !== null && $for !== '') {
            $attrs['for'] = $for;
        }
        $attrs['class'] = trim((string) ($attrs['class'] ?? '') . ' label');
        echo '<label ' . admin_m_label_title01_attrs($attrs) . '>' . $html . '</label>';
    }
}
