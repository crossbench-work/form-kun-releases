<?php
/**
 * HTML 入力切り替え付きエディタ c-htmlInputEditor01。
 * スタイルは同ディレクトリの _c-htmlInputEditor01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_html_input_editor01_open')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_html_input_editor01_attrs(array $attrs): string
    {
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_html_input_editor01_open(array $attrs = []): void
    {
        $attrs['data-module'] = 'c-htmlInputEditor01';
        echo '<div ' . admin_c_html_input_editor01_attrs($attrs) . '><div class="wrapper">';
    }

    function admin_c_html_input_editor01_close(): void
    {
        echo '</div></div>';
    }

    /**
     * @param array<string, string|int|float|bool|null> $inputAttrs
     * @param array<string, string|int|float|bool|null> $labelAttrs
     */
    function admin_c_html_input_editor01_toggle(array $inputAttrs = [], string $label = 'HTMLで入力する', array $labelAttrs = []): void
    {
        $labelClass = trim((string) ($labelAttrs['class'] ?? ''));
        $labelAttrs['class'] = trim('label is-choice c-htmlInputEditor01__toggle ' . $labelClass);
        $inputAttrs = array_merge([
            'type' => 'checkbox',
            'data-target' => 'c-htmlInputEditor01__toggle',
            'value' => '1',
        ], $inputAttrs);

        echo '<label ' . admin_c_html_input_editor01_attrs($labelAttrs) . '>';
        echo '<input ' . admin_c_html_input_editor01_attrs($inputAttrs) . '>';
        echo e($label);
        echo '</label>';
    }
}
