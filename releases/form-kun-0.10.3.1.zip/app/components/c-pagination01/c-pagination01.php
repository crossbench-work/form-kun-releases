<?php
/**
 * 管理画面ページネーション c-pagination01。
 * スタイルは同ディレクトリの _c-pagination01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_pagination01_open')) {
    function admin_c_pagination01_open(): void
    {
        echo '<div data-module="c-pagination01">';
    }

    function admin_c_pagination01_close(): void
    {
        echo '</div>';
    }
}
