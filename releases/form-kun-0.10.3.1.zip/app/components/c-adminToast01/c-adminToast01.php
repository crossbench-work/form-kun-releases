<?php
/**
 * 管理画面トースト c-adminToast01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _c-adminToast01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_admin_toast01_stack_open')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_admin_toast01_attrs(array $attrs): string
    {
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_admin_toast01_stack_open(array $attrs = []): void
    {
        $attrs['data-module'] = 'c-adminToastStack01';
        $attrs['id'] = $attrs['id'] ?? 'admin-toast-stack';
        $attrs['aria-live'] = $attrs['aria-live'] ?? 'polite';
        $attrs['aria-relevant'] = $attrs['aria-relevant'] ?? 'additions text';
        echo '<div ' . admin_c_admin_toast01_attrs($attrs) . '>';
    }

    function admin_c_admin_toast01_stack_close(): void
    {
        echo '</div>';
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_admin_toast01(string $message, string $type = 'info', array $attrs = []): void
    {
        $attrs['data-module'] = 'c-adminToast01';
        $attrs['class'] = trim((string) ($attrs['class'] ?? '') . ' is-' . $type);
        $attrs['role'] = $attrs['role'] ?? 'status';
        echo '<div ' . admin_c_admin_toast01_attrs($attrs) . '>' . e($message) . '</div>';
    }
}
