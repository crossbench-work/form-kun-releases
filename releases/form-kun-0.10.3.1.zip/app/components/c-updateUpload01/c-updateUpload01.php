<?php
/**
 * 管理画面の手動 ZIP アップロード c-updateUpload01。
 */
if (!function_exists('admin_c_update_upload01_zone')) {
    function admin_c_update_upload01_zone(): void
    {
        echo '<div class="c-updateUpload01__zone" data-target="c-updateUpload01__zone" tabindex="0" role="button" aria-label="ZIP ファイルを選択">';
        echo '<p class="c-updateUpload01__hint">ZIP をドラッグ＆ドロップ、またはクリックして選択</p>';
        echo '<p class="c-updateUpload01__filename" data-module="m-text01" data-type="muted" data-target="c-updateUpload01__filename" hidden></p>';
        echo '<input type="file" name="update_zip" accept=".zip,application/zip" data-target="c-updateUpload01__input" hidden required>';
        echo '</div>';
    }
}
