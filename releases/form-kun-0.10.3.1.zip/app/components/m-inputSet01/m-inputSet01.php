<?php
/**
 * 管理画面のラベル行＋入力セット m-inputSet01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _m-inputSet01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_input_set01_open')) {
    /**
     * @param array<string, string|int|bool|null> $attrs ルート要素に追加する属性（true は値なし属性、null / false は出力しない）
     */
    function admin_m_input_set01_open(array $attrs = []): void
    {
        $extra = '';
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || (string) $name === 'data-module') {
                continue;
            }
            $extra .= ' ' . e((string) $name) . ($value === true ? '' : '="' . e((string) $value) . '"');
        }
        echo '<div data-module="m-inputSet01"' . $extra . '><div class="wrapper"><div class="block is-contents">';
    }

    function admin_m_input_set01_close(): void
    {
        echo '</div></div></div>';
    }
}
