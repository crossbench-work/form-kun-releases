<?php
/**
 * 管理画面の小さな補助ラベル m-labelSmallTitle01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _m-labelSmallTitle01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_label_small_title01')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_label_small_title01_attrs(array $attrs): string
    {
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_label_small_title01(string $text, ?string $for = null, array $attrs = []): void
    {
        $attrs['data-module'] = 'm-labelSmallTitle01';
        if ($for !== null && $for !== '') {
            $attrs['for'] = $for;
        }
        echo '<label ' . admin_m_label_small_title01_attrs($attrs) . '>' . e($text) . '</label>';
    }
}
