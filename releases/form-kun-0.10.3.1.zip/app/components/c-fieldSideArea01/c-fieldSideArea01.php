<?php
/**
 * 管理画面の左サイドバー UI c-fieldSideArea01。
 * スタイルは同ディレクトリの _c-fieldSideArea01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_field_side_area01_attrs')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_field_side_area01_attrs(array $attrs): string
    {
        $attrs['data-module'] = 'c-fieldSideArea01';
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false) {
                continue;
            }
            $nameStr = (string) $name;
            if ($value === true) {
                $parts[] = e($nameStr);
                continue;
            }
            $parts[] = e($nameStr) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_field_side_area01_open(array $attrs = []): void
    {
        echo '<div ' . admin_c_field_side_area01_attrs($attrs) . '>';
    }

    function admin_c_field_side_area01_close(): void
    {
        echo '</div>';
    }

    function admin_c_field_side_area01_backdrop(string $closeTarget): void
    {
        echo '<div class="c-fieldSideArea01__backdrop" data-target="' . e($closeTarget) . '"></div>';
    }

    function admin_c_field_side_area01_panel_open(string $labelledby): void
    {
        echo '<div class="c-fieldSideArea01__panel" role="dialog" aria-modal="true" aria-labelledby="' . e($labelledby) . '">';
    }

    function admin_c_field_side_area01_panel_close(): void
    {
        echo '</div>';
    }

    function admin_c_field_side_area01_header_open(): void
    {
        echo '<div class="c-fieldSideArea01__header">';
    }

    function admin_c_field_side_area01_header_close(): void
    {
        echo '</div>';
    }

    function admin_c_field_side_area01_body_open(): void
    {
        echo '<div class="c-fieldSideArea01__body">';
    }

    function admin_c_field_side_area01_body_close(): void
    {
        echo '</div>';
    }
}
