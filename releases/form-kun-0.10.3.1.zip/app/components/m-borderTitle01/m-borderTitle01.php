<?php
/**
 * 管理画面の罫線付き小見出し m-borderTitle01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _m-borderTitle01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_border_title01')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_border_title01_attrs(array $attrs): string
    {
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_border_title01(string $text, array $attrs = []): void
    {
        admin_m_border_title01_html(e($text), $attrs);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_border_title01_html(string $html, array $attrs = []): void
    {
        $attrs['data-module'] = 'm-borderTitle01';
        echo '<p ' . admin_m_border_title01_attrs($attrs) . '>' . $html . '</p>';
    }
}
