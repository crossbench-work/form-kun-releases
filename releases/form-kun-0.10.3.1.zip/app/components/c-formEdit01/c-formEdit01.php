<?php
/**
 * フォーム編集画面 c-formEdit01。
 * スタイルは同ディレクトリの _c-formEdit01.scss（_admin-app.scss から @use）。
 * `data-target`（p-formEdit01__dirtyActions 等）は admin.js 互換のため変更しない。
 */
if (!function_exists('admin_c_form_edit01_open')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_form_edit01_attrs(array $attrs): string
    {
        $attrs['data-module'] = 'c-formEdit01';
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_form_edit01_open(array $attrs = []): void
    {
        echo '<form ' . admin_c_form_edit01_attrs($attrs) . '>';
    }

    function admin_c_form_edit01_close(): void
    {
        echo '</form>';
    }

    function admin_c_form_edit01_floating_actions(bool $isNew): void
    {
        require __DIR__ . '/c-formEdit01_floating_actions.php';
    }
}
