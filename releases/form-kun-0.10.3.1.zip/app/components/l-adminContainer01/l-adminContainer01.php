<?php
/**
 * 管理画面全体コンテナ l-adminContainer01。
 * スタイルは同ディレクトリの _l-adminContainer01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_l_admin_container01_open')) {
    function admin_l_admin_container01_open(): void
    {
        echo '<div data-module="l-adminContainer01">';
    }

    function admin_l_admin_container01_close(): void
    {
        echo '</div>';
    }
}
