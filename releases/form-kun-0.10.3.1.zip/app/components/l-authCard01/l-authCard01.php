<?php
/**
 * 認証画面カード配置用レイアウト l-authCard01。
 * スタイルは同ディレクトリの _l-authCard01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_l_auth_card01_open')) {
    function admin_l_auth_card01_open(): void
    {
        echo '<main data-module="l-authCard01">';
    }

    function admin_l_auth_card01_close(): void
    {
        echo '</main>';
    }
}
