<template data-target="m-formBuilder01__groupTemplate">
    <?php admin_c_form_editor_item01_open([
        'data-group-item' => '1',
        'data-group-key' => '',
    ]); ?>
        <div class="wrapper">
            <div class="block is-header">
                <?php admin_c_form_editor_item_header01_open(); ?>
                    <div class="area is-move">
                        <div class="box is-handle ui-sortable-handle" title="ドラッグして並べ替え">
                            <?php admin_m_drag_handle01('c-formEditor__dragHandle'); ?>
                        </div>
                    </div>
                    <div class="area is-summary">
                        <div class="c-formEditorSummary01">
                            <div class="wrapper">
                                <div class="block is-contents">
                                    <p class="index" data-target="c-formEditorGroup__summaryIndex">1</p>
                                    <p class="label" data-target="c-formEditorGroup__summaryLabel">グループ</p>
                                    <p class="type">グループ</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="area is-delete">
                        <label class="c-formEditorSummary01__visibility" title="表示中">
                            <input type="checkbox" data-group-name="visible" value="1" checked>
                            <span aria-hidden="true">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/>
                                    <circle cx="12" cy="12" r="3"/>
                                    <path class="is-hiddenLine" stroke-linecap="round" stroke-linejoin="round" d="M4 20L20 4"/>
                                </svg>
                            </span>
                        </label>
                        <details class="menu" data-target="c-formEditorGroup__actionMenu">
                            <summary class="toggle" aria-label="グループ操作"><span aria-hidden="true">⋯</span></summary>
                            <div class="items" role="menu" aria-label="グループ操作">
                                <button type="button" data-target="c-formEditorGroup__duplicate" role="menuitem">複製</button>
                                <button type="button" data-target="c-formEditorGroup__remove" role="menuitem">削除</button>
                            </div>
                        </details>
                    </div>
                <?php admin_c_form_editor_item_header01_close(); ?>
            </div>
            <div class="block is-body">
                <?php admin_c_form_editor_item_body01_open(); ?>
                    <div class="block is-contents">
                        <div class="block is-title"><p data-module="m-borderTitle01">基本設定</p></div>
                        <div class="block is-field">
                            <div class="c-formEditor__field">
                                <div class="wrapper">
                                    <div class="block is-contents">
                                        <div class="area is-title c-formEditor__labelTitle"><label class="label" data-module="m-labelTitle01">ラベル</label><label class="label is-choice">
                                            <input type="hidden" data-group-name="show_label" value="0">
                                            <input type="checkbox" data-group-name="show_label" value="1" checked>
                                            表示する
                                        </label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                            'type' => 'text',
                                            'data-group-name' => 'label',
                                            'data-target' => 'c-formEditorGroup__labelInput',
                                            'value' => 'グループ',
                                        ]); ?><?php admin_m_input01_close(); ?></div>
                                    </div>
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">UUID</label></div>
                                        <div class="area is-field">
                                            <div class="c-formEditor__fieldKey">
                                                <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                    'type' => 'text',
                                                    'data-target' => 'c-formEditorGroup__groupKeyInput',
                                                    'class' => 'is-locked',
                                                    'readonly' => true,
                                                    'spellcheck' => 'false',
                                                ]); ?><?php admin_m_input01_close(); ?>
                                                <button type="button" class="btn is-icon" data-target="c-formEditorGroup__groupKeyLock" aria-label="UUIDを編集" title="編集する" aria-pressed="true">
                                                    <svg data-target="c-formEditorGroup__groupKeyLockedIcon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                                                    <svg data-target="c-formEditorGroup__groupKeyOpenIcon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:none" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z"/></svg>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="block is-contents">
                        <div class="block is-title"><p data-module="m-borderTitle01">表示設定</p></div>
                        <div class="block is-field">
                            <div class="c-formEditor__field is-vertical">
                                <div class="wrapper">
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">説明文</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_textarea([
                                            'rows' => 2,
                                            'data-group-name' => 'description',
                                        ], ''); ?><?php admin_m_input01_close(); ?></div>
                                    </div>
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">項目設定</label></div>
                                        <div class="area is-field">
                                            <div class="c-formEditor c-formEditorList01 is-nested" data-module="c-formEditorList01">
                                                <div class="wrapper">
                                                    <div class="block is-contents" data-target="m-formBuilder01__fields" data-input-page-key="<?= e(\Models\FormInputPage::DEFAULT_KEY) ?>" data-parent-group-key=""></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="block is-contents">
                                        <div class="area is-field">
                                            <?php admin_m_btn01_button_wrap('＋ 項目を追加', ['type' => 'button', 'class' => 'is-sm', 'data-target' => 'm-formBuilder01__add']); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" data-group-name="group_key" data-target="c-formEditorGroup__groupKey">
                    <input type="hidden" data-group-name="input_page_key" value="<?= e(\Models\FormInputPage::DEFAULT_KEY) ?>" data-target="c-formEditorGroup__inputPageKey">
                    <input type="hidden" data-group-name="parent_group_key" value="" data-target="c-formEditorGroup__parentGroupKey">
                    <input type="hidden" data-group-name="sort_order" value="1" data-target="c-formEditorGroup__sortOrder">
                    <input type="hidden" data-group-name="_remove" value="0" data-target="c-formEditorGroup__removeFlag">
                <?php admin_c_form_editor_item_body01_close(); ?>
            </div>
        </div>
    <?php admin_c_form_editor_item01_close(); ?>
</template>
