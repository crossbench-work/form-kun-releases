<?php
/**
 * フォーム編集のフィールド型選択 UI c-fieldTypeModal01 のマークアップヘルパー。
 * 実際の表示は c-fieldSideArea01 を利用した左サイドバーで描画する。
 * `data-target`（m-formBuilder01__typeModal 等）は admin.js 互換のため変更しない。
 */
if (!function_exists('admin_c_field_type_modal01')) {
    function admin_c_field_type_modal01(): void
    {
        require __DIR__ . '/c-fieldTypeModal01_markup.php';
    }
}
