<?php
$fieldTypeLabels = \Models\FormField::TYPE_LABELS();
$fieldTypeGroups = [
    'よく使う項目' => [
        ['type' => '__name__', 'label' => 'お名前'],
        ['type' => '__name_kana__', 'label' => 'お名前（カナ）'],
        ['type' => '__address_group__', 'label' => '住所'],
        ['type' => 'tel'],
        ['type' => 'email'],
        ['type' => '__gender__', 'label' => '性別'],
        ['type' => '__birthdate__', 'label' => '生年月日'],
        ['type' => '__terms__', 'label' => '規約に同意する'],
    ],
    '基本' => [
        ['type' => 'text_multi'],
        ['type' => 'textarea'],
        ['type' => 'radio'],
        ['type' => 'checkbox'],
        ['type' => 'select'],
        ['type' => 'date'],
        ['type' => 'time'],
        ['type' => 'number'],
        ['type' => 'file'],
        ['type' => 'postal_code'],
    ],
    '装飾' => [
        ['type' => 'heading'],
        ['type' => 'description'],
        ['type' => 'divider'],
        ['type' => '__group__', 'label' => 'グループ'],
    ],
];
?>
<?php admin_c_field_side_area01_open([
    'data-target' => 'm-formBuilder01__typeModal',
    'hidden' => true,
]); ?>
    <?php admin_c_field_side_area01_backdrop('m-formBuilder01__typeModalClose'); ?>
    <?php admin_c_field_side_area01_panel_open('field-type-modal-title'); ?>
        <?php admin_c_field_side_area01_header_open(); ?>
            <h2 id="field-type-modal-title">項目を追加</h2>
            <button type="button" class="btn is-sm" data-target="m-formBuilder01__typeModalClose">閉じる</button>
        <?php admin_c_field_side_area01_header_close(); ?>
        <?php admin_c_field_side_area01_body_open(); ?>
            <?php foreach ($fieldTypeGroups as $groupTitle => $groupItems): ?>
                <section class="c-fieldSideArea01__group">
                    <h3 class="c-fieldSideArea01__groupTitle"><?= e($groupTitle) ?></h3>
                    <div class="c-fieldSideArea01__optionList">
                        <?php foreach ($groupItems as $item):
                            $typeValue = (string) ($item['type'] ?? '');
                            $typeLabel = (string) ($item['label'] ?? ($fieldTypeLabels[$typeValue] ?? ''));
                            if ($typeLabel === '') {
                                continue;
                            }
                        ?>
                            <button
                                type="button"
                                class="c-fieldSideArea01__option"
                                data-target="m-formBuilder01__typeOption"
                                data-field-type="<?= e($typeValue) ?>"
                                data-field-type-label="<?= e($typeLabel) ?>"
                            >
                                <?= e($typeLabel) ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endforeach; ?>
        <?php admin_c_field_side_area01_body_close(); ?>
    <?php admin_c_field_side_area01_panel_close(); ?>
<?php admin_c_field_side_area01_close(); ?>
