# c-fieldTypeModal01（フィールド型選択モーダル）

- **PHP**: [`c-fieldTypeModal01.php`](c-fieldTypeModal01.php) … `admin_c_field_type_modal01()` が [`c-fieldTypeModal01_markup.php`](c-fieldTypeModal01_markup.php) を読み込む。`layouts/admin_components.php` 経由で `require_once`。
- **UI コンポーネント**: 実表示は [`../c-fieldSideArea01/`](../c-fieldSideArea01/) を利用する。`c-fieldTypeModal01` 自体は builder 互換の `data-target` を保つための薄いラッパー。
- **`data-target`**（`m-formBuilder01__typeModal` 等）は `public_html/assets/js/admin.js` が参照するため変更しない。
