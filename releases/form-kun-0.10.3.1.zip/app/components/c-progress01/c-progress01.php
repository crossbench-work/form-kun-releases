<?php
/**
 * 管理画面の進捗表示 c-progress01。
 * スタイルは同ディレクトリの _c-progress01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_progress01')) {
    function admin_c_progress01(float $percent, string $state = ''): void
    {
        $value = min(100.0, max(0.0, $percent));
        $stateClass = in_array($state, ['is-warning', 'is-danger'], true) ? ' class="' . e($state) . '"' : '';
        echo '<div data-module="c-progress01"' . $stateClass . ' role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . e((string) (int) round($value)) . '">';
        echo '<span class="bar"><span class="fill" style="width: ' . e((string) $value) . '%"></span></span>';
        echo '</div>';
    }

    /**
     * @param array<string, mixed> $resource
     */
    function admin_c_progress01_resource_summary(array $resource, string $actionHtml = ''): void
    {
        $percent = (float) ($resource['percent'] ?? 0);
        $state = !empty($resource['exceeded']) ? 'is-danger' : (!empty($resource['warning']) ? 'is-warning' : '');
        echo '<div class="c-titleResource01">';
        echo '<div class="summary">';
        echo '<span class="usage">合計: <strong>' . e(\Core\Validator::formatBytes((int) ($resource['used_total'] ?? 0))) . '</strong> / 上限 ' . e(\Core\Validator::formatBytes((int) ($resource['max'] ?? 0))) . '（' . e(number_format($percent, 1)) . '%）</span>';
        echo '</div>';
        admin_c_progress01($percent, $state);
        if ($actionHtml !== '') {
            echo '<div class="actions">' . $actionHtml . '</div>';
        }
        echo '</div>';
    }
}
