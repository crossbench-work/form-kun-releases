<?php
/**
 * 設定画面のフィールドテンプレート一覧 c-fieldTemplateList01。
 * スタイルは同ディレクトリの _c-fieldTemplateList01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_field_template_list01_open')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_field_template_list01_attrs(array $attrs): string
    {
        $attrs['data-module'] = 'c-fieldTemplateList01';
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_c_field_template_list01_open(array $attrs = []): void
    {
        echo '<div ' . admin_c_field_template_list01_attrs($attrs) . '>';
    }

    function admin_c_field_template_list01_close(): void
    {
        echo '</div>';
    }
}
