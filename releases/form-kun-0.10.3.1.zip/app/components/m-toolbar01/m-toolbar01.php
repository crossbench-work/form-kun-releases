<?php
/**
 * 管理画面ツールバー m-toolbar01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _m-toolbar01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_toolbar01_open')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_toolbar01_attrs(array $attrs): string
    {
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_toolbar01_open(string $tag = 'div', array $attrs = []): void
    {
        $tag = strtolower($tag);
        if (!in_array($tag, ['div', 'form'], true)) {
            $tag = 'div';
        }
        $attrs['data-module'] = 'm-toolbar01';
        echo '<' . $tag . ' ' . admin_m_toolbar01_attrs($attrs) . '>';
    }

    function admin_m_toolbar01_close(string $tag = 'div'): void
    {
        $tag = strtolower($tag);
        if (!in_array($tag, ['div', 'form'], true)) {
            $tag = 'div';
        }
        echo '</' . $tag . '>';
    }
}
