<?php
/** @var string $namePrefix */
/** @var int $i */
/** @var array<string, mixed> $rule */
$blockId = (string) ($rule['id'] ?? ($namePrefix . '-' . $i));
$startInputId = $blockId . '-start';
$endInputId = $blockId . '-end';
$dailyStartInputId = $blockId . '-daily-start';
$dailyEndInputId = $blockId . '-daily-end';
$holidayInputId = $blockId . '-holiday';
$weekdaysMask = isset($rule['weekdays']) && $rule['weekdays'] !== '' ? (int) $rule['weekdays'] : null;
$summaryText = form_publish_rule_summary($rule);
?>
<?php admin_c_form_editor_item01_open([
    'data-publish-rule-block' => true,
    'data-index' => (string) $i,
], true, empty($rule['visible'])); ?>
<input type="hidden" name="<?= e($namePrefix) ?>[<?= $i ?>][id]" value="<?= e($blockId) ?>" data-name="id">
<div class="wrapper">
    <div class="block is-header">
        <?php admin_c_form_editor_item_header01_open(); ?>
        <div class="area is-move">
            <div class="box is-handle ui-sortable-handle" title="ドラッグして並べ替え">
                <?php admin_m_drag_handle01('c-publishScheduleEditor__dragHandle'); ?>
            </div>
        </div>
        <div class="area is-summary">
            <div class="c-publishScheduleEditorSummary01">
                <div class="wrapper">
                    <div class="block is-contents">
                        <p class="detail" data-target="c-publishScheduleEditor__summaryDetail"><?= e($summaryText) ?></p>
                    </div>
                </div>
            </div>
        </div>
        <div class="area is-delete">
            <label class="c-publishScheduleEditorSummary01__visibility" title="<?= !empty($rule['visible']) ? '有効' : '無効' ?>">
                <input type="checkbox" name="<?= e($namePrefix) ?>[<?= $i ?>][visible]" value="1" data-name="visible"
                    <?= !empty($rule['visible']) ? 'checked' : '' ?>>
                <span aria-hidden="true">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" />
                        <circle cx="12" cy="12" r="3" />
                        <path class="is-hiddenLine" stroke-linecap="round" stroke-linejoin="round" d="M4 20L20 4" />
                    </svg>
                </span>
            </label>
            <?php admin_m_delete_btn01('fb-publish-rule-remove'); ?>
        </div>
        <?php admin_c_form_editor_item_header01_close(); ?>
    </div>
    <div class="block is-body">
        <?php admin_c_form_editor_item_body01_open(); ?>
        <div class="block is-field">
            <div class="area is-field">
                <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01(e('公開期間'), $startInputId); ?>
                </div>
                <div class="area is-field">
                    <div class="c-publishScheduleEditorRange01">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label($startInputId, [
                            'type' => 'date',
                            'id' => $startInputId,
                            'name' => $namePrefix . '[' . $i . '][start_at]',
                            'value' => form_publish_date_input_value($rule['start_at'] ?? null),
                            'data-name' => 'start_at',
                            'data-target' => 'c-publishScheduleEditor__startInput',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                        <span class="separator" aria-hidden="true">〜</span>
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label($endInputId, [
                            'type' => 'date',
                            'id' => $endInputId,
                            'name' => $namePrefix . '[' . $i . '][end_at]',
                            'value' => form_publish_date_input_value($rule['end_at'] ?? null),
                            'data-name' => 'end_at',
                            'data-target' => 'c-publishScheduleEditor__endInput',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                </div>
                <?php admin_m_input_set01_close(); ?>
            </div>
        </div>
        <div class="block is-field">
            <div class="area is-field">
                <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01(e('曜日')); ?>
                </div>
                <div class="area is-field">
                    <div class="c-publishScheduleEditorWeekdays01">
                        <?php foreach (form_publish_weekday_ui_order() as $day): ?>
                            <?php
                            $weekdayInputId = $blockId . '-weekday-' . $day;
                            $weekdayAttrs = [
                                'id' => $weekdayInputId,
                                'name' => $namePrefix . '[' . $i . '][weekdays][]',
                                'value' => (string) $day,
                                'data-name' => 'weekdays',
                                'data-weekday' => (string) $day,
                            ];
                            if (form_publish_weekdays_has_day($weekdaysMask, $day)) {
                                $weekdayAttrs['checked'] = true;
                            }
                            admin_m_checkbox01(form_publish_weekday_label($day), $weekdayAttrs);
                            ?>
                        <?php endforeach; ?>
                        <?php admin_m_checkbox01('祝日', admin_m_input01_attrs_with_bound_label($holidayInputId, [
                            'id' => $holidayInputId,
                            'name' => $namePrefix . '[' . $i . '][holiday]',
                            'value' => '1',
                            'data-name' => 'holiday',
                            'checked' => !empty($rule['holiday']),
                        ])); ?>
                    </div>
                </div>
                <?php admin_m_input_set01_close(); ?>
            </div>
        </div>
        <div class="block is-field">
            <div class="area is-field">
                <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01(e('時刻帯'), $dailyStartInputId); ?>
                </div>
                <div class="area is-field">
                    <div class="c-publishScheduleEditorRange01">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label($dailyStartInputId, [
                            'type' => 'time',
                            'id' => $dailyStartInputId,
                            'name' => $namePrefix . '[' . $i . '][daily_start_time]',
                            'value' => $rule['daily_start_time'] ? substr((string) $rule['daily_start_time'], 0, 5) : '',
                            'data-name' => 'daily_start_time',
                            'data-target' => 'c-publishScheduleEditor__dailyStartInput',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                        <span class="separator" aria-hidden="true">〜</span>
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label($dailyEndInputId, [
                            'type' => 'time',
                            'id' => $dailyEndInputId,
                            'name' => $namePrefix . '[' . $i . '][daily_end_time]',
                            'value' => $rule['daily_end_time'] ? substr((string) $rule['daily_end_time'], 0, 5) : '',
                            'data-name' => 'daily_end_time',
                            'data-target' => 'c-publishScheduleEditor__dailyEndInput',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                </div>
                <?php admin_m_input_set01_close(); ?>
            </div>
        </div>
        <?php admin_c_form_editor_item_body01_close(); ?>
    </div>
</div>
<?php admin_c_form_editor_item01_close(); ?>
