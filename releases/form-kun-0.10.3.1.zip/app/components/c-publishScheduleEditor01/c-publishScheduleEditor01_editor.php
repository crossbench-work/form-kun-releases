<?php
/** @var string $namePrefix */
/** @var array<int, array<string, mixed>> $rules */
/** @var string $title */
$scheduleIdPrefix = $namePrefix === 'unpublish_rules' ? 'unpublish' : 'publish';
?>
<div class="area is-field" data-target="publishScheduleEditorWrap">
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e($title)); ?>
    </div>
    <div class="area is-field">
        <div data-module="c-publishScheduleEditor01" data-publish-schedule-editor data-name-prefix="<?= e($namePrefix) ?>" data-id-prefix="<?= e($scheduleIdPrefix) ?>">
            <div class="wrapper">
                <div class="block is-contents">
                    <div class="c-formEditor c-formEditorList01" data-module="c-formEditorList01">
                        <div class="wrapper">
                            <div class="block is-contents" data-publish-rule-list>
                                <?php foreach ($rules as $i => $rule): ?>
                                    <?php require __DIR__ . '/c-publishScheduleEditor01_rule_row.php'; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="block is-toolbar">
                    <div class="area is-actions">
                        <?php admin_m_btn01_button_wrap('＋ 項目を追加', [
                            'data-target' => 'm-formBuilder01__add',
                            'class' => 'fb-publish-rule-add',
                        ]); ?>
                    </div>
                </div>
            </div>
            <template data-publish-rule-template data-target="c-publishScheduleEditor01__ruleTemplate">
                <?php
                $i = 0;
                $rule = [
                    'id' => $scheduleIdPrefix . '-new',
                    'visible' => 1,
                    'position' => 0,
                    'start_at' => null,
                    'end_at' => null,
                    'weekdays' => null,
                    'holiday' => 0,
                    'daily_start_time' => null,
                    'daily_end_time' => null,
                ];
                require __DIR__ . '/c-publishScheduleEditor01_rule_row.php';
                ?>
            </template>
        </div>
    </div>
    <?php admin_m_input_set01_close(); ?>
</div>
