<template data-target="c-publishScheduleEditor01__ruleTemplate">
    <?php
    $namePrefix = 'publish_rules';
    $i = 0;
    $rule = [
        'id' => 'publish-new',
        'visible' => 1,
        'position' => 0,
        'start_at' => null,
        'end_at' => null,
        'weekdays' => null,
        'holiday' => 0,
        'daily_start_time' => null,
        'daily_end_time' => null,
    ];
    require __DIR__ . '/c-publishScheduleEditor01_rule_row.php';
    ?>
</template>
