<?php
/**
 * 公開条件エディタ c-publishScheduleEditor01 のマークアップヘルパー。
 */
if (!function_exists('admin_c_publish_schedule_editor01')) {
    /**
     * @param string $namePrefix
     * @param array<int, array<string, mixed>> $rules
     */
    function admin_c_publish_schedule_editor01(string $namePrefix, array $rules, string $title = '公開条件'): void
    {
        require __DIR__ . '/c-publishScheduleEditor01_editor.php';
    }
}

if (!function_exists('admin_c_publish_schedule_editor01_rule_template')) {
    function admin_c_publish_schedule_editor01_rule_template(string $namePrefix = 'publish_rules', string $idPrefix = 'publish'): void
    {
        require __DIR__ . '/c-publishScheduleEditor01_rule_template.php';
    }
}
