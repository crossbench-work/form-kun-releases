<?php
/**
 * 管理画面の本文テキスト m-text01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _m-text01.scss（_admin-app.scss / _public-app.scss から @use）。
 */
if (!function_exists('admin_m_text01')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_text01_attrs(array $attrs): string
    {
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false) {
                continue;
            }
            $nameStr = (string) $name;
            if ($value === true) {
                $parts[] = e($nameStr);
                continue;
            }
            $parts[] = e($nameStr) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_text01(string $text, string $type = '', string $tag = 'p', array $attrs = []): void
    {
        admin_m_text01_html(e($text), $type, $tag, $attrs);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_text01_html(string $html, string $type = '', string $tag = 'p', array $attrs = []): void
    {
        $tag = strtolower($tag);
        if (!preg_match('/\A(?:p|span|div)\z/', $tag)) {
            $tag = 'p';
        }
        $attrs['data-module'] = 'm-text01';
        if ($type !== '') {
            $attrs['data-type'] = $type;
        }
        $s = admin_m_text01_attrs($attrs);
        echo '<' . $tag . ($s !== '' ? ' ' . $s : '') . '>' . $html . '</' . $tag . '>';
    }
}
