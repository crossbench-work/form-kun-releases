<?php
/**
 * 管理画面の単純な状態アラート m-alert01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _m-alert01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_alert01')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_alert01_attrs(string $type = '', array $attrs = []): string
    {
        $attrs['data-module'] = 'm-alert01';
        if ($type !== '') {
            $attrs['class'] = trim((string) ($attrs['class'] ?? '') . ' is-' . $type);
        }

        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_alert01(string $text, string $type = 'info', array $attrs = []): void
    {
        admin_m_alert01_html(e($text), $type, $attrs);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_alert01_html(string $html, string $type = 'info', array $attrs = []): void
    {
        echo '<div ' . admin_m_alert01_attrs($type, $attrs) . '>' . $html . '</div>';
    }
}
