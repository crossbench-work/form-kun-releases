<?php
/**
 * 管理画面の小さな状態バッジ m-badge01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _m-badge01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_badge01')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_badge01(string $label, string $type = '', array $attrs = []): void
    {
        $attrs['data-module'] = 'm-badge01';
        if ($type !== '') {
            $attrs['class'] = trim((string) ($attrs['class'] ?? '') . ' is-' . $type);
        }

        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        echo '<span ' . implode(' ', $parts) . '>' . e($label) . '</span>';
    }
}
