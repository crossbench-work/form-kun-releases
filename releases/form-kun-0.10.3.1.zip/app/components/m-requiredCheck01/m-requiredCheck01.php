<?php
/**
 * 必須チェックのラベル群 m-requiredCheck01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _m-requiredCheck01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_required_check01_open')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_required_check01_attrs(array $attrs): string
    {
        $attrs['data-module'] = 'm-requiredCheck01';
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_required_check01_open(array $attrs = []): void
    {
        echo '<div ' . admin_m_required_check01_attrs($attrs) . '>';
    }

    function admin_m_required_check01_close(): void
    {
        echo '</div>';
    }
}
