<?php
/**
 * 送信ステータス選択 m-submissionWorkflowStatus01 の補助ヘルパー。
 * スタイルは同ディレクトリの _m-submissionWorkflowStatus01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_submission_workflow_status01_attrs')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_submission_workflow_status01_attrs(bool $detail = false, array $attrs = []): string
    {
        $attrs['data-module'] = 'm-submissionWorkflowStatus01';
        if ($detail) {
            $attrs['class'] = trim((string) ($attrs['class'] ?? '') . ' is-detail');
        }

        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false || $value === '') {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }
}
