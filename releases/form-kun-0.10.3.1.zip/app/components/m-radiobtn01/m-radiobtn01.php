<?php
/**
 * 管理画面のラジオボタン m-radiobtn01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _m-radiobtn01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_radiobtn01_attrs')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_m_radiobtn01_attrs(array $attrs): string
    {
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false) {
                continue;
            }
            $nameStr = (string) $name;
            if ($value === true) {
                $parts[] = e($nameStr);
                continue;
            }
            $parts[] = e($nameStr) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }

    /**
     * @param array<string, string|int|float|bool|null> $inputAttrs
     * @param array<string, string|int|float|bool|null> $moduleAttrs
     */
    function admin_m_radiobtn01(string $label, array $inputAttrs, array $moduleAttrs = []): void
    {
        $inputAttrs = array_merge(['type' => 'radio'], $inputAttrs);
        $moduleAttrs = array_merge(['data-module' => 'm-radiobtn01'], $moduleAttrs);
        $moduleAttrText = admin_m_radiobtn01_attrs($moduleAttrs);
        $inputAttrText = admin_m_radiobtn01_attrs($inputAttrs);

        echo '<label' . ($moduleAttrText !== '' ? ' ' . $moduleAttrText : '') . '>';
        echo '<input' . ($inputAttrText !== '' ? ' ' . $inputAttrText : '') . '>';
        echo '<span class="text">' . e($label) . '</span>';
        echo '</label>';
    }
}
