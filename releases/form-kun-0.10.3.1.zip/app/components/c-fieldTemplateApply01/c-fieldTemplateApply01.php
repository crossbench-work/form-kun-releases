<?php
/**
 * フィールドテンプレート適用モーダル c-fieldTemplateApply01。
 * 現状は画面側の既存マークアップを維持し、読み込み単位として切り出す。
 */
if (!function_exists('admin_c_field_template_apply01_module_name')) {
    function admin_c_field_template_apply01_module_name(): string
    {
        return 'c-fieldTemplateApply01';
    }
}
