<?php
/**
 * 認証画面の最小レイアウト body 用 l-authMinimal01。
 * スタイルは同ディレクトリの _l-authMinimal01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_l_auth_minimal01_body_attrs')) {
    /**
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_l_auth_minimal01_body_attrs(array $attrs = []): string
    {
        $attrs['data-module'] = 'l-authMinimal01';
        $parts = [];
        foreach ($attrs as $name => $value) {
            if ($value === null || $value === false) {
                continue;
            }
            if ($value === true) {
                $parts[] = e((string) $name);
                continue;
            }
            $parts[] = e((string) $name) . '="' . e((string) $value) . '"';
        }

        return implode(' ', $parts);
    }
}
