<?php
namespace Controllers;

use Core\View;
use Models\Form;

class HomeController
{
    public function index(): void
    {
        if (!settings_show_active_forms_list()) {
            $url = settings_active_forms_list_redirect_url();
            if ($url !== '') {
                header('Location: ' . resolve_form_button_url($url), true, 302);
                exit;
            }
            $this->notFound();
            return;
        }

        (new View())->render('front/home', [
            'forms' => Form::allActive(),
            'title' => 'フォーム一覧',
        ], 'public');
    }

    private function notFound(): void
    {
        http_response_code(404);
        (new View())->render('front/404', ['title' => 'Not Found'], 'public');
    }
}
