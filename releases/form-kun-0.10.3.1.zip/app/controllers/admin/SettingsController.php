<?php
namespace Controllers\Admin;

use Core\AppUpdater;
use Core\Auth;
use Core\Csrf;
use Core\FieldKey;
use Core\SiteBackup;
use Core\JapaneseHolidays;
use Core\SiteResource;
use Core\SubmissionPurgeSchedule;
use Core\View;
use Models\AppSetting;
use Models\Form;
use Models\FormField;
use Models\FormFieldGroup;
use Models\FormFieldTemplate;

class SettingsController
{
    public function __construct()
    {
        Auth::requireCanAccessSettings();
    }

    public function index(): void
    {
        Auth::requireLogin();

        $resource = SiteResource::snapshot();

        $data = [
            'title'               => '設定',
            'form_count'          => Form::count(),
            'max_forms'           => effective_max_forms(),
            'storage_used_uploads' => $resource['used_uploads'],
            'storage_used_db'     => $resource['used_db'],
            'storage_used_total'  => $resource['used_total'],
            'storage_max'         => $resource['max'],
            'storage_percent'     => $resource['percent'],
            'storage_warning'     => $resource['warning'],
            'storage_exceeded'    => $resource['exceeded'],
            'storage_max_mb'      => (int) max(1, (int) round($resource['max'] / 1024 / 1024)),
            'storage_resource'     => $resource,
            'field_templates'       => FormFieldTemplate::all(),
            'form_version_interval_minutes' => \Models\FormVersion::intervalMinutes(),
            'form_version_save_on_save' => \Models\FormVersion::saveOnSaveEnabled(),
            'form_version_save_on_login' => \Models\FormVersion::saveOnLoginEnabled(),
            'form_version_save_on_logout' => \Models\FormVersion::saveOnLogoutEnabled(),
            'form_version_retention_limit' => \Models\FormVersion::retentionLimit(),
            'show_active_forms_list' => settings_show_active_forms_list(),
            'active_forms_list_redirect_url' => settings_active_forms_list_redirect_url(),
            'holidays_status' => JapaneseHolidays::status(),
            'holidays_status_message' => JapaneseHolidays::statusMessage(),
            'holidays_fetched_at' => JapaneseHolidays::fetchedAt(),
            'holidays_count' => count(JapaneseHolidays::load()),
            'holidays_fetch_interval_days' => effective_holidays_jp_fetch_interval_days(),
        ];

        $purgeSchedule = SubmissionPurgeSchedule::settings();
        $data['submission_purge_schedule_enabled'] = $purgeSchedule['enabled'];
        $data['submission_purge_schedule_mode'] = $purgeSchedule['mode'];
        $data['submission_purge_schedule_daily_hour'] = $purgeSchedule['daily_hour'];
        $data['submission_purge_schedule_interval_hours'] = $purgeSchedule['interval_hours'];
        $data['submission_purge_schedule_last_run_at'] = $purgeSchedule['last_run_at'];

        if (Auth::role() === 'admin') {
            $data['line_credential_errors'] = $_SESSION['formkun_line_credential_errors'] ?? [];
            unset($_SESSION['formkun_line_credential_errors']);
            $showManifestUi = (bool) config('update.show_manifest_ui', false);
            $manifest = null;
            $manifestError = '';
            if ($showManifestUi && effective_update_manifest_url() !== '') {
                $result = AppUpdater::fetchManifest();
                if ($result['ok']) {
                    $manifest = $result['manifest'];
                } else {
                    $manifestError = $result['message'];
                }
            }

            $data['show_manifest_ui'] = $showManifestUi;
            $data['currentVersion'] = AppUpdater::currentVersion();
            $data['requirements'] = AppUpdater::requirements();
            $data['manifest'] = $manifest;
            $data['manifestError'] = $manifestError;
            $data['releases_page_url'] = update_releases_page_url();
            $data['manual_upload_max_bytes'] = AppUpdater::manualUploadMaxBytes();
        }

        (new View())->render('admin/settings/index', $data, 'admin');
    }

    public function exportBackup(): void
    {
        Auth::requireLogin();
        Auth::requireRole('admin');
        Csrf::verify();

        $back = '/admin/settings#settings-backup';
        $password = (string) ($_POST['backup_password'] ?? '');
        $confirm = (string) ($_POST['backup_password_confirm'] ?? '');
        if (trim($password) === '') {
            flash('danger', 'バックアップのパスワードを入力してください。');
            redirect($back);
        }
        if ($password !== $confirm) {
            flash('danger', 'パスワードと確認が一致しません。');
            redirect($back);
        }

        try {
            SiteBackup::export($password);
        } catch (\InvalidArgumentException | \RuntimeException $e) {
            flash('danger', $e->getMessage());
            redirect($back);
        } catch (\Throwable $e) {
            error_log('[formkun] site backup export failed: ' . $e->getMessage());
            flash('danger', 'バックアップを作成できませんでした。');
            redirect($back);
        }
    }

    public function importBackup(): void
    {
        Auth::requireLogin();
        Auth::requireRole('admin');
        Csrf::verify();

        $back = '/admin/settings#settings-backup';
        $file = $_FILES['backup_file'] ?? null;
        $error = is_array($file) ? (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
            flash('danger', 'ファイルが大きすぎます。サーバーのアップロード上限を確認してください。');
            redirect($back);
        }
        if ($error !== UPLOAD_ERR_OK) {
            flash('danger', 'バックアップ ZIP を選択してください。');
            redirect($back);
        }
        $tmp = (string) ($file['tmp_name'] ?? '');
        $size = (int) ($file['size'] ?? 0);
        $maxBytes = max(1, (int) config('submissions.import_max_bytes', 500 * 1024 * 1024));
        if (!preg_match('/\.zip\z/i', (string) ($file['name'] ?? '')) || $tmp === '' || !is_uploaded_file($tmp)) {
            flash('danger', 'ZIP ファイルを選択してください。');
            redirect($back);
        }
        if ($size <= 0 || $size > $maxBytes) {
            flash('danger', 'ZIP ファイルは ' . number_format((int) floor($maxBytes / 1048576)) . 'MB 以下にしてください。');
            redirect($back);
        }
        $password = (string) ($_POST['restore_password'] ?? '');
        if (trim($password) === '') {
            flash('danger', 'バックアップのパスワードを入力してください。');
            redirect($back);
        }

        try {
            SiteBackup::restore($tmp, $password);
        } catch (\RuntimeException $e) {
            if ($e->getCode() === SiteBackup::ERROR_UPLOADS_AFTER_DB) {
                Auth::logout();
                flash('danger', $e->getMessage());
                redirect('/admin/login');
            }
            flash('danger', $e->getMessage());
            redirect($back);
        } catch (\InvalidArgumentException $e) {
            flash('danger', $e->getMessage());
            redirect($back);
        } catch (\Throwable $e) {
            error_log('[formkun] site backup restore failed: ' . $e->getMessage());
            flash('danger', 'バックアップを復元できませんでした。データは変更されていません。');
            redirect($back);
        }

        Auth::logout();
        flash('success', 'バックアップを復元しました。バックアップ時点のアカウントでログインしてください。');
        redirect('/admin/login');
    }

    public function storeTemplate(): void
    {
        Auth::requireLogin();
        Csrf::verify();

        $payload = $this->collectTemplatePayload();
        FormFieldTemplate::create($payload['title'], $payload['fields'], $payload['field_groups']);
        flash('success', 'テンプレートを保存しました。');
        redirect('/admin/settings#settings-templates');
    }

    public function updateTemplate(int $id): void
    {
        Auth::requireLogin();
        Csrf::verify();

        if (FormFieldTemplate::find($id) === null) {
            flash('danger', 'テンプレートが見つかりません。');
            redirect('/admin/settings#settings-template-editor');
        }

        $payload = $this->collectTemplatePayload();
        FormFieldTemplate::update($id, $payload['title'], $payload['fields'], $payload['field_groups']);
        flash('success', 'テンプレートを保存しました。');
        redirect('/admin/settings#settings-templates');
    }

    public function deleteTemplate(int $id): void
    {
        Auth::requireLogin();
        Csrf::verify();
        FormFieldTemplate::delete($id);
        flash('success', 'テンプレートを削除しました。');
        redirect('/admin/settings#settings-templates');
    }

    public function templateJson(string $id): void
    {
        Auth::requireLogin();
        $template = FormFieldTemplate::findTemplate($id);
        if ($template === null) {
            http_response_code(404);
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode(['ok' => false, 'message' => 'テンプレートが見つかりません。'], JSON_UNESCAPED_UNICODE);
            return;
        }
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'ok' => true,
            'template' => [
                'id' => $template['id'],
                'title' => (string) $template['title'],
                'fields' => $template['fields'],
                'field_groups' => $template['field_groups'],
            ],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function update(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $raw = trim((string) ($_POST['max_forms'] ?? ''));
        $v = filter_var($raw, FILTER_VALIDATE_INT);
        if ($v === false || $v < 1 || $v > 999999) {
            flash('danger', 'フォームの作成上限は 1 から 999999 までの整数で入力してください。');
            redirect('/admin/settings');
        }

        AppSetting::set(AppSetting::KEY_MAX_FORMS, (string) $v);
        flash('success', 'フォームの作成上限を保存しました。');
        redirect('/admin/settings');
    }

    public function updateSiteResource(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $raw = trim((string) ($_POST['max_site_resource_mb'] ?? ''));
        $v = filter_var($raw, FILTER_VALIDATE_INT);
        if ($v === false || $v < 1 || $v > 1048576) {
            flash('danger', '使用リソースの上限は 1 から 1048576 MB までの整数で入力してください。');
            redirect('/admin/settings');
        }

        AppSetting::set(AppSetting::KEY_MAX_SITE_RESOURCE_BYTES, (string) ($v * 1024 * 1024));
        flash('success', '使用リソースの上限を保存しました。');
        redirect('/admin/settings');
    }

    public function updateDisplay(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $redirectUrl = trim((string) ($_POST['active_forms_list_redirect_url'] ?? ''));
        if ($redirectUrl !== '' && !is_form_button_url($redirectUrl)) {
            flash('danger', 'リダイレクト URL は http:// / https:// で始まる URL、または / から始まるパスを指定してください。');
            redirect('/admin/settings#settings-config');
        }

        AppSetting::set(
            AppSetting::KEY_SHOW_ACTIVE_FORMS_LIST,
            !empty($_POST['show_active_forms_list']) ? '1' : '0'
        );
        AppSetting::set(AppSetting::KEY_ACTIVE_FORMS_LIST_REDIRECT_URL, $redirectUrl);

        flash('success', '表示設定を保存しました。');
        redirect('/admin/settings#settings-config');
    }

    public function updateHolidays(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $raw = trim((string) ($_POST['holidays_jp_fetch_interval_days'] ?? ''));
        $v = filter_var($raw, FILTER_VALIDATE_INT);
        if ($v === false || $v < 1 || $v > 3650) {
            flash('danger', '自動取得間隔は 1 から 3650 までの整数で入力してください。');
            redirect('/admin/settings#settings-config');
        }

        AppSetting::set(AppSetting::KEY_HOLIDAYS_JP_FETCH_INTERVAL_DAYS, (string) $v);
        flash('success', '祝日情報の自動取得間隔を保存しました。');
        redirect('/admin/settings#settings-config');
    }

    public function fetchHolidays(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        try {
            JapaneseHolidays::fetchAndSave();
            $count = count(JapaneseHolidays::load());
            flash('success', '祝日情報を取得しました。（' . $count . ' 件）');
        } catch (\Throwable $e) {
            flash('danger', '祝日情報の取得に失敗しました: ' . $e->getMessage());
        }

        redirect('/admin/settings#settings-config');
    }

    public function updateSubmissionPurgeSchedule(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $enabled = !empty($_POST['submission_purge_schedule_enabled']);

        $mode = SubmissionPurgeSchedule::normalizeMode((string) ($_POST['submission_purge_schedule_mode'] ?? ''));

        $hourRaw = trim((string) ($_POST['submission_purge_schedule_daily_hour'] ?? ''));
        $hour = filter_var($hourRaw, FILTER_VALIDATE_INT);
        if ($hour === false || $hour < SubmissionPurgeSchedule::MIN_DAILY_HOUR || $hour > SubmissionPurgeSchedule::MAX_DAILY_HOUR) {
            flash('danger', '実行時刻は 0 から 23 までの整数で入力してください。');
            redirect('/admin/settings#settings-config');
        }

        $intervalRaw = trim((string) ($_POST['submission_purge_schedule_interval_hours'] ?? ''));
        $interval = filter_var($intervalRaw, FILTER_VALIDATE_INT);
        if ($interval === false || $interval < SubmissionPurgeSchedule::MIN_INTERVAL_HOURS || $interval > SubmissionPurgeSchedule::MAX_INTERVAL_HOURS) {
            flash('danger', '実行間隔は 1 から 168 までの整数（時間）で入力してください。');
            redirect('/admin/settings#settings-config');
        }

        AppSetting::set(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_ENABLED, $enabled ? '1' : '0');
        AppSetting::set(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_MODE, $mode);
        AppSetting::set(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_DAILY_HOUR, (string) $hour);
        AppSetting::set(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_INTERVAL_HOURS, (string) $interval);

        flash('success', '受信履歴の定期削除スケジュールを保存しました。');
        redirect('/admin/settings#settings-config');
    }

    public function updateVersioning(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $intervalRaw = trim((string) ($_POST['form_version_interval_minutes'] ?? ''));
        $interval = filter_var($intervalRaw, FILTER_VALIDATE_INT);
        if ($interval === false || $interval < 0 || $interval > 10080) {
            flash('danger', '「◯分おきに保存」は 0 から 10080 までの整数で入力してください。');
            redirect('/admin/settings');
        }

        $retentionRaw = trim((string) ($_POST['form_version_retention_limit'] ?? ''));
        $retention = filter_var($retentionRaw, FILTER_VALIDATE_INT);
        if ($retention === false || $retention < 1 || $retention > 10000) {
            flash('danger', '保存回数は 1 から 10000 までの整数で入力してください。');
            redirect('/admin/settings');
        }

        AppSetting::set(AppSetting::KEY_FORM_VERSION_INTERVAL_MINUTES, (string) $interval);
        AppSetting::set(AppSetting::KEY_FORM_VERSION_SAVE_ON_SAVE, !empty($_POST['form_version_save_on_save']) ? '1' : '0');
        AppSetting::set(AppSetting::KEY_FORM_VERSION_SAVE_ON_LOGIN, !empty($_POST['form_version_save_on_login']) ? '1' : '0');
        AppSetting::set(AppSetting::KEY_FORM_VERSION_SAVE_ON_LOGOUT, !empty($_POST['form_version_save_on_logout']) ? '1' : '0');
        AppSetting::set(AppSetting::KEY_FORM_VERSION_RETENTION_LIMIT, (string) $retention);
        \Models\FormVersion::pruneAllUnpinned();

        flash('success', 'バージョン管理の設定を保存しました。');
        redirect('/admin/settings');
    }

    /**
     * @return array{title:string, fields:array<int, array<string, mixed>>, field_groups:array<int, array<string, mixed>>}
     */
    private function collectTemplatePayload(): array
    {
        return [
            'title' => FormFieldTemplate::normalizeTitle((string) ($_POST['title'] ?? '')),
            'fields' => $this->collectTemplateFields(),
            'field_groups' => $this->collectTemplateGroups(),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function collectTemplateFields(): array
    {
        $raw = $_POST['fields'] ?? [];
        $fields = [];
        if (!is_array($raw)) {
            return [];
        }
        foreach ($raw as $f) {
            if (!is_array($f) || !empty($f['_remove'])) {
                continue;
            }
            $type = FormField::sanitizeType((string) ($f['type'] ?? 'text_multi'));
            $isDisplayOnly = FormField::isDisplayOnlyType($type);
            $required = (!$isDisplayOnly && !empty($f['required'])) ? 1 : 0;
            $regex = trim((string) ($f['regex_pattern'] ?? ''));
            if ($required !== 1 || $isDisplayOnly || in_array($type, ['radio', 'select'], true)) {
                $regex = '';
            }
            $regexStored = $regex !== '' ? FormField::encodeRegexPatterns([$regex]) : null;
            $lengthLimitMode = (string) ($f['length_limit_mode'] ?? '');
            $minLength = isset($f['min_length']) && $f['min_length'] !== '' && !$isDisplayOnly && !in_array($type, ['radio', 'checkbox', 'select', 'file', FormField::TYPE_MATRIX], true) ? (int) $f['min_length'] : '';
            $maxLength = isset($f['max_length']) && $f['max_length'] !== '' && !$isDisplayOnly && !in_array($type, ['radio', 'checkbox', 'select', 'file', FormField::TYPE_MATRIX], true) ? (int) $f['max_length'] : '';
            $exactLength = isset($f['exact_length']) && $f['exact_length'] !== '' && !$isDisplayOnly && !in_array($type, ['radio', 'checkbox', 'select', 'file', FormField::TYPE_MATRIX], true) ? (int) $f['exact_length'] : '';
            if ($lengthLimitMode === 'exact' && $exactLength !== '') {
                $minLength = '';
                $maxLength = '';
            } elseif ($lengthLimitMode === 'range') {
                $exactLength = '';
                if ($minLength !== '' && $maxLength !== '' && $minLength > $maxLength) {
                    $minLength = $maxLength;
                }
            } else {
                $minLength = '';
                $maxLength = '';
                $exactLength = '';
            }
            $fields[] = [
                'input_page_key' => FormField::sanitizeInputPageKey((string) ($f['input_page_key'] ?? 'input-1')),
                'parent_group_key' => FormFieldGroup::sanitizeGroupKey((string) ($f['parent_group_key'] ?? '')) ?: null,
                'sort_order' => isset($f['sort_order']) && is_numeric($f['sort_order']) ? (int) $f['sort_order'] : count($fields) + 1,
                'field_key' => trim((string) ($f['field_key'] ?? '')) !== '' ? trim((string) $f['field_key']) : FieldKey::generateUuidV4(),
                'label' => trim((string) ($f['label'] ?? '')),
                'show_label' => !empty($f['show_label']) ? 1 : 0,
                'visible' => !array_key_exists('visible', $f) || !empty($f['visible']) ? 1 : 0,
                'type' => $type,
                'required' => $required,
                'min_length' => $minLength,
                'max_length' => $maxLength,
                'exact_length' => $exactLength,
                'regex' => $regexStored,
                'regex_pattern' => $regex,
                'help_text' => trim((string) ($f['help_text'] ?? '')),
                'help_text_is_html' => !empty($f['help_text_is_html']) ? 1 : 0,
                'placeholder' => (!$isDisplayOnly && !in_array($type, ['radio', 'checkbox', 'select', 'text_multi'], true)) ? trim((string) ($f['placeholder'] ?? '')) : '',
                'multi_text_items' => (string) ($f['multi_text_items'] ?? ''),
                'checkbox_limit_enabled' => ($type === 'checkbox' && $required === 1 && !empty($f['checkbox_limit_enabled'])) ? 1 : 0,
                'checkbox_min_selections' => isset($f['checkbox_min_selections']) ? (string) $f['checkbox_min_selections'] : '',
                'checkbox_max_selections' => isset($f['checkbox_max_selections']) ? (string) $f['checkbox_max_selections'] : '',
                'options' => (string) ($f['options'] ?? ''),
            ];
        }
        return $fields;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function collectTemplateGroups(): array
    {
        $raw = $_POST['field_groups'] ?? [];
        $groups = [];
        if (!is_array($raw)) {
            return [];
        }
        foreach ($raw as $i => $group) {
            if (!is_array($group) || !empty($group['_remove'])) {
                continue;
            }
            $groupKey = FormFieldGroup::sanitizeGroupKey((string) ($group['group_key'] ?? ''));
            if ($groupKey === '') {
                $groupKey = FieldKey::generateUuidV4();
            }
            $parentGroupKey = FormFieldGroup::sanitizeGroupKey((string) ($group['parent_group_key'] ?? ''));
            if ($parentGroupKey === $groupKey) {
                $parentGroupKey = '';
            }
            $groups[] = [
                'input_page_key' => FormField::sanitizeInputPageKey((string) ($group['input_page_key'] ?? 'input-1')),
                'parent_group_key' => $parentGroupKey !== '' ? $parentGroupKey : null,
                'sort_order' => isset($group['sort_order']) && is_numeric($group['sort_order']) ? (int) $group['sort_order'] : (int) $i + 1,
                'group_key' => $groupKey,
                'label' => trim((string) ($group['label'] ?? '')),
                'show_label' => !empty($group['show_label']) ? 1 : 0,
                'description' => trim((string) ($group['description'] ?? '')),
                'visible' => !array_key_exists('visible', $group) || !empty($group['visible']) ? 1 : 0,
            ];
        }
        return $groups;
    }

    private static function appSettingIsSet(string $key): bool
    {
        $raw = AppSetting::get($key);
        return $raw !== null && $raw !== '';
    }
}
