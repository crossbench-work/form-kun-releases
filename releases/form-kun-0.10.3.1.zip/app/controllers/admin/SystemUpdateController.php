<?php
namespace Controllers\Admin;

use Core\AppUpdater;
use Core\Auth;
use Core\Csrf;

class SystemUpdateController
{
    public function __construct()
    {
        Auth::requireCanAccessSettings();
    }

    public function index(): void
    {
        Auth::requireRole('admin');
        redirect('/admin/settings#app-update');
    }

    public function run(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        if (!AppUpdater::isServerUpdateAllowed()) {
            flash('danger', 'サーバーからの更新が無効です。');
            redirect('/admin/settings#app-update');
        }

        $version = trim((string) ($_POST['version'] ?? ''));
        if ($version === '') {
            flash('danger', 'バージョンを指定してください。');
            redirect('/admin/settings#app-update');
        }

        $result = AppUpdater::applyRelease($version);
        flash($result['ok'] ? 'success' : 'danger', $result['message']);
        redirect('/admin/settings#app-update');
    }

    public function check(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        if (!AppUpdater::isServerUpdateAllowed()) {
            flash('danger', 'サーバーからの更新が無効です。');
            redirect('/admin/settings#app-update');
        }

        $result = AppUpdater::fetchManifest();
        if (!$result['ok']) {
            flash('danger', $result['message']);
            redirect('/admin/settings#app-update');
        }

        $latest = (string) ($result['manifest']['latest'] ?? '');
        $current = AppUpdater::currentVersion();
        if ($latest === '' || version_compare($latest, $current, '<=')) {
            flash('success', 'お使いのバージョンは最新です（' . $current . '）。');
        } else {
            flash('info', '新しいバージョン ' . $latest . ' があります。画面を再読み込みしてください。');
        }
        redirect('/admin/settings#app-update');
    }

    public function upload(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $file = $_FILES['update_zip'] ?? null;
        if (!is_array($file)) {
            $file = null;
        }

        $result = AppUpdater::applyUploadedZip($file, '');
        flash($result['ok'] ? 'success' : 'danger', $result['message']);
        redirect('/admin/settings#app-update-manual');
    }
}
