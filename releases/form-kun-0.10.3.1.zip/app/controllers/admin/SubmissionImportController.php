<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\Csrf;
use Core\FileTypePolicy;
use Core\SubmissionArchive;
use Core\View;
use Models\Form;
use Models\FormField;

/**
 * 送信履歴のインポート。エクスポート ZIP をアップロードし、DB に入れずにプレビューしてから登録する。
 */
class SubmissionImportController
{
    private const SESSION_KEY = '_submission_imports';
    private const TTL_SECONDS = 1800;
    private const MAX_JOBS = 3;
    private const PER_PAGE = 50;

    public function __construct()
    {
        Auth::requireLogin();
    }

    public function uploadForm(int $formId): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); }

        (new View())->render('admin/forms/submissions/import', [
            'title' => 'インポート: ' . $form['title'],
            'form' => $form,
            'maxBytes' => self::maxUploadBytes(),
        ], 'admin');
    }

    public function upload(int $formId): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        Csrf::verify();
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); }

        $back = self::uploadUrl($formId);
        $file = $_FILES['import_file'] ?? null;
        $error = is_array($file) ? (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
            flash('error', 'ファイルが大きすぎます。サーバーのアップロード上限を確認してください。');
            redirect($back);
        }
        if ($error !== UPLOAD_ERR_OK) {
            flash('error', 'エクスポートした ZIP ファイルを選択してください。');
            redirect($back);
        }
        $tmp = (string) ($file['tmp_name'] ?? '');
        $size = (int) ($file['size'] ?? 0);
        if (!preg_match('/\.zip\z/i', (string) ($file['name'] ?? '')) || $tmp === '' || !is_uploaded_file($tmp)) {
            flash('error', 'ZIP ファイルを選択してください。');
            redirect($back);
        }
        if ($size <= 0 || $size > self::maxUploadBytes()) {
            flash('error', 'ZIP ファイルは ' . number_format((int) floor(self::maxUploadBytes() / 1048576)) . 'MB 以下にしてください。');
            redirect($back);
        }

        self::pruneJobs();
        $dir = self::workDir();
        $token = bin2hex(random_bytes(16));
        $path = $dir . DIRECTORY_SEPARATOR . $token . '.zip';
        if (!@move_uploaded_file($tmp, $path)) {
            flash('error', 'アップロードしたファイルを保存できませんでした。');
            redirect($back);
        }

        try {
            $archive = SubmissionArchive::read($path, self::maxRows());
            $analysis = SubmissionArchive::analyze($archive, $form);
            if ($analysis['file_bytes'] > self::maxAttachmentBytes()) {
                throw new \RuntimeException('添付ファイルの合計が、一度にインポートできる上限（約 '
                    . number_format((int) floor(self::maxAttachmentBytes() / 1048576)) . 'MB）を超えています。');
            }
        } catch (\RuntimeException $e) {
            @unlink($path);
            flash('error', $e->getMessage());
            redirect($back);
        } catch (\Throwable $e) {
            @unlink($path);
            error_log('[form-kun] submission import read failed: ' . $e->getMessage());
            flash('error', 'ZIP ファイルを読み込めませんでした。');
            redirect($back);
        }

        $jobs = (array) ($_SESSION[self::SESSION_KEY] ?? []);
        $jobs[$token] = [
            'form_id' => $formId,
            'path' => $path,
            'name' => mb_substr((string) ($file['name'] ?? ''), 0, 200),
            'created_at' => time(),
        ];
        while (count($jobs) > self::MAX_JOBS) {
            $oldest = array_key_first($jobs);
            @unlink((string) ($jobs[$oldest]['path'] ?? ''));
            unset($jobs[$oldest]);
        }
        $_SESSION[self::SESSION_KEY] = $jobs;

        redirect(self::previewUrl($formId, $token));
    }

    /**
     * DB に入れずに内容を表示する。
     */
    public function preview(int $formId, string $token): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); }
        $job = self::findJob($formId, $token);
        if ($job === null) {
            flash('error', 'インポートの有効期限が切れたか、見つかりません。もう一度アップロードしてください。');
            redirect(self::uploadUrl($formId));
        }

        try {
            $archive = SubmissionArchive::read((string) $job['path'], self::maxRows());
            $analysis = SubmissionArchive::analyze($archive, $form);
        } catch (\Throwable $e) {
            self::discardJob($token);
            flash('error', $e instanceof \RuntimeException ? $e->getMessage() : 'ZIP ファイルを読み込めませんでした。');
            redirect(self::uploadUrl($formId));
        }

        $total = count($archive['submissions']);
        $totalPages = max(1, (int) ceil($total / self::PER_PAGE));
        $page = min($totalPages, max(1, (int) ($_GET['page'] ?? 1)));
        $offset = ($page - 1) * self::PER_PAGE;

        $fields = FormField::orderedSubmittableForForm($formId, true);
        $previewKeys = array_slice(array_map(static fn(array $f): string => (string) $f['field_key'], $fields), 0, 3);

        $archiveFieldLabels = [];
        foreach ($archive['fields'] as $field) {
            if (!is_array($field)) {
                continue;
            }
            $fk = (string) ($field['field_key'] ?? '');
            if ($fk !== '') {
                $archiveFieldLabels[$fk] = trim((string) ($field['label'] ?? '')) ?: $fk;
            }
        }
        $unknownLabels = [];
        foreach ($analysis['unknown_keys'] as $key) {
            $unknownLabels[] = $archiveFieldLabels[$key] ?? (string) $key;
        }

        $rows = [];
        foreach (array_slice($archive['submissions'], $offset, self::PER_PAGE, true) as $i => $submission) {
            $rows[] = $submission + [
                'duplicate' => isset($analysis['duplicates'][$i]),
                'archive_index' => $i,
            ];
        }

        (new View())->render('admin/forms/submissions/import_preview', [
            'title' => 'インポートのプレビュー: ' . $form['title'],
            'form' => $form,
            'token' => $token,
            'fileName' => (string) ($job['name'] ?? ''),
            'archive' => $archive,
            'analysis' => $analysis,
            'fields' => $fields,
            'previewKeys' => $previewKeys,
            'unknownLabels' => $unknownLabels,
            'rows' => $rows,
            'total' => $total,
            'newCount' => $total - count($analysis['duplicates']),
            'page' => $page,
            'totalPages' => $totalPages,
            'canImport' => Auth::role() === 'admin',
        ], 'admin');
    }

    public function previewShow(int $formId, string $token, int $index): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        $loaded = $this->loadArchiveJob($formId, $token);
        if ($loaded === null) {
            return;
        }
        ['form' => $form, 'archive' => $archive, 'analysis' => $analysis] = $loaded;

        if (!isset($archive['submissions'][$index])) {
            $this->notFound();
        }
        $submission = $archive['submissions'][$index];
        $values = (array) ($submission['values'] ?? []);
        $fields = FormField::orderedSubmittableForForm($formId, true);

        $filesByKey = [];
        foreach ($submission['files'] as $fileIndex => $file) {
            if (!is_array($file)) {
                continue;
            }
            $key = (string) ($file['field_key'] ?? '');
            if ($key === '') {
                continue;
            }
            $filesByKey[$key][] = $file + ['preview_file_index' => $fileIndex];
        }

        $backPage = max(1, (int) ($_GET['page'] ?? 1));

        (new View())->render('admin/forms/submissions/import_preview_show', [
            'title' => 'インポートのプレビュー: ' . $form['title'],
            'form' => $form,
            'token' => $token,
            'archiveIndex' => $index,
            'sub' => $submission,
            'values' => $values,
            'fields' => $fields,
            'filesByKey' => $filesByKey,
            'duplicate' => isset($analysis['duplicates'][$index]),
            'backPage' => $backPage,
        ], 'admin');
    }

    public function previewFile(int $formId, string $token, int $index, int $fileIndex): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        $loaded = $this->loadArchiveJob($formId, $token);
        if ($loaded === null) {
            return;
        }
        ['job' => $job, 'archive' => $archive] = $loaded;

        if (!isset($archive['submissions'][$index])) {
            $this->notFound();
        }
        $submission = $archive['submissions'][$index];
        $files = $submission['files'] ?? [];
        if (!is_array($files) || !isset($files[$fileIndex]) || !is_array($files[$fileIndex])) {
            $this->notFound();
        }
        $file = $files[$fileIndex];
        $path = $file['path'] ?? null;
        if (!is_string($path) || $path === '') {
            $this->notFound();
        }

        if (!class_exists(\ZipArchive::class)) {
            http_response_code(503);
            echo 'ZIP に対応していません';
            exit;
        }
        $zip = new \ZipArchive();
        if ($zip->open((string) $job['path'], \ZipArchive::RDONLY) !== true) {
            $this->notFound();
        }
        $stat = $zip->statName($path);
        if ($stat === false) {
            $zip->close();
            $this->notFound();
        }
        $stream = $zip->getStream($path);
        if ($stream === false) {
            $zip->close();
            $this->notFound();
        }

        $tmpBase = tempnam(sys_get_temp_dir(), 'formkun-import-file-');
        if ($tmpBase === false) {
            if (is_resource($stream)) {
                fclose($stream);
            }
            $zip->close();
            http_response_code(500);
            echo '一時ファイルを作成できません';
            exit;
        }
        $tmpPath = $tmpBase;
        try {
            $out = fopen($tmpPath, 'wb');
            if ($out === false) {
                throw new \RuntimeException('temp write');
            }
            stream_copy_to_stream($stream, $out);
            fclose($out);
            if (is_resource($stream)) {
                fclose($stream);
            }
            $zip->close();

            $name = (string) ($file['original_name'] ?? 'file');
            $extension = submission_file_extension($file);
            $previewFile = $file;
            if (!isset($previewFile['stored_path']) && $extension !== '') {
                $previewFile['stored_path'] = 'preview.' . $extension;
            }
            $serving = submission_file_serving_mime($previewFile, $tmpPath);
            $requestedInline = isset($_GET['inline']) && (string) $_GET['inline'] !== '' && (string) $_GET['inline'] !== '0';
            $inline = $requestedInline && $serving['inline_ok'];
            $mime = $serving['mime_matches'] ? $serving['mime'] : 'application/octet-stream';

            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            header('Content-Type: ' . $mime);
            header('Content-Length: ' . filesize($tmpPath));
            $disposition = $inline ? 'inline' : 'attachment';
            header('Content-Disposition: ' . $disposition . '; filename="' . self::asciiFallback($name)
                . '"; filename*=UTF-8\'\'' . rawurlencode($name));
            header('X-Content-Type-Options: nosniff');
            header('Content-Security-Policy: sandbox');
            readfile($tmpPath);
        } finally {
            @unlink($tmpPath);
        }
        exit;
    }

    public function commit(int $formId, string $token): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        Auth::requireRole('admin');
        Csrf::verify();
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); }
        $job = self::findJob($formId, $token);
        if ($job === null) {
            flash('error', 'インポートの有効期限が切れたか、見つかりません。もう一度アップロードしてください。');
            redirect(self::uploadUrl($formId));
        }

        @set_time_limit(300);
        try {
            $archive = SubmissionArchive::read((string) $job['path'], self::maxRows());
            $result = SubmissionArchive::import((string) $job['path'], $archive, $form);
        } catch (\RuntimeException $e) {
            flash('error', $e->getMessage());
            redirect(self::previewUrl($formId, $token));
        } catch (\Throwable $e) {
            error_log('[form-kun] submission import failed: ' . $e->getMessage());
            flash('error', 'インポートできませんでした。');
            redirect(self::previewUrl($formId, $token));
        }
        self::discardJob($token);

        $message = $result['imported'] . '件の送信をインポートしました。';
        if ($result['skipped'] > 0) {
            $message .= '既にデータが存在した ' . $result['skipped'] . ' 件は取り込みませんでした。';
        }
        if ($result['failed'] > 0) {
            $message .= $result['failed'] . '件は登録できませんでした。';
        }
        flash($result['failed'] > 0 ? 'error' : 'success', $message);
        redirect('/admin/forms/' . $formId . '/submissions');
    }

    public function discard(int $formId, string $token): void
    {
        Auth::requireCanWriteSubmissions($formId);
        Auth::requireFormAccess($formId);
        Csrf::verify();
        if (self::findJob($formId, $token) !== null) {
            self::discardJob($token);
        }
        flash('success', 'アップロードしたファイルを破棄しました。');
        redirect(self::uploadUrl($formId));
    }

    private static function uploadUrl(int $formId): string
    {
        return '/admin/forms/' . $formId . '/submissions/import';
    }

    private static function previewUrl(int $formId, string $token): string
    {
        return self::uploadUrl($formId) . '/' . $token;
    }

    private static function maxUploadBytes(): int
    {
        return max(1, (int) config('submissions.import_max_bytes', 500 * 1024 * 1024));
    }

    private static function maxAttachmentBytes(): int
    {
        return max(1, (int) config('submissions.export_max_attachment_bytes', 500 * 1024 * 1024));
    }

    private static function maxRows(): int
    {
        return max(1, (int) config('submissions.export_max_rows', 10000));
    }

    private static function workDir(): string
    {
        $dir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'formkun-import';
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new \RuntimeException('一時ディレクトリを作成できません。');
        }
        return $dir;
    }

    /**
     * @return array<string, mixed>|null
     */
    private static function findJob(int $formId, string $token): ?array
    {
        if (preg_match('/\A[0-9a-f]{32}\z/', $token) !== 1) {
            return null;
        }
        self::pruneJobs();
        $job = $_SESSION[self::SESSION_KEY][$token] ?? null;
        if (!is_array($job) || (int) ($job['form_id'] ?? 0) !== $formId || !is_file((string) ($job['path'] ?? ''))) {
            return null;
        }
        return $job;
    }

    private static function discardJob(string $token): void
    {
        $job = $_SESSION[self::SESSION_KEY][$token] ?? null;
        if (is_array($job)) {
            @unlink((string) ($job['path'] ?? ''));
        }
        unset($_SESSION[self::SESSION_KEY][$token]);
    }

    /**
     * 期限切れのジョブと、どのセッションからも参照されなくなった古い一時ファイルを削除する。
     */
    private static function pruneJobs(): void
    {
        $cutoff = time() - self::TTL_SECONDS;
        $jobs = (array) ($_SESSION[self::SESSION_KEY] ?? []);
        foreach ($jobs as $token => $job) {
            if (!is_array($job) || (int) ($job['created_at'] ?? 0) < $cutoff) {
                if (is_array($job)) {
                    @unlink((string) ($job['path'] ?? ''));
                }
                unset($jobs[$token]);
            }
        }
        $_SESSION[self::SESSION_KEY] = $jobs;

        foreach (glob(self::workDir() . DIRECTORY_SEPARATOR . '*.zip') ?: [] as $path) {
            if (is_file($path) && (int) filemtime($path) < $cutoff) {
                @unlink($path);
            }
        }
    }

    /**
     * @return array{form: array<string, mixed>, job: array<string, mixed>, archive: array<string, mixed>, analysis: array<string, mixed>}|null
     */
    private function loadArchiveJob(int $formId, string $token): ?array
    {
        $form = Form::find($formId);
        if (!$form) {
            $this->notFound();
            return null;
        }
        $job = self::findJob($formId, $token);
        if ($job === null) {
            flash('error', 'インポートの有効期限が切れたか、見つかりません。もう一度アップロードしてください。');
            redirect(self::uploadUrl($formId));
            return null;
        }
        try {
            $archive = SubmissionArchive::read((string) $job['path'], self::maxRows());
            $analysis = SubmissionArchive::analyze($archive, $form);
        } catch (\Throwable $e) {
            flash('error', $e instanceof \RuntimeException ? $e->getMessage() : 'ZIP ファイルを読み込めませんでした。');
            redirect(self::uploadUrl($formId));
            return null;
        }

        return [
            'form' => $form,
            'job' => $job,
            'archive' => $archive,
            'analysis' => $analysis,
        ];
    }

    private static function asciiFallback(string $name): string
    {
        $ascii = preg_replace('/[^\x20-\x7e]/', '_', $name) ?? 'download';
        return str_replace('"', '_', $ascii);
    }

    private function notFound(): never
    {
        http_response_code(404);
        echo '<!doctype html><meta charset="utf-8"><title>404</title><h1>404</h1>';
        exit;
    }
}
