<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\Csrf;
use Core\FieldKey;
use Core\FormPublishSchedule;
use Core\FormBundleExportOptions;
use Core\FormBundleTransfer;
use Core\SiteResource;
use Core\SubmissionRetention;
use Core\View;
use Core\SubmissionNotifier;
use Core\LineSiteConfig;
use Core\LineSubmissionNotifier;
use Models\Form;
use Models\FormBranchRule;
use Models\FormEmbedSetting;
use Models\FormField;
use Models\FormFieldGroup;
use Models\FormFieldTemplate;
use Models\FormInputPage;
use Models\FormVersion;
use Models\Submission;

class FormController
{
    private const DEFAULT_META_HTML = <<<'HTML'
<meta name="description" content="フォームの概要を入力してください。">
<meta name="keywords" content="フォーム, お問い合わせ">
HTML;

    /** 公開ページへ生で出力される HTML/JS と、外部接続先を決める SMTP 設定。admin 以外は変更できない。 */
    public const ADMIN_ONLY_FORM_KEYS = [
        'meta_html',
        'custom_css',
        'custom_js',
        'mail_transport',
        'mail_from_email',
        'mail_from_name',
        'mail_smtp_host',
        'mail_smtp_port',
        'mail_smtp_secure',
        'mail_smtp_username',
        'mail_smtp_password',
        'mail_smtp_timeout',
        'mail_smtp_ehlo_host',
        'mail_smtp_verify_peer',
        'mail_smtp_verify_peer_name',
        'mail_smtp_allow_self_signed',
        'line_channel_access_token',
        'line_channel_secret',
        'submission_retention_days',
        'submission_retention_action',
        'submission_retention_enabled',
    ];

    public function __construct()
    {
        Auth::requireLogin();
    }

    public function index(): void
    {
        $forms = Form::allForCurrentUser();
        $countsByForm = [];
        foreach (Submission::countsByForm() as $row) {
            $countsByForm[(int) $row['id']] = (int) $row['cnt'];
        }
        foreach ($forms as &$form) {
            $form['cnt'] = $countsByForm[(int) $form['id']] ?? 0;
        }
        unset($form);
        $formCount = Form::count();
        $maxForms = effective_max_forms();
        $resource = SiteResource::snapshot();
        (new View())->render('admin/forms/index', [
            'title'          => 'フォーム一覧',
            'forms'          => $forms,
            'form_count'     => $formCount,
            'max_forms'      => $maxForms,
            'at_form_limit'  => $formCount >= $maxForms,
            'storage_resource' => $resource,
        ], 'admin');
    }

    public function createForm(): void
    {
        Auth::requireCanManageForms();
        if (Form::count() >= effective_max_forms()) {
            flash('danger', 'フォームの作成上限（' . effective_max_forms() . ' 件）に達しています。設定から上限を変更するか、不要なフォームを削除してください。');
            redirect('/admin/forms');
        }

        $defaultForm = self::defaultForm();
        $inputPages = self::prepareInputPagesForEdit([FormInputPage::defaultPage($defaultForm)], $defaultForm);

        (new View())->render('admin/forms/detail/index', [
            'title' => 'フォーム新規作成',
            'form'  => self::prepareFormForEdit($defaultForm),
            'fields'=> [],
            'fieldGroups' => [],
            'inputPages' => $inputPages,
            'branchRules' => [],
            'fieldTemplates' => FormFieldTemplate::all(),
            'replyFieldOptions' => [],
            'embedSettings' => FormEmbedSetting::defaults(0),
            'errors'=> [],
            'isNew' => true,
        ], 'admin');
    }

    public function store(): void
    {
        Auth::requireCanManageForms();
        Csrf::verify();

        if (Form::count() >= effective_max_forms()) {
            flash('danger', 'フォームの作成上限（' . effective_max_forms() . ' 件）に達しています。設定から上限を変更するか、不要なフォームを削除してください。');
            redirect('/admin/forms');
        }

        $data = $this->collect();
        $data = self::applyEmbedSettingsWhenDisabled($data, null);
        $data['form'] = self::retainAdminOnlyFields($data['form'], null);
        $errors = $this->validate($data, null);

        if (!empty($errors)) {
            $inputPages = self::prepareInputPagesForEdit($data['input_pages'], $data['form']);
            (new View())->render('admin/forms/detail/index', [
                'title' => 'フォーム新規作成',
                'form'  => self::prepareFormForEdit($data['form']),
                'fields'=> $data['fields'],
                'fieldGroups' => $data['field_groups'],
                'inputPages' => $inputPages,
                'branchRules' => $data['branch_rules'],
                'fieldTemplates' => FormFieldTemplate::all(),
                'replyFieldOptions' => self::replyFieldOptions($data['fields'], $data['field_groups'], $inputPages),
                'embedSettings' => self::embedSettingsForView($data['embed_settings']),
                'errors'=> $errors,
                'isNew' => true,
            ], 'admin');
            return;
        }

        $id = Form::createWithRelations(
            $data['form'],
            $data['input_pages'],
            $data['field_groups'],
            $data['fields'],
            $data['branch_rules'],
            FormVersion::ACTION_CREATE,
            Auth::user()
        );
        FormEmbedSetting::save($id, $data['embed_settings']);

        flash('success', 'フォームを作成しました。');
        redirect('/admin/forms/' . $id . '/edit');
    }

    public function edit(int $id): void
    {
        Auth::requireCanManageForm($id);
        $form = Form::find($id);
        if (!$form) { $this->notFound(); return; }
        FormVersion::createIntervalSnapshotIfDue($id, Auth::user());
        $form = self::prepareFormForEdit($form);
        $fields = FormField::forForm($id, true);
        $fieldGroups = FormFieldGroup::forForm($id, true);

        // 編集ビュー用に options をテキストに変換
        $editFields = array_map(function ($f) {
            $f['file_type_mode'] = FormField::FILE_SELECTION_CUSTOM;
            $f['file_convert_to_jpeg'] = 0;
            if (($f['type'] ?? '') === 'text_multi') {
                $f['multi_text_items'] = (string) ($f['options_json'] ?? '');
                $f['text_multi_postal_target_prefecture'] = '';
                $f['text_multi_postal_target_city'] = '';
                $f['postal_target_prefecture'] = '';
                $f['postal_target_city'] = '';
                $f['placeholder'] = '';
                $f['options'] = '';
                $f['default_value'] = '';
                $f['date_default_mode'] = '';
                $f['date_default_value'] = '';
                $f['time_default_mode'] = '';
                $f['time_default_value'] = '';
                $f['radio_default_value'] = '';
                $f['checkbox_limit_enabled'] = 0;
                $f['checkbox_min_selections'] = '';
                $f['checkbox_max_selections'] = '';
                $f['pair_label_left'] = '';
                $f['pair_label_right'] = '';
                $f['pair_placeholder_left'] = '';
                $f['pair_placeholder_right'] = '';
                $f['file_allowed_extensions'] = '';
                $f['matrix_rows'] = '';
                $f['matrix_columns'] = '';
                $f['matrix_selection_type'] = 'radio';
            } elseif (($f['type'] ?? '') === 'file') {
                $fileSettings = \Models\FormField::decodeFileSettings($f['options_json'] ?? null);
                $f['file_allowed_extensions'] = implode(', ', $fileSettings['allowed_extensions']);
                $f['file_type_mode'] = $fileSettings['selection_mode'];
                $f['file_convert_to_jpeg'] = (int) ($fileSettings['convert_to_jpeg'] ?? 0);
                $f['options'] = '';
                $f['checkbox_limit_enabled'] = 0;
                $f['checkbox_min_selections'] = '';
                $f['checkbox_max_selections'] = '';
                $f['default_value'] = '';
                $f['date_default_mode'] = '';
                $f['date_default_value'] = '';
                $f['time_default_mode'] = '';
                $f['time_default_value'] = '';
                $f['radio_default_value'] = '';
                $f['pair_label_left'] = '';
                $f['pair_label_right'] = '';
                $f['pair_placeholder_left'] = '';
                $f['pair_placeholder_right'] = '';
                $f['multi_text_items'] = '';
                $f['text_multi_postal_target_prefecture'] = '';
                $f['text_multi_postal_target_city'] = '';
                $f['postal_target_prefecture'] = '';
                $f['postal_target_city'] = '';
                $f['matrix_rows'] = '';
                $f['matrix_columns'] = '';
                $f['matrix_selection_type'] = 'radio';
            } elseif (($f['type'] ?? '') === \Models\FormField::TYPE_MATRIX) {
                $matrixSettings = \Models\FormField::decodeMatrixSettings($f['options_json'] ?? null);
                $f['matrix_rows'] = implode("\n", $matrixSettings['rows']);
                $f['matrix_columns'] = implode("\n", $matrixSettings['columns']);
                $f['matrix_selection_type'] = $matrixSettings['selection_type'];
                $f['options'] = '';
                $f['checkbox_limit_enabled'] = 0;
                $f['checkbox_min_selections'] = '';
                $f['checkbox_max_selections'] = '';
                $f['default_value'] = '';
                $f['date_default_mode'] = '';
                $f['date_default_value'] = '';
                $f['time_default_mode'] = '';
                $f['time_default_value'] = '';
                $f['radio_default_value'] = '';
                $f['pair_label_left'] = '';
                $f['pair_label_right'] = '';
                $f['pair_placeholder_left'] = '';
                $f['pair_placeholder_right'] = '';
                $f['multi_text_items'] = '';
                $f['text_multi_postal_target_prefecture'] = '';
                $f['text_multi_postal_target_city'] = '';
                $f['postal_target_prefecture'] = '';
                $f['postal_target_city'] = '';
                $f['file_allowed_extensions'] = '';
            } elseif (($f['type'] ?? '') === \Models\FormField::TYPE_POSTAL_CODE) {
                $postalSettings = \Models\FormField::decodePostalCodeSettings($f['options_json'] ?? null);
                $f['options'] = '';
                $f['checkbox_limit_enabled'] = 0;
                $f['checkbox_min_selections'] = '';
                $f['checkbox_max_selections'] = '';
                $f['default_value'] = '';
                $f['date_default_mode'] = '';
                $f['date_default_value'] = '';
                $f['time_default_mode'] = '';
                $f['time_default_value'] = '';
                $f['radio_default_value'] = '';
                $f['pair_label_left'] = '';
                $f['pair_label_right'] = '';
                $f['pair_placeholder_left'] = '';
                $f['pair_placeholder_right'] = '';
                $f['multi_text_items'] = '';
                $f['text_multi_postal_target_prefecture'] = '';
                $f['text_multi_postal_target_city'] = '';
                $f['postal_target_prefecture'] = $postalSettings['postal_target_prefecture'];
                $f['postal_target_city'] = $postalSettings['postal_target_city'];
                $f['file_allowed_extensions'] = '';
                $f['matrix_rows'] = '';
                $f['matrix_columns'] = '';
                $f['matrix_selection_type'] = 'radio';
            } else {
                if (($f['type'] ?? '') === 'checkbox') {
                    $checkboxSettings = \Models\FormField::decodeCheckboxSettings($f['options_json'] ?? null);
                    $f['options'] = implode("\n", $checkboxSettings['options']);
                    $f['checkbox_min_selections'] = $checkboxSettings['min_selections'];
                    $f['checkbox_max_selections'] = $checkboxSettings['max_selections'];
                    $f['checkbox_limit_enabled'] = ($checkboxSettings['min_selections'] !== '' || $checkboxSettings['max_selections'] !== '') ? 1 : 0;
                    $f['radio_default_value'] = '';
                } elseif (($f['type'] ?? '') === 'radio') {
                    $choiceSettings = \Models\FormField::decodeChoiceSettings($f['options_json'] ?? null);
                    $f['options'] = implode("\n", $choiceSettings['options']);
                    $f['checkbox_limit_enabled'] = 0;
                    $f['checkbox_min_selections'] = '';
                    $f['checkbox_max_selections'] = '';
                    $f['radio_default_value'] = $choiceSettings['default_value'];
                } else {
                    $opts = json_decode((string) ($f['options_json'] ?? ''), true);
                    $f['options'] = is_array($opts) && array_keys($opts) === range(0, count($opts) - 1)
                        ? implode("\n", $opts)
                        : '';
                    $f['checkbox_limit_enabled'] = 0;
                    $f['checkbox_min_selections'] = '';
                    $f['checkbox_max_selections'] = '';
                    $f['radio_default_value'] = '';
                }
                if (($f['type'] ?? '') === 'textarea' || ($f['type'] ?? '') === 'number') {
                    $defaultSettings = \Models\FormField::decodeDefaultValueSettings($f['options_json'] ?? null);
                    $f['default_value'] = $defaultSettings['default_value'];
                    $f['date_default_mode'] = '';
                    $f['date_default_value'] = '';
                    $f['time_default_mode'] = '';
                    $f['time_default_value'] = '';
                } elseif (($f['type'] ?? '') === 'date') {
                    $dateSettings = \Models\FormField::decodeDateDefaultSettings($f['options_json'] ?? null);
                    $f['default_value'] = '';
                    $f['date_default_mode'] = $dateSettings['default_mode'];
                    $f['date_default_value'] = $dateSettings['default_value'];
                    $f['time_default_mode'] = '';
                    $f['time_default_value'] = '';
                } elseif (($f['type'] ?? '') === 'time') {
                    $timeSettings = \Models\FormField::decodeTimeDefaultSettings($f['options_json'] ?? null);
                    $f['default_value'] = '';
                    $f['date_default_mode'] = '';
                    $f['date_default_value'] = '';
                    $f['time_default_mode'] = $timeSettings['default_mode'];
                    $f['time_default_value'] = $timeSettings['default_value'];
                } else {
                    $f['default_value'] = '';
                    $f['date_default_mode'] = '';
                    $f['date_default_value'] = '';
                    $f['time_default_mode'] = '';
                    $f['time_default_value'] = '';
                }
                $f['pair_label_left'] = '';
                $f['pair_label_right'] = '';
                $f['pair_placeholder_left'] = '';
                $f['pair_placeholder_right'] = '';
                $f['multi_text_items'] = '';
                $f['text_multi_postal_target_prefecture'] = '';
                $f['text_multi_postal_target_city'] = '';
                $f['postal_target_prefecture'] = '';
                $f['postal_target_city'] = '';
                $f['file_allowed_extensions'] = '';
                $f['matrix_rows'] = '';
                $f['matrix_columns'] = '';
                $f['matrix_selection_type'] = 'radio';
            }
            return $f;
        }, $fields);

        $inputPages = self::prepareInputPagesForEdit(FormInputPage::forForm($id, $form), $form);

        (new View())->render('admin/forms/detail/index', [
            'title' => 'フォーム編集',
            'form'  => $form,
            'fields'=> $editFields,
            'fieldGroups' => $fieldGroups,
            'inputPages' => $inputPages,
            'branchRules' => FormBranchRule::forForm($id),
            'fieldTemplates' => FormFieldTemplate::all(),
            'replyFieldOptions' => self::replyFieldOptions($editFields, $fieldGroups, $inputPages),
            'embedSettings' => FormEmbedSetting::forForm($id),
            'errors'=> [],
            'isNew' => false,
        ], 'admin');
    }

    public function update(int $id): void
    {
        Auth::requireCanManageForm($id);
        $form = Form::find($id);
        if (!$form) { $this->notFound(); return; }

        Csrf::verify();
        $data = $this->collect();
        $data['form'] = self::mergeStoredMailSettings($data['form'], $form, $data['mail_input_presence'] ?? []);
        $data['form'] = self::retainAdminOnlyFields($data['form'], $form);
        $postedRetentionDays = (string) ($data['form']['submission_retention_days'] ?? '');
        if (!Form::retentionEnabled($data['form'])
            && (preg_match('/\A[0-9]{1,4}\z/', $postedRetentionDays) !== 1 || (int) $postedRetentionDays > Form::MAX_RETENTION_DAYS)) {
            $data['form']['submission_retention_days'] = Form::retentionDays($form);
        }
        if (!hash_equals(Form::smtpFingerprint($form), Form::smtpFingerprint($data['form']))) {
            $data['form']['smtp_tested_at'] = null;
            $data['form']['smtp_test_fingerprint'] = null;
        }
        $storedEmbedSettings = FormEmbedSetting::forForm($id);
        $data['embed_settings']['turnstile_secret_configured'] = !empty($storedEmbedSettings['turnstile_secret_configured']) ? 1 : 0;
        $data['embed_settings']['recaptcha_secret_configured'] = !empty($storedEmbedSettings['recaptcha_secret_configured']) ? 1 : 0;
        $data['embed_settings']['recaptcha_v3_secret_configured'] = !empty($storedEmbedSettings['recaptcha_v3_secret_configured']) ? 1 : 0;
        $data['embed_settings']['ipinfo_lite_token_configured'] = !empty($storedEmbedSettings['ipinfo_lite_token_configured']) ? 1 : 0;
        $data = self::applyEmbedSettingsWhenDisabled($data, $storedEmbedSettings);
        $errors = $this->validate($data, $id);

        if (!empty($errors)) {
            $inputPages = self::prepareInputPagesForEdit($data['input_pages'], $data['form']);
            (new View())->render('admin/forms/detail/index', [
                'title' => 'フォーム編集',
                'form'  => self::prepareFormForEdit(self::mergeStoredFormForError($form, $data['form'], $data['mail_input_presence'] ?? [])),
                'fields'=> $data['fields'],
                'fieldGroups' => $data['field_groups'],
                'inputPages' => $inputPages,
                'branchRules' => $data['branch_rules'],
                'fieldTemplates' => FormFieldTemplate::all(),
                'replyFieldOptions' => self::replyFieldOptions($data['fields'], $data['field_groups'], $inputPages),
                'embedSettings' => self::embedSettingsForView(array_merge($storedEmbedSettings, $data['embed_settings'])),
                'errors'=> $errors,
                'isNew' => false,
            ], 'admin');
            return;
        }

        Form::updateWithRelations(
            $id,
            $data['form'],
            $data['input_pages'],
            $data['field_groups'],
            $data['fields'],
            $data['branch_rules'],
            FormVersion::ACTION_UPDATE,
            Auth::user()
        );
        FormEmbedSetting::save($id, $data['embed_settings']);

        $message = 'フォームを更新しました。';
        $updatedForm = Form::find($id);
        if ($updatedForm !== null && self::retentionSettingsChanged($form, $updatedForm)) {
            $purged = SubmissionRetention::purgeExpired($updatedForm);
            if ($purged > 0) {
                $message .= '保存期間を過ぎた受信履歴を ' . number_format($purged) . ' 件削除しました。';
            }
        }
        flash('success', $message);
        redirect('/admin/forms/' . $id . '/edit');
    }

    /**
     * 保存期間の設定を変えた場合に削除される件数（保存前の確認用）。
     */
    public function retentionPreview(int $id): void
    {
        Auth::requireRole('admin');
        $form = Form::find($id);
        if (!$form) { $this->notFound(); return; }

        $form['submission_retention_enabled'] = (string) ($_GET['enabled'] ?? '1') === '0' ? 0 : 1;
        $form['submission_retention_days'] = Form::normalizeRetentionDays($_GET['days'] ?? null);
        $form['submission_retention_action'] = Form::normalizeRetentionAction($_GET['action'] ?? '');

        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        echo json_encode(['count' => SubmissionRetention::countExpired($form)]);
    }

    /**
     * @param array<string, mixed> $before
     * @param array<string, mixed> $after
     */
    private static function retentionSettingsChanged(array $before, array $after): bool
    {
        return Form::retentionEnabled($before) !== Form::retentionEnabled($after)
            || Form::retentionDays($before) !== Form::retentionDays($after)
            || Form::retentionDeletes($before) !== Form::retentionDeletes($after);
    }

    public function testSmtp(int $id): void
    {
        Auth::requireRole('admin');
        $storedForm = Form::find($id);
        if (!$storedForm) { $this->notFound(); return; }
        Csrf::verify();

        // 画面上の値でテストし、結果にかかわらず有効なフォーム設定は保存する。
        // これによりテスト後のリダイレクトで入力したSMTP設定が失われない。
        $data = $this->collect();
        $data['form'] = self::mergeStoredMailSettings($data['form'], $storedForm, $data['mail_input_presence'] ?? []);
        $requestedMode = (string) ($data['form']['submission_storage_mode'] ?? Form::STORAGE_DATABASE);
        $data['form']['submission_storage_mode'] = Form::STORAGE_DATABASE;
        $data['form']['smtp_tested_at'] = null;
        $data['form']['smtp_test_fingerprint'] = null;

        $storedEmbedSettings = FormEmbedSetting::forForm($id);
        $data['embed_settings']['turnstile_secret_configured'] = !empty($storedEmbedSettings['turnstile_secret_configured']) ? 1 : 0;
        $data['embed_settings']['recaptcha_secret_configured'] = !empty($storedEmbedSettings['recaptcha_secret_configured']) ? 1 : 0;
        $data['embed_settings']['recaptcha_v3_secret_configured'] = !empty($storedEmbedSettings['recaptcha_v3_secret_configured']) ? 1 : 0;
        $data['embed_settings']['ipinfo_lite_token_configured'] = !empty($storedEmbedSettings['ipinfo_lite_token_configured']) ? 1 : 0;
        $errors = $this->validate($data, $id);

        if ((string) ($data['form']['mail_transport'] ?? '') !== 'smtp') {
            $errors[] = 'SMTPテストを行うには送信方式でSMTPを選択してください。';
        }
        if (trim((string) ($data['form']['admin_emails'] ?? '')) === '') {
            $errors[] = 'SMTPテストを行うには管理者通知先を入力してください。';
        }
        if ($errors !== []) {
            $inputPages = self::prepareInputPagesForEdit($data['input_pages'], $data['form']);
            (new View())->render('admin/forms/detail/index', [
                'title' => 'フォーム編集',
                'form' => self::prepareFormForEdit(self::mergeStoredFormForError($storedForm, $data['form'], $data['mail_input_presence'] ?? [])),
                'fields' => $data['fields'],
                'fieldGroups' => $data['field_groups'],
                'inputPages' => $inputPages,
                'branchRules' => $data['branch_rules'],
                'fieldTemplates' => FormFieldTemplate::all(),
                'replyFieldOptions' => self::replyFieldOptions($data['fields'], $data['field_groups'], $inputPages),
                'embedSettings' => self::embedSettingsForView(array_merge($storedEmbedSettings, $data['embed_settings'])),
                'errors' => $errors,
                'isNew' => false,
            ], 'admin');
            return;
        }

        $testForm = $data['form'];
        $sent = SubmissionNotifier::sendSmtpTest($testForm);
        if ($sent) {
            $data['form']['submission_storage_mode'] = $requestedMode;
            $data['form']['smtp_tested_at'] = date('Y-m-d H:i:s');
            $data['form']['smtp_test_fingerprint'] = Form::smtpFingerprint($testForm);
        }
        Form::updateWithRelations(
            $id,
            $data['form'],
            $data['input_pages'],
            $data['field_groups'],
            $data['fields'],
            $data['branch_rules'],
            FormVersion::ACTION_UPDATE,
            Auth::user()
        );
        FormEmbedSetting::save($id, $data['embed_settings']);

        if ($sent) {
            flash('success', '設定を保存し、SMTPテストメールを送信しました。');
        } else {
            flash('danger', '設定を保存しましたが、SMTPテストメールを送信できませんでした。メール送信のみモードは無効のままです。');
        }
        redirect('/admin/forms/' . $id . '/edit#mail-smtp');
    }

    public function testLine(int $id): void
    {
        Auth::requireCanManageForm($id);
        $storedForm = Form::find($id);
        if (!$storedForm) {
            $this->respondLineNotifySettingsJson(false, 'フォームが見つかりません。', 404);

            return;
        }
        Csrf::verify();

        if (trim((string) ($storedForm['line_push_to_id'] ?? '')) === '') {
            $this->respondLineNotifySettingsJson(false, '送信先 ID が未設定です。', 400);

            return;
        }
        if (LineSiteConfig::channelAccessToken() === '') {
            $this->respondLineNotifySettingsJson(false, 'Channel access token が未設定です。', 400);

            return;
        }

        $sent = LineSubmissionNotifier::sendTest($storedForm);
        if ($sent) {
            $this->respondLineNotifySettingsJson(true, 'LINE テストメッセージを送信しました。', 200);
        } else {
            $this->respondLineNotifySettingsJson(
                false,
                'LINE テストメッセージを送信できませんでした。トークン・送信先 ID を確認してください。',
                502
            );
        }
    }

    public function testLineMessage(int $id): void
    {
        Auth::requireCanManageForm($id);
        $storedForm = Form::find($id);
        if (!$storedForm) {
            $this->respondLineNotifySettingsJson(false, 'フォームが見つかりません。', 404);

            return;
        }
        Csrf::verify();

        if (!LineSiteConfig::isSetupComplete()) {
            $this->respondLineNotifySettingsJson(false, 'アカウント連携のチェックリストが未完了です。設定 → LINE 連携を完了してください。', 400);

            return;
        }
        if (LineSiteConfig::pushToId() === '') {
            $this->respondLineNotifySettingsJson(false, '送信先 ID が未設定です。', 400);

            return;
        }
        if (LineSiteConfig::channelAccessToken() === '') {
            $this->respondLineNotifySettingsJson(false, 'Channel access token が未設定です。', 400);

            return;
        }

        $templateFromRequest = (string) ($_POST['line_message_template'] ?? '');
        $fields = FormField::forForm($id, true);
        $sent = LineSubmissionNotifier::sendMessageTest($storedForm, $fields, $templateFromRequest);
        if ($sent) {
            $this->respondLineNotifySettingsJson(true, 'テストメッセージを送信しました。', 200);
        } else {
            $this->respondLineNotifySettingsJson(
                false,
                'テストメッセージを送信できませんでした。トークン・送信先 ID を確認してください。',
                502
            );
        }
    }

    public function resetLineAccountLink(int $id): void
    {
        Auth::requireRole('admin');
        $storedForm = Form::find($id);
        if (!$storedForm) {
            $this->notFound();

            return;
        }
        Csrf::verify();

        Form::resetLineAccountLink($id);
        flash('success', 'アカウント連携の設定を解除しました。');
        redirect('/admin/forms/' . $id . '/edit#mail-line');
    }

    public function saveLineChannelSecret(int $id): void
    {
        $this->saveLineCredential($id, 'secret');
    }

    public function deleteLineChannelSecret(int $id): void
    {
        $this->saveLineCredential($id, 'delete_secret');
    }

    public function saveLineChannelAccessToken(int $id): void
    {
        $this->saveLineCredential($id, 'token');
    }

    public function deleteLineChannelAccessToken(int $id): void
    {
        $this->saveLineCredential($id, 'delete_token');
    }

    public function updateLineSetupChecklist(int $id): void
    {
        Auth::requireCanManageForm($id);
        $storedForm = Form::find($id);
        if (!$storedForm) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
            http_response_code(404);
            echo json_encode(['ok' => false, 'message' => 'フォームが見つかりません。'], JSON_UNESCAPED_UNICODE);

            return;
        }
        Csrf::verify();
        $item = trim((string) ($_POST['item'] ?? ''));
        $checked = (string) ($_POST['checked'] ?? '0') === '1';
        if (!in_array($item, Form::lineFormSetupChecklistItemKeys(), true)) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
            http_response_code(400);
            echo json_encode(['ok' => false, 'message' => '不正なチェック項目です。'], JSON_UNESCAPED_UNICODE);

            return;
        }
        if (!Form::lineSetupChecklistItemIsManual($item)) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
            http_response_code(400);
            echo json_encode(['ok' => false, 'message' => 'この項目は手動でチェックできません。'], JSON_UNESCAPED_UNICODE);

            return;
        }
        try {
            Form::updateLineSetupChecklistItem($id, $item, $checked);
        } catch (\InvalidArgumentException $e) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
            http_response_code(400);
            echo json_encode(['ok' => false, 'message' => '不正なチェック項目です。'], JSON_UNESCAPED_UNICODE);

            return;
        }
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        echo json_encode(['ok' => true, 'item' => $item, 'checked' => $checked], JSON_UNESCAPED_UNICODE);
    }

    public function syncLineTalkSendSetupChecklist(int $id): void
    {
        Auth::requireCanManageForm($id);
        $storedForm = Form::find($id);
        if (!$storedForm) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
            http_response_code(404);
            echo json_encode(['ok' => false, 'message' => 'フォームが見つかりません。'], JSON_UNESCAPED_UNICODE);

            return;
        }
        Csrf::verify();
        $panelId = trim((string) ($_POST['panel'] ?? ''));
        if (!in_array($panelId, ['line-talk-user', 'line-talk-group'], true)) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
            http_response_code(400);
            echo json_encode(['ok' => false, 'message' => '不正なタブです。'], JSON_UNESCAPED_UNICODE);

            return;
        }
        try {
            $checked = Form::syncLineTalkSendSetupChecklistForPanel($id, $panelId);
        } catch (\InvalidArgumentException $e) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
            http_response_code(400);
            echo json_encode(['ok' => false, 'message' => 'チェック状態を保存できません。'], JSON_UNESCAPED_UNICODE);

            return;
        }
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        echo json_encode([
            'ok' => true,
            'item' => Form::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP,
            'checked' => $checked,
        ], JSON_UNESCAPED_UNICODE);
    }

    public function deleteLineWebhookTarget(int $id): void
    {
        Auth::requireCanManageForm($id);
        $storedForm = Form::find($id);
        if (!$storedForm) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
            http_response_code(404);
            echo json_encode(['ok' => false, 'message' => 'フォームが見つかりません。'], JSON_UNESCAPED_UNICODE);

            return;
        }
        Csrf::verify();
        $targetType = trim((string) ($_POST['target_type'] ?? ''));
        $targetId = trim((string) ($_POST['target_id'] ?? ''));
        if (!in_array($targetType, ['user', 'group', 'room'], true) || $targetId === '') {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
            http_response_code(400);
            echo json_encode(['ok' => false, 'message' => '不正な ID です。'], JSON_UNESCAPED_UNICODE);

            return;
        }
        \Models\LineWebhookTarget::remove($targetType, $targetId);
        $types = in_array($targetType, ['group', 'room'], true) ? ['group', 'room'] : ['user'];
        \Core\LineSiteConfig::syncLineTalkSendSetupChecklistForTypes($types);
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
    }

    public function saveLineStep2(int $id): void
    {
        $this->saveLineStep($id, 2);
    }

    public function saveLineStep3(int $id): void
    {
        $this->saveLineStep($id, 3);
    }

    public function saveLineNotifySettings(int $id): void
    {
        Auth::requireCanManageForm($id);
        $storedForm = Form::find($id);
        if (!$storedForm) {
            $this->respondLineNotifySettingsJson(false, 'フォームが見つかりません。', 404);

            return;
        }
        Csrf::verify();

        $_POST['_line_save_step'] = '3';
        $data = $this->collect();
        $presence = $data['mail_input_presence'] ?? [];
        $presence['line_save_step'] = 3;
        $data['form'] = self::mergeStoredMailSettings($data['form'], $storedForm, $presence);
        $data['form'] = self::retainAdminOnlyFields($data['form'], $storedForm);

        if (!self::wasMailInputPosted($presence, 'line_message_template')) {
            $data['form']['line_message_template'] = $storedForm['line_message_template'] ?? '';
        } elseif (!Form::lineSetupChecklistIsCompleteForFormRow($storedForm)) {
            $storedTemplate = (string) ($storedForm['line_message_template'] ?? '');
            $newTemplate = (string) ($data['form']['line_message_template'] ?? '');
            if ($newTemplate !== $storedTemplate) {
                $this->respondLineNotifySettingsJson(
                    false,
                    'アカウント連携のチェックリストが未完了のため、表示設定を保存できません。',
                    400
                );

                return;
            }
        }

        Form::updateWithRelations(
            $id,
            $data['form'],
            $data['input_pages'],
            $data['field_groups'],
            $data['fields'],
            $data['branch_rules'],
            FormVersion::ACTION_UPDATE,
            Auth::user()
        );
        FormEmbedSetting::save($id, $data['embed_settings']);

        $this->respondLineNotifySettingsJson(true, null, 200, [
            'line_notify_enabled' => !empty($data['form']['line_notify_enabled']) ? 1 : 0,
        ]);
    }

    /**
     * @param array<string, mixed> $extra
     */
    private function respondLineNotifySettingsJson(bool $ok, ?string $message, int $status, array $extra = []): void
    {
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        http_response_code($status);
        $payload = array_merge(['ok' => $ok], $extra);
        if ($message !== null && $message !== '') {
            $payload['message'] = $message;
        }
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    }

    /**
     * @param 'secret'|'delete_secret'|'token'|'delete_token' $action
     */
    private function saveLineCredential(int $id, string $action): void
    {
        Auth::requireRole('admin');
        $storedForm = Form::find($id);
        if (!$storedForm) {
            $this->notFound();

            return;
        }
        Csrf::verify();

        $_POST['_line_save_credential'] = $action;
        $data = $this->collect();
        $presence = $data['mail_input_presence'] ?? [];
        $presence['line_save_credential'] = $action;
        $data['form'] = self::mergeStoredMailSettings($data['form'], $storedForm, $presence);
        $data['form'] = self::retainAdminOnlyFields($data['form'], $storedForm);

        $storedEmbedSettings = FormEmbedSetting::forForm($id);
        $lineCredentialErrors = [
            'line_channel_secret' => [],
            'line_channel_access_token' => [],
        ];
        if ($action === 'secret') {
            $lineCredentialErrors['line_channel_secret'] = self::validateLineChannelSecretForSave($data['form']);
        } elseif ($action === 'token') {
            $lineCredentialErrors['line_channel_access_token'] = self::validateLineChannelAccessTokenForSave($data['form']);
        }

        $hasCredentialErrors = $lineCredentialErrors['line_channel_secret'] !== []
            || $lineCredentialErrors['line_channel_access_token'] !== [];

        if ($hasCredentialErrors) {
            $inputPages = self::prepareInputPagesForEdit($data['input_pages'], $data['form']);
            (new View())->render('admin/forms/detail/index', [
                'title' => 'フォーム編集',
                'form' => self::prepareFormForEdit(self::mergeStoredFormForError($storedForm, $data['form'], $presence)),
                'fields' => $data['fields'],
                'fieldGroups' => $data['field_groups'],
                'inputPages' => $inputPages,
                'branchRules' => $data['branch_rules'],
                'fieldTemplates' => FormFieldTemplate::all(),
                'replyFieldOptions' => self::replyFieldOptions($data['fields'], $data['field_groups'], $inputPages),
                'embedSettings' => self::embedSettingsForView(array_merge($storedEmbedSettings, $data['embed_settings'])),
                'errors' => [],
                'lineCredentialErrors' => $lineCredentialErrors,
                'isNew' => false,
            ], 'admin');

            return;
        }

        Form::updateWithRelations(
            $id,
            $data['form'],
            $data['input_pages'],
            $data['field_groups'],
            $data['fields'],
            $data['branch_rules'],
            FormVersion::ACTION_UPDATE,
            Auth::user()
        );
        FormEmbedSetting::save($id, $data['embed_settings']);

        if ($action === 'secret' || $action === 'delete_secret') {
            Form::updateLineSetupChecklistItem(
                $id,
                Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_SECRET,
                $action === 'secret'
            );
        }
        if ($action === 'token' || $action === 'delete_token') {
            Form::updateLineSetupChecklistItem(
                $id,
                Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_ACCESS_TOKEN,
                $action === 'token'
            );
        }

        $flashMessages = [
            'secret' => 'Channel secret を保存しました。',
            'delete_secret' => 'Channel secret を削除しました。',
            'token' => 'Channel access token を保存しました。',
            'delete_token' => 'Channel access token を削除しました。',
        ];
        flash('success', $flashMessages[$action] ?? 'LINE 設定を保存しました。');
        redirect('/admin/forms/' . $id . '/edit#mail-line');
    }

    /**
     * @param int $step 2|3
     */
    private function saveLineStep(int $id, int $step): void
    {
        Auth::requireCanManageForm($id);
        $storedForm = Form::find($id);
        if (!$storedForm) {
            $this->notFound();

            return;
        }
        Csrf::verify();

        $_POST['_line_save_step'] = (string) $step;
        $data = $this->collect();
        $presence = $data['mail_input_presence'] ?? [];
        $presence['line_save_step'] = $step;
        $data['form'] = self::mergeStoredMailSettings($data['form'], $storedForm, $presence);
        $data['form'] = self::retainAdminOnlyFields($data['form'], $storedForm);

        $storedEmbedSettings = FormEmbedSetting::forForm($id);
        $errors = self::validateLineStep($data['form'], $storedForm, $step);

        if ($errors !== []) {
            $inputPages = self::prepareInputPagesForEdit($data['input_pages'], $data['form']);
            (new View())->render('admin/forms/detail/index', [
                'title' => 'フォーム編集',
                'form' => self::prepareFormForEdit(self::mergeStoredFormForError($storedForm, $data['form'], $presence)),
                'fields' => $data['fields'],
                'fieldGroups' => $data['field_groups'],
                'inputPages' => $inputPages,
                'branchRules' => $data['branch_rules'],
                'fieldTemplates' => FormFieldTemplate::all(),
                'replyFieldOptions' => self::replyFieldOptions($data['fields'], $data['field_groups'], $inputPages),
                'embedSettings' => self::embedSettingsForView(array_merge($storedEmbedSettings, $data['embed_settings'])),
                'errors' => $errors,
                'isNew' => false,
            ], 'admin');

            return;
        }

        Form::updateWithRelations(
            $id,
            $data['form'],
            $data['input_pages'],
            $data['field_groups'],
            $data['fields'],
            $data['branch_rules'],
            FormVersion::ACTION_UPDATE,
            Auth::user()
        );
        FormEmbedSetting::save($id, $data['embed_settings']);

        $successMessages = [
            2 => '送信先 ID を保存しました。',
            3 => 'LINE 通知設定を保存しました。',
        ];
        flash('success', $successMessages[$step] ?? 'LINE 設定を保存しました。');
        redirect('/admin/forms/' . $id . '/edit#mail-line');
    }

    public function previewInput(): void
    {
        self::requireCanManageFormForPreviewPost();
        Csrf::verify();
        $data = $this->collect();
        $previewForm = self::buildPreviewForm($data['form']);
        $inputPages = self::prepareInputPagesForEdit($data['input_pages'], $previewForm);
        $requestedPageKey = trim((string) ($_POST['preview_input_page_key'] ?? ''));
        $inputPage = $inputPages[0] ?? FormInputPage::defaultPage($previewForm);
        if ($requestedPageKey !== '') {
            foreach ($inputPages as $candidatePage) {
                if ((string) ($candidatePage['page_key'] ?? '') === $requestedPageKey) {
                    $inputPage = $candidatePage;
                    break;
                }
            }
        }
        $previewFields = self::preparePreviewFields($data['fields']);
        $previewFieldGroups = self::preparePreviewFieldGroups($data['field_groups']);
        $branchRules = FormBranchRule::normalizeRules($data['branch_rules'] ?? []);

        (new View())->render('front/form/show', [
            'title' => trim((string) ($inputPage['title'] ?? '')) !== ''
                ? (string) $inputPage['title']
                : '入力画面プレビュー',
            'form' => $previewForm,
            'fields' => $previewFields,
            'fieldGroups' => $previewFieldGroups,
            'inputPages' => $inputPages,
            'inputPage' => $inputPage,
            'inputPageFields' => FormField::forInputPage($previewFields, (string) $inputPage['page_key']),
            'inputPageGroups' => FormFieldGroup::forInputPage($previewFieldGroups, (string) $inputPage['page_key']),
            'branchRules' => $branchRules,
            'branchControlledFieldKeys' => self::branchControlledFieldKeysForPreview($branchRules, (string) $inputPage['page_key']),
            'branchControlledGroupKeys' => self::branchControlledGroupKeysForPreview($branchRules, (string) $inputPage['page_key']),
            'branchVisibleFieldKeys' => [],
            'branchVisibleGroupKeys' => [],
            'values' => [],
            'errors' => [],
            'previewMode' => true,
            'previewInteractive' => true,
        ], 'public');
    }

    public function previewConfirm(): void
    {
        self::requireCanManageFormForPreviewPost();
        Csrf::verify();
        $data = $this->collect();
        $previewForm = self::buildPreviewForm($data['form']);

        (new View())->render('front/form/confirm', [
            'title' => trim((string) ($previewForm['confirm_page_title'] ?? '')) !== ''
                ? (string) $previewForm['confirm_page_title']
                : '確認画面プレビュー',
            'form' => $previewForm,
            'fields' => self::preparePreviewFields($data['fields']),
            'values' => [],
            'fileMetas' => [],
            'previewMode' => true,
        ], 'public');
    }

    public function previewThanks(): void
    {
        self::requireCanManageFormForPreviewPost();
        Csrf::verify();
        $data = $this->collect();
        $previewForm = self::buildPreviewForm($data['form']);

        (new View())->render('front/form/thanks', [
            'title' => trim((string) ($previewForm['thanks_page_title'] ?? '')) !== ''
                ? (string) $previewForm['thanks_page_title']
                : '完了画面プレビュー',
            'form' => $previewForm,
            'previewMode' => true,
        ], 'public');
    }

    public function previewClosed(): void
    {
        self::requireCanManageFormForPreviewPost();
        Csrf::verify();
        $data = $this->collect();
        $previewForm = self::buildPreviewForm($data['form']);

        (new View())->render('front/form/closed', [
            'title' => trim((string) ($previewForm['closed_page_title'] ?? '')) !== ''
                ? (string) $previewForm['closed_page_title']
                : '時間外画面プレビュー',
            'form' => $previewForm,
            'previewMode' => true,
        ], 'public');
    }

    public function versions(int $id): void
    {
        Auth::requireCanManageForms();
        $form = Form::find($id);
        if (!$form) { $this->notFound(); return; }

        (new View())->render('admin/forms/versions/index', [
            'title' => 'バージョン管理',
            'form' => $form,
            'versions' => FormVersion::forForm($id),
        ], 'admin');
    }

    public function restoreVersion(int $id, int $versionId): void
    {
        Auth::requireCanManageForms();
        $form = Form::find($id);
        if (!$form) { $this->notFound(); return; }

        Csrf::verify();
        $version = FormVersion::findForForm($id, $versionId);
        if ($version === null) { $this->notFound(); return; }

        try {
            $snapshot = FormVersion::decodeSnapshot($version);
            Form::updateWithRelations(
                $id,
                self::applyAdminOnlyFieldPolicy($snapshot['form'], $form),
                $snapshot['input_pages'],
                $snapshot['field_groups'],
                $snapshot['fields'],
                $snapshot['branch_rules'],
                FormVersion::ACTION_RESTORE,
                Auth::user()
            );
        } catch (\Throwable $e) {
            flash('danger', '選択したバージョンを復元できませんでした。');
            redirect('/admin/forms/' . $id . '/versions');
        }

        flash('success', 'バージョン #' . (int) ($version['version_number'] ?? 0) . ' を復元しました。');
        redirect('/admin/forms/' . $id . '/versions');
    }

    public function deleteVersion(int $id, int $versionId): void
    {
        Auth::requireCanManageForms();
        $form = Form::find($id);
        if (!$form) { $this->notFound(); return; }

        Csrf::verify();
        $version = FormVersion::findForForm($id, $versionId);
        if ($version === null) { $this->notFound(); return; }

        FormVersion::deleteForForm($id, $versionId);
        flash('success', 'バージョン #' . (int) ($version['version_number'] ?? 0) . ' を削除しました。');
        redirect('/admin/forms/' . $id . '/versions');
    }

    public function toggleVersionPin(int $id, int $versionId): void
    {
        Auth::requireCanManageForms();
        $form = Form::find($id);
        if (!$form) { $this->notFound(); return; }

        Csrf::verify();
        $version = FormVersion::findForForm($id, $versionId);
        if ($version === null) { $this->notFound(); return; }

        $nextPinned = empty($version['pinned']);
        FormVersion::setPinned($id, $versionId, $nextPinned);
        flash('success', $nextPinned ? 'バージョンをピン留めしました。' : 'バージョンのピン留めを解除しました。');
        redirect('/admin/forms/' . $id . '/versions');
    }

    public function destroy(int $id): void
    {
        Auth::requireCanManageForms();
        $form = Form::find($id);
        if (!$form) { $this->notFound(); return; }

        Csrf::verify();
        Form::delete($id);
        flash('success', 'フォームを削除しました。');
        redirect('/admin/forms');
    }

    public function duplicate(int $id): void
    {
        Auth::requireCanManageForms();
        $form = Form::find($id);
        if (!$form) { $this->notFound(); return; }

        Csrf::verify();
        if (Form::count() >= effective_max_forms()) {
            flash('danger', 'フォームの作成上限（' . effective_max_forms() . ' 件）に達しています。設定から上限を変更するか、不要なフォームを削除してください。');
            redirect('/admin/forms');
        }

        $newId = Form::duplicate($id, Auth::user());
        flash('success', 'フォームを複製しました。');
        redirect('/admin/forms/' . $newId . '/edit');
    }

    public function exportFormPage(int $id): void
    {
        Auth::requireCanManageForm($id);
        $form = Form::find($id);
        if (!$form) {
            $this->notFound();
            return;
        }

        $defaults = FormBundleExportOptions::defaults();
        (new View())->render('admin/forms/export', [
            'title' => 'フォームのエクスポート',
            'form' => $form,
            'options' => $defaults,
        ], 'admin');
    }

    public function exportBundle(int $id): void
    {
        Auth::requireCanManageForm($id);
        if (!Form::find($id)) {
            $this->notFound();
            return;
        }
        Csrf::verify();
        $back = '/admin/forms/' . $id . '/export';
        $exportPassword = trim((string) ($_POST['export_password'] ?? ''));
        $exportPasswordConfirm = trim((string) ($_POST['export_password_confirm'] ?? ''));
        if ($exportPassword !== $exportPasswordConfirm) {
            flash('danger', '暗号化パスワードと確認が一致しません。');
            redirect($back);
        }
        try {
            $options = FormBundleExportOptions::fromRequest($_POST);
            FormBundleTransfer::exportForm(
                $id,
                $options,
                $exportPassword !== '' ? $exportPassword : null
            );
        } catch (\InvalidArgumentException $e) {
            flash('danger', $e->getMessage());
            redirect($back);
        } catch (\Throwable $e) {
            error_log('[form-kun] form bundle export failed: ' . $e->getMessage());
            flash('danger', 'フォームをエクスポートできませんでした。');
            redirect($back);
        }
    }

    public function importForm(): void
    {
        Auth::requireCanManageForms();
        (new View())->render('admin/forms/import', [
            'title' => 'フォームのインポート',
            'maxBytes' => max(1, (int) config('submissions.import_max_bytes', 500 * 1024 * 1024)),
        ], 'admin');
    }

    public function importBundle(): void
    {
        Auth::requireCanManageForms();
        Csrf::verify();

        $back = '/admin/forms/import';
        $file = $_FILES['import_file'] ?? null;
        $error = is_array($file) ? (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
            flash('danger', 'ファイルが大きすぎます。サーバーのアップロード上限を確認してください。');
            redirect($back);
        }
        if ($error !== UPLOAD_ERR_OK) {
            flash('danger', 'エクスポートした ZIP ファイルを選択してください。');
            redirect($back);
        }
        $tmp = (string) ($file['tmp_name'] ?? '');
        $size = (int) ($file['size'] ?? 0);
        $maxBytes = max(1, (int) config('submissions.import_max_bytes', 500 * 1024 * 1024));
        if (!preg_match('/\.zip\z/i', (string) ($file['name'] ?? '')) || $tmp === '' || !is_uploaded_file($tmp)) {
            flash('danger', 'ZIP ファイルを選択してください。');
            redirect($back);
        }
        if ($size <= 0 || $size > $maxBytes) {
            flash('danger', 'ZIP ファイルは ' . number_format((int) floor($maxBytes / 1048576)) . 'MB 以下にしてください。');
            redirect($back);
        }

        try {
            $availableSlots = max(0, effective_max_forms() - Form::count());
            $importPassword = trim((string) ($_POST['import_password'] ?? ''));
            $result = FormBundleTransfer::importZip(
                $tmp,
                $availableSlots,
                Auth::user(),
                $importPassword !== '' ? $importPassword : null
            );
            $message = 'フォームを下書きとしてインポートしました。';
            if (!empty($result['secrets_restored'])) {
                $message .= ' SMTP / CAPTCHA シークレットを復元しました（埋め込み API は無効のままです）。';
            }
            if ($result['imported_submissions'] > 0 || $result['skipped_submissions'] > 0 || $result['failed_submissions'] > 0) {
                $message .= ' 送信 ' . number_format($result['imported_submissions']) . ' 件を取り込み';
                if ($result['skipped_submissions'] > 0) {
                    $message .= '（重複 ' . number_format($result['skipped_submissions']) . ' 件はスキップ）';
                }
                if ($result['failed_submissions'] > 0) {
                    $message .= '（' . number_format($result['failed_submissions']) . ' 件は失敗）';
                }
                $message .= '。';
            }
            flash('success', $message);
        } catch (\InvalidArgumentException $e) {
            flash('danger', $e->getMessage());
        } catch (\RuntimeException $e) {
            flash('danger', $e->getMessage());
        } catch (\PDOException $e) {
            flash('danger', $e->getMessage());
        } catch (\Throwable $e) {
            error_log('[form-kun] form bundle import failed: ' . $e->getMessage());
            flash('danger', 'フォームをインポートできませんでした。');
        }
        redirect('/admin/forms');
    }

    /**
     * POST から form / fields を組み立てる。
     */
    private function collect(): array
    {
        $builderPayload = self::collectBuilderPayload($_POST);
        $form = [
            'slug'                 => trim((string) ($_POST['slug'] ?? '')),
            'title'                => trim((string) ($_POST['title'] ?? '')),
            'meta_html'            => trim((string) ($_POST['meta_html'] ?? '')),
            'custom_css'           => trim((string) ($_POST['custom_css'] ?? '')),
            'custom_js'            => trim((string) ($_POST['custom_js'] ?? '')),
            'header_html'          => sanitize_rich_text_html((string) ($_POST['header_html'] ?? '')),
            'footer_html'          => sanitize_rich_text_html((string) ($_POST['footer_html'] ?? '')),
            'input_page_title'     => trim((string) ($_POST['input_page_title'] ?? '')),
            'show_input_page_title'=> !empty($_POST['show_input_page_title']) ? 1 : 0,
            'description'          => null,
            'show_title'           => 0,
            'show_description'     => 0,
            'confirm_page_title'   => trim((string) ($_POST['confirm_page_title'] ?? '')),
            'show_confirm_page_title' => !empty($_POST['show_confirm_page_title']) ? 1 : 0,
            'confirm_button_text'  => trim((string) ($_POST['confirm_button_text'] ?? '')),
            'submit_button_text'   => trim((string) ($_POST['submit_button_text'] ?? '')),
            'back_button_text'     => trim((string) ($_POST['back_button_text'] ?? '')),
            'confirm_message'      => null,
            'thanks_page_title'    => trim((string) ($_POST['thanks_page_title'] ?? '')),
            'show_thanks_page_title' => !empty($_POST['show_thanks_page_title']) ? 1 : 0,
            'thanks_message'       => null,
            'thanks_button_text'   => trim((string) ($_POST['thanks_button_text'] ?? '')),
            'thanks_button_url'    => trim((string) ($_POST['thanks_button_url'] ?? '')),
            'admin_emails'         => trim((string) ($_POST['admin_emails'] ?? '')),
            'mail_subject_admin'   => trim((string) ($_POST['mail_subject_admin'] ?? '')),
            'mail_template_admin'  => (string) ($_POST['mail_template_admin'] ?? ''),
            'mail_transport'       => in_array($_POST['mail_transport'] ?? '', ['mail', 'smtp'], true) ? (string) $_POST['mail_transport'] : 'mail',
            'mail_from_email'      => trim((string) ($_POST['mail_from_email'] ?? '')),
            'mail_from_name'       => trim((string) ($_POST['mail_from_name'] ?? '')),
            'mail_smtp_host'       => trim((string) ($_POST['mail_smtp_host'] ?? '')),
            'mail_smtp_port'       => trim((string) ($_POST['mail_smtp_port'] ?? '')),
            'mail_smtp_secure'     => (string) ($_POST['mail_smtp_secure'] ?? ''),
            'mail_smtp_username'   => trim((string) ($_POST['mail_smtp_username'] ?? '')),
            'mail_smtp_password'   => (string) ($_POST['mail_smtp_password'] ?? ''),
            'mail_smtp_timeout'    => trim((string) ($_POST['mail_smtp_timeout'] ?? '')),
            'mail_smtp_ehlo_host'  => trim((string) ($_POST['mail_smtp_ehlo_host'] ?? '')),
            'mail_smtp_verify_peer' => !empty($_POST['mail_smtp_verify_peer']) ? 1 : 0,
            'mail_smtp_verify_peer_name' => !empty($_POST['mail_smtp_verify_peer_name']) ? 1 : 0,
            'mail_smtp_allow_self_signed' => !empty($_POST['mail_smtp_allow_self_signed']) ? 1 : 0,
            'mail_smtp_clear_password' => !empty($_POST['mail_smtp_clear_password']) ? 1 : 0,
            'submission_storage_mode' => in_array($_POST['submission_storage_mode'] ?? '', [Form::STORAGE_DATABASE, Form::STORAGE_MAIL_ONLY], true)
                ? (string) $_POST['submission_storage_mode'] : Form::STORAGE_DATABASE,
            'mail_attachment_max_bytes' => max(1, min(25, (int) ($_POST['mail_attachment_max_mb'] ?? 10))) * 1024 * 1024,
            'submission_retention_days' => trim((string) ($_POST['submission_retention_days'] ?? (string) Form::DEFAULT_RETENTION_DAYS)),
            'submission_retention_action' => Form::normalizeRetentionAction($_POST['submission_retention_action'] ?? ''),
            'submission_retention_enabled' => (string) ($_POST['submission_retention_enabled'] ?? '1') === '0' ? 0 : 1,
            'smtp_tested_at' => null,
            'smtp_test_fingerprint' => null,
            'reply_enabled'        => !empty($_POST['reply_enabled']) ? 1 : 0,
            'reply_from_field_key' => Form::encodeReplyFieldKeys(self::collectReplyFieldKeys($_POST['reply_from_field_key'] ?? [])),
            'reply_subject'        => trim((string) ($_POST['reply_subject'] ?? '')),
            'reply_template'       => (string) ($_POST['reply_template'] ?? ''),
            'line_notify_enabled'  => !empty($_POST['line_notify_enabled']) ? 1 : 0,
            'line_push_to_id'      => trim((string) ($_POST['line_push_to_id'] ?? '')),
            'line_channel_access_token' => (string) ($_POST['line_channel_access_token'] ?? ''),
            'line_channel_secret'  => (string) ($_POST['line_channel_secret'] ?? ''),
            'line_message_template' => (string) ($_POST['line_message_template'] ?? ''),
            'status'               => in_array($_POST['status'] ?? '', ['active', 'draft', 'hidden', 'archived'], true) ? $_POST['status'] : 'draft',
            'publish_schedule_enabled' => 0,
            'closed_page_title'    => trim((string) ($_POST['closed_page_title'] ?? '')),
            'show_closed_page_title' => !empty($_POST['show_closed_page_title']) ? 1 : 0,
            'closed_message'       => null,
            'closed_button_text'   => trim((string) ($_POST['closed_button_text'] ?? '')),
            'closed_button_url'    => trim((string) ($_POST['closed_button_url'] ?? '')),
        ];
        if ($form['confirm_button_text'] === '') {
            $form['confirm_button_text'] = '入力内容を確認する';
        }
        if ($form['input_page_title'] === '') {
            $form['input_page_title'] = $form['title'];
        }
        if (!isset($form['show_input_page_title'])) {
            $form['show_input_page_title'] = 1;
        }
        if ($form['confirm_page_title'] === '') {
            $form['confirm_page_title'] = '入力内容のご確認';
        }
        if (!isset($form['show_confirm_page_title'])) {
            $form['show_confirm_page_title'] = 1;
        }
        if ($form['submit_button_text'] === '') {
            $form['submit_button_text'] = '送信する';
        }
        if ($form['back_button_text'] === '') {
            $form['back_button_text'] = '入力に戻る';
        }
        if ($form['thanks_page_title'] === '') {
            $form['thanks_page_title'] = '送信が完了しました';
        }
        if (!isset($form['show_thanks_page_title'])) {
            $form['show_thanks_page_title'] = 1;
        }
        if ($form['thanks_button_text'] === '') {
            $form['thanks_button_text'] = 'トップへ戻る';
        }
        if ($form['thanks_button_url'] === '') {
            $form['thanks_button_url'] = '/';
        }
        if ($form['closed_page_title'] === '') {
            $form['closed_page_title'] = '現在、フォームをご利用いただけません';
        }
        if (!isset($form['show_closed_page_title'])) {
            $form['show_closed_page_title'] = 1;
        }
        if ($form['closed_button_text'] === '') {
            $form['closed_button_text'] = 'トップへ戻る';
        }
        if ($form['closed_button_url'] === '') {
            $form['closed_button_url'] = '/';
        }
        if ($form['mail_smtp_port'] === '') {
            $form['mail_smtp_port'] = '25';
        }
        if ($form['mail_smtp_timeout'] === '') {
            $form['mail_smtp_timeout'] = '10';
        }

        $descriptionBlocks = self::collectContentBlocks('description_blocks', 'description');
        $form['description'] = encode_form_description_blocks($descriptionBlocks);
        $form['show_description'] = self::hasVisibleContentBlocks($descriptionBlocks) ? 1 : 0;
        $form['description_blocks'] = self::normalizeDescriptionBlocks($descriptionBlocks, true, 'description');
        $confirmBlocks = self::collectContentBlocks('confirm_blocks', 'confirm');
        $form['confirm_message'] = encode_form_description_blocks($confirmBlocks);
        $form['confirm_blocks'] = self::normalizeDescriptionBlocks($confirmBlocks, true, 'confirm');
        $thanksBlocks = self::collectContentBlocks('thanks_blocks', 'thanks');
        $form['thanks_message'] = encode_form_description_blocks($thanksBlocks);
        $form['thanks_blocks'] = self::normalizeDescriptionBlocks($thanksBlocks, true, 'thanks');
        $publishRules = self::collectScheduleRules($_POST['publish_rules'] ?? [], 'publish');
        $form['publish_rules'] = encode_form_publish_rules($publishRules);
        $form['publish_rules_list'] = normalize_form_publish_rules($publishRules);
        $unpublishRules = self::collectScheduleRules($_POST['unpublish_rules'] ?? [], 'unpublish');
        $form['unpublish_rules'] = encode_form_unpublish_rules($unpublishRules);
        $form['unpublish_rules_list'] = normalize_form_unpublish_rules($unpublishRules);
        $form['publish_schedule_enabled'] = self::hasActivePublishSchedule($publishRules) || self::hasActivePublishSchedule($unpublishRules) ? 1 : 0;
        $closedBlocks = self::collectContentBlocks('closed_blocks', 'closed');
        $form['closed_message'] = encode_form_description_blocks($closedBlocks);
        $form['closed_blocks'] = self::normalizeDescriptionBlocks($closedBlocks, true, 'closed');

        $inputPages = $this->collectInputPages($form, $builderPayload['input_pages'] ?? null);
        $firstPage = $inputPages[0] ?? FormInputPage::defaultPage($form);
        $form['input_page_title'] = (string) ($firstPage['title'] ?? $form['input_page_title']);
        $form['show_input_page_title'] = !empty($firstPage['show_title']) ? 1 : 0;
        $form['description'] = $firstPage['description'] ?? $form['description'];
        $firstDescriptionBlocks = decode_form_description_blocks($form['description']);
        $form['show_description'] = self::hasVisibleContentBlocks($firstDescriptionBlocks) ? 1 : 0;
        $form['description_blocks'] = self::normalizeDescriptionBlocks($firstDescriptionBlocks, true, 'description');
        $form['confirm_button_text'] = (string) ($firstPage['button_text'] ?? $form['confirm_button_text']);

        $fields = [];
        $raw = $builderPayload['fields'] ?? ($_POST['fields'] ?? []);
        if (is_array($raw)) {
            foreach ($raw as $f) {
                if (!is_array($f)) continue;
                if (!empty($f['_remove'])) continue;
                $key = trim((string) ($f['field_key'] ?? ''));
                if ($key === '') {
                    $key = FieldKey::generateUuidV4();
                }

                $required = !empty($f['required']) ? 1 : 0;
                $type = FormField::sanitizeType((string) ($f['type'] ?? 'text_multi'));
                $isDisplayOnly = FormField::isDisplayOnlyType($type);
                $patterns = [];
                $singleRx = trim((string) ($f['regex_pattern'] ?? ''));
                if ($singleRx !== '' && $singleRx !== '__custom__') {
                    $patterns[] = $singleRx;
                }
                $regexStored = FormField::encodeRegexPatterns($patterns);
                if ($required !== 1 || $isDisplayOnly || in_array($type, ['radio', 'select', 'file', FormField::TYPE_MATRIX], true)) {
                    $regexStored = null;
                } elseif ($type === 'checkbox' && $singleRx !== '' && $singleRx !== '__custom__') {
                    $regexStored = null;
                }

                $placeholder = trim((string) ($f['placeholder'] ?? ''));
                if ($isDisplayOnly || in_array($type, ['radio', 'checkbox', 'select', 'text_multi', 'file', FormField::TYPE_MATRIX], true)) {
                    $placeholder = '';
                }
                $lengthLimitMode = (string) ($f['length_limit_mode'] ?? '');
                $minLength = isset($f['min_length']) && $f['min_length'] !== '' ? (int) $f['min_length'] : '';
                $maxLength = isset($f['max_length']) && $f['max_length'] !== '' ? (int) $f['max_length'] : '';
                $exactLength = isset($f['exact_length']) && $f['exact_length'] !== '' ? (int) $f['exact_length'] : '';
                if ($isDisplayOnly || in_array($type, ['radio', 'checkbox', 'select', 'file', FormField::TYPE_MATRIX], true)) {
                    $minLength = '';
                    $maxLength = '';
                    $exactLength = '';
                } elseif ($lengthLimitMode === 'exact' && $exactLength !== '') {
                    $minLength = '';
                    $maxLength = '';
                } elseif ($lengthLimitMode === 'range') {
                    $exactLength = '';
                    if ($minLength !== '' && $maxLength !== '' && $minLength > $maxLength) {
                        $minLength = $maxLength;
                    }
                } else {
                    $minLength = '';
                    $maxLength = '';
                    $exactLength = '';
                }
                if ($isDisplayOnly) {
                    $required = 0;
                }
                $checkboxLimitEnabled = ($type === 'checkbox' && $required === 1 && !empty($f['checkbox_limit_enabled'])) ? 1 : 0;
                $checkboxMinSelections = ($checkboxLimitEnabled && isset($f['checkbox_min_selections']) && $f['checkbox_min_selections'] !== '')
                    ? (int) $f['checkbox_min_selections']
                    : '';
                $checkboxMaxSelections = ($checkboxLimitEnabled && isset($f['checkbox_max_selections']) && $f['checkbox_max_selections'] !== '')
                    ? (int) $f['checkbox_max_selections']
                    : '';
                $fileTypeMode = $type === 'file'
                    ? FormField::normalizeFileSelectionMode((string) ($f['file_type_mode'] ?? FormField::FILE_SELECTION_CUSTOM))
                    : FormField::FILE_SELECTION_CUSTOM;
                $fileConvertToJpeg = ($type === 'file' && $fileTypeMode === FormField::FILE_SELECTION_IMAGE) ? 1 : 0;
                $helpTextRaw = trim((string) ($f['help_text'] ?? ''));
                $helpTextIsHtml = $type !== FormField::TYPE_HEADING && !empty($f['help_text_is_html']);
                $helpText = $helpTextIsHtml ? sanitize_rich_text_html($helpTextRaw) : $helpTextRaw;
                if ($isDisplayOnly && !in_array($type, [FormField::TYPE_HEADING, FormField::TYPE_DESCRIPTION], true)) {
                    $helpText = '';
                }

                $fields[] = [
                    'input_page_key'   => FormField::sanitizeInputPageKey((string) ($f['input_page_key'] ?? FormInputPage::DEFAULT_KEY)),
                    'parent_group_key' => FormFieldGroup::sanitizeGroupKey((string) ($f['parent_group_key'] ?? '')) ?: null,
                    'sort_order'       => isset($f['sort_order']) && is_numeric($f['sort_order']) ? (int) $f['sort_order'] : count($fields) + 1,
                    'field_key'       => $key,
                    'label'           => trim((string) ($f['label'] ?? '')),
                    'show_label'      => !empty($f['show_label']) ? 1 : 0,
                    'visible'         => !empty($f['visible']) ? 1 : 0,
                    'type'            => $type,
                    'required'        => $required,
                    'min_length'      => $minLength,
                    'max_length'      => $maxLength,
                    'exact_length'    => $exactLength,
                    'regex'           => $regexStored,
                    'help_text'       => $helpText,
                    'placeholder'     => $placeholder,
                    'pair_label_left' => trim((string) ($f['pair_label_left'] ?? '')),
                    'pair_label_right'=> trim((string) ($f['pair_label_right'] ?? '')),
                    'pair_placeholder_left' => trim((string) ($f['pair_placeholder_left'] ?? '')),
                    'pair_placeholder_right'=> trim((string) ($f['pair_placeholder_right'] ?? '')),
                    'multi_text_items' => (string) ($f['multi_text_items'] ?? ''),
                    'text_multi_meta' => '',
                    'postal_target_prefecture' => trim((string) ($f['postal_target_prefecture'] ?? '')),
                    'postal_target_city' => trim((string) ($f['postal_target_city'] ?? '')),
                    'default_value' => (string) ($f['default_value'] ?? ''),
                    'date_default_mode' => (string) ($f['date_default_mode'] ?? ''),
                    'date_default_value' => (string) ($f['date_default_value'] ?? ''),
                    'time_default_mode' => (string) ($f['time_default_mode'] ?? ''),
                    'time_default_value' => (string) ($f['time_default_value'] ?? ''),
                    'radio_default_value' => (string) ($f['radio_default_value'] ?? ''),
                    'checkbox_limit_enabled' => $checkboxLimitEnabled,
                    'checkbox_min_selections' => $checkboxMinSelections,
                    'checkbox_max_selections' => $checkboxMaxSelections,
                    'options'         => (string) ($f['options'] ?? ''),
                    'file_allowed_extensions' => (string) ($f['file_allowed_extensions'] ?? ''),
                    'file_type_mode' => $fileTypeMode,
                    'file_convert_to_jpeg' => $fileConvertToJpeg,
                    'matrix_rows' => (string) ($f['matrix_rows'] ?? ''),
                    'matrix_columns' => (string) ($f['matrix_columns'] ?? ''),
                    'matrix_selection_type' => (string) ($f['matrix_selection_type'] ?? 'radio'),
                ];
            }
        }
        $fieldGroups = [];
        $rawGroups = $builderPayload['field_groups'] ?? ($_POST['field_groups'] ?? []);
        if (is_array($rawGroups)) {
            foreach ($rawGroups as $i => $group) {
                if (!is_array($group) || !empty($group['_remove'])) {
                    continue;
                }
                $groupKey = FormFieldGroup::sanitizeGroupKey((string) ($group['group_key'] ?? ''));
                if ($groupKey === '') {
                    $groupKey = FieldKey::generateUuidV4();
                }
                $parentGroupKey = FormFieldGroup::sanitizeGroupKey((string) ($group['parent_group_key'] ?? ''));
                if ($parentGroupKey === $groupKey) {
                    $parentGroupKey = '';
                }
                $fieldGroups[] = [
                    'input_page_key' => FormField::sanitizeInputPageKey((string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY)),
                    'parent_group_key' => $parentGroupKey !== '' ? $parentGroupKey : null,
                    'sort_order' => isset($group['sort_order']) && is_numeric($group['sort_order']) ? (int) $group['sort_order'] : (int) $i + 1,
                    'group_key' => $groupKey,
                    'label' => trim((string) ($group['label'] ?? '')),
                    'show_label' => !empty($group['show_label']) ? 1 : 0,
                    'description' => trim((string) ($group['description'] ?? '')),
                    'visible' => !array_key_exists('visible', $group) || !empty($group['visible']) ? 1 : 0,
                ];
            }
        }
        $data = [
            'form' => $form,
            'fields' => $fields,
            'field_groups' => $fieldGroups,
            'input_pages' => $inputPages,
            'branch_rules' => $this->collectBranchRules($builderPayload['branch_rules'] ?? null),
            'builder_meta' => self::collectBuilderMeta($_POST),
            'builder_payload_errors' => $builderPayload['errors'] ?? [],
            'builder_payload_present' => !empty($builderPayload['present']),
            'mail_input_presence' => self::collectMailInputPresence($_POST),
            'embed_settings' => self::collectEmbedSettings($_POST),
        ];
        $embedEnabled = !empty($_POST['embed_enabled']);
        $hidePublicPage = !empty($_POST['embed_public_page_hidden']);
        if ($embedEnabled && $hidePublicPage) {
            $data['form']['status'] = 'hidden';
        } elseif (($data['form']['status'] ?? '') === 'hidden') {
            $data['form']['status'] = 'draft';
        }
        $data['embed_settings']['public_page_hidden'] = ($data['form']['status'] ?? '') === 'hidden' ? 1 : 0;

        return $data;
    }

    /**
     * 外部埋め込み OFF 時は POST の詳細設定を使わず enabled=0 のみ反映する。
     *
     * @param array<string, mixed> $data
     * @param array<string, mixed>|null $storedEmbedSettings
     * @return array<string, mixed>
     */
    private static function applyEmbedSettingsWhenDisabled(array $data, ?array $storedEmbedSettings): array
    {
        if (!empty($data['embed_settings']['enabled'])) {
            return $data;
        }
        if (is_array($storedEmbedSettings) && $storedEmbedSettings !== []) {
            $data['embed_settings'] = array_merge($storedEmbedSettings, [
                'enabled' => 0,
                'public_page_hidden' => 0,
            ]);
        } else {
            $data['embed_settings'] = array_merge(
                FormEmbedSetting::defaults(0),
                ['enabled' => 0, 'public_page_hidden' => 0]
            );
        }

        return $data;
    }

    /** @param array<string, mixed> $post @return array<string, mixed> */
    private static function collectEmbedSettings(array $post): array
    {
        $rawOrigins = $post['embed_allowed_origins'] ?? '';
        $originInput = is_array($rawOrigins)
            ? implode("\n", array_values(array_filter(
                array_map(static fn($value): string => is_scalar($value) ? trim((string) $value) : '', $rawOrigins),
                static fn(string $value): bool => $value !== ''
            )))
            : trim((string) $rawOrigins);
        $captchaProvider = trim((string) ($post['embed_captcha_provider'] ?? ''));
        $allowedProviders = [
            FormEmbedSetting::CAPTCHA_NONE,
            FormEmbedSetting::CAPTCHA_TURNSTILE,
            FormEmbedSetting::CAPTCHA_RECAPTCHA_V2,
            FormEmbedSetting::CAPTCHA_RECAPTCHA_V3,
        ];
        if (!in_array($captchaProvider, $allowedProviders, true)) {
            if (!empty($post['embed_turnstile_enabled'])) {
                $captchaProvider = FormEmbedSetting::CAPTCHA_TURNSTILE;
            } elseif (!empty($post['embed_recaptcha_enabled'])) {
                $captchaProvider = FormEmbedSetting::CAPTCHA_RECAPTCHA_V2;
            } else {
                $captchaProvider = FormEmbedSetting::CAPTCHA_NONE;
            }
        }
        $japanProvider = trim((string) ($post['embed_japan_only_provider'] ?? ''));
        $allowedJapanProviders = [
            FormEmbedSetting::JAPAN_PROVIDER_NONE,
            FormEmbedSetting::JAPAN_PROVIDER_IPINFO_LITE,
        ];
        if (!in_array($japanProvider, $allowedJapanProviders, true)) {
            $japanProvider = !empty($post['embed_japan_only_enabled'])
                ? FormEmbedSetting::JAPAN_PROVIDER_IPINFO_LITE
                : FormEmbedSetting::JAPAN_PROVIDER_NONE;
        }
        return [
            'enabled' => !empty($post['embed_enabled']) ? 1 : 0,
            'public_page_hidden' => !empty($post['embed_public_page_hidden']) ? 1 : 0,
            'allowed_origins_input' => $originInput,
            'allowed_origins' => FormEmbedSetting::normalizeOrigins($originInput),
            'completion_url' => trim((string) ($post['embed_completion_url'] ?? '')),
            'japan_only_provider' => $japanProvider,
            'japan_only_enabled' => $japanProvider === FormEmbedSetting::JAPAN_PROVIDER_IPINFO_LITE ? 1 : 0,
            'ipinfo_lite_token' => (string) ($post['embed_ipinfo_lite_token'] ?? ''),
            'ipinfo_lite_token_clear' => !empty($post['embed_ipinfo_lite_token_clear']) ? 1 : 0,
            'ipinfo_lite_token_configured' => 0,
            'captcha_provider' => $captchaProvider,
            'turnstile_enabled' => $captchaProvider === FormEmbedSetting::CAPTCHA_TURNSTILE ? 1 : 0,
            'turnstile_site_key' => trim((string) ($post['embed_turnstile_site_key'] ?? '')),
            'turnstile_secret_key' => (string) ($post['embed_turnstile_secret_key'] ?? ''),
            'turnstile_secret_clear' => !empty($post['embed_turnstile_secret_clear']) ? 1 : 0,
            'turnstile_secret_configured' => 0,
            'recaptcha_enabled' => $captchaProvider === FormEmbedSetting::CAPTCHA_RECAPTCHA_V2 ? 1 : 0,
            'recaptcha_site_key' => trim((string) ($post['embed_recaptcha_site_key'] ?? '')),
            'recaptcha_secret_key' => (string) ($post['embed_recaptcha_secret_key'] ?? ''),
            'recaptcha_secret_clear' => !empty($post['embed_recaptcha_secret_clear']) ? 1 : 0,
            'recaptcha_secret_configured' => 0,
            'recaptcha_v3_enabled' => $captchaProvider === FormEmbedSetting::CAPTCHA_RECAPTCHA_V3 ? 1 : 0,
            'recaptcha_v3_site_key' => trim((string) ($post['embed_recaptcha_v3_site_key'] ?? '')),
            'recaptcha_v3_secret_key' => (string) ($post['embed_recaptcha_v3_secret_key'] ?? ''),
            'recaptcha_v3_secret_clear' => !empty($post['embed_recaptcha_v3_secret_clear']) ? 1 : 0,
            'recaptcha_v3_secret_configured' => 0,
            'recaptcha_v3_min_score' => trim((string) ($post['embed_recaptcha_v3_min_score'] ?? FormEmbedSetting::DEFAULT_RECAPTCHA_V3_MIN_SCORE)),
            'rate_limit_count' => trim((string) ($post['embed_rate_limit_count'] ?? FormEmbedSetting::DEFAULT_RATE_LIMIT_COUNT)),
            'rate_limit_window_seconds' => trim((string) ($post['embed_rate_limit_window_seconds'] ?? FormEmbedSetting::DEFAULT_RATE_LIMIT_WINDOW_SECONDS)),
        ];
    }

    /** @param array<string, mixed> $settings @return array<string, mixed> */
    private static function embedSettingsForView(array $settings): array
    {
        $settings['allowed_origins_input'] = (string) ($settings['allowed_origins_input'] ?? implode("\n", (array) ($settings['allowed_origins'] ?? [])));
        $settings['turnstile_secret_configured'] = !empty($settings['turnstile_secret_configured']) ? 1 : 0;
        $settings['turnstile_secret_key'] = '';
        $settings['recaptcha_secret_configured'] = !empty($settings['recaptcha_secret_configured']) ? 1 : 0;
        $settings['recaptcha_secret_key'] = '';
        $settings['recaptcha_v3_secret_configured'] = !empty($settings['recaptcha_v3_secret_configured']) ? 1 : 0;
        $settings['recaptcha_v3_secret_key'] = '';
        $settings['ipinfo_lite_token_configured'] = !empty($settings['ipinfo_lite_token_configured']) ? 1 : 0;
        $settings['ipinfo_lite_token'] = '';
        $settings['captcha_provider'] = FormEmbedSetting::captchaProvider($settings);
        $settings['japan_only_provider'] = FormEmbedSetting::japanOnlyProvider($settings);
        return $settings;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function collectBranchRules(?array $providedRules = null): array
    {
        $rawRules = $providedRules ?? ($_POST['branch_rules'] ?? []);
        $rules = [];
        if (!is_array($rawRules)) {
            return [];
        }
        foreach ($rawRules as $i => $rule) {
            if (!is_array($rule) || !empty($rule['_remove'])) {
                continue;
            }
            $ruleKey = FormBranchRule::sanitizeRuleKey((string) ($rule['rule_key'] ?? ''));
            if ($ruleKey === '') {
                $ruleKey = 'branch-' . ((int) $i + 1);
            }
            $rules[] = [
                'rule_key' => $ruleKey,
                'sort_order' => count($rules) + 1,
                'trigger_page_key' => FormInputPage::sanitizePageKey((string) ($rule['trigger_page_key'] ?? FormInputPage::DEFAULT_KEY)),
                'source_field_key' => trim((string) ($rule['source_field_key'] ?? '')),
                'operator' => FormBranchRule::OP_EQUALS,
                'expected_value' => trim((string) ($rule['expected_value'] ?? '')),
                'action_type' => FormBranchRule::sanitizeActionType((string) ($rule['action_type'] ?? '')),
                'target_type' => FormBranchRule::sanitizeTargetType((string) ($rule['target_type'] ?? FormBranchRule::TARGET_FIELD)),
                'target_key' => trim((string) ($rule['target_key'] ?? '')),
                'enabled' => !array_key_exists('enabled', $rule) || !empty($rule['enabled']) ? 1 : 0,
            ];
        }
        return FormBranchRule::normalizeRules($rules);
    }

    /**
     * @param array<string, mixed> $form
     * @return array<int, array<string, mixed>>
     */
    private function collectInputPages(array $form, ?array $providedPages = null): array
    {
        $rawPages = $providedPages ?? ($_POST['input_pages'] ?? []);
        $pages = [];
        if (is_array($rawPages)) {
            foreach ($rawPages as $i => $page) {
                if (!is_array($page)) {
                    continue;
                }
                $pageKey = FormInputPage::sanitizePageKey((string) ($page['page_key'] ?? ''));
                if ($pageKey === '') {
                    $pageKey = 'input-' . ((int) $i + 1);
                }
                $descriptionBlocks = self::collectContentBlocks(
                    'description_blocks',
                    'description',
                    is_array($page['description_blocks'] ?? null) ? $page['description_blocks'] : []
                );
                $title = trim((string) ($page['title'] ?? ''));
                if ($title === '') {
                    $title = '入力画面 ' . ((int) $i + 1);
                }
                $buttonText = trim((string) ($page['button_text'] ?? ''));
                if ($buttonText === '') {
                    $buttonText = '次へ';
                }
                $backButtonText = trim((string) ($page['back_button_text'] ?? ''));
                if ($backButtonText === '') {
                    $backButtonText = '戻る';
                }
                $pages[] = [
                    'page_key' => $pageKey,
                    'sort_order' => count($pages) + 1,
                    'title' => $title,
                    'show_title' => !empty($page['show_title']) ? 1 : 0,
                    'description' => encode_form_description_blocks($descriptionBlocks),
                    'description_blocks' => self::normalizeDescriptionBlocks($descriptionBlocks, true, 'description'),
                    'button_text' => $buttonText,
                    'back_button_text' => $backButtonText,
                ];
            }
        }

        if ($pages === []) {
            $pages[] = [
                'page_key' => FormInputPage::DEFAULT_KEY,
                'sort_order' => 1,
                'title' => $form['input_page_title'],
                'show_title' => $form['show_input_page_title'],
                'description' => $form['description'],
                'description_blocks' => $form['description_blocks'],
                'button_text' => $form['confirm_button_text'],
                'back_button_text' => '戻る',
            ];
        }

        return FormInputPage::normalizePages($pages, $form);
    }

    private function validate(array $data, ?int $excludeId): array
    {
        $errors = [];
        $form = $data['form'];
        $fields = $data['fields'];
        $fieldGroups = $data['field_groups'] ?? [];
        $inputPages = $data['input_pages'] ?? [];
        $branchRules = $data['branch_rules'] ?? [];
        $embedSettings = $data['embed_settings'] ?? FormEmbedSetting::defaults($excludeId ?? 0);
        $builderMeta = $data['builder_meta'] ?? [];
        foreach (($data['builder_payload_errors'] ?? []) as $builderPayloadError) {
            $errors[] = (string) $builderPayloadError;
        }
        if (empty($data['builder_payload_present']) || !empty($data['builder_payload_errors'])) {
            self::appendBuilderMetaErrors($errors, $builderMeta, $fields, $fieldGroups, $inputPages, $branchRules);
        }

        if ($form['title'] === '') {
            $errors[] = 'タイトルは必須です。';
        }
        $retentionDays = (string) ($form['submission_retention_days'] ?? '');
        if (Form::retentionEnabled($form)
            && (preg_match('/\A[0-9]{1,4}\z/', $retentionDays) !== 1 || (int) $retentionDays < Form::MIN_RETENTION_DAYS || (int) $retentionDays > Form::MAX_RETENTION_DAYS)) {
            $errors[] = '受信履歴の保存期間は ' . Form::MIN_RETENTION_DAYS . '〜' . Form::MAX_RETENTION_DAYS . ' 日の整数で指定してください。';
        }
        if (mb_strlen($form['meta_html']) > 65535) {
            $errors[] = 'meta情報HTMLは65535文字以内にしてください。';
        }
        if (mb_strlen($form['custom_css']) > 65535) {
            $errors[] = 'CSSは65535文字以内にしてください。';
        }
        if (mb_strlen($form['custom_js']) > 65535) {
            $errors[] = 'JavaScriptは65535文字以内にしてください。';
        }
        if (mb_strlen((string) ($form['header_html'] ?? '')) > 65535) {
            $errors[] = '共通ヘッダーHTMLは65535文字以内にしてください。';
        }
        if (mb_strlen((string) ($form['footer_html'] ?? '')) > 65535) {
            $errors[] = '共通フッターHTMLは65535文字以内にしてください。';
        }
        if (mb_strlen($form['input_page_title']) > 200) {
            $errors[] = '入力画面のタイトルは200文字以内にしてください。';
        }
        if (mb_strlen($form['confirm_page_title']) > 200) {
            $errors[] = '確認画面のタイトルは200文字以内にしてください。';
        }
        if (!preg_match('/\A[a-zA-Z0-9_\-]{1,64}\z/', $form['slug'])) {
            $errors[] = 'スラッグは半角英数字・ハイフン・アンダースコアで64文字以内にしてください。';
        } elseif (!Form::isSlugAvailable($form['slug'], $excludeId)) {
            $errors[] = '同じスラッグが既に使われています。';
        }
        if (mb_strlen($form['confirm_button_text']) > 200) {
            $errors[] = 'ボタンテキストは200文字以内にしてください。';
        }
        if (mb_strlen($form['submit_button_text']) > 200) {
            $errors[] = '確認画面の送信ボタンテキストは200文字以内にしてください。';
        }
        if (mb_strlen($form['back_button_text']) > 200) {
            $errors[] = '確認画面の戻るボタンテキストは200文字以内にしてください。';
        }
        if (mb_strlen($form['thanks_button_text']) > 200) {
            $errors[] = '完了画面のボタンテキストは200文字以内にしてください。';
        }
        if (mb_strlen($form['thanks_page_title']) > 200) {
            $errors[] = '完了画面のタイトルは200文字以内にしてください。';
        }
        if (mb_strlen($form['thanks_button_url']) > 500) {
            $errors[] = '完了画面のボタンURLは500文字以内にしてください。';
        }
        if ($form['admin_emails'] !== '') {
            foreach (preg_split('/[,;]+/', $form['admin_emails']) as $em) {
                $em = trim($em);
                if ($em === '') continue;
                if (!filter_var($em, FILTER_VALIDATE_EMAIL)) {
                    $errors[] = '管理者通知メールアドレスに不正な形式があります: ' . $em;
                }
            }
        }
        if (!is_form_button_url($form['thanks_button_url'])) {
            $errors[] = '完了画面のボタンURLは http:// / https:// で始まるURL、または / から始まるパスを指定してください。';
        }
        if (mb_strlen((string) ($form['closed_page_title'] ?? '')) > 200) {
            $errors[] = '時間外画面のタイトルは200文字以内にしてください。';
        }
        if (mb_strlen((string) ($form['closed_button_text'] ?? '')) > 200) {
            $errors[] = '時間外画面のボタンテキストは200文字以内にしてください。';
        }
        if (mb_strlen((string) ($form['closed_button_url'] ?? '')) > 500) {
            $errors[] = '時間外画面のボタンURLは500文字以内にしてください。';
        }
        if (!is_form_button_url((string) ($form['closed_button_url'] ?? ''))) {
            $errors[] = '時間外画面のボタンURLは http:// / https:// で始まるURL、または / から始まるパスを指定してください。';
        }
        $publishRules = $form['publish_rules_list'] ?? decode_form_publish_rules($form['publish_rules'] ?? null);
        self::validateScheduleRules($publishRules, '公開条件', $errors);
        $unpublishRules = $form['unpublish_rules_list'] ?? decode_form_unpublish_rules($form['unpublish_rules'] ?? null);
        self::validateScheduleRules($unpublishRules, '非公開条件', $errors);
        if ($form['mail_from_email'] === '' || !filter_var($form['mail_from_email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = '通知設定の差出人メールアドレスは有効なメールアドレスを入力してください。';
        }
        if (!in_array($form['mail_transport'], ['mail', 'smtp'], true)) {
            $errors[] = '通知設定の送信方式が不正です。';
        }
        if (Form::isMailOnly($form)) {
            if ($form['mail_transport'] !== 'smtp') {
                $errors[] = 'メール送信のみモードではSMTPを選択してください。';
            }
            if (trim((string) $form['admin_emails']) === '') {
                $errors[] = 'メール送信のみモードでは管理者通知先が必須です。';
            }
            if ($excludeId === null) {
                $errors[] = 'メール送信のみモードはフォーム作成後にSMTPテストを行ってから有効にしてください。';
            } elseif (!Form::smtpTestIsCurrent($form)) {
                $errors[] = '現在のSMTP設定でテストメールを送信してから、メール送信のみモードを有効にしてください。';
            }
        }

        if (!empty($embedSettings['enabled'])) {
            $originLines = preg_split('/\R/u', (string) ($embedSettings['allowed_origins_input'] ?? '')) ?: [];
            $nonEmptyOriginLines = array_values(array_filter(array_map('trim', $originLines), static fn(string $value): bool => $value !== ''));
            if (count($nonEmptyOriginLines) > 50) {
                $errors[] = '外部連携の公開サイトは50件以内で入力してください。';
            }
            foreach ($nonEmptyOriginLines as $originLine) {
                if (FormEmbedSetting::normalizeOrigin($originLine) === null) {
                    $errors[] = '外部連携の公開サイトが不正です: ' . $originLine;
                }
            }
            $completionUrl = trim((string) ($embedSettings['completion_url'] ?? ''));
            if (mb_strlen($completionUrl) > 500) {
                $errors[] = '外部連携の送信完了画面は500文字以内で入力してください。';
            } elseif ($completionUrl !== '' && FormEmbedSetting::normalizeCompletionUrl($completionUrl) === null) {
                $errors[] = '外部連携の送信完了画面は http:// または https:// で始まるURLを入力してください。';
            }
            if (($embedSettings['allowed_origins'] ?? []) === []) {
                $errors[] = '外部埋め込み機能を有効にする場合は、公開サイトを1件以上入力してください。';
            }
            if (!ctype_digit((string) ($embedSettings['rate_limit_count'] ?? '')) || (int) $embedSettings['rate_limit_count'] < 1 || (int) $embedSettings['rate_limit_count'] > 1000) {
                $errors[] = '外部連携の送信上限は1〜1000回で入力してください。';
            }
            if (!ctype_digit((string) ($embedSettings['rate_limit_window_seconds'] ?? '')) || (int) $embedSettings['rate_limit_window_seconds'] < 60 || (int) $embedSettings['rate_limit_window_seconds'] > 86400) {
                $errors[] = '外部連携の制限期間は60〜86400秒で入力してください。';
            }
            if (mb_strlen((string) ($embedSettings['turnstile_site_key'] ?? '')) > 255 || mb_strlen((string) ($embedSettings['turnstile_secret_key'] ?? '')) > 255) {
                $errors[] = 'Turnstileのキーは255文字以内で入力してください。';
            }
            if (!empty($embedSettings['turnstile_enabled'])) {
                if (trim((string) ($embedSettings['turnstile_site_key'] ?? '')) === '') {
                    $errors[] = 'Turnstileを有効にする場合はサイトキーを入力してください。';
                }
                $hasSecret = trim((string) ($embedSettings['turnstile_secret_key'] ?? '')) !== ''
                    || (!empty($embedSettings['turnstile_secret_configured']) && empty($embedSettings['turnstile_secret_clear']));
                if (!$hasSecret) {
                    $errors[] = 'Turnstileを有効にする場合はシークレットキーを入力してください。';
                }
            }
            if (mb_strlen((string) ($embedSettings['recaptcha_site_key'] ?? '')) > 255 || mb_strlen((string) ($embedSettings['recaptcha_secret_key'] ?? '')) > 255) {
                $errors[] = 'reCAPTCHAのキーは255文字以内で入力してください。';
            }
            if (!empty($embedSettings['recaptcha_enabled'])) {
                if (trim((string) ($embedSettings['recaptcha_site_key'] ?? '')) === '') {
                    $errors[] = 'reCAPTCHAを有効にする場合はサイトキーを入力してください。';
                }
                $hasSecret = trim((string) ($embedSettings['recaptcha_secret_key'] ?? '')) !== ''
                    || (!empty($embedSettings['recaptcha_secret_configured']) && empty($embedSettings['recaptcha_secret_clear']));
                if (!$hasSecret) {
                    $errors[] = 'reCAPTCHAを有効にする場合はシークレットキーを入力してください。';
                }
            }
            if (mb_strlen((string) ($embedSettings['recaptcha_v3_site_key'] ?? '')) > 255 || mb_strlen((string) ($embedSettings['recaptcha_v3_secret_key'] ?? '')) > 255) {
                $errors[] = 'reCAPTCHA v3のキーは255文字以内で入力してください。';
            }
            if (!is_numeric($embedSettings['recaptcha_v3_min_score'] ?? null)
                || (float) $embedSettings['recaptcha_v3_min_score'] < 0.0
                || (float) $embedSettings['recaptcha_v3_min_score'] > 1.0) {
                $errors[] = 'reCAPTCHA v3の合格スコアは0.0〜1.0で入力してください。';
            }
            if (!empty($embedSettings['recaptcha_v3_enabled'])) {
                if (trim((string) ($embedSettings['recaptcha_v3_site_key'] ?? '')) === '') {
                    $errors[] = 'reCAPTCHA v3を有効にする場合はサイトキーを入力してください。';
                }
                $hasSecret = trim((string) ($embedSettings['recaptcha_v3_secret_key'] ?? '')) !== ''
                    || (!empty($embedSettings['recaptcha_v3_secret_configured']) && empty($embedSettings['recaptcha_v3_secret_clear']));
                if (!$hasSecret) {
                    $errors[] = 'reCAPTCHA v3を有効にする場合はシークレットキーを入力してください。';
                }
            }
            $enabledCaptchaCount = (!empty($embedSettings['turnstile_enabled']) ? 1 : 0)
                + (!empty($embedSettings['recaptcha_enabled']) ? 1 : 0)
                + (!empty($embedSettings['recaptcha_v3_enabled']) ? 1 : 0);
            if ($enabledCaptchaCount > 1) {
                $errors[] = '不正送信対策は1つだけ選択してください。';
            }
            if (!empty($embedSettings['japan_only_enabled'])) {
                if (mb_strlen((string) ($embedSettings['ipinfo_lite_token'] ?? '')) > 255) {
                    $errors[] = 'IPinfo Liteのトークンは255文字以内で入力してください。';
                }
                $hasIpinfoToken = trim((string) ($embedSettings['ipinfo_lite_token'] ?? '')) !== ''
                    || (!empty($embedSettings['ipinfo_lite_token_configured']) && empty($embedSettings['ipinfo_lite_token_clear']));
                if (!$hasIpinfoToken && trim((string) config('ip_geolocation.ipinfo_token', '')) === '') {
                    $errors[] = '国外送信対策で IPinfo Lite を使う場合はトークンを入力してください。';
                }
            }
        }
        if ($form['mail_transport'] === 'smtp') {
            if ($form['mail_smtp_host'] === '') {
                $errors[] = '通知設定の SMTPホストは必須です。';
            }
            if (!ctype_digit((string) $form['mail_smtp_port']) || (int) $form['mail_smtp_port'] < 1 || (int) $form['mail_smtp_port'] > 65535) {
                $errors[] = '通知設定の SMTPポートは 1〜65535 の整数で入力してください。';
            }
            if (!in_array($form['mail_smtp_secure'], ['', 'ssl', 'tls'], true)) {
                $errors[] = '通知設定の暗号化方式は「なし」「SSL」「STARTTLS」のいずれかを選択してください。';
            }
            if (!ctype_digit((string) $form['mail_smtp_timeout']) || (int) $form['mail_smtp_timeout'] < 1 || (int) $form['mail_smtp_timeout'] > 300) {
                $errors[] = '通知設定の SMTPタイムアウトは 1〜300 秒で入力してください。';
            }
            $ehloHost = trim((string) ($form['mail_smtp_ehlo_host'] ?? ''));
            if ($ehloHost !== '' && !\Core\Mailer::isValidEhloHost($ehloHost)) {
                $errors[] = '通知設定の EHLO ホスト名は半角英数字・ドット・ハイフンで入力してください。';
            }
            if (
                trim((string) $form['mail_smtp_username']) !== ''
                && trim((string) $form['mail_smtp_password']) === ''
            ) {
                $errors[] = '通知設定で SMTPユーザー名を使う場合は、SMTPパスワードも入力してください。';
            }
        }

        if (!empty($form['line_notify_enabled'])) {
            if (mb_strlen((string) ($form['line_push_to_id'] ?? '')) > 64) {
                $errors[] = 'LINE通知の送信先 ID は64文字以内にしてください。';
            }
        }

        if (count($inputPages) === 0) {
            $errors[] = '入力画面を1つ以上設定してください。';
        }
        $pageKeys = [];
        foreach ($inputPages as $i => $page) {
            $no = $i + 1;
            $pageKey = (string) ($page['page_key'] ?? '');
            if (FormInputPage::sanitizePageKey($pageKey) === '') {
                $errors[] = "入力画面{$no}: キーが不正です。";
            }
            if (in_array($pageKey, $pageKeys, true)) {
                $errors[] = "入力画面{$no}: キーが重複しています。";
            } else {
                $pageKeys[] = $pageKey;
            }
            if (mb_strlen((string) ($page['title'] ?? '')) > 200) {
                $errors[] = "入力画面{$no}: タイトルは200文字以内にしてください。";
            }
            if (mb_strlen((string) ($page['button_text'] ?? '')) > 200) {
                $errors[] = "入力画面{$no}: ボタンテキストは200文字以内にしてください。";
            }
            if (mb_strlen((string) ($page['back_button_text'] ?? '')) > 200) {
                $errors[] = "入力画面{$no}: 戻るボタンテキストは200文字以内にしてください。";
            }
        }

        $usedKeys = [];
        $usedGroupKeys = [];
        $groupPageKeys = [];
        $groupParents = [];
        foreach ($fieldGroups as $i => $group) {
            $no = $i + 1;
            $groupKey = (string) ($group['group_key'] ?? '');
            if (!in_array((string) ($group['input_page_key'] ?? ''), $pageKeys, true)) {
                $errors[] = "グループ{$no}: 所属する入力画面が不正です。";
            }
            if ($group['label'] === '') {
                $errors[] = "グループ{$no}: ラベルは必須です。";
            }
            if (FormFieldGroup::sanitizeGroupKey($groupKey) === '') {
                $errors[] = "グループ{$no}: グループキーが不正です。";
            } elseif (in_array($groupKey, $usedGroupKeys, true)) {
                $errors[] = "グループ{$no}: グループキー '{$groupKey}' が重複しています。";
            } else {
                $usedGroupKeys[] = $groupKey;
            }
            $groupPageKeys[$groupKey] = (string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY);
            $parentGroupKey = (string) ($group['parent_group_key'] ?? '');
            if ($parentGroupKey !== '') {
                $groupParents[$groupKey] = $parentGroupKey;
            }
            if (mb_strlen((string) ($group['description'] ?? '')) > 500) {
                $errors[] = "グループ{$no}: 説明文は500文字以内で入力してください。";
            }
        }
        foreach ($fieldGroups as $i => $group) {
            $no = $i + 1;
            $groupKey = (string) ($group['group_key'] ?? '');
            $parentGroupKey = (string) ($group['parent_group_key'] ?? '');
            if ($parentGroupKey === '') {
                continue;
            }
            if (!in_array($parentGroupKey, $usedGroupKeys, true)) {
                $errors[] = "グループ{$no}: 親グループが存在しません。";
                continue;
            }
            if (($groupPageKeys[$parentGroupKey] ?? '') !== ($groupPageKeys[$groupKey] ?? null)) {
                $errors[] = "グループ{$no}: 親グループは同じ入力画面内から選択してください。";
            }
            $seenParents = [$groupKey => true];
            $cursor = $parentGroupKey;
            while ($cursor !== '') {
                if (isset($seenParents[$cursor])) {
                    $errors[] = "グループ{$no}: グループの入れ子が循環しています。";
                    break;
                }
                $seenParents[$cursor] = true;
                $cursor = (string) ($groupParents[$cursor] ?? '');
            }
        }
        foreach ($fields as $i => $f) {
            $no = $i + 1;
            if (!in_array((string) ($f['input_page_key'] ?? ''), $pageKeys, true)) {
                $errors[] = "項目{$no}: 所属する入力画面が不正です。";
            }
            if ($f['label'] === '') {
                $errors[] = "項目{$no}: ラベルは必須です。";
            }
            if (!FieldKey::isValid($f['field_key'])) {
                $errors[] = "項目{$no}: フィールドキーは UUID 形式、または英字で始まる英数字・アンダースコア（最大64文字）にしてください。";
            } elseif (in_array($f['field_key'], $usedKeys, true)) {
                $errors[] = "項目{$no}: フィールドキー '{$f['field_key']}' が重複しています。";
            } else {
                $usedKeys[] = $f['field_key'];
            }
            $parentGroupKey = (string) ($f['parent_group_key'] ?? '');
            if ($parentGroupKey !== '') {
                if (!in_array($parentGroupKey, $usedGroupKeys, true)) {
                    $errors[] = "項目{$no}: 所属グループが存在しません。";
                } elseif (($groupPageKeys[$parentGroupKey] ?? '') !== (string) ($f['input_page_key'] ?? '')) {
                    $errors[] = "項目{$no}: 所属グループは同じ入力画面内から選択してください。";
                }
            }
            if (FormField::isDisplayOnlyType((string) ($f['type'] ?? ''))) {
                continue;
            }
            if (in_array($f['type'], ['radio','checkbox','select'], true)) {
                $opts = FormField::parseOptions($f['options']);
                if (count($opts) === 0) {
                    $errors[] = "項目{$no}: 選択肢を1行に1つずつ入力してください。";
                }
                if ($f['type'] === 'checkbox' && !empty($f['checkbox_limit_enabled'])) {
                    $minSelections = $f['checkbox_min_selections'] !== '' ? (int) $f['checkbox_min_selections'] : 0;
                    $maxSelections = $f['checkbox_max_selections'] !== '' ? (int) $f['checkbox_max_selections'] : 0;
                    if ($f['checkbox_min_selections'] !== '' && $minSelections <= 0) {
                        $errors[] = "項目{$no}: 最小選択数は1以上で入力してください。";
                    }
                    if ($f['checkbox_max_selections'] !== '' && $maxSelections <= 0) {
                        $errors[] = "項目{$no}: 最大選択数は1以上で入力してください。";
                    }
                    if ($minSelections <= 0 && $maxSelections <= 0) {
                        $errors[] = "項目{$no}: 選択数を設定する場合は最小または最大を入力してください。";
                    }
                    if ($minSelections > 0 && $maxSelections > 0 && $minSelections > $maxSelections) {
                        $errors[] = "項目{$no}: 最小選択数は最大選択数以下にしてください。";
                    }
                    if ($minSelections > count($opts)) {
                        $errors[] = "項目{$no}: 最小選択数は選択肢数以下にしてください。";
                    }
                }
                if ($f['type'] === 'radio') {
                    $radioDefaultValue = trim((string) ($f['radio_default_value'] ?? ''));
                    if ($radioDefaultValue !== '' && !in_array($radioDefaultValue, $opts, true)) {
                        $errors[] = "項目{$no}: 初期選択は選択肢から選んでください。";
                    }
                }
            } elseif ($f['type'] === 'text_multi') {
                $multiTextItems = FormField::decodeTextMultiItems((string) ($f['multi_text_items'] ?? ''), false);
                if (count($multiTextItems) === 0) {
                    $errors[] = "項目{$no}: 複数入力の入力欄を1つ以上設定してください。";
                }
            } elseif ($f['type'] === FormField::TYPE_POSTAL_CODE) {
                foreach ([
                    '都道府県UUID' => (string) ($f['postal_target_prefecture'] ?? ''),
                    '市区町村UUID' => (string) ($f['postal_target_city'] ?? ''),
                ] as $targetLabel => $targetKey) {
                    $targetKey = trim($targetKey);
                    if ($targetKey !== '' && !FieldKey::isValid($targetKey)) {
                        $errors[] = "項目{$no}: 郵便番号補完先の{$targetLabel}は有効なフィールドキーを指定してください。";
                    }
                }
            } elseif ($f['type'] === 'file') {
                $fileTypeMode = FormField::normalizeFileSelectionMode((string) ($f['file_type_mode'] ?? FormField::FILE_SELECTION_CUSTOM));
                $allowedExtensions = FormField::parseExtensionList((string) ($f['file_allowed_extensions'] ?? ''));
                if ($fileTypeMode === FormField::FILE_SELECTION_CUSTOM && (string) ($f['file_allowed_extensions'] ?? '') !== '' && $allowedExtensions === []) {
                    $errors[] = "項目{$no}: 許可拡張子はカンマ区切りで入力してください。";
                }
            } elseif ($f['type'] === FormField::TYPE_MATRIX) {
                $rows = FormField::parseOptions((string) ($f['matrix_rows'] ?? ''));
                $columns = FormField::parseOptions((string) ($f['matrix_columns'] ?? ''));
                if ($rows === []) {
                    $errors[] = "項目{$no}: マトリックスの行を1つ以上入力してください。";
                }
                if ($columns === []) {
                    $errors[] = "項目{$no}: マトリックスの列を1つ以上入力してください。";
                }
                if (count($rows) !== count(array_unique($rows))) {
                    $errors[] = "項目{$no}: マトリックスの行が重複しています。";
                }
                if (count($columns) !== count(array_unique($columns))) {
                    $errors[] = "項目{$no}: マトリックスの列が重複しています。";
                }
                if ((string) ($f['matrix_selection_type'] ?? 'radio') !== 'radio') {
                    $errors[] = "項目{$no}: マトリックスの選択方式が不正です。";
                }
            }
            if (in_array($f['type'], ['textarea', 'number'], true)) {
                $defaultValue = (string) ($f['default_value'] ?? '');
                if ($f['type'] === 'number' && $defaultValue !== '' && !is_numeric($defaultValue)) {
                    $errors[] = "項目{$no}: 数値項目の初期値は数値で入力してください。";
                }
            } elseif ($f['type'] === 'date') {
                $defaultMode = (string) ($f['date_default_mode'] ?? '');
                $defaultValue = (string) ($f['date_default_value'] ?? '');
                if (!in_array($defaultMode, ['', 'fixed', 'today'], true)) {
                    $errors[] = "項目{$no}: 日付項目の初期値設定が不正です。";
                }
                if ($defaultMode === 'fixed' && !preg_match('/\A\d{4}-\d{2}-\d{2}\z/', $defaultValue)) {
                    $errors[] = "項目{$no}: 日付項目の固定初期値は YYYY-MM-DD 形式で入力してください。";
                }
            } elseif ($f['type'] === 'time') {
                $defaultMode = (string) ($f['time_default_mode'] ?? '');
                $defaultValue = (string) ($f['time_default_value'] ?? '');
                if (!in_array($defaultMode, ['', 'fixed', 'now'], true)) {
                    $errors[] = "項目{$no}: 時間項目の初期値設定が不正です。";
                }
                if ($defaultMode === 'fixed' && !preg_match('/\A\d{2}:\d{2}\z/', $defaultValue)) {
                    $errors[] = "項目{$no}: 時間項目の固定初期値は HH:MM 形式で入力してください。";
                }
            }
            $regexPatterns = FormField::decodeRegexPatterns(
                isset($f['regex']) && is_string($f['regex']) ? $f['regex'] : ''
            );
            foreach ($regexPatterns as $pat) {
                if ($pat !== '' && @preg_match($pat, '') === false) {
                    $errors[] = "項目{$no}: 正規表現が不正です。";
                    break;
                }
            }
        }

        $errors = array_merge($errors, FormBranchRule::validateRules($branchRules, $fields, $inputPages, $fieldGroups));
        foreach (FormBranchRule::duplicateTargetWarnings($branchRules) as $warning) {
            $errors[] = $warning;
        }

        if (!empty($form['reply_enabled'])) {
            $selectedReplyFieldKeys = Form::replyFieldKeys($form['reply_from_field_key'] ?? null);
            $availableReplyFieldKeys = array_column(self::replyFieldOptions($fields, $fieldGroups, $inputPages), 'value');
            if ($selectedReplyFieldKeys === []) {
                $errors[] = '送信先には、入力画面に表示されるメールアドレス項目を1つ以上選択してください。';
            } else {
                foreach ($selectedReplyFieldKeys as $replyFieldKey) {
                    if (!in_array($replyFieldKey, $availableReplyFieldKeys, true)) {
                        $errors[] = '送信先には、入力画面に表示されるメールアドレス項目だけを選択してください。';
                        break;
                    }
                }
            }
        }

        return $errors;
    }

    /**
     * @param array<string> $errors
     * @param array<string, mixed> $builderMeta
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $fieldGroups
     * @param array<int, array<string, mixed>> $inputPages
     * @param array<int, array<string, mixed>> $branchRules
     */
    private static function appendBuilderMetaErrors(array &$errors, array $builderMeta, array $fields, array $fieldGroups, array $inputPages, array $branchRules): void
    {
        $fieldCountMismatch = !empty($builderMeta['field_count']) && count($fields) < (int) $builderMeta['field_count'];
        $groupCountMismatch = !empty($builderMeta['group_count']) && count($fieldGroups) < (int) $builderMeta['group_count'];
        $pageCountMismatch = !empty($builderMeta['input_page_count']) && count($inputPages) < (int) $builderMeta['input_page_count'];
        $ruleCountMismatch = !empty($builderMeta['branch_rule_count']) && count($branchRules) < (int) $builderMeta['branch_rule_count'];

        $fieldKeyMismatch = false;
        $expectedFieldKeys = is_array($builderMeta['field_keys'] ?? null) ? $builderMeta['field_keys'] : [];
        if ($expectedFieldKeys !== []) {
            $actualFieldKeys = array_map(static function (array $field): string {
                return (string) ($field['field_key'] ?? '');
            }, $fields);
            $fieldKeyMismatch = array_values(array_diff($expectedFieldKeys, $actualFieldKeys)) !== [];
        }

        $groupKeyMismatch = false;
        $expectedGroupKeys = is_array($builderMeta['group_keys'] ?? null) ? $builderMeta['group_keys'] : [];
        if ($expectedGroupKeys !== []) {
            $actualGroupKeys = array_map(static function (array $group): string {
                return (string) ($group['group_key'] ?? '');
            }, $fieldGroups);
            $groupKeyMismatch = array_values(array_diff($expectedGroupKeys, $actualGroupKeys)) !== [];
        }

        if (!$fieldCountMismatch && !$groupCountMismatch && !$pageCountMismatch && !$ruleCountMismatch && !$fieldKeyMismatch && !$groupKeyMismatch) {
            return;
        }

        $message = '項目設定の送信内容が途中で切れているため保存できませんでした。フォーム項目を減らすか、サーバーの max_input_vars を増やしてから再度保存してください。';
        $inputVarCount = (int) ($builderMeta['input_var_count'] ?? 0);
        if ($inputVarCount > 0) {
            $message .= ' 現在の POST 変数数の目安: ' . $inputVarCount . '。';
        }
        $errors[] = $message;
    }

    public static function defaultForm(): array
    {
        return [
            'id' => null,
            'slug' => FieldKey::generateUuidV4(),
            'title' => '',
            'meta_html' => self::DEFAULT_META_HTML,
            'custom_css' => '',
            'custom_js' => '',
            'header_html' => '',
            'footer_html' => '',
            'input_page_title' => '',
            'show_input_page_title' => 1,
            'description' => '',
            'show_title' => 0,
            'show_description' => 1,
            'confirm_page_title' => '入力内容のご確認',
            'show_confirm_page_title' => 1,
            'confirm_button_text' => '入力内容を確認する',
            'submit_button_text' => '送信する',
            'back_button_text' => '入力に戻る',
            'confirm_message' => '',
            'thanks_page_title' => '送信が完了しました',
            'show_thanks_page_title' => 1,
            'thanks_message' => '',
            'thanks_button_text' => 'トップへ戻る',
            'thanks_button_url' => '/',
            'admin_emails' => '',
            'mail_subject_admin' => '',
            'mail_template_admin' => Form::defaultAdminMailTemplate(),
            'mail_transport' => (string) config('mail.transport', 'mail'),
            'mail_from_email' => (string) config('mail.from_email', 'noreply@example.com'),
            'mail_from_name' => (string) config('mail.from_name', ''),
            'mail_smtp_host' => (string) config('mail.smtp.host', ''),
            'mail_smtp_port' => (string) config('mail.smtp.port', 25),
            'mail_smtp_secure' => (string) config('mail.smtp.secure', ''),
            'mail_smtp_username' => (string) config('mail.smtp.username', ''),
            'mail_smtp_password' => '',
            'mail_smtp_timeout' => (string) config('mail.smtp.timeout', 10),
            'mail_smtp_ehlo_host' => (string) config('mail.smtp.ehlo_host', ''),
            'mail_smtp_verify_peer' => !empty(config('mail.smtp.verify_peer', true)) ? 1 : 0,
            'mail_smtp_verify_peer_name' => !empty(config('mail.smtp.verify_peer_name', true)) ? 1 : 0,
            'mail_smtp_allow_self_signed' => !empty(config('mail.smtp.allow_self_signed', false)) ? 1 : 0,
            'mail_smtp_password_configured' => 0,
            'mail_smtp_clear_password' => 0,
            'submission_storage_mode' => Form::STORAGE_DATABASE,
            'mail_attachment_max_bytes' => Form::DEFAULT_MAIL_ATTACHMENT_MAX_BYTES,
            'submission_retention_days' => Form::DEFAULT_RETENTION_DAYS,
            'submission_retention_action' => Form::RETENTION_WARN,
            'submission_retention_enabled' => 1,
            'smtp_tested_at' => null,
            'smtp_test_fingerprint' => null,
            'reply_enabled' => 0,
            'reply_from_field_key' => '',
            'reply_subject' => '送信ありがとうございました',
            'reply_template' => "お問い合わせいただきありがとうございました。\n以下の内容で受け付けました。\n\n{{__all__}}",
            'line_notify_enabled' => 0,
            'line_push_to_id' => '',
            'line_push_to_id_configured' => 0,
            'line_channel_access_token' => '',
            'line_channel_access_token_configured' => 0,
            'line_channel_secret' => '',
            'line_channel_secret_configured' => 0,
            'line_message_template' => Form::defaultAdminMailTemplate(),
            'publish_schedule_enabled' => 0,
            'publish_rules' => null,
            'unpublish_rules' => null,
            'closed_page_title' => '現在、フォームをご利用いただけません',
            'show_closed_page_title' => 1,
            'closed_message' => '',
            'closed_button_text' => 'トップへ戻る',
            'closed_button_url' => '/',
            'status' => 'draft',
        ];
    }

    /**
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    private static function prepareFormForEdit(array $form): array
    {
        $smtpTestIsCurrent = Form::smtpTestIsCurrent($form);
        $form['input_page_title'] = trim((string) ($form['input_page_title'] ?? '')) !== ''
            ? (string) $form['input_page_title']
            : trim((string) ($form['title'] ?? ''));
        $form['meta_html'] = trim((string) ($form['meta_html'] ?? ''));
        $form['custom_css'] = trim((string) ($form['custom_css'] ?? ''));
        $form['custom_js'] = trim((string) ($form['custom_js'] ?? ''));
        $form['header_html'] = trim((string) ($form['header_html'] ?? ''));
        $form['footer_html'] = trim((string) ($form['footer_html'] ?? ''));
        if ($form['meta_html'] === '') {
            $legacyMetaTitle = str_replace('"', "'", trim((string) ($form['meta_title'] ?? '')));
            $legacyMetaDescription = str_replace('"', "'", trim((string) ($form['meta_description'] ?? '')));
            if ($legacyMetaTitle !== '' || $legacyMetaDescription !== '') {
                $legacyLines = [];
                if ($legacyMetaDescription !== '') {
                    $legacyLines[] = '<meta name="description" content="' . $legacyMetaDescription . '">';
                }
                if ($legacyMetaTitle !== '') {
                    $legacyLines[] = '<meta property="og:title" content="' . $legacyMetaTitle . '">';
                }
                if ($legacyMetaDescription !== '') {
                    $legacyLines[] = '<meta property="og:description" content="' . $legacyMetaDescription . '">';
                }
                $legacyLines[] = '<meta property="og:type" content="website">';
                $form['meta_html'] = implode("\n", $legacyLines);
            }
        }
        $form['show_input_page_title'] = !array_key_exists('show_input_page_title', $form) || !empty($form['show_input_page_title']) ? 1 : 0;
        $form['confirm_page_title'] = trim((string) ($form['confirm_page_title'] ?? '')) !== ''
            ? (string) $form['confirm_page_title']
            : '入力内容のご確認';
        $form['show_confirm_page_title'] = !array_key_exists('show_confirm_page_title', $form) || !empty($form['show_confirm_page_title']) ? 1 : 0;
        $form['confirm_button_text'] = trim((string) ($form['confirm_button_text'] ?? '')) !== ''
            ? (string) $form['confirm_button_text']
            : '入力内容を確認する';
        $form['submit_button_text'] = trim((string) ($form['submit_button_text'] ?? '')) !== ''
            ? (string) $form['submit_button_text']
            : '送信する';
        $form['back_button_text'] = trim((string) ($form['back_button_text'] ?? '')) !== ''
            ? (string) $form['back_button_text']
            : '入力に戻る';
        $form['thanks_page_title'] = trim((string) ($form['thanks_page_title'] ?? '')) !== ''
            ? (string) $form['thanks_page_title']
            : '送信が完了しました';
        $form['show_thanks_page_title'] = !array_key_exists('show_thanks_page_title', $form) || !empty($form['show_thanks_page_title']) ? 1 : 0;
        $form['thanks_button_text'] = trim((string) ($form['thanks_button_text'] ?? '')) !== ''
            ? (string) $form['thanks_button_text']
            : 'トップへ戻る';
        $form['thanks_button_url'] = trim((string) ($form['thanks_button_url'] ?? '')) !== ''
            ? (string) $form['thanks_button_url']
            : '/';
        $form['mail_transport'] = in_array(($form['mail_transport'] ?? null), ['mail', 'smtp'], true)
            ? (string) $form['mail_transport']
            : (string) config('mail.transport', 'mail');
        $form['mail_from_email'] = array_key_exists('mail_from_email', $form)
            ? (string) ($form['mail_from_email'] ?? '')
            : (string) config('mail.from_email', 'noreply@example.com');
        $form['mail_from_name'] = array_key_exists('mail_from_name', $form)
            ? (string) ($form['mail_from_name'] ?? '')
            : (string) config('mail.from_name', '');
        $form['mail_smtp_host'] = array_key_exists('mail_smtp_host', $form)
            ? (string) ($form['mail_smtp_host'] ?? '')
            : (string) config('mail.smtp.host', '');
        $form['mail_smtp_port'] = trim((string) ($form['mail_smtp_port'] ?? '')) !== ''
            ? (string) $form['mail_smtp_port']
            : (string) config('mail.smtp.port', 25);
        $form['mail_smtp_secure'] = in_array(($form['mail_smtp_secure'] ?? null), ['', 'ssl', 'tls'], true)
            ? (string) ($form['mail_smtp_secure'] ?? '')
            : (string) config('mail.smtp.secure', '');
        $form['mail_smtp_username'] = array_key_exists('mail_smtp_username', $form)
            ? (string) ($form['mail_smtp_username'] ?? '')
            : (string) config('mail.smtp.username', '');
        $form['mail_smtp_timeout'] = trim((string) ($form['mail_smtp_timeout'] ?? '')) !== ''
            ? (string) $form['mail_smtp_timeout']
            : (string) config('mail.smtp.timeout', 10);
        $form['mail_smtp_ehlo_host'] = array_key_exists('mail_smtp_ehlo_host', $form)
            ? (string) ($form['mail_smtp_ehlo_host'] ?? '')
            : (string) config('mail.smtp.ehlo_host', '');
        $form['mail_smtp_verify_peer'] = !array_key_exists('mail_smtp_verify_peer', $form) || !empty($form['mail_smtp_verify_peer']) ? 1 : 0;
        $form['mail_smtp_verify_peer_name'] = !array_key_exists('mail_smtp_verify_peer_name', $form) || !empty($form['mail_smtp_verify_peer_name']) ? 1 : 0;
        $form['mail_smtp_allow_self_signed'] = !empty($form['mail_smtp_allow_self_signed']) ? 1 : 0;
        $form['mail_smtp_password_configured'] = trim((string) ($form['mail_smtp_password'] ?? '')) !== '' ? 1 : 0;
        $form['mail_smtp_password'] = '';
        $form['mail_smtp_clear_password'] = !empty($form['mail_smtp_clear_password']) ? 1 : 0;
        $form['line_channel_access_token_configured'] = trim((string) ($form['line_channel_access_token'] ?? '')) !== '' ? 1 : 0;
        $form['line_channel_access_token'] = '';
        $form['line_channel_secret_configured'] = trim((string) ($form['line_channel_secret'] ?? '')) !== '' ? 1 : 0;
        $form['line_channel_secret'] = '';
        $form['line_push_to_id_configured'] = trim((string) ($form['line_push_to_id'] ?? '')) !== '' ? 1 : 0;
        $lineMessageStored = trim((string) ($form['line_message_template'] ?? ''));
        $form['line_message_template_effective'] = $lineMessageStored !== ''
            ? (string) $form['line_message_template']
            : (string) ($form['mail_template_admin'] ?? Form::defaultAdminMailTemplate());
        $form['line_setup_checklist'] = Form::lineSetupChecklistStateForDisplay($form);
        $form['submission_storage_mode'] = Form::isMailOnly($form) ? Form::STORAGE_MAIL_ONLY : Form::STORAGE_DATABASE;
        $form['mail_attachment_max_bytes'] = Form::normalizeAttachmentMaxBytes($form['mail_attachment_max_bytes'] ?? null);
        $form['smtp_test_is_current'] = $smtpTestIsCurrent ? 1 : 0;
        $form['reply_from_field_keys'] = Form::replyFieldKeys($form['reply_from_field_key'] ?? null);
        $form['description_blocks'] = self::normalizeDescriptionBlocks(
            decode_form_description_blocks($form['description'] ?? '', !empty($form['show_description'])),
            true,
            'description'
        );
        $form['confirm_blocks'] = self::normalizeDescriptionBlocks(
            decode_form_description_blocks($form['confirm_message'] ?? '', true),
            true,
            'confirm'
        );
        $form['thanks_blocks'] = self::normalizeDescriptionBlocks(
            decode_form_description_blocks($form['thanks_message'] ?? '', true),
            true,
            'thanks'
        );
        $form['publish_rules_list'] = decode_form_publish_rules($form['publish_rules'] ?? null);
        $form['publish_rules'] = $form['publish_rules_list'];
        $form['unpublish_rules_list'] = decode_form_unpublish_rules($form['unpublish_rules'] ?? null);
        $form['unpublish_rules'] = $form['unpublish_rules_list'];
        $form['closed_blocks'] = self::normalizeDescriptionBlocks(
            decode_form_description_blocks($form['closed_message'] ?? '', true),
            true,
            'closed'
        );
        return $form;
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     * @param array<string, mixed> $form
     * @return array<int, array<string, mixed>>
     */
    private static function prepareInputPagesForEdit(array $pages, array $form): array
    {
        $prepared = [];
        foreach (FormInputPage::normalizePages($pages, $form) as $page) {
            $page['description_blocks'] = self::normalizeDescriptionBlocks(
                decode_form_description_blocks($page['description'] ?? '', true),
                true,
                'description'
            );
            $prepared[] = $page;
        }
        return $prepared;
    }

    /**
     * @param array<string, mixed> $submittedForm
     * @param array<string, mixed>|null $storedForm
     * @return array<string, mixed>
     */
    private static function retainAdminOnlyFields(array $submittedForm, ?array $storedForm): array
    {
        return self::applyAdminOnlyFieldPolicy($submittedForm, $storedForm ?? self::defaultForm());
    }

    /**
     * admin 以外の操作では ADMIN_ONLY_FORM_KEYS を基準値（保存済み or 既定値）で上書きする。
     *
     * @param array<string, mixed> $submittedForm
     * @param array<string, mixed> $baseForm
     * @return array<string, mixed>
     */
    public static function applyAdminOnlyFieldPolicy(array $submittedForm, array $baseForm): array
    {
        if (Auth::role() === 'admin') {
            return $submittedForm;
        }
        foreach (self::ADMIN_ONLY_FORM_KEYS as $key) {
            $submittedForm[$key] = $baseForm[$key] ?? null;
        }
        $submittedForm['mail_smtp_clear_password'] = 0;
        return $submittedForm;
    }

    /**
     * @param array<string, mixed> $submittedForm
     * @param array<string, mixed> $storedForm
     * @param array<string, mixed> $mailInputPresence
     * @return array<string, mixed>
     */
    private static function mergeStoredMailSettings(array $submittedForm, array $storedForm, array $mailInputPresence): array
    {
        $lineSaveCredential = trim((string) ($mailInputPresence['line_save_credential'] ?? ''));
        $lineSaveStep = (int) ($mailInputPresence['line_save_step'] ?? 0);

        if ($lineSaveCredential !== '') {
            $postedLineSecret = trim((string) ($submittedForm['line_channel_secret'] ?? ''));
            $postedLineToken = trim((string) ($submittedForm['line_channel_access_token'] ?? ''));
            $submittedForm = self::preserveNonLineMailFromStored($submittedForm, $storedForm);
            $submittedForm = self::preserveLineFromStored($submittedForm, $storedForm);
            if ($lineSaveCredential === 'secret' || $lineSaveCredential === 'delete_secret') {
                $submittedForm['line_channel_secret'] = $lineSaveCredential === 'delete_secret'
                    ? ''
                    : $postedLineSecret;
            }
            if ($lineSaveCredential === 'token' || $lineSaveCredential === 'delete_token') {
                $submittedForm['line_channel_access_token'] = $lineSaveCredential === 'delete_token'
                    ? ''
                    : $postedLineToken;
            }
        } elseif ($lineSaveStep > 0) {
            $submittedForm = self::preserveNonLineMailFromStored($submittedForm, $storedForm);
            foreach (self::lineFormKeys() as $key) {
                $submittedForm[$key] = self::mergeLineStep($submittedForm, $storedForm, $lineSaveStep)[$key];
            }
        } else {
            $submittedForm = self::preserveLineFromStored($submittedForm, $storedForm);
            $submittedForm = self::mergeLineNotifyUiFromPosted($submittedForm, $storedForm, $mailInputPresence);
        }

        foreach (self::mailScalarKeys() as $key) {
            if (in_array($key, self::lineFormKeys(), true)) {
                continue;
            }
            if (!self::wasMailInputPosted($mailInputPresence, $key) && array_key_exists($key, $storedForm)) {
                $submittedForm[$key] = $storedForm[$key];
            }
        }

        if (!self::wasMailSectionPosted($mailInputPresence, 'smtp')) {
            foreach (self::mailSmtpToggleKeys() as $key) {
                if (array_key_exists($key, $storedForm)) {
                    $submittedForm[$key] = $storedForm[$key];
                }
            }
        }

        if (!self::wasMailSectionPosted($mailInputPresence, 'reply') && array_key_exists('reply_enabled', $storedForm)) {
            $submittedForm['reply_enabled'] = $storedForm['reply_enabled'];
        }

        if (!empty($submittedForm['mail_smtp_clear_password'])) {
            $submittedForm['mail_smtp_password'] = '';

            return $submittedForm;
        }

        if (trim((string) ($submittedForm['mail_smtp_password'] ?? '')) === '') {
            $submittedForm['mail_smtp_password'] = (string) ($storedForm['mail_smtp_password'] ?? '');
        }

        return $submittedForm;
    }

    /**
     * 通常フォーム保存時: 通知 ON/OFF と表示設定テンプレのみ POST を反映（credential / 送信先 ID は stored 維持）。
     *
     * @param array<string, mixed> $submittedForm
     * @param array<string, mixed> $storedForm
     * @param array<string, mixed> $mailInputPresence
     * @return array<string, mixed>
     */
    private static function mergeLineNotifyUiFromPosted(
        array $submittedForm,
        array $storedForm,
        array $mailInputPresence
    ): array {
        if (self::wasMailInputPosted($mailInputPresence, 'line_notify_enabled')) {
            $submittedForm['line_notify_enabled'] = !empty($submittedForm['line_notify_enabled']) ? 1 : 0;
        }
        if (self::wasMailInputPosted($mailInputPresence, 'line_message_template')
            && Form::lineSetupChecklistIsCompleteForFormRow($storedForm)) {
            $submittedForm['line_message_template'] = (string) ($submittedForm['line_message_template'] ?? '');
        }

        return $submittedForm;
    }

    /**
     * @return array<int, string>
     */
    private static function lineFormKeys(): array
    {
        return [
            'line_notify_enabled',
            'line_push_to_id',
            'line_message_template',
            'line_channel_access_token',
            'line_channel_secret',
        ];
    }

    /**
     * @param array<string, mixed> $submittedForm
     * @param array<string, mixed> $storedForm
     * @return array<string, mixed>
     */
    private static function preserveLineFromStored(array $submittedForm, array $storedForm): array
    {
        foreach (self::lineFormKeys() as $key) {
            if (array_key_exists($key, $storedForm)) {
                $submittedForm[$key] = $storedForm[$key];
            }
        }

        return $submittedForm;
    }

    /**
     * LINE Step 保存時に SMTP 等の通知設定は stored を維持する。
     *
     * @param array<string, mixed> $submittedForm
     * @param array<string, mixed> $storedForm
     * @return array<string, mixed>
     */
    private static function preserveNonLineMailFromStored(array $submittedForm, array $storedForm): array
    {
        foreach (self::mailScalarKeys() as $key) {
            if (in_array($key, self::lineFormKeys(), true)) {
                continue;
            }
            if (array_key_exists($key, $storedForm)) {
                $submittedForm[$key] = $storedForm[$key];
            }
        }
        foreach (self::mailSmtpToggleKeys() as $key) {
            if (array_key_exists($key, $storedForm)) {
                $submittedForm[$key] = $storedForm[$key];
            }
        }
        if (array_key_exists('reply_enabled', $storedForm)) {
            $submittedForm['reply_enabled'] = $storedForm['reply_enabled'];
        }
        if (array_key_exists('mail_smtp_password', $storedForm)) {
            $submittedForm['mail_smtp_password'] = $storedForm['mail_smtp_password'];
        }

        return $submittedForm;
    }

    /**
     * @param array<string, mixed> $submittedForm
     * @param array<string, mixed> $storedForm
     * @return array<string, mixed>
     */
    private static function mergeLineStep(array $submittedForm, array $storedForm, int $step): array
    {
        $result = [];
        foreach (self::lineFormKeys() as $key) {
            $result[$key] = $storedForm[$key] ?? null;
        }

        if ($step === 2) {
            $result['line_push_to_id'] = trim((string) ($submittedForm['line_push_to_id'] ?? ''));

            return $result;
        }

        if ($step === 3) {
            $result['line_notify_enabled'] = !empty($submittedForm['line_notify_enabled']) ? 1 : 0;
            $result['line_message_template'] = (string) ($submittedForm['line_message_template'] ?? '');
        }

        return $result;
    }

    /**
     * @param array<string, mixed> $form
     * @return array<int, string>
     */
    private static function validateLineChannelSecretForSave(array $form): array
    {
        $errors = [];
        $value = trim((string) ($form['line_channel_secret'] ?? ''));
        if ($value === '') {
            $errors[] = 'Channel secret を入力してください。';
        } elseif (mb_strlen($value) > 255) {
            $errors[] = 'Channel secret が長すぎます。';
        }

        return $errors;
    }

    /**
     * @param array<string, mixed> $form
     * @return array<int, string>
     */
    private static function validateLineChannelAccessTokenForSave(array $form): array
    {
        $errors = [];
        $value = trim((string) ($form['line_channel_access_token'] ?? ''));
        if ($value === '') {
            $errors[] = 'Channel access token を入力してください。';
        } elseif (mb_strlen($value) > 512) {
            $errors[] = 'Channel access token が長すぎます。';
        }

        return $errors;
    }

    /**
     * @param array<string, mixed> $form
     * @param array<string, mixed> $storedForm
     * @return array<int, string>
     */
    private static function validateLineStep(array $form, array $storedForm, int $step): array
    {
        $errors = [];
        if ($step === 2) {
            if (mb_strlen((string) ($form['line_push_to_id'] ?? '')) > 64) {
                $errors[] = '送信先 ID は64文字以内にしてください。';
            }

            return $errors;
        }

        return $errors;
    }

    /**
     * バリデーションエラー再描画用に、通知設定だけは空値で保存済み値を潰さない。
     *
     * @param array<string, mixed> $storedForm
     * @param array<string, mixed> $submittedForm
     * @param array<string, mixed> $mailInputPresence
     * @return array<string, mixed>
     */
    private static function mergeStoredFormForError(array $storedForm, array $submittedForm, array $mailInputPresence): array
    {
        $merged = array_merge($storedForm, $submittedForm);

        foreach (self::mailScalarKeys() as $key) {
            if (!self::wasMailInputPosted($mailInputPresence, $key) && array_key_exists($key, $storedForm)) {
                $merged[$key] = $storedForm[$key];
            }
        }

        if (!self::wasMailSectionPosted($mailInputPresence, 'smtp')) {
            foreach (self::mailSmtpToggleKeys() as $key) {
                if (array_key_exists($key, $storedForm)) {
                    $merged[$key] = $storedForm[$key];
                }
            }
        }

        if (!self::wasMailSectionPosted($mailInputPresence, 'reply') && array_key_exists('reply_enabled', $storedForm)) {
            $merged['reply_enabled'] = $storedForm['reply_enabled'];
        }

        $lineStep = (int) ($mailInputPresence['line_save_step'] ?? 0);
        $lineSaveCredential = trim((string) ($mailInputPresence['line_save_credential'] ?? ''));
        if ($lineSaveCredential !== '') {
            if ($lineSaveCredential === 'secret' || $lineSaveCredential === 'delete_secret') {
                $merged['line_channel_secret'] = $lineSaveCredential === 'delete_secret'
                    ? ''
                    : trim((string) ($submittedForm['line_channel_secret'] ?? ''));
            }
            if ($lineSaveCredential === 'token' || $lineSaveCredential === 'delete_token') {
                $merged['line_channel_access_token'] = $lineSaveCredential === 'delete_token'
                    ? ''
                    : trim((string) ($submittedForm['line_channel_access_token'] ?? ''));
            }
        } elseif ($lineStep > 0) {
            $stepMerged = self::mergeLineStep($submittedForm, $storedForm, $lineStep);
            foreach (self::lineFormKeys() as $key) {
                if (array_key_exists($key, $stepMerged)) {
                    $merged[$key] = $stepMerged[$key];
                }
            }
        } else {
            foreach (self::lineFormKeys() as $key) {
                if (array_key_exists($key, $storedForm)) {
                    $merged[$key] = $storedForm[$key];
                }
            }
        }

        if (empty($submittedForm['mail_smtp_clear_password']) && !empty($storedForm['mail_smtp_password'])) {
            $merged['mail_smtp_password'] = $storedForm['mail_smtp_password'];
        }

        return $merged;
    }

    /**
     * @param array<string, mixed> $post
     * @return array<string, mixed>
     */
    private static function collectMailInputPresence(array $post): array
    {
        $keys = [];
        foreach (array_merge(self::mailScalarKeys(), self::mailSmtpToggleKeys(), ['mail_smtp_password', 'mail_smtp_clear_password', 'line_channel_access_token', 'line_channel_secret', 'reply_enabled']) as $key) {
            $keys[$key] = array_key_exists($key, $post);
        }
        $keys['mail_attachment_max_bytes'] = array_key_exists('mail_attachment_max_mb', $post);
        if (!empty($post['reply_from_field_key_present'])) {
            $keys['reply_from_field_key'] = true;
        }

        $sections = ['smtp' => false, 'admin' => false, 'line' => false, 'reply' => false];
        $rawSections = $post['_mail_section_present'] ?? [];
        if (is_array($rawSections)) {
            foreach (array_keys($sections) as $section) {
                $sections[$section] = !empty($rawSections[$section]);
            }
        }

        return [
            'keys' => $keys,
            'sections' => $sections,
            'line_save_step' => max(0, min(3, (int) ($post['_line_save_step'] ?? 0))),
            'line_save_credential' => trim((string) ($post['_line_save_credential'] ?? '')),
        ];
    }

    /**
     * @param array<string, mixed> $post
     * @return array<string, mixed>
     */
    private static function collectBuilderMeta(array $post): array
    {
        $raw = $post['_builder_meta'] ?? [];
        if (!is_array($raw)) {
            $raw = [];
        }

        return [
            'field_count' => max(0, (int) ($raw['field_count'] ?? 0)),
            'field_keys' => self::decodeBuilderMetaKeyList($raw['field_keys'] ?? ''),
            'group_count' => max(0, (int) ($raw['group_count'] ?? 0)),
            'group_keys' => self::decodeBuilderMetaKeyList($raw['group_keys'] ?? ''),
            'input_page_count' => max(0, (int) ($raw['input_page_count'] ?? 0)),
            'branch_rule_count' => max(0, (int) ($raw['branch_rule_count'] ?? 0)),
            'input_var_count' => max(0, (int) ($raw['input_var_count'] ?? 0)),
        ];
    }

    /**
     * @param array<string, mixed> $post
     * @return array<string, mixed>
     */
    private static function collectBuilderPayload(array $post): array
    {
        $rawPayload = $post['builder_payload'] ?? '';
        if (!is_string($rawPayload) || trim($rawPayload) === '') {
            return ['present' => false];
        }

        $decoded = json_decode($rawPayload, true);
        if (!is_array($decoded)) {
            return [
                'present' => true,
                'errors' => ['項目設定JSONの形式が不正なため保存できませんでした。画面を再読み込みしてから再度お試しください。'],
            ];
        }

        return [
            'present' => true,
            'fields' => is_array($decoded['fields'] ?? null) ? $decoded['fields'] : [],
            'field_groups' => is_array($decoded['field_groups'] ?? null) ? $decoded['field_groups'] : [],
            'input_pages' => is_array($decoded['input_pages'] ?? null) ? $decoded['input_pages'] : [],
            'branch_rules' => is_array($decoded['branch_rules'] ?? null) ? $decoded['branch_rules'] : [],
            'errors' => [],
        ];
    }

    /**
     * @return array<int, string>
     */
    private static function decodeBuilderMetaKeyList(mixed $rawValue): array
    {
        if (!is_string($rawValue) || trim($rawValue) === '') {
            return [];
        }

        $decoded = json_decode($rawValue, true);
        if (!is_array($decoded)) {
            return [];
        }

        $keys = [];
        foreach ($decoded as $value) {
            $key = trim((string) $value);
            if ($key === '' || in_array($key, $keys, true)) {
                continue;
            }
            $keys[] = $key;
        }

        return $keys;
    }

    /**
     * @return array<int, string>
     */
    private static function mailScalarKeys(): array
    {
        return [
            'admin_emails',
            'mail_subject_admin',
            'mail_template_admin',
            'mail_transport',
            'mail_from_email',
            'mail_from_name',
            'mail_smtp_host',
            'mail_smtp_port',
            'mail_smtp_secure',
            'mail_smtp_username',
            'mail_smtp_timeout',
            'mail_smtp_ehlo_host',
            'submission_storage_mode',
            'mail_attachment_max_bytes',
            'smtp_tested_at',
            'smtp_test_fingerprint',
            'reply_from_field_key',
            'reply_subject',
            'reply_template',
            'line_notify_enabled',
            'line_push_to_id',
            'line_message_template',
        ];
    }

    /**
     * @return array<int, string>
     */
    private static function mailSmtpToggleKeys(): array
    {
        return [
            'mail_smtp_verify_peer',
            'mail_smtp_verify_peer_name',
            'mail_smtp_allow_self_signed',
        ];
    }

    /**
     * @param array<string, mixed> $mailInputPresence
     */
    private static function wasMailInputPosted(array $mailInputPresence, string $key): bool
    {
        return !empty($mailInputPresence['keys'][$key]);
    }

    /**
     * @param array<string, mixed> $mailInputPresence
     */
    private static function wasMailSectionPosted(array $mailInputPresence, string $section): bool
    {
        return !empty($mailInputPresence['sections'][$section]);
    }

    /**
     * @param array<int, array<string, mixed>> $blocks
     * @return array<int, array{id:string,label:string,html:string,position:int,visible:int,is_html:int}>
     */
    private static function normalizeDescriptionBlocks(array $blocks, bool $allowEmptyHtml = false, string $idPrefix = 'description'): array
    {
        $out = [];
        foreach ($blocks as $i => $block) {
            if (!is_array($block)) {
                continue;
            }
            $rawHtml = trim((string) ($block['html'] ?? ''));
            $isHtml = array_key_exists('is_html', $block)
                ? !empty($block['is_html'])
                : preg_match('/<\s*\/?[a-zA-Z][^>]*>/', $rawHtml) === 1;
            $html = $allowEmptyHtml ? $rawHtml : ($isHtml ? sanitize_rich_text_html($rawHtml) : $rawHtml);
            if (!$allowEmptyHtml && $html === '') {
                continue;
            }
            $id = trim((string) ($block['id'] ?? ''));
            if ($id === '') {
                $id = $idPrefix . '-' . $i;
            }
            $out[] = [
                'id' => $id,
                'label' => trim((string) ($block['label'] ?? '')),
                'html' => $html,
                'position' => isset($block['position']) && is_numeric($block['position']) ? max(0, (int) $block['position']) : 0,
                'visible' => !empty($block['visible']) ? 1 : 0,
                'is_html' => $isHtml ? 1 : 0,
            ];
        }

        if ($out === []) {
            $out[] = [
                'id' => $idPrefix . '-0',
                'label' => '',
                'html' => '',
                'position' => 0,
                'visible' => 1,
                'is_html' => 0,
            ];
        }

        return $out;
    }

    /**
     * @return array<int, array{id:string,label:string,html:string,position:int,visible:int,is_html:int}>
     */
    /**
     * @param mixed $raw
     * @return array<int, array<string, mixed>>
     */
    /**
     * @param array<int, array<string, mixed>> $rules
     */
    private static function hasActivePublishSchedule(array $rules): bool
    {
        foreach ($rules as $rule) {
            if (!empty($rule['visible']) && FormPublishSchedule::hasConfiguredDimension($rule)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param mixed $raw
     * @return array<int, array<string, mixed>>
     */
    private static function collectScheduleRules($raw, string $idPrefix): array
    {
        if (!is_array($raw)) {
            return [];
        }
        $rules = [];
        foreach ($raw as $i => $item) {
            if (!is_array($item) || !empty($item['_remove'])) {
                continue;
            }
            $rules[] = [
                'id' => trim((string) ($item['id'] ?? '')) !== '' ? trim((string) $item['id']) : $idPrefix . '-' . $i,
                'visible' => !empty($item['visible']) ? 1 : 0,
                'position' => isset($item['position']) && is_numeric($item['position']) ? (int) $item['position'] : count($rules),
                'start_at' => form_publish_date_from_input((string) ($item['start_at'] ?? '')),
                'end_at' => form_publish_date_from_input((string) ($item['end_at'] ?? '')),
                'weekdays' => form_publish_weekdays_from_post($item['weekdays'] ?? null),
                'holiday' => !empty($item['holiday']) ? 1 : 0,
                'daily_start_time' => form_publish_time_from_input((string) ($item['daily_start_time'] ?? '')),
                'daily_end_time' => form_publish_time_from_input((string) ($item['daily_end_time'] ?? '')),
            ];
        }

        return $idPrefix === 'unpublish'
            ? normalize_form_unpublish_rules($rules)
            : normalize_form_publish_rules($rules);
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @param array<int, string> $errors
     */
    private static function validateScheduleRules(array $rules, string $labelPrefix, array &$errors): void
    {
        foreach ($rules as $ruleIndex => $rule) {
            if (empty($rule['visible'])) {
                continue;
            }
            $ruleName = $labelPrefix . ((int) $ruleIndex + 1);
            $hasPeriod = trim((string) ($rule['start_at'] ?? '')) !== '' || trim((string) ($rule['end_at'] ?? '')) !== '';
            $hasWeekdays = isset($rule['weekdays']) && (int) $rule['weekdays'] > 0;
            $hasHoliday = !empty($rule['holiday']);
            $dailyStart = trim((string) ($rule['daily_start_time'] ?? ''));
            $dailyEnd = trim((string) ($rule['daily_end_time'] ?? ''));
            $hasTimeBand = $dailyStart !== '' && $dailyEnd !== '';
            if (!$hasPeriod && !$hasWeekdays && !$hasTimeBand && !$hasHoliday) {
                $errors[] = $ruleName . 'には、期間・曜日・祝日・時刻帯のいずれかを設定してください。';
            }
            if (($dailyStart !== '' && $dailyEnd === '') || ($dailyStart === '' && $dailyEnd !== '')) {
                $errors[] = $ruleName . 'の時刻帯は、開始時刻と終了時刻を両方入力してください。';
            }
            $startAt = trim((string) ($rule['start_at'] ?? ''));
            $endAt = trim((string) ($rule['end_at'] ?? ''));
            if ($startAt !== '' && $endAt !== '') {
                $startDt = form_publish_period_boundary($startAt, false);
                $endDt = form_publish_period_boundary($endAt, true);
                if ($startDt && $endDt && $startDt > $endDt) {
                    $errors[] = $ruleName . 'の公開期間は、開始日が終了日より前になるようにしてください。';
                }
            }
        }
    }

    /**
     * @param mixed $raw
     * @return array<int, array<string, mixed>>
     */
    private static function collectPublishRules($raw): array
    {
        return self::collectScheduleRules($raw, 'publish');
    }

    private static function collectContentBlocks(string $postKey, string $idPrefix, ?array $providedBlocks = null): array
    {
        $blocks = [];
        $rawBlocks = $providedBlocks ?? ($_POST[$postKey] ?? []);
        if (!is_array($rawBlocks)) {
            return $blocks;
        }

        foreach ($rawBlocks as $i => $block) {
            if (!is_array($block)) {
                continue;
            }
            $blocks[] = [
                'id' => trim((string) ($block['id'] ?? '')) !== '' ? trim((string) $block['id']) : $idPrefix . '-' . $i,
                'label' => trim((string) ($block['label'] ?? '')),
                'html' => (string) ($block['html'] ?? ''),
                'position' => isset($block['position']) && is_numeric($block['position']) ? max(0, (int) $block['position']) : 0,
                'visible' => !empty($block['visible']) ? 1 : 0,
                'is_html' => !empty($block['is_html']) ? 1 : 0,
            ];
        }

        return $blocks;
    }

    private static function hasVisibleContentBlocks(array $blocks): bool
    {
        foreach ($blocks as $block) {
            $content = !empty($block['is_html'])
                ? sanitize_rich_text_html($block['html'] ?? '')
                : trim((string) ($block['html'] ?? ''));
            if (!empty($block['visible']) && $content !== '') {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    private static function buildPreviewForm(array $form): array
    {
        $storedId = (int) ($_POST['_form_id'] ?? 0);
        $form = self::retainAdminOnlyFields($form, $storedId > 0 ? Form::find($storedId) : null);
        return array_merge($form, [
            'slug' => trim((string) ($form['slug'] ?? '')) !== '' ? (string) $form['slug'] : '__preview__',
        ]);
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $fieldGroups
     * @param array<int, array<string, mixed>> $inputPages
     * @return array<int, array{value:string,label:string}>
     */
    private static function replyFieldOptions(array $fields, array $fieldGroups, array $inputPages): array
    {
        return FormField::replyRecipientOptions($fields, $fieldGroups, $inputPages);
    }

    /**
     * @param mixed $raw
     * @return array<int, string>
     */
    private static function collectReplyFieldKeys($raw): array
    {
        return Form::replyFieldKeys($raw);
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<int, array<string, mixed>>
     */
    private static function preparePreviewFields(array $fields): array
    {
        $previewFields = [];
        foreach ($fields as $i => $field) {
            $fieldType = FormField::sanitizeType((string) ($field['type'] ?? 'text_multi'));
            $isDisplayOnly = FormField::isDisplayOnlyType($fieldType);
            $optionsJson = null;
            if (!$isDisplayOnly && in_array($fieldType, ['radio', 'checkbox', 'select'], true) && !empty($field['options'])) {
                $options = FormField::parseOptions($field['options']);
                if ($fieldType === 'checkbox') {
                    $optionsJson = FormField::encodeCheckboxSettings(
                        $options,
                        $field['checkbox_min_selections'] ?? '',
                        $field['checkbox_max_selections'] ?? ''
                    );
                } elseif ($fieldType === 'radio') {
                    $optionsJson = FormField::encodeChoiceSettings(
                        $options,
                        (string) ($field['radio_default_value'] ?? '')
                    );
                } else {
                    $optionsJson = json_encode($options, JSON_UNESCAPED_UNICODE);
                }
            } elseif ($fieldType === 'text_multi') {
                $optionsJson = FormField::encodeTextMultiSettings(
                    FormField::decodeTextMultiItems($field['multi_text_items'] ?? null)
                );
            } elseif ($fieldType === FormField::TYPE_POSTAL_CODE) {
                $optionsJson = FormField::encodePostalCodeSettings([
                    'postal_target_prefecture' => (string) ($field['postal_target_prefecture'] ?? ''),
                    'postal_target_city' => (string) ($field['postal_target_city'] ?? ''),
                ]);
            } elseif ($fieldType === 'file') {
                $optionsJson = FormField::encodeFileSettings(
                    [
                        'selection_mode' => FormField::normalizeFileSelectionMode((string) ($field['file_type_mode'] ?? FormField::FILE_SELECTION_CUSTOM)),
                        'allowed_extensions' => FormField::parseExtensionList($field['file_allowed_extensions'] ?? ''),
                        'convert_to_jpeg' => FormField::normalizeFileSelectionMode((string) ($field['file_type_mode'] ?? FormField::FILE_SELECTION_CUSTOM)) === FormField::FILE_SELECTION_IMAGE ? 1 : 0,
                    ]
                );
            } elseif ($fieldType === FormField::TYPE_MATRIX) {
                $optionsJson = FormField::encodeMatrixSettings(
                    FormField::parseOptions($field['matrix_rows'] ?? ''),
                    FormField::parseOptions($field['matrix_columns'] ?? ''),
                    (string) ($field['matrix_selection_type'] ?? 'radio')
                );
            } elseif (in_array($fieldType, ['textarea', 'number'], true)) {
                $optionsJson = FormField::encodeDefaultValueSettings((string) ($field['default_value'] ?? ''));
            } elseif ($fieldType === 'date') {
                $optionsJson = FormField::encodeDateDefaultSettings(
                    (string) ($field['date_default_mode'] ?? ''),
                    (string) ($field['date_default_value'] ?? '')
                );
            } elseif ($fieldType === 'time') {
                $optionsJson = FormField::encodeTimeDefaultSettings(
                    (string) ($field['time_default_mode'] ?? ''),
                    (string) ($field['time_default_value'] ?? '')
                );
            }

            $placeholder = isset($field['placeholder']) && $field['placeholder'] !== '' ? (string) $field['placeholder'] : null;
            if ($isDisplayOnly || in_array($fieldType, ['radio', 'checkbox', 'select', 'text_multi', 'file', FormField::TYPE_MATRIX], true)) {
                $placeholder = null;
            }

            $previewFields[] = [
                'id' => $i + 1,
                'form_id' => 0,
                'input_page_key' => FormField::sanitizeInputPageKey((string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY)),
                'parent_group_key' => FormFieldGroup::sanitizeGroupKey((string) ($field['parent_group_key'] ?? '')) ?: null,
                'sort_order' => isset($field['sort_order']) && is_numeric($field['sort_order']) ? (int) $field['sort_order'] : $i + 1,
                'field_key' => (string) ($field['field_key'] ?? ''),
                'label' => (string) ($field['label'] ?? ''),
                'show_label' => !array_key_exists('show_label', $field) || !empty($field['show_label']) ? 1 : 0,
                'visible' => !array_key_exists('visible', $field) || !empty($field['visible']) ? 1 : 0,
                'type' => $fieldType,
                'required' => !$isDisplayOnly && !empty($field['required']) ? 1 : 0,
                'min_length' => !$isDisplayOnly && !in_array($fieldType, ['radio', 'checkbox', 'select', 'file', FormField::TYPE_MATRIX], true) && isset($field['min_length']) && $field['min_length'] !== '' ? (int) $field['min_length'] : null,
                'max_length' => !$isDisplayOnly && !in_array($fieldType, ['radio', 'checkbox', 'select', 'file', FormField::TYPE_MATRIX], true) && isset($field['max_length']) && $field['max_length'] !== '' ? (int) $field['max_length'] : null,
                'exact_length' => !$isDisplayOnly && !in_array($fieldType, ['radio', 'checkbox', 'select', 'file', FormField::TYPE_MATRIX], true) && isset($field['exact_length']) && $field['exact_length'] !== '' ? (int) $field['exact_length'] : null,
                'regex' => !$isDisplayOnly && !in_array($fieldType, ['radio', 'select', 'file', FormField::TYPE_MATRIX], true) && isset($field['regex']) && $field['regex'] !== '' ? (string) $field['regex'] : null,
                'help_text' => (!$isDisplayOnly || in_array($fieldType, [FormField::TYPE_HEADING, FormField::TYPE_DESCRIPTION], true)) && isset($field['help_text']) && $field['help_text'] !== '' ? (string) $field['help_text'] : null,
                'placeholder' => $placeholder,
                'options_json' => $optionsJson,
                'file_allowed_extensions' => $fieldType === 'file' ? implode(', ', FormField::decodeFileSettings($optionsJson)['allowed_extensions']) : '',
                'file_type_mode' => $fieldType === 'file' ? FormField::decodeFileSettings($optionsJson)['selection_mode'] : FormField::FILE_SELECTION_CUSTOM,
                'file_convert_to_jpeg' => $fieldType === 'file' ? (int) FormField::decodeFileSettings($optionsJson)['convert_to_jpeg'] : 0,
            ];
        }

        return $previewFields;
    }

    /**
     * @param array<int, array<string, mixed>> $groups
     * @return array<int, array<string, mixed>>
     */
    private static function preparePreviewFieldGroups(array $groups): array
    {
        $previewGroups = [];
        foreach ($groups as $i => $group) {
            $previewGroups[] = [
                'id' => $i + 1,
                'form_id' => 0,
                'input_page_key' => FormField::sanitizeInputPageKey((string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY)),
                'parent_group_key' => FormFieldGroup::sanitizeGroupKey((string) ($group['parent_group_key'] ?? '')) ?: null,
                'sort_order' => isset($group['sort_order']) && is_numeric($group['sort_order']) ? (int) $group['sort_order'] : $i + 1,
                'group_key' => FormFieldGroup::sanitizeGroupKey((string) ($group['group_key'] ?? '')),
                'label' => (string) ($group['label'] ?? ''),
                'show_label' => !array_key_exists('show_label', $group) || !empty($group['show_label']) ? 1 : 0,
                'description' => (string) ($group['description'] ?? ''),
                'visible' => !array_key_exists('visible', $group) || !empty($group['visible']) ? 1 : 0,
            ];
        }

        return $previewGroups;
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, string>
     */
    private static function branchControlledFieldKeysForPreview(array $rules, ?string $triggerPageKey = null): array
    {
        $keys = [];
        foreach (FormBranchRule::normalizeRules($rules) as $rule) {
            if ($triggerPageKey !== null && (string) ($rule['trigger_page_key'] ?? FormInputPage::DEFAULT_KEY) !== $triggerPageKey) {
                continue;
            }
            if (
                !empty($rule['enabled'])
                && ($rule['action_type'] ?? '') === FormBranchRule::ACTION_SHOW_FIELD
                && ($rule['target_type'] ?? FormBranchRule::TARGET_FIELD) === FormBranchRule::TARGET_FIELD
            ) {
                $keys[] = (string) ($rule['target_key'] ?? '');
            }
        }
        return array_values(array_unique(array_filter($keys, static fn($key): bool => $key !== '')));
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, string>
     */
    private static function branchControlledGroupKeysForPreview(array $rules, ?string $triggerPageKey = null): array
    {
        $keys = [];
        foreach (FormBranchRule::normalizeRules($rules) as $rule) {
            if ($triggerPageKey !== null && (string) ($rule['trigger_page_key'] ?? FormInputPage::DEFAULT_KEY) !== $triggerPageKey) {
                continue;
            }
            if (
                !empty($rule['enabled'])
                && ($rule['action_type'] ?? '') === FormBranchRule::ACTION_SHOW_FIELD
                && ($rule['target_type'] ?? FormBranchRule::TARGET_FIELD) === FormBranchRule::TARGET_GROUP
            ) {
                $keys[] = (string) ($rule['target_key'] ?? '');
            }
        }
        return array_values(array_unique(array_filter($keys, static fn($key): bool => $key !== '')));
    }

    private static function defaultField(): array
    {
        return [
            'input_page_key' => FormInputPage::DEFAULT_KEY,
            'parent_group_key' => null,
            'sort_order' => 1,
            'field_key' => FieldKey::generateUuidV4(),
            'label' => 'お名前',
            'show_label' => 1,
            'visible' => 1,
            'type'  => 'text_multi',
            'required' => 1,
            'min_length' => '',
            'max_length' => 100,
            'exact_length' => '',
            'regex' => null,
            'help_text' => '',
            'placeholder' => '',
            'pair_label_left' => '',
            'pair_label_right' => '',
            'pair_placeholder_left' => '',
            'pair_placeholder_right' => '',
            'multi_text_items' => '',
            'postal_target_prefecture' => '',
            'postal_target_city' => '',
            'default_value' => '',
            'date_default_mode' => '',
            'date_default_value' => '',
            'time_default_mode' => '',
            'time_default_value' => '',
            'radio_default_value' => '',
            'checkbox_limit_enabled' => 0,
            'checkbox_min_selections' => '',
            'checkbox_max_selections' => '',
            'options' => '',
            'file_allowed_extensions' => '',
            'file_type_mode' => FormField::FILE_SELECTION_CUSTOM,
            'file_convert_to_jpeg' => 0,
            'matrix_rows' => '',
            'matrix_columns' => '',
            'matrix_selection_type' => 'radio',
        ];
    }

    private function notFound(): void
    {
        http_response_code(404);
        echo '<!doctype html><meta charset="utf-8"><title>404</title><h1>404</h1>';
        exit;
    }

    private static function requireCanManageFormForPreviewPost(): void
    {
        $formId = (int) ($_POST['_form_id'] ?? 0);
        if ($formId > 0) {
            Auth::requireCanManageForm($formId);
            return;
        }
        Auth::requireCanManageForms();
    }
}
