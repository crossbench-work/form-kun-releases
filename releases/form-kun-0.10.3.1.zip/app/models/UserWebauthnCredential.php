<?php
namespace Models;

use Core\Database;

class UserWebauthnCredential
{
    /** @return list<array<string, mixed>> */
    public static function listForUser(int $userId): array
    {
        return Database::fetchAll(
            'SELECT id, user_id, credential_id, sign_count, transports, name, created_at, last_used_at
             FROM user_webauthn_credentials WHERE user_id = ? ORDER BY id ASC',
            [$userId]
        );
    }

    public static function find(int $id): ?array
    {
        return Database::fetchOne('SELECT * FROM user_webauthn_credentials WHERE id = ?', [$id]);
    }

    public static function findByCredentialId(string $credentialIdBinary): ?array
    {
        return Database::fetchOne(
            'SELECT * FROM user_webauthn_credentials WHERE credential_id = ?',
            [$credentialIdBinary]
        );
    }

    public static function insert(
        int $userId,
        string $credentialIdBinary,
        string $publicKeyBinary,
        string $userHandleBinary,
        int $signCount,
        array $transports,
        ?string $name
    ): int {
        $now = date('Y-m-d H:i:s');
        $transportsJson = $transports !== [] ? json_encode(array_values($transports), JSON_UNESCAPED_UNICODE) : null;
        Database::execute(
            'INSERT INTO user_webauthn_credentials
                (user_id, credential_id, public_key, user_handle, sign_count, transports, name, created_at, last_used_at)
             VALUES (?,?,?,?,?,?,?,?,?)',
            [
                $userId,
                $credentialIdBinary,
                $publicKeyBinary,
                $userHandleBinary,
                max(0, $signCount),
                $transportsJson,
                $name !== null && $name !== '' ? mb_substr($name, 0, 100) : null,
                $now,
                $now,
            ]
        );

        return Database::lastInsertId();
    }

    public static function updateAfterAssertion(int $id, int $signCount): void
    {
        Database::execute(
            'UPDATE user_webauthn_credentials SET sign_count = ?, last_used_at = ? WHERE id = ?',
            [max(0, $signCount), date('Y-m-d H:i:s'), $id]
        );
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM user_webauthn_credentials WHERE id = ?', [$id]);
    }

    public static function countForUser(int $userId): int
    {
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS c FROM user_webauthn_credentials WHERE user_id = ?',
            [$userId]
        );

        return (int) ($row['c'] ?? 0);
    }
}
