<?php
namespace Models;

use Core\Database;

class FormVersion
{
    public const ACTION_CREATE = 'create';
    public const ACTION_UPDATE = 'update';
    public const ACTION_RESTORE = 'restore';
    public const ACTION_DUPLICATE = 'duplicate';
    public const ACTION_IMPORT = 'import';
    public const ACTION_INTERVAL = 'interval';
    public const ACTION_LOGIN = 'login';
    public const ACTION_LOGOUT = 'logout';
    public const DEFAULT_INTERVAL_MINUTES = 10;
    public const DEFAULT_RETENTION_LIMIT = 100;

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function forForm(int $formId): array
    {
        return Database::fetchAll(
            'SELECT * FROM form_versions WHERE form_id = ? ORDER BY version_number DESC, id DESC',
            [$formId]
        );
    }

    /**
     * @return array<string, mixed>|null
     */
    public static function findForForm(int $formId, int $versionId): ?array
    {
        return Database::fetchOne(
            'SELECT * FROM form_versions WHERE form_id = ? AND id = ?',
            [$formId, $versionId]
        );
    }

    public static function deleteForForm(int $formId, int $versionId): void
    {
        Database::execute(
            'DELETE FROM form_versions WHERE form_id = ? AND id = ?',
            [$formId, $versionId]
        );
    }

    public static function setPinned(int $formId, int $versionId, bool $pinned): void
    {
        Database::execute(
            'UPDATE form_versions SET pinned = ? WHERE form_id = ? AND id = ?',
            [$pinned ? 1 : 0, $formId, $versionId]
        );
        if (!$pinned) {
            self::pruneUnpinned($formId);
        }
    }

    /**
     * @param array<string, mixed>|null $actor
     */
    public static function createSnapshot(int $formId, string $actionType, ?array $actor = null): int
    {
        $snapshot = self::buildSnapshot($formId);
        $versionRow = Database::fetchOne(
            'SELECT MAX(version_number) AS max_version FROM form_versions WHERE form_id = ?',
            [$formId]
        );
        $versionNumber = (int) ($versionRow['max_version'] ?? 0) + 1;
        $actorName = trim((string) (($actor['display_name'] ?? '') !== '' ? $actor['display_name'] : ($actor['username'] ?? '')));
        $now = date('Y-m-d H:i:s');

        Database::execute(
            'INSERT INTO form_versions (
                form_id, version_number, action_type, created_by_user_id, created_by_name, snapshot_json, created_at
             ) VALUES (?,?,?,?,?,?,?)',
            [
                $formId,
                $versionNumber,
                self::sanitizeActionType($actionType),
                isset($actor['id']) ? (int) $actor['id'] : null,
                $actorName !== '' ? $actorName : null,
                json_encode($snapshot, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                $now,
            ]
        );

        self::pruneUnpinned($formId);

        return Database::lastInsertId();
    }

    /**
     * @param array<string, mixed>|null $actor
     */
    public static function createSnapshotForUpdate(int $formId, ?array $actor = null): ?int
    {
        if (!self::saveOnSaveEnabled()) {
            return null;
        }

        return self::createSnapshot($formId, self::ACTION_UPDATE, $actor);
    }

    /**
     * @param array<string, mixed>|null $actor
     */
    public static function createIntervalSnapshotIfDue(int $formId, ?array $actor = null): ?int
    {
        if (!self::isIntervalDue($formId)) {
            return null;
        }

        return self::createSnapshot($formId, self::ACTION_INTERVAL, $actor);
    }

    /**
     * @param array<string, mixed>|null $actor
     */
    public static function createLifecycleSnapshots(string $actionType, ?array $actor = null): void
    {
        if (
            ($actionType === self::ACTION_LOGIN && !self::saveOnLoginEnabled())
            || ($actionType === self::ACTION_LOGOUT && !self::saveOnLogoutEnabled())
        ) {
            return;
        }

        foreach (Form::all() as $form) {
            $formId = (int) ($form['id'] ?? 0);
            if ($formId <= 0 || !self::isLifecycleDue($formId)) {
                continue;
            }
            self::createSnapshot($formId, $actionType, $actor);
        }
    }

    /**
     * @return array{form: array<string, mixed>, input_pages: array<int, array<string, mixed>>, field_groups: array<int, array<string, mixed>>, fields: array<int, array<string, mixed>>, branch_rules: array<int, array<string, mixed>>}
     */
    public static function decodeSnapshot(array $version): array
    {
        $decoded = json_decode((string) ($version['snapshot_json'] ?? ''), true);
        if (!is_array($decoded)) {
            throw new \RuntimeException('版データの形式が不正です。');
        }

        $form = is_array($decoded['form'] ?? null) ? $decoded['form'] : [];
        if ($form === []) {
            throw new \RuntimeException('版データにフォーム本体が含まれていません。');
        }

        return [
            'form' => $form,
            'input_pages' => is_array($decoded['input_pages'] ?? null) ? array_values($decoded['input_pages']) : [],
            'field_groups' => is_array($decoded['field_groups'] ?? null) ? array_values($decoded['field_groups']) : [],
            'fields' => is_array($decoded['fields'] ?? null) ? array_values($decoded['fields']) : [],
            'branch_rules' => is_array($decoded['branch_rules'] ?? null) ? array_values($decoded['branch_rules']) : [],
        ];
    }

    public static function actionLabel(string $actionType): string
    {
        return match (self::sanitizeActionType($actionType)) {
            self::ACTION_CREATE => '新規作成',
            self::ACTION_DUPLICATE => '複製',
            self::ACTION_IMPORT => 'インポート',
            self::ACTION_RESTORE => '復元',
            self::ACTION_INTERVAL => '間隔保存',
            self::ACTION_LOGIN => 'ログイン時保存',
            self::ACTION_LOGOUT => 'ログアウト時保存',
            default => '保存',
        };
    }

    public static function intervalMinutes(): int
    {
        $stored = AppSetting::get(AppSetting::KEY_FORM_VERSION_INTERVAL_MINUTES);
        $value = filter_var($stored, FILTER_VALIDATE_INT);
        if ($value === false || $value < 0 || $value > 10080) {
            return self::DEFAULT_INTERVAL_MINUTES;
        }
        return (int) $value;
    }

    public static function retentionLimit(): int
    {
        $stored = AppSetting::get(AppSetting::KEY_FORM_VERSION_RETENTION_LIMIT);
        $value = filter_var($stored, FILTER_VALIDATE_INT);
        if ($value === false || $value < 1 || $value > 10000) {
            return self::DEFAULT_RETENTION_LIMIT;
        }
        return (int) $value;
    }

    public static function saveOnSaveEnabled(): bool
    {
        return AppSetting::get(AppSetting::KEY_FORM_VERSION_SAVE_ON_SAVE) === '1';
    }

    public static function saveOnLoginEnabled(): bool
    {
        return AppSetting::get(AppSetting::KEY_FORM_VERSION_SAVE_ON_LOGIN) === '1';
    }

    public static function saveOnLogoutEnabled(): bool
    {
        return AppSetting::get(AppSetting::KEY_FORM_VERSION_SAVE_ON_LOGOUT) === '1';
    }

    public static function pruneAllUnpinned(): void
    {
        foreach (Form::all() as $form) {
            $formId = (int) ($form['id'] ?? 0);
            if ($formId > 0) {
                self::pruneUnpinned($formId);
            }
        }
    }

    private static function sanitizeActionType(string $actionType): string
    {
        return match ($actionType) {
            self::ACTION_CREATE,
            self::ACTION_UPDATE,
            self::ACTION_RESTORE,
            self::ACTION_DUPLICATE,
            self::ACTION_IMPORT,
            self::ACTION_INTERVAL,
            self::ACTION_LOGIN,
            self::ACTION_LOGOUT => $actionType,
            default => self::ACTION_UPDATE,
        };
    }

    private static function isIntervalDue(int $formId): bool
    {
        $intervalMinutes = self::intervalMinutes();
        if ($intervalMinutes <= 0) {
            return false;
        }

        return self::hasElapsedSinceLatest($formId, $intervalMinutes);
    }

    private static function isLifecycleDue(int $formId): bool
    {
        $intervalMinutes = self::intervalMinutes();
        if ($intervalMinutes <= 0) {
            return true;
        }

        return self::hasElapsedSinceLatest($formId, $intervalMinutes);
    }

    private static function hasElapsedSinceLatest(int $formId, int $intervalMinutes): bool
    {
        if ($intervalMinutes <= 0) {
            return true;
        }

        $latest = Database::fetchOne(
            'SELECT created_at FROM form_versions WHERE form_id = ? ORDER BY created_at DESC, id DESC LIMIT 1',
            [$formId]
        );
        if ($latest === null || trim((string) ($latest['created_at'] ?? '')) === '') {
            return true;
        }

        $lastTimestamp = strtotime((string) $latest['created_at']);
        if ($lastTimestamp === false) {
            return true;
        }

        return (time() - $lastTimestamp) >= ($intervalMinutes * 60);
    }

    private static function pruneUnpinned(int $formId): void
    {
        $limit = self::retentionLimit();
        if ($limit < 1) {
            return;
        }

        $rows = Database::fetchAll(
            'SELECT id FROM form_versions WHERE form_id = ? AND pinned = 0 ORDER BY version_number DESC, id DESC',
            [$formId]
        );
        if (count($rows) <= $limit) {
            return;
        }

        $deleteIds = array_map(
            static fn(array $row): int => (int) ($row['id'] ?? 0),
            array_slice($rows, $limit)
        );
        $deleteIds = array_values(array_filter($deleteIds, static fn(int $id): bool => $id > 0));
        if ($deleteIds === []) {
            return;
        }

        $placeholders = implode(',', array_fill(0, count($deleteIds), '?'));
        Database::execute(
            "DELETE FROM form_versions WHERE form_id = ? AND pinned = 0 AND id IN ($placeholders)",
            array_merge([$formId], $deleteIds)
        );
    }

    /**
     * @return array{form: array<string, mixed>, input_pages: array<int, array<string, mixed>>, field_groups: array<int, array<string, mixed>>, fields: array<int, array<string, mixed>>, branch_rules: array<int, array<string, mixed>>}
     */
    private static function buildSnapshot(int $formId): array
    {
        $form = Form::find($formId);
        if ($form === null) {
            throw new \RuntimeException('版保存対象のフォームが見つかりません。');
        }

        unset($form['mail_smtp_password'], $form['smtp_tested_at'], $form['smtp_test_fingerprint'], $form['line_channel_access_token'], $form['line_channel_secret']);

        return [
            'form' => $form,
            'input_pages' => FormInputPage::forForm($formId, $form),
            'field_groups' => FormFieldGroup::forForm($formId, true),
            'fields' => FormField::forForm($formId, true),
            'branch_rules' => FormBranchRule::forForm($formId),
        ];
    }
}
