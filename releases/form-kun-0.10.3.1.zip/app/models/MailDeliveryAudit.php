<?php
namespace Models;

use Core\Database;

class MailDeliveryAudit
{
    public static function record(int $formId, string $route, string $status, ?string $errorCode, array $attachments): void
    {
        $count = 0;
        $bytes = 0;
        foreach ($attachments as $attachment) {
            if (!is_array($attachment)) {
                continue;
            }
            $count++;
            $bytes += max(0, (int) ($attachment['size'] ?? 0));
        }
        try {
            Database::execute(
                'INSERT INTO mail_delivery_audits (form_id, route, delivery_status, error_code, attachment_count, attachment_total_bytes, created_at) VALUES (?,?,?,?,?,?,?)',
                [$formId, substr($route, 0, 16), substr($status, 0, 16), $errorCode !== null ? substr($errorCode, 0, 64) : null, $count, $bytes, date('Y-m-d H:i:s')]
            );
            if (random_int(1, 100) === 1) {
                self::prune();
            }
        } catch (\Throwable $e) {
            // 監査記録の障害で受付結果を変えない。入力由来情報はログへ出さない。
            error_log('[formkun] mail delivery audit write failed');
        }
    }

    public static function prune(): void
    {
        Database::execute('DELETE FROM mail_delivery_audits WHERE created_at < ?', [date('Y-m-d H:i:s', time() - 90 * 86400)]);
    }
}
