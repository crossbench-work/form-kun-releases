<?php
namespace Models;

use Core\Database;

class FormField
{
    public const TYPE_HEADING = 'heading';
    public const TYPE_DESCRIPTION = 'description';
    public const TYPE_DIVIDER = 'divider';
    public const TYPE_MATRIX = 'matrix';
    public const TYPE_POSTAL_CODE = 'postal_code';
    public const FILE_SELECTION_IMAGE = 'image';
    public const FILE_SELECTION_CUSTOM = 'custom';

    /**
     * DB の regex 列（JSON 配列または従来の1本文字列）をパターン配列に。
     *
     * @return string[]
     */
    public static function decodeRegexPatterns(?string $stored): array
    {
        if ($stored === null) {
            return [];
        }
        $stored = trim($stored);
        if ($stored === '') {
            return [];
        }
        $decoded = json_decode($stored, true);
        if (is_array($decoded) && array_keys($decoded) === range(0, count($decoded) - 1)) {
            $out = [];
            foreach ($decoded as $p) {
                if (!is_string($p)) {
                    continue;
                }
                $p = trim($p);
                if ($p !== '') {
                    $out[] = $p;
                }
            }
            return $out;
        }

        return [$stored];
    }

    /**
     * @param string[] $patterns
     */
    public static function encodeRegexPatterns(array $patterns): ?string
    {
        $clean = [];
        foreach ($patterns as $p) {
            $p = trim((string) $p);
            if ($p !== '') {
                $clean[] = $p;
            }
        }
        if (count($clean) === 0) {
            return null;
        }

        return json_encode(array_values($clean), JSON_UNESCAPED_UNICODE);
    }

    /**
     * 入力タイプの内部値 => 管理画面・一覧向け日本語ラベル（表示順維持）。
     *
     * @return array<string, string>
     */
    public static function TYPE_LABELS(): array
    {
        return [
            'text_multi' => '1行テキスト',
            'textarea' => '複数行テキスト',
            self::TYPE_POSTAL_CODE => '郵便番号',
            'address' => '住所',
            self::TYPE_MATRIX => 'マトリックス',
            'email' => 'メールアドレス',
            'tel' => '電話番号',
            'number' => '数値',
            'date' => '日付',
            'time' => '時間（時:分）',
            'radio' => 'ラジオボタン',
            'checkbox' => 'チェックボックス',
            'select' => 'プルダウン（選択）',
            'file' => 'ファイル添付',
            self::TYPE_HEADING => '見出し',
            self::TYPE_DESCRIPTION => '説明文',
            self::TYPE_DIVIDER => '罫線',
        ];
    }

    public static function ALLOWED_TYPES(): array
    {
        return array_keys(self::TYPE_LABELS());
    }

    public static function typeLabel(string $type): string
    {
        $type = self::normalizeType($type);
        $labels = self::TYPE_LABELS();

        return $labels[$type] ?? $type;
    }

    public static function normalizeType(string $type): string
    {
        if (in_array($type, ['text', 'text_pair'], true)) {
            return 'text_multi';
        }

        return $type;
    }

    public static function sanitizeType(string $type): string
    {
        $type = self::normalizeType($type);
        return array_key_exists($type, self::TYPE_LABELS()) ? $type : 'text_multi';
    }

    public static function isDisplayOnlyType(string $type): bool
    {
        return in_array(self::normalizeType($type), [self::TYPE_HEADING, self::TYPE_DESCRIPTION, self::TYPE_DIVIDER], true);
    }

    public static function forForm(int $formId, bool $includeHidden = false): array
    {
        $fields = Database::fetchAll(
            'SELECT * FROM form_fields WHERE form_id = ? ORDER BY input_page_key ASC, sort_order ASC, id ASC',
            [$formId]
        );

        return array_values(array_filter(array_map([self::class, 'normalizeField'], $fields), static function ($field) use ($includeHidden): bool {
            return is_array($field)
                && !self::isAgreementFieldRecord($field)
                && ($includeHidden || !empty($field['visible']));
        }));
    }

    /**
     * 通知本文・送信詳細向けに、フォーム表示順の送信対象項目だけを返す。
     *
     * @return array<int, array<string, mixed>>
     */
    public static function orderedSubmittableForForm(int $formId, bool $includeHidden = true): array
    {
        return self::orderedSubmittable(
            self::forForm($formId, true),
            FormFieldGroup::forForm($formId, true),
            FormInputPage::forForm($formId),
            $includeHidden
        );
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $groups
     * @param array<int, array<string, mixed>> $inputPages
     * @return array<int, array<string, mixed>>
     */
    public static function orderedSubmittable(array $fields, array $groups, array $inputPages, bool $includeHidden = true): array
    {
        $ordered = [];
        $seenFieldKeys = [];
        $pageKeys = [];

        foreach ($inputPages as $page) {
            $pageKey = FormInputPage::sanitizePageKey((string) ($page['page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($pageKey !== '' && !in_array($pageKey, $pageKeys, true)) {
                $pageKeys[] = $pageKey;
            }
        }
        foreach ($fields as $field) {
            $pageKey = self::sanitizeInputPageKey((string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
            if (!in_array($pageKey, $pageKeys, true)) {
                $pageKeys[] = $pageKey;
            }
        }
        foreach ($groups as $group) {
            $pageKey = self::sanitizeInputPageKey((string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
            if (!in_array($pageKey, $pageKeys, true)) {
                $pageKeys[] = $pageKey;
            }
        }

        $appendNode = static function (array $node) use (&$appendNode, &$ordered, &$seenFieldKeys, $fields, $groups, $includeHidden): void {
            if (($node['kind'] ?? '') === 'field') {
                $field = $node['item'] ?? null;
                if (!is_array($field) || self::isDisplayOnlyType((string) ($field['type'] ?? ''))) {
                    return;
                }
                if (!$includeHidden && empty($field['visible'])) {
                    return;
                }
                $fieldKey = (string) ($field['field_key'] ?? '');
                if ($fieldKey === '' || isset($seenFieldKeys[$fieldKey])) {
                    return;
                }
                $seenFieldKeys[$fieldKey] = true;
                $ordered[] = $field;
                return;
            }

            $group = $node['item'] ?? null;
            if (!is_array($group)) {
                return;
            }
            $groupKey = (string) ($group['group_key'] ?? '');
            if ($groupKey === '') {
                return;
            }
            foreach (FormFieldGroup::childrenForParent($fields, $groups, (string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY), $groupKey) as $childNode) {
                $appendNode($childNode);
            }
        };

        foreach ($pageKeys as $pageKey) {
            foreach (FormFieldGroup::childrenForParent($fields, $groups, $pageKey, null) as $node) {
                $appendNode($node);
            }
        }

        foreach ($fields as $field) {
            $fieldKey = (string) ($field['field_key'] ?? '');
            if ($fieldKey === '' || isset($seenFieldKeys[$fieldKey])) {
                continue;
            }
            if (self::isDisplayOnlyType((string) ($field['type'] ?? ''))) {
                continue;
            }
            if (!$includeHidden && empty($field['visible'])) {
                continue;
            }
            $seenFieldKeys[$fieldKey] = true;
            $ordered[] = $field;
        }

        return $ordered;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $groups
     * @param array<int, array<string, mixed>> $inputPages
     * @return array<int, array{value:string,label:string}>
     */
    public static function replyRecipientOptions(array $fields, array $groups, array $inputPages): array
    {
        $orderedFields = self::orderedSubmittable($fields, $groups, $inputPages, false);
        $pageTitles = [];
        foreach ($inputPages as $index => $page) {
            $pageKey = FormInputPage::sanitizePageKey((string) ($page['page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($pageKey === '') {
                continue;
            }
            $title = trim((string) ($page['title'] ?? ''));
            if ($title === '') {
                $title = '入力画面 ' . ((int) $index + 1);
            }
            $pageTitles[$pageKey] = $title;
        }
        $withPageTitle = count($pageTitles) > 1;
        $options = [];

        foreach ($orderedFields as $field) {
            if (self::normalizeType((string) ($field['type'] ?? '')) !== 'email') {
                continue;
            }
            $fieldKey = trim((string) ($field['field_key'] ?? ''));
            if ($fieldKey === '') {
                continue;
            }
            $fieldLabel = trim((string) ($field['label'] ?? ''));
            if ($fieldLabel === '') {
                $fieldLabel = $fieldKey;
            }
            $label = $fieldLabel === $fieldKey ? $fieldKey : $fieldLabel . '（' . $fieldKey . '）';
            if ($withPageTitle) {
                $pageKey = self::sanitizeInputPageKey((string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
                $pageTitle = $pageTitles[$pageKey] ?? $pageKey;
                $label = $pageTitle . ' / ' . $label;
            }
            $options[] = [
                'value' => $fieldKey,
                'label' => $label,
            ];
        }

        return $options;
    }

    /**
     * フォームの項目をまるごと置き換え。
     *
     * @param array<int, array> $fields
     */
    public static function replaceForForm(int $formId, array $fields, bool $useTransaction = true): void
    {
        $replace = static function () use ($formId, $fields): void {
            Database::execute('DELETE FROM form_fields WHERE form_id = ?', [$formId]);
            $order = 0;
            foreach ($fields as $f) {
                if (self::isAgreementFieldRecord($f)) {
                    continue;
                }
                $order++;
                $type = self::sanitizeType((string) ($f['type'] ?? 'text_multi'));
                $optionsJson = null;
                if (self::isDisplayOnlyType($type)) {
                    $optionsJson = null;
                } elseif (in_array($type, ['radio','checkbox','select'], true) && !empty($f['options'])) {
                    $opts = self::parseOptions($f['options']);
                    if ($type === 'checkbox') {
                        $optionsJson = self::encodeCheckboxSettings(
                            $opts,
                            $f['checkbox_min_selections'] ?? '',
                            $f['checkbox_max_selections'] ?? ''
                        );
                    } elseif ($type === 'radio') {
                        $optionsJson = self::encodeChoiceSettings(
                            $opts,
                            (string) ($f['radio_default_value'] ?? '')
                        );
                    } else {
                        $optionsJson = json_encode($opts, JSON_UNESCAPED_UNICODE);
                    }
                } elseif ($type === 'text_multi') {
                    $optionsJson = self::encodeTextMultiSettings(
                        self::decodeTextMultiItems($f['multi_text_items'] ?? null)
                    );
                } elseif ($type === self::TYPE_POSTAL_CODE) {
                    $optionsJson = self::encodePostalCodeSettings([
                        'postal_target_prefecture' => (string) ($f['postal_target_prefecture'] ?? ''),
                        'postal_target_city' => (string) ($f['postal_target_city'] ?? ''),
                    ]);
                } elseif ($type === 'file') {
                    $optionsJson = self::encodeFileSettings(
                        [
                            'selection_mode' => self::normalizeFileSelectionMode((string) ($f['file_type_mode'] ?? self::FILE_SELECTION_CUSTOM)),
                            'allowed_extensions' => self::parseExtensionList($f['file_allowed_extensions'] ?? []),
                            'convert_to_jpeg' => !empty($f['file_convert_to_jpeg']) ? 1 : 0,
                        ]
                    );
                } elseif ($type === self::TYPE_MATRIX) {
                    $optionsJson = self::encodeMatrixSettings(
                        self::parseOptions($f['matrix_rows'] ?? []),
                        self::parseOptions($f['matrix_columns'] ?? []),
                        (string) ($f['matrix_selection_type'] ?? 'radio')
                    );
                } elseif (in_array($type, ['textarea', 'number'], true)) {
                    $optionsJson = self::encodeDefaultValueSettings((string) ($f['default_value'] ?? ''));
                } elseif ($type === 'date') {
                    $optionsJson = self::encodeDateDefaultSettings(
                        (string) ($f['date_default_mode'] ?? ''),
                        (string) ($f['date_default_value'] ?? '')
                    );
                } elseif ($type === 'time') {
                    $optionsJson = self::encodeTimeDefaultSettings(
                        (string) ($f['time_default_mode'] ?? ''),
                        (string) ($f['time_default_value'] ?? '')
                    );
                }
                $placeholder = isset($f['placeholder']) && $f['placeholder'] !== '' ? (string) $f['placeholder'] : null;
                if (in_array($type, ['radio', 'checkbox', 'select', 'text_multi', 'file', self::TYPE_MATRIX], true)) {
                    $placeholder = null;
                }
                $minLength = isset($f['min_length']) && $f['min_length'] !== '' ? (int) $f['min_length'] : null;
                $maxLength = isset($f['max_length']) && $f['max_length'] !== '' ? (int) $f['max_length'] : null;
                $exactLength = isset($f['exact_length']) && $f['exact_length'] !== '' ? (int) $f['exact_length'] : null;
                if (in_array($type, ['radio', 'checkbox', 'select', 'file', self::TYPE_MATRIX], true)) {
                    $minLength = null;
                    $maxLength = null;
                    $exactLength = null;
                }
                $required = !empty($f['required']) ? 1 : 0;
                $regex = isset($f['regex']) && $f['regex'] !== null && $f['regex'] !== ''
                    ? (string) $f['regex']
                    : null;
                if (in_array($type, ['radio', 'select', 'file', self::TYPE_MATRIX], true)) {
                    $regex = null;
                }
                $helpText = isset($f['help_text']) && $f['help_text'] !== '' ? (string) $f['help_text'] : null;
                if (self::isDisplayOnlyType($type)) {
                    $required = 0;
                    $minLength = null;
                    $maxLength = null;
                    $exactLength = null;
                    $regex = null;
                    $placeholder = null;
                    if (!in_array($type, [self::TYPE_HEADING, self::TYPE_DESCRIPTION], true)) {
                        $helpText = null;
                    }
                }
                $parentGroupKey = FormFieldGroup::sanitizeGroupKey((string) ($f['parent_group_key'] ?? ''));
                Database::execute(
                    'INSERT INTO form_fields (
                        form_id, input_page_key, parent_group_key, sort_order, field_key, label, show_label, visible, type,
                        required, min_length, max_length, exact_length, regex, help_text, placeholder, options_json
                     ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    [
                        $formId,
                        self::sanitizeInputPageKey((string) ($f['input_page_key'] ?? FormInputPage::DEFAULT_KEY)),
                        $parentGroupKey !== '' ? $parentGroupKey : null,
                        isset($f['sort_order']) && is_numeric($f['sort_order']) ? (int) $f['sort_order'] : $order,
                        $f['field_key'],
                        $f['label'],
                        !array_key_exists('show_label', $f) || !empty($f['show_label']) ? 1 : 0,
                        !array_key_exists('visible', $f) || !empty($f['visible']) ? 1 : 0,
                        $type,
                        $required,
                        $minLength,
                        $maxLength,
                        $exactLength,
                        $regex,
                        $helpText,
                        $placeholder,
                        $optionsJson,
                    ]
                );
            }
        };

        if ($useTransaction) {
            Database::transaction($replace);
            return;
        }

        $replace();
    }

    /**
     * エクスポート済みのDB表現（options_jsonを含む）から項目を復元する。
     *
     * @param array<int, array<string, mixed>> $fields
     */
    public static function replaceStoredForForm(int $formId, array $fields, bool $useTransaction = true): void
    {
        $replace = static function () use ($formId, $fields): void {
            Database::execute('DELETE FROM form_fields WHERE form_id = ?', [$formId]);
            foreach (array_values($fields) as $i => $field) {
                $type = self::sanitizeType((string) ($field['type'] ?? ''));
                $parentGroupKey = FormFieldGroup::sanitizeGroupKey((string) ($field['parent_group_key'] ?? '')) ?: null;
                Database::execute(
                    'INSERT INTO form_fields (
                        form_id, input_page_key, parent_group_key, sort_order, field_key, label, show_label, visible, type,
                        required, min_length, max_length, exact_length, regex, help_text, placeholder, options_json
                     ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    [
                        $formId,
                        self::sanitizeInputPageKey((string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY)),
                        $parentGroupKey,
                        isset($field['sort_order']) && is_numeric($field['sort_order']) ? (int) $field['sort_order'] : $i + 1,
                        (string) ($field['field_key'] ?? ''),
                        trim((string) ($field['label'] ?? '')),
                        !array_key_exists('show_label', $field) || !empty($field['show_label']) ? 1 : 0,
                        !array_key_exists('visible', $field) || !empty($field['visible']) ? 1 : 0,
                        $type,
                        !empty($field['required']) && !self::isDisplayOnlyType($type) ? 1 : 0,
                        isset($field['min_length']) && is_numeric($field['min_length']) ? (int) $field['min_length'] : null,
                        isset($field['max_length']) && is_numeric($field['max_length']) ? (int) $field['max_length'] : null,
                        isset($field['exact_length']) && is_numeric($field['exact_length']) ? (int) $field['exact_length'] : null,
                        isset($field['regex']) && trim((string) $field['regex']) !== '' ? (string) $field['regex'] : null,
                        isset($field['help_text']) && trim((string) $field['help_text']) !== '' ? (string) $field['help_text'] : null,
                        isset($field['placeholder']) && trim((string) $field['placeholder']) !== '' ? (string) $field['placeholder'] : null,
                        isset($field['options_json']) && trim((string) $field['options_json']) !== '' ? (string) $field['options_json'] : null,
                    ]
                );
            }
        };

        if ($useTransaction) {
            Database::transaction($replace);
            return;
        }
        $replace();
    }

    public static function duplicateForForm(int $sourceFormId, int $targetFormId): void
    {
        $rows = Database::fetchAll(
            'SELECT * FROM form_fields WHERE form_id = ? ORDER BY input_page_key ASC, sort_order ASC, id ASC',
            [$sourceFormId]
        );
        foreach ($rows as $row) {
            Database::execute(
                'INSERT INTO form_fields (
                    form_id, input_page_key, parent_group_key, sort_order, field_key, label, show_label, visible, type,
                    required, min_length, max_length, exact_length, regex, help_text, placeholder, options_json
                 ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                [
                    $targetFormId,
                    (string) ($row['input_page_key'] ?? FormInputPage::DEFAULT_KEY),
                    FormFieldGroup::sanitizeGroupKey((string) ($row['parent_group_key'] ?? '')) ?: null,
                    (int) ($row['sort_order'] ?? 0),
                    (string) ($row['field_key'] ?? ''),
                    (string) ($row['label'] ?? ''),
                    !array_key_exists('show_label', $row) || !empty($row['show_label']) ? 1 : 0,
                    !empty($row['visible']) ? 1 : 0,
                    (string) ($row['type'] ?? 'text_multi'),
                    !empty($row['required']) ? 1 : 0,
                    $row['min_length'] ?? null,
                    $row['max_length'] ?? null,
                    $row['exact_length'] ?? null,
                    $row['regex'] ?? null,
                    $row['help_text'] ?? null,
                    $row['placeholder'] ?? null,
                    $row['options_json'] ?? null,
                ]
            );
        }
    }

    public static function sanitizeInputPageKey(string $key): string
    {
        $key = trim($key);
        return preg_match('/\A[a-zA-Z0-9_\-]{1,64}\z/', $key) ? $key : FormInputPage::DEFAULT_KEY;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<int, array<string, mixed>>
     */
    public static function forInputPage(array $fields, string $pageKey): array
    {
        return array_values(array_filter($fields, static function ($field) use ($pageKey): bool {
            return (string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY) === $pageKey;
        }));
    }

    /**
     * "選択肢A\n選択肢B" 形式 / 配列両方を受け付け、配列に正規化。
     */
    public static function parseOptions($value): array
    {
        if (is_array($value)) {
            $arr = $value;
        } elseif (is_string($value)) {
            $arr = preg_split('/\r\n|\r|\n/', $value) ?: [];
        } else {
            return [];
        }
        $out = [];
        foreach ($arr as $v) {
            $v = trim((string) $v);
            if ($v !== '') {
                $out[] = $v;
            }
        }
        return array_values(array_unique($out));
    }

    /**
     * @return array{options:array<int,string>,min_selections:string,max_selections:string}
     */
    public static function decodeCheckboxSettings($json): array
    {
        if (!is_string($json) || trim($json) === '') {
            return ['options' => [], 'min_selections' => '', 'max_selections' => ''];
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            return ['options' => [], 'min_selections' => '', 'max_selections' => ''];
        }

        if (array_keys($decoded) === range(0, count($decoded) - 1)) {
            return [
                'options' => self::parseOptions($decoded),
                'min_selections' => '',
                'max_selections' => '',
            ];
        }

        $options = self::parseOptions($decoded['options'] ?? []);
        $min = isset($decoded['min_selections']) && (int) $decoded['min_selections'] > 0
            ? (string) ((int) $decoded['min_selections'])
            : '';
        $max = isset($decoded['max_selections']) && (int) $decoded['max_selections'] > 0
            ? (string) ((int) $decoded['max_selections'])
            : '';

        return [
            'options' => $options,
            'min_selections' => $min,
            'max_selections' => $max,
        ];
    }

    /**
     * @param array<int, string> $options
     */
    public static function encodeCheckboxSettings(array $options, $minSelections = '', $maxSelections = ''): ?string
    {
        $cleanOptions = self::parseOptions($options);
        if (count($cleanOptions) === 0) {
            return null;
        }

        $min = (is_numeric($minSelections) && (int) $minSelections > 0) ? (int) $minSelections : null;
        $max = (is_numeric($maxSelections) && (int) $maxSelections > 0) ? (int) $maxSelections : null;

        if ($min === null && $max === null) {
            return json_encode($cleanOptions, JSON_UNESCAPED_UNICODE);
        }

        return json_encode([
            'options' => $cleanOptions,
            'min_selections' => $min,
            'max_selections' => $max,
        ], JSON_UNESCAPED_UNICODE);
    }

    /**
     * @return array{left_label:string,right_label:string}
     */
    public static function decodeTextPairLabels($json): array
    {
        if (!is_string($json) || trim($json) === '') {
            return ['left_label' => '', 'right_label' => ''];
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            return ['left_label' => '', 'right_label' => ''];
        }

        if (array_keys($decoded) === range(0, count($decoded) - 1)) {
            return [
                'left_label' => isset($decoded[0]) ? trim((string) $decoded[0]) : '',
                'right_label' => isset($decoded[1]) ? trim((string) $decoded[1]) : '',
            ];
        }

        return [
            'left_label' => trim((string) ($decoded['left_label'] ?? '')),
            'right_label' => trim((string) ($decoded['right_label'] ?? '')),
        ];
    }

    public static function encodeTextPairLabels(string $leftLabel, string $rightLabel): ?string
    {
        $payload = [
            'left_label' => trim($leftLabel),
            'right_label' => trim($rightLabel),
        ];
        if ($payload['left_label'] === '' && $payload['right_label'] === '') {
            return null;
        }

        return json_encode($payload, JSON_UNESCAPED_UNICODE);
    }

    /**
     * @return array{left_placeholder:string,right_placeholder:string}
     */
    public static function decodeTextPairPlaceholders($stored): array
    {
        if (!is_string($stored) || trim($stored) === '') {
            return ['left_placeholder' => '', 'right_placeholder' => ''];
        }

        $decoded = json_decode($stored, true);
        if (!is_array($decoded)) {
            return [
                'left_placeholder' => trim($stored),
                'right_placeholder' => '',
            ];
        }

        if (array_keys($decoded) === range(0, count($decoded) - 1)) {
            return [
                'left_placeholder' => isset($decoded[0]) ? trim((string) $decoded[0]) : '',
                'right_placeholder' => isset($decoded[1]) ? trim((string) $decoded[1]) : '',
            ];
        }

        return [
            'left_placeholder' => trim((string) ($decoded['left_placeholder'] ?? '')),
            'right_placeholder' => trim((string) ($decoded['right_placeholder'] ?? '')),
        ];
    }

    public static function encodeTextPairPlaceholders(string $leftPlaceholder, string $rightPlaceholder): ?string
    {
        $payload = [
            'left_placeholder' => trim($leftPlaceholder),
            'right_placeholder' => trim($rightPlaceholder),
        ];
        if ($payload['left_placeholder'] === '' && $payload['right_placeholder'] === '') {
            return null;
        }

        return json_encode($payload, JSON_UNESCAPED_UNICODE);
    }

    /**
     * @param mixed $json
     * @return array<int, array{label:string,placeholder:string,default_value:string}>
     */
    public static function decodeTextMultiItems($json, bool $ensureDefault = false): array
    {
        $default = $ensureDefault ? [['label' => '', 'placeholder' => '', 'default_value' => '']] : [];
        if (!is_string($json) || trim($json) === '') {
            return $default;
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            return $default;
        }

        if (array_keys($decoded) !== range(0, count($decoded) - 1)) {
            $decoded = $decoded['items'] ?? [];
            if (!is_array($decoded)) {
                return $default;
            }
        }

        $items = [];
        foreach ($decoded as $item) {
            if (is_string($item)) {
                $label = trim($item);
                $placeholder = '';
                $defaultValue = '';
            } elseif (is_array($item)) {
                $label = trim((string) ($item['label'] ?? $item[0] ?? ''));
                $placeholder = trim((string) ($item['placeholder'] ?? $item[1] ?? ''));
                $defaultValue = trim((string) ($item['default_value'] ?? $item[2] ?? ''));
            } else {
                continue;
            }

            $items[] = [
                'label' => $label,
                'placeholder' => $placeholder,
                'default_value' => $defaultValue,
            ];
        }

        if ($items === []) {
            return $default;
        }

        return array_values($items);
    }

    /**
     * @param mixed $json
     * @return array{postal_target_prefecture:string,postal_target_city:string}
     */
    public static function decodeTextMultiMeta($json): array
    {
        if (!is_string($json) || trim($json) === '') {
            return [
                'postal_target_prefecture' => '',
                'postal_target_city' => '',
            ];
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded) || array_keys($decoded) === range(0, count($decoded) - 1)) {
            return [
                'postal_target_prefecture' => '',
                'postal_target_city' => '',
            ];
        }

        return [
            'postal_target_prefecture' => trim((string) ($decoded['postal_target_prefecture'] ?? '')),
            'postal_target_city' => trim((string) ($decoded['postal_target_city'] ?? '')),
        ];
    }

    /**
     * @param array<int, array{label?:string,placeholder?:string,default_value?:string}|string> $items
     */
    public static function encodeTextMultiItems(array $items): ?string
    {
        $payload = [];
        foreach ($items as $item) {
            if (is_string($item)) {
                $label = trim($item);
                $placeholder = '';
                $defaultValue = '';
            } else {
                $label = trim((string) ($item['label'] ?? ''));
                $placeholder = trim((string) ($item['placeholder'] ?? ''));
                $defaultValue = trim((string) ($item['default_value'] ?? ''));
            }

            $payload[] = [
                'label' => $label,
                'placeholder' => $placeholder,
                'default_value' => $defaultValue,
            ];
        }

        if ($payload === []) {
            return null;
        }

        return json_encode(array_values($payload), JSON_UNESCAPED_UNICODE);
    }

    /**
     * @param array<int, array{label?:string,placeholder?:string,default_value?:string}|string> $items
     * @param array{postal_target_prefecture?:string,postal_target_city?:string} $meta
     */
    public static function encodeTextMultiSettings(array $items, array $meta = []): ?string
    {
        $encodedItems = self::encodeTextMultiItems($items);
        $decodedItems = $encodedItems !== null ? (json_decode($encodedItems, true) ?: []) : [];
        $prefTarget = trim((string) ($meta['postal_target_prefecture'] ?? ''));
        $cityTarget = trim((string) ($meta['postal_target_city'] ?? ''));

        if ($prefTarget === '' && $cityTarget === '') {
            return $encodedItems;
        }

        return json_encode([
            'items' => is_array($decodedItems) ? $decodedItems : [],
            'postal_target_prefecture' => $prefTarget,
            'postal_target_city' => $cityTarget,
        ], JSON_UNESCAPED_UNICODE);
    }

    /**
     * @param mixed $json
     * @return array{postal_target_prefecture:string,postal_target_city:string}
     */
    public static function decodePostalCodeSettings($json): array
    {
        if (!is_string($json) || trim($json) === '') {
            return [
                'postal_target_prefecture' => '',
                'postal_target_city' => '',
            ];
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded) || array_keys($decoded) === range(0, count($decoded) - 1)) {
            return [
                'postal_target_prefecture' => '',
                'postal_target_city' => '',
            ];
        }

        return [
            'postal_target_prefecture' => trim((string) ($decoded['postal_target_prefecture'] ?? '')),
            'postal_target_city' => trim((string) ($decoded['postal_target_city'] ?? '')),
        ];
    }

    /**
     * @param array{postal_target_prefecture?:string,postal_target_city?:string} $settings
     */
    public static function encodePostalCodeSettings(array $settings): ?string
    {
        $prefTarget = trim((string) ($settings['postal_target_prefecture'] ?? ''));
        $cityTarget = trim((string) ($settings['postal_target_city'] ?? ''));
        if ($prefTarget === '' && $cityTarget === '') {
            return null;
        }

        return json_encode([
            'postal_target_prefecture' => $prefTarget,
            'postal_target_city' => $cityTarget,
        ], JSON_UNESCAPED_UNICODE);
    }

    /**
     * @param mixed $json
     * @return array{default_value:string}
     */
    public static function decodeDefaultValueSettings($json): array
    {
        if (!is_string($json) || trim($json) === '') {
            return ['default_value' => ''];
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded) || array_keys($decoded) === range(0, count($decoded) - 1)) {
            return ['default_value' => ''];
        }

        return ['default_value' => (string) ($decoded['default_value'] ?? '')];
    }

    public static function encodeDefaultValueSettings(string $defaultValue): ?string
    {
        if ($defaultValue === '') {
            return null;
        }

        return json_encode([
            'default_value' => $defaultValue,
        ], JSON_UNESCAPED_UNICODE);
    }

    /**
     * @param mixed $json
     * @return array{options:array<int,string>,default_value:string}
     */
    public static function decodeChoiceSettings($json): array
    {
        if (!is_string($json) || trim($json) === '') {
            return ['options' => [], 'default_value' => ''];
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            return ['options' => [], 'default_value' => ''];
        }

        if (array_keys($decoded) === range(0, count($decoded) - 1)) {
            return [
                'options' => self::parseOptions($decoded),
                'default_value' => '',
            ];
        }

        return [
            'options' => self::parseOptions($decoded['options'] ?? []),
            'default_value' => trim((string) ($decoded['default_value'] ?? '')),
        ];
    }

    /**
     * @param array<int,string> $options
     */
    public static function encodeChoiceSettings(array $options, string $defaultValue = ''): ?string
    {
        $cleanOptions = self::parseOptions($options);
        if ($cleanOptions === []) {
            return null;
        }

        $defaultValue = trim($defaultValue);
        if ($defaultValue === '') {
            return json_encode($cleanOptions, JSON_UNESCAPED_UNICODE);
        }

        return json_encode([
            'options' => $cleanOptions,
            'default_value' => $defaultValue,
        ], JSON_UNESCAPED_UNICODE);
    }

    /**
     * @param mixed $json
     * @return array{default_mode:string,default_value:string}
     */
    public static function decodeDateDefaultSettings($json): array
    {
        return self::decodeTemporalDefaultSettings($json, ['fixed', 'today']);
    }

    public static function encodeDateDefaultSettings(string $defaultMode, string $defaultValue): ?string
    {
        return self::encodeTemporalDefaultSettings($defaultMode, $defaultValue, ['fixed', 'today']);
    }

    /**
     * @param mixed $json
     * @return array{default_mode:string,default_value:string}
     */
    public static function decodeTimeDefaultSettings($json): array
    {
        return self::decodeTemporalDefaultSettings($json, ['fixed', 'now']);
    }

    public static function encodeTimeDefaultSettings(string $defaultMode, string $defaultValue): ?string
    {
        return self::encodeTemporalDefaultSettings($defaultMode, $defaultValue, ['fixed', 'now']);
    }

    /**
     * @param array<int,string> $allowedModes
     * @param mixed $json
     * @return array{default_mode:string,default_value:string}
     */
    private static function decodeTemporalDefaultSettings($json, array $allowedModes): array
    {
        if (!is_string($json) || trim($json) === '') {
            return ['default_mode' => '', 'default_value' => ''];
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded) || array_keys($decoded) === range(0, count($decoded) - 1)) {
            return ['default_mode' => '', 'default_value' => ''];
        }

        $defaultMode = trim((string) ($decoded['default_mode'] ?? ''));
        if (!in_array($defaultMode, $allowedModes, true)) {
            $defaultMode = '';
        }

        return [
            'default_mode' => $defaultMode,
            'default_value' => trim((string) ($decoded['default_value'] ?? '')),
        ];
    }

    /**
     * @param array<int,string> $allowedModes
     */
    private static function encodeTemporalDefaultSettings(string $defaultMode, string $defaultValue, array $allowedModes): ?string
    {
        $defaultMode = trim($defaultMode);
        $defaultValue = trim($defaultValue);
        if (!in_array($defaultMode, $allowedModes, true)) {
            $defaultMode = '';
        }
        if ($defaultMode === '') {
            $defaultValue = '';
        }
        if ($defaultMode === '' && $defaultValue === '') {
            return null;
        }

        return json_encode([
            'default_mode' => $defaultMode,
            'default_value' => $defaultValue,
        ], JSON_UNESCAPED_UNICODE);
    }

    /**
     * @param mixed $json
     * @return array{allowed_extensions:array<int,string>,selection_mode:string,convert_to_jpeg:int}
     */
    public static function decodeFileSettings($json): array
    {
        $default = [
            'allowed_extensions' => [],
            'selection_mode' => self::FILE_SELECTION_CUSTOM,
            'convert_to_jpeg' => 0,
        ];
        if (!is_string($json) || trim($json) === '') {
            return $default;
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            return $default;
        }

        if (array_keys($decoded) === range(0, count($decoded) - 1)) {
            $default['allowed_extensions'] = self::parseExtensionList($decoded);
            return $default;
        }

        $selectionMode = self::normalizeFileSelectionMode((string) ($decoded['selection_mode'] ?? self::FILE_SELECTION_CUSTOM));
        return [
            'allowed_extensions' => self::parseExtensionList($decoded['allowed_extensions'] ?? []),
            'selection_mode' => $selectionMode,
            'convert_to_jpeg' => $selectionMode === self::FILE_SELECTION_IMAGE ? 1 : (!empty($decoded['convert_to_jpeg']) ? 1 : 0),
        ];
    }

    /**
     * @param array<string, mixed>|array<int, string>|string $extensions
     */
    public static function encodeFileSettings($extensions): ?string
    {
        $selectionMode = self::FILE_SELECTION_CUSTOM;
        $convertToJpeg = 0;
        $allowedExtensionsSource = $extensions;
        if (is_array($extensions) && array_keys($extensions) !== range(0, count($extensions) - 1)) {
            $selectionMode = self::normalizeFileSelectionMode((string) ($extensions['selection_mode'] ?? self::FILE_SELECTION_CUSTOM));
            $convertToJpeg = $selectionMode === self::FILE_SELECTION_IMAGE ? 1 : (!empty($extensions['convert_to_jpeg']) ? 1 : 0);
            $allowedExtensionsSource = $extensions['allowed_extensions'] ?? [];
        }

        $allowedExtensions = self::parseExtensionList($allowedExtensionsSource);
        if ($selectionMode === self::FILE_SELECTION_CUSTOM && $allowedExtensions === [] && $convertToJpeg !== 1) {
            return null;
        }

        return json_encode([
            'selection_mode' => $selectionMode,
            'allowed_extensions' => $allowedExtensions,
            'convert_to_jpeg' => $convertToJpeg,
        ], JSON_UNESCAPED_UNICODE);
    }

    public static function normalizeFileSelectionMode(string $mode): string
    {
        return $mode === self::FILE_SELECTION_IMAGE ? self::FILE_SELECTION_IMAGE : self::FILE_SELECTION_CUSTOM;
    }

    /**
     * @return array<int, string>
     */
    public static function imageUploadExtensions(): array
    {
        return ['jpg', 'jpeg', 'png', 'gif', 'webp', 'heic', 'heif'];
    }

    /**
     * @return array<int, string>
     */
    public static function imageAcceptTokens(): array
    {
        return ['image/*', '.heic', '.heif'];
    }

    public static function isImageUploadExtension(string $extension): bool
    {
        $extension = strtolower(ltrim(trim($extension), '.'));
        return $extension !== '' && in_array($extension, self::imageUploadExtensions(), true);
    }

    /**
     * @param mixed $json
     * @return array{rows:array<int,string>,columns:array<int,string>,selection_type:string}
     */
    public static function decodeMatrixSettings($json): array
    {
        $default = ['rows' => [], 'columns' => [], 'selection_type' => 'radio'];
        if (!is_string($json) || trim($json) === '') {
            return $default;
        }

        $decoded = json_decode($json, true);
        if (!is_array($decoded)) {
            return $default;
        }

        return [
            'rows' => self::parseOptions($decoded['rows'] ?? []),
            'columns' => self::parseOptions($decoded['columns'] ?? []),
            'selection_type' => ($decoded['selection_type'] ?? 'radio') === 'radio' ? 'radio' : 'radio',
        ];
    }

    /**
     * @param array<int, string>|string $rows
     * @param array<int, string>|string $columns
     */
    public static function encodeMatrixSettings($rows, $columns, string $selectionType = 'radio'): ?string
    {
        $matrixRows = self::parseOptions($rows);
        $matrixColumns = self::parseOptions($columns);
        if ($matrixRows === [] || $matrixColumns === []) {
            return null;
        }

        return json_encode([
            'rows' => $matrixRows,
            'columns' => $matrixColumns,
            'selection_type' => $selectionType === 'radio' ? 'radio' : 'radio',
        ], JSON_UNESCAPED_UNICODE);
    }

    /**
     * @param array{label?:string,placeholder?:string,default_value?:string}|null $item
     */
    public static function textMultiItemDisplayLabel(?array $item, int $index, string $fallbackBase = '入力欄'): string
    {
        $label = trim((string) ($item['label'] ?? ''));
        if ($label !== '') {
            return $label;
        }

        return $fallbackBase . ($index + 1);
    }

    /**
     * @param array{label?:string,placeholder?:string,default_value?:string}|null $item
     */
    public static function textMultiItemAriaLabel(?array $item, int $index, string $fieldLabel = ''): string
    {
        $label = trim((string) ($item['label'] ?? ''));
        if ($label !== '') {
            return $label;
        }
        if ($fieldLabel !== '') {
            return $fieldLabel . ' ' . ($index + 1);
        }

        return self::textMultiItemDisplayLabel($item, $index, '内容');
    }

    /**
     * @param array<int, string>|string $extensions
     * @return array<int, string>
     */
    public static function parseExtensionList($extensions): array
    {
        if (is_array($extensions)) {
            $items = $extensions;
        } elseif (is_string($extensions)) {
            $items = preg_split('/[\s,]+/', $extensions) ?: [];
        } else {
            return [];
        }

        $normalized = [];
        foreach ($items as $extension) {
            $extension = strtolower(trim((string) $extension));
            $extension = ltrim($extension, '.');
            if ($extension === '' || !preg_match('/\A[a-z0-9]+(?:[a-z0-9._-]*[a-z0-9]+)?\z/', $extension)) {
                continue;
            }
            $normalized[$extension] = $extension;
        }

        return array_values($normalized);
    }

    /**
     * @param array<string, mixed> $field
     * @return array<string, mixed>
     */
    private static function normalizeField(array $field): array
    {
        $field['input_page_key'] = self::sanitizeInputPageKey((string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
        $parentGroupKey = FormFieldGroup::sanitizeGroupKey((string) ($field['parent_group_key'] ?? ''));
        $field['parent_group_key'] = $parentGroupKey !== '' ? $parentGroupKey : null;
        if (!array_key_exists('visible', $field)) {
            $field['visible'] = 1;
        } else {
            $field['visible'] = !empty($field['visible']) ? 1 : 0;
        }
        if (!array_key_exists('show_label', $field)) {
            $field['show_label'] = 1;
        } else {
            $field['show_label'] = !empty($field['show_label']) ? 1 : 0;
        }
        $originalType = (string) ($field['type'] ?? '');
        $normalizedType = self::normalizeType($originalType);
        if ($normalizedType === $originalType) {
            return $field;
        }

        $field['type'] = $normalizedType;
        if ($originalType === 'text') {
            $field['options_json'] = self::encodeTextMultiSettings([[
                'label' => '',
                'placeholder' => trim((string) ($field['placeholder'] ?? '')),
            ]]);
            $field['placeholder'] = null;
            return $field;
        }

        if ($originalType === 'text_pair') {
            $labels = self::decodeTextPairLabels($field['options_json'] ?? null);
            $placeholders = self::decodeTextPairPlaceholders($field['placeholder'] ?? null);
            $field['options_json'] = self::encodeTextMultiSettings([
                [
                    'label' => $labels['left_label'],
                    'placeholder' => $placeholders['left_placeholder'],
                ],
                [
                    'label' => $labels['right_label'],
                    'placeholder' => $placeholders['right_placeholder'],
                ],
            ]);
            $field['placeholder'] = null;
        }

        return $field;
    }

    /**
     * @param array<string, mixed> $field
     */
    private static function isAgreementFieldRecord(array $field): bool
    {
        $fieldKey = trim((string) ($field['field_key'] ?? ''));
        if ($fieldKey === 'agreement_consent') {
            return true;
        }

        if ((string) ($field['type'] ?? '') !== 'checkbox') {
            return false;
        }

        $label = trim((string) ($field['label'] ?? ''));
        if ($label !== '規約への同意') {
            return false;
        }

        $options = [];
        if (array_key_exists('options', $field)) {
            $options = self::parseOptions((string) ($field['options'] ?? ''));
        } else {
            $checkboxSettings = self::decodeCheckboxSettings($field['options_json'] ?? null);
            $options = $checkboxSettings['options'];
        }

        return count($options) === 1 && (string) ($options[0] ?? '') === '規約に同意する';
    }
}
