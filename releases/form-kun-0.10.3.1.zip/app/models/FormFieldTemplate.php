<?php
namespace Models;

use Core\Database;

class FormFieldTemplate
{
    /**
     * @return array<int, array<string, mixed>>
     */
    public static function all(): array
    {
        $rows = Database::fetchAll(
            'SELECT * FROM form_field_templates ORDER BY updated_at DESC, id DESC'
        );
        return array_merge(self::builtinTemplates(), array_map([self::class, 'normalizeRow'], $rows));
    }

    public static function find(int $id): ?array
    {
        $row = Database::fetchOne('SELECT * FROM form_field_templates WHERE id = ?', [$id]);
        return $row !== null ? self::normalizeRow($row) : null;
    }

    public static function findTemplate(string $id): ?array
    {
        if (strpos($id, 'builtin-') === 0) {
            foreach (self::builtinTemplates() as $template) {
                if ((string) ($template['id'] ?? '') === $id) {
                    return $template;
                }
            }
            return null;
        }

        if (!ctype_digit($id)) {
            return null;
        }

        return self::find((int) $id);
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $groups
     */
    public static function create(string $title, array $fields, array $groups): int
    {
        $now = date('Y-m-d H:i:s');
        Database::execute(
            'INSERT INTO form_field_templates (title, fields_json, field_groups_json, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
            [
                self::normalizeTitle($title),
                self::encodeJson($fields),
                self::encodeJson($groups),
                $now,
                $now,
            ]
        );
        return Database::lastInsertId();
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $groups
     */
    public static function update(int $id, string $title, array $fields, array $groups): void
    {
        Database::execute(
            'UPDATE form_field_templates SET title = ?, fields_json = ?, field_groups_json = ?, updated_at = ? WHERE id = ?',
            [
                self::normalizeTitle($title),
                self::encodeJson($fields),
                self::encodeJson($groups),
                date('Y-m-d H:i:s'),
                $id,
            ]
        );
    }

    public static function delete(int $id): void
    {
        Database::execute('DELETE FROM form_field_templates WHERE id = ?', [$id]);
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public static function normalizeRow(array $row): array
    {
        $fields = self::decodeJson($row['fields_json'] ?? '[]');
        foreach ($fields as &$field) {
            if (!isset($field['regex_pattern']) && isset($field['regex'])) {
                $patterns = FormField::decodeRegexPatterns($field['regex'] !== null ? (string) $field['regex'] : null);
                $field['regex_pattern'] = (string) ($patterns[0] ?? '');
            }
        }
        unset($field);
        $row['fields'] = $fields;
        $row['field_groups'] = self::decodeJson($row['field_groups_json'] ?? '[]');
        return $row;
    }

    public static function normalizeTitle(string $title): string
    {
        $title = trim($title);
        return $title !== '' ? mb_substr($title, 0, 200) : '無題のテンプレート';
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function builtinTemplates(): array
    {
        return [
            [
                'id' => 'builtin-contact',
                'title' => 'お問い合わせ',
                'is_builtin' => true,
                'fields' => [
                    self::builtinField('builtin-contact-name', 1, 'text_multi', 'お名前'),
                    self::builtinField('builtin-contact-name-kana', 2, 'text_multi', 'お名前（カナ）'),
                    self::builtinField('builtin-contact-email', 3, 'email', 'メールアドレス'),
                    self::builtinField('builtin-contact-tel', 4, 'tel', '電話番号'),
                    self::builtinField('builtin-contact-message', 5, 'textarea', 'お問い合わせ内容'),
                ],
                'field_groups' => [],
            ],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private static function builtinField(string $key, int $sortOrder, string $type, string $label): array
    {
        return [
            'input_page_key' => 'input-1',
            'parent_group_key' => null,
            'sort_order' => $sortOrder,
            'field_key' => $key,
            'label' => $label,
            'show_label' => 1,
            'visible' => 1,
            'type' => $type,
            'required' => 0,
            'min_length' => '',
            'max_length' => '',
            'exact_length' => '',
            'regex' => null,
            'regex_pattern' => '',
            'help_text' => '',
            'help_text_is_html' => 0,
            'placeholder' => '',
            'multi_text_items' => '',
            'checkbox_limit_enabled' => 0,
            'checkbox_min_selections' => '',
            'checkbox_max_selections' => '',
            'options' => '',
            'file_allowed_extensions' => '',
            'file_type_mode' => FormField::FILE_SELECTION_CUSTOM,
            'file_convert_to_jpeg' => 0,
            'matrix_rows' => '',
            'matrix_columns' => '',
            'matrix_selection_type' => 'radio',
        ];
    }

    /**
     * @param mixed $value
     * @return array<int, array<string, mixed>>
     */
    private static function decodeJson($value): array
    {
        $decoded = json_decode((string) $value, true);
        if (!is_array($decoded)) {
            return [];
        }
        return array_values(array_filter($decoded, static fn($item): bool => is_array($item)));
    }

    /**
     * @param array<int, array<string, mixed>> $value
     */
    private static function encodeJson(array $value): string
    {
        return json_encode(array_values($value), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '[]';
    }
}
