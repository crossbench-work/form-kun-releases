<?php
namespace Models;

use Core\Database;

class UserFormGrant
{
    /**
     * @return int[]
     */
    public static function formIdsForUser(int $userId): array
    {
        return array_keys(self::grantsForUser($userId));
    }

    /**
     * @return array<int, string> form_id => view|edit
     */
    public static function grantsForUser(int $userId): array
    {
        if ($userId <= 0) {
            return [];
        }
        $rows = Database::fetchAll(
            'SELECT form_id, access_level FROM user_form_grants WHERE user_id = ? ORDER BY form_id ASC',
            [$userId]
        );
        $grants = [];
        foreach ($rows as $row) {
            $formId = (int) $row['form_id'];
            $level = (string) ($row['access_level'] ?? 'view');
            if ($formId > 0 && in_array($level, ['view', 'edit'], true)) {
                $grants[$formId] = $level;
            }
        }
        return $grants;
    }

    /**
     * @param array<int, string> $grants form_id => view|edit
     */
    public static function syncForUser(int $userId, array $grants): void
    {
        if ($userId <= 0) {
            return;
        }
        $normalized = [];
        foreach ($grants as $formId => $level) {
            $formId = (int) $formId;
            $level = (string) $level;
            if ($formId <= 0 || !in_array($level, ['view', 'edit'], true)) {
                continue;
            }
            $normalized[$formId] = $level;
        }
        if ($normalized !== []) {
            $existing = Database::fetchAll('SELECT id FROM forms');
            $valid = [];
            foreach ($existing as $row) {
                $fid = (int) $row['id'];
                if (isset($normalized[$fid])) {
                    $valid[$fid] = $normalized[$fid];
                }
            }
            $normalized = $valid;
        }

        Database::transaction(function () use ($userId, $normalized): void {
            Database::execute('DELETE FROM user_form_grants WHERE user_id = ?', [$userId]);
            foreach ($normalized as $formId => $level) {
                Database::execute(
                    'INSERT INTO user_form_grants (user_id, form_id, access_level) VALUES (?, ?, ?)',
                    [$userId, $formId, $level]
                );
            }
        });
    }

    public static function clearForUser(int $userId): void
    {
        if ($userId <= 0) {
            return;
        }
        Database::execute('DELETE FROM user_form_grants WHERE user_id = ?', [$userId]);
    }
}
