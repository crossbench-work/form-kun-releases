<?php
namespace Models;

use Core\Database;

class FormInputPage
{
    public const DEFAULT_KEY = 'input-1';

    /**
     * @return array<int, array<string, mixed>>
     */
    public static function forForm(int $formId, ?array $form = null): array
    {
        $rows = Database::fetchAll(
            'SELECT * FROM form_input_pages WHERE form_id = ? ORDER BY sort_order ASC, id ASC',
            [$formId]
        );
        $pages = array_map([self::class, 'normalizePage'], $rows);
        if ($pages !== [] && $form !== null) {
            $legacyDescription = trim((string) ($form['description'] ?? ''));
            $firstDescription = trim((string) ($pages[0]['description'] ?? ''));
            if ($firstDescription === '' && $legacyDescription !== '') {
                $pages[0]['description'] = (string) $form['description'];
            }
        }
        if ($pages === [] && $form !== null) {
            $pages = [self::defaultPage($form)];
        }
        return self::normalizePages($pages, $form ?? []);
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     */
    public static function replaceForForm(int $formId, array $pages, bool $useTransaction = true): void
    {
        $pages = self::normalizePages($pages, []);
        $replace = static function () use ($formId, $pages): void {
            Database::execute('DELETE FROM form_input_pages WHERE form_id = ?', [$formId]);
            $now = date('Y-m-d H:i:s');
            foreach ($pages as $i => $page) {
                Database::execute(
                    'INSERT INTO form_input_pages (
                        form_id, page_key, sort_order, title, show_title, description, button_text, back_button_text, created_at, updated_at
                     ) VALUES (?,?,?,?,?,?,?,?,?,?)',
                    [
                        $formId,
                        (string) $page['page_key'],
                        $i + 1,
                        (string) ($page['title'] ?? ''),
                        !empty($page['show_title']) ? 1 : 0,
                        $page['description'] ?? null,
                        (string) ($page['button_text'] ?? ''),
                        (string) ($page['back_button_text'] ?? ''),
                        $now,
                        $now,
                    ]
                );
            }
        };

        if ($useTransaction) {
            Database::transaction($replace);
            return;
        }

        $replace();
    }

    public static function duplicateForForm(int $sourceFormId, int $targetFormId): void
    {
        $rows = Database::fetchAll(
            'SELECT * FROM form_input_pages WHERE form_id = ? ORDER BY sort_order ASC, id ASC',
            [$sourceFormId]
        );
        $now = date('Y-m-d H:i:s');
        foreach ($rows as $row) {
            Database::execute(
                'INSERT INTO form_input_pages (
                    form_id, page_key, sort_order, title, show_title, description, button_text, back_button_text, created_at, updated_at
                 ) VALUES (?,?,?,?,?,?,?,?,?,?)',
                [
                    $targetFormId,
                    (string) ($row['page_key'] ?? ''),
                    (int) ($row['sort_order'] ?? 0),
                    (string) ($row['title'] ?? ''),
                    !empty($row['show_title']) ? 1 : 0,
                    $row['description'] ?? null,
                    (string) ($row['button_text'] ?? ''),
                    (string) ($row['back_button_text'] ?? ''),
                    $now,
                    $now,
                ]
            );
        }
    }

    /**
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    public static function defaultPage(array $form = []): array
    {
        $title = trim((string) ($form['input_page_title'] ?? ''));
        if ($title === '') {
            $title = trim((string) ($form['title'] ?? ''));
        }
        $button = trim((string) ($form['confirm_button_text'] ?? ''));
        if ($button === '') {
            $button = '入力内容を確認する';
        }

        return [
            'page_key' => self::DEFAULT_KEY,
            'sort_order' => 1,
            'title' => $title,
            'show_title' => !array_key_exists('show_input_page_title', $form) || !empty($form['show_input_page_title']) ? 1 : 0,
            'description' => $form['description'] ?? null,
            'description_blocks' => is_array($form['description_blocks'] ?? null) ? $form['description_blocks'] : [],
            'button_text' => $button,
            'back_button_text' => '戻る',
        ];
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     * @param array<string, mixed> $form
     * @return array<int, array<string, mixed>>
     */
    public static function normalizePages(array $pages, array $form = []): array
    {
        $out = [];
        $used = [];
        foreach (array_values($pages) as $i => $page) {
            if (!is_array($page)) {
                continue;
            }
            $normalized = self::normalizePage($page);
            $key = self::sanitizePageKey((string) ($normalized['page_key'] ?? ''));
            if ($key === '' || isset($used[$key])) {
                $key = self::generatePageKey($used, $i + 1);
            }
            $used[$key] = true;
            $normalized['page_key'] = $key;
            $normalized['sort_order'] = count($out) + 1;
            $out[] = $normalized;
        }

        if ($out === []) {
            $out[] = self::defaultPage($form);
        }

        return $out;
    }

    /**
     * @param array<string, mixed> $page
     * @return array<string, mixed>
     */
    public static function normalizePage(array $page): array
    {
        $key = self::sanitizePageKey((string) ($page['page_key'] ?? ''));
        if ($key === '') {
            $key = self::DEFAULT_KEY;
        }
        $title = trim((string) ($page['title'] ?? ''));
        if ($title === '') {
            $title = '入力画面';
        }
        $button = trim((string) ($page['button_text'] ?? ''));
        if ($button === '') {
            $button = '次へ';
        }
        $backButton = trim((string) ($page['back_button_text'] ?? ''));
        if ($backButton === '') {
            $backButton = '戻る';
        }

        return [
            'id' => isset($page['id']) ? (int) $page['id'] : null,
            'page_key' => $key,
            'sort_order' => isset($page['sort_order']) ? (int) $page['sort_order'] : 0,
            'title' => $title,
            'show_title' => !array_key_exists('show_title', $page) || !empty($page['show_title']) ? 1 : 0,
            'description' => $page['description'] ?? null,
            'description_blocks' => is_array($page['description_blocks'] ?? null) ? $page['description_blocks'] : [],
            'button_text' => $button,
            'back_button_text' => $backButton,
        ];
    }

    public static function sanitizePageKey(string $key): string
    {
        $key = trim($key);
        return preg_match('/\A[a-zA-Z0-9_\-]{1,64}\z/', $key) ? $key : '';
    }

    /**
     * @param array<string, bool> $used
     */
    private static function generatePageKey(array $used, int $seed): string
    {
        $n = max(1, $seed);
        do {
            $key = 'input-' . $n;
            $n++;
        } while (isset($used[$key]));
        return $key;
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     */
    public static function findPage(array $pages, string $pageKey): ?array
    {
        foreach ($pages as $page) {
            if ((string) ($page['page_key'] ?? '') === $pageKey) {
                return $page;
            }
        }
        return null;
    }

    /**
     * @param array<int, array<string, mixed>> $pages
     */
    public static function nextPageKey(array $pages, string $pageKey): ?string
    {
        $count = count($pages);
        for ($i = 0; $i < $count; $i++) {
            if ((string) ($pages[$i]['page_key'] ?? '') === $pageKey) {
                return isset($pages[$i + 1]) ? (string) $pages[$i + 1]['page_key'] : null;
            }
        }
        return null;
    }
}
