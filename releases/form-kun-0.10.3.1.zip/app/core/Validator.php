<?php
namespace Core;

use Models\FormField;

class Validator
{
    /** @var array<string, array<string, mixed>> */
    private array $errors = [];

    /**
     * フォーム項目定義に基づいて入力をバリデーション。
     *
     * @param array<int, array> $fields  form_fields の配列
     * @param array<string, mixed> $input
     * @param array<string, array> $files  $_FILES 形式（fieldKey => entry）
     * @return array{values: array<string,mixed>, errors: array<string, mixed>}
     */
    public function validate(array $fields, array $input, array $files = []): array
    {
        $values = [];
        foreach ($fields as $field) {
            $key = $field['field_key'];
            $type = $field['type'];
            if (FormField::isDisplayOnlyType((string) $type)) {
                continue;
            }

            if ($type === 'file') {
                $entry = $files[$key] ?? null;
                // ファイル項目は submission_values には保存しない（submission_files で管理）
                // テンプレート用に元ファイル名だけは values に残す
                $values[$key] = is_array($entry) && !empty($entry['name']) ? (string) $entry['name'] : '';
                $this->validateFile($field, $entry);
                continue;
            }

            $raw = $input[$key] ?? null;
            $clean = $this->normalize($raw, $type);
            $values[$key] = $clean;
            $this->validateScalar($field, $clean);
        }

        return ['values' => $values, 'errors' => $this->errors];
    }

    private function normalize($raw, string $type)
    {
        if ($type === 'address') {
            if (!is_array($raw)) {
                return ['postal' => '', 'prefecture' => '', 'city' => '', 'number' => '', 'building' => ''];
            }
            $p3 = isset($raw['postal3']) ? preg_replace('/\D/', '', (string) $raw['postal3']) : '';
            $p4 = isset($raw['postal4']) ? preg_replace('/\D/', '', (string) $raw['postal4']) : '';
            $legacy = isset($raw['postal']) ? preg_replace('/\D/', '', (string) $raw['postal']) : '';
            $digits = ($p3 !== '' || $p4 !== '') ? ($p3 . $p4) : $legacy;
            $postal = '';
            if (strlen($digits) === 7) {
                $postal = substr($digits, 0, 3) . '-' . substr($digits, 3);
            } elseif ($digits !== '') {
                $postal = $digits;
            }
            $pref = isset($raw['prefecture']) ? trim((string) $raw['prefecture']) : '';
            $prefAllowed = array_flip(\japanese_prefectures());
            if ($pref !== '' && !isset($prefAllowed[$pref])) {
                $pref = '';
            }
            $number = isset($raw['number']) ? trim((string) $raw['number']) : '';
            $building = isset($raw['building']) ? trim((string) $raw['building']) : '';
            if ($number === '' && $building === '' && isset($raw['street'])) {
                $number = trim((string) $raw['street']);
            }
            return [
                'postal'      => $postal,
                'prefecture'  => $pref,
                'city'        => isset($raw['city']) ? trim((string) $raw['city']) : '',
                'number'      => $number,
                'building'    => $building,
            ];
        }
        if ($type === 'text_pair') {
            if (!is_array($raw)) {
                return ['left' => '', 'right' => ''];
            }
            return [
                'left' => isset($raw['left']) ? trim((string) $raw['left']) : '',
                'right' => isset($raw['right']) ? trim((string) $raw['right']) : '',
            ];
        }
        if ($type === 'text_multi') {
            if (!is_array($raw)) {
                return ['items' => []];
            }
            $rawItems = isset($raw['items']) && is_array($raw['items']) ? $raw['items'] : $raw;
            $items = [];
            foreach ($rawItems as $item) {
                $items[] = trim((string) $item);
            }
            return ['items' => array_values($items)];
        }
        if ($type === FormField::TYPE_POSTAL_CODE) {
            if ($raw === null) {
                return '';
            }
            $postal = trim((string) $raw);
            $digits = preg_replace('/\D/', '', $postal);
            if (strlen($digits) === 7) {
                return substr($digits, 0, 3) . '-' . substr($digits, 3);
            }
            return $postal;
        }
        if ($type === FormField::TYPE_MATRIX) {
            if (!is_array($raw)) {
                return ['rows' => []];
            }
            $rows = isset($raw['rows']) && is_array($raw['rows']) ? $raw['rows'] : $raw;
            $normalized = [];
            foreach ($rows as $rowKey => $selectedValue) {
                $rowKey = trim((string) $rowKey);
                if ($rowKey === '') {
                    continue;
                }
                $normalized[$rowKey] = trim((string) $selectedValue);
            }
            return ['rows' => $normalized];
        }
        if (is_array($raw)) {
            $arr = [];
            foreach ($raw as $v) {
                if (is_string($v)) {
                    $arr[] = trim($v);
                }
            }
            return $arr;
        }
        if ($raw === null) {
            return $type === 'checkbox' ? [] : '';
        }
        if (is_string($raw)) {
            return trim($raw);
        }
        return '';
    }

    private function validateScalar(array $field, $value): void
    {
        $key   = $field['field_key'];
        $label = $field['label'];
        $type  = $field['type'];
        $req   = (int) ($field['required'] ?? 0) === 1;
        $minL  = isset($field['min_length']) ? (int) $field['min_length'] : 0;
        $maxL  = isset($field['max_length']) ? (int) $field['max_length'] : 0;
        $exactL = isset($field['exact_length']) ? (int) $field['exact_length'] : 0;
        $regexStored = $field['regex'] ?? '';
        $regexPatterns = is_string($regexStored)
            ? FormField::decodeRegexPatterns($regexStored)
            : [];
        $opts  = self::decodeOptions($field['options_json'] ?? null);
        $checkboxSettings = $type === 'checkbox'
            ? FormField::decodeCheckboxSettings($field['options_json'] ?? null)
            : ['options' => [], 'min_selections' => '', 'max_selections' => ''];

        if ($type === 'address') {
            $this->validateAddressField($field, $value);
            return;
        }
        if ($type === 'text_pair') {
            $this->validateTextPairField($field, $value);
            return;
        }
        if ($type === 'text_multi') {
            $this->validateTextMultiField($field, $value);
            return;
        }
        if ($type === FormField::TYPE_MATRIX) {
            $this->validateMatrixField($field, $value);
            return;
        }

        $isEmpty = is_array($value) ? count($value) === 0 : ((string) $value === '');
        if ($req && $isEmpty) {
            $this->errors[$key][] = $label . 'は必須項目です。';
            return;
        }
        if ($isEmpty) {
            return;
        }

        if (is_string($value)) {
            if ($exactL > 0) {
                if (mb_strlen($value, 'UTF-8') !== $exactL) {
                    $this->errors[$key][] = $label . 'は' . $exactL . '文字で入力してください。';
                }
            } else {
                if ($minL > 0 && mb_strlen($value, 'UTF-8') < $minL) {
                    $this->errors[$key][] = $label . 'は' . $minL . '文字以上で入力してください。';
                }
                if ($maxL > 0 && mb_strlen($value, 'UTF-8') > $maxL) {
                    $this->errors[$key][] = $label . 'は' . $maxL . '文字以内で入力してください。';
                }
            }
            foreach ($regexPatterns as $regex) {
                if ($regex === '') {
                    continue;
                }
                if (@preg_match($regex, '') === false) {
                    $this->errors[$key][] = $label . 'の検証設定が不正です。';
                    break;
                }
                if (!preg_match($regex, $value)) {
                    $this->errors[$key][] = $label . 'の形式が正しくありません。';
                    break;
                }
            }
        }

        switch ($type) {
            case 'email':
                if (is_string($value) && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $this->errors[$key][] = $label . 'はメールアドレスの形式で入力してください。';
                }
                break;
            case 'tel':
                if (is_string($value) && !preg_match('/\A[0-9+\-\s()]{6,20}\z/', $value)) {
                    $this->errors[$key][] = $label . 'は電話番号の形式で入力してください。';
                }
                break;
            case 'number':
                if (is_string($value) && !is_numeric($value)) {
                    $this->errors[$key][] = $label . 'は数値で入力してください。';
                }
                break;
            case 'date':
                if (is_string($value) && !$this->isValidDate($value)) {
                    $this->errors[$key][] = $label . 'は有効な日付（YYYY-MM-DD）で入力してください。';
                }
                break;
            case FormField::TYPE_POSTAL_CODE:
                if (is_string($value) && !$this->isValidPostalDigits($value)) {
                    $this->errors[$key][] = $label . 'は7桁の郵便番号で入力してください。';
                }
                break;
            case 'time':
                if (is_string($value) && !preg_match('/\A([01]\d|2[0-3]):[0-5]\d\z/', $value)) {
                    $this->errors[$key][] = $label . 'は有効な時刻（HH:MM）で入力してください。';
                }
                break;
            case 'radio':
            case 'select':
                if (is_string($value) && !in_array($value, $opts, true)) {
                    $this->errors[$key][] = $label . 'の値が不正です。';
                }
                break;
            case 'checkbox':
                if (is_array($value)) {
                    foreach ($value as $v) {
                        if (!in_array($v, $opts, true)) {
                            $this->errors[$key][] = $label . 'の値が不正です。';
                            break;
                        }
                    }
                    $selectedCount = count($value);
                    $minSelections = $checkboxSettings['min_selections'] !== ''
                        ? (int) $checkboxSettings['min_selections']
                        : 0;
                    $maxSelections = $checkboxSettings['max_selections'] !== ''
                        ? (int) $checkboxSettings['max_selections']
                        : 0;
                    if ($minSelections > 0 && $selectedCount < $minSelections) {
                        $this->errors[$key][] = $label . 'は' . $minSelections . '個以上選択してください。';
                    }
                    if ($maxSelections > 0 && $selectedCount > $maxSelections) {
                        $this->errors[$key][] = $label . 'は' . $maxSelections . '個以下で選択してください。';
                    }
                }
                break;
        }
    }

    /**
     * @param mixed $value normalize 済みの連想配列を想定
     */
    private function validateTextPairField(array $field, $value): void
    {
        $key   = $field['field_key'];
        $label = $field['label'];
        $req   = (int) ($field['required'] ?? 0) === 1;
        $minL  = isset($field['min_length']) ? (int) $field['min_length'] : 0;
        $maxL  = isset($field['max_length']) ? (int) $field['max_length'] : 0;
        $exactL = isset($field['exact_length']) ? (int) $field['exact_length'] : 0;
        $regexStored = $field['regex'] ?? '';
        $regexPatterns = is_string($regexStored)
            ? FormField::decodeRegexPatterns($regexStored)
            : [];
        $pairLabels = FormField::decodeTextPairLabels($field['options_json'] ?? null);
        $leftLabel = $pairLabels['left_label'] !== '' ? $pairLabels['left_label'] : '入力欄1';
        $rightLabel = $pairLabels['right_label'] !== '' ? $pairLabels['right_label'] : '入力欄2';

        if (!is_array($value)) {
            $this->addTextPairPartError($key, '_root', $label . 'の入力形式が不正です。');
            return;
        }

        $left = (string) ($value['left'] ?? '');
        $right = (string) ($value['right'] ?? '');
        $allEmpty = ($left === '' && $right === '');

        if ($req && $allEmpty) {
            $this->addTextPairPartError($key, 'left', $label . 'の' . $leftLabel . 'を入力してください。');
            $this->addTextPairPartError($key, 'right', $label . 'の' . $rightLabel . 'を入力してください。');
            return;
        }
        if (!$req && $allEmpty) {
            return;
        }
        if ($req && $left === '') {
            $this->addTextPairPartError($key, 'left', $label . 'の' . $leftLabel . 'を入力してください。');
        }
        if ($req && $right === '') {
            $this->addTextPairPartError($key, 'right', $label . 'の' . $rightLabel . 'を入力してください。');
        }

        foreach (['left' => $leftLabel, 'right' => $rightLabel] as $part => $partLabel) {
            $partValue = (string) ($value[$part] ?? '');
            if ($partValue === '') {
                continue;
            }
            if ($exactL > 0) {
                if (mb_strlen($partValue, 'UTF-8') !== $exactL) {
                    $this->addTextPairPartError($key, $part, $label . 'の' . $partLabel . 'は' . $exactL . '文字で入力してください。');
                }
            } else {
                if ($minL > 0 && mb_strlen($partValue, 'UTF-8') < $minL) {
                    $this->addTextPairPartError($key, $part, $label . 'の' . $partLabel . 'は' . $minL . '文字以上で入力してください。');
                }
                if ($maxL > 0 && mb_strlen($partValue, 'UTF-8') > $maxL) {
                    $this->addTextPairPartError($key, $part, $label . 'の' . $partLabel . 'は' . $maxL . '文字以内で入力してください。');
                }
            }
            foreach ($regexPatterns as $regex) {
                if ($regex === '') {
                    continue;
                }
                if (@preg_match($regex, '') === false) {
                    $this->addTextPairPartError($key, $part, $label . 'の検証設定が不正です。');
                    break 2;
                }
                if (!preg_match($regex, $partValue)) {
                    $this->addTextPairPartError($key, $part, $label . 'の' . $partLabel . 'の形式が正しくありません。');
                    break;
                }
            }
        }
    }

    /**
     * @param mixed $value normalize 済みの配列を想定
     */
    private function validateTextMultiField(array $field, $value): void
    {
        $key   = $field['field_key'];
        $label = $field['label'];
        $req   = (int) ($field['required'] ?? 0) === 1;
        $minL  = isset($field['min_length']) ? (int) $field['min_length'] : 0;
        $maxL  = isset($field['max_length']) ? (int) $field['max_length'] : 0;
        $exactL = isset($field['exact_length']) ? (int) $field['exact_length'] : 0;
        $regexStored = $field['regex'] ?? '';
        $regexPatterns = is_string($regexStored)
            ? FormField::decodeRegexPatterns($regexStored)
            : [];
        $configuredItems = FormField::decodeTextMultiItems($field['options_json'] ?? null, true);

        if (!is_array($value) || !isset($value['items']) || !is_array($value['items'])) {
            $this->addTextMultiPartError($key, '_root', $label . 'の入力形式が不正です。');
            return;
        }

        $items = array_values(array_map(static fn($item): string => trim((string) $item), $value['items']));
        $expectedCount = count($configuredItems);
        if ($expectedCount === 0) {
            $this->addTextMultiPartError($key, '_root', $label . 'の入力欄設定が不正です。');
            return;
        }
        if (count($items) > $expectedCount) {
            $this->addTextMultiPartError($key, '_root', $label . 'の入力数が不正です。');
            return;
        }
        for ($i = count($items); $i < $expectedCount; $i++) {
            $items[$i] = '';
        }

        $allEmpty = true;
        foreach ($items as $itemValue) {
            if ($itemValue !== '') {
                $allEmpty = false;
                break;
            }
        }

        if ($req && $allEmpty) {
            foreach ($configuredItems as $index => $item) {
                $partLabel = FormField::textMultiItemDisplayLabel($item, $index, '内容');
                $this->addTextMultiPartError($key, (string) $index, $label . 'の' . $partLabel . 'を入力してください。');
            }
            return;
        }
        if (!$req && $allEmpty) {
            return;
        }

        foreach ($configuredItems as $index => $item) {
            $partLabel = FormField::textMultiItemDisplayLabel($item, $index, '内容');
            $itemValue = (string) ($items[$index] ?? '');
            if ($req && $itemValue === '') {
                $this->addTextMultiPartError($key, (string) $index, $label . 'の' . $partLabel . 'を入力してください。');
                continue;
            }
            if ($itemValue === '') {
                continue;
            }
            if ($exactL > 0) {
                if (mb_strlen($itemValue, 'UTF-8') !== $exactL) {
                    $this->addTextMultiPartError($key, (string) $index, $label . 'の' . $partLabel . 'は' . $exactL . '文字で入力してください。');
                }
            } else {
                if ($minL > 0 && mb_strlen($itemValue, 'UTF-8') < $minL) {
                    $this->addTextMultiPartError($key, (string) $index, $label . 'の' . $partLabel . 'は' . $minL . '文字以上で入力してください。');
                }
                if ($maxL > 0 && mb_strlen($itemValue, 'UTF-8') > $maxL) {
                    $this->addTextMultiPartError($key, (string) $index, $label . 'の' . $partLabel . 'は' . $maxL . '文字以内で入力してください。');
                }
            }
            foreach ($regexPatterns as $regex) {
                if ($regex === '') {
                    continue;
                }
                if (@preg_match($regex, '') === false) {
                    $this->addTextMultiPartError($key, (string) $index, $label . 'の検証設定が不正です。');
                    break 2;
                }
                if (!preg_match($regex, $itemValue)) {
                    $this->addTextMultiPartError($key, (string) $index, $label . 'の' . $partLabel . 'の形式が正しくありません。');
                    break;
                }
            }
        }
    }

    /**
     * @param mixed $value normalize 済みの配列を想定
     */
    private function validateMatrixField(array $field, $value): void
    {
        $key = (string) ($field['field_key'] ?? '');
        $label = (string) ($field['label'] ?? '');
        $req = (int) ($field['required'] ?? 0) === 1;
        $settings = FormField::decodeMatrixSettings($field['options_json'] ?? null);
        $rows = $settings['rows'];
        $columns = $settings['columns'];

        if (!is_array($value) || !isset($value['rows']) || !is_array($value['rows'])) {
            $this->errors[$key][] = $label . 'の入力形式が不正です。';
            return;
        }

        $selectedRows = $value['rows'];
        $hasAny = false;
        foreach ($rows as $rowLabel) {
            $selected = trim((string) ($selectedRows[$rowLabel] ?? ''));
            if ($selected !== '') {
                $hasAny = true;
            }
            if ($selected !== '' && !in_array($selected, $columns, true)) {
                $this->errors[$key][] = $label . 'の選択値が不正です。';
                return;
            }
            if ($req && $selected === '') {
                $this->errors[$key][] = $label . 'の「' . $rowLabel . '」を選択してください。';
            }
        }

        if (!$req && !$hasAny) {
            return;
        }
    }

    /**
     * @param mixed $value normalize 済みの連想配列を想定
     */
    private function validateAddressField(array $field, $value): void
    {
        $key   = $field['field_key'];
        $label = $field['label'];
        $req   = (int) ($field['required'] ?? 0) === 1;
        $minL  = isset($field['min_length']) ? (int) $field['min_length'] : 0;
        $maxL  = isset($field['max_length']) ? (int) $field['max_length'] : 0;
        $exactL = isset($field['exact_length']) ? (int) $field['exact_length'] : 0;
        $regexStored = $field['regex'] ?? '';
        $regexPatterns = is_string($regexStored)
            ? FormField::decodeRegexPatterns($regexStored)
            : [];

        if (!is_array($value)) {
            $this->addAddressPartError($key, '_root', $label . 'の入力形式が不正です。');
            return;
        }
        $postal = (string) ($value['postal'] ?? '');
        $pref   = (string) ($value['prefecture'] ?? '');
        $city   = (string) ($value['city'] ?? '');
        $number = (string) ($value['number'] ?? '');
        $build  = (string) ($value['building'] ?? '');
        $allEmpty = ($postal === '' && $pref === '' && $city === '' && $number === '' && $build === '');

        if ($req && $allEmpty) {
            $this->addAddressPartError($key, 'prefecture', $label . 'の都道府県を選択してください。');
            $this->addAddressPartError($key, 'city', $label . 'の市区町村を入力してください。');
            $this->addAddressPartError($key, 'number', $label . 'の番地を入力してください。');
            return;
        }
        // 項目全体が任意でも、何か入力があれば都道府県・市区町村・番地は必須（郵便番号・建物は任意）
        if (!$req && $allEmpty) {
            return;
        }

        $prefs = array_flip(\japanese_prefectures());

        if ($postal !== '' && !$this->isValidPostalDigits($postal)) {
            $this->addAddressPartError($key, 'postal', $label . 'の郵便番号は7桁の数字で入力してください。');
        }
        if ($pref === '') {
            $this->addAddressPartError($key, 'prefecture', $label . 'の都道府県を選択してください。');
        } elseif (!isset($prefs[$pref])) {
            $this->addAddressPartError($key, 'prefecture', $label . 'の都道府県が不正です。');
        }
        if ($city === '') {
            $this->addAddressPartError($key, 'city', $label . 'の市区町村を入力してください。');
        }
        if ($number === '') {
            $this->addAddressPartError($key, 'number', $label . 'の番地を入力してください。');
        }

        $combined = $pref . $city . $number . $build;
        if ($exactL > 0) {
            if ($combined !== '' && mb_strlen($combined, 'UTF-8') !== $exactL) {
                $this->addAddressPartError($key, 'combined', $label . 'は合計' . $exactL . '文字で入力してください。');
            }
        } else {
            if ($minL > 0 && $city !== '' && mb_strlen($city, 'UTF-8') < $minL) {
                $this->addAddressPartError($key, 'city', $label . 'の市区町村は' . $minL . '文字以上で入力してください。');
            }
            if ($minL > 0 && $number !== '' && mb_strlen($number, 'UTF-8') < $minL) {
                $this->addAddressPartError($key, 'number', $label . 'の番地は' . $minL . '文字以上で入力してください。');
            }
            if ($minL > 0 && $build !== '' && mb_strlen($build, 'UTF-8') < $minL) {
                $this->addAddressPartError($key, 'building', $label . 'の建物名・部屋番号は' . $minL . '文字以上で入力してください。');
            }
            if ($maxL > 0 && mb_strlen($combined, 'UTF-8') > $maxL) {
                $this->addAddressPartError($key, 'combined', $label . 'は合計' . $maxL . '文字以内で入力してください。');
            }
        }

        foreach ($regexPatterns as $regex) {
            if ($regex === '') {
                continue;
            }
            if (@preg_match($regex, '') === false) {
                $this->addAddressPartError($key, 'combined', $label . 'の検証設定が不正です。');
                break;
            }
            if (!preg_match($regex, $combined)) {
                $this->addAddressPartError($key, 'combined', $label . 'の形式が正しくありません。');
                break;
            }
        }
    }

    /**
     * 住所フィールドのエラーを入力欄ごとに分類して格納する。
     *
     * @param string $part postal|prefecture|city|number|combined|_root
     */
    private function addAddressPartError(string $key, string $part, string $message): void
    {
        if (!isset($this->errors[$key])) {
            $this->errors[$key] = [];
        }
        if (!isset($this->errors[$key][$part])) {
            $this->errors[$key][$part] = [];
        }
        $this->errors[$key][$part][] = $message;
    }

    /**
     * @param string $part left|right|_root
     */
    private function addTextPairPartError(string $key, string $part, string $message): void
    {
        if (!isset($this->errors[$key])) {
            $this->errors[$key] = [];
        }
        if (!isset($this->errors[$key][$part])) {
            $this->errors[$key][$part] = [];
        }
        $this->errors[$key][$part][] = $message;
    }

    /**
     * @param string $part 数値文字列または _root
     */
    private function addTextMultiPartError(string $key, string $part, string $message): void
    {
        if (!isset($this->errors[$key])) {
            $this->errors[$key] = [];
        }
        if ($part === '_root') {
            if (!isset($this->errors[$key]['_root'])) {
                $this->errors[$key]['_root'] = [];
            }
            $this->errors[$key]['_root'][] = $message;
            return;
        }
        if (!isset($this->errors[$key]['items'])) {
            $this->errors[$key]['items'] = [];
        }
        if (!isset($this->errors[$key]['items'][(int) $part])) {
            $this->errors[$key]['items'][(int) $part] = [];
        }
        $this->errors[$key]['items'][(int) $part][] = $message;
    }

    private function isValidPostalDigits(string $postal): bool
    {
        $d = preg_replace('/\D/', '', $postal);
        return strlen($d) === 7;
    }

    private function validateFile(array $field, $entry): void
    {
        $key   = $field['field_key'];
        $label = $field['label'];
        $req   = (int) ($field['required'] ?? 0) === 1;

        if (!$entry || !isset($entry['error']) || $entry['error'] === UPLOAD_ERR_NO_FILE) {
            if ($req) {
                $this->errors[$key][] = $label . 'は必須項目です。';
            }
            return;
        }

        if ($entry['error'] !== UPLOAD_ERR_OK) {
            $this->errors[$key][] = $label . 'のアップロードに失敗しました。' . self::fileUploadErrorMessage((int) $entry['error']);
            return;
        }

        $maxSize = (int) config('upload.max_size', 5 * 1024 * 1024);
        if (($entry['size'] ?? 0) > $maxSize) {
            $this->errors[$key][] = $label . 'のファイルサイズが大きすぎます（最大' . self::formatBytes($maxSize) . '）。';
            return;
        }

        $fileSettings = FormField::decodeFileSettings($field['options_json'] ?? null);
        $fileSelectionMode = FormField::normalizeFileSelectionMode((string) ($fileSettings['selection_mode'] ?? FormField::FILE_SELECTION_CUSTOM));
        $allowed = $fileSelectionMode === FormField::FILE_SELECTION_IMAGE
            ? FormField::imageUploadExtensions()
            : array_map('strtolower', (array) config('upload.allowed_extensions', []));
        if ($fileSelectionMode === FormField::FILE_SELECTION_CUSTOM && $fileSettings['allowed_extensions'] !== []) {
            $allowed = $fileSettings['allowed_extensions'];
        }
        $ext = strtolower(pathinfo($entry['name'] ?? '', PATHINFO_EXTENSION));
        if ($ext === '' || !in_array($ext, $allowed, true)) {
            $displayAllowed = $allowed !== [] ? implode(', ', array_map(static fn($item): string => '.' . $item, $allowed)) : '';
            $this->errors[$key][] = $label . 'のファイル形式が許可されていません。'
                . ($displayAllowed !== '' ? ' 許可形式: ' . $displayAllowed : '');
            return;
        }

        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime  = finfo_file($finfo, $entry['tmp_name']);
            finfo_close($finfo);
            if ($mime === false) {
                $this->errors[$key][] = $label . 'のファイルが読み取れません。';
                return;
            }
            $mime = strtolower((string) $mime);
            if (!FileTypePolicy::isMimeAllowedForExtension($ext, $mime)) {
                $this->errors[$key][] = $label . 'の拡張子とファイル内容が一致しません。';
                return;
            }
            if ($fileSelectionMode === FormField::FILE_SELECTION_IMAGE) {
                $isImageMime = str_starts_with($mime, 'image/');
                $isHeicLikeExt = in_array($ext, ['heic', 'heif'], true);
                $mimeLooksUnknown = in_array($mime, ['application/octet-stream', 'application/x-empty'], true);
                if (!$isImageMime && !($isHeicLikeExt && $mimeLooksUnknown)) {
                    $this->errors[$key][] = $label . 'は画像ファイルを選択してください。';
                    return;
                }
            }
        }
    }

    private static function fileUploadErrorMessage(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE => 'サーバーのアップロード上限を超えています。画像を小さくするか、PHP の upload_max_filesize / post_max_size を確認してください。（コード:1）',
            UPLOAD_ERR_FORM_SIZE => 'フォームで指定されたアップロード上限を超えています。（コード:2）',
            UPLOAD_ERR_PARTIAL => 'ファイルが途中までしかアップロードされませんでした。通信状況を確認して再度お試しください。（コード:3）',
            UPLOAD_ERR_NO_TMP_DIR => 'サーバーの一時保存ディレクトリが見つかりません。管理者にお問い合わせください。（コード:6）',
            UPLOAD_ERR_CANT_WRITE => 'サーバーにファイルを書き込めませんでした。管理者にお問い合わせください。（コード:7）',
            UPLOAD_ERR_EXTENSION => 'サーバーの拡張機能によりアップロードが停止されました。管理者にお問い合わせください。（コード:8）',
            default => '時間をおいて再度お試しください。（コード:' . $code . '）',
        };
    }

    private function isValidDate(string $value): bool
    {
        $d = \DateTime::createFromFormat('Y-m-d', $value);
        return $d && $d->format('Y-m-d') === $value;
    }

    public static function decodeOptions($json): array
    {
        if (empty($json)) {
            return [];
        }
        $arr = json_decode($json, true);
        if (!is_array($arr)) {
            return [];
        }
        if (array_keys($arr) !== range(0, count($arr) - 1)) {
            $arr = $arr['options'] ?? [];
            if (!is_array($arr) || array_keys($arr) !== range(0, count($arr) - 1)) {
                return [];
            }
        }
        return array_values(array_filter(array_map(
            static fn($value): string => is_scalar($value) ? (string) $value : '',
            $arr
        ), static fn($value): bool => $value !== ''));
    }

    public static function formatBytes(int $bytes): string
    {
        if ($bytes >= 1024 * 1024) return round($bytes / 1024 / 1024, 1) . 'MB';
        if ($bytes >= 1024)        return round($bytes / 1024, 1) . 'KB';
        return $bytes . 'B';
    }
}
