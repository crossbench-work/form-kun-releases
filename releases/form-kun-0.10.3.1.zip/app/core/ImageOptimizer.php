<?php
namespace Core;

/**
 * アップロード画像のリサイズ・再圧縮（GD）と、必要に応じた JPEG 変換。
 */
class ImageOptimizer
{
  private const SUPPORTED_MIMES = [
    'image/jpeg' => 'jpeg',
    'image/png'  => 'png',
    'image/webp' => 'webp',
  ];

  public static function isAvailable(): bool
  {
    return extension_loaded('gd');
  }

  public static function canOptimizeMime(string $mime): bool
  {
    return isset(self::SUPPORTED_MIMES[strtolower($mime)]);
  }

  public static function canConvertToJpegMime(string $mime): bool
  {
    $mime = strtolower(trim($mime));
    if ($mime === '') {
      return false;
    }
    if (in_array($mime, ['image/jpeg', 'image/png', 'image/gif', 'image/webp'], true)) {
      return extension_loaded('gd');
    }
    if (in_array($mime, ['image/heic', 'image/heif'], true)) {
      return class_exists(\Imagick::class);
    }
    return false;
  }

  /**
   * @param array<string, mixed> $config upload.image 設定
   * @return array{mime_type:string, size:int, stored_ext:string}|null 最適化しない場合は null
   */
  public static function optimize(string $sourcePath, string $destBasePath, array $config): ?array
  {
    if (empty($config['enabled']) || !self::isAvailable() || !is_file($sourcePath)) {
      return null;
    }

    $mime = self::detectMime($sourcePath);
    if ($mime === null || !self::canOptimizeMime($mime)) {
      return null;
    }

    $maxW = max(1, (int) ($config['max_width'] ?? 1280));
    $maxH = max(1, (int) ($config['max_height'] ?? 1280));
    $jpegQ = max(1, min(100, (int) ($config['jpeg_quality'] ?? 82)));
    $webpQ = max(1, min(100, (int) ($config['webp_quality'] ?? 80)));
    $pngLevel = max(0, min(9, (int) ($config['png_compression'] ?? 6)));
    $tryWebp = !empty($config['try_webp']) && function_exists('imagewebp');

    $image = self::loadImage($sourcePath, $mime);
    if ($image === null) {
      return null;
    }

    try {
      if ($mime === 'image/jpeg') {
        $image = self::applyExifOrientation($sourcePath, $image) ?? $image;
      }

      [$image, $resized] = self::resizeDown($image, $maxW, $maxH);
      $originalSize = filesize($sourcePath) ?: PHP_INT_MAX;
      $candidates = [];

      $format = self::SUPPORTED_MIMES[$mime];
      $nativePath = $destBasePath . '.opt.' . $format;
      if (self::saveFormat($image, $format, $nativePath, $jpegQ, $pngLevel, $webpQ)) {
        $candidates[] = [
          'path' => $nativePath,
          'mime' => $mime,
          'ext'  => self::extForFormat($format),
        ];
      }

      if ($tryWebp) {
        $webpPath = $destBasePath . '.opt.webp';
        if (self::saveFormat($image, 'webp', $webpPath, $jpegQ, $pngLevel, $webpQ)) {
          $candidates[] = [
            'path' => $webpPath,
            'mime' => 'image/webp',
            'ext'  => '.webp',
          ];
        }
      }

      $best = null;
      $bestSize = PHP_INT_MAX;
      foreach ($candidates as $c) {
        if (!is_file($c['path'])) {
          continue;
        }
        $size = filesize($c['path']) ?: PHP_INT_MAX;
        if ($size < $bestSize) {
          $bestSize = $size;
          $best = $c;
        }
      }

      foreach ($candidates as $c) {
        if ($best === null || $c['path'] !== $best['path']) {
          @unlink($c['path']);
        }
      }

      imagedestroy($image);

      if ($best === null) {
        return null;
      }

      if (!$resized && $bestSize >= $originalSize) {
        @unlink($best['path']);
        return null;
      }

      return [
        'mime_type'   => $best['mime'],
        'size'        => $bestSize,
        'stored_ext'  => $best['ext'],
        'output_path' => $best['path'],
      ];
    } catch (\Throwable $e) {
      if (is_resource($image) || $image instanceof \GdImage) {
        imagedestroy($image);
      }
      error_log('[formkun] ImageOptimizer: ' . $e->getMessage());
      return null;
    }
  }

  /**
   * @param array<string, mixed> $config
   * @return array{mime_type:string,size:int,stored_ext:string,output_path:string}|null
   */
  public static function convertToJpeg(string $sourcePath, string $destBasePath, array $config): ?array
  {
    if (!is_file($sourcePath)) {
      return null;
    }

    $mime = self::detectMime($sourcePath);
    if ($mime === null || !self::canConvertToJpegMime($mime)) {
      return null;
    }

    $maxW = max(1, (int) ($config['max_width'] ?? 1280));
    $maxH = max(1, (int) ($config['max_height'] ?? 1280));
    $jpegQ = max(1, min(100, (int) ($config['jpeg_quality'] ?? 82)));
    $outputPath = $destBasePath . '.opt.jpg';

    if (in_array($mime, ['image/heic', 'image/heif'], true)) {
      return self::convertImagickToJpeg($sourcePath, $outputPath, $maxW, $maxH, $jpegQ);
    }

    $image = self::loadImage($sourcePath, $mime);
    if ($image === null) {
      return null;
    }

    try {
      if ($mime === 'image/jpeg') {
        $image = self::applyExifOrientation($sourcePath, $image) ?? $image;
      }
      [$image] = self::resizeDown($image, $maxW, $maxH);
      $jpegImage = self::flattenForJpeg($image);
      if ($jpegImage !== $image) {
        imagedestroy($image);
      }
      if (!self::saveFormat($jpegImage, 'jpeg', $outputPath, $jpegQ, 6, 80)) {
        imagedestroy($jpegImage);
        return null;
      }
      imagedestroy($jpegImage);
      return [
        'mime_type'   => 'image/jpeg',
        'size'        => (int) (filesize($outputPath) ?: 0),
        'stored_ext'  => '.jpg',
        'output_path' => $outputPath,
      ];
    } catch (\Throwable $e) {
      if (is_resource($image) || $image instanceof \GdImage) {
        imagedestroy($image);
      }
      error_log('[formkun] ImageOptimizer JPEG: ' . $e->getMessage());
      return null;
    }
  }

  private static function detectMime(string $path): ?string
  {
    if (!function_exists('finfo_open')) {
      return null;
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    if ($finfo === false) {
      return null;
    }
    $mime = finfo_file($finfo, $path);
    finfo_close($finfo);
    if ($mime === false || $mime === '') {
      return null;
    }
    return strtolower((string) $mime);
  }

  /** @return \GdImage|resource|null */
  private static function loadImage(string $path, string $mime)
  {
    return match ($mime) {
      'image/jpeg' => @imagecreatefromjpeg($path) ?: null,
      'image/gif'  => @imagecreatefromgif($path) ?: null,
      'image/png'  => @imagecreatefrompng($path) ?: null,
      'image/webp' => function_exists('imagecreatefromwebp') ? (@imagecreatefromwebp($path) ?: null) : null,
      default      => null,
    };
  }

  /** @param \GdImage|resource $image */
  private static function applyExifOrientation(string $path, $image)
  {
    if (!function_exists('exif_read_data')) {
      return $image;
    }
    $exif = @exif_read_data($path);
    if (!is_array($exif) || !isset($exif['Orientation'])) {
      return $image;
    }
    return match ((int) $exif['Orientation']) {
      2 => self::flipHorizontal($image),
      3 => imagerotate($image, 180, 0) ?: $image,
      4 => self::flipVertical($image),
      5 => self::rotateAndFlip($image, 270, true),
      6 => imagerotate($image, -90, 0) ?: $image,
      7 => self::rotateAndFlip($image, 90, true),
      8 => imagerotate($image, 90, 0) ?: $image,
      default => $image,
    };
  }

  /** @param \GdImage|resource $image */
  private static function flipHorizontal($image)
  {
    if (function_exists('imageflip')) {
      imageflip($image, IMG_FLIP_HORIZONTAL);
      return $image;
    }
    return $image;
  }

  /** @param \GdImage|resource $image */
  private static function flipVertical($image)
  {
    if (function_exists('imageflip')) {
      imageflip($image, IMG_FLIP_VERTICAL);
      return $image;
    }
    return $image;
  }

  /** @param \GdImage|resource $image */
  private static function rotateAndFlip($image, int $angle, bool $flipH)
  {
    $rotated = imagerotate($image, $angle, 0);
    if ($rotated === false) {
      return $image;
    }
    imagedestroy($image);
    if ($flipH) {
      return self::flipHorizontal($rotated);
    }
    return $rotated;
  }

  /**
   * @param \GdImage|resource $image
   * @return array{0:\GdImage|resource,1:bool}
   */
  private static function resizeDown($image, int $maxW, int $maxH): array
  {
    $w = imagesx($image);
    $h = imagesy($image);
    if ($w <= 0 || $h <= 0) {
      return [$image, false];
    }
    $scale = min($maxW / $w, $maxH / $h, 1.0);
    if ($scale >= 1.0) {
      return [$image, false];
    }
    $nw = max(1, (int) round($w * $scale));
    $nh = max(1, (int) round($h * $scale));
    $resized = imagecreatetruecolor($nw, $nh);
    if ($resized === false) {
      return [$image, false];
    }
    imagealphablending($resized, false);
    imagesavealpha($resized, true);
    $transparent = imagecolorallocatealpha($resized, 0, 0, 0, 127);
    if ($transparent !== false) {
      imagefill($resized, 0, 0, $transparent);
    }
    imagecopyresampled($resized, $image, 0, 0, 0, 0, $nw, $nh, $w, $h);
    imagedestroy($image);
    return [$resized, true];
  }

  private static function saveFormat($image, string $format, string $path, int $jpegQ, int $pngLevel, int $webpQ): bool
  {
    if ($format === 'png') {
      imagesavealpha($image, true);
    }
    $ok = match ($format) {
      'jpeg' => imagejpeg($image, $path, $jpegQ),
      'png'  => imagepng($image, $path, $pngLevel),
      'webp' => function_exists('imagewebp') ? imagewebp($image, $path, $webpQ) : false,
      default => false,
    };
    if ($ok) {
      @chmod($path, 0644);
    }
    return (bool) $ok;
  }

  private static function extForFormat(string $format): string
  {
    return match ($format) {
      'jpeg' => '.jpg',
      'png'  => '.png',
      'webp' => '.webp',
      default => '.bin',
    };
  }

  /** @param \GdImage|resource $image */
  private static function flattenForJpeg($image)
  {
    $w = imagesx($image);
    $h = imagesy($image);
    $canvas = imagecreatetruecolor($w, $h);
    if ($canvas === false) {
      return $image;
    }
    $white = imagecolorallocate($canvas, 255, 255, 255);
    if ($white !== false) {
      imagefill($canvas, 0, 0, $white);
    }
    imagecopy($canvas, $image, 0, 0, 0, 0, $w, $h);
    return $canvas;
  }

  /**
   * @return array{mime_type:string,size:int,stored_ext:string,output_path:string}|null
   */
  private static function convertImagickToJpeg(string $sourcePath, string $outputPath, int $maxW, int $maxH, int $jpegQ): ?array
  {
    if (!class_exists(\Imagick::class)) {
      return null;
    }

    try {
      $image = new \Imagick();
      $image->readImage($sourcePath);
      if (method_exists($image, 'setIteratorIndex')) {
        $image->setIteratorIndex(0);
      }
      if (method_exists($image, 'autoOrient')) {
        $image->autoOrient();
      } elseif (method_exists($image, 'autoOrientImage')) {
        $image->autoOrientImage();
      }
      $image->setImageBackgroundColor('white');
      if (method_exists($image, 'mergeImageLayers') && defined('Imagick::LAYERMETHOD_FLATTEN')) {
        $flattened = $image->mergeImageLayers(\Imagick::LAYERMETHOD_FLATTEN);
        if ($flattened instanceof \Imagick) {
          $image->clear();
          $image->destroy();
          $image = $flattened;
        }
      }
      $image->thumbnailImage($maxW, $maxH, true, true);
      $image->setImageFormat('jpeg');
      $image->setImageCompressionQuality($jpegQ);
      $image->stripImage();
      if (!$image->writeImage($outputPath)) {
        $image->clear();
        $image->destroy();
        return null;
      }
      @chmod($outputPath, 0644);
      $size = (int) (filesize($outputPath) ?: 0);
      $image->clear();
      $image->destroy();
      return [
        'mime_type'   => 'image/jpeg',
        'size'        => $size,
        'stored_ext'  => '.jpg',
        'output_path' => $outputPath,
      ];
    } catch (\Throwable $e) {
      error_log('[formkun] ImageOptimizer Imagick JPEG: ' . $e->getMessage());
      return null;
    }
  }
}
