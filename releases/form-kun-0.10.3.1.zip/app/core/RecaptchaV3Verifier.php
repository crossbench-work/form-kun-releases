<?php
namespace Core;

class RecaptchaV3Verifier
{
    public const VALID = 'valid';
    public const INVALID = 'invalid';
    public const UNAVAILABLE = 'unavailable';
    private const VERIFY_URL = 'https://www.google.com/recaptcha/api/siteverify';
    private const EXPECTED_ACTION = 'submit';

    public static function verify(
        string $secret,
        string $token,
        string $ip,
        string $expectedHostname,
        float $minimumScore
    ): string {
        $secret = trim($secret);
        $token = trim($token);
        if ($secret === '' || $token === '' || strlen($token) > 4096) {
            return self::INVALID;
        }
        $payload = http_build_query([
            'secret' => $secret,
            'response' => $token,
            'remoteip' => substr($ip, 0, 45),
        ], '', '&', PHP_QUERY_RFC3986);
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/x-www-form-urlencoded\r\nAccept: application/json\r\n",
                'content' => $payload,
                'timeout' => 5,
                'ignore_errors' => true,
            ],
        ]);
        $response = @file_get_contents(self::VERIFY_URL, false, $context);
        if ($response === false) {
            error_log('[formkun] reCAPTCHA v3 Siteverify request failed');
            return self::UNAVAILABLE;
        }
        $status = self::responseStatus($http_response_header ?? []);
        $decoded = json_decode($response, true);
        if ($status < 200 || $status >= 300 || !is_array($decoded)) {
            error_log('[formkun] reCAPTCHA v3 Siteverify returned an invalid response');
            return self::UNAVAILABLE;
        }
        return self::validateResponse($decoded, $expectedHostname, $minimumScore);
    }

    /** @param array<string, mixed> $response */
    public static function validateResponse(array $response, string $expectedHostname, float $minimumScore): string
    {
        if (empty($response['success']) || !isset($response['score']) || !is_numeric($response['score'])) {
            return self::INVALID;
        }
        $hostname = strtolower(rtrim(trim((string) ($response['hostname'] ?? '')), '.'));
        $expectedHostname = strtolower(rtrim(trim($expectedHostname), '.'));
        $action = trim((string) ($response['action'] ?? ''));
        $score = (float) $response['score'];
        $minimumScore = max(0.0, min(1.0, $minimumScore));
        if ($hostname === '' || !hash_equals($expectedHostname, $hostname)) {
            return self::INVALID;
        }
        if (!hash_equals(self::EXPECTED_ACTION, $action)) {
            return self::INVALID;
        }
        return $score >= $minimumScore ? self::VALID : self::INVALID;
    }

    /** @param list<string> $headers */
    private static function responseStatus(array $headers): int
    {
        foreach ($headers as $header) {
            if (preg_match('/\AHTTP\/\S+\s+(\d{3})\b/i', $header, $matches)) {
                return (int) $matches[1];
            }
        }
        return 0;
    }
}
