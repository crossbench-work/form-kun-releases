<?php
namespace Core;

use Models\AppSetting;

class JapaneseHolidays
{
    public const API_URL = 'https://holidays-jp.github.io/api/v1/date.json';

    /**
     * @return array<string, string>
     */
    public static function fetchFromApi(): array
    {
        $raw = self::httpGet(self::API_URL);
        if ($raw === null) {
            throw new \RuntimeException('祝日 API への接続に失敗しました。');
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            throw new \RuntimeException('祝日 API の応答が不正です。');
        }

        $holidays = [];
        foreach ($decoded as $date => $name) {
            if (!is_string($date) || preg_match('/\A\d{4}-\d{2}-\d{2}\z/', $date) !== 1) {
                continue;
            }
            $holidays[$date] = trim((string) $name);
        }

        if ($holidays === []) {
            throw new \RuntimeException('祝日 API からデータを取得できませんでした。');
        }

        ksort($holidays);

        return $holidays;
    }

    /**
     * @param array<string, string> $holidays
     */
    public static function save(array $holidays): void
    {
        AppSetting::set(
            AppSetting::KEY_HOLIDAYS_JP_JSON,
            json_encode($holidays, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}'
        );
        AppSetting::set(AppSetting::KEY_HOLIDAYS_JP_FETCHED_AT, date('Y-m-d H:i:s'));
        AppSetting::set(AppSetting::KEY_HOLIDAYS_JP_LAST_ERROR, '');
    }

    public static function recordError(string $message): void
    {
        AppSetting::set(AppSetting::KEY_HOLIDAYS_JP_LAST_ERROR, trim($message));
    }

    /**
     * @return array<string, string>
     */
    public static function load(): array
    {
        $raw = AppSetting::get(AppSetting::KEY_HOLIDAYS_JP_JSON);
        if ($raw === null || trim($raw) === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            return [];
        }

        $holidays = [];
        foreach ($decoded as $date => $name) {
            if (!is_string($date) || preg_match('/\A\d{4}-\d{2}-\d{2}\z/', $date) !== 1) {
                continue;
            }
            $holidays[$date] = (string) $name;
        }

        return $holidays;
    }

    public static function fetchedAt(): ?string
    {
        $raw = AppSetting::get(AppSetting::KEY_HOLIDAYS_JP_FETCHED_AT);
        if ($raw === null || trim($raw) === '') {
            return null;
        }

        return trim($raw);
    }

    public static function lastError(): string
    {
        return trim((string) (AppSetting::get(AppSetting::KEY_HOLIDAYS_JP_LAST_ERROR) ?? ''));
    }

    public static function daysSinceFetch(): ?int
    {
        $fetchedAt = self::fetchedAt();
        if ($fetchedAt === null) {
            return null;
        }
        $dt = \DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $fetchedAt);
        if ($dt === false) {
            return null;
        }

        return (int) floor((time() - $dt->getTimestamp()) / 86400);
    }

    public static function isStale(): bool
    {
        if (self::load() === [] || self::fetchedAt() === null) {
            return true;
        }

        $days = self::daysSinceFetch();
        if ($days === null) {
            return true;
        }

        return $days >= effective_holidays_jp_fetch_interval_days();
    }

    public static function status(): string
    {
        $holidays = self::load();
        $error = self::lastError();

        if ($holidays === [] || self::fetchedAt() === null) {
            return $error !== '' ? 'error' : 'missing';
        }
        if (self::isStale()) {
            return 'stale';
        }
        if ($error !== '') {
            return 'error';
        }

        return 'ok';
    }

    public static function statusMessage(): string
    {
        $status = self::status();
        if ($status === 'error') {
            $error = self::lastError();
            return $error !== ''
                ? '祝日情報の取得に失敗しました: ' . $error
                : '祝日情報の取得に失敗しました。';
        }
        if ($status === 'missing') {
            return '祝日情報が未取得です。「祝日情報を取得する」で取得してください。';
        }
        if ($status === 'stale') {
            $days = self::daysSinceFetch() ?? effective_holidays_jp_fetch_interval_days();
            $interval = effective_holidays_jp_fetch_interval_days();

            return '祝日情報が ' . $interval . ' 日以上更新されていません（最終取得から ' . $days . ' 日経過）。取得ボタンで更新してください。';
        }

        return '';
    }

    public static function ensureFreshOnAdminBoot(): void
    {
        if (self::status() !== 'missing') {
            return;
        }

        try {
            self::save(self::fetchFromApi());
        } catch (\Throwable $e) {
            self::recordError($e->getMessage());
            error_log('[formkun] JapaneseHolidays auto fetch failed: ' . $e->getMessage());
        }
    }

    public static function fetchAndSave(): void
    {
        try {
            self::save(self::fetchFromApi());
        } catch (\Throwable $e) {
            self::recordError($e->getMessage());
            throw $e;
        }
    }

    private static function httpGet(string $url): ?string
    {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch !== false) {
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_TIMEOUT        => 15,
                    CURLOPT_HTTPHEADER     => [
                        'Accept: application/json',
                        'User-Agent: form-kun/1',
                    ],
                ]);
                $raw = curl_exec($ch);
                $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                curl_close($ch);
                if (is_string($raw) && $raw !== '' && ($code === 0 || ($code >= 200 && $code < 300))) {
                    return $raw;
                }
            }
        }

        $fopenEnabled = filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN);
        if (!$fopenEnabled) {
            return null;
        }

        $ctx = stream_context_create([
            'http' => [
                'timeout' => 15,
                'header'  => "Accept: application/json\r\nUser-Agent: form-kun/1\r\n",
            ],
            'ssl' => [
                'verify_peer'      => true,
                'verify_peer_name' => true,
            ],
        ]);
        $raw = @file_get_contents($url, false, $ctx);

        if ($raw !== false && $raw !== '') {
            return $raw;
        }

        return null;
    }
}
