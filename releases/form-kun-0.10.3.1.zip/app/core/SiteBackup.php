<?php
namespace Core;

/**
 * サイト全体のバックアップ（DB 全テーブル + uploads）を AES-256 暗号化 ZIP で入出力する。
 * 復元は追加ではなく置き換え。
 */
final class SiteBackup
{
    public const FORMAT = 'form-kun-site-backup';
    public const VERSION = 1;
    public const MANIFEST_NAME = 'formkun-backup.json';
    private const TABLES_DIR = 'tables/';
    private const UPLOADS_PREFIX = 'uploads/';
    private const MANIFEST_MAX_BYTES = 5 * 1024 * 1024;
    /** DB 置換後に uploads の配置だけ失敗したことを示す例外コード */
    public const ERROR_UPLOADS_AFTER_DB = 2;

    /** 一時データのため対象外にするテーブル */
    private const EXCLUDED_TABLES = [
        'password_reset_tokens',
        'login_attempts',
        'ip_country_cache',
        'public_api_rate_limits',
    ];

    /** uploads 直下で常に残す保護用ファイル */
    private const UPLOADS_KEEP = ['.htaccess', 'index.html'];

    public static function export(string $password): never
    {
        if (trim($password) === '') {
            throw new \InvalidArgumentException('バックアップのパスワードを入力してください。');
        }
        self::assertEncryptionSupported();

        $zipPath = tempnam(sys_get_temp_dir(), 'fk-backup-');
        if ($zipPath === false) {
            throw new \RuntimeException('バックアップを作成できませんでした。');
        }
        $tempFiles = [];

        try {
            $zip = new \ZipArchive();
            if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
                throw new \RuntimeException('ZIP を作成できません。');
            }

            $tableCounts = [];
            foreach (self::targetTables() as $table) {
                $tmp = tempnam(sys_get_temp_dir(), 'fk-backup-tbl-');
                if ($tmp === false) {
                    throw new \RuntimeException('バックアップを作成できませんでした。');
                }
                $tempFiles[] = $tmp;
                $tableCounts[$table] = self::dumpTable($table, $tmp);
                self::addEncryptedFile($zip, $tmp, self::TABLES_DIR . $table . '.json', $password);
            }

            $uploadCount = 0;
            $uploadBytes = 0;
            foreach (self::uploadFiles() as $rel => $abs) {
                self::addEncryptedFile($zip, $abs, self::UPLOADS_PREFIX . $rel, $password);
                $uploadCount++;
                $uploadBytes += (int) (filesize($abs) ?: 0);
            }

            $manifest = json_encode([
                'format' => self::FORMAT,
                'version' => self::VERSION,
                'app_version' => AppUpdater::currentVersion(),
                'created_at' => date(DATE_ATOM),
                'tables' => $tableCounts,
                'upload_count' => $uploadCount,
                'upload_bytes' => $uploadBytes,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
            if (!is_string($manifest)) {
                throw new \RuntimeException('バックアップ情報を生成できませんでした。');
            }
            $zip->addFromString(self::MANIFEST_NAME, $manifest);
            if (!$zip->setEncryptionName(self::MANIFEST_NAME, \ZipArchive::EM_AES_256, $password)) {
                throw new \RuntimeException('バックアップを暗号化できませんでした。');
            }

            if (!$zip->close()) {
                throw new \RuntimeException('ZIP の書き込みに失敗しました。');
            }

            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            $filename = 'form-kun-backup-' . date('Ymd-His') . '.zip';
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . (string) filesize($zipPath));
            header('X-Content-Type-Options: nosniff');
            readfile($zipPath);
        } finally {
            foreach ($tempFiles as $tmp) {
                @unlink($tmp);
            }
            @unlink($zipPath);
        }
        exit;
    }

    /**
     * @return array{tables: int, rows: int, uploads: int}
     */
    public static function restore(string $zipPath, string $password): array
    {
        if (trim($password) === '') {
            throw new \InvalidArgumentException('バックアップのパスワードを入力してください。');
        }
        if (!class_exists(\ZipArchive::class)) {
            throw new \RuntimeException('サーバーが ZIP に対応していません。');
        }

        $zip = new \ZipArchive();
        if ($zip->open($zipPath, \ZipArchive::RDONLY) !== true) {
            throw new \InvalidArgumentException('ZIP ファイルを開けません。');
        }

        $stagingNew = null;
        try {
            $manifest = self::readManifest($zip, $password);

            $currentTables = self::targetTables();
            $tableData = [];
            foreach (array_keys((array) ($manifest['tables'] ?? [])) as $table) {
                $table = (string) $table;
                if (!in_array($table, $currentTables, true)) {
                    continue;
                }
                $json = $zip->getFromName(self::TABLES_DIR . $table . '.json');
                $data = is_string($json) ? json_decode($json, true) : null;
                if (!is_array($data) || !is_array($data['rows'] ?? null)) {
                    throw new \InvalidArgumentException('バックアップのテーブルデータ（' . $table . '）が壊れています。');
                }
                $tableData[$table] = $data;
            }

            $stagingNew = self::makeStagingDir('new');
            $uploadCount = self::extractUploads($zip, $password, $stagingNew);
        } catch (\Throwable $e) {
            if ($stagingNew !== null) {
                self::removeTree($stagingNew);
            }
            throw $e;
        } finally {
            $zip->close();
        }

        try {
            self::assertUploadsSwappable();
            $rows = self::replaceDatabase($currentTables, $tableData);
        } catch (\Throwable $e) {
            self::removeTree($stagingNew);
            throw $e;
        }

        self::swapUploads($stagingNew);

        return ['tables' => count($tableData), 'rows' => $rows, 'uploads' => $uploadCount];
    }

    private static function assertEncryptionSupported(): void
    {
        if (!class_exists(\ZipArchive::class)
            || !defined('ZipArchive::EM_AES_256')
            || !method_exists(\ZipArchive::class, 'setEncryptionName')) {
            throw new \RuntimeException('このサーバーは暗号化 ZIP に対応していません。');
        }
    }

    private static function addEncryptedFile(\ZipArchive $zip, string $abs, string $name, string $password): void
    {
        if (!$zip->addFile($abs, $name) || !$zip->setEncryptionName($name, \ZipArchive::EM_AES_256, $password)) {
            throw new \RuntimeException('バックアップにファイルを追加できませんでした: ' . $name);
        }
    }

    /** @return list<string> */
    private static function targetTables(): array
    {
        $rows = Database::fetchAll(
            "SELECT TABLE_NAME AS t FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE'
             ORDER BY TABLE_NAME"
        );
        $tables = [];
        foreach ($rows as $row) {
            $name = (string) ($row['t'] ?? '');
            if ($name !== '' && !in_array($name, self::EXCLUDED_TABLES, true) && preg_match('/\A\w+\z/', $name) === 1) {
                $tables[] = $name;
            }
        }

        return $tables;
    }

    /** @return array<string, string> 列名 => DATA_TYPE */
    private static function columnTypes(string $table): array
    {
        $rows = Database::fetchAll(
            'SELECT COLUMN_NAME AS c, DATA_TYPE AS d FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION',
            [$table]
        );
        $out = [];
        foreach ($rows as $row) {
            $out[(string) $row['c']] = strtolower((string) $row['d']);
        }

        return $out;
    }

    private static function isBinaryType(string $type): bool
    {
        return in_array($type, ['binary', 'varbinary', 'tinyblob', 'blob', 'mediumblob', 'longblob'], true);
    }

    /**
     * テーブルを {"binary_columns": [...], "rows": [...]} 形式で一時ファイルに書き出し、行数を返す。
     */
    private static function dumpTable(string $table, string $path): int
    {
        $binaryColumns = [];
        foreach (self::columnTypes($table) as $column => $type) {
            if (self::isBinaryType($type)) {
                $binaryColumns[] = $column;
            }
        }

        $out = fopen($path, 'wb');
        if ($out === false) {
            throw new \RuntimeException('バックアップを作成できませんでした。');
        }

        $pdo = Database::pdo();
        $buffered = $pdo->getAttribute(\PDO::MYSQL_ATTR_USE_BUFFERED_QUERY);
        $pdo->setAttribute(\PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
        $count = 0;
        try {
            fwrite($out, '{"binary_columns":' . json_encode($binaryColumns) . ',"rows":[');
            $stmt = $pdo->query('SELECT * FROM `' . $table . '`');
            while (($row = $stmt->fetch(\PDO::FETCH_ASSOC)) !== false) {
                foreach ($binaryColumns as $column) {
                    if (isset($row[$column])) {
                        $row[$column] = base64_encode((string) $row[$column]);
                    }
                }
                $json = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
                if (!is_string($json)) {
                    throw new \RuntimeException('テーブル ' . $table . ' を書き出せませんでした。');
                }
                fwrite($out, ($count > 0 ? ',' : '') . $json);
                $count++;
            }
            $stmt->closeCursor();
            fwrite($out, ']}');
        } finally {
            $pdo->setAttribute(\PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, $buffered);
            fclose($out);
        }

        return $count;
    }

    /** @return array<string, string> uploads 相対パス => 絶対パス */
    private static function uploadFiles(): array
    {
        $root = UPLOADS_DIR;
        if (!is_dir($root)) {
            return [];
        }
        $files = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($root, \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if (!$file->isFile()) {
                continue;
            }
            $rel = str_replace(DIRECTORY_SEPARATOR, '/', substr($file->getPathname(), strlen($root) + 1));
            if (in_array($rel, self::UPLOADS_KEEP, true) || self::hasDotSegment($rel)) {
                continue;
            }
            $files[$rel] = $file->getPathname();
        }

        return $files;
    }

    private static function hasDotSegment(string $rel): bool
    {
        foreach (explode('/', $rel) as $segment) {
            if ($segment === '' || $segment[0] === '.') {
                return true;
            }
        }

        return false;
    }

    /** @return array<string, mixed> */
    private static function readManifest(\ZipArchive $zip, string $password): array
    {
        $stat = $zip->statName(self::MANIFEST_NAME);
        if ($stat === false) {
            throw new \InvalidArgumentException('バックアップファイルではありません（' . self::MANIFEST_NAME . ' がありません）。');
        }
        if ((int) ($stat['encryption_method'] ?? 0) === \ZipArchive::EM_NONE) {
            throw new \InvalidArgumentException('パスワードで保護されていない ZIP は復元できません。');
        }
        if ((int) $stat['size'] > self::MANIFEST_MAX_BYTES) {
            throw new \InvalidArgumentException('バックアップ情報が大きすぎます。');
        }

        $zip->setPassword($password);
        $json = $zip->getFromName(self::MANIFEST_NAME);
        $manifest = is_string($json) ? json_decode($json, true) : null;
        if (!is_array($manifest)) {
            throw new \InvalidArgumentException('パスワードが正しくないか、バックアップファイルが壊れています。');
        }
        if (($manifest['format'] ?? null) !== self::FORMAT || (int) ($manifest['version'] ?? 0) !== self::VERSION) {
            throw new \InvalidArgumentException('対応していないバックアップ形式です。');
        }
        $backupVersion = (string) ($manifest['app_version'] ?? '');
        if ($backupVersion !== '' && version_compare($backupVersion, AppUpdater::currentVersion(), '>')) {
            throw new \InvalidArgumentException(
                'このバックアップは新しいバージョン（' . $backupVersion . '）で作成されています。先にアプリを更新してください。'
            );
        }
        $uploadBytes = (int) ($manifest['upload_bytes'] ?? 0);
        $max = (int) (SiteResource::snapshot()['max'] ?? 0);
        if ($max > 0 && $uploadBytes > $max) {
            throw new \InvalidArgumentException('バックアップの添付ファイルがサイトの利用容量の上限を超えています。');
        }

        return $manifest;
    }

    private static function makeStagingDir(string $kind): string
    {
        $dir = UPLOADS_DIR . DIRECTORY_SEPARATOR . '.restore-' . $kind . '-' . bin2hex(random_bytes(6));
        if (!@mkdir($dir, 0775, true) && !is_dir($dir)) {
            throw new \RuntimeException('復元用の作業ディレクトリを作成できません。');
        }

        return $dir;
    }

    private static function extractUploads(\ZipArchive $zip, string $password, string $dest): int
    {
        $count = 0;
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = (string) $zip->getNameIndex($i);
            if (!str_starts_with($name, self::UPLOADS_PREFIX) || str_ends_with($name, '/')) {
                continue;
            }
            $rel = substr($name, strlen(self::UPLOADS_PREFIX));
            if ($rel === '' || strlen($rel) > 512 || str_contains($rel, '\\') || str_contains($rel, "\0")
                || self::hasDotSegment($rel) || in_array($rel, self::UPLOADS_KEEP, true)) {
                throw new \InvalidArgumentException('バックアップ内のファイルパスが正しくありません: ' . $name);
            }

            $target = $dest . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
            $dir = dirname($target);
            if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
                throw new \RuntimeException('復元用のディレクトリを作成できません。');
            }
            $zip->setPassword($password);
            $stream = $zip->getStream($name);
            if ($stream === false) {
                throw new \InvalidArgumentException('バックアップ内のファイルを読めません: ' . $name);
            }
            $out = fopen($target, 'wb');
            if ($out === false) {
                fclose($stream);
                throw new \RuntimeException('復元用のファイルを書き込めません。');
            }
            $copied = stream_copy_to_stream($stream, $out);
            fclose($stream);
            fclose($out);
            if ($copied === false) {
                throw new \RuntimeException('復元用のファイルを書き込めません。');
            }
            $count++;
        }

        return $count;
    }

    /**
     * 対象テーブルを空にしてバックアップの行を入れる。現在のテーブルに存在する列だけを使う。
     *
     * @param list<string> $currentTables
     * @param array<string, array<string, mixed>> $tableData
     */
    private static function replaceDatabase(array $currentTables, array $tableData): int
    {
        $pdo = Database::pdo();
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
        $inserted = 0;
        try {
            $pdo->beginTransaction();
            try {
                foreach ($currentTables as $table) {
                    $pdo->exec('DELETE FROM `' . $table . '`');
                }
                foreach ($tableData as $table => $data) {
                    $types = self::columnTypes($table);
                    $binaryColumns = array_map('strval', (array) ($data['binary_columns'] ?? []));
                    $statements = [];
                    foreach ($data['rows'] as $row) {
                        if (!is_array($row)) {
                            continue;
                        }
                        $columns = array_values(array_filter(
                            array_keys($row),
                            static fn($c): bool => isset($types[(string) $c])
                        ));
                        if ($columns === []) {
                            continue;
                        }
                        $key = implode(',', $columns);
                        if (!isset($statements[$key])) {
                            $statements[$key] = $pdo->prepare(
                                'INSERT INTO `' . $table . '` (`' . implode('`,`', $columns) . '`) VALUES ('
                                . implode(',', array_fill(0, count($columns), '?')) . ')'
                            );
                        }
                        $stmt = $statements[$key];
                        foreach ($columns as $i => $column) {
                            $value = $row[$column];
                            if ($value !== null && in_array($column, $binaryColumns, true)) {
                                $decoded = base64_decode((string) $value, true);
                                $stmt->bindValue($i + 1, $decoded === false ? '' : $decoded, \PDO::PARAM_LOB);
                            } elseif ($value === null) {
                                $stmt->bindValue($i + 1, null, \PDO::PARAM_NULL);
                            } else {
                                $stmt->bindValue($i + 1, is_bool($value) ? (int) $value : (string) $value);
                            }
                        }
                        $stmt->execute();
                        $inserted++;
                    }
                }
                $pdo->commit();
            } catch (\Throwable $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                throw $e;
            }
        } finally {
            $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
        }

        return $inserted;
    }

    /**
     * DB を置き換える前に、swapUploads が既存エントリを退避できる権限があるか確かめる。
     * ディレクトリを別の親へ rename するには、そのディレクトリ自身への書き込み権限も要る。
     */
    private static function assertUploadsSwappable(): void
    {
        $root = UPLOADS_DIR;
        $ok = is_dir($root) && is_writable($root);
        if ($ok) {
            foreach (scandir($root) ?: [] as $entry) {
                if ($entry === '.' || $entry === '..' || $entry[0] === '.' || in_array($entry, self::UPLOADS_KEEP, true)) {
                    continue;
                }
                $path = $root . DIRECTORY_SEPARATOR . $entry;
                if (is_dir($path) && !is_writable($path)) {
                    error_log('[formkun] site backup aborted: uploads entry not writable: ' . $entry);
                    $ok = false;
                    break;
                }
            }
        }
        if (!$ok) {
            throw new \RuntimeException('添付ファイル保存先の権限が不足しているため復元を中止しました（データベースは変更していません）。サーバーの uploads ディレクトリの権限を確認してください。');
        }
    }

    /**
     * uploads の中身を展開済みディレクトリの中身と入れ替える（uploads 自体はマウントの可能性があるため消さない）。
     */
    private static function swapUploads(string $stagingNew): void
    {
        $root = UPLOADS_DIR;
        $stagingOld = self::makeStagingDir('old');
        $movedOld = [];
        $movedNew = [];
        try {
            foreach (scandir($root) ?: [] as $entry) {
                if ($entry === '.' || $entry === '..' || $entry[0] === '.' || in_array($entry, self::UPLOADS_KEEP, true)) {
                    continue;
                }
                if (!@rename($root . DIRECTORY_SEPARATOR . $entry, $stagingOld . DIRECTORY_SEPARATOR . $entry)) {
                    throw new \RuntimeException('既存の添付ファイルを退避できませんでした。');
                }
                $movedOld[] = $entry;
            }
            foreach (scandir($stagingNew) ?: [] as $entry) {
                if ($entry === '.' || $entry === '..') {
                    continue;
                }
                if (!@rename($stagingNew . DIRECTORY_SEPARATOR . $entry, $root . DIRECTORY_SEPARATOR . $entry)) {
                    throw new \RuntimeException('添付ファイルを配置できませんでした。');
                }
                $movedNew[] = $entry;
            }
        } catch (\Throwable $e) {
            foreach ($movedNew as $entry) {
                @rename($root . DIRECTORY_SEPARATOR . $entry, $stagingNew . DIRECTORY_SEPARATOR . $entry);
            }
            foreach ($movedOld as $entry) {
                @rename($stagingOld . DIRECTORY_SEPARATOR . $entry, $root . DIRECTORY_SEPARATOR . $entry);
            }
            self::removeTree($stagingNew);
            self::removeTree($stagingOld);
            error_log('[formkun] site backup uploads swap failed: ' . $e->getMessage());
            throw new \RuntimeException(
                'データベースは復元しましたが、添付ファイルを配置できませんでした。サーバーの uploads ディレクトリの権限を確認してください。',
                self::ERROR_UPLOADS_AFTER_DB
            );
        }

        self::removeTree($stagingNew);
        self::removeTree($stagingOld);
    }

    private static function removeTree(?string $dir): void
    {
        if ($dir === null || !is_dir($dir)) {
            return;
        }
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($iterator as $file) {
            $file->isDir() ? @rmdir($file->getPathname()) : @unlink($file->getPathname());
        }
        @rmdir($dir);
    }
}
