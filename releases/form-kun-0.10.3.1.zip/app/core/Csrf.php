<?php
namespace Core;

class Csrf
{
    private const SESSION_KEY = '_csrf_token';

    public static function token(): string
    {
        if (empty($_SESSION[self::SESSION_KEY])) {
            $_SESSION[self::SESSION_KEY] = bin2hex(random_bytes(32));
        }
        return $_SESSION[self::SESSION_KEY];
    }

    public static function field(): string
    {
        return '<input type="hidden" name="_token" value="' . e(self::token()) . '">';
    }

    public static function check(?string $token): bool
    {
        $expected = $_SESSION[self::SESSION_KEY] ?? null;
        if (!$expected || !is_string($token) || $token === '') {
            return false;
        }
        return hash_equals($expected, $token);
    }

    /**
     * POST 用の検証。失敗時は 419 で終了。
     */
    public static function verify(): void
    {
        $token = $_POST['_token'] ?? null;
        if (!self::check($token)) {
            http_response_code(419);
            echo '<!doctype html><meta charset="utf-8"><title>419</title>';
            echo '<h1>セッションが切れています</h1>';
            echo '<p>ページを再読み込みしてからもう一度お試しください。</p>';
            exit;
        }
    }

    public static function rotate(): void
    {
        $_SESSION[self::SESSION_KEY] = bin2hex(random_bytes(32));
    }

    /**
     * POST フォーム・JSON ボディ・X-CSRF-Token ヘッダのいずれかで検証する。
     */
    public static function verifyRequest(): void
    {
        if (self::tokenIsValid(self::resolveSubmittedToken())) {
            return;
        }
        http_response_code(419);
        if (self::wantsJsonResponse()) {
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode(['error' => 'セッションが切れています。ページを再読み込みしてください。'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        echo '<!doctype html><meta charset="utf-8"><title>419</title>';
        echo '<h1>セッションが切れています</h1>';
        echo '<p>ページを再読み込みしてからもう一度お試しください。</p>';
        exit;
    }

    private static function resolveSubmittedToken(): ?string
    {
        $candidates = [
            $_POST['_token'] ?? null,
            $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null,
        ];
        $json = json_request_body();
        if (is_array($json) && array_key_exists('_token', $json)) {
            $candidates[] = $json['_token'];
        }
        foreach ($candidates as $token) {
            if (is_string($token) && $token !== '') {
                return $token;
            }
        }

        return null;
    }

    private static function tokenIsValid(?string $token): bool
    {
        return is_string($token) && $token !== '' && self::check($token);
    }

    public static function wantsJsonResponse(): bool
    {
        $accept = (string) ($_SERVER['HTTP_ACCEPT'] ?? '');
        if (str_contains($accept, 'application/json')) {
            return true;
        }
        $requestedWith = (string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '');

        return strcasecmp($requestedWith, 'XMLHttpRequest') === 0;
    }
}
