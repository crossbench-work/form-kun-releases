<?php
namespace Core;

/**
 * LINE Messaging API（Push message）の薄いクライアント。
 */
class LineMessagingClient
{
    private const PUSH_URL = 'https://api.line.me/v2/bot/message/push';
    private const MAX_MESSAGES_PER_PUSH = 5;

    public static function pushText(string $channelAccessToken, string $to, string $text): bool
    {
        return self::pushMessages($channelAccessToken, $to, [
            ['type' => 'text', 'text' => $text],
        ]);
    }

    /**
     * @param list<array<string, mixed>> $messages text / image（1〜5 件）
     */
    public static function pushMessages(string $channelAccessToken, string $to, array $messages): bool
    {
        $token = trim($channelAccessToken);
        $to = trim($to);
        if ($token === '' || $to === '' || $messages === []) {
            return false;
        }

        $normalized = [];
        foreach ($messages as $message) {
            if (!is_array($message)) {
                continue;
            }
            $type = (string) ($message['type'] ?? '');
            if ($type === 'text') {
                $text = (string) ($message['text'] ?? '');
                if ($text === '') {
                    continue;
                }
                $normalized[] = ['type' => 'text', 'text' => $text];
            } elseif ($type === 'image') {
                $original = trim((string) ($message['originalContentUrl'] ?? ''));
                $preview = trim((string) ($message['previewImageUrl'] ?? ''));
                if ($original === '' || $preview === '') {
                    continue;
                }
                $normalized[] = [
                    'type' => 'image',
                    'originalContentUrl' => $original,
                    'previewImageUrl' => $preview,
                ];
            }
        }
        if ($normalized === []) {
            return false;
        }

        $chunks = array_chunk($normalized, self::MAX_MESSAGES_PER_PUSH);
        foreach ($chunks as $chunk) {
            if (!self::pushMessagesChunk($token, $to, $chunk)) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param list<array<string, mixed>> $messages
     */
    private static function pushMessagesChunk(string $token, string $to, array $messages): bool
    {
        $payload = json_encode([
            'to' => $to,
            'messages' => $messages,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($payload)) {
            return false;
        }

        $raw = self::httpPostJson(self::PUSH_URL, $payload, $token);
        if ($raw === null) {
            return false;
        }

        $decoded = json_decode($raw, true);
        if (is_array($decoded) && isset($decoded['message']) && is_string($decoded['message'])) {
            return false;
        }

        return true;
    }

    private static function httpPostJson(string $url, string $jsonBody, string $bearerToken): ?string
    {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch !== false) {
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $jsonBody,
                    CURLOPT_TIMEOUT        => 15,
                    CURLOPT_HTTPHEADER     => [
                        'Content-Type: application/json',
                        'Authorization: Bearer ' . $bearerToken,
                        'User-Agent: form-kun/1',
                    ],
                ]);
                $raw = curl_exec($ch);
                $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                curl_close($ch);
                if (is_string($raw) && $code >= 200 && $code < 300) {
                    return $raw;
                }
                return null;
            }
        }

        return null;
    }
}
