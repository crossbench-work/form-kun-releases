<?php
namespace Core;

use Core\Validator;
use Models\FormEmbedSetting;
use Models\FormField;
use Models\FormInputPage;

class EmbedCodeSample
{
    public static function generateCss(): string
    {
        return <<<'CSS'
.embed-form {
  max-width: 640px;
  margin: 0 auto;
  font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", "Noto Sans JP", sans-serif;
  line-height: 1.6;
  color: #1d2430;
}
.embed-form .field {
  margin-bottom: 16px;
}
.embed-form label {
  display: block;
  font-weight: 600;
  font-size: 14px;
  margin-bottom: 4px;
}
.embed-form .req {
  color: #c0392b;
  font-weight: 400;
  font-size: 12px;
  margin-left: 4px;
}
.embed-form input[type="text"],
.embed-form input[type="email"],
.embed-form input[type="tel"],
.embed-form input[type="url"],
.embed-form input[type="number"],
.embed-form input[type="date"],
.embed-form input[type="time"],
.embed-form textarea,
.embed-form select {
  width: 100%;
  padding: 8px 10px;
  border: 1px solid #d9dde3;
  border-radius: 6px;
  font: inherit;
  font-size: 14px;
  box-sizing: border-box;
}
.embed-form textarea {
  min-height: 100px;
  resize: vertical;
}
.embed-form .choices {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 16px;
}
.embed-form .choices label {
  font-weight: 400;
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0;
}
.embed-form button[type="submit"] {
  font: inherit;
  font-size: 14px;
  padding: 9px 18px;
  border-radius: 6px;
  border: 1px solid #2f6fd0;
  background: #2f6fd0;
  color: #fff;
  cursor: pointer;
}
CSS;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $fieldGroups
     * @param array<int, array<string, mixed>> $inputPages
     * @param array<string, string> $captchaContext turnstile_site_key, recaptcha_site_key
     */
    public static function generateFormHtml(
        array $fields,
        array $fieldGroups,
        array $inputPages,
        string $captchaProvider,
        array $captchaContext = []
    ): string {
        $ordered = FormField::orderedSubmittable($fields, $fieldGroups, $inputPages, true);
        if ($ordered === []) {
            return '';
        }

        $pageTitles = self::pageTitleMap($inputPages, $fields, $fieldGroups);
        $multiPage = count($pageTitles) > 1;

        $lines = [
            '<form id="contact-form" class="embed-form" method="post" action="#" novalidate>',
        ];

        $lastPageKey = null;
        foreach ($ordered as $field) {
            $pageKey = FormField::sanitizeInputPageKey((string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($multiPage && $pageKey !== $lastPageKey) {
                $title = $pageTitles[$pageKey] ?? $pageKey;
                $lines[] = '';
                $lines[] = '<!-- 入力画面: ' . self::escapeHtml($title) . ' -->';
                $lastPageKey = $pageKey;
            }
            foreach (self::fieldLines($field) as $line) {
                $lines[] = $line;
            }
        }

        $captchaBlock = self::captchaBlock($captchaProvider, $captchaContext);
        if ($captchaBlock !== '') {
            $lines[] = '';
            $lines[] = $captchaBlock;
        }

        $lines[] = '';
        $lines[] = '  <button type="submit">送信</button>';
        $lines[] = '</form>';

        return implode("\n", $lines);
    }

    /** @param array<int, array<string, mixed>> $inputPages @return array<string, string> */
    private static function pageTitleMap(array $inputPages, array $fields, array $fieldGroups): array
    {
        $titles = [];
        foreach ($inputPages as $index => $page) {
            $pageKey = FormInputPage::sanitizePageKey((string) ($page['page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($pageKey === '') {
                continue;
            }
            $title = trim((string) ($page['title'] ?? ''));
            $titles[$pageKey] = $title !== '' ? $title : '入力画面 ' . ((int) $index + 1);
        }
        foreach ($fields as $field) {
            $pageKey = FormField::sanitizeInputPageKey((string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($pageKey !== '' && !isset($titles[$pageKey])) {
                $titles[$pageKey] = $pageKey;
            }
        }
        foreach ($fieldGroups as $group) {
            $pageKey = FormField::sanitizeInputPageKey((string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($pageKey !== '' && !isset($titles[$pageKey])) {
                $titles[$pageKey] = $pageKey;
            }
        }
        return $titles;
    }

    /** @param array<string, string> $captchaContext */
    private static function captchaBlock(string $captchaProvider, array $captchaContext): string
    {
        if ($captchaProvider === FormEmbedSetting::CAPTCHA_TURNSTILE) {
            $siteKey = trim((string) ($captchaContext['turnstile_site_key'] ?? 'YOUR_TURNSTILE_SITE_KEY'));
            if ($siteKey === '') {
                $siteKey = 'YOUR_TURNSTILE_SITE_KEY';
            }
            return '  <div class="cf-turnstile" data-sitekey="' . self::escapeHtml($siteKey) . '"></div>';
        }
        if ($captchaProvider === FormEmbedSetting::CAPTCHA_RECAPTCHA_V2) {
            $siteKey = trim((string) ($captchaContext['recaptcha_site_key'] ?? 'YOUR_RECAPTCHA_SITE_KEY'));
            if ($siteKey === '') {
                $siteKey = 'YOUR_RECAPTCHA_SITE_KEY';
            }
            return '  <div class="g-recaptcha" data-sitekey="' . self::escapeHtml($siteKey) . '"></div>';
        }
        return '';
    }

    /** @param array<string, mixed> $field @return list<string> */
    private static function fieldLines(array $field): array
    {
        $key = trim((string) ($field['field_key'] ?? ''));
        if ($key === '') {
            return [];
        }
        $type = FormField::normalizeType((string) ($field['type'] ?? 'text'));
        $label = trim((string) ($field['label'] ?? $key));
        $req = !empty($field['required']);
        $reqMark = $req ? ' <span class="req">(必須)</span>' : '';
        $ph = self::escapeHtml(trim((string) ($field['placeholder'] ?? '')));
        $reqAttr = $req ? ' required' : '';

        $open = '  <div class="field">';
        $labelLine = '    <label for="f_' . self::escapeHtml($key) . '">' . self::escapeHtml($label) . $reqMark . '</label>';

        $simpleInputTypes = ['text', 'email', 'tel', 'url', 'number', 'time'];
        if (in_array($type, $simpleInputTypes, true)) {
            $inputType = $type === 'url' ? 'url' : $type;
            return [
                $open,
                $labelLine,
                '    <input type="' . self::escapeHtml($inputType) . '" id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '"' . ($ph !== '' ? ' placeholder="' . $ph . '"' : '') . $reqAttr . '>',
                '  </div>',
            ];
        }

        if ($type === 'date') {
            return [
                $open,
                $labelLine,
                '    <input type="date" id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '"' . $reqAttr . '>',
                '  </div>',
            ];
        }

        if ($type === 'textarea') {
            return [
                $open,
                $labelLine,
                '    <textarea id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '" rows="6"' . ($ph !== '' ? ' placeholder="' . $ph . '"' : '') . $reqAttr . '></textarea>',
                '  </div>',
            ];
        }

        if ($type === 'select') {
            $opts = Validator::decodeOptions($field['options_json'] ?? null);
            $lines = [$open, $labelLine, '    <select id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '"' . $reqAttr . '>'];
            $lines[] = '      <option value="">選択してください</option>';
            foreach ($opts as $opt) {
                $opt = (string) $opt;
                $lines[] = '      <option value="' . self::escapeHtml($opt) . '">' . self::escapeHtml($opt) . '</option>';
            }
            $lines[] = '    </select>';
            $lines[] = '  </div>';
            return $lines;
        }

        if ($type === 'radio') {
            $settings = FormField::decodeChoiceSettings($field['options_json'] ?? null);
            $opts = is_array($settings['options'] ?? null) ? $settings['options'] : [];
            $lines = [$open, '    <span class="label">' . self::escapeHtml($label) . $reqMark . '</span>', '    <div class="choices">'];
            foreach ($opts as $opt) {
                $opt = (string) $opt;
                $lines[] = '      <label><input type="radio" name="' . self::escapeHtml($key) . '" value="' . self::escapeHtml($opt) . '"> ' . self::escapeHtml($opt) . '</label>';
            }
            $lines[] = '    </div>';
            $lines[] = '  </div>';
            return $lines;
        }

        if ($type === 'checkbox') {
            $settings = FormField::decodeCheckboxSettings($field['options_json'] ?? null);
            $opts = is_array($settings['options'] ?? null) ? $settings['options'] : [];
            $lines = [$open, '    <span class="label">' . self::escapeHtml($label) . $reqMark . '</span>', '    <div class="choices">'];
            foreach ($opts as $opt) {
                $opt = (string) $opt;
                $lines[] = '      <label><input type="checkbox" name="' . self::escapeHtml($key) . '[]" value="' . self::escapeHtml($opt) . '"> ' . self::escapeHtml($opt) . '</label>';
            }
            $lines[] = '    </div>';
            $lines[] = '  </div>';
            return $lines;
        }

        if ($type === 'text_multi') {
            $items = FormField::decodeTextMultiItems($field['options_json'] ?? null, true);
            $count = max(1, count($items));
            $lines = [$open, $labelLine];
            for ($i = 0; $i < $count; $i++) {
                $lines[] = '    <input type="text" id="f_' . self::escapeHtml($key) . '_' . $i . '" name="' . self::escapeHtml($key) . '[items][]"' . $reqAttr . '>';
            }
            $lines[] = '  </div>';
            return $lines;
        }

        if ($type === 'file') {
            $fileSettings = FormField::decodeFileSettings($field['options_json'] ?? null);
            $exts = is_array($fileSettings['allowed_extensions'] ?? null) ? $fileSettings['allowed_extensions'] : [];
            $accept = $exts !== [] ? ' accept="' . self::escapeHtml('.' . implode(',.', array_map('strval', $exts))) . '"' : '';
            return [
                $open,
                $labelLine,
                '    <input type="file" id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '"' . $accept . $reqAttr . '>',
                '  </div>',
            ];
        }

        if (in_array($type, ['address', 'text_pair', FormField::TYPE_POSTAL_CODE, FormField::TYPE_MATRIX], true)) {
            $typeLabel = $type;
            return [
                $open,
                '    <!-- タイプ ' . self::escapeHtml($typeLabel) . ': 公開フォームのマークアップを参照 -->',
                $labelLine,
                '    <input type="text" id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '" placeholder="（サンプル）"' . $reqAttr . '>',
                '  </div>',
            ];
        }

        return [
            $open,
            $labelLine,
            '    <input type="text" id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '"' . $reqAttr . '>',
            '  </div>',
        ];
    }

    private static function escapeHtml(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
