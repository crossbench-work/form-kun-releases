<?php
namespace Core;

class LineWebhookSignature
{
    public static function isValid(string $channelSecret, string $rawBody, string $signatureHeader): bool
    {
        $secret = trim($channelSecret);
        $signatureHeader = trim($signatureHeader);
        if ($secret === '' || $signatureHeader === '') {
            return false;
        }
        $expected = base64_encode(hash_hmac('sha256', $rawBody, $secret, true));

        return hash_equals($expected, $signatureHeader);
    }
}
