<?php
namespace Core;

use Models\FormEmbedSetting;

/**
 * フォームバンドル ZIP 内の暗号化秘密情報（SMTP パスワード・CAPTCHA シークレット）。
 */
final class FormBundleSecretVault
{
    public const FORMAT = 'form-kun-form-secrets';
    public const VERSION = 1;
    public const FILE_NAME = 'formkun-secrets.enc.json';

    /**
     * @return array<string, mixed>
     */
    public static function collectPayload(int $formId, FormBundleExportOptions $options): array
    {
        $payload = [
            'mail_smtp_password' => null,
            'embed' => [
                'turnstile_secret_key' => null,
                'recaptcha_secret_key' => null,
                'recaptcha_v3_secret_key' => null,
            ],
        ];

        if ($options->includeSmtp) {
            $row = Database::fetchOne('SELECT mail_smtp_password FROM forms WHERE id = ?', [$formId]);
            $password = trim((string) ($row['mail_smtp_password'] ?? ''));
            if ($password !== '') {
                $payload['mail_smtp_password'] = $password;
            }
        }

        if ($options->includeEmbed) {
            $embed = FormEmbedSetting::forForm($formId, true);
            foreach (['turnstile_secret_key', 'recaptcha_secret_key', 'recaptcha_v3_secret_key'] as $key) {
                $value = trim((string) ($embed[$key] ?? ''));
                if ($value !== '') {
                    $payload['embed'][$key] = $value;
                }
            }
        }

        return $payload;
    }

    /**
     * @param array<string, mixed> $payload
     */
    public static function encryptPayload(array $payload, string $password): string
    {
        $plaintext = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($plaintext)) {
            throw new \RuntimeException('秘密情報を JSON にできませんでした。');
        }

        if (function_exists('sodium_crypto_secretbox')) {
            $salt = random_bytes(SODIUM_CRYPTO_PWHASH_SALTBYTES);
            $key = sodium_crypto_pwhash(
                SODIUM_CRYPTO_SECRETBOX_KEYBYTES,
                $password,
                $salt,
                SODIUM_CRYPTO_PWHASH_OPSLIMIT_INTERACTIVE,
                SODIUM_CRYPTO_PWHASH_MEMLIMIT_INTERACTIVE,
                SODIUM_CRYPTO_PWHASH_ALG_ARGON2ID13
            );
            $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
            $ciphertext = sodium_crypto_secretbox($plaintext, $nonce, $key);
            sodium_memzero($key);

            $envelope = [
                'format' => self::FORMAT,
                'version' => self::VERSION,
                'kdf' => 'argon2id',
                'salt' => base64_encode($salt),
                'nonce' => base64_encode($nonce),
                'ciphertext' => base64_encode($ciphertext),
            ];
        } else {
            $salt = random_bytes(16);
            $key = hash_pbkdf2('sha256', $password, $salt, 120000, 32, true);
            $iv = random_bytes(12);
            $tag = '';
            $ciphertext = openssl_encrypt($plaintext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag);
            if (!is_string($ciphertext)) {
                throw new \RuntimeException('秘密情報を暗号化できませんでした。');
            }

            $envelope = [
                'format' => self::FORMAT,
                'version' => self::VERSION,
                'kdf' => 'pbkdf2-sha256',
                'salt' => base64_encode($salt),
                'nonce' => base64_encode($iv),
                'tag' => base64_encode($tag),
                'ciphertext' => base64_encode($ciphertext),
            ];
        }

        $json = json_encode($envelope, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        if (!is_string($json)) {
            throw new \RuntimeException('暗号化データを JSON にできませんでした。');
        }

        return $json;
    }

    /**
     * @return array<string, mixed>
     */
    public static function decryptEnvelope(string $json, string $password): array
    {
        $envelope = json_decode($json, true);
        if (!is_array($envelope) || ($envelope['format'] ?? '') !== self::FORMAT || (int) ($envelope['version'] ?? 0) !== self::VERSION) {
            throw new \InvalidArgumentException('暗号化秘密情報の形式が正しくありません。');
        }

        $salt = base64_decode((string) ($envelope['salt'] ?? ''), true);
        $nonce = base64_decode((string) ($envelope['nonce'] ?? ''), true);
        $ciphertext = base64_decode((string) ($envelope['ciphertext'] ?? ''), true);
        if ($salt === false || $nonce === false || $ciphertext === false) {
            throw new \InvalidArgumentException('暗号化秘密情報が壊れています。');
        }

        $kdf = (string) ($envelope['kdf'] ?? '');
        if ($kdf === 'argon2id' && function_exists('sodium_crypto_secretbox_open')) {
            $key = sodium_crypto_pwhash(
                SODIUM_CRYPTO_SECRETBOX_KEYBYTES,
                $password,
                $salt,
                SODIUM_CRYPTO_PWHASH_OPSLIMIT_INTERACTIVE,
                SODIUM_CRYPTO_PWHASH_MEMLIMIT_INTERACTIVE,
                SODIUM_CRYPTO_PWHASH_ALG_ARGON2ID13
            );
            $plaintext = sodium_crypto_secretbox_open($ciphertext, $nonce, $key);
            sodium_memzero($key);
        } elseif ($kdf === 'pbkdf2-sha256') {
            $tag = base64_decode((string) ($envelope['tag'] ?? ''), true);
            if ($tag === false) {
                throw new \InvalidArgumentException('暗号化秘密情報が壊れています。');
            }
            $key = hash_pbkdf2('sha256', $password, $salt, 120000, 32, true);
            $plaintext = openssl_decrypt($ciphertext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $nonce, $tag);
        } else {
            throw new \InvalidArgumentException('対応していない暗号化方式です。');
        }

        if (!is_string($plaintext)) {
            throw new \InvalidArgumentException('パスワードが正しくないか、ファイルが壊れています。');
        }

        $payload = json_decode($plaintext, true);
        if (!is_array($payload)) {
            throw new \InvalidArgumentException('復号した秘密情報の形式が正しくありません。');
        }

        return $payload;
    }

    /**
     * @param array<string, mixed> $payload
     */
    public static function applyToForm(int $formId, array $payload): void
    {
        $smtpPassword = $payload['mail_smtp_password'] ?? null;
        if (is_string($smtpPassword) && $smtpPassword !== '') {
            Database::execute(
                'UPDATE forms SET mail_smtp_password = ?, updated_at = ? WHERE id = ?',
                [$smtpPassword, date('Y-m-d H:i:s'), $formId]
            );
        }

        $embedSecrets = $payload['embed'] ?? null;
        if (!is_array($embedSecrets)) {
            return;
        }

        $embed = FormEmbedSetting::forForm($formId, true);
        foreach (['turnstile_secret_key', 'recaptcha_secret_key', 'recaptcha_v3_secret_key'] as $key) {
            $value = $embedSecrets[$key] ?? null;
            if (is_string($value) && $value !== '') {
                $embed[$key] = $value;
            }
        }
        FormEmbedSetting::save($formId, $embed);
    }

    public static function readFromZip(string $zipPath): ?string
    {
        if (!class_exists(\ZipArchive::class)) {
            return null;
        }
        $zip = new \ZipArchive();
        if ($zip->open($zipPath, \ZipArchive::RDONLY) !== true) {
            return null;
        }
        try {
            $json = $zip->getFromName(self::FILE_NAME);

            return is_string($json) ? $json : null;
        } finally {
            $zip->close();
        }
    }
}
