<?php
namespace Core;

class Mailer
{
    /**
     * メール送信。複数宛先はカンマ区切り or 配列。
     */
    public static function send($to, string $subject, string $body, array $extraHeaders = [], array $mailConfig = []): bool
    {
        $recipients = [];
        if (is_array($to)) {
            foreach ($to as $address) {
                $address = trim((string) $address);
                if ($address !== '') {
                    $recipients[] = $address;
                }
            }
        } else {
            $recipients = array_filter(array_map('trim', preg_split('/[,;]+/', (string) $to) ?: []));
        }
        if ($recipients === []) {
            return false;
        }

        $sent = false;
        foreach ($recipients as $recipient) {
            $sent = self::sendSingle($recipient, $subject, $body, $extraHeaders, $mailConfig) || $sent;
        }

        return $sent;
    }

    /**
     * 全宛先を同一SMTPトランザクションで送信する。1件でもRCPTが拒否された場合はDATAを送らない。
     *
     * @param list<string> $recipients
     * @param list<array{stored_path:string,original_name:string,mime_type?:string,size?:int}> $attachments
     */
    public static function sendSmtpAll(array $recipients, string $subject, string $body, array $attachments, string $messageId, array $mailConfig): bool
    {
        $recipients = array_values(array_unique(array_filter(array_map('trim', $recipients), static fn(string $v): bool => filter_var($v, FILTER_VALIDATE_EMAIL) !== false)));
        if ($recipients === []) {
            return false;
        }
        $resolved = self::resolveMailConfig($mailConfig);
        if (!self::shouldUseSmtp($resolved)) {
            return false;
        }
        $headers = self::buildHeaders(['Message-ID' => self::normalizeMessageId($messageId, $resolved)], $resolved);
        if ($headers === null) {
            return false;
        }
        return self::sendViaSmtpMany($recipients, $subject, $body, $headers, $resolved, $attachments);
    }

    private static function sendSingle(string $to, string $subject, string $body, array $extraHeaders = [], array $mailConfig = []): bool
    {
        $to = trim($to);
        if ($to === '') {
            return false;
        }

        if (function_exists('mb_language')) {
            mb_language('Japanese');
        }
        if (function_exists('mb_internal_encoding')) {
            mb_internal_encoding('UTF-8');
        }

        $resolvedMailConfig = self::resolveMailConfig($mailConfig);
        $headers = self::buildHeaders($extraHeaders, $resolvedMailConfig);
        if ($headers === null) {
            return false;
        }

        if (self::shouldUseSmtp($resolvedMailConfig)) {
            return self::sendViaSmtp($to, $subject, $body, $headers, $resolvedMailConfig);
        }

        $fromEmail = self::extractEnvelopeFrom($headers['From'] ?? '', $resolvedMailConfig);
        // -f は sendmail のコマンドライン引数になるため、空白・引用符を含む値は引数注入を防ぐため使わない。
        if (!self::isSafeEnvelopeFrom($fromEmail)) {
            $fromEmail = trim((string) config('mail.from_email', ''));
        }
        $params = self::isSafeEnvelopeFrom($fromEmail) ? '-f' . $fromEmail : '';
        $additional = '';
        foreach ($headers as $k => $v) {
            if (in_array(strtolower($k), ['mime-version', 'content-type', 'content-transfer-encoding'], true)) {
                continue;
            }
            $additional .= $k . ': ' . $v . "\r\n";
        }

        if (function_exists('mb_send_mail')) {
            $sent = mb_send_mail($to, $subject, $body, $additional, $params);
            if (!$sent) {
                error_log('[formkun] mailer: mb_send_mail failed');
            }
            return $sent;
        }

        $allHeaders = '';
        foreach ($headers as $k => $v) {
            $allHeaders .= $k . ': ' . $v . "\r\n";
        }
        $sent = mail($to, self::encodeMimeHeader($subject), $body, $allHeaders, $params);
        if (!$sent) {
            error_log('[formkun] mailer: mail fallback failed');
        }
        return $sent;
    }

    private static function shouldUseSmtp(array $mailConfig): bool
    {
        $transport = strtolower(trim((string) ($mailConfig['transport'] ?? 'mail')));
        return $transport === 'smtp' || !empty($mailConfig['smtp']['enabled']);
    }

    private static function sendViaSmtp(string $to, string $subject, string $body, array $headers, array $mailConfig): bool
    {
        $socket = self::openSmtpSocket($mailConfig);
        if (!is_resource($socket)) {
            return false;
        }

        try {
            self::expectSmtpResponse($socket, [220]);

            $ehloHost = self::ehloHost($mailConfig);

            self::writeSmtpCommand($socket, 'EHLO ' . $ehloHost);
            self::expectSmtpResponse($socket, [250]);

            $secure = strtolower(trim((string) ($mailConfig['smtp']['secure'] ?? '')));
            if ($secure === 'tls') {
                self::writeSmtpCommand($socket, 'STARTTLS');
                self::expectSmtpResponse($socket, [220]);

                if (!defined('STREAM_CRYPTO_METHOD_TLS_CLIENT')) {
                    throw new \RuntimeException('この PHP 環境は STARTTLS に対応していません。');
                }

                $cryptoEnabled = stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
                if ($cryptoEnabled !== true) {
                    throw new \RuntimeException('STARTTLS の開始に失敗しました。');
                }

                self::writeSmtpCommand($socket, 'EHLO ' . $ehloHost);
                self::expectSmtpResponse($socket, [250]);
            }

            $username = trim((string) ($mailConfig['smtp']['username'] ?? ''));
            $password = (string) ($mailConfig['smtp']['password'] ?? '');
            if ($username !== '') {
                self::writeSmtpCommand($socket, 'AUTH LOGIN');
                self::expectSmtpResponse($socket, [334]);
                self::writeSmtpCommand($socket, base64_encode($username));
                self::expectSmtpResponse($socket, [334]);
                self::writeSmtpCommand($socket, base64_encode($password));
                self::expectSmtpResponse($socket, [235]);
            }

            $fromEmail = self::extractEnvelopeFrom($headers['From'] ?? '', $mailConfig);
            if (!filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
                throw new \RuntimeException('SMTP の送信元メールアドレスが不正です。');
            }

            if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
                throw new \RuntimeException('SMTP の宛先メールアドレスが不正です。');
            }

            self::writeSmtpCommand($socket, 'MAIL FROM:<' . $fromEmail . '>');
            self::expectSmtpResponse($socket, [250]);
            self::writeSmtpCommand($socket, 'RCPT TO:<' . $to . '>');
            self::expectSmtpResponse($socket, [250, 251]);
            self::writeSmtpCommand($socket, 'DATA');
            self::expectSmtpResponse($socket, [354]);

            $message = self::buildSmtpMessage($to, $subject, $body, $headers);
            $bytesWritten = fwrite($socket, $message . "\r\n.\r\n");
            if ($bytesWritten === false) {
                throw new \RuntimeException('SMTP メッセージ本文の送信に失敗しました。');
            }
            self::expectSmtpResponse($socket, [250]);

            self::writeSmtpCommand($socket, 'QUIT');
            self::expectSmtpResponse($socket, [221]);

            return true;
        } catch (\RuntimeException $e) {
            error_log('[formkun] mailer smtp failed');
            return false;
        } finally {
            fclose($socket);
        }
    }

    private static function sendViaSmtpMany(array $recipients, string $subject, string $body, array $headers, array $mailConfig, array $attachments): bool
    {
        $socket = self::openSmtpSocket($mailConfig);
        if (!is_resource($socket)) {
            return false;
        }
        try {
            self::smtpHandshake($socket, $mailConfig);
            $fromEmail = self::extractEnvelopeFrom($headers['From'] ?? '', $mailConfig);
            if (!filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
                throw new \RuntimeException('invalid_from');
            }
            self::writeSmtpCommand($socket, 'MAIL FROM:<' . $fromEmail . '>');
            self::expectSmtpResponse($socket, [250]);
            foreach ($recipients as $recipient) {
                if (!filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
                    throw new \RuntimeException('invalid_recipient');
                }
                self::writeSmtpCommand($socket, 'RCPT TO:<' . $recipient . '>');
                self::expectSmtpResponse($socket, [250, 251]);
            }
            self::writeSmtpCommand($socket, 'DATA');
            self::expectSmtpResponse($socket, [354]);
            $message = self::buildSmtpMessageMany($recipients, $subject, $body, $headers, $attachments);
            if (fwrite($socket, $message . "\r\n.\r\n") === false) {
                throw new \RuntimeException('data_write_failed');
            }
            self::expectSmtpResponse($socket, [250]);
            self::writeSmtpCommand($socket, 'QUIT');
            self::expectSmtpResponse($socket, [221]);
            return true;
        } catch (\Throwable $e) {
            error_log('[formkun] mailer smtp batch failed');
            return false;
        } finally {
            fclose($socket);
        }
    }

    private static function smtpHandshake($socket, array $mailConfig): void
    {
        self::expectSmtpResponse($socket, [220]);
        $ehloHost = self::ehloHost($mailConfig);
        self::writeSmtpCommand($socket, 'EHLO ' . $ehloHost);
        self::expectSmtpResponse($socket, [250]);
        $secure = strtolower(trim((string) ($mailConfig['smtp']['secure'] ?? '')));
        if ($secure === 'tls') {
            self::writeSmtpCommand($socket, 'STARTTLS');
            self::expectSmtpResponse($socket, [220]);
            if (!defined('STREAM_CRYPTO_METHOD_TLS_CLIENT') || stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT) !== true) {
                throw new \RuntimeException('tls_failed');
            }
            self::writeSmtpCommand($socket, 'EHLO ' . $ehloHost);
            self::expectSmtpResponse($socket, [250]);
        }
        $username = trim((string) ($mailConfig['smtp']['username'] ?? ''));
        if ($username !== '') {
            self::writeSmtpCommand($socket, 'AUTH LOGIN');
            self::expectSmtpResponse($socket, [334]);
            self::writeSmtpCommand($socket, base64_encode($username));
            self::expectSmtpResponse($socket, [334]);
            self::writeSmtpCommand($socket, base64_encode((string) ($mailConfig['smtp']['password'] ?? '')));
            self::expectSmtpResponse($socket, [235]);
        }
    }

    private static function buildSmtpMessageMany(array $recipients, string $subject, string $body, array $headers, array $attachments): string
    {
        $messageHeaders = array_merge([
            'To' => implode(', ', $recipients),
            'Subject' => self::encodeMimeHeader($subject),
            'Date' => date(DATE_RFC2822),
        ], $headers);
        if ($attachments === []) {
            $messageBody = self::normalizeMessageBody($body);
        } else {
            $boundary = '=_formkun_' . bin2hex(random_bytes(18));
            $messageHeaders['Content-Type'] = 'multipart/mixed; boundary="' . $boundary . '"';
            unset($messageHeaders['Content-Transfer-Encoding']);
            $parts = [
                '--' . $boundary,
                'Content-Type: text/plain; charset=UTF-8',
                'Content-Transfer-Encoding: 8bit',
                '',
                self::normalizeMessageBody($body),
            ];
            foreach ($attachments as $attachment) {
                $path = (string) ($attachment['stored_path'] ?? '');
                if ($path === '' || !is_file($path) || !is_readable($path)) {
                    throw new \RuntimeException('attachment_unreadable');
                }
                $raw = file_get_contents($path);
                if (!is_string($raw)) {
                    throw new \RuntimeException('attachment_read_failed');
                }
                $name = self::safeAttachmentName((string) ($attachment['original_name'] ?? 'attachment.bin'));
                $mime = preg_match('/\A[-+\.\w]+\/[-+\.\w]+\z/', (string) ($attachment['mime_type'] ?? ''))
                    ? (string) $attachment['mime_type'] : 'application/octet-stream';
                array_push($parts,
                    '--' . $boundary,
                    'Content-Type: ' . $mime . '; name*=UTF-8\'\'' . rawurlencode($name),
                    'Content-Disposition: attachment; filename*=UTF-8\'\'' . rawurlencode($name),
                    'Content-Transfer-Encoding: base64',
                    '',
                    rtrim(chunk_split(base64_encode($raw), 76, "\r\n"), "\r\n")
                );
            }
            $parts[] = '--' . $boundary . '--';
            $messageBody = implode("\r\n", $parts);
        }
        $lines = [];
        foreach ($messageHeaders as $key => $value) {
            $lines[] = $key . ': ' . $value;
        }
        return implode("\r\n", $lines) . "\r\n\r\n" . $messageBody;
    }

    private static function normalizeMessageId(string $messageId, array $mailConfig): string
    {
        $id = preg_replace('/[^a-zA-Z0-9._-]+/', '', trim($messageId)) ?: bin2hex(random_bytes(16));
        $host = trim((string) ($mailConfig['smtp']['ehlo_host'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost')));
        $host = preg_match('/\A[a-zA-Z0-9.-]+\z/', $host) ? $host : 'localhost';
        return '<' . $id . '@' . $host . '>';
    }

    private static function safeAttachmentName(string $name): string
    {
        $name = basename(str_replace('\\', '/', $name));
        $name = preg_replace('/[\x00-\x1F\x7F]+/u', '', $name) ?? '';
        return mb_substr(trim($name) !== '' ? trim($name) : 'attachment.bin', 0, 180);
    }

    /**
     * @return resource|null
     */
    private static function openSmtpSocket(array $mailConfig)
    {
        $host = trim((string) ($mailConfig['smtp']['host'] ?? ''));
        $port = (int) ($mailConfig['smtp']['port'] ?? 25);
        $secure = strtolower(trim((string) ($mailConfig['smtp']['secure'] ?? '')));
        $timeout = (int) ($mailConfig['smtp']['timeout'] ?? 10);

        if ($host === '' || $port <= 0) {
            error_log('[formkun] mailer smtp configuration missing');
            return null;
        }
        if (!in_array($secure, ['', 'ssl', 'tls'], true)) {
            error_log('[formkun] mailer smtp configuration invalid');
            return null;
        }

        $transport = $secure === 'ssl' ? 'ssl' : 'tcp';
        $remote = $transport . '://' . $host . ':' . $port;
        $context = stream_context_create([
            'ssl' => [
                'verify_peer' => !empty($mailConfig['smtp']['verify_peer']),
                'verify_peer_name' => !empty($mailConfig['smtp']['verify_peer_name']),
                'allow_self_signed' => !empty($mailConfig['smtp']['allow_self_signed']),
            ],
        ]);

        $errno = 0;
        $errstr = '';
        // 接続失敗は戻り値と分類ログで処理する。debug環境でもWarningをHTMLへ出さず、
        // リダイレクトやJSONレスポンスのヘッダーを壊さない。
        $socket = @stream_socket_client($remote, $errno, $errstr, max(1, $timeout), STREAM_CLIENT_CONNECT, $context);
        if (!is_resource($socket)) {
            error_log('[formkun] mailer smtp connection failed');
            return null;
        }

        stream_set_timeout($socket, max(1, $timeout));
        return $socket;
    }

    private static function isSafeEnvelopeFrom(string $email): bool
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false
            && preg_match('/[\s"\'\\\\`$]/', $email) !== 1;
    }

    public static function isValidEhloHost(string $host): bool
    {
        return preg_match('/\A[A-Za-z0-9.-]{1,253}\z/', $host) === 1;
    }

    private static function ehloHost(array $mailConfig): string
    {
        $host = trim((string) ($mailConfig['smtp']['ehlo_host'] ?? ($_SERVER['SERVER_NAME'] ?? 'localhost')));
        return self::isValidEhloHost($host) ? $host : 'localhost';
    }

    private static function writeSmtpCommand($socket, string $command): void
    {
        if (preg_match('/[\r\n]/', $command) === 1) {
            throw new \RuntimeException('SMTP コマンドに改行は含められません。');
        }
        $bytesWritten = fwrite($socket, $command . "\r\n");
        if ($bytesWritten === false) {
            throw new \RuntimeException('SMTP コマンド送信に失敗しました。');
        }
    }

    /**
     * @param array<int, int> $expectedCodes
     */
    private static function expectSmtpResponse($socket, array $expectedCodes): string
    {
        $response = self::readSmtpResponse($socket);
        $code = (int) substr($response, 0, 3);
        if (!in_array($code, $expectedCodes, true)) {
            throw new \RuntimeException('SMTP 応答が不正です。受信: ' . trim($response));
        }
        return $response;
    }

    private static function readSmtpResponse($socket): string
    {
        $response = '';
        while (($line = fgets($socket, 515)) !== false) {
            $response .= $line;
            if (strlen($line) < 4 || $line[3] === ' ') {
                break;
            }
        }

        if ($response === '') {
            throw new \RuntimeException('SMTP 応答を受信できませんでした。');
        }

        $meta = stream_get_meta_data($socket);
        if (!empty($meta['timed_out'])) {
            throw new \RuntimeException('SMTP 応答がタイムアウトしました。');
        }

        return $response;
    }

    private static function buildSmtpMessage(string $to, string $subject, string $body, array $headers): string
    {
        $messageHeaders = array_merge(
            [
                'To' => $to,
                'Subject' => self::encodeMimeHeader($subject),
                'Date' => date(DATE_RFC2822),
            ],
            $headers
        );

        $lines = [];
        foreach ($messageHeaders as $k => $v) {
            $lines[] = $k . ': ' . $v;
        }

        return implode("\r\n", $lines) . "\r\n\r\n" . self::normalizeMessageBody($body);
    }

    private static function normalizeMessageBody(string $body): string
    {
        $normalized = str_replace(["\r\n", "\r"], "\n", $body);
        $lines = explode("\n", $normalized);
        foreach ($lines as &$line) {
            if (strpos($line, '.') === 0) {
                $line = '.' . $line;
            }
        }
        unset($line);

        return implode("\r\n", $lines);
    }

    /**
     * @return array<string, string>|null
     */
    private static function buildHeaders(array $extraHeaders, array $mailConfig): ?array
    {
        $headers = array_merge([
            'From' => self::buildDefaultFromHeader($mailConfig),
            'MIME-Version' => '1.0',
            'Content-Type' => 'text/plain; charset=UTF-8',
        ], $extraHeaders);

        $normalized = [];
        foreach ($headers as $k => $v) {
            $name = trim((string) $k);
            $value = trim((string) $v);
            if ($name === '' || $value === '') {
                continue;
            }
            if (!preg_match('/\A[A-Za-z0-9\-]+\z/', $name)) {
                error_log('[formkun] mailer: invalid header name blocked');
                return null;
            }
            if (preg_match('/[\r\n]/', $value)) {
                error_log('[formkun] mailer: header injection blocked');
                return null;
            }
            $normalized[$name] = $value;
        }

        return $normalized;
    }

    private static function buildDefaultFromHeader(array $mailConfig): string
    {
        $fromEmail = trim((string) ($mailConfig['from_email'] ?? 'noreply@example.com'));
        $fromName = trim((string) ($mailConfig['from_name'] ?? ''));
        if ($fromName === '') {
            return $fromEmail;
        }

        return self::encodeMimeHeader($fromName) . ' <' . $fromEmail . '>';
    }

    private static function extractEnvelopeFrom(string $fromHeader, array $mailConfig): string
    {
        if (preg_match('/<([^>]+)>/', $fromHeader, $matches) === 1) {
            return trim((string) $matches[1]);
        }

        $candidate = trim($fromHeader);
        if (filter_var($candidate, FILTER_VALIDATE_EMAIL)) {
            return $candidate;
        }

        return trim((string) ($mailConfig['from_email'] ?? 'noreply@example.com'));
    }

    /**
     * @param array<string, mixed> $mailConfig
     * @return array<string, mixed>
     */
    private static function resolveMailConfig(array $mailConfig): array
    {
        $baseConfig = (array) config('mail', []);
        if (!isset($baseConfig['smtp']) || !is_array($baseConfig['smtp'])) {
            $baseConfig['smtp'] = [];
        }
        if (!isset($mailConfig['smtp']) || !is_array($mailConfig['smtp'])) {
            $mailConfig['smtp'] = [];
        }

        return array_replace_recursive($baseConfig, $mailConfig);
    }

    private static function encodeMimeHeader(string $value): string
    {
        if ($value === '') {
            return '';
        }

        if (preg_match('/\A[\x20-\x7E]+\z/', $value) === 1) {
            return $value;
        }

        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }

    /**
     * テンプレート内の {{field_key}} を置換。
     * 特別キー: {{__all__}} = 全項目を「ラベル: 値」改行区切り
     *           {{__submitted_at__}} {{__form_title__}} {{__ip__}} など。
     *
     * @param array<int, array> $fields
     * @param array<string, mixed> $values
     */
    public static function renderTemplate(string $template, array $fields, array $values, array $context = []): string
    {
        $fields = self::orderedSubmittableFields($fields);
        $typesByKey = [];
        foreach ($fields as $f) {
            if (\Models\FormField::isDisplayOnlyType((string) ($f['type'] ?? ''))) {
                continue;
            }
            $typesByKey[$f['field_key']] = $f['type'];
        }

        $lineFileUrls = [];
        if (isset($context['line_public_file_urls']) && is_array($context['line_public_file_urls'])) {
            foreach ($context['line_public_file_urls'] as $urlKey => $url) {
                if (is_string($urlKey) && is_string($url) && $url !== '') {
                    $lineFileUrls[$urlKey] = $url;
                }
            }
        }

        $allLines = [];
        foreach ($fields as $f) {
            if (\Models\FormField::isDisplayOnlyType((string) ($f['type'] ?? ''))) {
                continue;
            }
            $val = $values[$f['field_key']] ?? '';
            if ($f['type'] === 'file') {
                $name = is_string($val) ? $val : (is_array($val) && !empty($val['name']) ? $val['name'] : '');
                $line = $f['label'] . ': ' . ($name !== '' ? $name : '（ファイルなし）');
                $fieldKey = (string) ($f['field_key'] ?? '');
                if ($name !== '' && $fieldKey !== '' && isset($lineFileUrls[$fieldKey])) {
                    $line .= "\n" . $lineFileUrls[$fieldKey];
                }
                $allLines[] = $line;
                continue;
            }
            if ($f['type'] === 'address') {
                $valStr = \format_address_value_display($val);
                $allLines[] = $f['label'] . ":\n" . $valStr;
                continue;
            }
            if ($f['type'] === 'text_pair') {
                $pairLabels = \Models\FormField::decodeTextPairLabels($f['options_json'] ?? null);
                $valStr = \format_text_pair_value_display($val, $pairLabels);
                $allLines[] = $f['label'] . ":\n" . $valStr;
                continue;
            }
            if ($f['type'] === 'text_multi') {
                $multiItems = \Models\FormField::decodeTextMultiItems($f['options_json'] ?? null, true);
                $valStr = \format_text_multi_value_display($val, $multiItems);
                $allLines[] = $f['label'] . ":\n" . $valStr;
                continue;
            }
            if ($f['type'] === \Models\FormField::TYPE_MATRIX) {
                $matrixSettings = \Models\FormField::decodeMatrixSettings($f['options_json'] ?? null);
                $valStr = \format_matrix_value_display($val, $matrixSettings);
                $allLines[] = $f['label'] . ":\n" . $valStr;
                continue;
            }
            if (is_array($val)) {
                $val = implode(', ', $val);
            }
            $allLines[] = $f['label'] . ":\n" . $val;
        }
        $allText = implode("\n----------------------------------\n", $allLines);

        $replacements = [
            '{{__all__}}'           => $allText,
            '{{__submitted_at__}}'  => $context['submitted_at'] ?? date('Y-m-d H:i:s'),
            '{{__form_title__}}'    => $context['form_title'] ?? '',
            '{{__ip__}}'            => $context['ip'] ?? '',
        ];

        foreach ($values as $key => $val) {
            if (($typesByKey[$key] ?? '') === 'address') {
                $val = \format_address_value_display($val);
            } elseif (($typesByKey[$key] ?? '') === 'text_pair') {
                $field = null;
                foreach ($fields as $f) {
                    if (($f['field_key'] ?? '') === $key) {
                        $field = $f;
                        break;
                    }
                }
                $pairLabels = \Models\FormField::decodeTextPairLabels($field['options_json'] ?? null);
                $val = \format_text_pair_value_display($val, $pairLabels);
            } elseif (($typesByKey[$key] ?? '') === 'text_multi') {
                $field = null;
                foreach ($fields as $f) {
                    if (($f['field_key'] ?? '') === $key) {
                        $field = $f;
                        break;
                    }
                }
                $multiItems = \Models\FormField::decodeTextMultiItems($field['options_json'] ?? null, true);
                $val = \format_text_multi_value_display($val, $multiItems);
            } elseif (($typesByKey[$key] ?? '') === \Models\FormField::TYPE_MATRIX) {
                $field = null;
                foreach ($fields as $f) {
                    if (($f['field_key'] ?? '') === $key) {
                        $field = $f;
                        break;
                    }
                }
                $matrixSettings = \Models\FormField::decodeMatrixSettings($field['options_json'] ?? null);
                $val = \format_matrix_value_display($val, $matrixSettings);
            } elseif (is_array($val)) {
                if (isset($val['name'])) {
                    $val = (string) $val['name'];
                } else {
                    $val = implode(', ', $val);
                }
            }
            if (($typesByKey[$key] ?? '') === 'file') {
                $name = is_string($val) ? trim($val) : '';
                if ($name !== '' && isset($lineFileUrls[$key])) {
                    $val = $name . "\n" . $lineFileUrls[$key];
                }
            }
            $replacements['{{' . $key . '}}'] = (string) $val;
        }

        return strtr($template, $replacements);
    }

    /**
     * 件名用テンプレートを1行ヘッダ向けに展開・正規化する。
     *
     * @param array<int, array> $fields
     * @param array<string, mixed> $values
     */
    public static function renderSubjectTemplate(string $template, array $fields, array $values, array $context = []): string
    {
        $subject = self::renderTemplate($template, $fields, $values, $context);
        $subject = preg_replace('/\R/u', ' ', $subject) ?? str_replace(["\r", "\n"], ' ', $subject);
        $subject = trim($subject);

        return preg_replace('/[[:space:]]+/u', ' ', $subject) ?? $subject;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<int, array<string, mixed>>
     */
    private static function orderedSubmittableFields(array $fields): array
    {
        if ($fields === []) {
            return [];
        }

        $formId = (int) ($fields[0]['form_id'] ?? 0);
        if ($formId <= 0) {
            return array_values(array_filter($fields, static function ($field): bool {
                return is_array($field) && !\Models\FormField::isDisplayOnlyType((string) ($field['type'] ?? ''));
            }));
        }

        return \Models\FormField::orderedSubmittableForForm($formId, true);
    }
}
