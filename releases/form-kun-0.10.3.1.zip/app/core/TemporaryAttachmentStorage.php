<?php
namespace Core;

class TemporaryAttachmentStorage
{
    private const TTL_SECONDS = 1800;

    public static function store(array $entry): ?array
    {
        if ((int) ($entry['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file((string) ($entry['tmp_name'] ?? ''))) {
            return null;
        }
        self::pruneMaybe();
        $dir = self::directory();
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            throw new \RuntimeException('一時添付ディレクトリを作成できません。');
        }
        $token = bin2hex(random_bytes(24));
        $path = $dir . DIRECTORY_SEPARATOR . $token . '.tmp';
        if (!@move_uploaded_file((string) $entry['tmp_name'], $path)) {
            throw new \RuntimeException('添付ファイルを一時保存できません。');
        }
        @chmod($path, 0600);
        return [
            'temporary' => 1,
            'stored_path' => $path,
            'original_name' => self::safeName((string) ($entry['name'] ?? 'attachment.bin')),
            'mime_type' => self::mime($path),
            'size' => (int) filesize($path),
        ];
    }

    public static function fromUpload(array $entry): ?array
    {
        $path = (string) ($entry['tmp_name'] ?? '');
        if ((int) ($entry['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || $path === '' || !is_uploaded_file($path)) {
            return null;
        }
        return [
            'temporary' => 0,
            'stored_path' => $path,
            'original_name' => self::safeName((string) ($entry['name'] ?? 'attachment.bin')),
            'mime_type' => self::mime($path),
            'size' => (int) ($entry['size'] ?? filesize($path)),
        ];
    }

    public static function isReadableAttachment(array $attachment): bool
    {
        $path = (string) ($attachment['stored_path'] ?? '');
        if ($path === '' || !is_file($path) || !is_readable($path)) {
            return false;
        }
        if (empty($attachment['temporary'])) {
            return is_uploaded_file($path);
        }
        return str_starts_with($path, self::directory() . DIRECTORY_SEPARATOR);
    }

    public static function delete(array $attachment): void
    {
        if (empty($attachment['temporary'])) {
            return;
        }
        $path = (string) ($attachment['stored_path'] ?? '');
        $dir = self::directory() . DIRECTORY_SEPARATOR;
        if ($path !== '' && str_starts_with($path, $dir) && is_file($path)) {
            @unlink($path);
        }
    }

    public static function deleteAll(array $attachments): void
    {
        foreach ($attachments as $attachment) {
            if (is_array($attachment)) {
                self::delete($attachment);
            }
        }
    }

    public static function prune(): void
    {
        $dir = self::directory();
        if (!is_dir($dir)) {
            return;
        }
        $cutoff = time() - self::TTL_SECONDS;
        foreach (glob($dir . DIRECTORY_SEPARATOR . '*.tmp') ?: [] as $path) {
            if (is_file($path) && (int) filemtime($path) < $cutoff) {
                @unlink($path);
            }
        }
    }

    private static function pruneMaybe(): void
    {
        if (random_int(1, 20) === 1) {
            self::prune();
        }
    }

    private static function directory(): string
    {
        // 公開ルート配下には置かず、同一ホスト上の別インストールとも分離する。
        $installationKey = substr(hash('sha256', PUBLIC_DIR), 0, 16);
        return rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
            . DIRECTORY_SEPARATOR . 'form-kun-mail-attachments-' . $installationKey;
    }

    private static function safeName(string $name): string
    {
        $name = basename(str_replace('\\', '/', $name));
        $name = preg_replace('/[\x00-\x1F\x7F]+/u', '', $name) ?? '';
        return mb_substr(trim($name) !== '' ? trim($name) : 'attachment.bin', 0, 180);
    }

    private static function mime(string $path): string
    {
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = $finfo ? finfo_file($finfo, $path) : false;
            if ($finfo) { finfo_close($finfo); }
            if (is_string($mime) && $mime !== '') {
                return $mime;
            }
        }
        return 'application/octet-stream';
    }
}
