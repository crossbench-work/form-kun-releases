<?php
namespace Core;

class SiteResource
{
    public static function usedUploadsBytes(): int
    {
        return FileStorage::directorySize(UPLOADS_DIR);
    }

    public static function usedDatabaseBytes(): int
    {
        try {
            $row = Database::fetchOne(
                'SELECT COALESCE(SUM(data_length + index_length), 0) AS bytes
                 FROM information_schema.TABLES
                 WHERE table_schema = DATABASE()'
            );
            if ($row === null) {
                return 0;
            }
            return max(0, (int) ($row['bytes'] ?? 0));
        } catch (\Throwable) {
            return 0;
        }
    }

    public static function usedTotalBytes(): int
    {
        return self::usedUploadsBytes() + self::usedDatabaseBytes();
    }

    public static function maxBytes(): int
    {
        return effective_max_site_resource_bytes();
    }

    public static function usagePercent(): float
    {
        $max = self::maxBytes();
        if ($max <= 0) {
            return 0.0;
        }
        return min(100.0, (self::usedTotalBytes() / $max) * 100.0);
    }

    public static function warningRatio(): float
    {
        $ratio = (float) config('limits.resource_warning_ratio', 0.8);
        if ($ratio < 0.0) {
            $ratio = 0.0;
        }
        if ($ratio > 1.0) {
            $ratio = 1.0;
        }
        return $ratio;
    }

    public static function isWarning(): bool
    {
        if (self::isExceeded()) {
            return true;
        }
        $max = self::maxBytes();
        if ($max <= 0) {
            return false;
        }
        return self::usedTotalBytes() >= (int) floor($max * self::warningRatio());
    }

    public static function isExceeded(): bool
    {
        return self::usedTotalBytes() >= self::maxBytes();
    }

    /**
     * 追加バイトを含めた場合に上限を超えるか。
     */
    public static function wouldExceedWithAdditionalBytes(int $additionalBytes): bool
    {
        if ($additionalBytes < 0) {
            $additionalBytes = 0;
        }
        return self::usedTotalBytes() + $additionalBytes > self::maxBytes();
    }

    /**
     * @return array{
     *   used_uploads:int,
     *   used_db:int,
     *   used_total:int,
     *   max:int,
     *   percent:float,
     *   warning:bool,
     *   exceeded:bool
     * }
     */
    public static function snapshot(): array
    {
        return [
            'used_uploads' => self::usedUploadsBytes(),
            'used_db'      => self::usedDatabaseBytes(),
            'used_total'   => self::usedTotalBytes(),
            'max'          => self::maxBytes(),
            'percent'      => self::usagePercent(),
            'warning'      => self::isWarning(),
            'exceeded'     => self::isExceeded(),
        ];
    }
}
