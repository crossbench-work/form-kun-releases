<?php
namespace Core;

class PublicApiRateLimiter
{
    /** @return array{allowed: bool, retry_after: int} */
    public static function consume(int $formId, string $ip, int $limit, int $windowSeconds): array
    {
        $ip = substr($ip, 0, 45);
        $limit = max(1, $limit);
        $windowSeconds = max(60, $windowSeconds);
        $now = time();

        $result = Database::transaction(function () use ($formId, $ip, $limit, $windowSeconds, $now): array {
            Database::execute(
                'INSERT IGNORE INTO public_api_rate_limits (form_id, ip, window_started_at, attempt_count, updated_at) VALUES (?,?,?,?,?)',
                [$formId, $ip, $now, 0, date('Y-m-d H:i:s')]
            );
            $row = Database::fetchOne(
                'SELECT * FROM public_api_rate_limits WHERE form_id = ? AND ip = ? FOR UPDATE',
                [$formId, $ip]
            );
            if ($row === null) {
                throw new \RuntimeException('レート制限状態を取得できませんでした。');
            }
            if ($now - (int) ($row['window_started_at'] ?? 0) >= $windowSeconds) {
                Database::execute(
                    'UPDATE public_api_rate_limits SET window_started_at = ?, attempt_count = 1, updated_at = ? WHERE form_id = ? AND ip = ?',
                    [$now, date('Y-m-d H:i:s'), $formId, $ip]
                );
                return ['allowed' => true, 'retry_after' => 0];
            }

            $count = (int) ($row['attempt_count'] ?? 0);
            $retryAfter = max(1, $windowSeconds - ($now - (int) $row['window_started_at']));
            if ($count >= $limit) {
                return ['allowed' => false, 'retry_after' => $retryAfter];
            }
            Database::execute(
                'UPDATE public_api_rate_limits SET attempt_count = attempt_count + 1, updated_at = ? WHERE form_id = ? AND ip = ?',
                [date('Y-m-d H:i:s'), $formId, $ip]
            );
            return ['allowed' => true, 'retry_after' => 0];
        });

        if (random_int(1, 100) === 1) {
            Database::execute('DELETE FROM public_api_rate_limits WHERE updated_at < ?', [date('Y-m-d H:i:s', $now - 172800)]);
        }
        return $result;
    }
}
