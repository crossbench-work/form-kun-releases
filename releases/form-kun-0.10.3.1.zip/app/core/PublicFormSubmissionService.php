<?php
namespace Core;

use Models\Form;
use Models\FormBranchRule;
use Models\FormField;
use Models\FormFieldGroup;
use Models\FormInputPage;

class PublicFormSubmissionService
{
    /**
     * @param array<string, mixed> $input
     * @param array<string, mixed> $uploadedFiles
     * @return array{success: bool, errors?: array<string, mixed>}
     */
    public static function submit(array $form, array $input, array $uploadedFiles): array
    {
        $formId = (int) $form['id'];
        $fields = FormField::forForm($formId, true);
        $groups = FormFieldGroup::forForm($formId, true);
        $pages = FormInputPage::forForm($formId, $form);
        $rules = FormBranchRule::forForm($formId);
        $values = [];
        $errors = [];
        $submittedKeys = [];
        $visited = [];
        $page = $pages[0] ?? FormInputPage::defaultPage($form);

        while ($page !== null) {
            $pageKey = (string) ($page['page_key'] ?? FormInputPage::DEFAULT_KEY);
            if (isset($visited[$pageKey])) {
                throw new \RuntimeException('フォームの画面分岐が循環しています。');
            }
            $visited[$pageKey] = true;
            if (count($visited) > count($pages)) {
                throw new \RuntimeException('フォームの画面分岐が不正です。');
            }

            $pageFields = FormField::forInputPage($fields, $pageKey);
            $candidateValues = array_merge($input, $values);
            $visibleFields = self::visibleFieldsForPage($pageFields, $groups, $rules, $candidateValues, $pageKey);
            $files = self::fileMap($visibleFields, $uploadedFiles);
            $result = (new Validator())->validate($visibleFields, $input, $files);
            $values = array_merge($values, $result['values']);
            foreach ((array) $result['errors'] as $fieldKey => $fieldErrors) {
                $errors[$fieldKey] = $fieldErrors;
            }
            foreach ($visibleFields as $field) {
                $fieldKey = (string) ($field['field_key'] ?? '');
                if ($fieldKey !== '' && !FormField::isDisplayOnlyType((string) ($field['type'] ?? ''))) {
                    $submittedKeys[$fieldKey] = true;
                }
            }

            // 遷移判定には、到達して検証対象になった項目だけを使う。
            // 非表示項目をPOSTして分岐を強制することは許可しない。
            $evaluation = FormBranchRule::evaluate($rules, $values, $pageKey);
            $nextKey = $evaluation['next_screen_key'] ?? FormInputPage::nextPageKey($pages, $pageKey);
            if ($nextKey === null || in_array($nextKey, [FormBranchRule::SCREEN_CONFIRM, FormBranchRule::SCREEN_THANKS], true)) {
                break;
            }
            $page = FormInputPage::findPage($pages, (string) $nextKey);
            if ($page === null) {
                throw new \RuntimeException('フォームの遷移先画面が見つかりません。');
            }
        }

        if ($errors !== []) {
            return ['success' => false, 'errors' => $errors];
        }

        $orderedFields = FormField::orderedSubmittableForForm($formId, true);
        $submittedFields = array_values(array_filter($orderedFields, static function (array $field) use ($submittedKeys): bool {
            return isset($submittedKeys[(string) ($field['field_key'] ?? '')]);
        }));
        $deliveryId = trim((string) ($input['delivery_id'] ?? ''));
        unset($values['delivery_id']);
        if (Form::isMailOnly($form) && !is_uuid_v4($deliveryId)) {
            return ['success' => false, 'errors' => ['delivery_id' => ['delivery_id は UUID v4 で指定してください。']]];
        }
        if ($deliveryId === '') { $deliveryId = uuid_v4(); }
        $fileMetas = self::storeFiles($form, $submittedFields, $uploadedFiles);
        if (Form::isMailOnly($form) && !SubmissionDeliveryService::attachmentsWithinLimit($form, $fileMetas)) {
            self::deleteFiles($fileMetas);
            return ['success' => false, 'errors' => ['_attachments' => ['添付ファイルの合計サイズがメール添付上限を超えています。']]];
        }
        $delivery = SubmissionDeliveryService::deliver($form, $submittedFields, $values, $fileMetas, 'embed_api', $deliveryId);
        if (!$delivery['success']) {
            self::deleteFiles($fileMetas);
            return ['success' => false, 'delivery_error' => true, 'error_code' => 'mail_delivery_failed'];
        }
        if (Form::isMailOnly($form)) { self::deleteFiles($fileMetas); }
        return ['success' => true];
    }

    /** @param array<int, array<string, mixed>> $fields @param array<string, mixed> $uploadedFiles */
    private static function fileMap(array $fields, array $uploadedFiles): array
    {
        $files = [];
        foreach ($fields as $field) {
            if (($field['type'] ?? '') !== 'file') {
                continue;
            }
            $key = (string) ($field['field_key'] ?? '');
            if ($key !== '' && isset($uploadedFiles[$key]) && is_array($uploadedFiles[$key])) {
                $files[$key] = $uploadedFiles[$key];
            }
        }
        return $files;
    }

    /** @param array<int, array<string, mixed>> $fields @param array<string, mixed> $uploadedFiles */
    private static function storeFiles(array $form, array $fields, array $uploadedFiles): array
    {
        $metas = [];
        $formUuid = Form::requirePublicUuid($form);
        try {
            foreach ($fields as $field) {
                if (($field['type'] ?? '') !== 'file') {
                    continue;
                }
                $key = (string) ($field['field_key'] ?? '');
                $entry = $uploadedFiles[$key] ?? null;
                if (!is_array($entry) || (int) ($entry['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
                    continue;
                }
                $meta = Form::isMailOnly($form)
                    ? TemporaryAttachmentStorage::fromUpload($entry)
                    : FileStorage::store($entry, $formUuid, FormField::decodeFileSettings($field['options_json'] ?? null));
                if ($meta !== null) {
                    $metas[$key] = $meta;
                }
            }
            return $metas;
        } catch (\Throwable $e) {
            self::deleteFiles($metas);
            throw $e;
        }
    }

    private static function deleteFiles(array $fileMetas): void
    {
        foreach ($fileMetas as $meta) {
            if (is_array($meta) && !empty($meta['stored_path'])) {
                if (array_key_exists('temporary', $meta)) { TemporaryAttachmentStorage::delete($meta); }
                else { FileStorage::delete((string) $meta['stored_path']); }
            }
        }
    }

    /** @return array<int, array<string, mixed>> */
    private static function visibleFieldsForPage(array $fields, array $groups, array $rules, array $values, string $pageKey): array
    {
        $controlledFields = [];
        $controlledGroups = [];
        foreach (FormBranchRule::normalizeRules($rules) as $rule) {
            if (empty($rule['enabled']) || (string) $rule['trigger_page_key'] !== $pageKey || $rule['action_type'] !== FormBranchRule::ACTION_SHOW_FIELD) {
                continue;
            }
            if (($rule['target_type'] ?? FormBranchRule::TARGET_FIELD) === FormBranchRule::TARGET_GROUP) {
                $controlledGroups[] = (string) $rule['target_key'];
            } else {
                $controlledFields[] = (string) $rule['target_key'];
            }
        }
        $evaluation = FormBranchRule::evaluate($rules, $values, $pageKey);
        $hiddenGroups = self::hiddenGroupKeys($groups, $controlledGroups, $evaluation['visible_group_keys']);
        return array_values(array_filter($fields, static function (array $field) use ($controlledFields, $evaluation, $hiddenGroups, $groups): bool {
            if (empty($field['visible'])) {
                return false;
            }
            $key = (string) ($field['field_key'] ?? '');
            if (in_array($key, $controlledFields, true) && !in_array($key, $evaluation['visible_field_keys'], true)) {
                return false;
            }
            return !self::belongsToHiddenGroup($field, $hiddenGroups, $groups);
        }));
    }

    /** @return list<string> */
    private static function hiddenGroupKeys(array $groups, array $controlled, array $visible): array
    {
        $hidden = array_values(array_diff($controlled, $visible));
        foreach ($groups as $group) {
            if (empty($group['visible'])) {
                $hidden[] = (string) ($group['group_key'] ?? '');
            }
        }
        $hidden = array_values(array_unique(array_filter($hidden)));
        $changed = true;
        while ($changed) {
            $changed = false;
            foreach ($groups as $group) {
                $key = (string) ($group['group_key'] ?? '');
                $parent = (string) ($group['parent_group_key'] ?? '');
                if ($key !== '' && $parent !== '' && in_array($parent, $hidden, true) && !in_array($key, $hidden, true)) {
                    $hidden[] = $key;
                    $changed = true;
                }
            }
        }
        return $hidden;
    }

    private static function belongsToHiddenGroup(array $field, array $hidden, array $groups): bool
    {
        $parent = (string) ($field['parent_group_key'] ?? '');
        $parentMap = [];
        foreach ($groups as $group) {
            $key = (string) ($group['group_key'] ?? '');
            if ($key !== '') {
                $parentMap[$key] = (string) ($group['parent_group_key'] ?? '');
            }
        }
        $seen = [];
        while ($parent !== '') {
            if (isset($seen[$parent])) {
                return true;
            }
            $seen[$parent] = true;
            if (in_array($parent, $hidden, true)) {
                return true;
            }
            $parent = (string) ($parentMap[$parent] ?? '');
        }
        return false;
    }
}
