<?php
namespace Core;

class FileStorage
{
    /**
     * アップロードを uploads/{form_uuid}/{file_uuid}.ext に保存し、メタ情報を返す。
     *
     * @return array{stored_path:string, file_uuid:string, original_name:string, mime_type:string, size:int}|null
     */
    public static function directorySize(string $dir): int
    {
        if (!is_dir($dir)) {
            return 0;
        }

        $total = 0;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $total += (int) $file->getSize();
            }
        }
        return $total;
    }

    public static function store(array $entry, string $formUuid, array $fileSettings = []): ?array
    {
        if (!isset($entry['tmp_name']) || $entry['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($entry['tmp_name'])) {
            return null;
        }

        $incomingSize = (int) ($entry['size'] ?? 0);
        if (SiteResource::wouldExceedWithAdditionalBytes($incomingSize)) {
            throw new \RuntimeException('サイトの利用容量が上限に達しているため、ファイルをアップロードできません。');
        }

        $formUuid = self::normalizeUuid($formUuid);
        if ($formUuid === null) {
            throw new \InvalidArgumentException('フォーム UUID が不正です。');
        }

        $fileUuid = \uuid_v4();
        $dir = UPLOADS_DIR . DIRECTORY_SEPARATOR . $formUuid;
        if (!is_dir($dir)) {
            if (!@mkdir($dir, 0775, true) && !is_dir($dir)) {
                throw new \RuntimeException('uploads ディレクトリを作成できません: ' . $dir);
            }
        }

        $original = self::sanitizeName((string) ($entry['name'] ?? 'upload.bin'));
        $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
        $normalizedSettings = self::normalizeFileSettings($fileSettings);
        $selectionMode = (string) ($normalizedSettings['selection_mode'] ?? \Models\FormField::FILE_SELECTION_CUSTOM);
        $shouldConvertToJpeg = $selectionMode === \Models\FormField::FILE_SELECTION_IMAGE && !empty($normalizedSettings['convert_to_jpeg']);
        $normalizedAllowed = self::allowedExtensionsForStorage($normalizedSettings);
        if ($normalizedAllowed !== [] && ($ext === '' || !in_array($ext, $normalizedAllowed, true))) {
            throw new \RuntimeException('許可されていない拡張子です。');
        }
        $tmpPath = $dir . DIRECTORY_SEPARATOR . $fileUuid . '.upload';

        if (!@move_uploaded_file($entry['tmp_name'], $tmpPath)) {
            throw new \RuntimeException('アップロードファイルの保存に失敗しました。');
        }
        @chmod($tmpPath, 0644);

        $destBase = $dir . DIRECTORY_SEPARATOR . $fileUuid;
        try {
            $tmpMime = FileTypePolicy::detectMime($tmpPath);
            if (!FileTypePolicy::isMimeAllowedForExtension($ext, $tmpMime)) {
                throw new \RuntimeException('ファイルの拡張子と内容が一致しません。');
            }
            if ($selectionMode === \Models\FormField::FILE_SELECTION_IMAGE && !self::isAcceptedImageUpload($ext, $tmpMime)) {
                throw new \RuntimeException('画像ファイルのみアップロードできます。');
            }

            if ($shouldConvertToJpeg) {
                if (!in_array($ext, ['jpg', 'jpeg'], true) || $tmpMime !== 'image/jpeg') {
                    if (in_array($ext, ['heic', 'heif'], true) || in_array($tmpMime, ['image/heic', 'image/heif'], true)) {
                        throw new \RuntimeException('ブラウザ側でHEIC / HEIFをJPEGへ変換できませんでした。別形式へ変換してからアップロードしてください。');
                    }
                    throw new \RuntimeException('ブラウザ側で画像をJPEGへ変換できませんでした。JPEG画像に変換してからアップロードしてください。');
                }
                $optimized = null;
            } elseif (!FileTypePolicy::isKnownExtension($ext)) {
                // 独自拡張子は内容にかかわらず .bin で保持し、実行可能な保存名を作らない。
                $optimized = null;
            } else {
                $imageConfig = (array) config('upload.image', []);
                $optimized = ImageOptimizer::optimize($tmpPath, $destBase, $imageConfig);
            }

            if ($optimized !== null && isset($optimized['output_path']) && is_file($optimized['output_path'])) {
                $storedExt = (string) $optimized['stored_ext'];
                $absPath = $dir . DIRECTORY_SEPARATOR . $fileUuid . $storedExt;
                if (!@rename($optimized['output_path'], $absPath)) {
                    @copy($optimized['output_path'], $absPath);
                    @unlink($optimized['output_path']);
                }
                @unlink($tmpPath);
                $mime = (string) $optimized['mime_type'];
                $size = (int) $optimized['size'];
                $stored = $fileUuid . $storedExt;
                if ($shouldConvertToJpeg) {
                    $original = self::replaceExtension($original, 'jpg');
                }
            } else {
                $storedExtension = FileTypePolicy::storageExtension($ext);
                $storedExt = '.' . $storedExtension;
                $stored = $fileUuid . $storedExt;
                $absPath = $dir . DIRECTORY_SEPARATOR . $stored;
                if (!@rename($tmpPath, $absPath)) {
                    throw new \RuntimeException('アップロードファイルの保存に失敗しました。');
                }
                $mime = FileTypePolicy::detectMime($absPath);
                $size = filesize($absPath) ?: 0;
            }

            foreach (glob($destBase . '.opt.*') ?: [] as $junk) {
                if (is_file($junk)) {
                    @unlink($junk);
                }
            }

            return [
                'stored_path'   => $formUuid . '/' . $stored,
                'file_uuid'     => $fileUuid,
                'original_name' => $original,
                'mime_type'     => $mime,
                'size'          => $size,
            ];
        } catch (\Throwable $e) {
            if (is_file($tmpPath)) {
                @unlink($tmpPath);
            }
            foreach (glob($destBase . '.opt.*') ?: [] as $junk) {
                if (is_file($junk)) {
                    @unlink($junk);
                }
            }
            throw $e;
        }
    }

    public static function absolutePath(string $relPath): string
    {
        $rel = ltrim(str_replace(['..', "\0"], '', $relPath), '/\\');
        return UPLOADS_DIR . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
    }

    public static function delete(string $relPath): void
    {
        $abs = self::absolutePath($relPath);
        if (is_file($abs)) {
            @unlink($abs);
        }
    }

    /**
     * submission_files から参照されていない古いアップロード（確認画面で離脱したもの等）を削除する。
     * 確認画面の保持は最大 30 分のため、閾値はそれより十分長く取る。
     */
    public static function pruneOrphans(int $olderThanSeconds = 7200): void
    {
        if (!is_dir(UPLOADS_DIR)) {
            return;
        }
        $cutoff = time() - max(3600, $olderThanSeconds);
        foreach (glob(UPLOADS_DIR . DIRECTORY_SEPARATOR . '*', GLOB_ONLYDIR) ?: [] as $dir) {
            $formUuid = self::normalizeUuid(basename($dir));
            if ($formUuid === null) {
                continue;
            }
            $candidates = [];
            foreach (glob($dir . DIRECTORY_SEPARATOR . '*') ?: [] as $path) {
                if (is_file($path) && (int) filemtime($path) < $cutoff) {
                    $candidates[$formUuid . '/' . basename($path)] = $path;
                }
            }
            if ($candidates === []) {
                continue;
            }
            $rows = Database::fetchAll(
                'SELECT stored_path FROM submission_files WHERE stored_path LIKE ?',
                [$formUuid . '/%']
            );
            foreach ($rows as $row) {
                unset($candidates[(string) $row['stored_path']]);
            }
            foreach ($candidates as $path) {
                @unlink($path);
            }
        }
    }

    public static function pruneOrphansMaybe(): void
    {
        if (random_int(1, 50) !== 1) {
            return;
        }
        try {
            self::pruneOrphans();
        } catch (\Throwable $e) {
            error_log('[form-kun] uploads orphan prune failed: ' . $e->getMessage());
        }
    }

    private static function normalizeUuid(string $uuid): ?string
    {
        $uuid = strtolower(trim($uuid));
        return is_uuid_v4($uuid) ? $uuid : null;
    }

    private static function sanitizeName(string $name): string
    {
        $name = preg_replace('/[\\\\\/\x00-\x1f]/', '_', $name) ?? 'upload.bin';
        $name = preg_replace('/\s+/', '_', $name) ?? $name;
        if (strlen($name) > 200) {
            $name = substr($name, -200);
        }
        return $name;
    }

    /**
     * @param array<string, mixed>|array<int, string> $fileSettings
     * @return array{allowed_extensions:array<int,string>,selection_mode:string,convert_to_jpeg:int}
     */
    private static function normalizeFileSettings(array $fileSettings): array
    {
        if (array_keys($fileSettings) === range(0, count($fileSettings) - 1)) {
            return [
                'allowed_extensions' => \Models\FormField::parseExtensionList($fileSettings),
                'selection_mode' => \Models\FormField::FILE_SELECTION_CUSTOM,
                'convert_to_jpeg' => 0,
            ];
        }

        return [
            'allowed_extensions' => \Models\FormField::parseExtensionList($fileSettings['allowed_extensions'] ?? []),
            'selection_mode' => \Models\FormField::normalizeFileSelectionMode((string) ($fileSettings['selection_mode'] ?? \Models\FormField::FILE_SELECTION_CUSTOM)),
            'convert_to_jpeg' => !empty($fileSettings['convert_to_jpeg']) ? 1 : 0,
        ];
    }

    /**
     * @param array{allowed_extensions:array<int,string>,selection_mode:string,convert_to_jpeg:int} $fileSettings
     * @return array<int,string>
     */
    private static function allowedExtensionsForStorage(array $fileSettings): array
    {
        if (($fileSettings['selection_mode'] ?? \Models\FormField::FILE_SELECTION_CUSTOM) === \Models\FormField::FILE_SELECTION_IMAGE) {
            return \Models\FormField::imageUploadExtensions();
        }
        $allowed = $fileSettings['allowed_extensions'] ?? [];
        if ($allowed !== []) {
            return \Models\FormField::parseExtensionList($allowed);
        }
        return \Models\FormField::parseExtensionList((array) config('upload.allowed_extensions', []));
    }

    private static function isAcceptedImageUpload(string $extension, string $mime): bool
    {
        if (\Models\FormField::isImageUploadExtension($extension) && str_starts_with($mime, 'image/')) {
            return true;
        }
        return in_array($extension, ['heic', 'heif'], true) && in_array($mime, ['application/octet-stream', 'application/x-empty', 'image/heic', 'image/heif'], true);
    }

    private static function replaceExtension(string $filename, string $newExtension): string
    {
        $newExtension = ltrim(strtolower(trim($newExtension)), '.');
        $base = pathinfo($filename, PATHINFO_FILENAME);
        $base = $base !== '' ? $base : 'upload';
        return $base . '.' . $newExtension;
    }
}
