<?php
namespace Core;

/**
 * LINE Webhook の source から Push 先 ID（user / group / room）を取り出す。
 */
class LineWebhookSourceTarget
{
    /**
     * @param array<string, mixed> $source
     * @return array{type: string, id: string}|null
     */
    public static function resolveForPush(array $source): ?array
    {
        $groupId = trim((string) ($source['groupId'] ?? ''));
        if ($groupId !== '') {
            return ['type' => 'group', 'id' => $groupId];
        }

        $roomId = trim((string) ($source['roomId'] ?? ''));
        if ($roomId !== '') {
            return ['type' => 'room', 'id' => $roomId];
        }

        $sourceType = trim((string) ($source['type'] ?? ''));
        $userId = trim((string) ($source['userId'] ?? ''));
        if ($sourceType === 'user' && $userId !== '') {
            return ['type' => 'user', 'id' => $userId];
        }

        return null;
    }

    public static function normalizeTargetType(string $targetType): string
    {
        return match ($targetType) {
            'group', 'room' => $targetType,
            default => 'user',
        };
    }
}
