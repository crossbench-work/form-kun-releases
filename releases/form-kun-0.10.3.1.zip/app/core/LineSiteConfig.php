<?php
namespace Core;

use Models\AppSetting;
use Models\Form;
use Models\LineWebhookTarget;

class LineSiteConfig
{
    public static function channelSecret(): string
    {
        return trim((string) AppSetting::get(AppSetting::KEY_LINE_CHANNEL_SECRET));
    }

    public static function channelAccessToken(): string
    {
        return trim((string) AppSetting::get(AppSetting::KEY_LINE_CHANNEL_ACCESS_TOKEN));
    }

    public static function isChannelSecretConfigured(): bool
    {
        return self::channelSecret() !== '';
    }

    public static function isChannelAccessTokenConfigured(): bool
    {
        return self::channelAccessToken() !== '';
    }

    public static function webhookUrl(): string
    {
        return url('/api/line/webhook');
    }

    public static function setChannelSecret(string $value): void
    {
        AppSetting::set(AppSetting::KEY_LINE_CHANNEL_SECRET, trim($value));
    }

    public static function setChannelAccessToken(string $value): void
    {
        AppSetting::set(AppSetting::KEY_LINE_CHANNEL_ACCESS_TOKEN, trim($value));
    }

    public static function pushToId(): string
    {
        return trim((string) AppSetting::get(AppSetting::KEY_LINE_PUSH_TO_ID));
    }

    public static function isPushToIdConfigured(): bool
    {
        return self::pushToId() !== '';
    }

    public static function setPushToId(string $value): void
    {
        AppSetting::set(AppSetting::KEY_LINE_PUSH_TO_ID, trim($value));
    }

    /**
     * @return list<string>
     */
    public static function siteChecklistItemKeys(): array
    {
        return [
            Form::LINE_SETUP_CHECKLIST_CREATE_MESSAGING_API_CHANNEL,
            Form::LINE_SETUP_CHECKLIST_ENABLE_MESSAGING_API,
            Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_SECRET,
            Form::LINE_SETUP_CHECKLIST_ISSUE_CHANNEL_ACCESS_TOKEN,
            Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_ACCESS_TOKEN,
            Form::LINE_SETUP_CHECKLIST_SET_WEBHOOK_URL,
            Form::LINE_SETUP_CHECKLIST_ENABLE_WEBHOOK,
            Form::LINE_SETUP_CHECKLIST_VERIFY_WEBHOOK_URL,
            Form::LINE_SETUP_CHECKLIST_ALLOW_GROUP_MULTIPERSON_CHAT,
            Form::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP,
            Form::LINE_SETUP_CHECKLIST_SET_LINE_PUSH_TO_ID,
            Form::LINE_SETUP_CHECKLIST_LINE_TALK_NOTIFY_TEST,
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public static function siteChecklistItemDefinitions(): array
    {
        $allowed = array_fill_keys(self::siteChecklistItemKeys(), true);
        $items = [];
        foreach (Form::lineSetupChecklistAllItemDefinitions() as $item) {
            $key = (string) ($item['key'] ?? '');
            if ($key !== '' && isset($allowed[$key])) {
                $items[] = $item;
            }
        }

        return $items;
    }

    public static function siteChecklistItemIsManual(string $itemKey): bool
    {
        foreach (self::siteChecklistItemDefinitions() as $item) {
            if (($item['key'] ?? '') === $itemKey) {
                return ($item['manual_check'] ?? true) !== false;
            }
        }

        return true;
    }

    public static function isSetupComplete(): bool
    {
        $state = self::lineSetupChecklistStateForDisplay();
        foreach (self::siteChecklistItemKeys() as $key) {
            if (empty($state[$key])) {
                return false;
            }
        }

        return true;
    }

    /**
     * @return array<string, bool>
     */
    public static function lineSetupChecklistStateForDisplay(): array
    {
        $flags = [
            'line_channel_secret_configured' => self::isChannelSecretConfigured() ? 1 : 0,
            'line_channel_access_token_configured' => self::isChannelAccessTokenConfigured() ? 1 : 0,
            'line_push_to_id_configured' => self::isPushToIdConfigured() ? 1 : 0,
        ];
        $state = self::decodeLineSetupChecklist(AppSetting::get(AppSetting::KEY_LINE_SETUP_CHECKLIST));
        foreach (self::siteChecklistItemDefinitions() as $item) {
            $key = (string) ($item['key'] ?? '');
            $whenField = trim((string) ($item['auto_checked_when'] ?? ''));
            if ($key === '' || $whenField === '') {
                continue;
            }
            if (!empty($flags[$whenField])) {
                $state[$key] = true;
            } else {
                unset($state[$key]);
            }
        }
        if (LineWebhookTarget::existsForSite(['user', 'group', 'room'])) {
            $state[Form::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP] = true;
        } else {
            unset($state[Form::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP]);
        }

        return $state;
    }

    /**
     * @param list<string> $types
     */
    public static function syncLineTalkSendSetupChecklistForTypes(array $types): void
    {
        self::updateLineSetupChecklistItem(
            Form::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP,
            LineWebhookTarget::existsForSite(['user', 'group', 'room'])
        );
    }

    /**
     * @param 'line-talk-user'|'line-talk-group' $panelId
     */
    public static function syncLineTalkSendSetupChecklistForPanel(string $panelId): bool
    {
        $types = $panelId === 'line-talk-group' ? ['group', 'room'] : ['user'];
        self::syncLineTalkSendSetupChecklistForTypes($types);

        return LineWebhookTarget::existsForSite($types);
    }

    public static function updateLineSetupChecklistItem(string $itemKey, bool $checked): void
    {
        if (!in_array($itemKey, self::siteChecklistItemKeys(), true)) {
            throw new \InvalidArgumentException('Invalid LINE site setup checklist item.');
        }
        if (Form::lineSetupChecklistItemIsManual($itemKey)) {
            Form::lineSetupChecklistAssertManualCheckAllowed(
                $itemKey,
                $checked,
                self::lineSetupChecklistStateForDisplay(),
                self::siteChecklistItemDefinitions()
            );
        }
        $state = self::decodeLineSetupChecklist(AppSetting::get(AppSetting::KEY_LINE_SETUP_CHECKLIST));
        if ($checked) {
            $state[$itemKey] = true;
        } else {
            unset($state[$itemKey]);
        }
        $json = $state === [] ? '' : json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        AppSetting::set(AppSetting::KEY_LINE_SETUP_CHECKLIST, $json);
    }

    /**
     * @param mixed $raw
     * @return array<string, bool>
     */
    public static function decodeLineSetupChecklist($raw): array
    {
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
        } elseif (is_array($raw)) {
            $decoded = $raw;
        } else {
            $decoded = [];
        }
        if (!is_array($decoded)) {
            return [];
        }
        $allowed = array_fill_keys(self::siteChecklistItemKeys(), true);
        $normalized = [];
        foreach ($decoded as $key => $value) {
            $key = (string) $key;
            if (!isset($allowed[$key]) || !$value) {
                continue;
            }
            $normalized[$key] = true;
        }

        return $normalized;
    }

    /**
     * @return array<string, mixed>
     */
    public static function viewContext(): array
    {
        return [
            'line_channel_secret_configured' => self::isChannelSecretConfigured() ? 1 : 0,
            'line_channel_access_token_configured' => self::isChannelAccessTokenConfigured() ? 1 : 0,
            'line_push_to_id' => self::pushToId(),
            'line_push_to_id_configured' => self::isPushToIdConfigured() ? 1 : 0,
        ];
    }

    public static function resetAccountLink(): void
    {
        Database::transaction(function (): void {
            AppSetting::set(AppSetting::KEY_LINE_CHANNEL_SECRET, '');
            AppSetting::set(AppSetting::KEY_LINE_CHANNEL_ACCESS_TOKEN, '');
            AppSetting::set(AppSetting::KEY_LINE_PUSH_TO_ID, '');
            AppSetting::set(AppSetting::KEY_LINE_SETUP_CHECKLIST, '');
            LineWebhookTarget::deleteAll();
            Database::execute(
                'UPDATE forms SET line_notify_enabled = 0, line_setup_checklist = NULL, updated_at = ?',
                [date('Y-m-d H:i:s')]
            );
        });
    }
}
