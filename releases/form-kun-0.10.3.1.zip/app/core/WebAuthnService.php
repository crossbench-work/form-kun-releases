<?php
namespace Core;

use Cose\Algorithm\Signature\ECDSA\ES256;
use Cose\Algorithm\Signature\RSA\RS256;
use Models\UserWebauthnCredential;
use Symfony\Component\Serializer\SerializerInterface;
use Symfony\Component\Uid\Uuid;
use Webauthn\AttestationStatement\AttestationStatementSupportManager;
use Webauthn\AttestationStatement\NoneAttestationStatementSupport;
use Webauthn\AuthenticatorAssertionResponse;
use Webauthn\AuthenticatorAssertionResponseValidator;
use Webauthn\AuthenticatorAttestationResponse;
use Webauthn\AuthenticatorAttestationResponseValidator;
use Webauthn\AuthenticatorSelectionCriteria;
use Webauthn\CeremonyStep\CeremonyStepManagerFactory;
use Webauthn\CredentialRecord;
use Webauthn\Denormalizer\WebauthnSerializerFactory;
use Webauthn\PublicKeyCredential;
use Webauthn\PublicKeyCredentialCreationOptions;
use Webauthn\PublicKeyCredentialDescriptor;
use Webauthn\PublicKeyCredentialParameters;
use Webauthn\PublicKeyCredentialRequestOptions;
use Webauthn\PublicKeyCredentialRpEntity;
use Webauthn\PublicKeyCredentialUserEntity;
use Webauthn\TrustPath\EmptyTrustPath;

class WebAuthnService
{
    private const SESSION_KEY = '_webauthn_ceremony';
    private const CHALLENGE_TTL = 120;

    private SerializerInterface $serializer;
    private AuthenticatorAttestationResponseValidator $attestationValidator;
    private AuthenticatorAssertionResponseValidator $assertionValidator;

    public function __construct()
    {
        $attestationManager = AttestationStatementSupportManager::create();
        $attestationManager->add(NoneAttestationStatementSupport::create());

        $factory = new WebauthnSerializerFactory($attestationManager);
        $this->serializer = $factory->create();

        $ceremonyFactory = new CeremonyStepManagerFactory();
        $ceremonyFactory->setAllowedOrigins($this->allowedOrigins(), false);

        $this->attestationValidator = AuthenticatorAttestationResponseValidator::create(
            $ceremonyFactory->creationCeremony()
        );
        $this->assertionValidator = AuthenticatorAssertionResponseValidator::create(
            $ceremonyFactory->requestCeremony()
        );
    }

    public static function available(): bool
    {
        return is_file(PUBLIC_DIR . '/vendor/autoload.php');
    }

    public function rpId(): string
    {
        $host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
        if (str_contains($host, ':')) {
            $host = (string) parse_url('http://' . $host, PHP_URL_HOST);
        }

        return $host !== '' ? $host : 'localhost';
    }

    /** @return string[] */
    private function allowedOrigins(): array
    {
        $origins = [];
        $baseUrl = trim((string) config('site.base_url', ''));
        if ($baseUrl !== '') {
            $origins[] = rtrim($baseUrl, '/');
        }
        $scheme = (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
            || (strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https')
            ? 'https'
            : 'http';
        $origins[] = $scheme . '://' . $this->rpId();

        return array_values(array_unique($origins));
    }

    public static function userHandleFromId(int $userId): string
    {
        return pack('N', $userId);
    }

    /**
     * @param array<string, mixed> $user
     * @return array{publicKey: array<string, mixed>}
     */
    public function buildRegistrationOptions(array $user): array
    {
        $challenge = random_bytes(32);
        $this->storeCeremony($challenge, 'register', (int) $user['id'], (string) $user['username']);

        $rp = PublicKeyCredentialRpEntity::create(
            (string) config('site.admin_name', 'form-kun'),
            $this->rpId()
        );
        $displayName = (string) ($user['display_name'] ?? $user['username']);
        $userEntity = PublicKeyCredentialUserEntity::create(
            (string) $user['username'],
            self::userHandleFromId((int) $user['id']),
            $displayName !== '' ? $displayName : (string) $user['username']
        );

        $exclude = [];
        foreach (UserWebauthnCredential::listForUser((int) $user['id']) as $row) {
            $exclude[] = PublicKeyCredentialDescriptor::create(
                PublicKeyCredentialDescriptor::CREDENTIAL_TYPE_PUBLIC_KEY,
                (string) $row['credential_id'],
                $this->decodeTransports($row['transports'] ?? null)
            );
        }

        $options = PublicKeyCredentialCreationOptions::create(
            $rp,
            $userEntity,
            $challenge,
            [
                PublicKeyCredentialParameters::createPk(ES256::ID),
                PublicKeyCredentialParameters::createPk(RS256::ID),
            ],
            AuthenticatorSelectionCriteria::create(
                null,
                AuthenticatorSelectionCriteria::USER_VERIFICATION_REQUIREMENT_PREFERRED,
                AuthenticatorSelectionCriteria::RESIDENT_KEY_REQUIREMENT_DISCOURAGED
            ),
            PublicKeyCredentialCreationOptions::ATTESTATION_CONVEYANCE_PREFERENCE_NONE,
            $exclude,
            120000
        );

        return [
            'publicKey' => $this->serializer->normalize($options, 'json'),
        ];
    }

    /**
     * @param array<string, mixed> $user
     * @return array{publicKey: array<string, mixed>}|null
     */
    public function buildLoginOptions(array $user): ?array
    {
        $credentials = UserWebauthnCredential::listForUser((int) $user['id']);
        if ($credentials === []) {
            return null;
        }

        $challenge = random_bytes(32);
        $this->storeCeremony($challenge, 'login', (int) $user['id'], (string) $user['username']);

        $allow = [];
        foreach ($credentials as $row) {
            $allow[] = PublicKeyCredentialDescriptor::create(
                PublicKeyCredentialDescriptor::CREDENTIAL_TYPE_PUBLIC_KEY,
                (string) $row['credential_id'],
                $this->decodeTransports($row['transports'] ?? null)
            );
        }

        $options = PublicKeyCredentialRequestOptions::create(
            $challenge,
            $this->rpId(),
            $allow,
            PublicKeyCredentialRequestOptions::USER_VERIFICATION_REQUIREMENT_PREFERRED,
            120000
        );

        return [
            'publicKey' => $this->serializer->normalize($options, 'json'),
        ];
    }

    /**
     * @param array<string, mixed> $user
     * @param array<string, mixed> $payload
     */
    public function verifyRegistration(array $user, array $payload, ?string $credentialName): void
    {
        $ceremony = $this->consumeCeremony('register', (int) $user['id']);
        $publicKeyCredential = $this->deserializeCredential($payload);
        if (!$publicKeyCredential->response instanceof AuthenticatorAttestationResponse) {
            throw new \InvalidArgumentException('無効な登録応答です。');
        }

        $rp = PublicKeyCredentialRpEntity::create(
            (string) config('site.admin_name', 'form-kun'),
            $this->rpId()
        );
        $displayName = (string) ($user['display_name'] ?? $user['username']);
        $userEntity = PublicKeyCredentialUserEntity::create(
            (string) $user['username'],
            self::userHandleFromId((int) $user['id']),
            $displayName !== '' ? $displayName : (string) $user['username']
        );
        $options = PublicKeyCredentialCreationOptions::create(
            $rp,
            $userEntity,
            $ceremony['challenge'],
            [PublicKeyCredentialParameters::createPk(ES256::ID)],
            null,
            PublicKeyCredentialCreationOptions::ATTESTATION_CONVEYANCE_PREFERENCE_NONE
        );

        $record = $this->attestationValidator->check(
            $publicKeyCredential->response,
            $options,
            $this->rpId()
        );

        UserWebauthnCredential::insert(
            (int) $user['id'],
            $record->publicKeyCredentialId,
            $record->credentialPublicKey,
            $record->userHandle,
            $record->counter,
            $record->transports,
            $credentialName
        );
    }

    /**
     * @param array<string, mixed> $user
     * @param array<string, mixed> $payload
     */
    public function verifyLogin(array $user, array $payload): void
    {
        $ceremony = $this->consumeCeremony('login', (int) $user['id']);
        $publicKeyCredential = $this->deserializeCredential($payload);
        if (!$publicKeyCredential->response instanceof AuthenticatorAssertionResponse) {
            throw new \InvalidArgumentException('無効なログイン応答です。');
        }

        $row = UserWebauthnCredential::findByCredentialId($publicKeyCredential->rawId);
        if ($row === null || (int) $row['user_id'] !== (int) $user['id']) {
            throw new \InvalidArgumentException('登録されていないパスキーです。');
        }

        $record = $this->credentialRecordFromRow($row);
        $allow = [
            PublicKeyCredentialDescriptor::create(
                PublicKeyCredentialDescriptor::CREDENTIAL_TYPE_PUBLIC_KEY,
                (string) $row['credential_id'],
                $this->decodeTransports($row['transports'] ?? null)
            ),
        ];
        $options = PublicKeyCredentialRequestOptions::create(
            $ceremony['challenge'],
            $this->rpId(),
            $allow,
            PublicKeyCredentialRequestOptions::USER_VERIFICATION_REQUIREMENT_PREFERRED
        );

        $updated = $this->assertionValidator->check(
            $record,
            $publicKeyCredential->response,
            $options,
            $this->rpId(),
            $record->userHandle
        );

        UserWebauthnCredential::updateAfterAssertion((int) $row['id'], $updated->counter);
    }

    public function credentialRecordFromRow(array $row): CredentialRecord
    {
        return CredentialRecord::create(
            (string) $row['credential_id'],
            PublicKeyCredentialDescriptor::CREDENTIAL_TYPE_PUBLIC_KEY,
            $this->decodeTransports($row['transports'] ?? null),
            'none',
            EmptyTrustPath::create(),
            Uuid::fromString('00000000-0000-0000-0000-000000000000'),
            (string) $row['public_key'],
            (string) $row['user_handle'],
            (int) $row['sign_count']
        );
    }

    /**
     * @param array<string, mixed> $payload
     */
    private function deserializeCredential(array $payload): PublicKeyCredential
    {
        /** @var PublicKeyCredential $credential */
        $credential = $this->serializer->denormalize($payload, PublicKeyCredential::class, 'json');

        return $credential;
    }

    private function storeCeremony(string $challenge, string $purpose, int $userId, string $username): void
    {
        $_SESSION[self::SESSION_KEY] = [
            'challenge' => $challenge,
            'purpose' => $purpose,
            'user_id' => $userId,
            'username' => $username,
            'expires' => time() + self::CHALLENGE_TTL,
        ];
    }

    /** @return array{challenge: string, purpose: string, user_id: int, username: string} */
    private function consumeCeremony(string $expectedPurpose, int $expectedUserId): array
    {
        $stored = $_SESSION[self::SESSION_KEY] ?? null;
        unset($_SESSION[self::SESSION_KEY]);
        if (!is_array($stored)
            || ($stored['purpose'] ?? '') !== $expectedPurpose
            || (int) ($stored['user_id'] ?? 0) !== $expectedUserId
            || (int) ($stored['expires'] ?? 0) < time()
            || !is_string($stored['challenge'] ?? null)
            || $stored['challenge'] === ''
        ) {
            throw new \InvalidArgumentException('認証の有効期限が切れました。もう一度お試しください。');
        }

        return $stored;
    }

    /** @return string[] */
    private function decodeTransports(mixed $raw): array
    {
        if ($raw === null || $raw === '') {
            return [];
        }
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);

            return is_array($decoded) ? array_values(array_filter($decoded, 'is_string')) : [];
        }

        return [];
    }
}
