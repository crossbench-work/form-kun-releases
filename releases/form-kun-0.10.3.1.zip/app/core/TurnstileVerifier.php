<?php
namespace Core;

class TurnstileVerifier
{
    public const VALID = 'valid';
    public const INVALID = 'invalid';
    public const UNAVAILABLE = 'unavailable';
    private const VERIFY_URL = 'https://challenges.cloudflare.com/turnstile/v0/siteverify';

    public static function verify(string $secret, string $token, string $ip, string $expectedHostname): string
    {
        $secret = trim($secret);
        $token = trim($token);
        if ($secret === '' || $token === '' || strlen($token) > 2048) {
            return self::INVALID;
        }
        $payload = http_build_query([
            'secret' => $secret,
            'response' => $token,
            'remoteip' => substr($ip, 0, 45),
        ], '', '&', PHP_QUERY_RFC3986);
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/x-www-form-urlencoded\r\nAccept: application/json\r\n",
                'content' => $payload,
                'timeout' => 5,
                'ignore_errors' => true,
            ],
        ]);
        $response = @file_get_contents(self::VERIFY_URL, false, $context);
        if ($response === false) {
            error_log('[formkun] Turnstile Siteverify request failed');
            return self::UNAVAILABLE;
        }
        $status = self::responseStatus($http_response_header ?? []);
        $decoded = json_decode($response, true);
        if ($status < 200 || $status >= 300 || !is_array($decoded)) {
            error_log('[formkun] Turnstile Siteverify returned an invalid response');
            return self::UNAVAILABLE;
        }
        if (empty($decoded['success'])) {
            return self::INVALID;
        }
        $hostname = strtolower(rtrim(trim((string) ($decoded['hostname'] ?? '')), '.'));
        $expectedHostname = strtolower(rtrim(trim($expectedHostname), '.'));
        return $hostname !== '' && hash_equals($expectedHostname, $hostname)
            ? self::VALID
            : self::INVALID;
    }

    /** @param list<string> $headers */
    private static function responseStatus(array $headers): int
    {
        foreach ($headers as $header) {
            if (preg_match('/\AHTTP\/\S+\s+(\d{3})\b/i', $header, $matches)) {
                return (int) $matches[1];
            }
        }
        return 0;
    }
}
