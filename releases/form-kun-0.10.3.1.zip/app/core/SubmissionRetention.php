<?php
namespace Core;

use Models\Form;
use Models\Submission;

/**
 * 保存期間を過ぎた送信の件数確認と削除（CLI の定期処理・設定変更時の即時削除で共用）。
 * 対象は保存期間を「設定する」かつ、期間を過ぎた履歴を「削除する」にしたフォームだけ。
 */
class SubmissionRetention
{
    private const BATCH_SIZE = 500;

    /**
     * @param array<string, mixed> $form
     */
    public static function purgeTarget(array $form): bool
    {
        return Form::retentionEnabled($form) && Form::retentionDeletes($form);
    }

    /**
     * @param array<string, mixed> $form
     */
    public static function countExpired(array $form, ?int $now = null): int
    {
        if (!self::purgeTarget($form)) {
            return 0;
        }
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS c FROM submissions WHERE form_id = ? AND submitted_at < ?',
            [(int) $form['id'], Form::retentionCutoff($form, $now)]
        );
        return (int) ($row['c'] ?? 0);
    }

    /**
     * 期間を過ぎた送信を添付ファイルとともに削除し、削除件数を返す。
     *
     * @param array<string, mixed> $form
     */
    public static function purgeExpired(array $form, ?int $now = null): int
    {
        if (!self::purgeTarget($form)) {
            return 0;
        }
        $formId = (int) $form['id'];
        $cutoff = Form::retentionCutoff($form, $now);
        $deleted = 0;
        while (true) {
            $rows = Database::fetchAll(
                'SELECT id FROM submissions WHERE form_id = ? AND submitted_at < ? ORDER BY id ASC LIMIT ' . self::BATCH_SIZE,
                [$formId, $cutoff]
            );
            if ($rows === []) {
                break;
            }
            Submission::bulkDelete(array_map(static fn(array $r): int => (int) $r['id'], $rows));
            $deleted += count($rows);
            if (count($rows) < self::BATCH_SIZE) {
                break;
            }
        }
        return $deleted;
    }
}
