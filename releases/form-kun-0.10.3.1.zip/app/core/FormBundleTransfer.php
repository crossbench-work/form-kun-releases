<?php
namespace Core;

use Models\Form;
use Models\Submission;

/**
 * 1 フォーム分の設定 JSON と送信履歴 ZIP（form-kun-form-bundle v1）。
 */
class FormBundleTransfer
{
    public const FORMAT = 'form-kun-form-bundle';
    public const VERSION = 1;
    public const META_NAME = 'formkun-form-bundle.json';
    public const SETTINGS_NAME = 'formkun-form-settings.json';

    public static function exportForm(int $formId, ?FormBundleExportOptions $options = null, ?string $exportPassword = null): never
    {
        $options ??= FormBundleExportOptions::defaults();
        $exportPassword = $exportPassword !== null ? trim($exportPassword) : '';
        if ($exportPassword === '') {
            $exportPassword = null;
        }
        $form = Form::find($formId);
        if (!$form) {
            throw new \InvalidArgumentException('フォームが見つかりません。');
        }
        if (!class_exists(\ZipArchive::class)) {
            throw new \RuntimeException('サーバーが ZIP 作成に対応していません。');
        }

        $submissions = [];
        $submissionCount = 0;
        if ($options->includeSubmissions) {
            $maxRows = max(1, (int) config('submissions.export_max_rows', 10000));
            $search = Submission::searchForExport($formId, null, null, null, null, $maxRows);
            $total = (int) $search['total'];
            if ($total > $maxRows) {
                throw new \InvalidArgumentException(
                    '送信が ' . number_format($total) . ' 件あり、一度にエクスポートできる上限（'
                    . number_format($maxRows) . ' 件）を超えています。'
                );
            }
            $submissions = $search['rows'];
            $submissionCount = count($submissions);
        }

        $zipPath = tempnam(sys_get_temp_dir(), 'fk-form-bundle-');
        if ($zipPath === false) {
            throw new \RuntimeException('ZIP を作成できませんでした。');
        }

        try {
            $zip = new \ZipArchive();
            if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
                throw new \RuntimeException('ZIP を作成できません。');
            }

            $zip->addFromString(self::SETTINGS_NAME, FormSettingsTransfer::exportFormSettingsFile($formId, $options));

            if ($submissionCount > 0) {
                $entries = [];
                $mailOnlyIds = [];
                if ($options->includeAttachmentFiles) {
                    ['entries' => $entries, 'total_bytes' => $totalBytes, 'mail_only_ids' => $mailOnlyIds] = SubmissionArchive::zipEntries($submissions);
                    if ($totalBytes > SubmissionArchive::maxZipAttachmentBytes()) {
                        throw new \InvalidArgumentException(
                            '添付ファイルの合計が、一度にエクスポートできる上限を超えています。'
                        );
                    }
                } else {
                    foreach ($submissions as $submission) {
                        if (Submission::isMailOnlyMetadata($submission)) {
                            $mailOnlyIds[(int) $submission['id']] = true;
                        }
                    }
                }
                $zip->addFromString(
                    SubmissionArchive::MANIFEST_NAME,
                    SubmissionArchive::exportManifestJson($formId, $submissions, $entries, $mailOnlyIds)
                );
                if ($options->includeAttachmentFiles) {
                    foreach ($entries as $entry) {
                        $zip->addFile($entry['abs'], $entry['name']);
                    }
                }
            }

            $hasEncryptedSecrets = false;
            if ($exportPassword !== null) {
                $zip->addFromString(
                    FormBundleSecretVault::FILE_NAME,
                    FormBundleSecretVault::encryptPayload(
                        FormBundleSecretVault::collectPayload($formId, $options),
                        $exportPassword
                    )
                );
                $hasEncryptedSecrets = true;
            }

            $meta = [
                'format' => self::FORMAT,
                'version' => self::VERSION,
                'exported_at' => date(DATE_ATOM),
                'form_title' => (string) ($form['title'] ?? ''),
                'submission_count' => $submissionCount,
                'export_options' => $options->toMetaArray(),
            ];
            if ($hasEncryptedSecrets) {
                $meta['has_encrypted_secrets'] = true;
            }
            $metaJson = json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (!is_string($metaJson)) {
                throw new \RuntimeException('メタデータを生成できませんでした。');
            }
            $zip->addFromString(self::META_NAME, $metaJson);

            if (!$zip->close()) {
                throw new \RuntimeException('ZIP の書き込みに失敗しました。');
            }

            $slug = preg_replace('/[^\w\-]+/', '-', (string) ($form['slug'] ?? 'form')) ?: 'form';
            $filename = 'form-kun-' . $slug . '-' . date('Ymd-His') . '.zip';

            while (ob_get_level() > 0) {
                ob_end_clean();
            }
            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Content-Length: ' . (string) filesize($zipPath));
            header('X-Content-Type-Options: nosniff');
            readfile($zipPath);
        } finally {
            @unlink($zipPath);
        }
        exit;
    }

    /**
     * @return array{form_id: int, imported_submissions: int, skipped_submissions: int, failed_submissions: int, secrets_restored: bool, has_encrypted_secrets: bool}
     */
    public static function importZip(string $zipPath, int $availableSlots, ?array $actor = null, ?string $importPassword = null): array
    {
        if (!class_exists(\ZipArchive::class)) {
            throw new \InvalidArgumentException('サーバーが ZIP に対応していません。');
        }

        $zip = new \ZipArchive();
        if ($zip->open($zipPath, \ZipArchive::RDONLY) !== true) {
            throw new \InvalidArgumentException('ZIP ファイルを開けません。');
        }
        try {
            $settingsStat = $zip->statName(self::SETTINGS_NAME);
            if ($settingsStat === false) {
                throw new \InvalidArgumentException(
                    'フォーム設定（' . self::SETTINGS_NAME . '）が見つかりません。フォーム一覧からエクスポートした ZIP を指定してください。'
                );
            }
            if ((int) $settingsStat['size'] > FormSettingsTransfer::MAX_FILE_BYTES) {
                throw new \InvalidArgumentException('フォーム設定が大きすぎます。');
            }
            $settingsJson = $zip->getFromName(self::SETTINGS_NAME);
            if (!is_string($settingsJson)) {
                throw new \InvalidArgumentException('フォーム設定を読み込めませんでした。');
            }
            $hasManifest = $zip->statName(SubmissionArchive::MANIFEST_NAME) !== false;
        } finally {
            $zip->close();
        }

        if ($availableSlots < 1) {
            throw new \InvalidArgumentException('フォームの作成上限に達しているため、インポートできません。');
        }

        $secretsJson = FormBundleSecretVault::readFromZip($zipPath);
        $secretPayload = null;
        $hasEncryptedSecrets = $secretsJson !== null;
        if ($hasEncryptedSecrets) {
            $pwd = $importPassword !== null ? trim($importPassword) : '';
            if ($pwd === '') {
                throw new \InvalidArgumentException(
                    'この ZIP には暗号化された秘密情報が含まれています。インポート用パスワードを入力してください。'
                );
            }
            $secretPayload = FormBundleSecretVault::decryptEnvelope($secretsJson, $pwd);
        }

        $archive = null;
        if ($hasManifest) {
            $maxRows = max(1, (int) config('submissions.export_max_rows', 10000));
            $archive = SubmissionArchive::read($zipPath, $maxRows);
        }

        $formResult = FormSettingsTransfer::importJson($settingsJson, 1, $actor);
        $formId = (int) ($formResult['ids'][0] ?? 0);
        if ($formId <= 0) {
            throw new \RuntimeException('フォームを作成できませんでした。');
        }

        $importedSubmissions = 0;
        $skippedSubmissions = 0;
        $failedSubmissions = 0;

        if ($archive !== null) {
            $form = Form::find($formId);
            if (!$form) {
                throw new \RuntimeException('作成したフォームが見つかりません。');
            }
            $subResult = SubmissionArchive::import($zipPath, $archive, $form);
            $importedSubmissions = (int) $subResult['imported'];
            $skippedSubmissions = (int) $subResult['skipped'];
            $failedSubmissions = (int) $subResult['failed'];
        }

        $secretsRestored = false;
        if ($secretPayload !== null) {
            FormBundleSecretVault::applyToForm($formId, $secretPayload);
            $secretsRestored = true;
        }

        return [
            'form_id' => $formId,
            'imported_submissions' => $importedSubmissions,
            'skipped_submissions' => $skippedSubmissions,
            'failed_submissions' => $failedSubmissions,
            'secrets_restored' => $secretsRestored,
            'has_encrypted_secrets' => $hasEncryptedSecrets,
        ];
    }
}
