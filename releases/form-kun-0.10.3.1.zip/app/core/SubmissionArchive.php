<?php
namespace Core;

use Models\Form;
use Models\FormField;
use Models\Submission;

/**
 * 送信履歴エクスポート ZIP（復元用 JSON 同梱）の読み込み・検証・インポート。
 * ZIP は展開せず、JSON に書かれたエントリだけをストリームで読む。
 */
class SubmissionArchive
{
    public const FORMAT = 'form-kun-submissions';
    public const VERSION = 1;
    public const MANIFEST_NAME = 'formkun-export.json';
    private const MANIFEST_MAX_BYTES = 200 * 1024 * 1024;

    /**
     * ZIP を開いて復元用 JSON を検証し、正規化したデータを返す。
     *
     * @return array{source: array{id:int, title:string, public_uuid:string}, exported_at:string, fields: list<array{field_key:string, type:string, label:string}>, submissions: list<array<string, mixed>>}
     */
    public static function read(string $zipPath, int $maxRows): array
    {
        if (!class_exists(\ZipArchive::class)) {
            throw new \RuntimeException('サーバーが ZIP に対応していないため、インポートできません。');
        }
        $zip = new \ZipArchive();
        if ($zip->open($zipPath, \ZipArchive::RDONLY) !== true) {
            throw new \RuntimeException('ZIP ファイルを開けません。');
        }
        try {
            $stat = $zip->statName(self::MANIFEST_NAME);
            if ($stat === false) {
                throw new \RuntimeException('復元用データ（' . self::MANIFEST_NAME . '）が見つかりません。「添付ファイルも含める（ZIP）」でエクスポートしたファイルを指定してください。');
            }
            if ((int) $stat['size'] > self::MANIFEST_MAX_BYTES) {
                throw new \RuntimeException('復元用データが大きすぎます。');
            }
            $json = $zip->getFromName(self::MANIFEST_NAME);
            $data = is_string($json) ? json_decode($json, true) : null;
            if (!is_array($data) || ($data['format'] ?? null) !== self::FORMAT) {
                throw new \RuntimeException('復元用データの形式が正しくありません。');
            }
            if ((int) ($data['version'] ?? 0) !== self::VERSION) {
                throw new \RuntimeException('対応していない復元用データのバージョンです。');
            }
            $items = $data['submissions'] ?? null;
            if (!is_array($items) || !array_is_list($items)) {
                throw new \RuntimeException('復元用データに送信の一覧がありません。');
            }
            if ($items === []) {
                throw new \RuntimeException('インポートできる送信がありません。');
            }
            if (count($items) > $maxRows) {
                throw new \RuntimeException('送信が ' . number_format(count($items)) . ' 件あり、一度にインポートできる上限（' . number_format($maxRows) . ' 件）を超えています。');
            }

            $submissions = [];
            foreach ($items as $i => $item) {
                $submissions[] = self::normalizeSubmission($item, $i + 1, $zip);
            }

            $fields = [];
            foreach ((array) ($data['fields'] ?? []) as $field) {
                if (is_array($field) && is_string($field['field_key'] ?? null)) {
                    $fields[] = [
                        'field_key' => (string) $field['field_key'],
                        'type' => (string) ($field['type'] ?? ''),
                        'label' => (string) ($field['label'] ?? ''),
                    ];
                }
            }
            $form = is_array($data['form'] ?? null) ? $data['form'] : [];

            return [
                'source' => [
                    'id' => (int) ($form['id'] ?? 0),
                    'title' => mb_substr((string) ($form['title'] ?? ''), 0, 200),
                    'public_uuid' => strtolower((string) ($form['public_uuid'] ?? '')),
                ],
                'exported_at' => (string) ($data['exported_at'] ?? ''),
                'fields' => $fields,
                'submissions' => $submissions,
            ];
        } finally {
            $zip->close();
        }
    }

    /**
     * @param mixed $item
     * @return array<string, mixed>
     */
    private static function normalizeSubmission($item, int $no, \ZipArchive $zip): array
    {
        $fail = static function (string $message) use ($no): never {
            throw new \RuntimeException($no . ' 件目の送信: ' . $message);
        };
        if (!is_array($item)) {
            $fail('形式が正しくありません。');
        }
        $submittedAt = (string) ($item['submitted_at'] ?? '');
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d H:i:s', $submittedAt);
        if ($date === false || $date->format('Y-m-d H:i:s') !== $submittedAt) {
            $fail('受信日時が正しくありません。');
        }
        $status = (string) ($item['workflow_status'] ?? Submission::WORKFLOW_PENDING);
        if (!Submission::isValidWorkflowStatus($status)) {
            $fail('状態が正しくありません。');
        }
        $storageMode = (string) ($item['storage_mode'] ?? Submission::STORAGE_DATABASE);
        if (!in_array($storageMode, [Submission::STORAGE_DATABASE, Submission::STORAGE_MAIL_ONLY], true)) {
            $fail('保存方式が正しくありません。');
        }

        $values = [];
        $rawValues = $item['values'] ?? [];
        if (is_object($rawValues)) {
            $rawValues = (array) $rawValues;
        }
        if (!is_array($rawValues)) {
            $fail('入力値の形式が正しくありません。');
        }
        foreach ($rawValues as $key => $value) {
            $key = (string) $key;
            if ($key === '' || strlen($key) > 191 || (!is_string($value) && !is_int($value) && !is_float($value) && $value !== null)) {
                $fail('入力値の形式が正しくありません。');
            }
            $values[$key] = (string) ($value ?? '');
        }

        $files = [];
        $rawFiles = $item['files'] ?? [];
        if (!is_array($rawFiles)) {
            $fail('添付ファイルの形式が正しくありません。');
        }
        foreach ($rawFiles as $file) {
            if (!is_array($file) || !is_string($file['field_key'] ?? null) || $file['field_key'] === '') {
                $fail('添付ファイルの形式が正しくありません。');
            }
            $path = $file['path'] ?? null;
            $size = null;
            if ($path !== null) {
                if (!is_string($path) || !self::isSafeEntryPath($path)) {
                    $fail('添付ファイルのパスが正しくありません。');
                }
                $stat = $zip->statName($path);
                if ($stat === false) {
                    $fail('添付ファイル（' . $path . '）が ZIP 内に見つかりません。');
                }
                $size = (int) $stat['size'];
            }
            $files[] = [
                'field_key' => (string) $file['field_key'],
                'original_name' => mb_substr(trim(preg_replace('/[\\\\\/\x00-\x1f\x7f]/', '_', (string) ($file['original_name'] ?? '')) ?? '') ?: 'file', 0, 200),
                'mime_type' => isset($file['mime_type']) ? mb_substr((string) $file['mime_type'], 0, 100) : null,
                'stored_ext' => is_string($file['stored_ext'] ?? null) && preg_match('/\A[a-z0-9]{1,10}\z/', strtolower($file['stored_ext'])) === 1
                    ? strtolower($file['stored_ext'])
                    : null,
                'path' => $path,
                'size' => $size,
            ];
        }

        return [
            'id' => (int) ($item['id'] ?? 0),
            'submitted_at' => $submittedAt,
            'workflow_status' => $status,
            'storage_mode' => $storageMode,
            'ip' => mb_substr((string) ($item['ip'] ?? ''), 0, 45),
            'user_agent' => mb_substr((string) ($item['user_agent'] ?? ''), 0, 255),
            'delivery_route' => isset($item['delivery_route']) ? mb_substr((string) $item['delivery_route'], 0, 16) : null,
            'mail_delivery_status' => isset($item['mail_delivery_status']) ? mb_substr((string) $item['mail_delivery_status'], 0, 16) : null,
            'mail_error_code' => isset($item['mail_error_code']) ? mb_substr((string) $item['mail_error_code'], 0, 64) : null,
            'attachment_count' => max(0, (int) ($item['attachment_count'] ?? 0)),
            'attachment_total_bytes' => max(0, (int) ($item['attachment_total_bytes'] ?? 0)),
            'values' => $values,
            'files' => $files,
        ];
    }

    private static function isSafeEntryPath(string $path): bool
    {
        if (!str_starts_with($path, 'files/') || strlen($path) > 512) {
            return false;
        }
        if (str_contains($path, '\\') || str_contains($path, "\0") || preg_match('/[\x00-\x1f\x7f]/', $path) === 1) {
            return false;
        }
        foreach (explode('/', $path) as $segment) {
            if ($segment === '' || $segment === '.' || $segment === '..') {
                return false;
            }
        }
        return true;
    }

    /**
     * 現在のフォームと照合した結果（重複・取り込まない項目・警告）を返す。
     *
     * @param array<string, mixed> $archive read() の戻り値
     * @param array<string, mixed> $form
     * @return array{duplicates: array<int, true>, unknown_keys: list<string>, warnings: list<string>, file_count:int, file_bytes:int}
     */
    public static function analyze(array $archive, array $form): array
    {
        $formId = (int) $form['id'];
        $known = [];
        foreach (FormField::orderedSubmittableForForm($formId, true) as $field) {
            $known[(string) $field['field_key']] = true;
        }

        $unknown = [];
        $fileCount = 0;
        $fileBytes = 0;
        foreach ($archive['submissions'] as $submission) {
            foreach (array_keys($submission['values']) as $key) {
                if (!isset($known[$key])) {
                    $unknown[$key] = true;
                }
            }
            foreach ($submission['files'] as $file) {
                if (!isset($known[$file['field_key']])) {
                    $unknown[$file['field_key']] = true;
                }
                if ($file['path'] !== null) {
                    $fileCount++;
                    $fileBytes += (int) $file['size'];
                }
            }
        }

        $warnings = [];
        $sourceUuid = (string) ($archive['source']['public_uuid'] ?? '');
        if ($sourceUuid !== '' && $sourceUuid !== strtolower((string) ($form['public_uuid'] ?? ''))) {
            $warnings[] = '別のフォーム（' . ($archive['source']['title'] !== '' ? $archive['source']['title'] : '不明') . '）からエクスポートされたデータです。項目キーが一致する値だけを取り込みます。';
        }

        return [
            'duplicates' => self::duplicateIndexes($formId, $archive['submissions']),
            'unknown_keys' => array_keys($unknown),
            'warnings' => $warnings,
            'file_count' => $fileCount,
            'file_bytes' => $fileBytes,
        ];
    }

    /**
     * 同じフォームに受信日時・IP・User-Agent が一致する送信がある行（0 始まりの添字）。
     *
     * @param list<array<string, mixed>> $submissions
     * @return array<int, true>
     */
    private static function duplicateIndexes(int $formId, array $submissions): array
    {
        $times = array_values(array_unique(array_map(static fn(array $s): string => $s['submitted_at'], $submissions)));
        $existing = [];
        foreach (array_chunk($times, 500) as $chunk) {
            $in = implode(',', array_fill(0, count($chunk), '?'));
            $rows = Database::fetchAll(
                "SELECT submitted_at, ip, user_agent FROM submissions WHERE form_id = ? AND submitted_at IN ($in)",
                array_merge([$formId], $chunk)
            );
            foreach ($rows as $row) {
                $existing[self::identity((string) $row['submitted_at'], (string) $row['ip'], (string) $row['user_agent'])] = true;
            }
        }

        $duplicates = [];
        $seen = [];
        foreach ($submissions as $i => $submission) {
            $identity = self::identity($submission['submitted_at'], $submission['ip'], $submission['user_agent']);
            if (isset($existing[$identity]) || isset($seen[$identity])) {
                $duplicates[$i] = true;
            }
            $seen[$identity] = true;
        }
        return $duplicates;
    }

    private static function identity(string $submittedAt, string $ip, string $userAgent): string
    {
        return $submittedAt . "\n" . $ip . "\n" . $userAgent;
    }

    /**
     * 重複を除いて DB に登録する。送信ごとに 1 トランザクションで、失敗した送信の添付は削除する。
     *
     * @param array<string, mixed> $archive
     * @param array<string, mixed> $form
     * @return array{imported:int, skipped:int, failed:int}
     */
    public static function import(string $zipPath, array $archive, array $form): array
    {
        $analysis = self::analyze($archive, $form);
        if (SiteResource::wouldExceedWithAdditionalBytes($analysis['file_bytes'])) {
            throw new \RuntimeException('サイトの利用容量が上限を超えるため、インポートできません。');
        }

        $zip = new \ZipArchive();
        if ($zip->open($zipPath, \ZipArchive::RDONLY) !== true) {
            throw new \RuntimeException('ZIP ファイルを開けません。');
        }

        $formId = (int) $form['id'];
        $formUuid = Form::requirePublicUuid($form);
        $known = [];
        foreach (FormField::orderedSubmittableForForm($formId, true) as $field) {
            $known[(string) $field['field_key']] = true;
        }

        $imported = 0;
        $skipped = 0;
        $failed = 0;
        try {
            foreach ($archive['submissions'] as $i => $submission) {
                if (isset($analysis['duplicates'][$i])) {
                    $skipped++;
                    continue;
                }
                $storedPaths = [];
                try {
                    $fileMetas = [];
                    if ($submission['storage_mode'] !== Submission::STORAGE_MAIL_ONLY) {
                        foreach ($submission['files'] as $file) {
                            if ($file['path'] === null || !isset($known[$file['field_key']])) {
                                continue;
                            }
                            $meta = self::storeEntry($zip, $file, $formUuid);
                            $storedPaths[] = $meta['stored_path'];
                            $fileMetas[] = $meta;
                        }
                    }
                    self::insertSubmission($formId, $submission, $known, $fileMetas);
                    $imported++;
                } catch (\Throwable $e) {
                    foreach ($storedPaths as $path) {
                        FileStorage::delete($path);
                    }
                    error_log('[form-kun] submission import failed: ' . $e->getMessage());
                    $failed++;
                }
            }
        } finally {
            $zip->close();
        }

        return ['imported' => $imported, 'skipped' => $skipped, 'failed' => $failed];
    }

    /**
     * @param array<string, mixed> $submission
     * @param array<string, true> $known
     * @param list<array<string, mixed>> $fileMetas
     */
    private static function insertSubmission(int $formId, array $submission, array $known, array $fileMetas): void
    {
        Database::transaction(function () use ($formId, $submission, $known, $fileMetas) {
            Database::execute(
                'INSERT INTO submissions (
                    form_id, ip, user_agent, submitted_at, workflow_status, storage_mode, delivery_route,
                    mail_delivery_status, mail_error_code, attachment_count, attachment_total_bytes
                 ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                [
                    $formId,
                    $submission['ip'],
                    $submission['user_agent'],
                    $submission['submitted_at'],
                    $submission['workflow_status'],
                    $submission['storage_mode'],
                    $submission['delivery_route'],
                    $submission['mail_delivery_status'],
                    $submission['mail_error_code'],
                    $submission['attachment_count'],
                    $submission['attachment_total_bytes'],
                ]
            );
            $sid = Database::lastInsertId();

            if ($submission['storage_mode'] === Submission::STORAGE_MAIL_ONLY) {
                return;
            }
            foreach ($submission['values'] as $key => $value) {
                if (!isset($known[$key])) {
                    continue;
                }
                Database::execute(
                    'INSERT INTO submission_values (submission_id, field_key, value) VALUES (?, ?, ?)',
                    [$sid, $key, $value]
                );
            }
            foreach ($fileMetas as $meta) {
                Database::execute(
                    'INSERT INTO submission_files (submission_id, field_key, file_uuid, original_name, stored_path, mime_type, size)
                     VALUES (?,?,?,?,?,?,?)',
                    [$sid, $meta['field_key'], $meta['file_uuid'], $meta['original_name'], $meta['stored_path'], $meta['mime_type'], $meta['size']]
                );
            }
        });
    }

    /**
     * ZIP 内の添付を uploads/{form_uuid}/{file_uuid}.{ext} にコピーする。拡張子と内容が一致しないものや未知の拡張子は .bin で保存する。
     *
     * @param array<string, mixed> $file
     * @return array{field_key:string, file_uuid:string, original_name:string, stored_path:string, mime_type:string, size:int}
     */
    private static function storeEntry(\ZipArchive $zip, array $file, string $formUuid): array
    {
        $stream = $zip->getStream((string) $file['path']);
        if ($stream === false) {
            throw new \RuntimeException('ZIP 内の添付ファイルを読めません: ' . $file['path']);
        }

        $dir = UPLOADS_DIR . DIRECTORY_SEPARATOR . $formUuid;
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            fclose($stream);
            throw new \RuntimeException('uploads ディレクトリを作成できません。');
        }

        $fileUuid = \uuid_v4();
        $tmpPath = $dir . DIRECTORY_SEPARATOR . $fileUuid . '.upload';
        $out = fopen($tmpPath, 'wb');
        if ($out === false) {
            fclose($stream);
            throw new \RuntimeException('添付ファイルを保存できません。');
        }
        $copied = stream_copy_to_stream($stream, $out);
        fclose($stream);
        fclose($out);
        if ($copied === false) {
            @unlink($tmpPath);
            throw new \RuntimeException('添付ファイルを保存できません。');
        }

        $originalName = (string) $file['original_name'];
        $detectedMime = FileTypePolicy::detectMime($tmpPath);
        $manifestMime = isset($file['mime_type']) ? trim((string) $file['mime_type']) : '';
        if ($manifestMime === '') {
            $manifestMime = null;
        }
        $storedExtHint = isset($file['stored_ext']) && is_string($file['stored_ext']) ? $file['stored_ext'] : null;
        $resolved = self::resolveImportStoredFile($originalName, $detectedMime, $manifestMime, $storedExtHint);
        $stored = $fileUuid . '.' . $resolved['stored_ext'];
        if (!@rename($tmpPath, $dir . DIRECTORY_SEPARATOR . $stored)) {
            @unlink($tmpPath);
            throw new \RuntimeException('添付ファイルを保存できません。');
        }

        return [
            'field_key' => (string) $file['field_key'],
            'file_uuid' => $fileUuid,
            'original_name' => $originalName,
            'stored_path' => $formUuid . '/' . $stored,
            'mime_type' => $resolved['mime'],
            'size' => (int) $copied,
        ];
    }

    /**
     * インポート時の保存拡張子と MIME。
     * 元の保存拡張子 → 元ファイル名の拡張子 → MIME からの逆引きの順に、検出 MIME か manifest MIME と整合するものを採用する。
     *
     * @return array{stored_ext: string, mime: string}
     */
    private static function resolveImportStoredFile(string $originalName, string $detectedMime, ?string $manifestMime, ?string $storedExtHint = null): array
    {
        $candidates = [];
        foreach ([
            $storedExtHint,
            strtolower(pathinfo($originalName, PATHINFO_EXTENSION)),
            FileTypePolicy::extensionForMime($detectedMime),
            $manifestMime !== null ? FileTypePolicy::extensionForMime($manifestMime) : null,
        ] as $ext) {
            $ext = strtolower(trim((string) $ext));
            if ($ext !== '' && FileTypePolicy::isKnownExtension($ext) && !in_array($ext, $candidates, true)) {
                $candidates[] = $ext;
            }
        }

        foreach ($candidates as $ext) {
            if (FileTypePolicy::isMimeAllowedForExtension($ext, $detectedMime)) {
                return ['stored_ext' => FileTypePolicy::storageExtension($ext), 'mime' => $detectedMime];
            }
        }
        if ($manifestMime !== null && $manifestMime !== '') {
            foreach ($candidates as $ext) {
                if (FileTypePolicy::isMimeAllowedForExtension($ext, $manifestMime)) {
                    return ['stored_ext' => FileTypePolicy::storageExtension($ext), 'mime' => $manifestMime];
                }
            }
        }

        return ['stored_ext' => 'bin', 'mime' => $detectedMime];
    }

    /**
     * ZIP に入れる添付と ZIP 内の名前を決める。サーバー上にないファイルと SMTP メールのみモードの送信は含めない。
     *
     * @param array<int, array<string, mixed>> $submissions
     * @return array{entries: array<int, array{abs:string, name:string}>, total_bytes:int, mail_only_ids: array<int, true>}
     */
    public static function zipEntries(array $submissions): array
    {
        $submissionIds = array_map(static fn(array $submission): int => (int) $submission['id'], $submissions);
        $mailOnlyIds = [];
        foreach ($submissions as $submission) {
            if (Submission::isMailOnlyMetadata($submission)) {
                $mailOnlyIds[(int) $submission['id']] = true;
            }
        }

        $entries = [];
        $usedNames = [];
        $totalBytes = 0;
        foreach (Submission::filesGroupedBySubmission($submissionIds) as $submissionId => $filesByKey) {
            if (isset($mailOnlyIds[(int) $submissionId])) {
                continue;
            }
            foreach ($filesByKey as $fieldKey => $files) {
                foreach ($files as $file) {
                    $abs = FileStorage::absolutePath((string) ($file['stored_path'] ?? ''));
                    if (!is_file($abs)) {
                        continue;
                    }
                    $name = 'files/' . (int) $submissionId . '/'
                        . self::zipSafeName((string) $fieldKey . '_' . (string) ($file['original_name'] ?? 'file'));
                    $candidate = $name;
                    for ($n = 2; isset($usedNames[$candidate]); $n++) {
                        $ext = pathinfo($name, PATHINFO_EXTENSION);
                        $candidate = $ext !== ''
                            ? substr($name, 0, -strlen($ext) - 1) . '_' . $n . '.' . $ext
                            : $name . '_' . $n;
                    }
                    $usedNames[$candidate] = true;
                    $entries[(int) $file['id']] = ['abs' => $abs, 'name' => $candidate];
                    $totalBytes += (int) (filesize($abs) ?: 0);
                }
            }
        }

        return ['entries' => $entries, 'total_bytes' => $totalBytes, 'mail_only_ids' => $mailOnlyIds];
    }

    /**
     * インポート用の復元データ（JSON）。値は DB の生の値、状態は内部コードのまま入れる。
     *
     * @param array<int, array<string, mixed>> $submissions
     * @param array<int, array{abs:string, name:string}> $entries
     * @param array<int, true> $mailOnlyIds
     */
    public static function exportManifestJson(int $formId, array $submissions, array $entries, array $mailOnlyIds): string
    {
        $form = Form::find($formId) ?? [];
        $submissionIds = array_map(static fn(array $s): int => (int) $s['id'], $submissions);
        $valuesBySubmission = Submission::valuesGroupedBySubmission($submissionIds);
        $filesBySubmission = Submission::filesGroupedBySubmission($submissionIds);

        $items = [];
        foreach ($submissions as $submission) {
            $sid = (int) $submission['id'];
            $files = [];
            if (!isset($mailOnlyIds[$sid])) {
                foreach ($filesBySubmission[$sid] ?? [] as $fieldKey => $fieldFiles) {
                    foreach ($fieldFiles as $file) {
                        $entry = $entries[(int) $file['id']] ?? null;
                        $mimeType = $file['mime_type'] !== null ? (string) $file['mime_type'] : null;
                        if (($mimeType === null || $mimeType === '') && is_array($entry)) {
                            $abs = FileStorage::absolutePath((string) ($file['stored_path'] ?? ''));
                            if (is_file($abs)) {
                                $mimeType = FileTypePolicy::detectMime($abs);
                            }
                        }
                        $files[] = [
                            'field_key' => (string) $fieldKey,
                            'original_name' => (string) ($file['original_name'] ?? ''),
                            'mime_type' => $mimeType !== null && $mimeType !== '' ? $mimeType : null,
                            'size' => $file['size'] !== null ? (int) $file['size'] : null,
                            'stored_ext' => strtolower(pathinfo((string) ($file['stored_path'] ?? ''), PATHINFO_EXTENSION)) ?: null,
                            'path' => $entry['name'] ?? null,
                        ];
                    }
                }
            }
            $items[] = [
                'id' => $sid,
                'submitted_at' => (string) ($submission['submitted_at'] ?? ''),
                'workflow_status' => (string) ($submission['workflow_status'] ?? Submission::WORKFLOW_PENDING),
                'storage_mode' => (string) ($submission['storage_mode'] ?? Submission::STORAGE_DATABASE),
                'ip' => (string) ($submission['ip'] ?? ''),
                'user_agent' => (string) ($submission['user_agent'] ?? ''),
                'delivery_route' => $submission['delivery_route'] ?? null,
                'mail_delivery_status' => $submission['mail_delivery_status'] ?? null,
                'mail_error_code' => $submission['mail_error_code'] ?? null,
                'attachment_count' => (int) ($submission['attachment_count'] ?? 0),
                'attachment_total_bytes' => (int) ($submission['attachment_total_bytes'] ?? 0),
                'values' => (object) ($valuesBySubmission[$sid] ?? []),
                'files' => $files,
            ];
        }

        $fields = array_map(static fn(array $f): array => [
            'field_key' => (string) ($f['field_key'] ?? ''),
            'type' => (string) ($f['type'] ?? ''),
            'label' => (string) ($f['label'] ?? ''),
        ], FormField::orderedSubmittableForForm($formId, true));

        return (string) json_encode([
            'format' => self::FORMAT,
            'version' => self::VERSION,
            'exported_at' => date('Y-m-d H:i:s'),
            'form' => [
                'id' => $formId,
                'title' => (string) ($form['title'] ?? ''),
                'public_uuid' => (string) ($form['public_uuid'] ?? ''),
            ],
            'fields' => $fields,
            'submissions' => $items,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }

    public static function maxZipAttachmentBytes(): int
    {
        return max(1, (int) config('submissions.export_max_attachment_bytes', 500 * 1024 * 1024));
    }

    /**
     * ZIP 内のファイル名に使えない文字（区切り文字・制御文字・先頭のドット等）を置き換える。
     */
    private static function zipSafeName(string $name): string
    {
        $name = preg_replace('/[\x00-\x1f\x7f\/\\\\:*?"<>|]/u', '_', $name) ?? 'file';
        $name = ltrim(str_replace('..', '_', $name), '. ');
        if ($name === '') {
            $name = 'file';
        }

        return mb_strimwidth($name, 0, 180, '', 'UTF-8');
    }
}
