(function () {
  'use strict';

  var base = typeof window.FORMKUN_BASE === 'string' ? window.FORMKUN_BASE : '';
  var csrf = typeof window.FORMKUN_CSRF === 'string' ? window.FORMKUN_CSRF : '';

  function adminPath(path) {
    if (!path.startsWith('/')) path = '/' + path;
    return base + path;
  }

  function showMessage(el, text) {
    if (!el) return;
    if (!text) {
      el.hidden = true;
      el.textContent = '';
      return;
    }
    el.hidden = false;
    el.textContent = text;
  }

  function postJson(url, payload) {
    return fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        'X-CSRF-Token': csrf,
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: JSON.stringify(Object.assign({ _token: csrf }, payload || {})),
    }).then(function (res) {
      return res.json().then(function (data) {
        if (!res.ok) {
          var err = new Error((data && data.error) || 'リクエストに失敗しました。');
          err.status = res.status;
          throw err;
        }
        return data;
      });
    });
  }

  function parseCreationOptions(json) {
    if (typeof PublicKeyCredential !== 'undefined' && typeof PublicKeyCredential.parseCreationOptionsFromJSON === 'function') {
      return PublicKeyCredential.parseCreationOptionsFromJSON(json);
    }
    throw new Error('このブラウザはパスキーに対応していません。');
  }

  function parseRequestOptions(json) {
    if (typeof PublicKeyCredential !== 'undefined' && typeof PublicKeyCredential.parseRequestOptionsFromJSON === 'function') {
      return PublicKeyCredential.parseRequestOptionsFromJSON(json);
    }
    throw new Error('このブラウザはパスキーに対応していません。');
  }

  function credentialToJson(credential) {
    if (typeof credential.toJSON === 'function') {
      return credential.toJSON();
    }
    throw new Error('パスキーの応答を処理できません。');
  }

  function initLogin() {
    var btn = document.querySelector('[data-admin-webauthn="login"]');
    if (!btn) return;

    var usernameInputId = btn.getAttribute('data-username-input') || 'username';
    var usernameEl = document.getElementById(usernameInputId);
    var messageEl = document.querySelector('[data-admin-webauthn-message]');

    btn.addEventListener('click', function () {
      showMessage(messageEl, '');
      if (!window.PublicKeyCredential) {
        showMessage(messageEl, 'このブラウザはパスキーに対応していません。');
        return;
      }
      var username = usernameEl ? String(usernameEl.value || '').trim() : '';
      if (!username) {
        showMessage(messageEl, 'ログインIDを入力してください。');
        if (usernameEl) usernameEl.focus();
        return;
      }

      btn.disabled = true;
      postJson(adminPath('/admin/webauthn/login/options'), { username: username })
        .then(function (data) {
          var options = parseRequestOptions(data.publicKey);
          return navigator.credentials.get({ publicKey: options });
        })
        .then(function (assertion) {
          if (!assertion) throw new Error('パスキーによるログインがキャンセルされました。');
          return postJson(adminPath('/admin/webauthn/login/verify'), {
            username: username,
            credential: credentialToJson(assertion),
          });
        })
        .then(function (data) {
          window.location.href = data.redirect || adminPath('/admin/');
        })
        .catch(function (err) {
          showMessage(messageEl, err.message || 'パスキーによるログインに失敗しました。');
        })
        .finally(function () {
          btn.disabled = false;
        });
    });
  }

  function initRegister() {
    var btn = document.querySelector('[data-admin-webauthn="register"]');
    if (!btn) return;

    var nameInputId = btn.getAttribute('data-passkey-name-input') || '';
    var nameEl = nameInputId ? document.getElementById(nameInputId) : null;
    var messageEl = document.querySelector('[data-admin-webauthn-message]');

    btn.addEventListener('click', function () {
      showMessage(messageEl, '');
      if (!window.PublicKeyCredential) {
        showMessage(messageEl, 'このブラウザはパスキーに対応していません。');
        return;
      }

      btn.disabled = true;
      postJson(adminPath('/admin/webauthn/register/options'), {})
        .then(function (data) {
          var options = parseCreationOptions(data.publicKey);
          return navigator.credentials.create({ publicKey: options });
        })
        .then(function (credential) {
          if (!credential) throw new Error('パスキーの登録がキャンセルされました。');
          var name = nameEl ? String(nameEl.value || '').trim() : '';
          return postJson(adminPath('/admin/webauthn/register/verify'), {
            credential: credentialToJson(credential),
            name: name,
          });
        })
        .then(function () {
          window.location.reload();
        })
        .catch(function (err) {
          showMessage(messageEl, err.message || 'パスキーの登録に失敗しました。');
        })
        .finally(function () {
          btn.disabled = false;
        });
    });
  }

  function initDeleteButtons() {
    document.querySelectorAll('[data-admin-webauthn="delete"]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var id = btn.getAttribute('data-credential-id');
        if (!id) return;
        if (!window.confirm('このパスキーを削除しますか？')) return;

        var messageEl = document.querySelector('[data-admin-webauthn-message]');
        btn.disabled = true;
        postJson(adminPath('/admin/webauthn/credentials/' + encodeURIComponent(id) + '/delete'), {})
          .then(function () {
            window.location.reload();
          })
          .catch(function (err) {
            showMessage(messageEl, err.message || '削除に失敗しました。');
            btn.disabled = false;
          });
      });
    });
  }

  function init() {
    if (!csrf) return;
    initLogin();
    initRegister();
    initDeleteButtons();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
