(function () {
    'use strict';

    var wheelOverlay = null;
    var wheelActiveInput = null;
    var wheelDraft = { year: 0, month: 0, day: 0 };
    var wheelSuppressScrollSync = false;

    function pad2(n) {
        return n < 10 ? '0' + n : String(n);
    }

    function parseIsoDate(value) {
        if (!value || !/^(19|20)\d{2}-\d{2}-\d{2}$/.test(value)) {
            return null;
        }
        var parts = value.split('-');
        return {
            year: parseInt(parts[0], 10),
            month: parseInt(parts[1], 10),
            day: parseInt(parts[2], 10),
        };
    }

    function formatIsoDate(y, m, d) {
        return y + '-' + pad2(m) + '-' + pad2(d);
    }

    function daysInMonth(year, month) {
        return new Date(year, month, 0).getDate();
    }

    function clampDraft() {
        var maxDay = daysInMonth(wheelDraft.year, wheelDraft.month);
        if (wheelDraft.day > maxDay) {
            wheelDraft.day = maxDay;
        }
    }

    function defaultDraft() {
        var now = new Date();
        return {
            year: now.getFullYear(),
            month: now.getMonth() + 1,
            day: now.getDate(),
        };
    }

    function ensureWheelOverlay() {
        if (wheelOverlay) {
            return wheelOverlay;
        }
        wheelOverlay = document.createElement('div');
        wheelOverlay.className = 'c-wheelDate01__overlay';
        wheelOverlay.setAttribute('data-module', 'c-wheelDate01');
        wheelOverlay.hidden = true;
        wheelOverlay.innerHTML =
            '<div class="c-wheelDate01__backdrop" data-action="cancel" aria-hidden="true"></div>' +
            '<div class="c-wheelDate01__panel" role="dialog" aria-modal="true">' +
            '<div class="c-wheelDate01__columns">' +
            '<ul class="c-wheelDate01__column" data-column="year" aria-label="年"></ul>' +
            '<ul class="c-wheelDate01__column" data-column="month" aria-label="月"></ul>' +
            '<ul class="c-wheelDate01__column" data-column="day" aria-label="日"></ul>' +
            '</div>' +
            '<div class="c-wheelDate01__actions">' +
            '<button type="button" class="btn" data-action="cancel">キャンセル</button>' +
            '<button type="button" class="btn is-primary" data-action="confirm">確定</button>' +
            '</div></div>';
        document.body.appendChild(wheelOverlay);

        wheelOverlay.addEventListener('click', function (event) {
            var action = event.target.closest('[data-action]');
            if (!action) {
                return;
            }
            var name = action.getAttribute('data-action');
            if (name === 'cancel') {
                closeWheelOverlay();
            } else if (name === 'confirm') {
                confirmWheelOverlay();
            }
        });

        wheelOverlay.querySelectorAll('.c-wheelDate01__column').forEach(function (column) {
            column.addEventListener('scroll', function () {
                if (wheelSuppressScrollSync) {
                    return;
                }
                syncDraftFromColumnScroll(column);
                if (column.getAttribute('data-column') === 'year' || column.getAttribute('data-column') === 'month') {
                    rebuildDayColumn();
                    scrollColumnToValue(wheelOverlay.querySelector('[data-column="day"]'), wheelDraft.day);
                }
            });
            column.addEventListener('click', function (event) {
                var item = event.target.closest('li[data-value]');
                if (!item) {
                    return;
                }
                scrollColumnToValue(column, parseInt(item.getAttribute('data-value'), 10));
                syncDraftFromColumnScroll(column);
                if (column.getAttribute('data-column') === 'year' || column.getAttribute('data-column') === 'month') {
                    rebuildDayColumn();
                    scrollColumnToValue(wheelOverlay.querySelector('[data-column="day"]'), wheelDraft.day);
                }
            });
        });

        return wheelOverlay;
    }

    function scrollColumnToValue(column, value) {
        if (!column) {
            return;
        }
        var item = column.querySelector('li[data-value="' + value + '"]');
        if (!item) {
            return;
        }
        column.scrollTop = item.offsetTop - column.clientHeight / 2 + item.offsetHeight / 2;
    }

    function syncDraftFromColumnScroll(column) {
        if (wheelSuppressScrollSync) {
            return;
        }
        var kind = column.getAttribute('data-column');
        var center = column.scrollTop + column.clientHeight / 2;
        var items = column.querySelectorAll('li[data-value]');
        var best = null;
        var bestDist = Infinity;
        items.forEach(function (item) {
            var mid = item.offsetTop + item.offsetHeight / 2;
            var dist = Math.abs(mid - center);
            if (dist < bestDist) {
                bestDist = dist;
                best = item;
            }
        });
        if (!best) {
            return;
        }
        var val = parseInt(best.getAttribute('data-value'), 10);
        if (kind === 'year') {
            wheelDraft.year = val;
        } else if (kind === 'month') {
            wheelDraft.month = val;
        } else if (kind === 'day') {
            wheelDraft.day = val;
        }
        highlightSelected(column, val);
    }

    function highlightSelected(column, value) {
        column.querySelectorAll('li').forEach(function (li) {
            li.classList.toggle('is-selected', parseInt(li.getAttribute('data-value'), 10) === value);
        });
    }

    function fillColumn(column, values, selected) {
        column.innerHTML = '';
        values.forEach(function (val) {
            var li = document.createElement('li');
            li.setAttribute('data-value', String(val));
            li.textContent = kindLabel(column.getAttribute('data-column'), val);
            if (val === selected) {
                li.classList.add('is-selected');
            }
            column.appendChild(li);
        });
    }

    function kindLabel(kind, val) {
        if (kind === 'year') {
            return val + '年';
        }
        if (kind === 'month') {
            return val + '月';
        }
        return val + '日';
    }

    function yearRange() {
        var years = [];
        for (var y = 1900; y <= 2100; y += 1) {
            years.push(y);
        }
        return years;
    }

    function rebuildDayColumn() {
        clampDraft();
        var column = wheelOverlay.querySelector('[data-column="day"]');
        var days = [];
        var max = daysInMonth(wheelDraft.year, wheelDraft.month);
        for (var d = 1; d <= max; d += 1) {
            days.push(d);
        }
        fillColumn(column, days, wheelDraft.day);
    }

    function positionWheelColumnsToDraft(overlay) {
        var yearCol = overlay.querySelector('[data-column="year"]');
        var monthCol = overlay.querySelector('[data-column="month"]');
        var dayCol = overlay.querySelector('[data-column="day"]');
        scrollColumnToValue(yearCol, wheelDraft.year);
        scrollColumnToValue(monthCol, wheelDraft.month);
        scrollColumnToValue(dayCol, wheelDraft.day);
        highlightSelected(yearCol, wheelDraft.year);
        highlightSelected(monthCol, wheelDraft.month);
        highlightSelected(dayCol, wheelDraft.day);
    }

    function openWheelOverlay(input) {
        var overlay = ensureWheelOverlay();
        wheelActiveInput = input;
        var parsed = parseIsoDate(input.value);
        wheelDraft = parsed || defaultDraft();
        clampDraft();

        fillColumn(overlay.querySelector('[data-column="year"]'), yearRange(), wheelDraft.year);
        fillColumn(
            overlay.querySelector('[data-column="month"]'),
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
            wheelDraft.month
        );
        rebuildDayColumn();

        wheelSuppressScrollSync = true;
        overlay.hidden = false;
        overlay.classList.add('is-open');
        document.body.classList.add('is-c-wheelDate01-open');

        requestAnimationFrame(function () {
            positionWheelColumnsToDraft(overlay);
            requestAnimationFrame(function () {
                wheelSuppressScrollSync = false;
            });
        });
    }

    function closeWheelOverlay() {
        if (!wheelOverlay) {
            return;
        }
        wheelSuppressScrollSync = false;
        wheelOverlay.hidden = true;
        wheelOverlay.classList.remove('is-open');
        document.body.classList.remove('is-c-wheelDate01-open');
        wheelActiveInput = null;
    }

    function confirmWheelOverlay() {
        if (!wheelActiveInput) {
            closeWheelOverlay();
            return;
        }
        clampDraft();
        var iso = formatIsoDate(wheelDraft.year, wheelDraft.month, wheelDraft.day);
        wheelActiveInput.value = iso;
        wheelActiveInput.dispatchEvent(new Event('change', { bubbles: true }));
        updateWheelTrigger(wheelActiveInput);
        closeWheelOverlay();
    }

    function formatDisplay(iso) {
        var p = parseIsoDate(iso);
        if (!p) {
            return '';
        }
        return p.year + '/' + pad2(p.month) + '/' + pad2(p.day);
    }

    function updateWheelTrigger(input) {
        var wrap = input.closest('[data-module="c-wheelDate01"]');
        if (!wrap) {
            return;
        }
        var trigger = wrap.querySelector('.c-wheelDate01__trigger');
        if (!trigger) {
            return;
        }
        var label = formatDisplay(input.value);
        trigger.textContent = label || '日付を選択';
        trigger.classList.toggle('is-empty', label === '');
    }

    var workflowStatusClassNames = ['is-pending', 'is-in_progress', 'is-done', 'is-on_hold'];

    function syncWorkflowStatusSelectClass(select, value) {
        workflowStatusClassNames.forEach(function (name) {
            select.classList.remove(name);
        });
        if (value) {
            select.classList.add('is-' + value);
        }
    }

    function shouldSkipTomSelectEnhance(select) {
        if (select.getAttribute('data-native-select') === 'keep') {
            return true;
        }
        if (select.tomselect || select.getAttribute('data-enhanced-select') === '1') {
            return true;
        }
        return false;
    }

    function bindTomSelect(select, options) {
        select.setAttribute('data-enhanced-select', '1');
        new TomSelect(select, options);
    }

    window.formkunDestroyAdminPickers = function (root) {
        if (!root) {
            return;
        }
        root.querySelectorAll('select[data-enhanced-select="1"]').forEach(function (select) {
            if (select.tomselect) {
                select.tomselect.destroy();
            }
            select.removeAttribute('data-enhanced-select');
        });
        root.querySelectorAll('[data-module="c-wheelDate01"].is-enhanced').forEach(function (wrap) {
            var input = wrap.querySelector('input[type="date"]');
            var trigger = wrap.querySelector('.c-wheelDate01__trigger');
            if (trigger) {
                trigger.remove();
            }
            if (input && wrap.parentNode) {
                wrap.parentNode.insertBefore(input, wrap);
                wrap.remove();
                input.classList.remove('c-wheelDate01__native');
            }
            if (input) {
                input.removeAttribute('data-wheel-date-bound');
            }
        });
    };

    window.formkunEnhanceAdminSelects = function (root) {
        if (typeof TomSelect === 'undefined') {
            return;
        }
        var scope = root || document;
        var tomSelectBase = {
            create: false,
            allowEmptyOption: true,
            maxOptions: 5000,
            controlInput: null,
        };

        scope.querySelectorAll('[data-module="m-input01"] select.m-inout01__input').forEach(function (select) {
            if (shouldSkipTomSelectEnhance(select)) {
                return;
            }
            bindTomSelect(select, Object.assign({}, tomSelectBase, {
                onChange: function () {
                    select.dispatchEvent(new Event('change', { bubbles: true }));
                },
            }));
        });

        scope.querySelectorAll(
            '[data-module="m-submissionWorkflowStatus01"] select[data-target="m-submissionWorkflowStatus01__select"]'
        ).forEach(function (select) {
            if (shouldSkipTomSelectEnhance(select)) {
                return;
            }
            bindTomSelect(select, Object.assign({}, tomSelectBase, {
                allowEmptyOption: false,
                dropdownParent: 'body',
                dropdownClass: 'ts-dropdown is-m-submissionWorkflowStatus01-dropdown',
                onChange: function (value) {
                    syncWorkflowStatusSelectClass(select, value);
                    select.dispatchEvent(new Event('change', { bubbles: true }));
                    if (select.form) {
                        select.form.submit();
                    }
                },
            }));
        });
    };

    window.formkunEnhanceAdminDateInputs = function (root) {
        var scope = root || document;
        scope.querySelectorAll('input[type="date"]').forEach(function (input) {
            if (input.getAttribute('data-native-date') === 'keep') {
                return;
            }
            if (input.getAttribute('data-wheel-date-bound') === '1') {
                updateWheelTrigger(input);
                return;
            }
            if (input.closest('[data-module="c-wheelDate01"].is-enhanced')) {
                return;
            }
            input.setAttribute('data-wheel-date-bound', '1');
            input.classList.add('c-wheelDate01__native');

            var wrap = document.createElement('div');
            wrap.setAttribute('data-module', 'c-wheelDate01');
            wrap.className = 'c-wheelDate01 is-enhanced';
            input.parentNode.insertBefore(wrap, input);
            wrap.appendChild(input);

            var trigger = document.createElement('button');
            trigger.type = 'button';
            trigger.className = 'c-wheelDate01__trigger';
            trigger.setAttribute('aria-haspopup', 'dialog');
            var boundId = input.id;
            if (boundId) {
                trigger.setAttribute('aria-labelledby', boundId);
            }
            wrap.appendChild(trigger);
            updateWheelTrigger(input);

            trigger.addEventListener('click', function () {
                openWheelOverlay(input);
            });
        });
    };

    window.formkunReenhanceAdminPickers = function (root) {
        var scope = root || document;
        window.formkunDestroyAdminPickers(scope);
        window.formkunEnhanceAdminSelects(scope);
        window.formkunEnhanceAdminDateInputs(scope);
    };

    function initPickersOnReady() {
        window.formkunReenhanceAdminPickers(document);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPickersOnReady);
    } else {
        initPickersOnReady();
    }
})();
