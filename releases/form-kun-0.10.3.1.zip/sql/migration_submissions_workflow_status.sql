-- 送信履歴の処理状態（未処理 / 対応中 / 処理済み / 保留）
-- SchemaPatch でも自動適用されます。

ALTER TABLE submissions
    ADD COLUMN workflow_status VARCHAR(32) NOT NULL DEFAULT 'pending' AFTER submitted_at;

ALTER TABLE submissions
    ADD KEY idx_form_workflow (form_id, workflow_status, submitted_at);
