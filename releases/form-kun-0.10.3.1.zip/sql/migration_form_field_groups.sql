-- 項目グループ機能（旧DB向け手動実行例）

ALTER TABLE form_fields
    ADD COLUMN parent_group_key VARCHAR(64) DEFAULT NULL AFTER input_page_key;

CREATE TABLE IF NOT EXISTS form_field_groups (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    form_id          INT NOT NULL,
    input_page_key   VARCHAR(64) NOT NULL DEFAULT 'input-1',
    parent_group_key VARCHAR(64) DEFAULT NULL,
    sort_order       INT NOT NULL DEFAULT 0,
    group_key        VARCHAR(64) NOT NULL,
    label            VARCHAR(200) NOT NULL,
    description      VARCHAR(500) DEFAULT NULL,
    visible          TINYINT(1) NOT NULL DEFAULT 1,
    created_at       DATETIME NOT NULL,
    updated_at       DATETIME NOT NULL,
    UNIQUE KEY uk_form_field_group (form_id, group_key),
    KEY idx_form_field_group_sort (form_id, input_page_key, parent_group_key, sort_order),
    CONSTRAINT fk_form_field_groups_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE form_branch_rules
    ADD COLUMN target_type VARCHAR(16) NOT NULL DEFAULT 'field' AFTER action_type;
