-- フォーム公開スケジュール・時間外画面
-- SchemaPatch でも自動適用されます。

ALTER TABLE forms
    ADD COLUMN publish_schedule_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER status,
    ADD COLUMN publish_rules TEXT DEFAULT NULL AFTER publish_schedule_enabled,
    ADD COLUMN closed_page_title VARCHAR(200) DEFAULT NULL AFTER publish_rules,
    ADD COLUMN show_closed_page_title TINYINT(1) NOT NULL DEFAULT 1 AFTER closed_page_title,
    ADD COLUMN closed_message TEXT DEFAULT NULL AFTER show_closed_page_title,
    ADD COLUMN closed_button_text VARCHAR(200) DEFAULT NULL AFTER closed_message,
    ADD COLUMN closed_button_url VARCHAR(500) DEFAULT NULL AFTER closed_button_text;
