-- 複数入力画面対応（旧DB向け手動実行用）

CREATE TABLE IF NOT EXISTS form_input_pages (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    form_id         INT NOT NULL,
    page_key        VARCHAR(64) NOT NULL,
    sort_order      INT NOT NULL DEFAULT 0,
    title           VARCHAR(200) DEFAULT NULL,
    show_title      TINYINT(1) NOT NULL DEFAULT 1,
    description     TEXT DEFAULT NULL,
    button_text     VARCHAR(200) DEFAULT NULL,
    back_button_text VARCHAR(200) DEFAULT NULL,
    created_at      DATETIME NOT NULL,
    updated_at      DATETIME NOT NULL,
    UNIQUE KEY uk_form_input_page (form_id, page_key),
    KEY idx_form_input_page_sort (form_id, sort_order),
    CONSTRAINT fk_form_input_pages_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE form_fields
    ADD COLUMN input_page_key VARCHAR(64) NOT NULL DEFAULT 'input-1' AFTER form_id;

INSERT INTO form_input_pages (
    form_id, page_key, sort_order, title, show_title, description, button_text, back_button_text, created_at, updated_at
)
SELECT
    f.id,
    'input-1',
    1,
    f.input_page_title,
    f.show_input_page_title,
    f.description,
    f.confirm_button_text,
    '戻る',
    NOW(),
    NOW()
FROM forms f
WHERE NOT EXISTS (
    SELECT 1 FROM form_input_pages p WHERE p.form_id = f.id AND p.page_key = 'input-1'
);

UPDATE form_fields SET input_page_key = 'input-1' WHERE input_page_key = '';
