-- 表示専用項目（見出し・説明文・罫線）を form_fields.type に追加
ALTER TABLE form_fields MODIFY COLUMN type ENUM(
    'text','textarea','email','tel','number','address','text_pair','text_multi',
    'radio','checkbox','select','date','time','file',
    'heading','description','divider'
) NOT NULL;
