ALTER TABLE submissions
    ADD COLUMN storage_mode VARCHAR(20) NOT NULL DEFAULT 'database' AFTER workflow_status,
    ADD COLUMN delivery_route VARCHAR(16) DEFAULT NULL AFTER storage_mode,
    ADD COLUMN mail_delivery_status VARCHAR(16) DEFAULT NULL AFTER delivery_route,
    ADD COLUMN mail_error_code VARCHAR(64) DEFAULT NULL AFTER mail_delivery_status,
    ADD COLUMN attachment_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER mail_error_code,
    ADD COLUMN attachment_total_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER attachment_count;
