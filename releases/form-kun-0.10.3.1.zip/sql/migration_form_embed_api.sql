-- Embed API モード
CREATE TABLE IF NOT EXISTS form_embed_settings (
    form_id                    INT NOT NULL PRIMARY KEY,
    enabled                    TINYINT(1) NOT NULL DEFAULT 0,
    public_page_hidden         TINYINT(1) NOT NULL DEFAULT 0,
    allowed_origins_json       TEXT DEFAULT NULL,
    completion_url             VARCHAR(500) DEFAULT NULL,
    japan_only_enabled         TINYINT(1) NOT NULL DEFAULT 0,
    turnstile_enabled          TINYINT(1) NOT NULL DEFAULT 0,
    turnstile_site_key         VARCHAR(255) DEFAULT NULL,
    turnstile_secret_key       VARCHAR(255) DEFAULT NULL,
    recaptcha_enabled          TINYINT(1) NOT NULL DEFAULT 0,
    recaptcha_site_key         VARCHAR(255) DEFAULT NULL,
    recaptcha_secret_key       VARCHAR(255) DEFAULT NULL,
    recaptcha_v3_enabled       TINYINT(1) NOT NULL DEFAULT 0,
    recaptcha_v3_site_key      VARCHAR(255) DEFAULT NULL,
    recaptcha_v3_secret_key    VARCHAR(255) DEFAULT NULL,
    recaptcha_v3_min_score     DECIMAL(3,2) NOT NULL DEFAULT 0.50,
    rate_limit_count           INT NOT NULL DEFAULT 10,
    rate_limit_window_seconds  INT NOT NULL DEFAULT 600,
    created_at                 DATETIME NOT NULL,
    updated_at                 DATETIME NOT NULL,
    CONSTRAINT fk_form_embed_settings_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ip_country_cache (
    ip            VARCHAR(45) NOT NULL PRIMARY KEY,
    country_code  CHAR(2) NOT NULL,
    checked_at    DATETIME NOT NULL,
    KEY idx_ip_country_checked (checked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS public_api_rate_limits (
    form_id            INT NOT NULL,
    ip                 VARCHAR(45) NOT NULL,
    window_started_at  INT UNSIGNED NOT NULL,
    attempt_count      INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at         DATETIME NOT NULL,
    PRIMARY KEY (form_id, ip),
    KEY idx_public_api_rate_updated (updated_at),
    CONSTRAINT fk_public_api_rate_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
