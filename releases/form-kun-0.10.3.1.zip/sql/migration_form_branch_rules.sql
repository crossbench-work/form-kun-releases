-- フォーム分岐処理（旧DB向け手動実行用）

CREATE TABLE IF NOT EXISTS form_branch_rules (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    form_id             INT NOT NULL,
    rule_key            VARCHAR(64) NOT NULL,
    sort_order          INT NOT NULL DEFAULT 0,
    trigger_page_key    VARCHAR(64) NOT NULL DEFAULT 'input-1',
    source_field_key    VARCHAR(64) NOT NULL,
    operator            VARCHAR(32) NOT NULL DEFAULT 'equals',
    expected_value      VARCHAR(255) NOT NULL,
    action_type         VARCHAR(32) NOT NULL,
    target_key          VARCHAR(64) NOT NULL,
    enabled             TINYINT(1) NOT NULL DEFAULT 1,
    created_at          DATETIME NOT NULL,
    updated_at          DATETIME NOT NULL,
    UNIQUE KEY uk_form_branch_rule (form_id, rule_key),
    KEY idx_form_branch_sort (form_id, sort_order),
    KEY idx_form_branch_page_sort (form_id, trigger_page_key, sort_order),
    KEY idx_form_branch_source (form_id, source_field_key),
    CONSTRAINT fk_form_branch_rules_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
