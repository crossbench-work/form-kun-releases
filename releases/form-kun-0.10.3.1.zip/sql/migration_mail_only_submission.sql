ALTER TABLE forms
    ADD COLUMN submission_storage_mode VARCHAR(20) NOT NULL DEFAULT 'database' AFTER mail_smtp_allow_self_signed,
    ADD COLUMN mail_attachment_max_bytes INT NOT NULL DEFAULT 10485760 AFTER submission_storage_mode,
    ADD COLUMN smtp_tested_at DATETIME DEFAULT NULL AFTER mail_attachment_max_bytes,
    ADD COLUMN smtp_test_fingerprint CHAR(64) DEFAULT NULL AFTER smtp_tested_at;

CREATE TABLE IF NOT EXISTS mail_delivery_audits (
    id                     BIGINT AUTO_INCREMENT PRIMARY KEY,
    form_id                INT NOT NULL,
    route                  VARCHAR(16) NOT NULL,
    delivery_status        VARCHAR(16) NOT NULL,
    error_code             VARCHAR(64) DEFAULT NULL,
    attachment_count       INT UNSIGNED NOT NULL DEFAULT 0,
    attachment_total_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_at             DATETIME NOT NULL,
    KEY idx_mail_audit_created (created_at),
    KEY idx_mail_audit_form_created (form_id, created_at),
    CONSTRAINT fk_mail_delivery_audits_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

UPDATE form_versions
SET snapshot_json = JSON_REMOVE(snapshot_json, '$.form.mail_smtp_password')
WHERE JSON_VALID(snapshot_json) = 1
  AND JSON_CONTAINS_PATH(snapshot_json, 'one', '$.form.mail_smtp_password') = 1;
