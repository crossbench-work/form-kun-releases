-- フォーム非公開条件
-- SchemaPatch でも自動適用されます。

ALTER TABLE forms
    ADD COLUMN unpublish_rules TEXT DEFAULT NULL AFTER publish_rules;
