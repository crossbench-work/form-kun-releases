-- Embed API専用フォーム向けに、フォームくん側の公開ページ非表示設定を追加
ALTER TABLE form_embed_settings
    ADD COLUMN public_page_hidden TINYINT(1) NOT NULL DEFAULT 0 AFTER enabled;
