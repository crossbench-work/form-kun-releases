-- 項目・グループの公開ラベル表示フラグを追加
ALTER TABLE form_fields
    ADD COLUMN show_label TINYINT(1) NOT NULL DEFAULT 1 AFTER label;

ALTER TABLE form_field_groups
    ADD COLUMN show_label TINYINT(1) NOT NULL DEFAULT 1 AFTER label;
