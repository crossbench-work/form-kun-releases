ALTER TABLE form_fields
  MODIFY COLUMN type ENUM(
    'text','textarea','email','tel','number','postal_code','address','text_pair','text_multi','matrix',
    'radio','checkbox','select','date','time','file',
    'heading','description','divider'
  ) NOT NULL;
