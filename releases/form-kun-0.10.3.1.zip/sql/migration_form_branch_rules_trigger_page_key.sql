-- 分岐処理の対象ページ（旧DB向け手動実行用）

ALTER TABLE form_branch_rules
    ADD COLUMN trigger_page_key VARCHAR(64) NOT NULL DEFAULT 'input-1' AFTER sort_order;

ALTER TABLE form_branch_rules
    ADD KEY idx_form_branch_page_sort (form_id, trigger_page_key, sort_order);
