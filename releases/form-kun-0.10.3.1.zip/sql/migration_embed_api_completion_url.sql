-- Embed APIへ送信完了後の外部遷移先URLを追加
ALTER TABLE form_embed_settings
    ADD COLUMN completion_url VARCHAR(500) DEFAULT NULL AFTER allowed_origins_json;
