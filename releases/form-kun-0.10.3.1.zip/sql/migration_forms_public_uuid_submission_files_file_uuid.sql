-- フォーム public_uuid・添付 file_uuid（既存 DB 向け）
-- SchemaPatch でも自動適用されます。

ALTER TABLE forms
    ADD COLUMN public_uuid CHAR(36) DEFAULT NULL AFTER slug;

UPDATE forms SET public_uuid = LOWER(UUID()) WHERE public_uuid IS NULL OR public_uuid = '';

ALTER TABLE forms
    MODIFY public_uuid CHAR(36) NOT NULL,
    ADD UNIQUE KEY uk_forms_public_uuid (public_uuid);

ALTER TABLE submission_files
    ADD COLUMN file_uuid CHAR(36) DEFAULT NULL AFTER field_key,
    ADD UNIQUE KEY uk_submission_files_file_uuid (file_uuid);
