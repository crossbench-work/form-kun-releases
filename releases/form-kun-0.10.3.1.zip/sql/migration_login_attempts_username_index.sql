-- ユーザー名単位のログイン試行制限を効率よく集計するための索引
ALTER TABLE login_attempts
    ADD KEY idx_username_time (username, attempted_at);
