-- 入力画面ごとの戻るボタン文言（旧DB向け手動実行用）

ALTER TABLE form_input_pages
    ADD COLUMN back_button_text VARCHAR(200) DEFAULT NULL AFTER button_text;
