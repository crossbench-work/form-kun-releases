-- 受信履歴の保存期間（日数）と、期間を過ぎたときの扱い（warn: 警告のみ / delete: CLI で削除）、保存期間を使うか（1: 設定する / 0: 設定しない）
ALTER TABLE forms
    ADD COLUMN submission_retention_days INT NOT NULL DEFAULT 14 AFTER mail_attachment_max_bytes,
    ADD COLUMN submission_retention_action VARCHAR(10) NOT NULL DEFAULT 'warn' AFTER submission_retention_days,
    ADD COLUMN submission_retention_enabled TINYINT(1) NOT NULL DEFAULT 1 AFTER submission_retention_action;
