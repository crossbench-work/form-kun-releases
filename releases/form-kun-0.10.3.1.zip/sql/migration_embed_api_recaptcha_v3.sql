-- Embed APIへreCAPTCHA v3のフォーム単位設定を追加
ALTER TABLE form_embed_settings
    ADD COLUMN recaptcha_v3_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER recaptcha_secret_key,
    ADD COLUMN recaptcha_v3_site_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_v3_enabled,
    ADD COLUMN recaptcha_v3_secret_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_v3_site_key,
    ADD COLUMN recaptcha_v3_min_score DECIMAL(3,2) NOT NULL DEFAULT 0.50 AFTER recaptcha_v3_secret_key;
