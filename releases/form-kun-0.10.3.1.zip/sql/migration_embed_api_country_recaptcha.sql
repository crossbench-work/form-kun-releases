-- 既存のEmbed APIへ日本限定IP判定とreCAPTCHA v2を追加
ALTER TABLE form_embed_settings
    ADD COLUMN japan_only_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER allowed_origins_json,
    ADD COLUMN recaptcha_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER turnstile_secret_key,
    ADD COLUMN recaptcha_site_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_enabled,
    ADD COLUMN recaptcha_secret_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_site_key;

CREATE TABLE IF NOT EXISTS ip_country_cache (
    ip            VARCHAR(45) NOT NULL PRIMARY KEY,
    country_code  CHAR(2) NOT NULL,
    checked_at    DATETIME NOT NULL,
    KEY idx_ip_country_checked (checked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
