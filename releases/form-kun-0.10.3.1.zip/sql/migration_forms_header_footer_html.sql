-- フォーム共通 header/footer HTML（旧DB向け手動実行用）

ALTER TABLE forms
    ADD COLUMN header_html TEXT DEFAULT NULL AFTER custom_js,
    ADD COLUMN footer_html TEXT DEFAULT NULL AFTER header_html;
