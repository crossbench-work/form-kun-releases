<?php
/**
 * 説明文エディタの既存ブロック 1 件分（先頭 / 末尾リスト共通）。
 */
if (!function_exists('admin_c_description_editor01_block')) {
    /**
     * @param array<string, mixed> $block
     */
    function admin_c_description_editor01_block(
        string $namePrefix,
        int $i,
        array $block,
        bool $imageUploadEnabled,
        int $formIdForImages
    ): void {
        $blockId = (string) ($block['id'] ?? ($namePrefix . '-' . $i));
        $labelValue = trim((string) ($block['label'] ?? ''));
        $labelInputId = $blockId . '-label';
        $positionValue = (int) ($block['position'] ?? 0);
        $contentType = ((string) ($block['content_type'] ?? '')) === 'image' ? 'image' : 'text';
        $typeLabel = $contentType === 'image' ? '画像' : 'テキスト';
        ?>
        <?php admin_c_form_editor_item01_open([
            'data-description-block' => true,
            'data-index' => (string) $i,
        ], true, empty($block['visible'])); ?>
        <input type="hidden" name="<?= e($namePrefix) ?>[<?= $i ?>][id]"
            value="<?= e($blockId) ?>" data-name="id">
        <input type="hidden" name="<?= e($namePrefix) ?>[<?= $i ?>][position]"
            value="<?= e((string) $positionValue) ?>" data-name="position"
            data-target="c-descriptionEditor__position">
        <div class="wrapper">
            <div class="block is-header">
                <?php admin_c_form_editor_item_header01_open(); ?>
                <div class="area is-move">
                    <div class="box is-handle ui-sortable-handle" title="ドラッグして並べ替え">
                        <?php admin_m_drag_handle01('c-descriptionEditor__dragHandle'); ?>
                    </div>
                </div>
                <div class="area is-summary">
                    <div class="c-descriptionEditorSummary01">
                        <div class="wrapper">
                            <div class="block is-contents">
                                <p class="label"
                                    data-target="c-descriptionEditor__summaryLabel"
                                    <?= $labelValue === '' ? ' hidden' : '' ?>>
                                    <?= $labelValue !== '' ? e($labelValue) : '' ?>
                                </p>
                                <p class="type"
                                    data-target="c-descriptionEditor__summaryType">
                                    <?= e($typeLabel) ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="area is-delete">
                    <label class="c-descriptionEditorSummary01__visibility"
                        title="<?= !empty($block['visible']) ? '表示中' : '非表示' ?>">
                        <input type="checkbox"
                            name="<?= e($namePrefix) ?>[<?= $i ?>][visible]"
                            value="1" data-name="visible"
                            <?= !empty($block['visible']) ? 'checked' : '' ?>>
                        <span aria-hidden="true">
                            <svg width="16" height="16" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" />
                                <circle cx="12" cy="12" r="3" />
                                <path class="is-hiddenLine" stroke-linecap="round"
                                    stroke-linejoin="round" d="M4 20L20 4" />
                            </svg>
                        </span>
                    </label>
                    <?php admin_m_delete_btn01('fb-description-remove'); ?>
                </div>
                <?php admin_c_form_editor_item_header01_close(); ?>
            </div>
            <div class="block is-body">
                <?php admin_c_form_editor_item_body01_open(); ?>
                <div class="block is-contents">
                    <div class="area is-field">
                        <?php admin_m_input_set01_open(); ?>
                        <div class="area is-title">
                            <?php admin_m_bold_title01(e('ラベル'), $labelInputId); ?>
                        </div>
                        <div class="area is-field">
                            <?php admin_m_input01_open(); ?>
                            <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label($labelInputId, [
                                'type' => 'text',
                                'id' => $labelInputId,
                                'name' => $namePrefix . '[' . $i . '][label]',
                                'value' => (string) $labelValue,
                                'data-name' => 'label',
                                'data-target' => 'c-descriptionEditor__labelInput',
                            ])); ?>
                            <?php admin_m_input01_close(); ?>
                        </div>
                        <?php admin_m_input_set01_close(); ?>
                    </div>
                </div>
                <?php admin_c_description_editor01_block_content(
                    $namePrefix,
                    $i,
                    $block,
                    $imageUploadEnabled,
                    $formIdForImages
                ); ?>
                <?php admin_c_form_editor_item_body01_close(); ?>
            </div>
        </div>
        <?php admin_c_form_editor_item01_close(); ?>
        <?php
    }
}
