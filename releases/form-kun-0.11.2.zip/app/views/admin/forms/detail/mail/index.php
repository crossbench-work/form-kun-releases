<?php
/** フォーム編集:「通知」タブパネル
 * _content_*.php … c-formBlock01 直下 .area.is-field の内側。各ファイル先頭コメントにフィールドの説明あり。
 */
$mtRaw = $form['mail_transport'] ?? null;
$mailTransportForTabs = ($mtRaw === null || $mtRaw === '') ? 'none' : (string) $mtRaw;
$mailTransportShowsNotifyTab = in_array($mailTransportForTabs, ['smtp', 'smtp_local'], true);
?>
<div data-target="c-formEditTabs01__contents" data-tab-panel="mail" class="area is-contents" role="tabpanel"
    aria-label="通知" hidden>
    <?php admin_c_form_edit_section_tabs01_open('mail', [
        ['panel' => 'mail-smtp', 'label' => 'メール設定', 'selected' => true],
        [
            'panel' => 'mail-notify',
            'label' => '通知設定',
            'selected' => false,
            'hidden' => !$mailTransportShowsNotifyTab,
        ],
        ['panel' => 'mail-line', 'label' => 'LINE通知', 'selected' => false],
    ], '通知の区分'); ?>
        <div data-target="c-formEditTabs01__contents" data-tab-panel="mail-smtp" class="area is-contents" role="tabpanel"
            aria-label="メール設定">
            <?php admin_c_form_block01_open(); ?>
                <input type="hidden" name="_mail_section_present[smtp]" value="1">
                <div class="area is-title">
                    <?php admin_m_large_title01('メール設定'); ?>
                </div>
                <?php if (\Core\Auth::role() !== 'admin'): ?>
                <div class="area is-field">
                    <?php admin_m_alert01('送信方式・SMTP の設定は admin のみ変更できます。編集しても保存されません。', 'info'); ?>
                </div>
                <?php endif; ?>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_transport.php'; ?>
                </div>
                <div class="block">
                    <div class="area is-title">
                        <?php admin_m_left_border_title01('メール添付'); ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_attachment_max.php'; ?>
                    </div>
                </div>
                <div class="block is-mailNotifySectionDivider">
                    <div class="area is-title">
                        <?php admin_m_left_border_title01('SMTP接続'); ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_smtp_host.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_smtp_port.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_smtp_secure.php'; ?>
                    </div>
                </div>
                <div class="block is-mailNotifySectionDivider">
                    <div class="area is-title">
                        <?php admin_m_left_border_title01('認証'); ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_smtp_username.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_smtp_password.php'; ?>
                    </div>
                </div>
                <div class="block is-mailNotifySectionDivider">
                    <div class="area is-title">
                        <?php admin_m_left_border_title01('詳細'); ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_smtp_ehlo_host.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_smtp_timeout.php'; ?>
                    </div>
                </div>
                <div class="block is-mailNotifySectionDivider">
                    <div class="area is-title">
                        <?php admin_m_left_border_title01('TLS・証明書'); ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_smtp_verify_peer.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_smtp_verify_peer_name.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_smtp_allow_self_signed.php'; ?>
                    </div>
                </div>
                <div class="block is-mailNotifySectionDivider">
                    <div class="area is-title">
                        <?php admin_m_left_border_title01('動作確認'); ?>
                    </div>
                    <?php require __DIR__ . '/_content_mail_smtp_test_button.php'; ?>
                </div>
            <?php admin_c_form_block01_close(); ?>
        </div>
        <div data-target="c-formEditTabs01__contents" data-tab-panel="mail-notify" class="area is-contents" role="tabpanel"
            aria-label="通知設定" hidden>
            <?php admin_c_form_block01_open(); ?>
                <input type="hidden" name="_mail_section_present[admin]" value="1">
                <input type="hidden" name="_mail_section_present[reply]" value="1">
                <div class="area is-title">
                    <?php admin_m_large_title01('通知設定'); ?>
                </div>
                <div class="block">
                    <div class="area is-title">
                        <?php admin_m_left_border_title01('送信者情報'); ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_from_email.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_from_name.php'; ?>
                    </div>
                </div>
                <div class="block is-mailNotifySectionDivider">
                    <div class="area is-title">
                        <?php admin_m_left_border_title01('管理者通知'); ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_admin_emails.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_subject_admin.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_template_admin.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_mail_template_vars.php'; ?>
                    </div>
                </div>
                <div class="block is-mailNotifySectionDivider">
                    <div class="area is-title">
                        <?php admin_m_left_border_title01('自動返信'); ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_reply_enabled.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_reply_from_field_key.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_reply_subject.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_reply_template.php'; ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_reply_template_vars.php'; ?>
                    </div>
                </div>
            <?php admin_c_form_block01_close(); ?>
        </div>
        <?php require __DIR__ . '/_line_tab_panel.php'; ?>
    <?php admin_c_form_edit_section_tabs01_close(); ?>
</div>
