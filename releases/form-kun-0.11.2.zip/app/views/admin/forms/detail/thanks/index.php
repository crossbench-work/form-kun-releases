<?php
/** フォーム編集:「完了画面」タブパネル
 * _content_*.php … c-formBlock01 直下 .area.is-field の内側。説明文は thanks_blocks エディタを本ファイルに残す。
 */
?>
<div data-target="c-formEditTabs01__contents" data-tab-panel="screen-thanks" class="area is-contents" role="tabpanel"
    aria-label="完了画面" hidden>
    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title">
            <?php admin_m_large_title01('完了画面'); ?>
        </div>
        <div class="area is-field">
            <?php require __DIR__ . '/_content_thanks_page_title.php'; ?>
        </div>
        <?php admin_c_description_editor01('thanks_blocks', $thanksBlocks, 'simple', !$isNew, (int) ($form['id'] ?? 0)); ?>
        <div class="area is-field">
            <?php require __DIR__ . '/_content_thanks_buttons.php'; ?>
        </div>
    <?php admin_c_form_block01_close(); ?>
</div>
