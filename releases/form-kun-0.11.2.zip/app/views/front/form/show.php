<section class="l-formWrapper01">
<?php $inputPage = $inputPage ?? \Models\FormInputPage::defaultPage($form ?? []); ?>
<?php $inputPageFields = $inputPageFields ?? $fields; ?>
<?php $descriptionBlocks = decode_form_description_blocks($inputPage['description'] ?? ($form['description'] ?? ''), true); ?>
<?php $descriptionEndPosition = count($inputPageFields) + 1; ?>
<?php $previewMode = !empty($previewMode); ?>
<?php $previewInteractive = !empty($previewInteractive); ?>
<?php $formDisabled = ($previewMode && !$previewInteractive) || !empty($site_resource_blocked); ?>
<?php $confirmButtonText = trim((string) ($inputPage['button_text'] ?? '')) !== '' ? (string) $inputPage['button_text'] : '次へ'; ?>
<?php $backButtonText = trim((string) ($inputPage['back_button_text'] ?? '')) !== '' ? (string) $inputPage['back_button_text'] : '戻る'; ?>
<?php $inputPageTitle = trim((string) ($inputPage['title'] ?? '')); ?>
<?php $inputPageGroups = $inputPageGroups ?? \Models\FormFieldGroup::forInputPage($fieldGroups ?? [], (string) ($inputPage['page_key'] ?? \Models\FormInputPage::DEFAULT_KEY)); ?>
<?php $branchControlledFieldKeys = $branchControlledFieldKeys ?? []; ?>
<?php $branchVisibleFieldKeys = $branchVisibleFieldKeys ?? []; ?>
<?php $branchControlledGroupKeys = $branchControlledGroupKeys ?? []; ?>
<?php $branchVisibleGroupKeys = $branchVisibleGroupKeys ?? []; ?>
<?php $values = $values ?? []; ?>
<?php $errors = $errors ?? []; ?>
<?php $renderedFieldCount = 0; ?>
<?php $descriptionImageFormId = (int) ($form['id'] ?? 0); ?>
<?php
$renderFormNode = function (array $node, bool $parentHidden = false) use (&$renderFormNode, &$renderedFieldCount, $inputPageFields, $inputPageGroups, $descriptionBlocks, $descriptionImageFormId, $branchControlledFieldKeys, $branchVisibleFieldKeys, $branchControlledGroupKeys, $branchVisibleGroupKeys, $values, $errors): void {
    if ($node['kind'] === 'field') {
        $field = $node['item'];
        if (!empty($field['visible'])) {
            include __DIR__ . '/_field.php';
        }
        $renderedFieldCount++;
        echo render_form_description_blocks_at($descriptionBlocks, $renderedFieldCount, $descriptionImageFormId);
        return;
    }

    $group = $node['item'];
    $groupKey = (string) ($group['group_key'] ?? '');
    $branchControlledGroupKeys = $branchControlledGroupKeys ?? [];
    $branchVisibleGroupKeys = $branchVisibleGroupKeys ?? [];
    $branchHidden = in_array($groupKey, $branchControlledGroupKeys, true) && !in_array($groupKey, $branchVisibleGroupKeys, true);
    $groupHidden = $parentHidden || empty($group['visible']) || $branchHidden;
    $showGroupLabel = !array_key_exists('show_label', $group) || !empty($group['show_label']);
    ?>
    <div class="area is-field">
        <fieldset data-module="c-formGroup01" data-group-key="<?= e($groupKey) ?>"<?= $groupHidden ? ' hidden inert disabled' : '' ?>>
            <?php if ($showGroupLabel): ?>
                <legend><?= e((string) ($group['label'] ?? 'グループ')) ?></legend>
            <?php endif; ?>
            <?php if (trim((string) ($group['description'] ?? '')) !== ''): ?>
                <p class="text is-help"><?= nl2br(e((string) $group['description'])) ?></p>
            <?php endif; ?>
            <?php foreach (\Models\FormFieldGroup::childrenForParent($inputPageFields, $inputPageGroups, (string) ($group['input_page_key'] ?? \Models\FormInputPage::DEFAULT_KEY), $groupKey) as $childNode): ?>
                <?php $renderFormNode($childNode, $groupHidden); ?>
            <?php endforeach; ?>
        </fieldset>
    </div>
    <?php
};
?>
<?php if (!empty($inputPage['show_title']) && $inputPageTitle !== ''): ?>
    <h1 class="title"><?= e($inputPageTitle) ?></h1>
<?php endif; ?>
<?= render_form_description_blocks_at($descriptionBlocks, 0, $descriptionImageFormId) ?>

<?php if (!empty($site_resource_blocked)): ?>
    <div data-module="m-alert01" class="is-danger">
        サイトの利用容量が上限に達しているため、現在このフォームをご利用いただけません。しばらくしてから再度お試しください。
    </div>
<?php endif; ?>

<?php if (!empty($errors)): ?>
    <div data-module="m-alert01" class="is-danger">
        入力内容にエラーがあります。下記をご確認ください。
    </div>
<?php endif; ?>

<?php
$branchClientRules = [];
$currentInputPageKey = (string) ($inputPage['page_key'] ?? \Models\FormInputPage::DEFAULT_KEY);
foreach (\Models\FormBranchRule::normalizeRules($branchRules ?? []) as $rule) {
    if (
        !empty($rule['enabled'])
        && ($rule['action_type'] ?? '') === \Models\FormBranchRule::ACTION_SHOW_FIELD
        && (string) ($rule['trigger_page_key'] ?? \Models\FormInputPage::DEFAULT_KEY) === $currentInputPageKey
    ) {
        $branchClientRules[] = [
            'source_field_key' => (string) $rule['source_field_key'],
            'expected_value' => (string) $rule['expected_value'],
            'target_type' => (string) ($rule['target_type'] ?? \Models\FormBranchRule::TARGET_FIELD),
            'target_key' => (string) $rule['target_key'],
        ];
    }
}
$branchJsonFlags = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
$storagePrefix = 'formkun-public:' . (string) ($form['slug'] ?? '') . ':';
?>
<form action="<?= e($formDisabled ? '#' : base_path('/f/' . $form['slug'] . '/confirm')) ?>" method="post" enctype="multipart/form-data" novalidate data-module="c-formSet01"
    data-form-storage-prefix="<?= e($storagePrefix) ?>"
    data-form-page-key="<?= e((string) ($inputPage['page_key'] ?? \Models\FormInputPage::DEFAULT_KEY)) ?>"
    data-form-dirty-alert="1"
    <?php if ($branchClientRules !== []): ?>
        data-branch-rules="<?= e(json_encode($branchClientRules, $branchJsonFlags)) ?>"
        data-branch-controlled-fields="<?= e(json_encode(array_values($branchControlledFieldKeys ?? []), $branchJsonFlags)) ?>"
        data-branch-controlled-groups="<?= e(json_encode(array_values($branchControlledGroupKeys ?? []), $branchJsonFlags)) ?>"
    <?php endif; ?>
    <?= $formDisabled ? ' inert' : '' ?>>
    <div class="wrapper">
        <div class="block is-contents">
            <?php if (!$formDisabled): ?>
                <?= \Core\Csrf::field() ?>
                <input type="hidden" name="input_page_key" value="<?= e((string) ($inputPage['page_key'] ?? \Models\FormInputPage::DEFAULT_KEY)) ?>">
            <?php endif; ?>

            <?php foreach (\Models\FormFieldGroup::childrenForParent($inputPageFields, $inputPageGroups, (string) ($inputPage['page_key'] ?? \Models\FormInputPage::DEFAULT_KEY), null) as $node): ?>
                <?php $renderFormNode($node, false); ?>
            <?php endforeach; ?>
        </div>

        <div class="block is-actions is-centered">
            <?php if ($previewMode && !$previewInteractive): ?>
                <button type="button" class="btn is-primary" disabled><?= e($confirmButtonText) ?></button>
            <?php elseif (!empty($site_resource_blocked)): ?>
                <button type="button" class="btn is-primary" disabled>現在ご利用いただけません</button>
            <?php else: ?>
                <?php if (!empty($canBackInput)): ?>
                    <button type="submit" name="_back_input" value="1" class="btn"><?= e($backButtonText) ?></button>
                <?php endif; ?>
                <button type="submit" class="btn is-primary"><?= e($confirmButtonText) ?></button>
            <?php endif; ?>
        </div>
    </div>
</form>
<?= render_form_description_blocks_at($descriptionBlocks, $descriptionEndPosition, $descriptionImageFormId) ?>
</section>
