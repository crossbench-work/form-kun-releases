<?php $storagePrefix = 'formkun-public:' . (string) ($form['slug'] ?? '') . ':'; ?>
<section class="l-formWrapper01" data-form-step="confirm">
        <?php $confirmBlocks = decode_form_description_blocks($form['confirm_message'] ?? '', true); ?>
        <?php $previewMode = !empty($previewMode); ?>
        <?php $formDisabled = $previewMode || !empty($site_resource_blocked); ?>
        <?php $confirmPageTitle = trim((string) ($form['confirm_page_title'] ?? '')) !== '' ? (string) $form['confirm_page_title'] : '入力内容のご確認'; ?>
        <?php $submitButtonText = trim((string) ($form['submit_button_text'] ?? '')) !== '' ? (string) $form['submit_button_text'] : '送信する'; ?>
        <?php $backButtonText = trim((string) ($form['back_button_text'] ?? '')) !== '' ? (string) $form['back_button_text'] : '入力に戻る'; ?>
        <?php if (!empty($form['show_confirm_page_title']) && $confirmPageTitle !== ''): ?>
        <h1 class="title"><?= e($confirmPageTitle) ?></h1>
        <?php endif; ?>
        <?= render_form_description_blocks_at($confirmBlocks, 0, (int) ($form['id'] ?? 0)) ?>

        <?php if (!empty($deliveryError)): ?>
        <div data-module="m-alert01" class="is-danger"><?= e((string) $deliveryError) ?></div>
        <?php endif; ?>

        <?php if (!empty($site_resource_blocked)): ?>
        <div data-module="m-alert01" class="is-danger">
            サイトの利用容量が上限に達しているため、現在送信できません。しばらくしてから再度お試しください。
        </div>
        <?php endif; ?>

<div data-module="c-formSet01" data-form-storage-prefix="<?= e($storagePrefix) ?>">
    <div class="wrapper">
<dl class="list is-confirm">
<?php foreach ($fields as $field):
    if (empty($field['visible']) || \Models\FormField::isDisplayOnlyType((string) ($field['type'] ?? ''))) {
        continue;
    }
    $key = $field['field_key'];
    $val = $values[$key] ?? '';
    if (!in_array($field['type'], ['address', 'text_pair', 'text_multi', \Models\FormField::TYPE_MATRIX], true) && is_array($val)) {
        $val = implode(', ', $val);
    }
?>
    <dt><?= e($field['label']) ?></dt>
    <dd>
    <?php if ($field['type'] === 'file'): ?>
        <?php if (!empty($fileMetas[$key]['original_name'])): ?>
            <?= e($fileMetas[$key]['original_name']) ?>
            （<?= e(\Core\Validator::formatBytes((int) ($fileMetas[$key]['size'] ?? 0))) ?>）
        <?php else: ?>
            <span data-module="m-text01" data-type="muted">（ファイルなし）</span>
        <?php endif; ?>
    <?php elseif ($field['type'] === 'address'): ?>
        <?php $addrText = format_address_value_display($val); ?>
        <?= $addrText !== '' ? nl2br(e($addrText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
    <?php elseif ($field['type'] === 'text_pair'): ?>
        <?php $pairText = format_text_pair_value_display($val, \Models\FormField::decodeTextPairLabels($field['options_json'] ?? null)); ?>
        <?= $pairText !== '' ? nl2br(e($pairText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
    <?php elseif ($field['type'] === 'text_multi'): ?>
        <?php $multiText = format_text_multi_value_display($val, \Models\FormField::decodeTextMultiItems($field['options_json'] ?? null, true)); ?>
        <?= $multiText !== '' ? nl2br(e($multiText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
    <?php elseif ($field['type'] === \Models\FormField::TYPE_MATRIX): ?>
        <?php $matrixText = format_matrix_value_display($val, \Models\FormField::decodeMatrixSettings($field['options_json'] ?? null)); ?>
        <?= $matrixText !== '' ? nl2br(e($matrixText)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
    <?php else: ?>
        <?= $val !== '' ? nl2br(e((string) $val)) : '<span data-module="m-text01" data-type="muted">（未入力）</span>' ?>
    <?php endif; ?>
    </dd>
<?php endforeach; ?>
</dl>

<form action="<?= e($formDisabled ? '#' : base_path('/f/' . $form['slug'] . '/submit')) ?>" method="post" data-form-storage-prefix="<?= e($storagePrefix) ?>" data-form-step="confirm-submit"<?= $formDisabled ? ' inert' : '' ?>>
    <?php if (!$formDisabled): ?>
        <?= \Core\Csrf::field() ?>
    <?php endif; ?>
    <div class="area is-actions is-centered">
        <?php if ($previewMode): ?>
            <button type="button" class="btn" disabled><?= e($backButtonText) ?></button>
            <button type="button" class="btn is-primary" disabled><?= e($submitButtonText) ?></button>
        <?php elseif (!empty($site_resource_blocked)): ?>
            <button type="button" class="btn" disabled><?= e($backButtonText) ?></button>
            <button type="button" class="btn is-primary" disabled>現在送信できません</button>
        <?php else: ?>
            <button type="submit" name="_back" value="1" class="btn"><?= e($backButtonText) ?></button>
            <button type="submit" class="btn is-primary"><?= e($submitButtonText) ?></button>
        <?php endif; ?>
    </div>
</form>
    </div>
</div>
        <?= render_form_description_blocks_at($confirmBlocks, 1, (int) ($form['id'] ?? 0)) ?>
</section>
