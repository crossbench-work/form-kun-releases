<?php

require_once APP_COMPONENTS_DIR . '/m-input01/m-input01.php';

$latest = is_array($manifest ?? null) ? (string) ($manifest['latest'] ?? '') : '';
$releases = is_array($manifest ?? null) ? ($manifest['releases'] ?? []) : [];
$requirements = is_array($requirements ?? null) ? $requirements : [];
$manualMaxBytes = \Core\AppUpdater::manualUploadMaxBytes();
$manualMaxLabel = $manualMaxBytes >= 1024 * 1024
    ? round($manualMaxBytes / (1024 * 1024), 1) . ' MB'
    : round($manualMaxBytes / 1024, 1) . ' KB';
?>
<div id="app-update">
<?php admin_c_form_block01_open(); ?>
            <div class="area is-title">
                <?php admin_m_large_title01('アプリ更新'); ?>
            </div>
            <div class="area is-field">
                <form method="post" action="<?= e(base_path('/admin/settings/update-config')) ?>">
                    <?= \Core\Csrf::field() ?>
                    <dl class="admin-settings-dl">
                        <dt>自己更新</dt>
                        <dd>
                            <label>
                                <input type="checkbox" name="update_enabled" value="1"<?= !empty($update_enabled) ? ' checked' : '' ?>>
                                有効にする
                            </label>
                            <?php if (empty($update_enabled_db_set)): ?>
                                <p class="text is-help">未保存のときは config.local.php の <code>update.enabled</code> が使われます。</p>
                            <?php endif; ?>
                        </dd>
                        <dt>manifest URL</dt>
                        <dd>
                            <?php admin_m_input01_open(); ?>
                                <?php admin_m_input01_input([
                                    'type' => 'url',
                                    'name' => 'update_manifest_url',
                                    'id' => 'update_manifest_url',
                                    'value' => (string) ($update_manifest_url ?? ''),
                                    'placeholder' => 'https://raw.githubusercontent.com/.../manifest.json',
                                    'autocomplete' => 'off',
                                ]); ?>
                            <?php admin_m_input01_close(); ?>
                            <?php if (empty($update_manifest_url_db_set)): ?>
                                <p class="text is-help">未保存のときは config.local.php の <code>update.manifest_url</code> が使われます。</p>
                            <?php endif; ?>
                        </dd>
                    </dl>
                    <p class="text is-help">HTTPS の manifest のみ利用できます。ZIP には環境設定を含めません。</p>
                    <p style="margin-top:1rem;">
                        <button type="submit" class="btn is-primary">更新設定を保存</button>
                    </p>
                </form>
            </div>
<?php admin_c_form_block01_close(); ?>

<?php admin_c_form_block01_open(); ?>
            <div class="area is-title">
                <?php admin_m_large_title01('リリース'); ?>
            </div>
            <div class="area is-field">
                <dl class="admin-settings-dl">
                    <dt>現在のバージョン</dt>
                    <dd><code><?= e((string) ($currentVersion ?? '')) ?></code></dd>
                    <?php if ($latest !== '' && $latest !== ($currentVersion ?? '')): ?>
                        <dt>最新リリース</dt>
                        <dd><code><?= e($latest) ?></code></dd>
                    <?php endif; ?>
                    <dt>ZipArchive</dt>
                    <dd><?= !empty($requirements['zip']) ? '利用可' : '不可（サーバー拡張が必要）' ?></dd>
                </dl>

                <?php if (($manifestError ?? '') !== ''): ?>
                    <p class="text is-danger"><?= e($manifestError) ?></p>
                <?php endif; ?>

                <?php if (is_array($manifest) && $releases !== []): ?>
                    <h3 class="title is-sm">利用可能なリリース（channel: <?= e((string) ($manifest['channel'] ?? '')) ?>）</h3>
                    <table class="m-table01">
                        <thead>
                            <tr><th>版</th><th>日付</th><th>メモ</th><th></th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($releases as $row): ?>
                                <?php if (!is_array($row)) continue; ?>
                                <tr>
                                    <td><code><?= e((string) ($row['version'] ?? '')) ?></code></td>
                                    <td><?= e((string) ($row['released_at'] ?? '')) ?></td>
                                    <td><?= e((string) ($row['notes'] ?? '')) ?></td>
                                    <td>
                                        <?php if (!empty($requirements['enabled']) && !empty($requirements['zip']) && ($row['version'] ?? '') !== ($currentVersion ?? '')): ?>
                                            <form method="post" action="<?= e(base_path('/admin/settings/update')) ?>" onsubmit="return confirm('バージョン <?= e((string) $row['version']) ?> に更新します。よろしいですか？');">
                                                <?= \Core\Csrf::field() ?>
                                                <input type="hidden" name="version" value="<?= e((string) $row['version']) ?>">
                                                <button type="submit" class="btn is-primary is-sm">この版に更新</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text is-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php elseif (!empty($requirements['enabled']) && ($manifestError ?? '') === ''): ?>
                    <p class="text is-muted">manifest を取得できませんでした。</p>
                <?php elseif (empty($requirements['enabled'])): ?>
                    <p class="text is-muted">自己更新を有効にし manifest URL を保存すると、リリース一覧を表示します。</p>
                <?php endif; ?>
            </div>
<?php admin_c_form_block01_close(); ?>

<div id="app-update-manual">
<?php admin_c_form_block01_open(); ?>
            <div class="area is-title">
                <?php admin_m_large_title01('手動アップロード'); ?>
            </div>
            <div class="area is-field">
                <p class="text is-help">管理者は <code>update.enabled</code> がオフでも利用できます。<code>npm run release</code> で作成した ZIP（<code>dist/</code> 直下を zip したもの）をアップロードしてください。<code>app/config.local.php</code> と <code>uploads/</code> は上書きしません。</p>
                <?php if (empty($requirements['zip'])): ?>
                    <p class="text is-danger">ZipArchive 拡張が無効のため、手動アップロードは利用できません。</p>
                <?php else: ?>
                    <form method="post" action="<?= e(base_path('/admin/settings/update-upload')) ?>" enctype="multipart/form-data" onsubmit="return confirm('ZIP の内容でアプリを更新します。よろしいですか？');">
                        <?= \Core\Csrf::field() ?>
                        <div data-module="c-updateUpload01">
                            <?php admin_c_update_upload01_zone(); ?>
                        </div>
                        <dl class="admin-settings-dl" style="margin-top:1rem;">
                            <dt>版（任意）</dt>
                            <dd>
                                <?php admin_m_input01_open(); ?>
                                    <?php admin_m_input01_input([
                                        'type' => 'text',
                                        'name' => 'version',
                                        'id' => 'update_manual_version',
                                        'value' => '',
                                        'placeholder' => '0.1.0（空なら ZIP 名または ZIP 内の version から推定）',
                                        'autocomplete' => 'off',
                                        'pattern' => '[0-9A-Za-z][0-9A-Za-z._-]*',
                                    ]); ?>
                                <?php admin_m_input01_close(); ?>
                            </dd>
                        </dl>
                        <p class="text is-help">ZIP の上限: <?= e($manualMaxLabel) ?>。サーバーの <code>upload_max_filesize</code> / <code>post_max_size</code> がこれより小さい場合は、PHP 設定の引き上げが必要です。</p>
                        <p style="margin-top:1rem;">
                            <button type="submit" class="btn is-primary">ZIP を適用して更新</button>
                        </p>
                    </form>
                <?php endif; ?>
            </div>
<?php admin_c_form_block01_close(); ?>
</div>
</div>
