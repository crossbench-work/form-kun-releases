<?php
// src/admin/index.php
// 管理画面のエントリポイント

define('FORMKUN_BOOT', true);
define('FORMKUN_AREA', 'admin');

require __DIR__ . '/../app/bootstrap.php';

$router = new \Core\Router('/admin');

// 認証
$router->get('/login',  fn() => (new \Controllers\Admin\AuthController())->loginForm());
$router->post('/login', fn() => (new \Controllers\Admin\AuthController())->login());
$router->post('/logout', fn() => (new \Controllers\Admin\AuthController())->logout());
// 外部サイトのリンク・画像からログアウトさせられないよう、GET ではログアウトしない。
$router->get('/logout', fn() => redirect('/admin/'));

$router->get('/account', fn() => (new \Controllers\Admin\AccountController())->index());
$router->post('/account', fn() => (new \Controllers\Admin\AccountController())->update());

$webauthn = new \Controllers\Admin\WebAuthnController();
$router->post('/webauthn/login/options', fn() => $webauthn->loginOptions());
$router->post('/webauthn/login/verify', fn() => $webauthn->loginVerify());
$router->post('/webauthn/register/options', fn() => $webauthn->registerOptions());
$router->post('/webauthn/register/verify', fn() => $webauthn->registerVerify());
$router->post('/webauthn/credentials/{id}/delete', fn($p) => $webauthn->deleteCredential((int) $p['id']));

// パスワード再設定（メール）
$router->get('/forgot-password',  fn() => (new \Controllers\Admin\AuthController())->forgotForm());
$router->post('/forgot-password', fn() => (new \Controllers\Admin\AuthController())->forgotSubmit());
$router->get('/reset-password',   fn() => (new \Controllers\Admin\AuthController())->resetForm());
$router->post('/reset-password',  fn() => (new \Controllers\Admin\AuthController())->resetSubmit());

// 初期セットアップ（初回管理者作成）
$router->get('/setup',  fn() => (new \Controllers\Admin\SetupController())->show());
$router->post('/setup', fn() => (new \Controllers\Admin\SetupController())->create());

// ダッシュボード
$router->get('/',  fn() => (new \Controllers\Admin\DashboardController())->index());
$router->get('',   fn() => (new \Controllers\Admin\DashboardController())->index());

// 全体設定（サイトは config 参照、フォーム作成上限は DB・管理者のみ更新可）
$router->get('/settings', fn() => (new \Controllers\Admin\SettingsController())->index());
$router->post('/settings', fn() => (new \Controllers\Admin\SettingsController())->update());
$router->post('/settings/site-resource', fn() => (new \Controllers\Admin\SettingsController())->updateSiteResource());
$router->post('/settings/display', fn() => (new \Controllers\Admin\SettingsController())->updateDisplay());
$router->post('/settings/admin-name', fn() => (new \Controllers\Admin\SettingsController())->updateAdminName());
$router->post('/settings/logo', fn() => (new \Controllers\Admin\SettingsController())->updateLogo());
$router->post('/settings/logo/reset', fn() => (new \Controllers\Admin\SettingsController())->resetLogo());
$router->post('/settings/timezone', fn() => (new \Controllers\Admin\SettingsController())->updateTimezone());
$router->post('/settings/holidays', fn() => (new \Controllers\Admin\SettingsController())->updateHolidays());
$router->post('/settings/holidays/fetch', fn() => (new \Controllers\Admin\SettingsController())->fetchHolidays());
$router->post('/settings/submission-purge-schedule', fn() => (new \Controllers\Admin\SettingsController())->updateSubmissionPurgeSchedule());
$router->post('/settings/versioning', fn() => (new \Controllers\Admin\SettingsController())->updateVersioning());
$router->post('/settings/templates', fn() => (new \Controllers\Admin\SettingsController())->storeTemplate());
$router->post('/settings/templates/{id}', fn($p) => (new \Controllers\Admin\SettingsController())->updateTemplate((int)$p['id']));
$router->post('/settings/templates/{id}/delete', fn($p) => (new \Controllers\Admin\SettingsController())->deleteTemplate((int)$p['id']));
$router->get('/settings/templates/{id}/json', fn($p) => (new \Controllers\Admin\SettingsController())->templateJson((string)$p['id']));
$router->post('/settings/backup/export', fn() => (new \Controllers\Admin\SettingsController())->exportBackup());
$router->post('/settings/backup/import', fn() => (new \Controllers\Admin\SettingsController())->importBackup());
$lineSettings = static fn() => new \Controllers\Admin\LineSettingsController();
$router->post('/settings/line/channel-secret', fn() => $lineSettings()->saveCredential('secret'));
$router->post('/settings/line/channel-secret/delete', fn() => $lineSettings()->saveCredential('delete_secret'));
$router->post('/settings/line/channel-access-token', fn() => $lineSettings()->saveCredential('token'));
$router->post('/settings/line/channel-access-token/delete', fn() => $lineSettings()->saveCredential('delete_token'));
$router->post('/settings/line/setup-checklist', fn() => $lineSettings()->updateLineSetupChecklist());
$router->post('/settings/line/talk-setup-checklist', fn() => $lineSettings()->syncLineTalkSendSetupChecklist());
$router->post('/settings/line/webhook-targets/delete', fn() => $lineSettings()->deleteLineWebhookTarget());
$router->post('/settings/line/push-to-id', fn() => $lineSettings()->savePushToId());
$router->post('/settings/line/test-line', fn() => $lineSettings()->testLine());
$router->post('/settings/line/diagnose-image-preview', fn() => $lineSettings()->diagnoseImagePreview());
$router->post('/settings/line/account-unlink', fn() => $lineSettings()->resetAccountLink());

$router->get('/settings/update', fn() => (new \Controllers\Admin\SystemUpdateController())->index());
$router->post('/settings/update', fn() => (new \Controllers\Admin\SystemUpdateController())->run());
$router->post('/settings/update-check', fn() => (new \Controllers\Admin\SystemUpdateController())->check());
$router->post('/settings/update-upload', fn() => (new \Controllers\Admin\SystemUpdateController())->upload());

// フォーム管理
$router->get('/forms',                  fn() => (new \Controllers\Admin\FormController())->index());
$router->get('/forms/new',              fn() => (new \Controllers\Admin\FormController())->createForm());
$router->get('/forms/import',           fn() => (new \Controllers\Admin\FormController())->importForm());
$router->post('/forms/import',          fn() => (new \Controllers\Admin\FormController())->importBundle());
$router->post('/forms',                 fn() => (new \Controllers\Admin\FormController())->store());
$router->post('/forms/preview-input',   fn() => (new \Controllers\Admin\FormController())->previewInput());
$router->post('/forms/preview-confirm', fn() => (new \Controllers\Admin\FormController())->previewConfirm());
$router->post('/forms/preview-thanks',  fn() => (new \Controllers\Admin\FormController())->previewThanks());
$router->post('/forms/preview-closed',  fn() => (new \Controllers\Admin\FormController())->previewClosed());
$router->get('/forms/{id}/edit',        fn($p) => (new \Controllers\Admin\FormController())->edit((int)$p['id']));
$router->get('/forms/{id}/versions',    fn($p) => (new \Controllers\Admin\FormController())->versions((int)$p['id']));
$router->post('/forms/{id}',            fn($p) => (new \Controllers\Admin\FormController())->update((int)$p['id']));
$router->post('/forms/{id}/test-smtp',  fn($p) => (new \Controllers\Admin\FormController())->testSmtp((int)$p['id']));
$router->post('/forms/{id}/line/test-message', fn($p) => (new \Controllers\Admin\FormController())->testLineMessage((int)$p['id']));
$router->post('/forms/{id}/line/channel-secret', fn($p) => (new \Controllers\Admin\FormController())->saveLineChannelSecret((int)$p['id']));
$router->post('/forms/{id}/line/channel-secret/delete', fn($p) => (new \Controllers\Admin\FormController())->deleteLineChannelSecret((int)$p['id']));
$router->post('/forms/{id}/line/channel-access-token', fn($p) => (new \Controllers\Admin\FormController())->saveLineChannelAccessToken((int)$p['id']));
$router->post('/forms/{id}/line/channel-access-token/delete', fn($p) => (new \Controllers\Admin\FormController())->deleteLineChannelAccessToken((int)$p['id']));
$router->post('/forms/{id}/line/step-3', fn($p) => (new \Controllers\Admin\FormController())->saveLineStep3((int)$p['id']));
$router->post('/forms/{id}/line/notify-settings', fn($p) => (new \Controllers\Admin\FormController())->saveLineNotifySettings((int)$p['id']));
$router->get('/forms/{id}/retention-preview', fn($p) => (new \Controllers\Admin\FormController())->retentionPreview((int)$p['id']));
$router->post('/forms/{id}/versions/{versionId}/pin', fn($p) => (new \Controllers\Admin\FormController())->toggleVersionPin((int)$p['id'], (int)$p['versionId']));
$router->post('/forms/{id}/versions/{versionId}/restore', fn($p) => (new \Controllers\Admin\FormController())->restoreVersion((int)$p['id'], (int)$p['versionId']));
$router->post('/forms/{id}/versions/{versionId}/delete', fn($p) => (new \Controllers\Admin\FormController())->deleteVersion((int)$p['id'], (int)$p['versionId']));
$router->post('/forms/{id}/duplicate',  fn($p) => (new \Controllers\Admin\FormController())->duplicate((int)$p['id']));
$router->get('/forms/{id}/export',      fn($p) => (new \Controllers\Admin\FormController())->exportFormPage((int)$p['id']));
$router->post('/forms/{id}/export',     fn($p) => (new \Controllers\Admin\FormController())->exportBundle((int)$p['id']));
$router->post('/forms/{id}/delete',     fn($p) => (new \Controllers\Admin\FormController())->destroy((int)$p['id']));

// 送信履歴
$router->get('/forms/{id}/submissions', fn($p) => (new \Controllers\Admin\SubmissionController())->index((int)$p['id']));
$router->post('/forms/{id}/submissions/bulk-delete', fn($p) => (new \Controllers\Admin\SubmissionController())->bulkDelete((int)$p['id']));
$router->get('/forms/{id}/submissions/export', fn($p) => (new \Controllers\Admin\SubmissionController())->exportPage((int)$p['id']));
$router->get('/forms/{id}/submissions/export/{token}/download', fn($p) => (new \Controllers\Admin\SubmissionController())->downloadExport((int)$p['id'], (string)$p['token']));
$router->post('/forms/{id}/submissions/export/{token}/delete', fn($p) => (new \Controllers\Admin\SubmissionController())->deleteExport((int)$p['id'], (string)$p['token']));
$router->post('/forms/{id}/submissions/export', fn($p) => (new \Controllers\Admin\SubmissionController())->exportByPeriod((int)$p['id']));
$router->get('/forms/{id}/submissions/import', fn($p) => (new \Controllers\Admin\SubmissionImportController())->uploadForm((int)$p['id']));
$router->post('/forms/{id}/submissions/import', fn($p) => (new \Controllers\Admin\SubmissionImportController())->upload((int)$p['id']));
$router->get('/forms/{id}/submissions/import/{token}/submissions/{index}/files/{fileIndex}', fn($p) => (new \Controllers\Admin\SubmissionImportController())->previewFile((int)$p['id'], (string)$p['token'], (int)$p['index'], (int)$p['fileIndex']));
$router->get('/forms/{id}/submissions/import/{token}/submissions/{index}', fn($p) => (new \Controllers\Admin\SubmissionImportController())->previewShow((int)$p['id'], (string)$p['token'], (int)$p['index']));
$router->get('/forms/{id}/submissions/import/{token}', fn($p) => (new \Controllers\Admin\SubmissionImportController())->preview((int)$p['id'], (string)$p['token']));
$router->post('/forms/{id}/submissions/import/{token}/commit', fn($p) => (new \Controllers\Admin\SubmissionImportController())->commit((int)$p['id'], (string)$p['token']));
$router->post('/forms/{id}/submissions/import/{token}/discard', fn($p) => (new \Controllers\Admin\SubmissionImportController())->discard((int)$p['id'], (string)$p['token']));
$router->post('/forms/{id}/submissions/export-csv', fn($p) => (new \Controllers\Admin\SubmissionController())->exportCsv((int)$p['id']));
$router->get('/forms/submissions/{id}', fn($p) => (new \Controllers\Admin\SubmissionController())->show((int)$p['id']));
$router->post('/forms/submissions/{id}/delete', fn($p) => (new \Controllers\Admin\SubmissionController())->destroy((int)$p['id']));
$router->post('/forms/submissions/{id}/status', fn($p) => (new \Controllers\Admin\SubmissionController())->updateStatus((int)$p['id']));
$router->get('/files/{id}',             fn($p) => (new \Controllers\Admin\SubmissionController())->download((int)$p['id']));

// ユーザー管理
$router->get('/users',                fn() => (new \Controllers\Admin\UserController())->index());
$router->get('/users/new',            fn() => (new \Controllers\Admin\UserController())->createForm());
$router->post('/users',               fn() => (new \Controllers\Admin\UserController())->store());
$router->get('/users/{id}/edit',      fn($p) => (new \Controllers\Admin\UserController())->edit((int)$p['id']));
$router->post('/users/{id}',          fn($p) => (new \Controllers\Admin\UserController())->update((int)$p['id']));
$router->post('/users/{id}/delete',   fn($p) => (new \Controllers\Admin\UserController())->destroy((int)$p['id']));

$router->dispatch();
