<!doctype html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=0.9">
<meta name="robots" content="noindex,nofollow">
<title><?= e($title ?? '管理画面') ?> | <?= e(effective_site_admin_name()) ?></title>
<link rel="stylesheet" href="<?= e(base_path('/assets/css/admin.css')) ?>">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.min.css">
<script>
window.FORMKUN_BASE = <?= json_encode(base_path(''), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE | JSON_HEX_APOS) ?>;
</script>
<script defer src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script defer src="https://code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
<script defer src="<?= e(base_path('/assets/js/vendor/tom-select.complete.min.js')) ?>"></script>
<script defer src="<?= e(base_path('/assets/js/admin-pickers.js')) ?>"></script>
<script defer src="<?= e(base_path('/assets/js/public-form.js')) ?>"></script>
<script defer src="<?= e(base_path('/assets/js/admin.js')) ?>"></script>
</head>
<body <?= admin_l_admin_shell01_body_attrs() ?>>
<?php
require_once __DIR__ . '/admin_components.php';
$__adminContainerAfterMain = (string) ($GLOBALS['formkun_admin_container_after_main'] ?? '');
unset($GLOBALS['formkun_admin_container_after_main']);
?>
<?php admin_l_admin_container01_open(); ?>
    <?php admin_c_admin_header01(); ?>

    <?php admin_l_admin_body01_open(); ?>
        <?= $content ?? '' ?>
    <?php admin_l_admin_body01_close(); ?>
    <?= $__adminContainerAfterMain ?>
<?php admin_l_admin_container01_close(); ?>
<?php admin_c_admin_toast01_stack_open(); ?>
<?php foreach ((flash() ?? []) as $f): ?>
    <?php admin_c_admin_toast01((string) $f['message'], (string) $f['type'], ['data-admin-autotoast' => true]); ?>
<?php endforeach; ?>
<?php admin_c_admin_toast01_stack_close(); ?>
</body>
</html>
