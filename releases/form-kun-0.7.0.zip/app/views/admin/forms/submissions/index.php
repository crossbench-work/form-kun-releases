<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
$bulkFormId = 'submission-bulk-action-form';
$listPath = '/admin/forms/' . (int) $form['id'] . '/submissions';
$listQuery = [];
if ($q !== '') {
    $listQuery['q'] = $q;
}
if ($from !== '') {
    $listQuery['from'] = $from;
}
if ($to !== '') {
    $listQuery['to'] = $to;
}
if (($statusFilter ?? '') !== '') {
    $listQuery['status'] = $statusFilter;
}
if ((int) $page > 1) {
    $listQuery['page'] = (int) $page;
}
$listRedirect = $listPath . ($listQuery !== [] ? '?' . http_build_query($listQuery) : '');
$hasMailOnlyRows = !empty(array_filter($rows ?? [], static fn(array $row): bool => \Models\Submission::isMailOnlyMetadata($row)));
$submissionReadOnly = !empty($submission_read_only);
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-field">
                                <?php require __DIR__ . '/_retention_notice.php'; ?>
                                <form method="get" action="<?= e(base_path('/admin/forms/' . $form['id'] . '/submissions')) ?>" data-module="m-toolbar01">
                                    <?php admin_m_input01_open(); ?>
                                        <?php admin_m_input01_input([
                                            'type' => 'text',
                                            'name' => 'q',
                                            'value' => (string) $q,
                                            'placeholder' => 'キーワード検索（送信内容）',
                                            'style' => 'width:280px',
                                        ]); ?>
                                    <?php admin_m_input01_close(); ?>
                                    <?php admin_m_bold_title01(e('期間'), 'submissions-from'); ?>
                                    <?php admin_m_input01_open(); ?>
                                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-from', [
                                            'type' => 'date',
                                            'id' => 'submissions-from',
                                            'name' => 'from',
                                            'value' => (string) $from,
                                        ])); ?>
                                    <?php admin_m_input01_close(); ?>
                                    <?php admin_m_bold_title01(e('〜'), 'submissions-to'); ?>
                                    <?php admin_m_input01_open(); ?>
                                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submissions-to', [
                                            'type' => 'date',
                                            'id' => 'submissions-to',
                                            'name' => 'to',
                                            'value' => (string) $to,
                                        ])); ?>
                                    <?php admin_m_input01_close(); ?>
                                    <?php admin_m_input01_open(); ?>
                                        <select name="status" class="m-inout01__input" aria-label="状態で絞り込み" style="width:auto;min-width:120px">
                                            <option value="">状態: すべて</option>
                                            <?php foreach ($workflowStatusOptions as $statusOpt): ?>
                                                <option value="<?= e($statusOpt) ?>"<?= ($statusFilter ?? '') === $statusOpt ? ' selected' : '' ?>>
                                                    <?= e(\Models\Submission::workflowStatusLabel($statusOpt)) ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    <?php admin_m_input01_close(); ?>
                                    <button class="btn" type="submit">検索</button>
                                    <?php if ($q !== '' || $from !== '' || $to !== '' || ($statusFilter ?? '') !== ''): ?>
                                        <a class="btn" href="<?= e(base_path('/admin/forms/' . $form['id'] . '/submissions')) ?>">リセット</a>
                                    <?php endif; ?>
                                    <span class="spacer"></span>
                                    <span data-module="m-text01" data-type="muted"><?= number_format($total) ?>件</span>
                                    <?php if (!$submissionReadOnly): ?>
                                    <?php $exportPeriod = array_filter(['from' => (string) $from, 'to' => (string) $to], static fn(string $v): bool => $v !== ''); ?>
                                    <a class="btn" href="<?= e(base_path($listPath . '/export' . ($exportPeriod !== [] ? '?' . http_build_query($exportPeriod) : ''))) ?>">エクスポート</a>
                                    <a class="btn" href="<?= e(base_path($listPath . '/import')) ?>">インポート</a>
                                    <?php endif; ?>
                                </form>

                                <?php if (empty($rows)): ?>
                                    <p data-module="m-text01" data-type="muted">該当する送信がありません。</p>
                                <?php else: ?>
                                    <?php if (!$submissionReadOnly): ?>
                                    <form method="post"
                                          action="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/submissions/bulk-delete')) ?>"
                                          id="<?= e($bulkFormId) ?>"
                                          data-module="m-submissionBulkAction01"
                                          data-delete-action="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/submissions/bulk-delete')) ?>"
                                          data-export-action="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/submissions/export-csv')) ?>">
                                        <?= \Core\Csrf::field() ?>
                                        <input type="hidden" name="redirect_to" value="<?= e($listRedirect) ?>">
                                        <div data-module="m-toolbar01">
                                            <span data-module="m-text01" data-type="muted" data-target="m-submissionBulkAction01__count">0件選択中</span>
                                            <?php admin_m_input01_open(); ?>
                                                <select name="bulk_action"
                                                        class="m-inout01__input"
                                                        aria-label="一括操作を選択"
                                                        data-target="m-submissionBulkAction01__action"
                                                        style="width:auto;min-width:150px">
                                                    <option value="">一括操作を選択</option>
                                                    <option value="delete">削除</option>
                                                    <option value="export_csv">CSV書き出し</option>
                                                </select>
                                            <?php admin_m_input01_close(); ?>
                                            <?php admin_m_input01_open(); ?>
                                                <?php admin_m_input01_input([
                                                    'type' => 'text',
                                                    'name' => 'export_filename',
                                                    'maxlength' => 100,
                                                    'placeholder' => 'ファイル名（空欄なら 期間_フォーム名）',
                                                    'aria-label' => 'CSV書き出しのファイル名',
                                                    'style' => 'width:280px',
                                                    'data-target' => 'm-submissionBulkAction01__filename',
                                                    'hidden' => true,
                                                ]); ?>
                                            <?php admin_m_input01_close(); ?>
                                            <button class="btn" type="submit" data-target="m-submissionBulkAction01__submit" disabled>実行</button>
                                        </div>
                                    </form>
                                    <?php endif; ?>

                                    <?php admin_m_table01_open(); ?>
                                        <thead>
                                            <tr>
                                                <?php if (!$submissionReadOnly): ?>
                                                <th>
                                                    <input type="checkbox"
                                                           value="1"
                                                           aria-label="一覧の送信をすべて選択"
                                                           data-target="m-submissionBulkAction01__selectAll"
                                                           data-bulk-form="<?= e($bulkFormId) ?>">
                                                </th>
                                                <?php endif; ?>
                                                <th>受信日時</th>
                                                <th>状態</th>
                                                <?php if ($hasMailOnlyRows): ?>
                                                    <th>保存方式</th>
                                                    <th>SMTP配送</th>
                                                    <th>添付</th>
                                                <?php endif; ?>
                                                <?php foreach ($previewKeys as $key):
                                                    $label = '';
                                                    foreach ($fields as $f) { if ($f['field_key'] === $key) { $label = $f['label']; break; } }
                                                ?>
                                                    <th><?= e($label ?: $key) ?></th>
                                                <?php endforeach; ?>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php foreach ($rows as $r):
                                            $workflowStatus = (string) ($r['workflow_status'] ?? \Models\Submission::WORKFLOW_PENDING);
                                        ?>
                                            <tr>
                                                <?php if (!$submissionReadOnly): ?>
                                                <td>
                                                    <input type="checkbox"
                                                           name="submission_ids[]"
                                                           value="<?= e((string) $r['id']) ?>"
                                                           form="<?= e($bulkFormId) ?>"
                                                           aria-label="送信ID <?= e((string) $r['id']) ?> を選択"
                                                           data-target="m-submissionBulkAction01__checkbox"
                                                           data-bulk-form="<?= e($bulkFormId) ?>">
                                                </td>
                                                <?php endif; ?>
                                                <td>
                                                    <?php if (!empty($retentionEnabled) && \Models\Form::isSubmissionExpired($form, (string) $r['submitted_at'], $retentionCutoff)): ?>
                                                        <?php admin_m_warning_mark01($retentionWarningText); ?>
                                                    <?php endif; ?>
                                                    <a href="<?= e(base_path('/admin/forms/submissions/' . $r['id'])) ?>">
                                                        <?= e($r['submitted_at']) ?>
                                                    </a>
                                                </td>
                                                <td class="is-workflow-status">
                                                    <?php if ($submissionReadOnly): ?>
                                                        <?php admin_m_badge01(\Models\Submission::workflowStatusLabel($workflowStatus), $workflowStatus); ?>
                                                    <?php else: ?>
                                                    <form method="post" action="<?= e(base_path('/admin/forms/submissions/' . $r['id'] . '/status')) ?>" data-module="m-submissionWorkflowStatus01">
                                                        <?= \Core\Csrf::field() ?>
                                                        <select name="status" data-target="m-submissionWorkflowStatus01__select" class="is-<?= e($workflowStatus) ?>" aria-label="状態を変更" onchange="this.form.submit()">
                                                            <?php foreach ($workflowStatusOptions as $statusOpt): ?>
                                                                <option value="<?= e($statusOpt) ?>"<?= $workflowStatus === $statusOpt ? ' selected' : '' ?>>
                                                                    <?= e(\Models\Submission::workflowStatusLabel($statusOpt)) ?>
                                                                </option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </form>
                                                    <?php endif; ?>
                                                </td>
                                                <?php if ($hasMailOnlyRows): ?>
                                                    <?php if (\Models\Submission::isMailOnlyMetadata($r)): ?>
                                                        <td>SMTPメールのみ</td>
                                                        <td><?= e(\Models\Submission::mailDeliveryStatusLabel((string) ($r['mail_delivery_status'] ?? 'success'))) ?></td>
                                                        <td><?= number_format((int) ($r['attachment_count'] ?? 0)) ?>件 / <?= e(\Core\Validator::formatBytes((int) ($r['attachment_total_bytes'] ?? 0))) ?></td>
                                                    <?php else: ?>
                                                        <td>DB保存</td><td>—</td><td>—</td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                <?php
                                                    $listPreviewRow = $r;
                                                    require __DIR__ . '/_list_preview_cells.php';
                                                ?>
                                                <td class="is-actions">
                                                    <details class="c-tableActionMenu01">
                                                        <summary class="c-tableActionMenu01__toggle" aria-label="操作">
                                                            <span aria-hidden="true">⋯</span>
                                                        </summary>
                                                        <div class="c-tableActionMenu01__menu" role="menu" aria-label="操作">
                                                            <a role="menuitem" href="<?= e(base_path('/admin/forms/submissions/' . $r['id'])) ?>">詳細</a>
                                                            <?php if (!$submissionReadOnly): ?>
                                                            <form method="post"
                                                                  action="<?= e(base_path('/admin/forms/submissions/' . $r['id'] . '/delete')) ?>"
                                                                  onsubmit="return confirm('この送信を削除しますか？');">
                                                                <?= \Core\Csrf::field() ?>
                                                                <?php admin_m_delete_btn01('admin-submission-delete-' . $r['id'], '削除', '削除', 'submit', '削除'); ?>
                                                            </form>
                                                            <?php endif; ?>
                                                        </div>
                                                    </details>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    <?php admin_m_table01_close(); ?>

                                    <?php if ($totalPages > 1): ?>
                                    <?php admin_c_pagination01_open(); ?>
                                        <?php
                                            $qs = function (int $p) use ($q, $from, $to, $statusFilter) {
                                                $params = ['page' => $p];
                                                if ($q !== '')    $params['q'] = $q;
                                                if ($from !== '') $params['from'] = $from;
                                                if ($to !== '')   $params['to'] = $to;
                                                if (($statusFilter ?? '') !== '') {
                                                    $params['status'] = $statusFilter;
                                                }
                                                return '?' . http_build_query($params);
                                            };
                                            $base = base_path('/admin/forms/' . $form['id'] . '/submissions');
                                        ?>
                                        <?php if ($page > 1): ?>
                                            <a href="<?= e($base . $qs($page - 1)) ?>">‹ 前へ</a>
                                        <?php else: ?>
                                            <span class="disabled">‹ 前へ</span>
                                        <?php endif; ?>

                                        <?php for ($p = max(1, $page - 3); $p <= min($totalPages, $page + 3); $p++): ?>
                                            <?php if ($p === $page): ?>
                                                <span class="current"><?= $p ?></span>
                                            <?php else: ?>
                                                <a href="<?= e($base . $qs($p)) ?>"><?= $p ?></a>
                                            <?php endif; ?>
                                        <?php endfor; ?>

                                        <?php if ($page < $totalPages): ?>
                                            <a href="<?= e($base . $qs($page + 1)) ?>">次へ ›</a>
                                        <?php else: ?>
                                            <span class="disabled">次へ ›</span>
                                        <?php endif; ?>
                                    <?php admin_c_pagination01_close(); ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
<?php admin_c_form_block01_close(); ?>
