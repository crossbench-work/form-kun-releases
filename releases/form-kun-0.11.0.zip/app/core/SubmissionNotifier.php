<?php
namespace Core;

use Models\Form;

class SubmissionNotifier
{
    /** @param array<int, array<string, mixed>> $fields */
    public static function send(array $form, array $fields, array $values): bool
    {
        try {
            return self::sendInternal($form, $fields, $values);
        } catch (\Throwable $e) {
            error_log('[formkun] submission notification failed for form ' . (int) ($form['id'] ?? 0));
            return false;
        }
    }

    /**
     * メール送信のみモード。管理者全宛先のSMTP受理を必須とし、自動返信は結果を分けて返す。
     *
     * @return array{admin_success:bool,reply_success:bool}
     */
    public static function sendMailOnly(array $form, array $fields, array $values, array $attachments, string $messageId): array
    {
        $context = ['submitted_at' => date('Y-m-d H:i:s'), 'form_title' => $form['title'], 'ip' => client_ip()];
        $admins = array_values(array_filter(array_map('trim', preg_split('/[,;]+/', (string) ($form['admin_emails'] ?? '')) ?: [])));
        $subject = !empty($form['mail_subject_admin']) ? (string) $form['mail_subject_admin'] : '[' . $form['title'] . '] 新規送信';
        $template = !empty($form['mail_template_admin']) ? (string) $form['mail_template_admin']
            : "フォーム「{{__form_title__}}」に新しい送信がありました。\n受信日時: {{__submitted_at__}}\nIP: {{__ip__}}\n\n{{__all__}}";
        $adminSuccess = Mailer::sendSmtpAll(
            $admins,
            Mailer::renderSubjectTemplate($subject, $fields, $values, $context),
            Mailer::renderTemplate($template, $fields, $values, $context),
            $attachments,
            $messageId,
            self::mailConfig($form)
        );
        if (!$adminSuccess) {
            return ['admin_success' => false, 'reply_success' => true];
        }

        $replySuccess = true;
        if (!empty($form['reply_enabled']) && !empty($form['reply_from_field_key'])) {
            $recipients = [];
            foreach (Form::replyFieldKeys($form['reply_from_field_key']) as $fieldKey) {
                $to = $values[$fieldKey] ?? null;
                if (is_array($to)) { $to = reset($to); }
                $to = is_string($to) ? trim($to) : '';
                if ($to !== '' && filter_var($to, FILTER_VALIDATE_EMAIL)) { $recipients[$to] = $to; }
            }
            if ($recipients !== []) {
                $replySubject = Mailer::renderSubjectTemplate((string) ($form['reply_subject'] ?? '送信ありがとうございました'), $fields, $values, $context);
                $replyBody = Mailer::renderTemplate((string) ($form['reply_template'] ?? "お問い合わせいただきありがとうございました。\n以下の内容で受け付けました。\n\n{{__all__}}"), $fields, $values, $context);
                foreach (array_values($recipients) as $recipient) {
                    $sent = Mailer::send(
                        $recipient, $replySubject, $replyBody,
                        ['Message-ID' => '<reply-' . preg_replace('/[^a-zA-Z0-9._-]+/', '', $messageId) . '@formkun>'],
                        self::mailConfig($form)
                    );
                    $replySuccess = $sent && $replySuccess;
                }
            }
        }
        return ['admin_success' => true, 'reply_success' => $replySuccess];
    }

    public static function sendSmtpTest(array $form): bool
    {
        $admins = array_values(array_filter(array_map('trim', preg_split('/[,;]+/', (string) ($form['admin_emails'] ?? '')) ?: [])));
        $first = $admins[0] ?? '';
        if ($first === '') {
            return false;
        }
        return Mailer::sendSmtpAll(
            [$first],
            '[ふぉーむくん] SMTPテスト',
            "SMTP設定のテストメールです。\nこのメールを受信できた場合、現在の設定でSMTP送信できます。",
            [],
            'smtp-test-' . bin2hex(random_bytes(12)),
            self::mailConfig($form)
        );
    }

    /** @param array<int, array<string, mixed>> $fields */
    private static function sendInternal(array $form, array $fields, array $values): bool
    {
        if (strtolower(trim((string) ($form['mail_transport'] ?? ''))) === 'none') {
            return true;
        }
        $context = [
            'submitted_at' => date('Y-m-d H:i:s'),
            'form_title' => $form['title'],
            'ip' => client_ip(),
        ];
        $mailConfig = self::mailConfig($form);
        $ok = true;

        $admins = array_filter(array_map('trim', preg_split('/[,;]+/', (string) ($form['admin_emails'] ?? '')) ?: []));
        if ($admins !== []) {
            $subject = !empty($form['mail_subject_admin']) ? (string) $form['mail_subject_admin'] : '[' . $form['title'] . '] 新規送信';
            $template = !empty($form['mail_template_admin'])
                ? (string) $form['mail_template_admin']
                : "フォーム「{{__form_title__}}」に新しい送信がありました。\n受信日時: {{__submitted_at__}}\nIP: {{__ip__}}\n\n{{__all__}}";
            $sent = Mailer::send(
                $admins,
                Mailer::renderSubjectTemplate($subject, $fields, $values, $context),
                Mailer::renderTemplate($template, $fields, $values, $context),
                [],
                $mailConfig
            );
            $ok = $sent && $ok;
        }

        if (!empty($form['reply_enabled']) && !empty($form['reply_from_field_key'])) {
            $recipients = [];
            foreach (Form::replyFieldKeys($form['reply_from_field_key']) as $fieldKey) {
                $to = $values[$fieldKey] ?? null;
                if (is_array($to)) {
                    $to = reset($to);
                }
                $to = is_string($to) ? trim($to) : '';
                if ($to !== '' && filter_var($to, FILTER_VALIDATE_EMAIL)) {
                    $recipients[$to] = $to;
                }
            }
            if ($recipients !== []) {
                $subject = (string) ($form['reply_subject'] ?? '送信ありがとうございました');
                $template = (string) ($form['reply_template'] ?? "お問い合わせいただきありがとうございました。\n以下の内容で受け付けました。\n\n{{__all__}}");
                $sent = Mailer::send(
                    array_values($recipients),
                    Mailer::renderSubjectTemplate($subject, $fields, $values, $context),
                    Mailer::renderTemplate($template, $fields, $values, $context),
                    [],
                    $mailConfig
                );
                $ok = $sent && $ok;
            }
        }
        if (!$ok) {
            error_log('[formkun] one or more submission notification mails failed for form ' . (int) ($form['id'] ?? 0));
        }
        return $ok;
    }

    /** @return array<string, mixed> */
    private static function mailConfig(array $form): array
    {
        return [
            'transport' => (string) ($form['mail_transport'] ?? config('mail.transport', 'none')),
            'from_email' => (string) ($form['mail_from_email'] ?? config('mail.from_email', 'noreply@example.com')),
            'from_name' => (string) ($form['mail_from_name'] ?? config('mail.from_name', '')),
            'smtp' => [
                'host' => (string) ($form['mail_smtp_host'] ?? config('mail.smtp.host', '')),
                'port' => (int) ($form['mail_smtp_port'] ?? config('mail.smtp.port', 25)),
                'secure' => (string) ($form['mail_smtp_secure'] ?? config('mail.smtp.secure', '')),
                'username' => (string) ($form['mail_smtp_username'] ?? config('mail.smtp.username', '')),
                'password' => (string) ($form['mail_smtp_password'] ?? config('mail.smtp.password', '')),
                'timeout' => (int) ($form['mail_smtp_timeout'] ?? config('mail.smtp.timeout', 10)),
                'ehlo_host' => (string) ($form['mail_smtp_ehlo_host'] ?? config('mail.smtp.ehlo_host', '')),
                'verify_peer' => !array_key_exists('mail_smtp_verify_peer', $form) ? !empty(config('mail.smtp.verify_peer', true)) : !empty($form['mail_smtp_verify_peer']),
                'verify_peer_name' => !array_key_exists('mail_smtp_verify_peer_name', $form) ? !empty(config('mail.smtp.verify_peer_name', true)) : !empty($form['mail_smtp_verify_peer_name']),
                'allow_self_signed' => !array_key_exists('mail_smtp_allow_self_signed', $form) ? !empty(config('mail.smtp.allow_self_signed', false)) : !empty($form['mail_smtp_allow_self_signed']),
            ],
        ];
    }
}
