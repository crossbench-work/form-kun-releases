        <div data-target="c-formEditTabs01__contents" data-tab-panel="mail-line" class="area is-contents" role="tabpanel"
            aria-label="LINE通知" hidden>
            <?php
            use Core\LineAccountScope;
            use Core\LineSiteConfig;
            use Models\Form;

            $lineNotifyEnabled = !empty($form['line_notify_enabled']);
            $lineCustomEnabled = !empty($form['line_custom_enabled']);
            $lineAccountLinkComplete = Form::lineSetupChecklistIsCompleteForFormRow($form);
            $lineSiteAccountComplete = LineSiteConfig::isSetupComplete();
            $lineFormId = (int) ($form['id'] ?? 0);
            $lineScopeForm = LineAccountScope::form($form);
            ?>
            <?php admin_c_form_block01_open(); ?>
                <input type="hidden" name="_mail_section_present[line]" value="1">
                <div class="area is-title">
                    <?php admin_m_large_title01('LINE通知'); ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_line_notify_enabled.php'; ?>
                </div>
                <div data-module="c-lineNotifyTab01"
                    data-line-account-link-complete="<?= $lineAccountLinkComplete ? '1' : '0' ?>"
                    data-line-site-account-complete="<?= $lineSiteAccountComplete ? '1' : '0' ?>"
                    data-line-custom-enabled="<?= $lineCustomEnabled ? '1' : '0' ?>"
                    <?= !$lineNotifyEnabled ? ' hidden' : '' ?>>
                    <div class="block is-lineNotifyUpper">
                    <div class="area is-field" data-target="c-lineNotifyTab01__messageFields"<?= !$lineNotifyEnabled || !$lineAccountLinkComplete ? ' hidden' : '' ?>>
                        <div data-module="c-lineNotifySettings01">
                            <?php require __DIR__ . '/_content_line_message_template.php'; ?>
                            <?php require __DIR__ . '/_content_line_message_template_vars.php'; ?>
                        </div>
                    </div>
                    <div class="area is-field" data-target="c-lineNotifyTab01__messageWait"<?= !$lineNotifyEnabled || $lineAccountLinkComplete || $lineCustomEnabled ? ' hidden' : '' ?>>
                        <p class="text is-help" data-target="c-lineNotifyTab01__waitTextSite"<?= $lineCustomEnabled ? ' hidden' : '' ?>><a href="<?= e(base_path('/admin/settings#line-settings')) ?>">設定 → LINE 連携</a> でアカウント連携（送信先 ID・通知テスト含む）を完了後、通知メッセージを設定できます。</p>
                    </div>
                    <?php if (\Core\Auth::role() !== 'admin' && !$lineCustomEnabled): ?>
                    <div class="area is-field">
                        <?php admin_m_alert01('LINE チャネル・送信先 ID の設定は <a href="' . e(base_path('/admin/settings#line-settings')) . '">設定 → LINE 連携</a>（admin のみ）で行います。', 'info'); ?>
                    </div>
                    <?php endif; ?>
                    </div>
                </div>
                <div id="line-custom-link-wrap" class="block is-lineAccountLink"<?= $lineNotifyEnabled && $lineCustomEnabled ? '' : ' hidden' ?>>
                    <?php
                    $lineScope = $lineScopeForm;
                    $lineSiteForm = $form;
                    $lineCredentialErrors = $lineCredentialErrors ?? [];
                    $lineAccountLinkComplete = $lineScope->isSetupComplete();
                    require APP_DIR . '/views/admin/line/_account_link_main.php';
                    ?>
                </div>
                <div id="line-custom-unlink-wrap" class="block is-lineAccountUnlink"<?= $lineNotifyEnabled && $lineCustomEnabled ? '' : ' hidden' ?>>
                    <div class="area is-title">
                        <?php admin_m_left_border_title01('アカウント連携の解除'); ?>
                    </div>
                    <div class="area is-field">
                        <?php
                        $lineAccountUnlinkUrl = base_path('/admin/forms/' . $lineFormId . '/line/account-unlink');
                        $lineAccountUnlinkContext = 'form';
                        require __DIR__ . '/_content_line_account_unlink.php';
                        ?>
                    </div>
                </div>
            <?php admin_c_form_block01_close(); ?>
        </div>
