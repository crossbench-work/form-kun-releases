<?php
namespace Controllers;

use Core\LineWebhookSignature;
use Core\LineWebhookSourceTarget;
use Models\Form;
use Models\LineWebhookTarget;

class LineWebhookController
{
    public function handle(string $publicUuid): void
    {
        header('Content-Type: application/json; charset=utf-8');

        $form = Form::findByPublicUuid($publicUuid);
        if ($form === null) {
            http_response_code(404);
            echo '{}';
            return;
        }

        $secret = trim((string) ($form['line_channel_secret'] ?? ''));
        if ($secret === '') {
            http_response_code(503);
            echo '{}';
            return;
        }

        $rawBody = (string) file_get_contents('php://input');
        $signature = (string) ($_SERVER['HTTP_X_LINE_SIGNATURE'] ?? '');
        if (!LineWebhookSignature::isValid($secret, $rawBody, $signature)) {
            http_response_code(401);
            echo '{}';
            return;
        }

        $payload = json_decode($rawBody, true);
        if (!is_array($payload)) {
            http_response_code(200);
            echo '{}';
            return;
        }

        $formId = (int) ($form['id'] ?? 0);
        $events = $payload['events'] ?? [];
        if (is_array($events)) {
            foreach ($events as $event) {
                if (is_array($event)) {
                    self::processEvent($formId, $event);
                }
            }
        }

        http_response_code(200);
        echo '{}';
    }

    /** @param array<string, mixed> $event */
    private static function processEvent(int $formId, array $event): void
    {
        $type = (string) ($event['type'] ?? '');
        $source = $event['source'] ?? [];
        if (!is_array($source)) {
            $source = [];
        }

        if ($type === 'follow') {
            $userId = trim((string) ($source['userId'] ?? ''));
            if ($userId !== '') {
                LineWebhookTarget::upsert($formId, 'user', $userId);
                Form::syncLineTalkSendSetupChecklistForTypes($formId, ['user']);
            }
            return;
        }

        if ($type === 'unfollow') {
            $userId = trim((string) ($source['userId'] ?? ''));
            if ($userId !== '') {
                LineWebhookTarget::remove($formId, 'user', $userId);
                Form::syncLineTalkSendSetupChecklistForTypes($formId, ['user']);
            }
            return;
        }

        if ($type === 'join' || $type === 'memberJoined' || $type === 'message' || $type === 'postback') {
            $resolved = LineWebhookSourceTarget::resolveForPush($source);
            if ($resolved !== null) {
                LineWebhookTarget::upsert($formId, $resolved['type'], $resolved['id']);
                $types = in_array($resolved['type'], ['group', 'room'], true) ? ['group', 'room'] : ['user'];
                Form::syncLineTalkSendSetupChecklistForTypes($formId, $types);
            }
            return;
        }

        if ($type === 'leave' || $type === 'memberLeft') {
            $resolved = LineWebhookSourceTarget::resolveForPush($source);
            if ($resolved !== null) {
                LineWebhookTarget::remove($formId, $resolved['type'], $resolved['id']);
                $types = in_array($resolved['type'], ['group', 'room'], true) ? ['group', 'room'] : ['user'];
                Form::syncLineTalkSendSetupChecklistForTypes($formId, $types);
            }
        }
    }
}
