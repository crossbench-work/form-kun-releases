        <div data-target="c-formEditTabs01__contents" data-tab-panel="mail-line" class="area is-contents" role="tabpanel"
            aria-label="LINE通知" hidden>
            <?php
            use Models\Form;

            $lineNotifyEnabled = !empty($form['line_notify_enabled']);
            $lineSetupChecklistState = Form::lineSetupChecklistStateForDisplay($form);
            $lineSetupChecklistComplete = Form::lineSetupChecklistIsComplete($lineSetupChecklistState);
            $lineSetupChecklistItemCount = count(Form::lineSetupChecklistItemKeys());
            $lineFormId = (int) ($form['id'] ?? 0);
            $lineNotifySettingsSaveUrl = $lineFormId > 0
                ? base_path('/admin/forms/' . $lineFormId . '/line/notify-settings')
                : '';
            ?>
            <?php admin_c_form_block01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_large_title01('LINE通知'); ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_line_notify_enabled.php'; ?>
                </div>
                <div data-module="c-lineNotifyTab01"
                    data-checklist-item-count="<?= (int) $lineSetupChecklistItemCount ?>"
                    <?= $lineNotifySettingsSaveUrl !== '' ? ' data-notify-settings-url="' . e($lineNotifySettingsSaveUrl) . '"' : '' ?>
                    data-csrf-name="_token"
                    <?= !$lineNotifyEnabled ? ' hidden' : '' ?>>
                    <div class="block is-lineNotifyUpper">
                    <div class="area is-field" data-target="c-lineNotifyTab01__messageFields"<?= !$lineNotifyEnabled || !$lineSetupChecklistComplete ? ' hidden' : '' ?>>
                        <div data-module="c-lineNotifySettings01">
                            <?php require __DIR__ . '/_content_line_message_template.php'; ?>
                            <?php require __DIR__ . '/_content_line_message_template_vars.php'; ?>
                        </div>
                    </div>
                    <div class="area is-field" data-target="c-lineNotifyTab01__messageWait"<?= !$lineNotifyEnabled || $lineSetupChecklistComplete ? ' hidden' : '' ?>>
                        <p class="text is-help">アカウント連携のチェックリストを全て完了後、通知メッセージを設定できます</p>
                    </div>
                    <?php if (\Core\Auth::role() !== 'admin'): ?>
                    <div class="area is-field">
                        <?php admin_m_alert01('Channel access token・Channel secret・Webhook URL の設定は admin のみ変更できます。', 'info'); ?>
                    </div>
                    <?php endif; ?>
                    </div>
                    <div class="block is-lineAccountLink">
                    <div class="area is-title">
                        <?php admin_m_bold_title01('アカウント連携の設定'); ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_line_setup_checklist.php'; ?>
                    </div>
                    </div>
                    <?php if (\Core\Auth::role() === 'admin'): ?>
                    <div class="block is-lineAccountUnlink">
                    <div class="area is-title">
                        <?php admin_m_bold_title01('アカウント連携の解除'); ?>
                    </div>
                    <div class="area is-field">
                        <?php require __DIR__ . '/_content_line_account_unlink.php'; ?>
                    </div>
                    </div>
                    <?php endif; ?>
                </div>
            <?php admin_c_form_block01_close(); ?>
        </div>
