<?php /** チェックリスト is-extra: LINEトークへの通知テスト */
$formId = (int) ($form['id'] ?? 0);
$lineNotifyTestUrl = $formId > 0
    ? base_path('/admin/forms/' . $formId . '/test-line')
    : '';
$canTest = !empty($form['line_push_to_id_configured'])
    && !empty($form['line_channel_access_token_configured']);
?>
<div data-module="c-lineNotifyTestPush01"<?= $lineNotifyTestUrl !== '' ? ' data-test-url="' . e($lineNotifyTestUrl) . '"' : '' ?> data-csrf-name="_token">
    <div class="area is-actions">
        <?php
        admin_m_btn01_button_wrap('テスト送信', [
            'type' => 'button',
            'class' => 'is-primary',
            'disabled' => $canTest ? null : true,
        ]);
        ?>
    </div>
</div>
