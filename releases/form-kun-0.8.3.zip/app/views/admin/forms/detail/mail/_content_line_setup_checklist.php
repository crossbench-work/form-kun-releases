<?php /** c-formBlock01 直下 .area.is-field: LINE セットアップチェックリスト */ ?>
<?php
use Models\Form;

$formId = (int) ($form['id'] ?? 0);
$lineSetupChecklistState = Form::lineSetupChecklistStateForDisplay($form);
$lineSetupChecklistPostUrl = $formId > 0
    ? base_path('/admin/forms/' . $formId . '/line/setup-checklist')
    : '';
$lineSetupChecklistAdminOnlyKeys = [
    Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_SECRET,
    Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_ACCESS_TOKEN,
    Form::LINE_SETUP_CHECKLIST_SET_WEBHOOK_URL,
];
admin_c_line_setup_checklist01(
    Form::lineSetupChecklistItemDefinitions(),
    $lineSetupChecklistState,
    $lineSetupChecklistPostUrl,
    $formId > 0,
    static function (string $itemKey) use ($form, $lineSetupChecklistAdminOnlyKeys): void {
        if (in_array($itemKey, $lineSetupChecklistAdminOnlyKeys, true) && \Core\Auth::role() !== 'admin') {
            return;
        }
        if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_SECRET) {
            $lineCredentialHideTitle = true;
            require __DIR__ . '/_content_line_channel_secret.php';

            return;
        }
        if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_ACCESS_TOKEN) {
            $lineCredentialHideTitle = true;
            require __DIR__ . '/_content_line_channel_access_token.php';

            return;
        }
        if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_WEBHOOK_URL) {
            $lineWebhookHideTitle = true;
            require __DIR__ . '/_content_line_webhook_url.php';

            return;
        }
        if ($itemKey === Form::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP) {
            require __DIR__ . '/_content_line_talk_setup.php';

            return;
        }
        if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_LINE_PUSH_TO_ID) {
            $linePushToIdHideTitle = true;
            $linePushToIdHideHelp = true;
            $linePushToIdInlineSave = true;
            require __DIR__ . '/_content_line_push_to_id.php';

            return;
        }
        if ($itemKey === Form::LINE_SETUP_CHECKLIST_LINE_TALK_NOTIFY_TEST) {
            require __DIR__ . '/_content_line_notify_test.php';

            return;
        }
    }
);
