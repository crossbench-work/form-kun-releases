<?php
/** c-formBlock01 / チェックリスト is-extra: LINE通知 — Webhook URL（表示のみ） */
/** @var bool $lineWebhookHideTitle チェックリスト内など見出しを省略する */
$lineWebhookHideTitle = !empty($lineWebhookHideTitle);
?>
    <?php admin_m_input_set01_open(); ?>
    <?php if (!$lineWebhookHideTitle): ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('Webhook URL')); ?>
    </div>
    <?php endif; ?>
    <div class="area is-field">
        <?php
        $webhookUrl = '';
        $formId = (int) ($form['id'] ?? 0);
        if ($formId > 0) {
            $uuid = trim((string) ($form['public_uuid'] ?? ''));
            if ($uuid !== '' && is_uuid_v4($uuid)) {
                $webhookUrl = url('/api/line/webhook/' . strtolower($uuid));
            }
        }
        ?>
        <?php if ($webhookUrl !== ''): ?>
            <?php admin_c_copy_tag_list01([$webhookUrl]); ?>
        <?php else: ?>
            <p class="text is-help">フォームを一度保存すると Webhook URL が表示されます。サイト設定の base URL（HTTPS）を設定してください。</p>
        <?php endif; ?>
    </div>
    <?php admin_m_input_set01_close(); ?>
