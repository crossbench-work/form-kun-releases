<?php /** LINE 通知タブ: アカウント連携の解除（admin のみ） */
$formId = (int) ($form['id'] ?? 0);
$lineAccountUnlinkUrl = $formId > 0
    ? base_path('/admin/forms/' . $formId . '/line/account-unlink')
    : '';
?>
<div data-module="c-lineAccountUnlink01"<?= $lineAccountUnlinkUrl !== '' ? ' data-reset-url="' . e($lineAccountUnlinkUrl) . '"' : '' ?> data-csrf-name="_token">
    <p class="text is-help">Channel secret・トークン・送信先 ID・チェックリスト・Webhook で記録した ID を消去し、LINE 通知をオフにします。通知メッセージの本文は残ります。</p>
    <div class="area is-actions">
        <?php
        admin_m_btn01_button_wrap('アカウント連携を解除', [
            'type' => 'button',
            'class' => 'is-danger',
            'data-target' => 'c-lineAccountUnlink01__submit',
        ]);
        ?>
    </div>
</div>
