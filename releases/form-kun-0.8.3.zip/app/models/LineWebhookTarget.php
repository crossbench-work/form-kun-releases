<?php
namespace Models;

use Core\Database;
use Core\LineWebhookSourceTarget;

class LineWebhookTarget
{
    public static function upsert(int $formId, string $targetType, string $targetId, ?string $label = null): void
    {
        $targetType = LineWebhookSourceTarget::normalizeTargetType($targetType);
        $targetId = trim($targetId);
        if ($formId <= 0 || $targetId === '' || strlen($targetId) > 64) {
            return;
        }
        $now = date('Y-m-d H:i:s');
        $label = $label !== null && trim($label) !== '' ? mb_substr(trim($label), 0, 200) : null;
        Database::execute(
            'INSERT INTO line_webhook_targets (form_id, target_type, target_id, label, last_seen_at)
             VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE label = COALESCE(VALUES(label), label), last_seen_at = VALUES(last_seen_at)',
            [$formId, $targetType, $targetId, $label, $now]
        );
    }

    public static function remove(int $formId, string $targetType, string $targetId): void
    {
        $targetType = LineWebhookSourceTarget::normalizeTargetType($targetType);
        $targetId = trim($targetId);
        if ($formId <= 0 || $targetId === '') {
            return;
        }
        Database::execute(
            'DELETE FROM line_webhook_targets WHERE form_id = ? AND target_type = ? AND target_id = ?',
            [$formId, $targetType, $targetId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public static function listRecent(int $formId, int $limit = 20): array
    {
        if ($formId <= 0) {
            return [];
        }
        $limit = max(1, min(50, $limit));
        return Database::fetchAll(
            'SELECT * FROM line_webhook_targets WHERE form_id = ? ORDER BY last_seen_at DESC LIMIT ' . $limit,
            [$formId]
        );
    }

    /**
     * @param list<string> $types
     * @return array<int, array<string, mixed>>
     */
    public static function listRecentForTypes(int $formId, array $types, int $limit = 20): array
    {
        if ($formId <= 0 || $types === []) {
            return [];
        }
        $allowed = [];
        foreach ($types as $type) {
            $normalized = LineWebhookSourceTarget::normalizeTargetType((string) $type);
            if ($normalized !== '') {
                $allowed[$normalized] = true;
            }
        }
        if ($allowed === []) {
            return [];
        }
        $limit = max(1, min(50, $limit));
        $placeholders = implode(',', array_fill(0, count($allowed), '?'));
        $params = array_merge([$formId], array_keys($allowed));

        return Database::fetchAll(
            'SELECT * FROM line_webhook_targets WHERE form_id = ? AND target_type IN ('
            . $placeholders
            . ') ORDER BY last_seen_at DESC LIMIT '
            . $limit,
            $params
        );
    }

    /**
     * @param list<string> $types
     */
    public static function existsForForm(int $formId, array $types): bool
    {
        if ($formId <= 0 || $types === []) {
            return false;
        }
        $allowed = [];
        foreach ($types as $type) {
            $normalized = LineWebhookSourceTarget::normalizeTargetType((string) $type);
            if ($normalized !== '') {
                $allowed[$normalized] = true;
            }
        }
        if ($allowed === []) {
            return false;
        }
        $placeholders = implode(',', array_fill(0, count($allowed), '?'));
        $params = array_merge([$formId], array_keys($allowed));
        $row = Database::fetchOne(
            'SELECT 1 AS ok FROM line_webhook_targets WHERE form_id = ? AND target_type IN (' . $placeholders . ') LIMIT 1',
            $params
        );

        return $row !== null;
    }
}
