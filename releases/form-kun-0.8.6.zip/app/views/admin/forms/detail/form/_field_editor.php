<?php
$fk = (string) ($f['field_key'] ?? '');
$inputPageKey = \Models\FormField::sanitizeInputPageKey((string) ($f['input_page_key'] ?? \Models\FormInputPage::DEFAULT_KEY));
$FB_REGEX_CUSTOM = $FB_REGEX_CUSTOM ?? '__custom__';
$FB_REGEX_CHECKBOX_LIMIT = $FB_REGEX_CHECKBOX_LIMIT ?? '__checkbox_limit__';
$regexPresetChoices = $regexPresetChoices ?? [
    '' => 'なし',
    '/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/u' => 'メールアドレス',
    '/\A\d{2,4}-?\d{2,4}-?\d{3,4}\z/u' => '電話番号',
    '/\A\d{3}-?\d{4}\z/u' => '郵便番号',
    '/\A[0-9]+\z/u' => '半角数字のみ',
    '/\A[ぁ-んー　]+\z/u' => 'ひらがなのみ（全角スペース可）',
    '/\A[ァ-ヶー　]+\z/u' => 'カタカナのみ（全角スペース可）',
    '/\A[a-zA-Z]+\z/u' => '半角英字のみ',
    $FB_REGEX_CUSTOM => 'カスタム（正規表現を入力）',
];
$fkLocked = $fk !== '' && \Core\FieldKey::isUuidFormat($fk);
$regexDecoded = \Models\FormField::decodeRegexPatterns(isset($f['regex']) ? (string) $f['regex'] : null);
$rp = $regexDecoded[0] ?? '';
$isTextMulti = (($f['type'] ?? '') === 'text_multi');
$isPostalCode = (($f['type'] ?? '') === \Models\FormField::TYPE_POSTAL_CODE);
$isDisplayOnly = \Models\FormField::isDisplayOnlyType((string) ($f['type'] ?? ''));
$isHeading = (string) ($f['type'] ?? '') === \Models\FormField::TYPE_HEADING;
$isDescription = (string) ($f['type'] ?? '') === \Models\FormField::TYPE_DESCRIPTION;
$showDisplaySettings = !$isDisplayOnly || $isHeading || $isDescription;
$multiTextItems = $isTextMulti
    ? \Models\FormField::decodeTextMultiItems($f['multi_text_items'] ?? ($f['options_json'] ?? null), true)
    : [];
$helpTextIsHtml = preg_match('/<\s*\/?[a-zA-Z][^>]*>/', (string) ($f['help_text'] ?? '')) === 1;
$summaryRequired = !empty($f['required']) ? '必須' : '任意';
if ($isDisplayOnly || empty($f['required']) || in_array($f['type'], ['radio', 'select'], true)) {
    $summaryRegex = 'なし';
} elseif ($f['type'] === 'checkbox' && !empty($f['checkbox_limit_enabled'])) {
    $summaryRegex = '選択数';
} elseif ($f['type'] === 'checkbox') {
    $summaryRegex = array_key_exists($rp, $regexPresetChoices) ? 'なし' : 'カスタム';
} elseif ($rp === '') {
    $summaryRegex = 'なし';
} elseif (array_key_exists($rp, $regexPresetChoices)) {
    $summaryRegex = $regexPresetChoices[$rp];
} else {
    $summaryRegex = 'カスタム';
}
?>
<?php admin_c_form_editor_item01_open([
    'data-index' => (string) $idx,
    'data-field-item' => '1',
], true, array_key_exists('visible', $f) && empty($f['visible'])); ?>
    <div class="wrapper">
        <div class="block is-header">
                <?php admin_c_form_editor_item_header01_open(); ?>
                            <div class="area is-move">
                                <div class="box is-handle ui-sortable-handle" title="ドラッグして並べ替え">
                                    <?php admin_m_drag_handle01('c-formEditor__dragHandle'); ?>
                                </div>
                            </div>
                            <div class="area is-summary">
                                <div class="c-formEditorSummary01">
                                    <div class="wrapper">
                                        <div class="block is-contents">
                                            <p class="index" data-target="c-formEditor__summaryIndex"><?= $idx + 1 ?></p>
                                            <p class="label" data-target="c-formEditor__summaryLabel"><?= e($f['label']) ?></p>
                                            <p class="type" data-target="c-formEditor__summaryType"><?= e(\Models\FormField::typeLabel($f['type'])) ?></p>
                                            <p class="required" data-target="c-formEditor__summaryRequired" <?= !empty($f['required']) ? '' : 'hidden' ?>><?= e($summaryRequired) ?></p>
                                            <p class="regex" data-target="c-formEditor__summaryRegexWrap" <?= (!empty($f['required']) && $summaryRegex !== 'なし') ? '' : 'hidden' ?>><svg width="12" height="12" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M20 6L9 17l-5-5"/></svg><span data-target="c-formEditor__summaryRegex"><?= e($summaryRegex) ?></span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="area is-delete">
                                <label class="c-formEditorSummary01__visibility" title="<?= !empty($f['visible']) ? '表示中' : '非表示' ?>">
                                    <input type="checkbox" name="fields[<?= $idx ?>][visible]" value="1" data-name="visible" <?= !array_key_exists('visible', $f) || !empty($f['visible']) ? 'checked' : '' ?>>
                                    <span aria-hidden="true">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/>
                                            <circle cx="12" cy="12" r="3"/>
                                            <path class="is-hiddenLine" stroke-linecap="round" stroke-linejoin="round" d="M4 20L20 4"/>
                                        </svg>
                                    </span>
                                </label>
                                <details class="menu" data-target="c-formEditor__actionMenu">
                                    <summary class="toggle" aria-label="項目操作"><span aria-hidden="true">⋯</span></summary>
                                    <div class="items" role="menu" aria-label="項目操作">
                                        <button type="button" data-target="c-formEditor__duplicate" role="menuitem">複製</button>
                                        <button type="button" data-target="c-formEditor__remove" role="menuitem">削除</button>
                                    </div>
                                </details>
                            </div>
                <?php admin_c_form_editor_item_header01_close(); ?>
        </div>
        <div class="block is-body">
                <?php admin_c_form_editor_item_body01_open(); ?>
                            <div class="block is-contents">
                                        <div class="block is-title">
                                            <p data-module="m-borderTitle01">基本設定</p>
                                        </div>
                                        <div class="block is-field">
                                            <div class="c-formEditor__field">
                                                <div class="wrapper">
                                                    <div class="block is-contents">
                                                        <div class="area is-title c-formEditor__labelTitle">
                                                            <label class="label" data-module="m-labelTitle01">ラベル</label>
                                                            <label class="label is-choice">
                                                                <input type="hidden" name="fields[<?= $idx ?>][show_label]" value="0" data-name="show_label">
                                                                <input type="checkbox" name="fields[<?= $idx ?>][show_label]" value="1" data-name="show_label" <?= !array_key_exists('show_label', $f) || !empty($f['show_label']) ? 'checked' : '' ?>>
                                                                表示する
                                                            </label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_input([
                                                                    'type' => 'text',
                                                                    'name' => 'fields[' . $idx . '][label]',
                                                                    'data-target' => 'c-formEditor__labelInput',
                                                                    'value' => (string) $f['label'],
                                                                ]); ?>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <div class="c-formEditor__fieldKeyColumn">
                                                                <label class="label" data-module="m-labelTitle01">フィールドキー</label>
                                                            </div>
                                                        </div>
                                                        <div class="area is-field">
                                                            <div class="c-formEditor__fieldKey">
                                                                <?php admin_m_input01_open(); ?>
                                                                    <?php
                                                                    $fieldKeyAttrs = [
                                                                        'type' => 'text',
                                                                        'name' => 'fields[' . $idx . '][field_key]',
                                                                        'value' => (string) $f['field_key'],
                                                                        'data-target' => 'c-formEditor__fieldKeyInput',
                                                                        'spellcheck' => 'false',
                                                                    ];
                                                                    if ($fkLocked) {
                                                                        $fieldKeyAttrs['class'] = 'is-locked';
                                                                        $fieldKeyAttrs['readonly'] = true;
                                                                    }
                                                                    admin_m_input01_input($fieldKeyAttrs);
                                                                    ?>
                                                                <?php admin_m_input01_close(); ?>
                                                                <button type="button" class="btn is-icon" data-target="c-formEditor__fieldKeyLock" aria-label="<?= $fkLocked ? 'キーを編集' : 'キーをロック' ?>" title="<?= $fkLocked ? '編集する' : 'ロックする' ?>" aria-pressed="<?= $fkLocked ? 'true' : 'false' ?>">
                                                                    <svg data-target="c-formEditor__fieldKeyLockedIcon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" <?= $fkLocked ? '' : 'style="display:none"' ?> aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                                                                    <svg data-target="c-formEditor__fieldKeyOpenIcon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" <?= $fkLocked ? 'style="display:none"' : '' ?> aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z"/></svg>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <input type="hidden" name="fields[<?= $idx ?>][type]" value="<?= e($f['type']) ?>" data-target="c-formEditor__type" data-type-label="<?= e(\Models\FormField::typeLabel($f['type'])) ?>">
                                                    <input type="hidden" name="fields[<?= $idx ?>][input_page_key]" value="<?= e($inputPageKey) ?>" data-name="input_page_key" data-target="c-formEditor__inputPageKey">
                                                    <input type="hidden" name="fields[<?= $idx ?>][parent_group_key]" value="<?= e((string) ($f['parent_group_key'] ?? '')) ?>" data-name="parent_group_key" data-target="c-formEditor__parentGroupKey">
                                                    <input type="hidden" name="fields[<?= $idx ?>][sort_order]" value="<?= e((string) ($f['sort_order'] ?? ($idx + 1))) ?>" data-name="sort_order" data-target="c-formEditor__sortOrder">
                                                </div>
                                            </div>
                                        </div>
                            </div>
                            <div class="block is-contents" data-target="c-formEditor__inputSettings" <?= $isDisplayOnly ? 'style="display:none"' : '' ?>>
                                            <div class="block is-title">
                                                <p data-module="m-borderTitle01">入力設定</p>
                                            </div>
                                            <div class="block is-field">
                                                <div class="c-formEditor__field">
                                                    <div class="wrapper">
                                                        <div class="block is-contents c-formEditor__validation">
                                                            <div class="area is-title">
                                                                <label class="label" data-module="m-labelTitle01">入力チェック</label>
                                                                <div data-module="m-requiredCheck01">
                                                                    <label class="label is-choice">
                                                                        <input type="checkbox" name="fields[<?= $idx ?>][required]" value="1" data-target="c-formEditor__required" <?= !empty($f['required']) ? 'checked' : '' ?> aria-label="必須にする">
                                                                        <span>必須にする</span>
                                                                    </label>
                                                                </div>
                                                            </div>
                                                            <div class="area is-field">
                                                                <div class="c-formEditor__validationControls">
                                                                    <div data-target="c-formEditor__regex">
                                                                        <div class="c-formEditor__regexList">
                                                                            <?php
                                                                            if ($f['type'] === 'checkbox' && !empty($f['checkbox_limit_enabled'])) {
                                                                                $selVal = $FB_REGEX_CHECKBOX_LIMIT;
                                                                                $customVal = '';
                                                                            } elseif ($f['type'] === 'checkbox') {
                                                                                $selVal = $rp !== '' ? $FB_REGEX_CUSTOM : '';
                                                                                $customVal = ($rp !== '' && !array_key_exists($rp, $regexPresetChoices)) ? $rp : '';
                                                                            } elseif ($rp === '') {
                                                                                $selVal = '';
                                                                                $customVal = '';
                                                                            } elseif ($rp !== '' && array_key_exists($rp, $regexPresetChoices) && $rp !== $FB_REGEX_CUSTOM) {
                                                                                $selVal = $rp;
                                                                                $customVal = '';
                                                                            } else {
                                                                                $selVal = $FB_REGEX_CUSTOM;
                                                                                $customVal = $rp;
                                                                            }
                                                                            $showCustom = ($selVal === $FB_REGEX_CUSTOM);
                                                                            $hiddenVal = $showCustom ? $customVal : ($selVal === $FB_REGEX_CHECKBOX_LIMIT ? '' : $selVal);
                                                                            ?>
                                                                            <div class="c-formEditor__regexRow">
                                                                                <?php admin_m_input01_open(); ?>
                                                                                    <?php
                                                                                    $regexKindAttrs = [
                                                                                        'data-target' => 'c-formEditor__regexKind',
                                                                                        'aria-label' => '入力チェックの種類',
                                                                                    ];
                                                                                    if (empty($f['required'])) {
                                                                                        $regexKindAttrs['disabled'] = true;
                                                                                    }
                                                                                    admin_m_input01_select_open($regexKindAttrs);
                                                                                    foreach ($regexPresetChoices as $patVal => $patLabel) {
                                                                                        if ($f['type'] === 'checkbox' && !in_array($patVal, ['', $FB_REGEX_CUSTOM], true)) {
                                                                                            continue;
                                                                                        }
                                                                                        if (in_array($f['type'], ['radio', 'select'], true) && $patVal !== '') {
                                                                                            continue;
                                                                                        }
                                                                                        admin_m_input01_option((string) $patVal, (string) $patLabel, $selVal === $patVal);
                                                                                    }
                                                                                    if ($f['type'] === 'checkbox') {
                                                                                        admin_m_input01_option((string) $FB_REGEX_CHECKBOX_LIMIT, '選択数を設定する', $selVal === $FB_REGEX_CHECKBOX_LIMIT);
                                                                                    }
                                                                                    admin_m_input01_select_close();
                                                                                    ?>
                                                                                <?php admin_m_input01_close(); ?>
                                                                                <div class="c-formEditor__regexCustom"<?= $showCustom ? '' : ' style="display:none"' ?>>
                                                                                    <?php admin_m_input01_open(); ?>
                                                                                        <?php
                                                                                        $regexCustomAttrs = [
                                                                                            'type' => 'text',
                                                                                            'data-target' => 'c-formEditor__regexCustomInput',
                                                                                            'value' => (string) $customVal,
                                                                                            'placeholder' => '正規表現',
                                                                                            'spellcheck' => 'false',
                                                                                            'autocomplete' => 'off',
                                                                                        ];
                                                                                        if (empty($f['required'])) {
                                                                                            $regexCustomAttrs['disabled'] = true;
                                                                                        }
                                                                                        admin_m_input01_input($regexCustomAttrs);
                                                                                        ?>
                                                                                    <?php admin_m_input01_close(); ?>
                                                                                </div>
                                                                                <input type="hidden" data-target="c-formEditor__regexValue" value="<?= e($hiddenVal) ?>" spellcheck="false">
                                                                            </div>
                                                                        </div>
                                                                        <input type="hidden" name="fields[<?= $idx ?>][checkbox_limit_enabled]" data-target="c-formEditor__checkboxLimitEnabled" value="<?= !empty($f['checkbox_limit_enabled']) ? '1' : '0' ?>">
                                                                        <div class="c-formEditor__checkboxLimit" <?= ($f['type'] === 'checkbox' && !empty($f['required']) && !empty($f['checkbox_limit_enabled'])) ? '' : 'style="display:none"' ?>>
                                                                            <div class="wrapper">
                                                                                <div class="block is-contents">
                                                                                    <div class="area is-title">
                                                                                        <label class="label" data-module="m-labelTitle01">最小選択数</label>
                                                                                    </div>
                                                                                    <div class="area is-field">
                                                                                        <?php admin_m_input01_open(); ?>
                                                                                            <?php admin_m_input01_input([
                                                                                                'type' => 'number',
                                                                                                'min' => 1,
                                                                                                'name' => 'fields[' . $idx . '][checkbox_min_selections]',
                                                                                                'value' => (string) ($f['checkbox_min_selections'] ?? ''),
                                                                                            ]); ?>
                                                                                        <?php admin_m_input01_close(); ?>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="block is-contents">
                                                                                    <div class="area is-title">
                                                                                        <label class="label" data-module="m-labelTitle01">最大選択数</label>
                                                                                    </div>
                                                                                    <div class="area is-field">
                                                                                        <?php admin_m_input01_open(); ?>
                                                                                            <?php admin_m_input01_input([
                                                                                                'type' => 'number',
                                                                                                'min' => 1,
                                                                                                'name' => 'fields[' . $idx . '][checkbox_max_selections]',
                                                                                                'value' => (string) ($f['checkbox_max_selections'] ?? ''),
                                                                                            ]); ?>
                                                                                        <?php admin_m_input01_close(); ?>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php
                                                        $lengthLimitMode = '';
                                                        if (!empty($f['exact_length'])) {
                                                            $lengthLimitMode = 'exact';
                                                        } elseif (!empty($f['min_length']) || !empty($f['max_length'])) {
                                                            $lengthLimitMode = 'range';
                                                        }
                                                        ?>
                                                        <div class="block is-contents" data-target="c-formEditor__minMaxLength" <?= ($isDisplayOnly || in_array($f['type'], ['radio', 'checkbox', 'select', 'file', \Models\FormField::TYPE_MATRIX], true)) ? 'style="display:none"' : '' ?>>
                                                            <div class="area is-title">
                                                                <label class="label" data-module="m-labelTitle01">文字数制限</label>
                                                            </div>
                                                            <div class="area is-field">
                                                                <div class="c-formEditor__child__field">
                                                                    <div class="wrapper">
                                                                        <div class="block is-contents">
                                                                            <div class="area is-field">
                                                                                <?php admin_m_input01_open('is-w60'); ?>
                                                                                    <select name="fields[<?= $idx ?>][length_limit_mode]" data-target="c-formEditor__lengthLimitMode">
                                                                                        <option value=""<?= $lengthLimitMode === '' ? ' selected' : '' ?>>なし</option>
                                                                                        <option value="range"<?= $lengthLimitMode === 'range' ? ' selected' : '' ?>>範囲</option>
                                                                                        <option value="exact"<?= $lengthLimitMode === 'exact' ? ' selected' : '' ?>>固定</option>
                                                                                    </select>
                                                                                <?php admin_m_input01_close(); ?>
                                                                            </div>
                                                                        </div>
                                                                        <div class="c-formEditor__lengthRange01" data-target="c-formEditor__lengthRange"<?= $lengthLimitMode === 'range' ? '' : ' style="display:none"' ?>>
                                                                            <?php admin_m_input01_open(); ?>
                                                                                <?php admin_m_input01_input([
                                                                                    'type' => 'number',
                                                                                    'min' => 1,
                                                                                    'name' => 'fields[' . $idx . '][min_length]',
                                                                                    'value' => (string) ($f['min_length'] ?? ''),
                                                                                ]); ?>
                                                                            <?php admin_m_input01_close(); ?>
                                                                            <span class="separator" aria-hidden="true">〜</span>
                                                                            <?php admin_m_input01_open(); ?>
                                                                                <?php admin_m_input01_input([
                                                                                    'type' => 'number',
                                                                                    'min' => 1,
                                                                                    'name' => 'fields[' . $idx . '][max_length]',
                                                                                    'value' => (string) ($f['max_length'] ?? ''),
                                                                                ]); ?>
                                                                            <?php admin_m_input01_close(); ?>
                                                                        </div>
                                                                        <div class="c-formEditor__lengthExact01" data-target="c-formEditor__lengthExact"<?= $lengthLimitMode === 'exact' ? '' : ' style="display:none"' ?>>
                                                                            <?php admin_m_input01_open(); ?>
                                                                                <?php admin_m_input01_input([
                                                                                    'type' => 'number',
                                                                                    'min' => 1,
                                                                                    'name' => 'fields[' . $idx . '][exact_length]',
                                                                                    'value' => (string) ($f['exact_length'] ?? ''),
                                                                                ]); ?>
                                                                            <?php admin_m_input01_close(); ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="block is-field" data-target="c-formEditor__options" <?= in_array($f['type'], ['radio','checkbox','select'], true) ? '' : 'style="display:none"' ?>>
                                                <?php $choiceOptions = \Models\FormField::parseOptions($f['options'] ?? ''); ?>
                                                <div class="c-formEditor__field">
                                                    <div class="wrapper">
                                                        <div class="block is-contents">
                                                            <div class="area is-title">
                                                                <label class="label" data-module="m-labelTitle01">選択肢（1行に1つ）</label>
                                                            </div>
                                                            <div class="area is-field">
                                                                <div class="c-formEditor__choiceEditor" data-choice-editor>
                                                                    <div class="c-formEditor__choiceList">
                                                                        <div class="wrapper">
                                                                            <div class="block is-contents" data-target="c-formEditor__choiceListContents">
                                                                                <?php foreach ($choiceOptions as $choiceOpt): ?>
                                                                                    <div class="area is-contents">
                                                                                        <div class="c-formEditor__choiceItem" data-choice-item>
                                                                                            <div class="wrapper">
                                                                                                <div class="block is-contents">
                                                                                                    <div class="area is-move">
                                                                                                        <div class="box is-handle ui-sortable-handle" title="ドラッグして並べ替え">
                                                                                                            <?php admin_m_drag_handle01('c-formEditor__choiceDragHandle'); ?>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <div class="c-formEditor__child__field">
                                                                                                        <div class="wrapper">
                                                                                                            <div class="block is-contents">
                                                                                                                <div class="area is-field">
                                                                                                                    <?php admin_m_input01_open(); ?>
                                                                                                                        <?php admin_m_input01_input([
                                                                                                                            'type' => 'text',
                                                                                                                            'data-target' => 'c-formEditor__choiceInput',
                                                                                                                            'value' => (string) $choiceOpt,
                                                                                                                            'placeholder' => '選択肢',
                                                                                                                        ]); ?>
                                                                                                                    <?php admin_m_input01_close(); ?>
                                                                                                                </div>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <?php admin_m_delete_btn01('c-formEditor__choiceRemove'); ?>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                <?php endforeach; ?>
                                                                                <div class="area is-contents" data-target="c-formEditor__choiceControls">
                                                                                    <?php admin_m_btn01_open('center'); ?>
                                                                                        <?php admin_m_btn01_button('＋ 選択肢を追加', [
                                                                                            'type' => 'button',
                                                                                            'class' => 'is-add',
                                                                                            'data-target' => 'c-formEditor__choiceAdd',
                                                                                        ]); ?>
                                                                                        <textarea name="fields[<?= $idx ?>][options]" data-target="c-formEditor__optionsSource" rows="4" hidden><?= e($f['options'] ?? '') ?></textarea>
                                                                                    <?php admin_m_btn01_close(); ?>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                </div>
                            <?php if (($f['type'] ?? '') === 'radio'): ?>
                            <div class="block is-field" data-target="c-formEditor__radioDefaultSettings">
                                <div class="c-formEditor__field">
                                    <div class="wrapper">
                                        <div class="block is-contents">
                                            <div class="area is-title">
                                                <label class="label" data-module="m-labelTitle01">初期選択</label>
                                            </div>
                                            <div class="area is-field">
                                                <?php admin_m_input01_open(); ?>
                                                    <select name="fields[<?= $idx ?>][radio_default_value]" data-target="c-formEditor__radioDefaultValue" data-value="<?= e((string) ($f['radio_default_value'] ?? '')) ?>">
                                                        <option value="">設定しない</option>
                                                    </select>
                                                <?php admin_m_input01_close(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="block is-contents" data-target="c-formEditor__displaySettings" <?= $showDisplaySettings ? '' : 'style="display:none"' ?>>
                                        <div class="block is-title">
                                            <p data-module="m-borderTitle01">表示設定</p>
                                        </div>
                                        <div class="block is-field" data-target="c-formEditor__placeholder" <?= ($isDisplayOnly || $isTextMulti || in_array($f['type'], ['radio', 'checkbox', 'select', 'file', \Models\FormField::TYPE_MATRIX], true)) ? 'style="display:none"' : '' ?>>
                                            <div class="c-formEditor__field">
                                                <div class="wrapper">
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">プレースホルダ（任意）</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_input([
                                                                    'type' => 'text',
                                                                    'name' => 'fields[' . $idx . '][placeholder]',
                                                                    'value' => (string) ($f['placeholder'] ?? ''),
                                                                ]); ?>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="block is-field" data-target="c-formEditor__fileSettings" <?= (($f['type'] ?? '') === 'file') ? '' : 'style="display:none"' ?>>
                                            <div class="c-formEditor__field">
                                                <div class="wrapper">
                                                    <?php $fileTypeMode = \Models\FormField::normalizeFileSelectionMode((string) ($f['file_type_mode'] ?? \Models\FormField::FILE_SELECTION_CUSTOM)); ?>
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">添付形式</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_radiobtn01('画像', [
                                                                'name' => 'fields[' . $idx . '][file_type_mode]',
                                                                'value' => \Models\FormField::FILE_SELECTION_IMAGE,
                                                                'data-target' => 'c-formEditor__fileTypeMode',
                                                                'checked' => $fileTypeMode === \Models\FormField::FILE_SELECTION_IMAGE,
                                                            ]); ?>
                                                            <?php admin_m_radiobtn01('形式を指定する', [
                                                                'name' => 'fields[' . $idx . '][file_type_mode]',
                                                                'value' => \Models\FormField::FILE_SELECTION_CUSTOM,
                                                                'data-target' => 'c-formEditor__fileTypeMode',
                                                                'checked' => $fileTypeMode !== \Models\FormField::FILE_SELECTION_IMAGE,
                                                            ]); ?>
                                                        </div>
                                                    </div>
                                                    <div class="block is-contents" data-target="c-formEditor__fileAllowedExtensionsWrap" <?= $fileTypeMode === \Models\FormField::FILE_SELECTION_CUSTOM ? '' : 'style="display:none"' ?>>
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">許可拡張子（任意）</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_input([
                                                                    'type' => 'text',
                                                                    'name' => 'fields[' . $idx . '][file_allowed_extensions]',
                                                                    'value' => (string) ($f['file_allowed_extensions'] ?? ''),
                                                                    'data-target' => 'c-formEditor__fileAllowedExtensions',
                                                                    'placeholder' => 'jpg, png, pdf',
                                                                ]); ?>
                                                            <?php admin_m_input01_close(); ?>
                                                            <p class="text is-help">画像を選ぶと、jpg / jpeg / png / gif / webp / heic / heif を対象にし、JPEG形式へ変換して保存します。</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="block is-field" data-target="c-formEditor__matrixSettings" <?= (($f['type'] ?? '') === \Models\FormField::TYPE_MATRIX) ? '' : 'style="display:none"' ?>>
                                            <div class="c-formEditor__field">
                                                <div class="wrapper">
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">行ラベル</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_textarea([
                                                                    'name' => 'fields[' . $idx . '][matrix_rows]',
                                                                    'rows' => 4,
                                                                    'data-target' => 'c-formEditor__matrixRows',
                                                                ], (string) ($f['matrix_rows'] ?? '')); ?>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">列ラベル</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_textarea([
                                                                    'name' => 'fields[' . $idx . '][matrix_columns]',
                                                                    'rows' => 4,
                                                                    'data-target' => 'c-formEditor__matrixColumns',
                                                                ], (string) ($f['matrix_columns'] ?? '')); ?>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">選択方式</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <select name="fields[<?= $idx ?>][matrix_selection_type]" data-target="c-formEditor__matrixSelectionType">
                                                                    <option value="radio"<?= (($f['matrix_selection_type'] ?? 'radio') === 'radio') ? ' selected' : '' ?>>行ごとに1つ選択</option>
                                                                </select>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="block is-field" data-target="c-formEditor__textMultiSettings" <?= $isTextMulti ? '' : 'style="display:none"' ?>>
                                            <div class="c-formEditor__field">
                                                <div class="c-formEditor__textMultiList" data-text-multi-editor>
                                                    <div class="wrapper">
                                                        <div class="block is-contents" data-target="c-formEditor__textMultiListContents">
                                                            <?php foreach ($multiTextItems as $multiTextIndex => $multiTextItem): ?>
                                                                <div class="area is-contents">
                                                                    <div class="c-formEditor__textMultiItem" data-text-multi-item>
                                                                        <div class="wrapper">
                                                                            <div class="block is-contents">
                                                                                <div class="c-formEditor__child__field">
                                                                                    <div class="wrapper">
                                                                                        <div class="block is-contents">
                                                                                            <div class="area is-title">
                                                                                                <label data-module="m-labelSmallTitle01">表示名</label>
                                                                                            </div>
                                                                                            <div class="area is-field">
                                                                                                <?php admin_m_input01_open(); ?>
                                                                                                    <?php admin_m_input01_input([
                                                                                                        'type' => 'text',
                                                                                                        'data-target' => 'c-formEditor__textMultiLabelInput',
                                                                                                        'value' => (string) ($multiTextItem['label'] ?? ''),
                                                                                                    ]); ?>
                                                                                                <?php admin_m_input01_close(); ?>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="block is-contents">
                                                                                            <div class="area is-title">
                                                                                                <label data-module="m-labelSmallTitle01">入力例</label>
                                                                                            </div>
                                                                                            <div class="area is-field">
                                                                                                <?php admin_m_input01_open(); ?>
                                                                                                    <?php admin_m_input01_input([
                                                                                                        'type' => 'text',
                                                                                                        'data-target' => 'c-formEditor__textMultiPlaceholderInput',
                                                                                                        'value' => (string) ($multiTextItem['placeholder'] ?? ''),
                                                                                                    ]); ?>
                                                                                                <?php admin_m_input01_close(); ?>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="block is-contents">
                                                                                            <div class="area is-title">
                                                                                                <label data-module="m-labelSmallTitle01">初期値</label>
                                                                                            </div>
                                                                                            <div class="area is-field">
                                                                                                <?php admin_m_input01_open(); ?>
                                                                                                    <?php admin_m_input01_input([
                                                                                                        'type' => 'text',
                                                                                                        'data-target' => 'c-formEditor__textMultiDefaultValueInput',
                                                                                                        'value' => (string) ($multiTextItem['default_value'] ?? ''),
                                                                                                    ]); ?>
                                                                                                <?php admin_m_input01_close(); ?>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <?php admin_m_delete_btn01('c-formEditor__textMultiRemove'); ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            <?php endforeach; ?>
                                                             <div class="area is-contents" data-target="c-formEditor__textMultiControls">
                                                                 <?php admin_m_btn01_open('center'); ?>
                                                                     <?php admin_m_btn01_button('＋ 入力エリアを追加', [
                                                                         'type' => 'button',
                                                                         'class' => 'is-add fb-description-add',
                                                                        'data-target' => 'c-formEditor__textMultiAdd',
                                                                     ]); ?>
                                                                     <textarea name="fields[<?= $idx ?>][multi_text_items]" data-target="c-formEditor__textMultiSource" hidden><?= e(json_encode($multiTextItems, JSON_UNESCAPED_UNICODE)) ?></textarea>
                                                                 <?php admin_m_btn01_close(); ?>
                                                             </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="block is-field" data-target="c-formEditor__postalCodeSettings" <?= $isPostalCode ? '' : 'style="display:none"' ?>>
                                            <div class="c-formEditor__field">
                                                <div class="wrapper">
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">郵便番号補完先（都道府県UUID）</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_input([
                                                                    'type' => 'text',
                                                                    'name' => 'fields[' . $idx . '][postal_target_prefecture]',
                                                                    'value' => (string) ($f['postal_target_prefecture'] ?? ''),
                                                                    'data-target' => 'c-formEditor__postalCodePrefectureTarget',
                                                                ]); ?>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">郵便番号補完先（市区町村UUID）</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_input([
                                                                    'type' => 'text',
                                                                    'name' => 'fields[' . $idx . '][postal_target_city]',
                                                                    'value' => (string) ($f['postal_target_city'] ?? ''),
                                                                    'data-target' => 'c-formEditor__postalCodeCityTarget',
                                                                ]); ?>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="block is-field" data-target="c-formEditor__defaultValueSettings" <?= in_array(($f['type'] ?? ''), ['textarea', 'number'], true) ? '' : 'style="display:none"' ?>>
                                            <div class="c-formEditor__field">
                                                <div class="wrapper">
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">初期値</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_input([
                                                                    'type' => 'text',
                                                                    'name' => 'fields[' . $idx . '][default_value]',
                                                                    'value' => (string) ($f['default_value'] ?? ''),
                                                                    'data-target' => 'c-formEditor__defaultValueInput',
                                                                ]); ?>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="block is-field" data-target="c-formEditor__dateDefaultSettings" <?= (($f['type'] ?? '') === 'date') ? '' : 'style="display:none"' ?>>
                                            <div class="c-formEditor__field">
                                                <div class="wrapper">
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">初期値</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <select name="fields[<?= $idx ?>][date_default_mode]" data-target="c-formEditor__dateDefaultMode">
                                                                    <option value=""<?= (($f['date_default_mode'] ?? '') === '') ? ' selected' : '' ?>>設定しない</option>
                                                                    <option value="today"<?= (($f['date_default_mode'] ?? '') === 'today') ? ' selected' : '' ?>>今日</option>
                                                                    <option value="fixed"<?= (($f['date_default_mode'] ?? '') === 'fixed') ? ' selected' : '' ?>>固定値</option>
                                                                </select>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">固定日付</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_input([
                                                                    'type' => 'date',
                                                                    'name' => 'fields[' . $idx . '][date_default_value]',
                                                                    'value' => (string) ($f['date_default_value'] ?? ''),
                                                                    'data-target' => 'c-formEditor__dateDefaultValue',
                                                                ]); ?>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="block is-field" data-target="c-formEditor__timeDefaultSettings" <?= (($f['type'] ?? '') === 'time') ? '' : 'style="display:none"' ?>>
                                            <div class="c-formEditor__field">
                                                <div class="wrapper">
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">初期値</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <select name="fields[<?= $idx ?>][time_default_mode]" data-target="c-formEditor__timeDefaultMode">
                                                                    <option value=""<?= (($f['time_default_mode'] ?? '') === '') ? ' selected' : '' ?>>設定しない</option>
                                                                    <option value="now"<?= (($f['time_default_mode'] ?? '') === 'now') ? ' selected' : '' ?>>現在時刻</option>
                                                                    <option value="fixed"<?= (($f['time_default_mode'] ?? '') === 'fixed') ? ' selected' : '' ?>>固定値</option>
                                                                </select>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                    <div class="block is-contents">
                                                        <div class="area is-title">
                                                            <label class="label" data-module="m-labelTitle01">固定時刻</label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_input([
                                                                    'type' => 'time',
                                                                    'name' => 'fields[' . $idx . '][time_default_value]',
                                                                    'value' => (string) ($f['time_default_value'] ?? ''),
                                                                    'data-target' => 'c-formEditor__timeDefaultValue',
                                                                ]); ?>
                                                            <?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="block is-field" data-target="c-formEditor__helpTextBlock" <?= ($isDisplayOnly && !$isHeading && !$isDescription) ? 'style="display:none"' : '' ?>>
                                            <div class="c-formEditor__field">
                                                <div class="wrapper">
                                                    <div class="block is-contents">
                                                        <div class="area is-title" data-target="c-formEditor__helpTextTitle" <?= $isDescription ? 'style="display:none"' : '' ?>>
                                                            <label class="label" data-module="m-labelTitle01" data-target="c-formEditor__helpTextLabel"><?= $isHeading ? '見出し' : '説明文' ?></label>
                                                        </div>
                                                        <div class="area is-field">
                                                            <div data-target="c-formEditor__headingTextWrap" <?= $isHeading ? '' : 'style="display:none"' ?>>
                                                                <?php admin_m_input01_open(); ?>
                                                                    <?php
                                                                    $headingTextAttrs = [
                                                                        'type' => 'text',
                                                                        'value' => (string) ($f['help_text'] ?? ''),
                                                                        'data-name' => 'help_text',
                                                                        'data-target' => 'c-formEditor__headingTextInput',
                                                                    ];
                                                                    if ($isHeading) {
                                                                        $headingTextAttrs['name'] = 'fields[' . $idx . '][help_text]';
                                                                    } else {
                                                                        $headingTextAttrs['disabled'] = true;
                                                                    }
                                                                    admin_m_input01_input($headingTextAttrs);
                                                                    ?>
                                                                <?php admin_m_input01_close(); ?>
                                                            </div>
                                                            <?php admin_c_html_input_editor01_open([
                                                                'data-html-toggle-editor' => true,
                                                                'data-target' => 'c-formEditor__helpTextEditor',
                                                                'style' => $isHeading ? 'display:none' : null,
                                                            ]); ?>
                                                                    <div class="block is-editor">
                                                                        <?php admin_m_input01_open(); ?>
                                                                            <?php
                                                                            $helpTextAttrs = [
                                                                                'rows' => 3,
                                                                                'data-name' => 'help_text',
                                                                                'data-target' => 'c-htmlInputEditor01__textarea',
                                                                            ];
                                                                            if (!$isHeading) {
                                                                                $helpTextAttrs['name'] = 'fields[' . $idx . '][help_text]';
                                                                            } else {
                                                                                $helpTextAttrs['disabled'] = true;
                                                                            }
                                                                            admin_m_input01_textarea($helpTextAttrs, (string) ($f['help_text'] ?? ''));
                                                                            ?>
                                                                        <?php admin_m_input01_close(); ?>
                                                                    </div>
                                                                    <div class="block is-toolbar" data-target="c-formEditor__helpTextToolbar" <?= $isHeading ? 'style="display:none"' : '' ?>>
                                                                        <?php admin_c_html_input_editor01_toggle([
                                                                            'name' => 'fields[' . $idx . '][help_text_is_html]',
                                                                            'checked' => $helpTextIsHtml,
                                                                            'disabled' => $isHeading,
                                                                        ]); ?>
                                                                    </div>
                                                            <?php admin_c_html_input_editor01_close(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                            <input type="hidden" name="fields[<?= $idx ?>][_remove]" value="0" data-target="c-formEditor__removeFlag">
                <?php admin_c_form_editor_item_body01_close(); ?>
            </div>
        </div>
    <?php admin_c_form_editor_item01_close(); ?>
</div>
