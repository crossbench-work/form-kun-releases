<?php
namespace Controllers;

use Core\FileStorage;
use Core\FileTypePolicy;
use Core\LinePublicFileAccess;
use Models\Submission;

class LinePublicFileController
{
    public function show(int $fileId): void
    {
        $token = trim((string) ($_GET['t'] ?? ''));
        if (LinePublicFileAccess::verifyToken($fileId, $token) === null) {
            $this->notFound();

            return;
        }

        $file = Submission::findFile($fileId);
        if ($file === null || !is_safe_inline_submission_file($file)) {
            $this->notFound();

            return;
        }

        $abs = FileStorage::absolutePath((string) ($file['stored_path'] ?? ''));
        if (!is_file($abs) || !is_readable($abs)) {
            $this->notFound();

            return;
        }

        $size = filesize($abs);
        if ($size === false || $size > LinePublicFileAccess::LINE_IMAGE_MAX_BYTES) {
            $this->notFound();

            return;
        }

        $extension = strtolower(pathinfo((string) ($file['stored_path'] ?? ''), PATHINFO_EXTENSION));
        $detectedMime = FileTypePolicy::detectMime($abs);
        if (!FileTypePolicy::isMimeAllowedForExtension($extension, $detectedMime)
            || !FileTypePolicy::isSafeInlineImage($extension, $detectedMime)) {
            $this->notFound();

            return;
        }

        $name = (string) ($file['original_name'] ?? 'image');
        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: ' . $detectedMime);
        header('Content-Length: ' . $size);
        header('Content-Disposition: inline; filename="' . self::asciiFallback($name)
            . '"; filename*=UTF-8\'\'' . rawurlencode($name));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, max-age=3600');
        readfile($abs);
        exit;
    }

    public function showStaged(string $handle): void
    {
        $token = trim((string) ($_GET['t'] ?? ''));
        if (LinePublicFileAccess::verifyStagedToken($handle, $token) === null) {
            $this->notFound();

            return;
        }

        $abs = LinePublicFileAccess::stagedAbsolutePath($handle);
        if ($abs === null) {
            $this->notFound();

            return;
        }

        $size = filesize($abs);
        if ($size === false || $size > LinePublicFileAccess::LINE_IMAGE_MAX_BYTES) {
            $this->notFound();

            return;
        }

        $detectedMime = FileTypePolicy::detectMime($abs);
        $inlineOk = false;
        foreach (['jpg', 'jpeg', 'png', 'gif', 'webp'] as $ext) {
            if (FileTypePolicy::isSafeInlineImage($ext, $detectedMime)) {
                $inlineOk = true;
                break;
            }
        }
        if (!$inlineOk) {
            $this->notFound();

            return;
        }

        while (ob_get_level() > 0) {
            ob_end_clean();
        }
        header('Content-Type: ' . $detectedMime);
        header('Content-Length: ' . $size);
        header('Content-Disposition: inline; filename="image"');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: private, max-age=3600');
        readfile($abs);
        exit;
    }

    private function notFound(): void
    {
        http_response_code(404);
        header('Content-Type: text/plain; charset=UTF-8');
        echo 'Not found';
        exit;
    }

    private static function asciiFallback(string $name): string
    {
        $ascii = preg_replace('/[^\x20-\x7e]/', '_', $name) ?? 'image';

        return str_replace('"', '_', $ascii);
    }
}
