(function () {
  'use strict';

  function currentBase() {
    return typeof window.FORMKUN_BASE === 'string' ? String(window.FORMKUN_BASE).replace(/\/?$/, '') : '';
  }

  function readJsonAttribute(el, name, fallback) {
    var raw = el.getAttribute(name);
    if (!raw) {
      return fallback;
    }
    try {
      var parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function storageAvailable() {
    try {
      var key = '__formkun_storage_check__';
      window.localStorage.setItem(key, '1');
      window.localStorage.removeItem(key);
      return true;
    } catch (e) {
      return false;
    }
  }

  var cssEscape = window.CSS && typeof window.CSS.escape === 'function'
    ? window.CSS.escape
    : function (value) { return String(value).replace(/["\\]/g, '\\$&'); };

  function valuesFor(form, name) {
    var values = [];
    form.querySelectorAll('[name="' + cssEscape(name) + '"], [name^="' + cssEscape(name) + '["]').forEach(function (input) {
      if ((input.type === 'checkbox' || input.type === 'radio') && !input.checked) return;
      if (input.disabled) return;
      values.push(String(input.value || '').trim());
    });
    return values;
  }

  function bindBranchRules(form) {
    if (!form || form.getAttribute('data-branch-bound') === '1') {
      return;
    }

    var rules = readJsonAttribute(form, 'data-branch-rules', []);
    if (rules.length === 0) {
      return;
    }

    var controlled = readJsonAttribute(form, 'data-branch-controlled-fields', []);
    var controlledGroups = readJsonAttribute(form, 'data-branch-controlled-groups', []);

    function sync() {
      var visible = {};
      rules.forEach(function (rule) {
        if (valuesFor(form, rule.source_field_key).indexOf(String(rule.expected_value || '').trim()) !== -1) {
          visible[String(rule.target_type || 'field') + ':' + rule.target_key] = true;
        }
      });

      controlledGroups.forEach(function (groupKey) {
        var box = form.querySelector('[data-group-key="' + cssEscape(groupKey) + '"]');
        if (!box) return;
        var show = !!visible['group:' + groupKey];
        box.hidden = !show;
        if ('inert' in HTMLElement.prototype) {
          box.inert = !show;
        }
        box.disabled = !show;
        box.querySelectorAll('input, textarea, select').forEach(function (input) {
          input.disabled = !show;
        });
      });

      controlled.forEach(function (fieldKey) {
        var box = form.querySelector('[data-field-key="' + cssEscape(fieldKey) + '"]');
        if (!box) return;
        var show = !!visible['field:' + fieldKey];
        box.hidden = !show;
        if ('inert' in HTMLElement.prototype) {
          box.inert = !show;
        }
        box.querySelectorAll('input, textarea, select').forEach(function (input) {
          input.disabled = !show;
        });
      });
    }

    form.addEventListener('input', sync);
    form.addEventListener('change', sync);
    form.setAttribute('data-branch-bound', '1');
    sync();
  }

  function formatDateDisplay(value) {
    var raw = String(value || '').trim();
    var match = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (!match) {
      return '';
    }

    return [match[1], match[2], match[3]].join(' / ');
  }

  function bindDateField(field) {
    if (!field || field.getAttribute('data-date-field-bound') === '1') {
      return;
    }

    var input = field.querySelector('[data-target="publicDateFieldInput"]');
    var display = field.querySelector('[data-target="publicDateFieldDisplay"]');
    if (!input || !display) {
      return;
    }

    function sync() {
      var formatted = formatDateDisplay(input.value);
      var placeholder = display.getAttribute('data-placeholder') || '';
      display.textContent = formatted || placeholder;
      field.classList.toggle('is-empty', formatted === '');
    }

    field.addEventListener('click', function (e) {
      if (e.target === input) {
        return;
      }
      if (typeof input.showPicker === 'function') {
        input.showPicker();
        return;
      }
      input.focus();
      if (typeof input.click === 'function') {
        input.click();
      }
    });

    input.addEventListener('input', sync);
    input.addEventListener('change', sync);
    field.setAttribute('data-date-field-bound', '1');
    sync();
  }

  function isHeicLikeFile(file) {
    if (!file) {
      return false;
    }
    var type = String(file.type || '').toLowerCase();
    var name = String(file.name || '').toLowerCase();
    return type === 'image/heic'
      || type === 'image/heif'
      || /\.heic$/i.test(name)
      || /\.heif$/i.test(name);
  }

  function replaceFileExtension(name, newExtension) {
    var safeName = String(name || 'upload').replace(/\.[^.]*$/, '');
    var ext = String(newExtension || 'jpg').replace(/^\.+/, '');
    return safeName + '.' + ext;
  }

  function assignConvertedFile(input, file) {
    if (!input || !file || typeof DataTransfer === 'undefined') {
      return false;
    }
    var transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    return true;
  }

  function parsePositiveInt(value, fallback) {
    var parsed = parseInt(value, 10);
    return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
  }

  function formatBytes(bytes) {
    var size = Number(bytes || 0);
    if (size >= 1024 * 1024) {
      return Math.round((size / 1024 / 1024) * 10) / 10 + 'MB';
    }
    if (size >= 1024) {
      return Math.round((size / 1024) * 10) / 10 + 'KB';
    }
    return size + 'B';
  }

  function loadImageFromBlob(blob) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(blob);
      var image = new Image();
      image.onload = function () {
        URL.revokeObjectURL(url);
        resolve(image);
      };
      image.onerror = function () {
        URL.revokeObjectURL(url);
        reject(new Error('image load failed'));
      };
      image.src = url;
    });
  }

  function createJpegBlobFromImage(image, maxWidth, maxHeight, quality) {
    if (typeof HTMLCanvasElement === 'undefined') {
      return Promise.reject(new Error('canvas unavailable'));
    }

    var sourceWidth = image.naturalWidth || image.width || 0;
    var sourceHeight = image.naturalHeight || image.height || 0;
    if (sourceWidth <= 0 || sourceHeight <= 0) {
      return Promise.reject(new Error('invalid image size'));
    }

    var ratio = Math.min(1, maxWidth / sourceWidth, maxHeight / sourceHeight);
    var width = Math.max(1, Math.round(sourceWidth * ratio));
    var height = Math.max(1, Math.round(sourceHeight * ratio));
    var canvas = document.createElement('canvas');
    var context = canvas.getContext('2d');
    if (!context) {
      return Promise.reject(new Error('canvas context unavailable'));
    }

    canvas.width = width;
    canvas.height = height;
    context.fillStyle = '#fff';
    context.fillRect(0, 0, width, height);
    context.drawImage(image, 0, 0, width, height);

    return new Promise(function (resolve, reject) {
      canvas.toBlob(function (jpegBlob) {
        if (!(jpegBlob instanceof Blob)) {
          reject(new Error('jpeg conversion failed'));
          return;
        }
        resolve(jpegBlob);
      }, 'image/jpeg', quality);
    });
  }

  function decodeHeicFile(file) {
    if (typeof window.heic2any !== 'function') {
      return Promise.reject(new Error('heic2any unavailable'));
    }
    return window.heic2any({
      blob: file,
      toType: 'image/jpeg',
      quality: 0.92
    }).then(function (result) {
      var blob = Array.isArray(result) ? result[0] : result;
      if (!(blob instanceof Blob)) {
        throw new Error('conversion failed');
      }
      return blob;
    });
  }

  function convertImageFileToJpeg(file, options) {
    var source = isHeicLikeFile(file) ? decodeHeicFile(file) : Promise.resolve(file);
    return source
      .then(loadImageFromBlob)
      .then(function (image) {
        var maxBase = Math.max(1, Math.min(options.maxWidth, options.maxHeight));
        var sizeSteps = [maxBase, 1000, 800, 640]
          .filter(function (size, index, list) {
            return size > 0 && size <= maxBase && list.indexOf(size) === index;
          })
          .sort(function (a, b) { return b - a; });
        var qualityBase = Math.max(0.1, Math.min(1, options.quality || 0.82));
        var qualitySteps = [qualityBase, 0.72, 0.62, 0.52, 0.42]
          .filter(function (quality, index, list) {
            return quality > 0 && list.indexOf(quality) === index;
          })
          .sort(function (a, b) { return b - a; });
        var lastFile = null;
        var sequence = Promise.resolve(null);

        sizeSteps.forEach(function (size) {
          qualitySteps.forEach(function (quality) {
            sequence = sequence.then(function (acceptedFile) {
              if (acceptedFile) {
                return acceptedFile;
              }
              return createJpegBlobFromImage(image, size, size, quality).then(function (jpegBlob) {
                var convertedFile = new File(
                  [jpegBlob],
                  replaceFileExtension(file.name || 'upload', 'jpg'),
                  { type: 'image/jpeg', lastModified: file.lastModified || Date.now() }
                );
                lastFile = convertedFile;
                if (options.maxBytes <= 0 || convertedFile.size <= options.maxBytes) {
                  return convertedFile;
                }
                return null;
              });
            });
          });
        });

        return sequence.then(function (acceptedFile) {
          if (acceptedFile) {
            return acceptedFile;
          }
          var limit = options.maxBytes > 0 ? formatBytes(options.maxBytes) : '';
          var actual = lastFile ? formatBytes(lastFile.size) : '';
          if (limit !== '' && actual !== '') {
            throw new Error('file too large:' + limit + ':' + actual);
          }
          if (limit !== '') {
            throw new Error('file too large:' + limit);
          }
          if (lastFile) {
            return lastFile;
          }
          throw new Error('jpeg conversion failed');
        });
      });
  }

  function bindFileConversion(form) {
    if (!form || form.getAttribute('data-file-conversion-bound') === '1') {
      return;
    }

    var isSubmitting = false;
    form.addEventListener('submit', function (event) {
      if (event.defaultPrevented) {
        return;
      }
      var submitter = event.submitter || null;
      if (isSubmitting) {
        return;
      }

      var targets = [];
      form.querySelectorAll('input[type="file"][data-file-selection-mode="image"]').forEach(function (input) {
        if (!input.files || !input.files[0]) {
          return;
        }
        targets.push({
          input: input,
          file: input.files[0],
          options: {
            maxWidth: parsePositiveInt(input.getAttribute('data-file-max-width'), 1200),
            maxHeight: parsePositiveInt(input.getAttribute('data-file-max-height'), 1200),
            quality: Math.max(0.1, Math.min(1, Number(input.getAttribute('data-file-jpeg-quality') || 0.82) || 0.82)),
            maxBytes: parsePositiveInt(input.getAttribute('data-file-max-size'), 0)
          }
        });
      });

      if (targets.length === 0) {
        return;
      }

      event.preventDefault();
      Promise.all(targets.map(function (target) {
        return convertImageFileToJpeg(target.file, target.options).then(function (convertedFile) {
          if (!assignConvertedFile(target.input, convertedFile)) {
            throw new Error('assign failed');
          }
          target.input.dispatchEvent(new Event('change', { bubbles: true }));
        });
      })).then(function () {
        isSubmitting = true;
        if (typeof form.requestSubmit === 'function') {
          form.requestSubmit(submitter);
          return;
        }
        form.submit();
      }).catch(function (error) {
        var errorMessage = error && error.message ? String(error.message) : '';
        var message = '画像のJPEG変換に失敗しました。別形式へ変換するか、画像変換に対応したブラウザでお試しください。';
        if (errorMessage.indexOf('file too large:') === 0) {
          var parts = errorMessage.replace('file too large:', '').split(':');
          message = '画像を圧縮してもファイルサイズが上限（' + parts[0] + '）を超えています。別の画像を選択してください。';
          if (parts[1]) {
            message = '画像を圧縮してもファイルサイズが上限（' + parts[0] + '）を超えています。現在の最小サイズは' + parts[1] + 'です。別の画像を選択してください。';
          }
        }
        window.alert(message);
      });
    });

    form.setAttribute('data-file-conversion-bound', '1');
  }

  function countCharacters(value) {
    return Array.from(String(value || '')).length;
  }

  function getFieldControls(field) {
    return Array.prototype.slice.call(field.querySelectorAll('input, textarea, select')).filter(function (control) {
      var type = String(control.type || '').toLowerCase();
      return type !== 'hidden' && type !== 'submit' && type !== 'reset' && type !== 'button';
    });
  }

  function isFieldVisible(field) {
    if (!field || field.hidden) {
      return false;
    }
    if (field.closest('[hidden]')) {
      return false;
    }
    var style = window.getComputedStyle(field);
    return style.display !== 'none' && style.visibility !== 'hidden';
  }

  function clearFieldMessages(field) {
    field.querySelectorAll('.text.is-error').forEach(function (message) {
      message.remove();
    });
  }

  function clearFieldState(field) {
    clearFieldMessages(field);
    field.classList.remove('is-error', 'is-success');
    field.querySelectorAll('.box.is-addressRow, .box.is-textPairCol, .box.is-textMultiCol').forEach(function (box) {
      box.classList.remove('is-error', 'is-success');
    });
  }

  function appendFieldMessage(field, message) {
    var error = document.createElement('p');
    error.className = 'text is-error';
    error.setAttribute('data-client-validation', '1');
    error.textContent = message;
    field.appendChild(error);
  }

  function setFieldError(field, message) {
    clearFieldState(field);
    field.classList.add('is-error');
    appendFieldMessage(field, message);
  }

  function setFieldSuccess(field) {
    clearFieldState(field);
    field.classList.add('is-success');
  }

  function getFieldLabel(field) {
    return String(field.getAttribute('data-field-label') || '').trim() || '入力項目';
  }

  function getFieldType(field) {
    return String(field.getAttribute('data-field-type') || '').trim();
  }

  function getFieldRegexPatterns(field) {
    return readJsonAttribute(field, 'data-field-regex-patterns', []);
  }

  function getFieldMinLength(field) {
    return parseInt(field.getAttribute('data-field-min-length') || '0', 10) || 0;
  }

  function getFieldMaxLength(field) {
    return parseInt(field.getAttribute('data-field-max-length') || '0', 10) || 0;
  }

  function getFieldExactLength(field) {
    return parseInt(field.getAttribute('data-field-exact-length') || '0', 10) || 0;
  }

  function getFieldCheckboxMin(field) {
    return parseInt(field.getAttribute('data-field-checkbox-min') || '0', 10) || 0;
  }

  function getFieldCheckboxMax(field) {
    return parseInt(field.getAttribute('data-field-checkbox-max') || '0', 10) || 0;
  }

  function controlHasValue(control) {
    if (!control || control.disabled) {
      return false;
    }
    if (control.type === 'checkbox' || control.type === 'radio') {
      return control.checked;
    }
    return String(control.value || '').trim() !== '';
  }

  function groupHasValue(controls) {
    return controls.some(controlHasValue);
  }

  function getMeaningfulControls(field) {
    return getFieldControls(field).filter(function (control) {
      return !control.disabled;
    });
  }

  function getFirstFocusableControl(field) {
    return getMeaningfulControls(field).find(function (control) {
      return typeof control.focus === 'function';
    }) || null;
  }

  function compileRegexPattern(pattern) {
    var source = String(pattern || '').trim();
    if (source === '') {
      return null;
    }
    try {
      if (source.charAt(0) === '/') {
        var lastSlash = source.lastIndexOf('/');
        if (lastSlash > 0) {
          var flags = source.slice(lastSlash + 1).replace(/[^dgimsuy]/g, '');
          var body = source.slice(1, lastSlash)
            .replace(/\\A/g, '^')
            .replace(/\\z/g, '$');
          return new RegExp(body, flags);
        }
      }
      return new RegExp(source.replace(/\\A/g, '^').replace(/\\z/g, '$'));
    } catch (e) {
      return null;
    }
  }

  function validateRegexPatterns(patterns, value) {
    for (var i = 0; i < patterns.length; i += 1) {
      var regex = compileRegexPattern(patterns[i]);
      if (!regex) {
        continue;
      }
      if (!regex.test(value)) {
        return false;
      }
    }
    return true;
  }

  function validateSimpleField(field, controls) {
    var control = controls[0];
    var label = getFieldLabel(field);
    var type = getFieldType(field);
    var minLength = getFieldMinLength(field);
    var maxLength = getFieldMaxLength(field);
    var exactLength = getFieldExactLength(field);
    var regexPatterns = getFieldRegexPatterns(field);
    var value = String(control && control.value || '').trim();
    var isRequired = String(field.getAttribute('data-field-required') || '') === '1';
    var result = { valid: true, hasValue: value !== '', message: '' };

    if (isRequired && value === '') {
      result.valid = false;
      result.message = label + 'は必須項目です。';
      return result;
    }
    if (value === '') {
      return result;
    }
    if (exactLength > 0) {
      if (countCharacters(value) !== exactLength) {
        result.valid = false;
        result.message = label + 'は' + exactLength + '文字で入力してください。';
        return result;
      }
    } else {
      if (minLength > 0 && countCharacters(value) < minLength) {
        result.valid = false;
        result.message = label + 'は' + minLength + '文字以上で入力してください。';
        return result;
      }
      if (maxLength > 0 && countCharacters(value) > maxLength) {
        result.valid = false;
        result.message = label + 'は' + maxLength + '文字以内で入力してください。';
        return result;
      }
    }
    if (!validateRegexPatterns(regexPatterns, value)) {
      result.valid = false;
      result.message = label + 'の形式が正しくありません。';
      return result;
    }
    if (type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      result.valid = false;
      result.message = label + 'はメールアドレスの形式で入力してください。';
      return result;
    }
    if (type === 'tel' && !/^[0-9+\-\s()]{6,20}$/.test(value)) {
      result.valid = false;
      result.message = label + 'は電話番号の形式で入力してください。';
      return result;
    }
    if (type === 'number' && Number.isNaN(Number(value))) {
      result.valid = false;
      result.message = label + 'は数値で入力してください。';
      return result;
    }
    if (type === 'time' && !/^\d{2}:\d{2}$/.test(value)) {
      result.valid = false;
      result.message = label + 'は時間（時:分）で入力してください。';
      return result;
    }
    if (type === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
      result.valid = false;
      result.message = label + 'は日付で入力してください。';
      return result;
    }
    if (type === 'postal_code') {
      var digits = value.replace(/\D/g, '');
      if (!/^\d{7}$/.test(digits)) {
        result.valid = false;
        result.message = label + 'は7桁の数字で入力してください。';
        return result;
      }
    }

    return result;
  }

  function validateSelectField(field, controls) {
    return validateSimpleField(field, controls);
  }

  function validateRadioField(field, controls) {
    var label = getFieldLabel(field);
    var checked = controls.find(function (control) { return control.checked; }) || null;
    var isRequired = String(field.getAttribute('data-field-required') || '') === '1';
    return {
      valid: !(isRequired && !checked),
      hasValue: !!checked,
      message: isRequired && !checked ? label + 'を選択してください。' : ''
    };
  }

  function validateCheckboxField(field, controls) {
    var label = getFieldLabel(field);
    var selected = controls.filter(function (control) { return control.checked; }).length;
    var isRequired = String(field.getAttribute('data-field-required') || '') === '1';
    var minSelections = getFieldCheckboxMin(field);
    var maxSelections = getFieldCheckboxMax(field);
    var result = {
      valid: true,
      hasValue: selected > 0,
      message: ''
    };

    if (isRequired && selected === 0) {
      result.valid = false;
      result.message = label + 'は必須項目です。';
      return result;
    }
    if (selected === 0) {
      return result;
    }
    if (minSelections > 0 && selected < minSelections) {
      result.valid = false;
      result.message = label + 'は' + minSelections + '個以上選択してください。';
      return result;
    }
    if (maxSelections > 0 && selected > maxSelections) {
      result.valid = false;
      result.message = label + 'は' + maxSelections + '個以下で選択してください。';
      return result;
    }

    return result;
  }

  function validateFileField(field, controls) {
    var label = getFieldLabel(field);
    var input = controls[0];
    var hasValue = !!(input && input.files && input.files.length > 0);
    var isRequired = String(field.getAttribute('data-field-required') || '') === '1';
    return {
      valid: !(isRequired && !hasValue),
      hasValue: hasValue,
      message: isRequired && !hasValue ? label + 'は必須項目です。' : ''
    };
  }

  function validateTextPairField(field, controls) {
    var label = getFieldLabel(field);
    var isRequired = String(field.getAttribute('data-field-required') || '') === '1';
    var minLength = getFieldMinLength(field);
    var maxLength = getFieldMaxLength(field);
    var exactLength = getFieldExactLength(field);
    var regexPatterns = getFieldRegexPatterns(field);
    var left = controls[0] || null;
    var right = controls[1] || null;
    var leftValue = String(left && left.value || '').trim();
    var rightValue = String(right && right.value || '').trim();
    var leftLabel = String(left && (left.getAttribute('aria-label') || '') || '入力欄1').trim();
    var rightLabel = String(right && (right.getAttribute('aria-label') || '') || '入力欄2').trim();
    var result = {
      valid: true,
      hasValue: leftValue !== '' || rightValue !== '',
      message: ''
    };

    if (isRequired && !result.hasValue) {
      result.valid = false;
      result.message = label + 'の' + leftLabel + 'を入力してください。';
      return result;
    }
    if (!isRequired && !result.hasValue) {
      return result;
    }
    if (isRequired && leftValue === '') {
      result.valid = false;
      result.message = label + 'の' + leftLabel + 'を入力してください。';
      return result;
    }
    if (isRequired && rightValue === '') {
      result.valid = false;
      result.message = label + 'の' + rightLabel + 'を入力してください。';
      return result;
    }

    var pairs = [
      { value: leftValue, label: leftLabel },
      { value: rightValue, label: rightLabel }
    ];
    for (var i = 0; i < pairs.length; i += 1) {
      var part = pairs[i];
      if (part.value === '') {
        continue;
      }
      if (exactLength > 0) {
        if (countCharacters(part.value) !== exactLength) {
          result.valid = false;
          result.message = label + 'の' + part.label + 'は' + exactLength + '文字で入力してください。';
          return result;
        }
      } else {
        if (minLength > 0 && countCharacters(part.value) < minLength) {
          result.valid = false;
          result.message = label + 'の' + part.label + 'は' + minLength + '文字以上で入力してください。';
          return result;
        }
        if (maxLength > 0 && countCharacters(part.value) > maxLength) {
          result.valid = false;
          result.message = label + 'の' + part.label + 'は' + maxLength + '文字以内で入力してください。';
          return result;
        }
      }
      if (!validateRegexPatterns(regexPatterns, part.value)) {
        result.valid = false;
        result.message = label + 'の' + part.label + 'の形式が正しくありません。';
        return result;
      }
    }

    return result;
  }

  function validateTextMultiField(field, controls) {
    var label = getFieldLabel(field);
    var isRequired = String(field.getAttribute('data-field-required') || '') === '1';
    var minLength = getFieldMinLength(field);
    var maxLength = getFieldMaxLength(field);
    var exactLength = getFieldExactLength(field);
    var regexPatterns = getFieldRegexPatterns(field);
    var values = controls.map(function (control) {
      return String(control.value || '').trim();
    });
    var hasValue = values.some(function (value) { return value !== ''; });
    var result = {
      valid: true,
      hasValue: hasValue,
      message: ''
    };

    if (isRequired && !hasValue) {
      result.valid = false;
      result.message = label + 'は必須項目です。';
      return result;
    }
    if (!isRequired && !hasValue) {
      return result;
    }
    for (var i = 0; i < controls.length; i += 1) {
      var partLabel = String(controls[i].getAttribute('aria-label') || ('入力欄' + (i + 1))).trim();
      var value = values[i];
      if (isRequired && value === '') {
        result.valid = false;
        result.message = label + 'の' + partLabel + 'を入力してください。';
        return result;
      }
      if (value === '') {
        continue;
      }
      if (exactLength > 0) {
        if (countCharacters(value) !== exactLength) {
          result.valid = false;
          result.message = label + 'の' + partLabel + 'は' + exactLength + '文字で入力してください。';
          return result;
        }
      } else {
        if (minLength > 0 && countCharacters(value) < minLength) {
          result.valid = false;
          result.message = label + 'の' + partLabel + 'は' + minLength + '文字以上で入力してください。';
          return result;
        }
        if (maxLength > 0 && countCharacters(value) > maxLength) {
          result.valid = false;
          result.message = label + 'の' + partLabel + 'は' + maxLength + '文字以内で入力してください。';
          return result;
        }
      }
      if (!validateRegexPatterns(regexPatterns, value)) {
        result.valid = false;
        result.message = label + 'の' + partLabel + 'の形式が正しくありません。';
        return result;
      }
    }

    return result;
  }

  function validateMatrixField(field, controls) {
    var label = getFieldLabel(field);
    var isRequired = String(field.getAttribute('data-field-required') || '') === '1';
    var rows = Array.prototype.slice.call(field.querySelectorAll('.box.is-matrix tbody tr'));
    var hasValue = controls.some(function (control) { return control.checked; });
    var result = {
      valid: true,
      hasValue: hasValue,
      message: ''
    };

    if (!isRequired && !hasValue) {
      return result;
    }
    for (var i = 0; i < rows.length; i += 1) {
      var row = rows[i];
      var rowLabelNode = row.querySelector('th');
      var rowLabel = String(rowLabelNode && rowLabelNode.textContent || ('行' + (i + 1))).trim();
      var rowChecked = !!row.querySelector('input[type="radio"]:checked');
      if (isRequired && !rowChecked) {
        result.valid = false;
        result.message = label + 'の「' + rowLabel + '」を選択してください。';
        return result;
      }
    }

    return result;
  }

  function validateAddressField(field) {
    var label = getFieldLabel(field);
    var isRequired = String(field.getAttribute('data-field-required') || '') === '1';
    var minLength = getFieldMinLength(field);
    var maxLength = getFieldMaxLength(field);
    var exactLength = getFieldExactLength(field);
    var regexPatterns = getFieldRegexPatterns(field);
    var postal1 = field.querySelector('.input-postal-part1');
    var postal2 = field.querySelector('.input-postal-part2');
    var prefecture = field.querySelector('.input-prefecture');
    var city = field.querySelector('.input-city');
    var number = field.querySelector('.input-number');
    var building = field.querySelector('.input-building');
    var postal = (String(postal1 && postal1.value || '') + String(postal2 && postal2.value || '')).replace(/\D/g, '');
    var prefectureValue = String(prefecture && prefecture.value || '').trim();
    var cityValue = String(city && city.value || '').trim();
    var numberValue = String(number && number.value || '').trim();
    var buildingValue = String(building && building.value || '').trim();
    var combined = prefectureValue + cityValue + numberValue + buildingValue;
    var hasValue = postal !== '' || combined !== '';
    var result = {
      valid: true,
      hasValue: hasValue,
      message: ''
    };

    if (isRequired && !hasValue) {
      result.valid = false;
      result.message = label + 'の都道府県を選択してください。';
      return result;
    }
    if (!isRequired && !hasValue) {
      return result;
    }
    if (postal !== '' && !/^\d{7}$/.test(postal)) {
      result.valid = false;
      result.message = label + 'の郵便番号は7桁の数字で入力してください。';
      return result;
    }
    if (prefectureValue === '') {
      result.valid = false;
      result.message = label + 'の都道府県を選択してください。';
      return result;
    }
    if (cityValue === '') {
      result.valid = false;
      result.message = label + 'の市区町村を入力してください。';
      return result;
    }
    if (numberValue === '') {
      result.valid = false;
      result.message = label + 'の番地を入力してください。';
      return result;
    }
    if (exactLength > 0) {
      if (combined !== '' && countCharacters(combined) !== exactLength) {
        result.valid = false;
        result.message = label + 'は合計' + exactLength + '文字で入力してください。';
        return result;
      }
    } else {
      if (minLength > 0 && cityValue !== '' && countCharacters(cityValue) < minLength) {
        result.valid = false;
        result.message = label + 'の市区町村は' + minLength + '文字以上で入力してください。';
        return result;
      }
      if (minLength > 0 && numberValue !== '' && countCharacters(numberValue) < minLength) {
        result.valid = false;
        result.message = label + 'の番地は' + minLength + '文字以上で入力してください。';
        return result;
      }
      if (minLength > 0 && buildingValue !== '' && countCharacters(buildingValue) < minLength) {
        result.valid = false;
        result.message = label + 'の建物名・部屋番号は' + minLength + '文字以上で入力してください。';
        return result;
      }
      if (maxLength > 0 && countCharacters(combined) > maxLength) {
        result.valid = false;
        result.message = label + 'は合計' + maxLength + '文字以内で入力してください。';
        return result;
      }
    }
    if (!validateRegexPatterns(regexPatterns, combined)) {
      result.valid = false;
      result.message = label + 'の形式が正しくありません。';
      return result;
    }

    return result;
  }

  function validateField(field, options) {
    options = options || {};
    if (!isFieldVisible(field)) {
      clearFieldState(field);
      return true;
    }

    var controls = getMeaningfulControls(field);
    if (controls.length === 0) {
      clearFieldState(field);
      return true;
    }

    var type = getFieldType(field);
    var touched = field.getAttribute('data-field-touched') === '1';
    var submitted = options.submitted === true;
    var result;

    switch (type) {
      case 'radio':
        result = validateRadioField(field, controls);
        break;
      case 'checkbox':
        result = validateCheckboxField(field, controls);
        break;
      case 'file':
        result = validateFileField(field, controls);
        break;
      case 'text_pair':
        result = validateTextPairField(field, controls);
        break;
      case 'text_multi':
        result = validateTextMultiField(field, controls);
        break;
      case 'address':
        result = validateAddressField(field);
        break;
      case 'matrix':
        result = validateMatrixField(field, controls);
        break;
      case 'select':
        result = validateSelectField(field, controls);
        break;
      default:
        result = validateSimpleField(field, controls);
        break;
    }

    if (!submitted && !touched && !result.hasValue) {
      clearFieldState(field);
      return true;
    }
    if (!result.valid) {
      setFieldError(field, result.message);
      return false;
    }
    if (result.hasValue) {
      setFieldSuccess(field);
      return true;
    }

    clearFieldState(field);
    return true;
  }

  function validateVisibleFields(form, options) {
    var allValid = true;
    form.querySelectorAll('.area.is-field[data-field-type]').forEach(function (field) {
      if (!validateField(field, options)) {
        allValid = false;
      }
    });
    return allValid;
  }

  function focusFirstInvalidField(form) {
    var field = form.querySelector('.area.is-field.is-error');
    var control = field ? getFirstFocusableControl(field) : null;
    if (control) {
      control.focus();
    }
  }

  function buildStorageKey(form) {
    var prefix = String(form.getAttribute('data-form-storage-prefix') || '').trim();
    var pageKey = String(form.getAttribute('data-form-page-key') || '').trim();
    if (prefix === '' || pageKey === '') {
      return '';
    }
    return prefix + pageKey;
  }

  function clearStoredFormStateByPrefix(prefix) {
    if (!prefix || !storageAvailable()) {
      return;
    }
    for (var i = window.localStorage.length - 1; i >= 0; i -= 1) {
      var key = window.localStorage.key(i);
      if (key && key.indexOf(prefix) === 0) {
        window.localStorage.removeItem(key);
      }
    }
  }

  function serializeFormState(form) {
    var groups = {};
    form.querySelectorAll('input[name], textarea[name], select[name]').forEach(function (control) {
      if (control.disabled) {
        return;
      }
      var type = String(control.type || '').toLowerCase();
      if (type === 'hidden' || type === 'file' || type === 'submit' || type === 'reset' || type === 'button') {
        return;
      }
      var name = String(control.name || '');
      if (name === '') {
        return;
      }
      if (!groups[name]) {
        groups[name] = [];
      }
      groups[name].push(control);
    });

    var state = {};
    Object.keys(groups).forEach(function (name) {
      var controls = groups[name];
      var first = controls[0];
      if (first.type === 'checkbox') {
        state[name] = controls.filter(function (control) {
          return control.checked;
        }).map(function (control) {
          return String(control.value || '');
        });
        return;
      }
      if (first.type === 'radio') {
        var checked = controls.find(function (control) {
          return control.checked;
        });
        state[name] = checked ? String(checked.value || '') : '';
        return;
      }
      if (controls.length > 1) {
        state[name] = controls.map(function (control) {
          return String(control.value || '');
        });
        return;
      }
      state[name] = String(first.value || '');
    });

    return state;
  }

  function snapshotFormState(form) {
    return JSON.stringify(serializeFormState(form));
  }

  function dispatchRestoredEvents(control) {
    control.dispatchEvent(new Event('input', { bubbles: true }));
    control.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function restoreStoredFormState(form) {
    var storageKey = buildStorageKey(form);
    if (storageKey === '' || !storageAvailable()) {
      return false;
    }

    var raw = window.localStorage.getItem(storageKey);
    if (!raw) {
      return false;
    }

    var restored = false;
    try {
      var state = JSON.parse(raw);
      Object.keys(state || {}).forEach(function (name) {
        var controls = Array.prototype.slice.call(form.querySelectorAll('[name="' + cssEscape(name) + '"]'));
        if (controls.length === 0 || groupHasValue(controls)) {
          return;
        }
        var first = controls[0];
        var value = state[name];
        if (first.type === 'checkbox') {
          var checkedValues = Array.isArray(value) ? value.map(String) : [];
          controls.forEach(function (control) {
            control.checked = checkedValues.indexOf(String(control.value || '')) !== -1;
            dispatchRestoredEvents(control);
          });
          restored = true;
          return;
        }
        if (first.type === 'radio') {
          controls.forEach(function (control) {
            control.checked = String(value || '') === String(control.value || '');
            dispatchRestoredEvents(control);
          });
          restored = true;
          return;
        }
        if (controls.length > 1 && Array.isArray(value)) {
          controls.forEach(function (control, index) {
            control.value = typeof value[index] === 'undefined' ? '' : String(value[index] || '');
            dispatchRestoredEvents(control);
          });
          restored = true;
          return;
        }
        first.value = String(value || '');
        dispatchRestoredEvents(first);
        restored = true;
      });
    } catch (e) {
      window.localStorage.removeItem(storageKey);
      return false;
    }

    return restored;
  }

  function saveStoredFormState(form) {
    var storageKey = buildStorageKey(form);
    if (storageKey === '' || !storageAvailable()) {
      return;
    }
    try {
      window.localStorage.setItem(storageKey, JSON.stringify(serializeFormState(form)));
    } catch (e) {
      // ignore quota / availability errors
    }
  }

  function bindFormEnhancements(form) {
    if (!form || form.getAttribute('data-form-enhanced') === '1') {
      return;
    }

    var initialSnapshot = snapshotFormState(form);
    form.setAttribute('data-form-restoring', '1');
    restoreStoredFormState(form);
    form.removeAttribute('data-form-restoring');
    saveStoredFormState(form);

    function isDirty() {
      return snapshotFormState(form) !== initialSnapshot;
    }

    form.addEventListener('focusout', function (event) {
      var target = event.target;
      var field = target && target.closest ? target.closest('.area.is-field[data-field-type]') : null;
      if (!field) {
        return;
      }
      field.setAttribute('data-field-touched', '1');
      validateField(field);
      saveStoredFormState(form);
    });

    form.addEventListener('change', function (event) {
      if (form.getAttribute('data-form-restoring') === '1') {
        return;
      }
      var target = event.target;
      var field = target && target.closest ? target.closest('.area.is-field[data-field-type]') : null;
      if (!field) {
        saveStoredFormState(form);
        return;
      }
      field.setAttribute('data-field-touched', '1');
      validateField(field);
      saveStoredFormState(form);
    });

    form.addEventListener('input', function (event) {
      if (form.getAttribute('data-form-restoring') === '1') {
        return;
      }
      var target = event.target;
      var field = target && target.closest ? target.closest('.area.is-field[data-field-type]') : null;
      if (field && (field.getAttribute('data-field-touched') === '1' || form.getAttribute('data-form-submit-attempted') === '1')) {
        validateField(field);
      }
      saveStoredFormState(form);
    });

    form.addEventListener('submit', function (event) {
      form.setAttribute('data-form-submit-attempted', '1');
      if (!validateVisibleFields(form, { submitted: true })) {
        event.preventDefault();
        form.removeAttribute('data-form-navigating');
        focusFirstInvalidField(form);
        return;
      }
      form.setAttribute('data-form-navigating', '1');
      saveStoredFormState(form);
    });

    if (form.getAttribute('data-form-dirty-alert') === '1') {
      window.addEventListener('beforeunload', function (event) {
        if (form.getAttribute('data-form-navigating') === '1' || !isDirty()) {
          return;
        }
        event.preventDefault();
        event.returnValue = '';
      });
    }

    form.setAttribute('data-form-enhanced', '1');
  }

  function bindStorageCleanup(root) {
    var scope = root && root.querySelectorAll ? root : document;
    var targets = [];
    if (scope.matches && scope.matches('[data-form-storage-clear-prefix]')) {
      targets.push(scope);
    }
    scope.querySelectorAll('[data-form-storage-clear-prefix]').forEach(function (el) {
      targets.push(el);
    });
    targets.forEach(function (el) {
      if (el.getAttribute('data-form-storage-cleared') === '1') {
        return;
      }
      clearStoredFormStateByPrefix(String(el.getAttribute('data-form-storage-clear-prefix') || ''));
      el.setAttribute('data-form-storage-cleared', '1');
    });
  }

  function init(root) {
    var scope = root && root.querySelectorAll ? root : document;
    if (scope.matches && scope.matches('form[data-module="c-formSet01"]')) {
      bindFormEnhancements(scope);
      bindBranchRules(scope);
      bindFileConversion(scope);
    }
    scope.querySelectorAll('form[data-module="c-formSet01"]').forEach(bindFormEnhancements);
    scope.querySelectorAll('form[data-module="c-formSet01"]').forEach(bindBranchRules);
    scope.querySelectorAll('form[data-module="c-formSet01"]').forEach(bindFileConversion);
    if (scope.matches && scope.matches('[data-date-field]')) {
      bindDateField(scope);
    }
    scope.querySelectorAll('[data-date-field]').forEach(bindDateField);
    bindStorageCleanup(scope);
  }

  window.FormKunPublicForm = {
    init: init
  };

  document.addEventListener('click', function (e) {
    var btn = e.target && e.target.closest ? e.target.closest('.js-zip-lookup') : null;
    if (!btn) {
      return;
    }
    var addressWrap = btn.closest ? btn.closest('[data-form-address]') : null;
    var postalWrap = btn.getAttribute('data-postal-code-field') === '1'
      ? (btn.closest ? btn.closest('.is-textMultiCol') : null)
      : null;
    if (!addressWrap && !postalWrap) {
      return;
    }
    e.preventDefault();
    var zip = '';
    var prefSel = null;
    var cityInp = null;

    function setFieldValue(field, value) {
      if (!field) return;
      field.value = value;
      field.dispatchEvent(new Event('input', { bubbles: true }));
      field.dispatchEvent(new Event('change', { bubbles: true }));
    }
    if (addressWrap) {
      var p1 = addressWrap.querySelector('.input-postal-part1');
      var p2 = addressWrap.querySelector('.input-postal-part2');
      prefSel = addressWrap.querySelector('.input-prefecture');
      cityInp = addressWrap.querySelector('.input-city');
      if (!p1 || !p2 || !prefSel || !cityInp) {
        return;
      }
      zip = ((p1.value || '') + (p2.value || '')).replace(/\D/g, '');
    } else {
      var postalInput = postalWrap ? postalWrap.querySelector('input[type="text"]') : null;
      if (!postalInput) {
        return;
      }
      zip = String(postalInput.value || '').replace(/\D/g, '');
      var form = btn.closest ? btn.closest('form') : null;
      var prefKey = btn.getAttribute('data-postal-target-prefecture') || '';
      var cityKey = btn.getAttribute('data-postal-target-city') || '';
      if (form && prefKey) {
        prefSel = form.querySelector('[name="' + cssEscape(prefKey + '[prefecture]') + '"], [name="' + cssEscape(prefKey + '[items][]') + '"], [name="' + cssEscape(prefKey) + '"]');
      }
      if (form && cityKey) {
        cityInp = form.querySelector('[name="' + cssEscape(cityKey + '[city]') + '"], [name="' + cssEscape(cityKey + '[items][]') + '"], [name="' + cssEscape(cityKey) + '"]');
      }
    }
    if (zip.length !== 7) {
      window.alert('郵便番号は7桁の数字で入力してください。');
      return;
    }
    var url = currentBase() + '/api/postal/lookup?zip=' + encodeURIComponent(zip);
    fetch(url, { credentials: 'same-origin' })
      .then(function (r) {
        if (!r.ok) {
          throw new Error('http');
        }
        return r.json();
      })
      .then(function (data) {
        if (data && data.ok && (data.prefecture || data.city)) {
          if (data.prefecture && prefSel) {
            setFieldValue(prefSel, data.prefecture);
          }
          if (cityInp) {
            setFieldValue(cityInp, data.city || '');
          }
        } else {
          window.alert((data && data.message) || '該当する住所が見つかりません。');
        }
      })
      .catch(function () {
        window.alert('住所検索に失敗しました。');
      });
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () {
      init(document);
    });
  } else {
    init(document);
  }
})();
