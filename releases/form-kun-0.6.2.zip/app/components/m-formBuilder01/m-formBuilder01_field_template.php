<template data-target="m-formBuilder01__fieldTemplate">
    <?php admin_c_form_editor_item01_open([
        'data-field-item' => '1',
    ]); ?>
        <div class="wrapper">
            <div class="block is-header">
                <?php admin_c_form_editor_item_header01_open(); ?>
                            <div class="area is-move">
                                <div class="box is-handle ui-sortable-handle" title="ドラッグして並べ替え">
                                    <?php admin_m_drag_handle01('c-formEditor__dragHandle'); ?>
                                </div>
                            </div>
                            <div class="area is-summary">
                                <div class="c-formEditorSummary01">
                                    <div class="wrapper">
                                        <div class="block is-contents">
                                            <p class="index" data-target="c-formEditor__summaryIndex">1</p>
                                            <p class="label" data-target="c-formEditor__summaryLabel"></p>
                                            <p class="type" data-target="c-formEditor__summaryType">
                                                <?= e(\Models\FormField::typeLabel('text_multi')) ?></p>
                                            <p class="required" data-target="c-formEditor__summaryRequired" hidden>必須
                                            </p>
                                            <p class="regex" data-target="c-formEditor__summaryRegexWrap" hidden><svg
                                                    width="12" height="12" viewBox="0 0 24 24" aria-hidden="true"
                                                    focusable="false" fill="none" stroke="currentColor"
                                                    stroke-width="2">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="M20 6L9 17l-5-5" />
                                                </svg><span data-target="c-formEditor__summaryRegex">なし</span></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="area is-delete">
                                <label class="c-formEditorSummary01__visibility" title="表示中">
                                    <input type="checkbox" data-name="visible" value="1" checked>
                                    <span aria-hidden="true">
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2">
                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" />
                                            <circle cx="12" cy="12" r="3" />
                                            <path class="is-hiddenLine" stroke-linecap="round" stroke-linejoin="round"
                                                d="M4 20L20 4" />
                                        </svg>
                                    </span>
                                </label>
                                <details class="menu" data-target="c-formEditor__actionMenu">
                                    <summary class="toggle" aria-label="項目操作"><span aria-hidden="true">⋯</span></summary>
                                    <div class="items" role="menu" aria-label="項目操作">
                                        <button type="button" data-target="c-formEditor__duplicate" role="menuitem">複製</button>
                                        <button type="button" data-target="c-formEditor__remove" role="menuitem">削除</button>
                                    </div>
                                </details>
                            </div>
                <?php admin_c_form_editor_item_header01_close(); ?>
            </div>
            <div class="block is-body">
                <?php admin_c_form_editor_item_body01_open(); ?>
                        <div class="block is-contents">
                            <div class="block is-title">
                                <p data-module="m-borderTitle01">基本設定</p>
                            </div>
                            <div class="block is-field">
                                <div class="c-formEditor__field">
                                    <div class="wrapper">
                                        <div class="block is-contents">
                                            <div class="area is-title c-formEditor__labelTitle"><label class="label"
                                                    data-module="m-labelTitle01">ラベル</label><label class="label is-choice">
                                                    <input type="hidden" data-name="show_label" value="0">
                                                    <input type="checkbox" data-name="show_label" value="1" checked>
                                                    表示する
                                                </label></div>
                                            <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                  'type' => 'text',
                                                  'data-name' => 'label',
                                                  'data-target' => 'c-formEditor__labelInput',
                                              ]); ?><?php admin_m_input01_close(); ?></div>
                                        </div>
                                        <div class="block is-contents">
                                            <div class="area is-title">
                                                <div class="c-formEditor__fieldKeyColumn"><label class="label"
                                                        data-module="m-labelTitle01">フィールドキー</label></div>
                                            </div>
                                            <div class="area is-field">
                                                <div class="c-formEditor__fieldKey"><?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                      'type' => 'text',
                                                      'data-name' => 'field_key',
                                                      'data-target' => 'c-formEditor__fieldKeyInput',
                                                      'class' => 'is-locked',
                                                      'readonly' => true,
                                                      'spellcheck' => 'false',
                                                  ]); ?><?php admin_m_input01_close(); ?><button
                                                        type="button" class="btn is-icon"
                                                        data-target="c-formEditor__fieldKeyLock" aria-label="キーを編集"
                                                        title="編集する" aria-pressed="true"><svg
                                                            data-target="c-formEditor__fieldKeyLockedIcon" width="18"
                                                            height="18" viewBox="0 0 24 24" fill="none"
                                                            stroke="currentColor" stroke-width="2" aria-hidden="true">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                                                        </svg><svg data-target="c-formEditor__fieldKeyOpenIcon"
                                                            width="18" height="18" viewBox="0 0 24 24" fill="none"
                                                            stroke="currentColor" stroke-width="2" style="display:none"
                                                            aria-hidden="true">
                                                            <path stroke-linecap="round" stroke-linejoin="round"
                                                                d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z" />
                                                        </svg></button></div>
                                            </div>
                                        </div>
                                        <input type="hidden" data-name="type" data-target="c-formEditor__type"
                                            value="text_multi"
                                            data-type-label="<?= e(\Models\FormField::typeLabel('text_multi')) ?>">
                                        <input type="hidden" data-name="input_page_key" value="<?= e(\Models\FormInputPage::DEFAULT_KEY) ?>" data-target="c-formEditor__inputPageKey">
                                        <input type="hidden" data-name="parent_group_key" value="" data-target="c-formEditor__parentGroupKey">
                                        <input type="hidden" data-name="sort_order" value="1" data-target="c-formEditor__sortOrder">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="block is-contents" data-target="c-formEditor__inputSettings">
                            <div class="block is-title">
                                <p data-module="m-borderTitle01">入力設定</p>
                            </div>
                            <div class="block is-field">
                                <div class="c-formEditor__field">
                                    <div class="wrapper">
                                        <div class="block is-contents c-formEditor__validation">
                                            <div class="area is-title">
                                                <label class="label" data-module="m-labelTitle01">入力チェック</label>
                                                <div data-module="m-requiredCheck01">
                                                    <label class="label is-choice">
                                                        <input type="checkbox" data-name="required" value="1"
                                                            data-target="c-formEditor__required" aria-label="必須にする">
                                                        <span>必須にする</span>
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="area is-field">
                                                <div class="c-formEditor__validationControls">
                                                    <div data-target="c-formEditor__regex">
                                                        <div class="c-formEditor__regexList">
                                                            <div class="c-formEditor__regexRow">
                                                                <?php admin_m_input01_open(); ?>
                                                                <?php admin_m_input01_select_open([
                                                                    'data-target' => 'c-formEditor__regexKind',
                                                                    'aria-label' => '入力チェックの種類',
                                                                ]);
                                                                foreach ($regexPresetChoices as $patVal => $patLabel) {
                                                                    admin_m_input01_option((string) $patVal, (string) $patLabel, false);
                                                                }
                                                                admin_m_input01_option((string) $FB_REGEX_CHECKBOX_LIMIT, '選択数を設定する', false);
                                                                admin_m_input01_select_close();
                                                                ?>
                                                                <?php admin_m_input01_close(); ?>
                                                                <div class="c-formEditor__regexCustom"
                                                                    style="display:none">
                                                                    <?php admin_m_input01_open(); ?>
                                                                    <?php admin_m_input01_input([
                                                                        'type' => 'text',
                                                                        'data-target' => 'c-formEditor__regexCustomInput',
                                                                        'placeholder' => '正規表現',
                                                                        'spellcheck' => 'false',
                                                                        'autocomplete' => 'off',
                                                                    ]); ?>
                                                                    <?php admin_m_input01_close(); ?>
                                                                </div>
                                                                <input type="hidden"
                                                                    data-target="c-formEditor__regexValue" value="">
                                                            </div>
                                                        </div>
                                                        <input type="hidden" data-name="checkbox_limit_enabled"
                                                            data-target="c-formEditor__checkboxLimitEnabled" value="0">
                                                        <div class="c-formEditor__checkboxLimit" style="display:none">
                                                            <div class="wrapper">
                                                                <div class="block is-contents">
                                                                    <div class="area is-title"><label class="label"
                                                                            data-module="m-labelTitle01">最小選択数</label>
                                                                    </div>
                                                                    <div class="area is-field">
                                                                        <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                                              'type' => 'number',
                                                                              'min' => 1,
                                                                              'data-name' => 'checkbox_min_selections',
                                                                          ]); ?><?php admin_m_input01_close(); ?>
                                                                    </div>
                                                                </div>
                                                                <div class="block is-contents">
                                                                    <div class="area is-title"><label class="label"
                                                                            data-module="m-labelTitle01">最大選択数</label>
                                                                    </div>
                                                                    <div class="area is-field">
                                                                        <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                                              'type' => 'number',
                                                                              'min' => 1,
                                                                              'data-name' => 'checkbox_max_selections',
                                                                          ]); ?><?php admin_m_input01_close(); ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                             <div class="block is-contents" data-target="c-formEditor__minMaxLength">
                                            <div class="area is-title"><label class="label"
                                                    data-module="m-labelTitle01">文字数制限</label></div>
                                            <div class="area is-field">
                                                <div class="c-formEditor__child__field">
                                                    <div class="wrapper">
                                                        <div class="block is-contents">
                                                            <div class="area is-field"><?php admin_m_input01_open('is-w60'); ?><select data-name="length_limit_mode" data-target="c-formEditor__lengthLimitMode"><option value="">制限なし</option><option value="range">範囲</option><option value="exact">固定</option></select><?php admin_m_input01_close(); ?></div>
                                                        </div>
                                                        <div class="c-formEditor__lengthRange01" data-target="c-formEditor__lengthRange" style="display:none">
                                                            <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                                  'type' => 'number',
                                                                  'min' => 1,
                                                                  'data-name' => 'min_length',
                                                              ]); ?><?php admin_m_input01_close(); ?>
                                                            <span class="separator" aria-hidden="true">〜</span>
                                                            <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                                  'type' => 'number',
                                                                  'min' => 1,
                                                                  'data-name' => 'max_length',
                                                              ]); ?><?php admin_m_input01_close(); ?>
                                                        </div>
                                                        <div class="c-formEditor__lengthExact01" data-target="c-formEditor__lengthExact" style="display:none">
                                                            <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                                  'type' => 'number',
                                                                  'min' => 1,
                                                                  'data-name' => 'exact_length',
                                                              ]); ?><?php admin_m_input01_close(); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="block is-field" data-target="c-formEditor__options" style="display:none">
                                <div class="c-formEditor__field">
                                    <div class="wrapper">
                                        <div class="block is-contents">
                                            <div class="area is-title">
                                                <label class="label" data-module="m-labelTitle01">選択肢（1行に1つ）</label>
                                            </div>
                                            <div class="area is-field">
                                                <div class="c-formEditor__choiceEditor" data-choice-editor>
                                                    <div class="c-formEditor__choiceList">
                                                        <div class="wrapper">
                                                            <div class="block is-contents"
                                                                data-target="c-formEditor__choiceListContents">
                                                                <div class="area is-contents">
                                                                    <div class="c-formEditor__choiceItem"
                                                                        data-choice-item>
                                                                        <div class="wrapper">
                                                                            <div class="block is-contents">
                                                                                <div class="area is-move">
                                                                                    <div class="box is-handle ui-sortable-handle"
                                                                                        title="ドラッグして並べ替え">
                                                                                        <?php admin_m_drag_handle01('c-formEditor__choiceDragHandle'); ?>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="c-formEditor__child__field">
                                                                                    <div class="wrapper">
                                                                                        <div class="block is-contents">
                                                                                            <div class="area is-field">
                                                                                                <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                                                                      'type' => 'text',
                                                                                                      'data-target' => 'c-formEditor__choiceInput',
                                                                                                      'placeholder' => '選択肢',
                                                                                                  ]); ?><?php admin_m_input01_close(); ?>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <?php admin_m_delete_btn01('c-formEditor__choiceRemove'); ?>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="area is-contents"
                                                                    data-target="c-formEditor__choiceControls">
                                                                    <?php admin_m_btn01_open('center'); ?>
                                                                    <?php admin_m_btn01_button('＋ 選択肢を追加', [
                                                                        'type' => 'button',
                                                                        'class' => 'is-add',
                                                                        'data-target' => 'c-formEditor__choiceAdd',
                                                                    ]); ?>
                                                                    <textarea data-name="options"
                                                                        data-target="c-formEditor__optionsSource"
                                                                        rows="4" hidden></textarea>
                                                                    <?php admin_m_btn01_close(); ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="block is-field" data-target="c-formEditor__radioDefaultSettings" style="display:none">
                                <div class="c-formEditor__field">
                                    <div class="wrapper">
                                        <div class="block is-contents">
                                            <div class="area is-title">
                                                <label class="label" data-module="m-labelTitle01">初期選択</label>
                                            </div>
                                            <div class="area is-field">
                                                <?php admin_m_input01_open(); ?><select data-name="radio_default_value" data-target="c-formEditor__radioDefaultValue" data-value=""><option value="">設定しない</option></select><?php admin_m_input01_close(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="block is-contents" data-target="c-formEditor__displaySettings">
                        <div class="block is-title">
                            <p data-module="m-borderTitle01">表示設定</p>
                        </div>
                        <div class="block is-field" data-target="c-formEditor__placeholder">
                            <div class="c-formEditor__field">
                                <div class="wrapper">
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label"
                                                data-module="m-labelTitle01">プレースホルダ（任意）</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                              'type' => 'text',
                                              'data-name' => 'placeholder',
                                          ]); ?><?php admin_m_input01_close(); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="block is-field" data-target="c-formEditor__fileSettings" style="display:none">
                            <div class="c-formEditor__field">
                                <div class="wrapper">
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">添付形式</label></div>
                                        <div class="area is-field">
                                            <?php admin_m_radiobtn01('画像', [
                                                'data-name' => 'file_type_mode',
                                                'data-target' => 'c-formEditor__fileTypeMode',
                                                'value' => \Models\FormField::FILE_SELECTION_IMAGE,
                                            ]); ?>
                                            <?php admin_m_radiobtn01('形式を指定する', [
                                                'data-name' => 'file_type_mode',
                                                'data-target' => 'c-formEditor__fileTypeMode',
                                                'value' => \Models\FormField::FILE_SELECTION_CUSTOM,
                                                'checked' => true,
                                            ]); ?>
                                        </div>
                                    </div>
                                    <div class="block is-contents" data-target="c-formEditor__fileAllowedExtensionsWrap">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">許可拡張子（任意）</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                              'type' => 'text',
                                              'data-name' => 'file_allowed_extensions',
                                              'data-target' => 'c-formEditor__fileAllowedExtensions',
                                              'placeholder' => 'jpg, png, pdf',
                                          ]); ?><?php admin_m_input01_close(); ?><p class="text is-help">画像を選ぶと、jpg / jpeg / png / gif / webp / heic / heif を対象にし、JPEG形式へ変換して保存します。</p></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="block is-field" data-target="c-formEditor__matrixSettings" style="display:none">
                            <div class="c-formEditor__field">
                                <div class="wrapper">
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">行ラベル</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_textarea([
                                              'rows' => 4,
                                              'data-name' => 'matrix_rows',
                                              'data-target' => 'c-formEditor__matrixRows',
                                          ], ''); ?><?php admin_m_input01_close(); ?></div>
                                    </div>
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">列ラベル</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_textarea([
                                              'rows' => 4,
                                              'data-name' => 'matrix_columns',
                                              'data-target' => 'c-formEditor__matrixColumns',
                                          ], ''); ?><?php admin_m_input01_close(); ?></div>
                                    </div>
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">選択方式</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><select data-name="matrix_selection_type" data-target="c-formEditor__matrixSelectionType"><option value="radio">行ごとに1つ選択</option></select><?php admin_m_input01_close(); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="block is-field" data-target="c-formEditor__textMultiSettings"
                            style="display:none">
                            <div class="c-formEditor__field">
                                <div class="c-formEditor__textMultiList" data-text-multi-editor>
                                    <div class="wrapper">
                                        <div class="block is-contents"
                                            data-target="c-formEditor__textMultiListContents">
                                            <div class="area is-contents">
                                                <div class="c-formEditor__textMultiItem" data-text-multi-item>
                                                    <div class="wrapper">
                                                        <div class="block is-contents">
                                                            <div class="c-formEditor__child__field">
                                                                <div class="wrapper">
                                                                    <div class="block is-contents">
                                                                        <div class="area is-title"><label
                                                                                data-module="m-labelSmallTitle01">表示名</label>
                                                                        </div>
                                                                        <div class="area is-field">
                                                                            <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                                                  'type' => 'text',
                                                                                  'data-target' => 'c-formEditor__textMultiLabelInput',
                                                                              ]); ?><?php admin_m_input01_close(); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="block is-contents">
                                                                        <div class="area is-title"><label
                                                                                data-module="m-labelSmallTitle01">入力例</label>
                                                                        </div>
                                                                        <div class="area is-field">
                                                                            <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                                                  'type' => 'text',
                                                                                  'data-target' => 'c-formEditor__textMultiPlaceholderInput',
                                                                               ]); ?><?php admin_m_input01_close(); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="block is-contents">
                                                                        <div class="area is-title"><label
                                                                                data-module="m-labelSmallTitle01">初期値</label>
                                                                        </div>
                                                                        <div class="area is-field">
                                                                            <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                                                  'type' => 'text',
                                                                                  'data-target' => 'c-formEditor__textMultiDefaultValueInput',
                                                                              ]); ?><?php admin_m_input01_close(); ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <?php admin_m_delete_btn01('c-formEditor__textMultiRemove'); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="area is-contents" data-target="c-formEditor__textMultiControls">
                                                <?php admin_m_btn01_open('center'); ?>
                                                <?php admin_m_btn01_button('＋ 入力エリアを追加', [
                                                    'type' => 'button',
                                                    'class' => 'is-add fb-description-add',
                                                    'data-target' => 'c-formEditor__textMultiAdd',
                                             ]); ?>
                                                <textarea data-name="multi_text_items"
                                                    data-target="c-formEditor__textMultiSource"
                                                    hidden>[{"label":"","placeholder":"","default_value":""}]</textarea>
                                                  <?php admin_m_btn01_close(); ?>
                                              </div>
                                          </div>
                                      </div>
                                  </div>
                            </div>
                        </div>
                        <div class="block is-field" data-target="c-formEditor__postalCodeSettings" style="display:none">
                            <div class="c-formEditor__field">
                                <div class="wrapper">
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">郵便番号補完先（都道府県UUID）</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                              'type' => 'text',
                                              'data-name' => 'postal_target_prefecture',
                                              'data-target' => 'c-formEditor__postalCodePrefectureTarget',
                                          ]); ?><?php admin_m_input01_close(); ?></div>
                                    </div>
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">郵便番号補完先（市区町村UUID）</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                              'type' => 'text',
                                              'data-name' => 'postal_target_city',
                                              'data-target' => 'c-formEditor__postalCodeCityTarget',
                                          ]); ?><?php admin_m_input01_close(); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="block is-field" data-target="c-formEditor__defaultValueSettings" style="display:none">
                            <div class="c-formEditor__field">
                                <div class="wrapper">
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">初期値</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                              'type' => 'text',
                                              'data-name' => 'default_value',
                                              'data-target' => 'c-formEditor__defaultValueInput',
                                          ]); ?><?php admin_m_input01_close(); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="block is-field" data-target="c-formEditor__dateDefaultSettings" style="display:none">
                            <div class="c-formEditor__field">
                                <div class="wrapper">
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">初期値</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><select data-name="date_default_mode" data-target="c-formEditor__dateDefaultMode"><option value="">設定しない</option><option value="today">今日</option><option value="fixed">固定値</option></select><?php admin_m_input01_close(); ?></div>
                                    </div>
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">固定日付</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                              'type' => 'date',
                                              'data-name' => 'date_default_value',
                                              'data-target' => 'c-formEditor__dateDefaultValue',
                                          ]); ?><?php admin_m_input01_close(); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="block is-field" data-target="c-formEditor__timeDefaultSettings" style="display:none">
                            <div class="c-formEditor__field">
                                <div class="wrapper">
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">初期値</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><select data-name="time_default_mode" data-target="c-formEditor__timeDefaultMode"><option value="">設定しない</option><option value="now">現在時刻</option><option value="fixed">固定値</option></select><?php admin_m_input01_close(); ?></div>
                                    </div>
                                    <div class="block is-contents">
                                        <div class="area is-title"><label class="label" data-module="m-labelTitle01">固定時刻</label></div>
                                        <div class="area is-field"><?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                              'type' => 'time',
                                              'data-name' => 'time_default_value',
                                              'data-target' => 'c-formEditor__timeDefaultValue',
                                          ]); ?><?php admin_m_input01_close(); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <div class="block is-field" data-target="c-formEditor__helpTextBlock">
                        <div class="c-formEditor__field">
                            <div class="wrapper">
                                <div class="block is-contents">
                                    <div class="area is-title" data-target="c-formEditor__helpTextTitle">
                                        <label class="label" data-module="m-labelTitle01" data-target="c-formEditor__helpTextLabel">説明文</label>
                                    </div>
                                    <div class="area is-field">
                                        <div data-target="c-formEditor__headingTextWrap" style="display:none">
                                            <?php admin_m_input01_open(); ?><?php admin_m_input01_input([
                                                  'type' => 'text',
                                                  'data-name' => 'help_text',
                                                  'data-target' => 'c-formEditor__headingTextInput',
                                                  'disabled' => true,
                                              ]); ?><?php admin_m_input01_close(); ?>
                                        </div>
                                        <?php admin_c_html_input_editor01_open([
                                            'data-html-toggle-editor' => true,
                                            'data-target' => 'c-formEditor__helpTextEditor',
                                        ]); ?>
                                                <div class="block is-editor">
                                                    <?php admin_m_input01_open(); ?><?php admin_m_input01_textarea([
                                                          'data-name' => 'help_text',
                                                          'rows' => 3,
                                                          'data-target' => 'c-htmlInputEditor01__textarea',
                                                      ], ''); ?><?php admin_m_input01_close(); ?>
                                                </div>
                                                <div class="block is-toolbar" data-target="c-formEditor__helpTextToolbar">
                                                    <?php admin_c_html_input_editor01_toggle([
                                                        'data-name' => 'help_text_is_html',
                                                    ]); ?>
                                                </div>
                                        <?php admin_c_html_input_editor01_close(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </div>
                    <input type="hidden" data-name="_remove" value="0" data-target="c-formEditor__removeFlag">
                <?php admin_c_form_editor_item_body01_close(); ?>
            </div>
        </div>
    <?php admin_c_form_editor_item01_close(); ?>
    </div>
    </div>
</template>
