<?php
/**
 * 管理画面の左固定ヘッダー c-adminHeader01。
 * スタイルは同ディレクトリの _c-adminHeader01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_admin_header01')) {
    function admin_c_admin_header01(): void
    {
        $nav = admin_relative_path();
        $navForms = str_starts_with($nav, '/forms') || str_starts_with($nav, '/files');
        $navUsers = str_starts_with($nav, '/users');
        $navSettings = str_starts_with($nav, '/settings');
        $user = \Core\Auth::user();
        ?>
        <header data-module="c-adminHeader01">
            <div class="wrapper">
                <div class="block is-contents">
                    <div class="area is-logo">
                        <a href="<?= e(base_path('/admin/')) ?>">
                            <img class="img" src="<?= e(base_path('/assets/images/common/logo01.png')) ?>" alt="<?= e(config('site.admin_name')) ?>">
                        </a>
                    </div>
                    <nav class="area is-nav">
                        <a href="<?= e(base_path('/admin/forms')) ?>" class="<?= $navForms ? 'is-active' : '' ?>"<?= $navForms ? ' aria-current="page"' : '' ?>>フォーム</a>
                        <?php if (\Core\Auth::role() === 'admin'): ?>
                            <a href="<?= e(base_path('/admin/users')) ?>" class="<?= $navUsers ? 'is-active' : '' ?>"<?= $navUsers ? ' aria-current="page"' : '' ?>>ユーザー</a>
                        <?php endif; ?>
                        <a href="<?= e(base_path('/admin/settings')) ?>" class="<?= $navSettings ? 'is-active' : '' ?>"<?= $navSettings ? ' aria-current="page"' : '' ?>>設定</a>
                    </nav>
                    <div class="area is-user">
                        <?php if ($user): ?>
                            <span class="name"><?= e($user['display_name'] ?? $user['username']) ?>（<?= e($user['role']) ?>）</span>
                            <form method="post" action="<?= e(base_path('/admin/logout')) ?>">
                                <?= \Core\Csrf::field() ?>
                                <?php admin_m_btn01_button_wrap('ログアウト', ['type' => 'submit', 'class' => 'is-danger is-sm']); ?>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </header>
        <?php
    }
}
