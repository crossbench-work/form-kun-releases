<?php
namespace Core;

use Models\Form;
use Models\MailDeliveryAudit;
use Models\Submission;

class SubmissionDeliveryService
{
    public static function attachmentTotalBytes(array $attachments): int
    {
        $total = 0;
        foreach ($attachments as $attachment) {
            if (is_array($attachment)) { $total += max(0, (int) ($attachment['size'] ?? 0)); }
        }
        return $total;
    }

    public static function attachmentsWithinLimit(array $form, array $attachments): bool
    {
        return self::attachmentTotalBytes($attachments) <= Form::normalizeAttachmentMaxBytes($form['mail_attachment_max_bytes'] ?? null);
    }

    /** @return array{success:bool,submission_id:?int,error_code:?string,reply_success:bool} */
    public static function deliver(array $form, array $fields, array $values, array $attachments, string $route, string $deliveryId): array
    {
        if (!Form::isMailOnly($form)) {
            $submissionId = Submission::create((int) $form['id'], $values, $attachments, client_ip(), (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''));
            SubmissionNotifier::send($form, $fields, $values);
            return ['success' => true, 'submission_id' => $submissionId, 'error_code' => null, 'reply_success' => true];
        }

        if ((string) ($form['mail_transport'] ?? '') !== 'smtp'
            || trim((string) ($form['admin_emails'] ?? '')) === ''
            || !Form::smtpTestIsCurrent($form)) {
            MailDeliveryAudit::record((int) $form['id'], $route, 'failed', 'mail_configuration_invalid', $attachments);
            return ['success' => false, 'submission_id' => null, 'error_code' => 'mail_delivery_failed', 'reply_success' => true];
        }
        foreach ($attachments as $attachment) {
            if (!is_array($attachment) || !TemporaryAttachmentStorage::isReadableAttachment($attachment)) {
                MailDeliveryAudit::record((int) $form['id'], $route, 'failed', 'attachment_unavailable', $attachments);
                return ['success' => false, 'submission_id' => null, 'error_code' => 'mail_delivery_failed', 'reply_success' => true];
            }
        }

        $result = SubmissionNotifier::sendMailOnly($form, $fields, $values, $attachments, $deliveryId);
        if (!$result['admin_success']) {
            MailDeliveryAudit::record((int) $form['id'], $route, 'failed', 'mail_delivery_failed', $attachments);
            return ['success' => false, 'submission_id' => null, 'error_code' => 'mail_delivery_failed', 'reply_success' => true];
        }
        $errorCode = $result['reply_success'] ? null : 'reply_delivery_failed';
        MailDeliveryAudit::record((int) $form['id'], $route, 'success', $errorCode, $attachments);
        $submissionId = null;
        try {
            $submissionId = Submission::createMailOnlyMetadata(
                (int) $form['id'],
                client_ip(),
                (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''),
                $route,
                $errorCode,
                count($attachments),
                self::attachmentTotalBytes($attachments)
            );
        } catch (\Throwable $e) {
            // SMTP受理後のため受付成功は取り消さない。入力由来情報はログへ出さない。
            error_log('[formkun] mail-only submission metadata write failed');
        }
        return ['success' => true, 'submission_id' => $submissionId, 'error_code' => $errorCode, 'reply_success' => $result['reply_success']];
    }
}
