<?php
namespace Core;

/**
 * アップロード拡張子と実ファイルMIMEの整合性、および安全なinline表示を判定する。
 */
class FileTypePolicy
{
    /** @var array<string, array<int, string>> */
    private const MIME_BY_EXTENSION = [
        'jpg' => ['image/jpeg'],
        'jpeg' => ['image/jpeg'],
        'png' => ['image/png'],
        'gif' => ['image/gif'],
        'webp' => ['image/webp'],
        'heic' => ['image/heic', 'image/heif', 'application/octet-stream', 'application/x-empty'],
        'heif' => ['image/heic', 'image/heif', 'application/octet-stream', 'application/x-empty'],
        'pdf' => ['application/pdf'],
        'txt' => ['text/plain', 'application/x-empty'],
        'csv' => ['text/csv', 'text/plain', 'application/csv', 'application/vnd.ms-excel', 'application/x-empty'],
        'doc' => ['application/msword', 'application/x-ole-storage', 'application/CDFV2', 'application/vnd.ms-office'],
        'xls' => ['application/vnd.ms-excel', 'application/x-ole-storage', 'application/CDFV2', 'application/vnd.ms-office'],
        'ppt' => ['application/vnd.ms-powerpoint', 'application/x-ole-storage', 'application/CDFV2', 'application/vnd.ms-office'],
        'docx' => ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/zip'],
        'xlsx' => ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/zip'],
        'pptx' => ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 'application/zip'],
        'zip' => ['application/zip', 'application/x-zip-compressed'],
    ];

    /** @var array<string, string> */
    private const INLINE_IMAGE_MIME_BY_EXTENSION = [
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        'gif' => 'image/gif',
        'webp' => 'image/webp',
    ];

    public static function detectMime(string $path): string
    {
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo !== false) {
                $mime = finfo_file($finfo, $path);
                finfo_close($finfo);
                if (is_string($mime) && $mime !== '') {
                    return self::normalizeMime($mime);
                }
            }
        }
        return 'application/octet-stream';
    }

    public static function isKnownExtension(string $extension): bool
    {
        return isset(self::MIME_BY_EXTENSION[self::normalizeExtension($extension)]);
    }

    public static function isMimeAllowedForExtension(string $extension, string $mime): bool
    {
        $extension = self::normalizeExtension($extension);
        if (!isset(self::MIME_BY_EXTENSION[$extension])) {
            return true;
        }
        $mime = self::normalizeMime($mime);
        return in_array($mime, array_map([self::class, 'normalizeMime'], self::MIME_BY_EXTENSION[$extension]), true);
    }

    public static function isSafeInlineImage(string $extension, string $mime): bool
    {
        $extension = self::normalizeExtension($extension);
        return isset(self::INLINE_IMAGE_MIME_BY_EXTENSION[$extension])
            && self::INLINE_IMAGE_MIME_BY_EXTENSION[$extension] === self::normalizeMime($mime);
    }

    /** inline 表示用の期待 MIME（jpg/png 等）。該当しない拡張子は null。 */
    public static function expectedInlineImageMime(string $extension): ?string
    {
        $extension = self::normalizeExtension($extension);
        return self::INLINE_IMAGE_MIME_BY_EXTENSION[$extension] ?? null;
    }

    public static function storageExtension(string $originalExtension): string
    {
        $extension = self::normalizeExtension($originalExtension);
        return self::isKnownExtension($extension) ? $extension : 'bin';
    }

    private static function normalizeExtension(string $extension): string
    {
        return strtolower(ltrim(trim($extension), '.'));
    }

    private static function normalizeMime(string $mime): string
    {
        return strtolower(trim($mime));
    }
}
