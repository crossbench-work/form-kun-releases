<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';

$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'href' => base_path('/admin/forms/' . (int) $form['id'] . '/edit')],
    ['label' => 'バージョン管理', 'current' => true],
]); ?>

<div data-module="m-toolbar01">
    <h1 class="title" style="margin:0;">バージョン管理</h1>
    <span class="spacer"></span>
    <?php admin_m_btn01_link_wrap('編集へ戻る', base_path('/admin/forms/' . (int) $form['id'] . '/edit')); ?>
</div>

<?php admin_c_form_block01_open(); ?>
<div class="area is-field">
    <?php if (empty($versions)): ?>
        <p data-module="m-text01" data-type="muted">まだ保存履歴がありません。</p>
    <?php else: ?>
        <?php admin_m_table01_open(); ?>
            <thead>
                <tr>
                    <th></th>
                    <th>版</th>
                    <th>操作</th>
                    <th>保存者</th>
                    <th>保存日時</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($versions as $version): ?>
                    <tr>
                        <td>
                            <form method="post" action="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/versions/' . (int) $version['id'] . '/pin')) ?>">
                                <?= \Core\Csrf::field() ?>
                                <button type="submit" class="btn is-sm" aria-label="<?= !empty($version['pinned']) ? 'ピン留めを解除' : 'ピン留めする' ?>" title="<?= !empty($version['pinned']) ? 'ピン留めを解除' : 'ピン留めする' ?>">
                                    <?= !empty($version['pinned']) ? '★' : '☆' ?>
                                </button>
                            </form>
                        </td>
                        <td><strong>#<?= e((string) ($version['version_number'] ?? '')) ?></strong></td>
                        <td><?= e(\Models\FormVersion::actionLabel((string) ($version['action_type'] ?? ''))) ?></td>
                        <td><?= e((string) (($version['created_by_name'] ?? '') !== '' ? $version['created_by_name'] : 'システム')) ?></td>
                        <td><?= e((string) ($version['created_at'] ?? '')) ?></td>
                        <td class="is-actions">
                            <details class="c-tableActionMenu01">
                                <summary class="c-tableActionMenu01__toggle" aria-label="操作">
                                    <span aria-hidden="true">⋯</span>
                                </summary>
                                <div class="c-tableActionMenu01__menu" role="menu" aria-label="操作">
                                    <form method="post"
                                          action="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/versions/' . (int) $version['id'] . '/restore')) ?>"
                                          onsubmit="return confirm('バージョン #<?= e((string) ($version['version_number'] ?? '')) ?> を現在のフォームへ復元します。よろしいですか？');">
                                        <?= \Core\Csrf::field() ?>
                                        <button type="submit" role="menuitem">復元</button>
                                    </form>
                                    <form method="post"
                                          action="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/versions/' . (int) $version['id'] . '/delete')) ?>"
                                          onsubmit="return confirm('バージョン #<?= e((string) ($version['version_number'] ?? '')) ?> を削除します。よろしいですか？');">
                                        <?= \Core\Csrf::field() ?>
                                        <button type="submit" role="menuitem">削除</button>
                                    </form>
                                </div>
                            </details>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        <?php admin_m_table01_close(); ?>
    <?php endif; ?>
</div>
<?php admin_c_form_block01_close(); ?>
