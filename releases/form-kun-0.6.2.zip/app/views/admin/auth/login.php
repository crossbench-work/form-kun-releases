<form method="post" action="<?= e(base_path('/admin/login')) ?>" class="block is-contents">
    <?= \Core\Csrf::field() ?>
    <div class="area is-title">
        <h2 class="title">ログイン</h2>
    </div>
    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('ユーザー名'), 'username'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('username', [
                    'type' => 'text',
                    'id' => 'username',
                    'name' => 'username',
                    'autocomplete' => 'username',
                    'required' => true,
                ])); ?>
                <?php admin_m_input01_close(); ?>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('パスワード'), 'password'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('password', [
                    'type' => 'password',
                    'id' => 'password',
                    'name' => 'password',
                    'autocomplete' => 'current-password',
                    'required' => true,
                ])); ?>
                <?php admin_m_input01_close(); ?>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>
    <div class="area is-actions">
        <?php admin_m_btn01_button_wrap('ログイン', ['type' => 'submit', 'class' => 'is-primary']); ?>
        <p class="text is-help">
            <a href="<?= e(base_path('/admin/forgot-password')) ?>">パスワードをお忘れの場合</a>
        </p>
    </div>
</form>
