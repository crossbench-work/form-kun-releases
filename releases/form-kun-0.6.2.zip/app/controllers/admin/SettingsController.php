<?php
namespace Controllers\Admin;

use Core\AppUpdater;
use Core\Auth;
use Core\Csrf;
use Core\FieldKey;
use Core\FormSettingsTransfer;
use Core\JapaneseHolidays;
use Core\SiteResource;
use Core\SubmissionPurgeSchedule;
use Core\View;
use Models\AppSetting;
use Models\Form;
use Models\FormField;
use Models\FormFieldGroup;
use Models\FormFieldTemplate;

class SettingsController
{
    public function index(): void
    {
        Auth::requireLogin();

        $resource = SiteResource::snapshot();

        $data = [
            'title'               => '設定',
            'form_count'          => Form::count(),
            'max_forms'           => effective_max_forms(),
            'storage_used_uploads' => $resource['used_uploads'],
            'storage_used_db'     => $resource['used_db'],
            'storage_used_total'  => $resource['used_total'],
            'storage_max'         => $resource['max'],
            'storage_percent'     => $resource['percent'],
            'storage_warning'     => $resource['warning'],
            'storage_exceeded'    => $resource['exceeded'],
            'storage_max_mb'      => (int) max(1, (int) round($resource['max'] / 1024 / 1024)),
            'storage_resource'     => $resource,
            'field_templates'       => FormFieldTemplate::all(),
            'form_version_interval_minutes' => \Models\FormVersion::intervalMinutes(),
            'form_version_save_on_save' => \Models\FormVersion::saveOnSaveEnabled(),
            'form_version_save_on_login' => \Models\FormVersion::saveOnLoginEnabled(),
            'form_version_save_on_logout' => \Models\FormVersion::saveOnLogoutEnabled(),
            'form_version_retention_limit' => \Models\FormVersion::retentionLimit(),
            'show_active_forms_list' => settings_show_active_forms_list(),
            'active_forms_list_redirect_url' => settings_active_forms_list_redirect_url(),
            'holidays_status' => JapaneseHolidays::status(),
            'holidays_status_message' => JapaneseHolidays::statusMessage(),
            'holidays_fetched_at' => JapaneseHolidays::fetchedAt(),
            'holidays_count' => count(JapaneseHolidays::load()),
            'holidays_fetch_interval_days' => effective_holidays_jp_fetch_interval_days(),
        ];

        $purgeSchedule = SubmissionPurgeSchedule::settings();
        $data['submission_purge_schedule_enabled'] = $purgeSchedule['enabled'];
        $data['submission_purge_schedule_mode'] = $purgeSchedule['mode'];
        $data['submission_purge_schedule_daily_hour'] = $purgeSchedule['daily_hour'];
        $data['submission_purge_schedule_interval_hours'] = $purgeSchedule['interval_hours'];
        $data['submission_purge_schedule_last_run_at'] = $purgeSchedule['last_run_at'];

        if (Auth::role() === 'admin') {
            $showManifestUi = (bool) config('update.show_manifest_ui', false);
            $manifest = null;
            $manifestError = '';
            if ($showManifestUi && AppUpdater::isEnabled()) {
                $result = AppUpdater::fetchManifest();
                if ($result['ok']) {
                    $manifest = $result['manifest'];
                } else {
                    $manifestError = $result['message'];
                }
            }

            $data['show_manifest_ui'] = $showManifestUi;
            $data['currentVersion'] = AppUpdater::currentVersion();
            $data['requirements'] = AppUpdater::requirements();
            $data['manifest'] = $manifest;
            $data['manifestError'] = $manifestError;
            $data['update_enabled'] = effective_update_enabled();
            $data['update_manifest_url'] = effective_update_manifest_url();
            $data['update_enabled_db_set'] = self::appSettingIsSet(AppSetting::KEY_UPDATE_ENABLED);
            $data['update_manifest_url_db_set'] = self::appSettingIsSet(AppSetting::KEY_UPDATE_MANIFEST_URL);
            $data['releases_page_url'] = update_releases_page_url();
            $data['manual_upload_max_bytes'] = AppUpdater::manualUploadMaxBytes();
        }

        (new View())->render('admin/settings/index', $data, 'admin');
    }

    public function exportForms(): void
    {
        Auth::requireLogin();
        Csrf::verify();

        $json = json_encode(FormSettingsTransfer::exportAll(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        if (!is_string($json)) {
            flash('danger', 'フォーム設定を書き出せませんでした。');
            redirect('/admin/settings#settings-transfer');
        }

        while (ob_get_level() > 0) { ob_end_clean(); }
        $filename = 'form-kun-settings-' . date('Ymd-His') . '.json';
        header('Content-Type: application/json; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($json));
        header('X-Content-Type-Options: nosniff');
        echo $json;
    }

    public function importForms(): void
    {
        Auth::requireLogin();
        Csrf::verify();

        try {
            $file = $_FILES['form_settings_file'] ?? null;
            if (!is_array($file) || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                throw new \InvalidArgumentException('JSON ファイルを選択してください。');
            }
            $size = (int) ($file['size'] ?? 0);
            if ($size <= 0 || $size > FormSettingsTransfer::MAX_FILE_BYTES) {
                throw new \InvalidArgumentException('JSON ファイルは 5 MB 以下にしてください。');
            }
            $name = (string) ($file['name'] ?? '');
            $tmp = (string) ($file['tmp_name'] ?? '');
            if (!preg_match('/\.json\z/i', $name) || $tmp === '' || !is_uploaded_file($tmp)) {
                throw new \InvalidArgumentException('有効な JSON ファイルを選択してください。');
            }
            $json = file_get_contents($tmp);
            if (!is_string($json)) {
                throw new \InvalidArgumentException('JSON ファイルを読み込めませんでした。');
            }
            $availableSlots = max(0, effective_max_forms() - Form::count());
            $result = FormSettingsTransfer::importJson($json, $availableSlots, Auth::user());
            flash('success', (int) $result['count'] . ' 件のフォームを下書きとしてインポートしました。');
        } catch (\InvalidArgumentException $e) {
            flash('danger', $e->getMessage());
        } catch (\Throwable $e) {
            error_log('[formkun] form settings import failed: ' . $e->getMessage());
            flash('danger', 'フォーム設定をインポートできませんでした。');
        }
        redirect('/admin/settings#settings-transfer');
    }

    public function storeTemplate(): void
    {
        Auth::requireLogin();
        Csrf::verify();

        $payload = $this->collectTemplatePayload();
        FormFieldTemplate::create($payload['title'], $payload['fields'], $payload['field_groups']);
        flash('success', 'テンプレートを保存しました。');
        redirect('/admin/settings#settings-templates');
    }

    public function updateTemplate(int $id): void
    {
        Auth::requireLogin();
        Csrf::verify();

        if (FormFieldTemplate::find($id) === null) {
            flash('danger', 'テンプレートが見つかりません。');
            redirect('/admin/settings#settings-template-editor');
        }

        $payload = $this->collectTemplatePayload();
        FormFieldTemplate::update($id, $payload['title'], $payload['fields'], $payload['field_groups']);
        flash('success', 'テンプレートを保存しました。');
        redirect('/admin/settings#settings-templates');
    }

    public function deleteTemplate(int $id): void
    {
        Auth::requireLogin();
        Csrf::verify();
        FormFieldTemplate::delete($id);
        flash('success', 'テンプレートを削除しました。');
        redirect('/admin/settings#settings-templates');
    }

    public function templateJson(string $id): void
    {
        Auth::requireLogin();
        $template = FormFieldTemplate::findTemplate($id);
        if ($template === null) {
            http_response_code(404);
            header('Content-Type: application/json; charset=UTF-8');
            echo json_encode(['ok' => false, 'message' => 'テンプレートが見つかりません。'], JSON_UNESCAPED_UNICODE);
            return;
        }
        header('Content-Type: application/json; charset=UTF-8');
        echo json_encode([
            'ok' => true,
            'template' => [
                'id' => $template['id'],
                'title' => (string) $template['title'],
                'fields' => $template['fields'],
                'field_groups' => $template['field_groups'],
            ],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public function update(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $raw = trim((string) ($_POST['max_forms'] ?? ''));
        $v = filter_var($raw, FILTER_VALIDATE_INT);
        if ($v === false || $v < 1 || $v > 999999) {
            flash('danger', 'フォームの作成上限は 1 から 999999 までの整数で入力してください。');
            redirect('/admin/settings');
        }

        AppSetting::set(AppSetting::KEY_MAX_FORMS, (string) $v);
        flash('success', 'フォームの作成上限を保存しました。');
        redirect('/admin/settings');
    }

    public function updateSiteResource(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $raw = trim((string) ($_POST['max_site_resource_mb'] ?? ''));
        $v = filter_var($raw, FILTER_VALIDATE_INT);
        if ($v === false || $v < 1 || $v > 1048576) {
            flash('danger', '使用リソースの上限は 1 から 1048576 MB までの整数で入力してください。');
            redirect('/admin/settings');
        }

        AppSetting::set(AppSetting::KEY_MAX_SITE_RESOURCE_BYTES, (string) ($v * 1024 * 1024));
        flash('success', '使用リソースの上限を保存しました。');
        redirect('/admin/settings');
    }

    public function updateDisplay(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $redirectUrl = trim((string) ($_POST['active_forms_list_redirect_url'] ?? ''));
        if ($redirectUrl !== '' && !is_form_button_url($redirectUrl)) {
            flash('danger', 'リダイレクト URL は http:// / https:// で始まる URL、または / から始まるパスを指定してください。');
            redirect('/admin/settings#settings-config');
        }

        AppSetting::set(
            AppSetting::KEY_SHOW_ACTIVE_FORMS_LIST,
            !empty($_POST['show_active_forms_list']) ? '1' : '0'
        );
        AppSetting::set(AppSetting::KEY_ACTIVE_FORMS_LIST_REDIRECT_URL, $redirectUrl);

        flash('success', '表示設定を保存しました。');
        redirect('/admin/settings#settings-config');
    }

    public function updateHolidays(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $raw = trim((string) ($_POST['holidays_jp_fetch_interval_days'] ?? ''));
        $v = filter_var($raw, FILTER_VALIDATE_INT);
        if ($v === false || $v < 1 || $v > 3650) {
            flash('danger', '自動取得間隔は 1 から 3650 までの整数で入力してください。');
            redirect('/admin/settings#settings-config');
        }

        AppSetting::set(AppSetting::KEY_HOLIDAYS_JP_FETCH_INTERVAL_DAYS, (string) $v);
        flash('success', '祝日情報の自動取得間隔を保存しました。');
        redirect('/admin/settings#settings-config');
    }

    public function fetchHolidays(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        try {
            JapaneseHolidays::fetchAndSave();
            $count = count(JapaneseHolidays::load());
            flash('success', '祝日情報を取得しました。（' . $count . ' 件）');
        } catch (\Throwable $e) {
            flash('danger', '祝日情報の取得に失敗しました: ' . $e->getMessage());
        }

        redirect('/admin/settings#settings-config');
    }

    public function updateSubmissionPurgeSchedule(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $enabled = !empty($_POST['submission_purge_schedule_enabled']);

        $mode = SubmissionPurgeSchedule::normalizeMode((string) ($_POST['submission_purge_schedule_mode'] ?? ''));

        $hourRaw = trim((string) ($_POST['submission_purge_schedule_daily_hour'] ?? ''));
        $hour = filter_var($hourRaw, FILTER_VALIDATE_INT);
        if ($hour === false || $hour < SubmissionPurgeSchedule::MIN_DAILY_HOUR || $hour > SubmissionPurgeSchedule::MAX_DAILY_HOUR) {
            flash('danger', '実行時刻は 0 から 23 までの整数で入力してください。');
            redirect('/admin/settings#settings-config');
        }

        $intervalRaw = trim((string) ($_POST['submission_purge_schedule_interval_hours'] ?? ''));
        $interval = filter_var($intervalRaw, FILTER_VALIDATE_INT);
        if ($interval === false || $interval < SubmissionPurgeSchedule::MIN_INTERVAL_HOURS || $interval > SubmissionPurgeSchedule::MAX_INTERVAL_HOURS) {
            flash('danger', '実行間隔は 1 から 168 までの整数（時間）で入力してください。');
            redirect('/admin/settings#settings-config');
        }

        AppSetting::set(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_ENABLED, $enabled ? '1' : '0');
        AppSetting::set(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_MODE, $mode);
        AppSetting::set(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_DAILY_HOUR, (string) $hour);
        AppSetting::set(AppSetting::KEY_SUBMISSION_PURGE_SCHEDULE_INTERVAL_HOURS, (string) $interval);

        flash('success', '受信履歴の定期削除スケジュールを保存しました。');
        redirect('/admin/settings#settings-config');
    }

    public function updateVersioning(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $intervalRaw = trim((string) ($_POST['form_version_interval_minutes'] ?? ''));
        $interval = filter_var($intervalRaw, FILTER_VALIDATE_INT);
        if ($interval === false || $interval < 0 || $interval > 10080) {
            flash('danger', '「◯分おきに保存」は 0 から 10080 までの整数で入力してください。');
            redirect('/admin/settings');
        }

        $retentionRaw = trim((string) ($_POST['form_version_retention_limit'] ?? ''));
        $retention = filter_var($retentionRaw, FILTER_VALIDATE_INT);
        if ($retention === false || $retention < 1 || $retention > 10000) {
            flash('danger', '保存回数は 1 から 10000 までの整数で入力してください。');
            redirect('/admin/settings');
        }

        AppSetting::set(AppSetting::KEY_FORM_VERSION_INTERVAL_MINUTES, (string) $interval);
        AppSetting::set(AppSetting::KEY_FORM_VERSION_SAVE_ON_SAVE, !empty($_POST['form_version_save_on_save']) ? '1' : '0');
        AppSetting::set(AppSetting::KEY_FORM_VERSION_SAVE_ON_LOGIN, !empty($_POST['form_version_save_on_login']) ? '1' : '0');
        AppSetting::set(AppSetting::KEY_FORM_VERSION_SAVE_ON_LOGOUT, !empty($_POST['form_version_save_on_logout']) ? '1' : '0');
        AppSetting::set(AppSetting::KEY_FORM_VERSION_RETENTION_LIMIT, (string) $retention);
        \Models\FormVersion::pruneAllUnpinned();

        flash('success', 'バージョン管理の設定を保存しました。');
        redirect('/admin/settings');
    }

    public function updateUpdateConfig(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $enabled = isset($_POST['update_enabled']) && (string) $_POST['update_enabled'] === '1';
        $manifestUrl = trim((string) ($_POST['update_manifest_url'] ?? ''));

        if ($enabled && $manifestUrl === '') {
            flash('danger', '自己更新を有効にする場合は manifest URL を入力してください。');
            redirect('/admin/settings#app-update');
        }

        if ($manifestUrl !== '' && filter_var($manifestUrl, FILTER_VALIDATE_URL) === false) {
            flash('danger', 'manifest URL の形式が正しくありません。');
            redirect('/admin/settings#app-update');
        }

        if ($manifestUrl !== '' && parse_url($manifestUrl, PHP_URL_SCHEME) !== 'https') {
            flash('danger', 'manifest URL は HTTPS のみ利用できます。');
            redirect('/admin/settings#app-update');
        }

        AppSetting::set(AppSetting::KEY_UPDATE_ENABLED, $enabled ? '1' : '0');
        AppSetting::set(AppSetting::KEY_UPDATE_MANIFEST_URL, $manifestUrl);

        flash('success', 'アプリ更新の設定を保存しました。');
        redirect('/admin/settings#app-update');
    }

    /**
     * @return array{title:string, fields:array<int, array<string, mixed>>, field_groups:array<int, array<string, mixed>>}
     */
    private function collectTemplatePayload(): array
    {
        return [
            'title' => FormFieldTemplate::normalizeTitle((string) ($_POST['title'] ?? '')),
            'fields' => $this->collectTemplateFields(),
            'field_groups' => $this->collectTemplateGroups(),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function collectTemplateFields(): array
    {
        $raw = $_POST['fields'] ?? [];
        $fields = [];
        if (!is_array($raw)) {
            return [];
        }
        foreach ($raw as $f) {
            if (!is_array($f) || !empty($f['_remove'])) {
                continue;
            }
            $type = FormField::sanitizeType((string) ($f['type'] ?? 'text_multi'));
            $isDisplayOnly = FormField::isDisplayOnlyType($type);
            $required = (!$isDisplayOnly && !empty($f['required'])) ? 1 : 0;
            $regex = trim((string) ($f['regex_pattern'] ?? ''));
            if ($required !== 1 || $isDisplayOnly || in_array($type, ['radio', 'select'], true)) {
                $regex = '';
            }
            $regexStored = $regex !== '' ? FormField::encodeRegexPatterns([$regex]) : null;
            $lengthLimitMode = (string) ($f['length_limit_mode'] ?? '');
            $minLength = isset($f['min_length']) && $f['min_length'] !== '' && !$isDisplayOnly && !in_array($type, ['radio', 'checkbox', 'select', 'file', FormField::TYPE_MATRIX], true) ? (int) $f['min_length'] : '';
            $maxLength = isset($f['max_length']) && $f['max_length'] !== '' && !$isDisplayOnly && !in_array($type, ['radio', 'checkbox', 'select', 'file', FormField::TYPE_MATRIX], true) ? (int) $f['max_length'] : '';
            $exactLength = isset($f['exact_length']) && $f['exact_length'] !== '' && !$isDisplayOnly && !in_array($type, ['radio', 'checkbox', 'select', 'file', FormField::TYPE_MATRIX], true) ? (int) $f['exact_length'] : '';
            if ($lengthLimitMode === 'exact' && $exactLength !== '') {
                $minLength = '';
                $maxLength = '';
            } elseif ($lengthLimitMode === 'range') {
                $exactLength = '';
                if ($minLength !== '' && $maxLength !== '' && $minLength > $maxLength) {
                    $minLength = $maxLength;
                }
            } else {
                $minLength = '';
                $maxLength = '';
                $exactLength = '';
            }
            $fields[] = [
                'input_page_key' => FormField::sanitizeInputPageKey((string) ($f['input_page_key'] ?? 'input-1')),
                'parent_group_key' => FormFieldGroup::sanitizeGroupKey((string) ($f['parent_group_key'] ?? '')) ?: null,
                'sort_order' => isset($f['sort_order']) && is_numeric($f['sort_order']) ? (int) $f['sort_order'] : count($fields) + 1,
                'field_key' => trim((string) ($f['field_key'] ?? '')) !== '' ? trim((string) $f['field_key']) : FieldKey::generateUuidV4(),
                'label' => trim((string) ($f['label'] ?? '')),
                'show_label' => !empty($f['show_label']) ? 1 : 0,
                'visible' => !array_key_exists('visible', $f) || !empty($f['visible']) ? 1 : 0,
                'type' => $type,
                'required' => $required,
                'min_length' => $minLength,
                'max_length' => $maxLength,
                'exact_length' => $exactLength,
                'regex' => $regexStored,
                'regex_pattern' => $regex,
                'help_text' => trim((string) ($f['help_text'] ?? '')),
                'help_text_is_html' => !empty($f['help_text_is_html']) ? 1 : 0,
                'placeholder' => (!$isDisplayOnly && !in_array($type, ['radio', 'checkbox', 'select', 'text_multi'], true)) ? trim((string) ($f['placeholder'] ?? '')) : '',
                'multi_text_items' => (string) ($f['multi_text_items'] ?? ''),
                'checkbox_limit_enabled' => ($type === 'checkbox' && $required === 1 && !empty($f['checkbox_limit_enabled'])) ? 1 : 0,
                'checkbox_min_selections' => isset($f['checkbox_min_selections']) ? (string) $f['checkbox_min_selections'] : '',
                'checkbox_max_selections' => isset($f['checkbox_max_selections']) ? (string) $f['checkbox_max_selections'] : '',
                'options' => (string) ($f['options'] ?? ''),
            ];
        }
        return $fields;
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function collectTemplateGroups(): array
    {
        $raw = $_POST['field_groups'] ?? [];
        $groups = [];
        if (!is_array($raw)) {
            return [];
        }
        foreach ($raw as $i => $group) {
            if (!is_array($group) || !empty($group['_remove'])) {
                continue;
            }
            $groupKey = FormFieldGroup::sanitizeGroupKey((string) ($group['group_key'] ?? ''));
            if ($groupKey === '') {
                $groupKey = FieldKey::generateUuidV4();
            }
            $parentGroupKey = FormFieldGroup::sanitizeGroupKey((string) ($group['parent_group_key'] ?? ''));
            if ($parentGroupKey === $groupKey) {
                $parentGroupKey = '';
            }
            $groups[] = [
                'input_page_key' => FormField::sanitizeInputPageKey((string) ($group['input_page_key'] ?? 'input-1')),
                'parent_group_key' => $parentGroupKey !== '' ? $parentGroupKey : null,
                'sort_order' => isset($group['sort_order']) && is_numeric($group['sort_order']) ? (int) $group['sort_order'] : (int) $i + 1,
                'group_key' => $groupKey,
                'label' => trim((string) ($group['label'] ?? '')),
                'show_label' => !empty($group['show_label']) ? 1 : 0,
                'description' => trim((string) ($group['description'] ?? '')),
                'visible' => !array_key_exists('visible', $group) || !empty($group['visible']) ? 1 : 0,
            ];
        }
        return $groups;
    }

    private static function appSettingIsSet(string $key): bool
    {
        $raw = AppSetting::get($key);
        return $raw !== null && $raw !== '';
    }
}
