<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\Csrf;
use Core\FileTypePolicy;
use Core\FileStorage;
use Core\View;
use Models\Form;
use Models\FormField;
use Models\Submission;

class SubmissionController
{
    public function __construct()
    {
        Auth::requireLogin();
    }

    public function index(int $formId): void
    {
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $q    = isset($_GET['q']) ? trim((string) $_GET['q']) : '';
        $from = isset($_GET['from']) ? trim((string) $_GET['from']) : '';
        $to   = isset($_GET['to']) ? trim((string) $_GET['to']) : '';
        $statusFilter = isset($_GET['status']) ? trim((string) $_GET['status']) : '';
        if ($statusFilter !== '' && !Submission::isValidWorkflowStatus($statusFilter)) {
            $statusFilter = '';
        }
        $page = max(1, (int) ($_GET['page'] ?? 1));
        $perPage = 20;

        $result = Submission::search(
            $formId,
            $q ?: null,
            $from ?: null,
            $to ?: null,
            $page,
            $perPage,
            $statusFilter !== '' ? $statusFilter : null
        );
        $totalPages = max(1, (int) ceil($result['total'] / $perPage));

        (new View())->render('admin/forms/submissions/index', array_merge([
            'title'   => '送信履歴: ' . $form['title'],
            'form'    => $form,
            'rows'    => $result['rows'],
            'total'   => $result['total'],
            'page'    => $page,
            'totalPages' => $totalPages,
            'q'       => $q,
            'from'    => $from,
            'to'      => $to,
            'statusFilter' => $statusFilter,
            'workflowStatusOptions' => Submission::allowedWorkflowStatuses(),
        ], self::listPreviewData($formId, $result['rows']), self::retentionData($form)), 'admin');
    }

    /**
     * エクスポート専用ページ。期間で絞り込んだ送信を一覧表示し、その全件をエクスポートする。
     */
    public function exportPage(int $formId): void
    {
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $from = trim((string) ($_GET['from'] ?? ''));
        $to   = trim((string) ($_GET['to'] ?? ''));
        $periodError = null;
        if (($from !== '' && !self::isValidDate($from)) || ($to !== '' && !self::isValidDate($to))) {
            $periodError = '期間の日付が正しくないため、すべての送信を表示しています。';
            $from = $to = '';
        } elseif ($from !== '' && $to !== '' && $from > $to) {
            $periodError = '開始日は終了日以前の日付にしてください。すべての送信を表示しています。';
            $from = $to = '';
        }

        $page = max(1, (int) ($_GET['page'] ?? 1));
        $perPage = 20;
        $result = Submission::search($formId, null, $from ?: null, $to ?: null, $page, $perPage);

        (new View())->render('admin/forms/submissions/export', array_merge([
            'title'   => 'エクスポート: ' . $form['title'],
            'form'    => $form,
            'rows'    => $result['rows'],
            'total'   => $result['total'],
            'page'    => $page,
            'totalPages' => max(1, (int) ceil($result['total'] / $perPage)),
            'from'    => $from,
            'to'      => $to,
            'periodError' => $periodError,
            'exportNotice' => self::exportNotice($formId, trim((string) ($_GET['export'] ?? ''))),
        ], self::listPreviewData($formId, $result['rows']), self::retentionData($form)), 'admin');
    }

    /**
     * 保存期間の警告表示用（期限日時・期限切れ件数・設定）。
     *
     * @param array<string, mixed> $form
     * @return array{retentionEnabled:bool, retentionCutoff:string, retentionDays:int, retentionDeletes:bool, expiredCount:int}
     */
    private static function retentionData(array $form): array
    {
        return [
            'retentionEnabled' => Form::retentionEnabled($form),
            'retentionCutoff' => Form::retentionCutoff($form),
            'retentionDays' => Form::retentionDays($form),
            'retentionDeletes' => Form::retentionDeletes($form),
            'expiredCount' => Form::countExpiredSubmissions($form),
        ];
    }

    /**
     * 一覧のプレビュー列（先頭 3 項目の値と添付）を用意する。
     *
     * @param array<int, array<string, mixed>> $rows
     * @return array{fields: array, previewKeys: list<string>, previews: array, previewFiles: array}
     */
    private static function listPreviewData(int $formId, array $rows): array
    {
        $fields = FormField::orderedSubmittableForForm($formId, true);
        $previewKeys = array_slice(array_map(fn($f) => $f['field_key'], $fields), 0, 3);
        $previews = [];
        $previewFiles = [];
        if (!empty($rows)) {
            $ids = array_map(fn($r) => (int) $r['id'], $rows);
            $in = implode(',', array_fill(0, count($ids), '?'));
            $values = \Core\Database::fetchAll(
                "SELECT submission_id, field_key, value FROM submission_values WHERE submission_id IN ($in)",
                $ids
            );
            foreach ($values as $r) {
                $previews[(int) $r['submission_id']][$r['field_key']] = $r['value'];
            }
            $previewFiles = Submission::filesGroupedBySubmission($ids);
        }

        return [
            'fields' => $fields,
            'previewKeys' => $previewKeys,
            'previews' => $previews,
            'previewFiles' => $previewFiles,
        ];
    }

    /**
     * エクスポートページの URL（base_path なし）。
     */
    private static function exportPageUrl(int $formId, string $from = '', string $to = '', ?string $token = null): string
    {
        $query = array_filter(['from' => $from, 'to' => $to, 'export' => $token], static fn($v): bool => $v !== null && $v !== '');
        return '/admin/forms/' . $formId . '/submissions/export' . ($query !== [] ? '?' . http_build_query($query) : '');
    }

    public function show(int $id): void
    {
        $sub = Submission::find($id);
        if (!$sub) { $this->notFound(); return; }
        $form = Form::find((int) $sub['form_id']);
        if (!$form) { $this->notFound(); return; }
        $fields = FormField::orderedSubmittableForForm((int) $form['id'], true);
        $values = Submission::valuesFor($id);
        $files  = Submission::filesFor($id);

        // ファイルキーのインデックス
        $filesByKey = [];
        foreach ($files as $f) {
            $filesByKey[$f['field_key']][] = $f;
        }

        (new View())->render('admin/forms/submissions/show', [
            'title' => '送信内容詳細',
            'form'  => $form,
            'sub'   => $sub,
            'fields'=> $fields,
            'values'=> $values,
            'filesByKey' => $filesByKey,
            'workflowStatusOptions' => Submission::allowedWorkflowStatuses(),
        ], 'admin');
    }

    public function updateStatus(int $id): void
    {
        Csrf::verify();
        $sub = Submission::find($id);
        if (!$sub) {
            $this->notFound();
            return;
        }

        $status = trim((string) ($_POST['status'] ?? ''));
        if (!Submission::isValidWorkflowStatus($status)) {
            flash('error', '無効な状態です。');
            redirect($this->safeRedirectAfterStatusChange($sub));
            return;
        }

        Submission::updateWorkflowStatus($id, $status);
        flash('success', '状態を「' . Submission::workflowStatusLabel($status) . '」に更新しました。');
        redirect($this->safeRedirectAfterStatusChange($sub));
    }

    public function destroy(int $id): void
    {
        Csrf::verify();
        $sub = Submission::find($id);
        if (!$sub) { $this->notFound(); return; }
        $formId = (int) $sub['form_id'];
        Submission::delete($id);
        flash('success', '送信を削除しました。');
        redirect('/admin/forms/' . $formId . '/submissions');
    }

    public function bulkDelete(int $formId): void
    {
        Csrf::verify();
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $submissions = $this->selectedSubmissionsForFormOrRedirect($formId);
        if ($submissions === null) {
            return;
        }

        $submissionIds = array_map(static fn(array $submission): int => (int) $submission['id'], $submissions);
        Submission::bulkDelete($submissionIds);

        flash('success', count($submissionIds) . '件の送信を削除しました。');
        redirect($this->safeSubmissionsIndexRedirect($formId));
    }

    public function exportCsv(int $formId): void
    {
        Csrf::verify();
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $submissions = $this->selectedSubmissionsForFormOrRedirect($formId);
        if ($submissions === null) {
            return;
        }

        $filename = $this->exportFilename($form, '', '', $submissions, (string) ($_POST['export_filename'] ?? ''));
        $this->redirectToPreparedExport($formId, $submissions, $filename, false, '', '');
    }

    /**
     * エクスポートページで指定した期間（空欄なら全期間）の送信をまとめて CSV、または添付込みの ZIP で書き出す。
     */
    public function exportByPeriod(int $formId): void
    {
        Csrf::verify();
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $from = trim((string) ($_POST['from'] ?? ''));
        $to   = trim((string) ($_POST['to'] ?? ''));
        $withFiles = !empty($_POST['include_files']);

        if (($from !== '' && !self::isValidDate($from)) || ($to !== '' && !self::isValidDate($to))) {
            flash('error', 'エクスポート期間の日付が正しくありません。');
            redirect(self::exportPageUrl($formId));
        }
        if ($from !== '' && $to !== '' && $from > $to) {
            flash('error', 'エクスポート期間の開始日は終了日以前の日付にしてください。');
            redirect(self::exportPageUrl($formId));
        }
        $backUrl = self::exportPageUrl($formId, $from, $to);

        $maxRows = max(1, (int) config('submissions.export_max_rows', 10000));
        $result = Submission::searchForExport(
            $formId,
            null,
            $from !== '' ? $from : null,
            $to !== '' ? $to : null,
            null,
            $maxRows
        );
        if ($result['total'] === 0) {
            flash('error', '該当する送信がありません。');
            redirect($backUrl);
        }
        if ($result['total'] > $maxRows) {
            flash('error', '該当する送信が ' . number_format($result['total']) . ' 件あり、一度にエクスポートできる上限（'
                . number_format($maxRows) . ' 件）を超えています。期間を絞ってください。');
            redirect($backUrl);
        }

        $submissions = $result['rows'];
        if ($withFiles) {
            if (!class_exists(\ZipArchive::class)) {
                flash('error', 'サーバーが ZIP 作成に対応していないため、添付ファイルを含めてエクスポートできません。');
                redirect($backUrl);
            }
            $totalBytes = self::zipEntries($submissions)['total_bytes'];
            $maxBytes = self::maxZipAttachmentBytes();
            if ($totalBytes > $maxBytes) {
                flash('error', '添付ファイルの合計（約 ' . number_format((int) ceil($totalBytes / 1048576)) . 'MB）が、一度にエクスポートできる上限（約 '
                    . number_format((int) floor($maxBytes / 1048576)) . 'MB）を超えています。期間を絞るか、添付ファイルを含めずにエクスポートしてください。');
                redirect($backUrl);
            }
        }

        $filename = $this->exportFilename($form, $from, $to, $submissions, (string) ($_POST['export_filename'] ?? ''));
        $this->redirectToPreparedExport($formId, $submissions, $filename, $withFiles, $from, $to);
    }

    /**
     * 準備済みエクスポートのファイルを返す。一覧の案内ブロックから自動または手動で呼ばれる。
     */
    public function downloadExport(int $formId, string $token): void
    {
        $job = self::findExport($formId, $token);
        if ($job === null) {
            self::plainError(404, 'エクスポートの有効期限が切れたか、見つかりません。送信履歴画面からもう一度エクスポートしてください。');
        }
        $submissions = self::existingExportSubmissions($formId, $job);
        if ($submissions === []) {
            self::plainError(404, 'エクスポート対象の送信はすでに削除されています。');
        }

        $_SESSION[self::EXPORT_SESSION_KEY][$token]['downloaded_at'] = time();
        // 大きな ZIP の送信中も一覧画面の操作がセッションロックで待たされないようにする。
        session_write_close();
        @set_time_limit(300);

        if (!empty($job['with_files'])) {
            $this->sendSubmissionsZip($formId, $submissions, (string) $job['filename']);
        }

        while (ob_get_level() > 0) { ob_end_clean(); }
        self::sendDownloadHeaders('text/csv; charset=UTF-8', $job['filename'] . '.csv');
        $output = fopen('php://output', 'wb');
        if ($output === false) {
            self::plainError(500, 'CSVを出力できませんでした。');
        }
        $this->writeSubmissionsCsv($output, $formId, $submissions);
        fclose($output);
        exit;
    }

    /**
     * ダウンロード済みのエクスポート対象を削除する（添付ファイルも削除される）。
     */
    public function deleteExport(int $formId, string $token): void
    {
        Csrf::verify();
        $form = Form::find($formId);
        if (!$form) { $this->notFound(); return; }

        $job = self::findExport($formId, $token);
        if ($job === null) {
            flash('error', 'エクスポートの有効期限が切れたか、見つかりません。');
            redirect(self::exportPageUrl($formId));
        }
        $from = (string) ($job['from'] ?? '');
        $to = (string) ($job['to'] ?? '');
        if (empty($job['downloaded_at'])) {
            flash('error', 'まだダウンロードされていないため削除できません。ファイルをダウンロードしてから削除してください。');
            redirect(self::exportPageUrl($formId, $from, $to, $token));
        }

        $ids = array_map(static fn(array $s): int => (int) $s['id'], self::existingExportSubmissions($formId, $job));
        if ($ids !== []) {
            Submission::bulkDelete($ids);
        }
        unset($_SESSION[self::EXPORT_SESSION_KEY][$token]);
        flash('success', count($ids) . '件の送信と添付ファイルを削除しました。');
        redirect(self::exportPageUrl($formId, $from, $to));
    }

    /**
     * 一覧の案内ブロック用。現在のフォームに属する有効なエクスポート履歴を返す。
     *
     * @return array{token:string, count:int, filename:string, downloaded:bool}|null
     */
    private static function exportNotice(int $formId, string $token): ?array
    {
        $job = self::findExport($formId, $token);
        if ($job === null) {
            return null;
        }
        return [
            'token' => $token,
            'count' => count($job['submission_ids']),
            'filename' => $job['filename'] . (!empty($job['with_files']) ? '.zip' : '.csv'),
            'downloaded' => !empty($job['downloaded_at']),
        ];
    }

    private const EXPORT_SESSION_KEY = '_submission_exports';
    private const EXPORT_TTL_SECONDS = 60;
    private const EXPORT_MAX_JOBS = 5;

    /**
     * @param array<int, array<string, mixed>> $submissions
     */
    private function redirectToPreparedExport(
        int $formId,
        array $submissions,
        string $filename,
        bool $withFiles,
        string $from,
        string $to
    ): void {
        self::pruneExports();
        $token = bin2hex(random_bytes(16));
        $jobs = (array) ($_SESSION[self::EXPORT_SESSION_KEY] ?? []);
        $jobs[$token] = [
            'form_id' => $formId,
            'submission_ids' => array_map(static fn(array $s): int => (int) $s['id'], $submissions),
            'filename' => $filename,
            'with_files' => $withFiles,
            'from' => $from,
            'to' => $to,
            'created_at' => time(),
            'downloaded_at' => null,
        ];
        $_SESSION[self::EXPORT_SESSION_KEY] = array_slice($jobs, -self::EXPORT_MAX_JOBS, null, true);

        redirect(self::exportPageUrl($formId, $from, $to, $token));
    }

    /**
     * @return array<string, mixed>|null
     */
    private static function findExport(int $formId, string $token): ?array
    {
        if (preg_match('/\A[0-9a-f]{32}\z/', $token) !== 1) {
            return null;
        }
        self::pruneExports();
        $job = $_SESSION[self::EXPORT_SESSION_KEY][$token] ?? null;
        if (!is_array($job) || (int) ($job['form_id'] ?? 0) !== $formId) {
            return null;
        }
        return $job;
    }

    private static function pruneExports(): void
    {
        $jobs = $_SESSION[self::EXPORT_SESSION_KEY] ?? null;
        if (!is_array($jobs)) {
            return;
        }
        $cutoff = time() - self::EXPORT_TTL_SECONDS;
        foreach ($jobs as $token => $job) {
            if (!is_array($job) || (int) ($job['created_at'] ?? 0) < $cutoff) {
                unset($jobs[$token]);
            }
        }
        $_SESSION[self::EXPORT_SESSION_KEY] = $jobs;
    }

    /**
     * @param array<string, mixed> $job
     * @return array<int, array<string, mixed>>
     */
    private static function existingExportSubmissions(int $formId, array $job): array
    {
        $ids = Submission::normalizeIds((array) ($job['submission_ids'] ?? []));
        if ($ids === []) {
            return [];
        }
        $rows = Submission::findByIdsForForm($formId, $ids);
        usort($rows, static function (array $a, array $b): int {
            return [(string) $a['submitted_at'], (int) $a['id']] <=> [(string) $b['submitted_at'], (int) $b['id']];
        });
        return $rows;
    }

    private static function plainError(int $status, string $message): never
    {
        while (ob_get_level() > 0) { ob_end_clean(); }
        http_response_code($status);
        header('Content-Type: text/plain; charset=UTF-8');
        echo $message;
        exit;
    }

    private static function maxZipAttachmentBytes(): int
    {
        return max(1, (int) config('submissions.export_max_attachment_bytes', 500 * 1024 * 1024));
    }

    /**
     * ZIP に入れる添付と ZIP 内の名前を決める。サーバー上にないファイルと SMTP メールのみモードの送信は含めない。
     *
     * @param array<int, array<string, mixed>> $submissions
     * @return array{entries: array<int, array{abs:string, name:string}>, total_bytes:int, mail_only_ids: array<int, true>}
     */
    private static function zipEntries(array $submissions): array
    {
        $submissionIds = array_map(static fn(array $submission): int => (int) $submission['id'], $submissions);
        $mailOnlyIds = [];
        foreach ($submissions as $submission) {
            if (Submission::isMailOnlyMetadata($submission)) {
                $mailOnlyIds[(int) $submission['id']] = true;
            }
        }

        $entries = [];
        $usedNames = [];
        $totalBytes = 0;
        foreach (Submission::filesGroupedBySubmission($submissionIds) as $submissionId => $filesByKey) {
            if (isset($mailOnlyIds[(int) $submissionId])) {
                continue;
            }
            foreach ($filesByKey as $fieldKey => $files) {
                foreach ($files as $file) {
                    $abs = FileStorage::absolutePath((string) ($file['stored_path'] ?? ''));
                    if (!is_file($abs)) {
                        continue;
                    }
                    $name = 'files/' . (int) $submissionId . '/'
                        . self::zipSafeName((string) $fieldKey . '_' . (string) ($file['original_name'] ?? 'file'));
                    $candidate = $name;
                    for ($n = 2; isset($usedNames[$candidate]); $n++) {
                        $ext = pathinfo($name, PATHINFO_EXTENSION);
                        $candidate = $ext !== ''
                            ? substr($name, 0, -strlen($ext) - 1) . '_' . $n . '.' . $ext
                            : $name . '_' . $n;
                    }
                    $usedNames[$candidate] = true;
                    $entries[(int) $file['id']] = ['abs' => $abs, 'name' => $candidate];
                    $totalBytes += (int) (filesize($abs) ?: 0);
                }
            }
        }

        return ['entries' => $entries, 'total_bytes' => $totalBytes, 'mail_only_ids' => $mailOnlyIds];
    }

    /**
     * CSV と添付ファイル本体を ZIP にまとめて送信する。CSV のファイル項目には ZIP 内のパスを記載する。
     *
     * @param array<int, array<string, mixed>> $submissions
     */
    private function sendSubmissionsZip(int $formId, array $submissions, string $baseName): never
    {
        if (!class_exists(\ZipArchive::class)) {
            self::plainError(500, 'サーバーが ZIP 作成に対応していないため、添付ファイルを含めてエクスポートできません。');
        }

        ['entries' => $entries, 'total_bytes' => $totalBytes, 'mail_only_ids' => $mailOnlyIds] = self::zipEntries($submissions);
        if ($totalBytes > self::maxZipAttachmentBytes()) {
            self::plainError(413, '添付ファイルの合計が、一度にエクスポートできる上限を超えています。期間を絞ってください。');
        }

        $zipPath = tempnam(sys_get_temp_dir(), 'fk-export-');
        $csvPath = tempnam(sys_get_temp_dir(), 'fk-export-csv-');
        if ($zipPath === false || $csvPath === false) {
            http_response_code(500);
            echo 'ZIPを作成できませんでした。';
            exit;
        }

        try {
            $csv = fopen($csvPath, 'wb');
            if ($csv === false) {
                throw new \RuntimeException('CSV の一時ファイルを開けません。');
            }
            $this->writeSubmissionsCsv($csv, $formId, $submissions, static function (array $file) use ($entries, $mailOnlyIds): string {
                $name = trim((string) ($file['original_name'] ?? ''));
                if (isset($mailOnlyIds[(int) ($file['submission_id'] ?? 0)])) {
                    return $name;
                }
                $entry = $entries[(int) ($file['id'] ?? 0)] ?? null;
                return $entry !== null ? $entry['name'] : $name . '（ファイルなし）';
            });
            fclose($csv);

            $zip = new \ZipArchive();
            if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
                throw new \RuntimeException('ZIP を作成できません。');
            }
            $zip->addFile($csvPath, $baseName . '.csv');
            $zip->addFromString(\Core\SubmissionArchive::MANIFEST_NAME, self::exportManifest($formId, $submissions, $entries, $mailOnlyIds));
            foreach ($entries as $entry) {
                $zip->addFile($entry['abs'], $entry['name']);
            }
            if (!$zip->close()) {
                throw new \RuntimeException('ZIP の書き込みに失敗しました。');
            }

            while (ob_get_level() > 0) { ob_end_clean(); }
            self::sendDownloadHeaders('application/zip', $baseName . '.zip');
            header('Content-Length: ' . filesize($zipPath));
            readfile($zipPath);
        } catch (\Throwable $e) {
            error_log('[form-kun] submissions zip export failed: ' . $e->getMessage());
            if (!headers_sent()) {
                http_response_code(500);
                echo 'ZIPを作成できませんでした。';
            }
        } finally {
            @unlink($csvPath);
            @unlink($zipPath);
        }
        exit;
    }

    /**
     * インポート用の復元データ（JSON）。値は DB の生の値、状態は内部コードのまま入れる。
     *
     * @param array<int, array<string, mixed>> $submissions
     * @param array<int, array{abs:string, name:string}> $entries
     * @param array<int, true> $mailOnlyIds
     */
    private static function exportManifest(int $formId, array $submissions, array $entries, array $mailOnlyIds): string
    {
        $form = Form::find($formId) ?? [];
        $submissionIds = array_map(static fn(array $s): int => (int) $s['id'], $submissions);
        $valuesBySubmission = Submission::valuesGroupedBySubmission($submissionIds);
        $filesBySubmission = Submission::filesGroupedBySubmission($submissionIds);

        $items = [];
        foreach ($submissions as $submission) {
            $sid = (int) $submission['id'];
            $files = [];
            if (!isset($mailOnlyIds[$sid])) {
                foreach ($filesBySubmission[$sid] ?? [] as $fieldKey => $fieldFiles) {
                    foreach ($fieldFiles as $file) {
                        $files[] = [
                            'field_key' => (string) $fieldKey,
                            'original_name' => (string) ($file['original_name'] ?? ''),
                            'mime_type' => $file['mime_type'] !== null ? (string) $file['mime_type'] : null,
                            'size' => $file['size'] !== null ? (int) $file['size'] : null,
                            'path' => $entries[(int) $file['id']]['name'] ?? null,
                        ];
                    }
                }
            }
            $items[] = [
                'id' => $sid,
                'submitted_at' => (string) ($submission['submitted_at'] ?? ''),
                'workflow_status' => (string) ($submission['workflow_status'] ?? Submission::WORKFLOW_PENDING),
                'storage_mode' => (string) ($submission['storage_mode'] ?? Submission::STORAGE_DATABASE),
                'ip' => (string) ($submission['ip'] ?? ''),
                'user_agent' => (string) ($submission['user_agent'] ?? ''),
                'delivery_route' => $submission['delivery_route'] ?? null,
                'mail_delivery_status' => $submission['mail_delivery_status'] ?? null,
                'mail_error_code' => $submission['mail_error_code'] ?? null,
                'attachment_count' => (int) ($submission['attachment_count'] ?? 0),
                'attachment_total_bytes' => (int) ($submission['attachment_total_bytes'] ?? 0),
                'values' => (object) ($valuesBySubmission[$sid] ?? []),
                'files' => $files,
            ];
        }

        $fields = array_map(static fn(array $f): array => [
            'field_key' => (string) ($f['field_key'] ?? ''),
            'type' => (string) ($f['type'] ?? ''),
            'label' => (string) ($f['label'] ?? ''),
        ], FormField::orderedSubmittableForForm($formId, true));

        return (string) json_encode([
            'format' => \Core\SubmissionArchive::FORMAT,
            'version' => \Core\SubmissionArchive::VERSION,
            'exported_at' => date('Y-m-d H:i:s'),
            'form' => [
                'id' => $formId,
                'title' => (string) ($form['title'] ?? ''),
                'public_uuid' => (string) ($form['public_uuid'] ?? ''),
            ],
            'fields' => $fields,
            'submissions' => $items,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    }

    /**
     * @param resource $output
     * @param array<int, array<string, mixed>> $submissions
     * @param (callable(array<string, mixed>): string)|null $fileCell 添付 1 件を CSV のセル文字列にする（既定は元ファイル名）
     */
    private function writeSubmissionsCsv($output, int $formId, array $submissions, ?callable $fileCell = null): void
    {
        $submissionIds = array_map(static fn(array $submission): int => (int) $submission['id'], $submissions);
        $fields = FormField::orderedSubmittableForForm($formId, true);
        $valuesBySubmission = Submission::valuesGroupedBySubmission($submissionIds);
        $filesBySubmission = Submission::filesGroupedBySubmission($submissionIds);

        fwrite($output, "\xEF\xBB\xBF");
        $header = ['送信ID', '受信日時', '状態', 'IPアドレス'];
        $header[] = 'User-Agent';
        $header[] = '保存方式';
        $header[] = 'SMTP配送結果';
        $header[] = '添付件数';
        $header[] = '添付合計容量';
        foreach ($fields as $field) {
            $label = trim((string) ($field['label'] ?? ''));
            $header[] = $label !== '' ? $label : (string) ($field['field_key'] ?? '');
        }
        fputcsv($output, self::sanitizeCsvRow($header));

        foreach ($submissions as $submission) {
            $submissionId = (int) $submission['id'];
            $workflowStatus = (string) ($submission['workflow_status'] ?? Submission::WORKFLOW_PENDING);
            $row = [
                (string) $submissionId,
                (string) ($submission['submitted_at'] ?? ''),
                Submission::workflowStatusLabel($workflowStatus),
                (string) ($submission['ip'] ?? ''),
                (string) ($submission['user_agent'] ?? ''),
                Submission::isMailOnlyMetadata($submission) ? 'SMTPメールのみ' : 'DB保存',
                Submission::mailDeliveryStatusLabel((string) ($submission['mail_delivery_status'] ?? '')),
                (string) (int) ($submission['attachment_count'] ?? 0),
                (string) (int) ($submission['attachment_total_bytes'] ?? 0),
            ];
            foreach ($fields as $field) {
                $row[] = $this->formatSubmissionCsvFieldValue(
                    $field,
                    $submissionId,
                    $valuesBySubmission,
                    $filesBySubmission,
                    $fileCell
                );
            }
            fputcsv($output, self::sanitizeCsvRow($row));
        }
    }

    private static function sendDownloadHeaders(string $contentType, string $filename): void
    {
        header('Content-Type: ' . $contentType);
        header('Content-Disposition: attachment; filename="' . self::asciiFallback($filename)
            . '"; filename*=UTF-8\'\'' . rawurlencode($filename));
        header('X-Content-Type-Options: nosniff');
    }

    private static function isValidDate(string $value): bool
    {
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d', $value);
        return $date !== false && $date->format('Y-m-d') === $value;
    }

    /**
     * ZIP 内のファイル名に使えない文字（区切り文字・制御文字・先頭のドット等）を置き換える。
     */
    private static function zipSafeName(string $name): string
    {
        $name = preg_replace('/[\x00-\x1f\x7f\/\\\\:*?"<>|]/u', '_', $name) ?? 'file';
        $name = ltrim(str_replace('..', '_', $name), '. ');
        if ($name === '') {
            $name = 'file';
        }
        return mb_strimwidth($name, 0, 180, '', 'UTF-8');
    }

    public function download(int $fileId): void
    {
        $file = Submission::findFile($fileId);
        if (!$file) { $this->notFound(); return; }
        $abs = FileStorage::absolutePath($file['stored_path']);
        if (!is_file($abs)) {
            http_response_code(404);
            echo 'File not found';
            exit;
        }

        $name = (string) $file['original_name'];
        // 保存名はアップロード時の検証・最適化後にアプリが決定した拡張子を使う。
        $extension = strtolower(pathinfo((string) ($file['stored_path'] ?? ''), PATHINFO_EXTENSION));
        $detectedMime = FileTypePolicy::detectMime($abs);
        $mimeMatches = FileTypePolicy::isMimeAllowedForExtension($extension, $detectedMime);
        $requestedInline = isset($_GET['inline']) && (string) $_GET['inline'] !== '' && (string) $_GET['inline'] !== '0';
        $inline = $requestedInline && $mimeMatches && FileTypePolicy::isSafeInlineImage($extension, $detectedMime);
        $mime = $mimeMatches && FileTypePolicy::isKnownExtension($extension)
            ? $detectedMime
            : 'application/octet-stream';

        while (ob_get_level() > 0) { ob_end_clean(); }
        header('Content-Type: ' . $mime);
        header('Content-Length: ' . filesize($abs));
        $disposition = $inline ? 'inline' : 'attachment';
        header('Content-Disposition: ' . $disposition . '; filename="' . self::asciiFallback($name)
            . '"; filename*=UTF-8\'\'' . rawurlencode($name));
        header('X-Content-Type-Options: nosniff');
        header('Content-Security-Policy: sandbox');
        readfile($abs);
        exit;
    }

    private static function asciiFallback(string $name): string
    {
        $ascii = preg_replace('/[^\x20-\x7e]/', '_', $name) ?? 'download';
        return str_replace('"', '_', $ascii);
    }

    /**
     * @param array<int, scalar|null> $row
     * @return array<int, string>
     */
    private static function sanitizeCsvRow(array $row): array
    {
        return array_map(static function ($value): string {
            $cell = (string) ($value ?? '');
            if (preg_match('/\A(?:[=+\-@\x09\x0A\x0D]|[＝＋－＠])/u', $cell) === 1) {
                return "'" . $cell;
            }
            return $cell;
        }, $row);
    }

    /**
     * @param array<string, mixed> $sub
     */
    private function safeRedirectAfterStatusChange(array $sub): string
    {
        $formId = (int) $sub['form_id'];
        $subId = (int) $sub['id'];
        $fallbackList = '/admin/forms/' . $formId . '/submissions';
        $fallbackShow = '/admin/forms/submissions/' . $subId;

        $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');
        if ($referer === '') {
            return $fallbackShow;
        }

        $path = parse_url($referer, PHP_URL_PATH);
        if (!is_string($path) || $path === '') {
            return $fallbackShow;
        }

        $base = rtrim((string) config('site.base_path', ''), '/');
        if ($base !== '' && str_starts_with($path, $base)) {
            $path = substr($path, strlen($base)) ?: '/';
        }

        $allowedPrefixes = [
            '/admin/forms/' . $formId . '/submissions',
            '/admin/forms/submissions/' . $subId,
        ];
        foreach ($allowedPrefixes as $prefix) {
            if ($path === $prefix || str_starts_with($path, $prefix . '?')) {
                $query = parse_url($referer, PHP_URL_QUERY);
                return $path . (is_string($query) && $query !== '' ? '?' . $query : '');
            }
        }

        return $fallbackShow;
    }

    /**
     * @return array<int, array<string, mixed>>|null
     */
    private function selectedSubmissionsForFormOrRedirect(int $formId): ?array
    {
        $submissionIds = Submission::normalizeIds($_POST['submission_ids'] ?? []);
        if ($submissionIds === []) {
            flash('error', '送信を選択してください。');
            redirect($this->safeSubmissionsIndexRedirect($formId));
        }

        $submissions = Submission::findByIdsForForm($formId, $submissionIds);
        if (count($submissions) !== count($submissionIds)) {
            flash('error', '選択した送信の一部が見つからないか、このフォームに属していません。');
            redirect($this->safeSubmissionsIndexRedirect($formId));
        }

        return $submissions;
    }

    private function safeSubmissionsIndexRedirect(int $formId): string
    {
        $fallback = '/admin/forms/' . $formId . '/submissions';
        $candidates = [];
        $postedRedirect = trim((string) ($_POST['redirect_to'] ?? ''));
        if ($postedRedirect !== '') {
            $candidates[] = $postedRedirect;
        }
        $referer = trim((string) ($_SERVER['HTTP_REFERER'] ?? ''));
        if ($referer !== '') {
            $candidates[] = $referer;
        }

        foreach ($candidates as $candidate) {
            $path = parse_url($candidate, PHP_URL_PATH);
            if (!is_string($path) || $path === '') {
                continue;
            }

            $base = rtrim((string) config('site.base_path', ''), '/');
            if ($base !== '' && str_starts_with($path, $base)) {
                $path = substr($path, strlen($base)) ?: '/';
            }

            if ($path !== $fallback) {
                continue;
            }

            $query = parse_url($candidate, PHP_URL_QUERY);
            return $path . (is_string($query) && $query !== '' ? '?' . $query : '');
        }

        return $fallback;
    }

    /**
     * @param array<string, mixed> $form
     */
    /**
     * 拡張子を除いたダウンロード名。入力が空なら「期間_フォーム名」とし、期間の空欄は対象データの最初・最後の受信日で補う。
     *
     * @param array<string, mixed> $form
     * @param array<int, array<string, mixed>> $submissions
     */
    private function exportFilename(array $form, string $from, string $to, array $submissions, string $input): string
    {
        $input = preg_replace('/\.(csv|zip)\z/i', '', trim($input)) ?? '';
        $custom = self::filenameSafe($input);
        if ($custom !== '') {
            return $custom;
        }

        $dates = array_map(static fn(array $s): string => substr((string) ($s['submitted_at'] ?? ''), 0, 10), $submissions);
        $dates = array_values(array_filter($dates, static fn(string $d): bool => self::isValidDate($d)));
        sort($dates);
        $start = $from !== '' ? $from : ($dates[0] ?? date('Y-m-d'));
        $end = $to !== '' ? $to : ($dates[count($dates) - 1] ?? date('Y-m-d'));
        $period = str_replace('-', '', $start) . ($start !== $end ? '-' . str_replace('-', '', $end) : '');

        $title = self::filenameSafe((string) ($form['title'] ?? ''));
        return $period . '_' . ($title !== '' ? $title : 'form-' . (int) ($form['id'] ?? 0));
    }

    /**
     * ダウンロード名に使えない文字（区切り文字・制御文字・Windows の禁止文字・先頭のドット）を除く。
     */
    private static function filenameSafe(string $name): string
    {
        $name = preg_replace('/[\x00-\x1f\x7f\/\\\\:*?"<>|]/u', '_', $name) ?? '';
        $name = trim(ltrim($name, '. '));
        return mb_substr($name, 0, 100, 'UTF-8');
    }

    /**
     * @param array<string, mixed> $field
     * @param array<int, array<string, string>> $valuesBySubmission
     * @param array<int, array<string, list<array<string, mixed>>>> $filesBySubmission
     */
    private function formatSubmissionCsvFieldValue(
        array $field,
        int $submissionId,
        array $valuesBySubmission,
        array $filesBySubmission,
        ?callable $fileCell = null
    ): string {
        $fieldKey = (string) ($field['field_key'] ?? '');
        $fieldType = (string) ($field['type'] ?? '');

        if ($fieldType === 'file') {
            $files = $filesBySubmission[$submissionId][$fieldKey] ?? [];
            $names = [];
            foreach ($files as $file) {
                $name = $fileCell !== null
                    ? trim($fileCell($file))
                    : trim((string) ($file['original_name'] ?? ''));
                if ($name !== '') {
                    $names[] = $name;
                }
            }
            return implode("\n", $names);
        }

        $value = (string) ($valuesBySubmission[$submissionId][$fieldKey] ?? '');
        return match ($fieldType) {
            'address' => format_address_value_display($value),
            'text_pair' => format_text_pair_value_display($value, FormField::decodeTextPairLabels($field['options_json'] ?? null)),
            'text_multi' => format_text_multi_value_display($value, FormField::decodeTextMultiItems($field['options_json'] ?? null, true)),
            FormField::TYPE_MATRIX => format_matrix_value_display($value, FormField::decodeMatrixSettings($field['options_json'] ?? null)),
            default => $value,
        };
    }

    private function notFound(): void
    {
        http_response_code(404);
        echo '<!doctype html><meta charset="utf-8"><title>404</title><h1>404</h1>';
        exit;
    }
}
