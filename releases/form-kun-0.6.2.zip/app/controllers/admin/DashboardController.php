<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\SiteResource;
use Core\View;
use Models\Form;
use Models\Submission;

class DashboardController
{
    public function index(): void
    {
        Auth::requireLogin();

        $recent = Submission::recent(10);
        $forms = Form::all();
        $countsByForm = [];
        foreach (Submission::countsByForm() as $row) {
            $countsByForm[(int) $row['id']] = (int) $row['cnt'];
        }
        foreach ($forms as &$form) {
            $form['cnt'] = $countsByForm[(int) $form['id']] ?? 0;
        }
        unset($form);
        $formCount = Form::count();
        $maxForms = effective_max_forms();
        $resource = SiteResource::snapshot();

        (new View())->render('admin/dashboard', [
            'title'               => 'ダッシュボード',
            'recent'              => $recent,
            'forms'               => $forms,
            'form_count'          => $formCount,
            'max_forms'           => $maxForms,
            'at_form_limit'       => $formCount >= $maxForms,
            'storage_used_uploads' => $resource['used_uploads'],
            'storage_used_db'     => $resource['used_db'],
            'storage_used_total'  => $resource['used_total'],
            'storage_max'         => $resource['max'],
            'storage_percent'     => $resource['percent'],
            'storage_warning'     => $resource['warning'],
            'storage_exceeded'    => $resource['exceeded'],
            'storage_resource'     => $resource,
        ], 'admin');
    }
}
