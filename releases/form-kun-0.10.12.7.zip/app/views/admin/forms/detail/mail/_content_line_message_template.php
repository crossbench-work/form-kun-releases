<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — 本文テンプレート（name=line_message_template） */
use Core\LineAccountScope;

$formId = (int) ($form['id'] ?? 0);
$lineMessageTestUrl = $formId > 0
    ? base_path('/admin/forms/' . $formId . '/line/test-message')
    : '';
if ($formId > 0) {
    $scope = LineAccountScope::forNotification($form);
    $msgTestHasPush = trim((string) $scope->pushToId()) !== '';
    $msgTestHasToken = trim((string) $scope->channelAccessToken()) !== ''
        || !empty($form['line_channel_access_token_configured']);
    $canLineMessageTest = $msgTestHasPush && $msgTestHasToken && $scope->isSetupComplete();
} else {
    $canLineMessageTest = false;
    $msgTestHasPush = false;
    $msgTestHasToken = false;
}
?>
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('表示設定'), 'line_message_template'); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input01_open(); ?>
        <?php admin_m_input01_textarea(admin_m_input01_attrs_with_bound_label('line_message_template', [
            'id' => 'line_message_template',
            'name' => 'line_message_template',
            'rows' => 6,
        ]), (string) ($form['line_message_template_effective'] ?? $form['line_message_template'] ?? '')); ?>
        <?php admin_m_input01_close(); ?>
    </div>
    <div class="area is-field">
        <input type="hidden" name="line_notify_include_images" value="0">
        <?php admin_m_checkbox01('画像をメッセージに含める', [
            'id' => 'line_notify_include_images',
            'name' => 'line_notify_include_images',
            'value' => '1',
            'checked' => !empty($form['line_notify_include_images']),
        ]); ?>
    </div>
    <div data-module="c-lineNotifyMessageTest01"<?= $lineMessageTestUrl !== '' ? ' data-test-url="' . e($lineMessageTestUrl) . '"' : '' ?> data-csrf-name="_token" data-msg-test-has-push="<?= !empty($msgTestHasPush) ? '1' : '0' ?>" data-msg-test-has-token="<?= !empty($msgTestHasToken) ? '1' : '0' ?>">
        <div class="area is-actions">
            <?php
            admin_m_btn01_button_wrap('メッセージをテスト送信する', [
                'type' => 'button',
                'class' => 'is-primary',
                'disabled' => $canLineMessageTest ? null : true,
            ]);
            ?>
        </div>
    </div>
    <?php admin_m_input_set01_close(); ?>
