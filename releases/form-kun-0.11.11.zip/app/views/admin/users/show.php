<?php
/**
 * ユーザー詳細（admin のみ）。項目ごとのモーダル編集付き。
 */
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
require_once APP_COMPONENTS_DIR . '/c-modal01/c-modal01.php';

$user = $user;
$userId = (int) $user['id'];
$username = (string) $user['username'];
$role = (string) $user['role'];
$roleLabel = match ($role) {
    'admin' => 'admin',
    'editor' => 'editor',
    'viewer' => 'viewer',
    default => $role,
};
$email = trim((string) ($user['email'] ?? ''));
$lastLoginAt = (string) ($user['last_login_at'] ?? '');
$formGrants = $form_grants ?? [];
$forms = $forms ?? [];
$grantedForms = $granted_forms ?? [];
$passkeys = $passkeys ?? [];
$errors = $errors ?? [];
$openModal = $open_modal ?? null;
$values = $values ?? [];
$twoFactorEnabled = !empty($two_factor_enabled);

$usernameValue = (string) ($values['username'] ?? $username);
$displayNameValue = (string) ($values['display_name'] ?? (string) ($user['display_name'] ?? ''));
$emailValue = (string) ($values['email'] ?? $email);
$roleValue = (string) ($values['role'] ?? $role);

$renderModalErrors = function (string $field) use ($errors, $openModal): void {
    if ($openModal !== $field || empty($errors)) {
        return;
    }
    ?>
    <div data-module="m-alert01" class="is-danger">
        <ul><?php foreach ($errors as $msg): ?><li><?= e($msg) ?></li><?php endforeach; ?></ul>
    </div>
    <?php
};

$pencilBtn = function (string $openTarget, string $label): void {
    ?>
    <button type="button" class="btn is-icon c-inlineEditBtn01" data-target="<?= e($openTarget) ?>" aria-label="<?= e($label) ?>を編集" title="編集する">
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" d="M17 3a2.828 2.828 0 114 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>
    </button>
    <?php
};
?>
<?php admin_c_breadcrumb01([
    ['label' => 'ユーザー管理', 'href' => base_path('/admin/users')],
    ['label' => 'ユーザー詳細', 'current' => true],
]); ?>

<?php admin_c_form_block01_open(); ?>
    <div class="area is-field">
        <?php admin_m_table01_open('is-kv'); ?>
            <tr><th>ユーザー名 <?php $pencilBtn('user-username-open', 'ユーザー名'); ?></th><td><code><?= e($username) ?></code></td></tr>
            <tr><th>表示名 <?php $pencilBtn('user-display-name-open', '表示名'); ?></th><td><?= e((string) ($user['display_name'] ?? '')) ?></td></tr>
            <tr><th>メールアドレス <?php $pencilBtn('user-email-open', 'メールアドレス'); ?></th><td><?= $email !== '' ? e($email) : '—' ?></td></tr>
            <tr><th>権限 <?php $pencilBtn('user-role-open', '権限'); ?></th><td><?php admin_m_badge01($roleLabel, $role); ?></td></tr>
            <?php if ($role === 'viewer'): ?>
                <tr>
                    <th>閲覧できるフォーム <?php $pencilBtn('user-form-grants-open', '閲覧できるフォーム'); ?></th>
                    <td>
                        <?php if (empty($formGrants)): ?>
                            <span data-module="m-text01" data-type="muted">許可されたフォームはありません。</span>
                        <?php else: ?>
                            <?php foreach ($formGrants as $grant): ?>
                                <div><?= e($grant['title']) ?>（<?= $grant['access'] === 'edit' ? '編集' : '閲覧' ?>）</div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
            <tr><th>パスワード <?php $pencilBtn('user-password-open', 'パスワード'); ?></th><td>••••••••</td></tr>
            <tr><th>最終ログイン</th><td><?= $lastLoginAt !== '' ? e($lastLoginAt) : '—' ?></td></tr>
            <tr><th>作成日時</th><td><?= e((string) ($user['created_at'] ?? '')) ?></td></tr>
            <tr><th>更新日時</th><td><?= e((string) ($user['updated_at'] ?? '')) ?></td></tr>
        <?php admin_m_table01_close(); ?>
    </div>
<?php admin_c_form_block01_close(); ?>

<?php if (!empty($passkeys)): ?>
    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title">
            <?php admin_m_large_title01('パスキー'); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_table01_open('is-compact'); ?>
                <thead>
                    <tr>
                        <th>名前</th>
                        <th>登録日時</th>
                        <th>最終利用</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($passkeys as $pk): ?>
                        <tr>
                            <td><?= e($pk['name'] !== null && $pk['name'] !== '' ? (string) $pk['name'] : '（名称なし）') ?></td>
                            <td><?= e((string) ($pk['created_at'] ?? '')) ?></td>
                            <td><?= e((string) ($pk['last_used_at'] ?? '—')) ?></td>
                            <td>
                                <form method="post" action="<?= e(base_path('/admin/webauthn/credentials/' . (int) $pk['id'] . '/delete')) ?>" onsubmit="return confirm('このパスキーを削除しますか？');">
                                    <?= \Core\Csrf::field() ?>
                                    <?php admin_m_btn01_button_wrap('削除', ['type' => 'submit', 'class' => 'is-danger is-sm']); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            <?php admin_m_table01_close(); ?>
        </div>
    <?php admin_c_form_block01_close(); ?>
<?php endif; ?>

<?php admin_c_modal01_open(['hidden' => $openModal !== 'username']); ?>
    <?php admin_c_modal01_backdrop('user-username-close'); ?>
    <?php admin_c_modal01_dialog_open('user-username-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('ユーザー名', 'h2', 'user-username-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/users/' . $userId . '/username')) ?>">
                <?= \Core\Csrf::field() ?>
                <?php $renderModalErrors('username'); ?>
                <div class="area is-field">
                    <?php admin_m_left_border_title01(e('ユーザー名'), 'admin-user-username-modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('admin-user-username-modal', [
                            'type' => 'text',
                            'id' => 'admin-user-username-modal',
                            'name' => 'username',
                            'value' => $usernameValue,
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">半角英数字・記号(_.-)で 3〜64 文字。</p>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="user-username-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>

<?php admin_c_modal01_open(['hidden' => $openModal !== 'display_name']); ?>
    <?php admin_c_modal01_backdrop('user-display-name-close'); ?>
    <?php admin_c_modal01_dialog_open('user-display-name-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('表示名', 'h2', 'user-display-name-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/users/' . $userId . '/display-name')) ?>">
                <?= \Core\Csrf::field() ?>
                <?php $renderModalErrors('display_name'); ?>
                <div class="area is-field">
                    <?php admin_m_left_border_title01(e('表示名'), 'admin-user-display_name-modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('admin-user-display_name-modal', [
                            'type' => 'text',
                            'id' => 'admin-user-display_name-modal',
                            'name' => 'display_name',
                            'value' => $displayNameValue,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">空のまま保存するとユーザー名が表示名になります。</p>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="user-display-name-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>

<?php admin_c_modal01_open(['hidden' => $openModal !== 'email']); ?>
    <?php admin_c_modal01_backdrop('user-email-close'); ?>
    <?php admin_c_modal01_dialog_open('user-email-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('メールアドレス', 'h2', 'user-email-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/users/' . $userId . '/email')) ?>">
                <?= \Core\Csrf::field() ?>
                <?php $renderModalErrors('email'); ?>
                <div class="area is-field">
                    <?php admin_m_left_border_title01($twoFactorEnabled ? 'メールアドレス <span data-module="m-required01" data-type="required">必須</span>' : e('メールアドレス（任意）'), 'admin-user-email-modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('admin-user-email-modal', [
                            'type' => 'email',
                            'id' => 'admin-user-email-modal',
                            'name' => 'email',
                            'value' => $emailValue,
                            'autocomplete' => 'email',
                            'required' => $twoFactorEnabled,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">「パスワードを忘れたとき」に再設定リンクを送るために使用します。</p>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="user-email-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>

<?php admin_c_modal01_open(['hidden' => $openModal !== 'role']); ?>
    <?php admin_c_modal01_backdrop('user-role-close'); ?>
    <?php admin_c_modal01_dialog_open('user-role-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('権限', 'h2', 'user-role-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/users/' . $userId . '/role')) ?>">
                <?= \Core\Csrf::field() ?>
                <?php $renderModalErrors('role'); ?>
                <div class="area is-field">
                    <?php admin_m_left_border_title01(e('権限'), 'admin-user-role'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_select_open(admin_m_input01_attrs_with_bound_label('admin-user-role', [
                            'id' => 'admin-user-role',
                            'name' => 'role',
                        ])); ?>
                        <?php admin_m_input01_option('editor', 'editor（フォーム/送信履歴の編集）', $roleValue === 'editor'); ?>
                        <?php admin_m_input01_option('viewer', 'viewer（フォーム/送信履歴の閲覧のみ）', $roleValue === 'viewer'); ?>
                        <?php admin_m_input01_option('admin', 'admin（ユーザー管理含む全権限）', $roleValue === 'admin'); ?>
                        <?php admin_m_input01_select_close(); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="user-role-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>

<?php admin_c_modal01_open(['hidden' => $openModal !== 'password']); ?>
    <?php admin_c_modal01_backdrop('user-password-close'); ?>
    <?php admin_c_modal01_dialog_open('user-password-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('パスワード', 'h2', 'user-password-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/users/' . $userId . '/password')) ?>">
                <?= \Core\Csrf::field() ?>
                <?php $renderModalErrors('password'); ?>
                <div class="area is-field">
                    <?php admin_m_left_border_title01('パスワード <span data-module="m-required01" data-type="required">必須</span>', 'admin-user-password-modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('admin-user-password-modal', [
                            'type' => 'password',
                            'id' => 'admin-user-password-modal',
                            'name' => 'password',
                            'autocomplete' => 'new-password',
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">8文字以上で設定してください。</p>
                </div>
                <div class="area is-field">
                    <?php admin_m_left_border_title01(e('パスワード（確認）'), 'admin-user-password_confirm-modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('admin-user-password_confirm-modal', [
                            'type' => 'password',
                            'id' => 'admin-user-password_confirm-modal',
                            'name' => 'password_confirm',
                            'autocomplete' => 'new-password',
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="user-password-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>

<?php admin_c_modal01_open(['hidden' => $openModal !== 'form_grants']); ?>
    <?php admin_c_modal01_backdrop('user-form-grants-close'); ?>
    <?php admin_c_modal01_dialog_open('user-form-grants-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('閲覧できるフォーム', 'h2', 'user-form-grants-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/users/' . $userId . '/form-grants')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field" id="admin-user-form-grants">
                    <?php if (empty($forms)): ?>
                        <p class="text is-help">フォームがまだありません。</p>
                    <?php else: ?>
                        <ul data-module="c-adminUserFormGrants01">
                            <?php foreach ($forms as $formRow): ?>
                                <?php
                                    $fid = (int) $formRow['id'];
                                    $isChecked = array_key_exists($fid, $grantedForms);
                                    $accessLevel = (string) ($grantedForms[$fid] ?? 'view');
                                    if (!in_array($accessLevel, ['view', 'edit'], true)) {
                                        $accessLevel = 'view';
                                    }
                                    $checkboxId = 'admin-user-form-grant-' . $fid;
                                ?>
                                <li class="item" data-target="adminUserFormGrantRow01">
                                    <?php admin_m_checkbox01(
                                        (string) $formRow['title'] . ' （' . (string) $formRow['slug'] . '）',
                                        [
                                            'id' => $checkboxId,
                                            'name' => 'form_ids[]',
                                            'value' => (string) $fid,
                                            'checked' => $isChecked,
                                            'data-target' => 'adminUserFormGrantRow01__checkbox',
                                        ]
                                    ); ?>
                                    <div class="block is-access"
                                         data-target="adminUserFormGrantRow01__access"
                                         role="group"
                                         aria-label="<?= e((string) $formRow['title']) ?> の権限"
                                        <?= $isChecked ? '' : ' hidden' ?>>
                                        <?php admin_m_radiobtn01('閲覧', [
                                            'name' => 'form_access[' . $fid . ']',
                                            'value' => 'view',
                                            'checked' => $accessLevel === 'view',
                                            'data-target' => 'adminUserFormGrantRow01__radio',
                                        ]); ?>
                                        <?php admin_m_radiobtn01('編集', [
                                            'name' => 'form_access[' . $fid . ']',
                                            'value' => 'edit',
                                            'checked' => $accessLevel === 'edit',
                                            'data-target' => 'adminUserFormGrantRow01__radio',
                                        ]); ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="user-form-grants-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
