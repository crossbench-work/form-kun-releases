<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\Csrf;
use Core\SiteResource;
use Core\View;
use Models\AppSetting;
use Models\Form;
use Models\OperationLog;
use Models\User;
use Models\UserFormGrant;

class UserController
{
    public function __construct()
    {
        Auth::requireRole('admin');
    }

    public function index(): void
    {
        $users = User::all();
        $resource = SiteResource::snapshot();
        (new View())->render('admin/users/index', [
            'title' => 'ユーザー管理',
            'users' => $users,
            'storage_resource' => $resource,
        ], 'admin');
    }

    public function createForm(): void
    {
        (new View())->render('admin/users/edit', $this->editViewData([
            'title' => 'ユーザー新規作成',
            'user'  => ['id' => null, 'username' => '', 'display_name' => '', 'email' => '', 'role' => 'editor'],
            'errors'=> [],
            'isNew' => true,
        ]), 'admin');
    }

    public function store(): void
    {
        Csrf::verify();

        $username    = trim((string) ($_POST['username'] ?? ''));
        $displayName = trim((string) ($_POST['display_name'] ?? ''));
        $email       = trim((string) ($_POST['email'] ?? ''));
        $role        = self::normalizeRole($_POST['role'] ?? '');
        $password    = (string) ($_POST['password'] ?? '');
        $passwordConf= (string) ($_POST['password_confirm'] ?? '');
        $grantedForms = self::grantsFromPost();

        $errors = $this->validateUsername($username, null);
        $errors = array_merge($errors, $this->validatePasswordPair($password, $passwordConf));
        $errors = array_merge($errors, $this->validateEmailDuplicate($email, null));
        if ($email === '' && self::twoFactorEnabled()) {
            $errors[] = '2要素認証が有効なため、メールアドレスは必須です。';
        }
        if ($displayName === '') $displayName = $username;

        if (!empty($errors)) {
            (new View())->render('admin/users/edit', $this->editViewData([
                'title' => 'ユーザー新規作成',
                'user'  => ['id' => null, 'username' => $username, 'display_name' => $displayName, 'email' => $email, 'role' => $role],
                'errors'=> $errors,
                'isNew' => true,
                'granted_forms' => $grantedForms,
            ]), 'admin');
            return;
        }

        $newId = User::create($username, $password, $displayName, $role, $email !== '' ? $email : null);
        self::syncFormGrantsForRole($newId, $role, $grantedForms);
        OperationLog::user('user.create', [
            'summary'     => 'ユーザー「' . $username . '」を作成しました',
            'target_type' => 'user',
            'target_id'   => $newId,
            'target_name' => $username,
            'detail'      => ['role' => $role],
        ]);
        flash('success', 'ユーザーを作成しました。');
        redirect('/admin/users');
    }

    public function show(int $id): void
    {
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }
        $this->renderShow([
            'user'       => $user,
            'errors'     => [],
            'open_modal' => null,
            'values'     => [],
        ]);
    }

    public function updateUsername(int $id): void
    {
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }

        Csrf::verify();
        $username = trim((string) ($_POST['username'] ?? ''));
        $errors = $this->validateUsername($username, $id);
        if (!empty($errors)) {
            $this->renderShow([
                'user'       => $user,
                'errors'     => $errors,
                'open_modal' => 'username',
                'values'     => ['username' => $username],
            ]);
            return;
        }

        $old = (string) $user['username'];
        User::setUsername($id, $username);
        self::refreshSelfIfNeeded($id);
        OperationLog::user('user.update', [
            'summary'     => 'ユーザー「' . $username . '」のユーザー名を「' . $old . '」から変更しました',
            'target_type' => 'user',
            'target_id'   => $id,
            'target_name' => $username,
            'detail'      => ['field' => 'username', 'from' => $old, 'to' => $username],
        ]);
        flash('success', 'ユーザー名を更新しました。');
        redirect('/admin/users/' . $id);
    }

    public function updateDisplayName(int $id): void
    {
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }

        Csrf::verify();
        $displayName = trim((string) ($_POST['display_name'] ?? ''));
        if ($displayName === '') $displayName = (string) $user['username'];
        User::setDisplayName($id, $displayName);
        self::refreshSelfIfNeeded($id);
        OperationLog::user('user.update', [
            'summary'     => 'ユーザー「' . (string) $user['username'] . '」の表示名を変更しました',
            'target_type' => 'user',
            'target_id'   => $id,
            'target_name' => (string) $user['username'],
            'detail'      => ['field' => 'display_name', 'to' => $displayName],
        ]);
        flash('success', '表示名を更新しました。');
        redirect('/admin/users/' . $id);
    }

    public function updateEmail(int $id): void
    {
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }

        Csrf::verify();
        $email = trim((string) ($_POST['email'] ?? ''));
        $errors = [];
        if ($email === '' && self::twoFactorEnabled()) {
            $errors[] = '2要素認証が有効なため、メールアドレスは必須です。';
        }
        $errors = array_merge($errors, $this->validateEmailDuplicate($email, $id));
        if (!empty($errors)) {
            $this->renderShow([
                'user'       => $user,
                'errors'     => $errors,
                'open_modal' => 'email',
                'values'     => ['email' => $email],
            ]);
            return;
        }

        User::setEmail($id, $email !== '' ? $email : null);
        self::refreshSelfIfNeeded($id);
        OperationLog::user('user.update', [
            'summary'     => 'ユーザー「' . (string) $user['username'] . '」のメールアドレスを変更しました',
            'target_type' => 'user',
            'target_id'   => $id,
            'target_name' => (string) $user['username'],
            'detail'      => ['field' => 'email', 'to' => $email !== '' ? $email : null],
        ]);
        flash('success', 'メールアドレスを更新しました。');
        redirect('/admin/users/' . $id);
    }

    public function updateRole(int $id): void
    {
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }

        Csrf::verify();
        $role = self::normalizeRole($_POST['role'] ?? '');
        $errors = [];
        // 最後の admin を admin 以外に変更する場合、admin が他に居なければ拒否
        if ((string) $user['role'] === 'admin' && $role !== 'admin' && $this->countOtherAdmins($id) === 0) {
            $errors[] = '他に admin 権限のユーザーがいないため、権限を変更できません。';
        }
        if (!empty($errors)) {
            $this->renderShow([
                'user'       => $user,
                'errors'     => $errors,
                'open_modal' => 'role',
                'values'     => ['role' => $role],
            ]);
            return;
        }

        User::setRole($id, $role);
        if ($role !== 'viewer') {
            UserFormGrant::clearForUser($id);
        }
        self::refreshSelfIfNeeded($id);
        OperationLog::user('user.update', [
            'summary'     => 'ユーザー「' . (string) $user['username'] . '」の権限を変更しました',
            'target_type' => 'user',
            'target_id'   => $id,
            'target_name' => (string) $user['username'],
            'detail'      => ['field' => 'role', 'from' => (string) $user['role'], 'to' => $role],
        ]);
        flash('success', '権限を更新しました。');
        redirect('/admin/users/' . $id);
    }

    public function updatePassword(int $id): void
    {
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }

        Csrf::verify();
        $password    = (string) ($_POST['password'] ?? '');
        $passwordConf= (string) ($_POST['password_confirm'] ?? '');
        $errors = $this->validatePasswordPair($password, $passwordConf);
        if (!empty($errors)) {
            $this->renderShow([
                'user'       => $user,
                'errors'     => $errors,
                'open_modal' => 'password',
                'values'     => [],
            ]);
            return;
        }

        User::setPassword($id, $password);
        self::refreshSelfIfNeeded($id);
        OperationLog::user('user.update', [
            'summary'     => 'ユーザー「' . (string) $user['username'] . '」のパスワードを変更しました',
            'target_type' => 'user',
            'target_id'   => $id,
            'target_name' => (string) $user['username'],
            'detail'      => ['field' => 'password', 'password_changed' => true],
        ]);
        flash('success', 'パスワードを変更しました。');
        redirect('/admin/users/' . $id);
    }

    public function updateFormGrants(int $id): void
    {
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }

        Csrf::verify();
        $grants = self::grantsFromPost();
        self::syncFormGrantsForRole($id, (string) $user['role'], $grants);
        $labels = [];
        if (!empty($grants)) {
            $forms = \Models\Form::allByIds(array_keys($grants));
            $titlesById = [];
            foreach ($forms as $form) {
                $titlesById[(int) $form['id']] = (string) ($form['title'] ?? '');
            }
            foreach ($grants as $formId => $access) {
                $labels[] = ($titlesById[$formId] ?? ('フォーム#' . $formId)) . '（' . ($access === 'edit' ? '編集' : '閲覧') . '）';
            }
        }
        OperationLog::user('user.update', [
            'summary'     => 'ユーザー「' . (string) $user['username'] . '」の閲覧できるフォームを更新しました',
            'target_type' => 'user',
            'target_id'   => $id,
            'target_name' => (string) $user['username'],
            'detail'      => ['field' => 'form_grants', 'forms' => $labels],
        ]);
        flash('success', '閲覧できるフォームを更新しました。');
        redirect('/admin/users/' . $id);
    }

    /**
     * ユーザー詳細ページの描画。項目別保存のエラー再表示でも使う。
     * @param array<string, mixed> $data
     */
    private function renderShow(array $data): void
    {
        $user = $data['user'];
        $id = (int) $user['id'];
        if (!isset($data['passkeys'])) {
            $data['passkeys'] = \Core\WebAuthnService::available()
                ? \Models\UserWebauthnCredential::listForUser($id)
                : [];
        }
        if (!isset($data['forms'])) {
            $data['forms'] = \Models\Form::all();
        }
        if (!isset($data['granted_forms'])) {
            $data['granted_forms'] = UserFormGrant::grantsForUser($id);
        }
        if (!isset($data['form_grants'])) {
            $data['form_grants'] = self::formGrantsForDisplay($user);
        }
        (new View())->render('admin/users/show', array_merge([
            'title'              => 'ユーザー詳細',
            'two_factor_enabled' => self::twoFactorEnabled(),
            'errors'             => [],
            'open_modal'         => null,
            'values'             => [],
        ], $data), 'admin');
    }

    /**
     * viewer の詳細表示用に、許可フォームの一覧（フォーム名・閲覧/編集の別）を組み立てる。
     * @return list<array{form_id: int, title: string, access: string}>
     */
    private static function formGrantsForDisplay(array $user): array
    {
        if ((string) $user['role'] !== 'viewer') {
            return [];
        }
        $grants = UserFormGrant::grantsForUser((int) $user['id']);
        $forms = \Models\Form::allByIds(array_keys($grants));
        $titlesById = [];
        foreach ($forms as $form) {
            $titlesById[(int) $form['id']] = (string) ($form['title'] ?? '');
        }
        $list = [];
        foreach ($grants as $formId => $access) {
            $list[] = [
                'form_id' => $formId,
                'title'   => $titlesById[$formId] ?? '（削除されたフォーム）',
                'access'  => $access,
            ];
        }
        return $list;
    }

    private static function refreshSelfIfNeeded(int $id): void
    {
        if ((int) Auth::id() === $id) {
            Auth::refreshCurrentUser();
        }
    }

    public function destroy(int $id): void
    {
        Csrf::verify();
        $user = User::find($id);
        if (!$user) { $this->notFound(); return; }

        if ((int) Auth::id() === $id) {
            flash('danger', 'ログイン中の自分自身は削除できません。');
            redirect('/admin/users');
        }

        if ($user['role'] === 'admin' && $this->countOtherAdmins($id) === 0) {
            flash('danger', '最後の admin ユーザーは削除できません。');
            redirect('/admin/users');
        }

        User::delete($id);
        OperationLog::user('user.delete', [
            'summary'     => 'ユーザー「' . (string) $user['username'] . '」を削除しました',
            'target_type' => 'user',
            'target_id'   => $id,
            'target_name' => (string) $user['username'],
        ]);
        flash('success', 'ユーザーを削除しました。');
        redirect('/admin/users');
    }

    /**
     * ユーザー名の形式と重複チェック（作成時と変更時で共用）。
     * @return string[] エラーメッセージ
     */
    private function validateUsername(string $username, ?int $excludeUserId): array
    {
        $errors = [];
        if (!preg_match('/\A[a-zA-Z0-9_.\-]{3,64}\z/', $username)) {
            $errors[] = 'ユーザー名は半角英数字・記号(_.-)で3〜64文字で入力してください。';
        } else {
            $other = User::findByUsername($username);
            if ($other !== null && ($excludeUserId === null || (int) $other['id'] !== $excludeUserId)) {
                $errors[] = 'そのユーザー名は既に使われています。';
            }
        }
        return $errors;
    }

    /**
     * パスワードの規則と確認入力の一致チェック（作成時と変更時で共用）。
     * @return string[] エラーメッセージ
     */
    private function validatePasswordPair(string $password, string $passwordConf): array
    {
        $errors = [];
        if (mb_strlen($password) < 8) {
            $errors[] = 'パスワードは8文字以上で設定してください。';
        }
        if ($password !== $passwordConf) {
            $errors[] = '確認用パスワードが一致しません。';
        }
        return $errors;
    }

    /**
     * @return string[] エラーメッセージ
     */
    private function validateEmailDuplicate(string $email, ?int $excludeUserId): array
    {
        $errors = [];
        if ($email === '') {
            return $errors;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'メールアドレスの形式が正しくありません。';
            return $errors;
        }
        $other = User::findByEmail($email);
        if ($other !== null && ($excludeUserId === null || (int) $other['id'] !== $excludeUserId)) {
            $errors[] = 'そのメールアドレスは既に使われています。';
        }
        return $errors;
    }

    private function countOtherAdmins(int $excludeId): int
    {
        $row = \Core\Database::fetchOne(
            "SELECT COUNT(*) AS c FROM users WHERE role = 'admin' AND id <> ?",
            [$excludeId]
        );
        return (int) ($row['c'] ?? 0);
    }

    /**
     * @param array<string, mixed> $data
     * @return array<string, mixed>
     */
    private function editViewData(array $data): array
    {
        if (!isset($data['forms'])) {
            $data['forms'] = Form::all();
        }
        if (!isset($data['two_factor_enabled'])) {
            $data['two_factor_enabled'] = self::twoFactorEnabled();
        }
        if (!isset($data['granted_forms'])) {
            $uid = (int) ($data['user']['id'] ?? 0);
            $data['granted_forms'] = $uid > 0 ? UserFormGrant::grantsForUser($uid) : [];
        }
        return $data;
    }

    private static function normalizeRole(mixed $raw): string
    {
        return in_array($raw, ['admin', 'editor', 'viewer'], true) ? (string) $raw : 'editor';
    }

    private static function twoFactorEnabled(): bool
    {
        return AppSetting::get(AppSetting::KEY_TWO_FACTOR_ENABLED) === '1';
    }

    /**
     * @return array<int, string> form_id => view|edit
     */
    private static function grantsFromPost(): array
    {
        $rawIds = $_POST['form_ids'] ?? [];
        if (!is_array($rawIds)) {
            return [];
        }
        $accessRaw = $_POST['form_access'] ?? [];
        if (!is_array($accessRaw)) {
            $accessRaw = [];
        }
        $grants = [];
        foreach ($rawIds as $v) {
            $id = (int) $v;
            if ($id <= 0 || isset($grants[$id])) {
                continue;
            }
            $level = (string) ($accessRaw[$id] ?? $accessRaw[(string) $id] ?? 'view');
            if (!in_array($level, ['view', 'edit'], true)) {
                $level = 'view';
            }
            $grants[$id] = $level;
        }
        return $grants;
    }

    /**
     * @param array<int, string> $grants
     */
    private static function syncFormGrantsForRole(int $userId, string $role, array $grants): void
    {
        if ($role === 'viewer') {
            UserFormGrant::syncForUser($userId, $grants);
            return;
        }
        UserFormGrant::clearForUser($userId);
    }

    private function notFound(): void
    {
        http_response_code(404);
        echo '<!doctype html><meta charset="utf-8"><title>404</title><h1>404</h1>';
        exit;
    }
}
