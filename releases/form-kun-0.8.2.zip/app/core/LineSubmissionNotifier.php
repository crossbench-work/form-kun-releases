<?php
namespace Core;

class LineSubmissionNotifier
{
    private const MAX_TEXT_LENGTH = 5000;

    private const DEFAULT_TEMPLATE = <<<'TXT'
フォーム「{{__form_title__}}」に新しい送信がありました。
受信日時: {{__submitted_at__}}
{{__submission_url__}}
TXT;

    /**
     * @param array<string, mixed> $form
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    public static function notify(array $form, array $fields, array $values, ?int $submissionId): void
    {
        try {
            self::notifyInternal($form, $fields, $values, $submissionId);
        } catch (\Throwable $e) {
            error_log('[formkun] line notify failed for form ' . (int) ($form['id'] ?? 0));
        }
    }

    /** @param array<string, mixed> $form */
    public static function sendTest(array $form): bool
    {
        $token = trim((string) ($form['line_channel_access_token'] ?? ''));
        $to = trim((string) ($form['line_push_to_id'] ?? ''));
        if ($token === '' || $to === '') {
            return false;
        }

        $text = "[ふぉーむくん] LINE通知テスト\nこのメッセージを受信できた場合、現在の設定で LINE Push できます。";

        return LineMessagingClient::pushText($token, $to, $text);
    }

    /**
     * @param array<string, mixed> $form
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    private static function notifyInternal(array $form, array $fields, array $values, ?int $submissionId): void
    {
        if (empty($form['line_notify_enabled'])) {
            return;
        }

        $token = trim((string) ($form['line_channel_access_token'] ?? ''));
        $to = trim((string) ($form['line_push_to_id'] ?? ''));
        if ($token === '' || $to === '') {
            return;
        }

        $formId = (int) ($form['id'] ?? 0);
        $submissionUrl = self::submissionUrl($formId, $submissionId);

        $context = [
            'submitted_at' => date('Y-m-d H:i:s'),
            'form_title' => (string) ($form['title'] ?? ''),
            'ip' => client_ip(),
        ];

        $template = trim((string) ($form['line_message_template'] ?? ''));
        if ($template === '') {
            $template = self::DEFAULT_TEMPLATE;
        }

        $text = Mailer::renderTemplate($template, $fields, $values, $context);
        $text = str_replace('{{__submission_url__}}', $submissionUrl, $text);
        if (mb_strlen($text) > self::MAX_TEXT_LENGTH) {
            $text = mb_substr($text, 0, self::MAX_TEXT_LENGTH);
        }

        if (!LineMessagingClient::pushText($token, $to, $text)) {
            error_log('[formkun] line push rejected for form ' . $formId);
        }
    }

    private static function submissionUrl(int $formId, ?int $submissionId): string
    {
        if ($formId <= 0) {
            return '';
        }
        if ($submissionId !== null && $submissionId > 0) {
            return url('/admin/forms/submissions/' . $submissionId);
        }

        return url('/admin/forms/' . $formId . '/submissions');
    }
}
