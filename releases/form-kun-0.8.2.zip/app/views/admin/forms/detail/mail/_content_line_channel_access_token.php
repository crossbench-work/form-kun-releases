<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — Channel access token（name=line_channel_access_token） */ ?>
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('Channel access token'), 'line_channel_access_token'); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input01_open(); ?>
        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('line_channel_access_token', [
            'type' => 'password',
            'id' => 'line_channel_access_token',
            'name' => 'line_channel_access_token',
            'value' => '',
            'autocomplete' => 'new-password',
        ])); ?>
        <?php admin_m_input01_close(); ?>
        <p class="text is-help">
            LINE Developers の Messaging API 設定で発行したトークンです。空欄のまま保存すると現在の値を保持します。<?= !empty($form['line_channel_access_token_configured']) ? '現在は設定済みです。' : '現在は未設定です。' ?>
        </p>
        <?php if (!empty($form['line_channel_access_token_configured'])): ?>
            <input type="hidden" name="line_clear_token" value="0">
            <?php admin_m_checkbox01('保存済みの Channel access token を削除する', [
                'name' => 'line_clear_token',
                'value' => '1',
                'checked' => !empty($form['line_clear_token']),
            ]); ?>
        <?php endif; ?>
    </div>
    <?php admin_m_input_set01_close(); ?>
