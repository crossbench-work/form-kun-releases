<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — 本文テンプレート（name=line_message_template） */ ?>
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('通知メッセージ'), 'line_message_template'); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input01_open(); ?>
        <?php admin_m_input01_textarea(admin_m_input01_attrs_with_bound_label('line_message_template', [
            'id' => 'line_message_template',
            'name' => 'line_message_template',
            'rows' => 8,
        ]), (string) ($form['line_message_template'] ?? '')); ?>
        <?php admin_m_input01_close(); ?>
        <p class="text is-help">空欄の場合はフォーム名・受信日時・管理画面 URL のみ送信します。{{__all__}} を含めると入力内容も LINE に送られます。</p>
    </div>
    <?php admin_m_input_set01_close(); ?>
