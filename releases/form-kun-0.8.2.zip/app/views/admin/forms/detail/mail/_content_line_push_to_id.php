<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — 送信先 ID（name=line_push_to_id） */ ?>
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('送信先 ID（userId / groupId）'), 'line_push_to_id'); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input01_open(); ?>
        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('line_push_to_id', [
            'type' => 'text',
            'id' => 'line_push_to_id',
            'name' => 'line_push_to_id',
            'value' => (string) ($form['line_push_to_id'] ?? ''),
            'autocomplete' => 'off',
            'maxlength' => 64,
        ])); ?>
        <?php admin_m_input01_close(); ?>
        <p class="text is-help">Messaging API の Push 先です。公式アカウントを友だち追加したユーザーの userId、または Bot を招待したグループの groupId を指定します。</p>
    </div>
    <?php admin_m_input_set01_close(); ?>
