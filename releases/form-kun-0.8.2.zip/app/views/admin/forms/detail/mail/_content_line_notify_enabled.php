<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — 有効化（name=line_notify_enabled） */ ?>
    <input type="hidden" name="line_notify_enabled" value="0">
    <?php admin_m_checkbox01('受信時に LINE へ通知する', [
        'name' => 'line_notify_enabled',
        'value' => '1',
        'checked' => !empty($form['line_notify_enabled']),
    ]); ?>
