<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — 使用可能な変数一覧 */ ?>
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('メッセージで使用可能な変数')); ?>
    </div>
    <div class="area is-field">
        <?php admin_c_copy_tag_list01(['{{field_key}}', '{{__all__}}', '{{__form_title__}}', '{{__submitted_at__}}', '{{__ip__}}', '{{__submission_url__}}']); ?>
    </div>
    <p class="text is-help">管理画面 URL を正しく開くには、サイト設定の base URL（絶対 URL）の設定を推奨します。</p>
    <?php admin_m_input_set01_close(); ?>
