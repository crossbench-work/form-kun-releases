<?php
/** フォーム編集:「通知」タブパネル
 * _content_*.php … c-formBlock01 直下 .area.is-field の内側。各ファイル先頭コメントにフィールドの説明あり。
 */
?>
<div data-target="c-formEditTabs01__contents" data-tab-panel="mail" class="area is-contents" role="tabpanel"
    aria-label="通知" hidden>
    <?php admin_c_form_edit_section_tabs01_open('mail', [
        ['panel' => 'mail-smtp', 'label' => '通知設定', 'selected' => true],
        ['panel' => 'mail-admin', 'label' => '管理者通知'],
        ['panel' => 'mail-line', 'label' => 'LINE通知'],
        ['panel' => 'mail-reply', 'label' => '自動返信'],
    ], '通知の区分'); ?>
        <div data-target="c-formEditTabs01__contents" data-tab-panel="mail-smtp" class="area is-contents" role="tabpanel"
            aria-label="通知設定">
            <?php admin_c_form_block01_open(); ?>
                <input type="hidden" name="_mail_section_present[smtp]" value="1">
                <div class="area is-title">
                    <?php admin_m_large_title01('通知設定'); ?>
                </div>
                <?php if (\Core\Auth::role() !== 'admin'): ?>
                <div class="area is-field">
                    <?php admin_m_alert01('送信方式・送信元・SMTP の設定は admin のみ変更できます。編集しても保存されません。', 'info'); ?>
                </div>
                <?php endif; ?>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_transport.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_submission_storage_mode.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_from_email.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_from_name.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_smtp_host.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_smtp_port.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_smtp_secure.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_smtp_username.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_smtp_password.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_smtp_ehlo_host.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_smtp_timeout.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_smtp_verify_peer.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_smtp_verify_peer_name.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_smtp_allow_self_signed.php'; ?>
                </div>
            <?php admin_c_form_block01_close(); ?>
        </div>
        <div data-target="c-formEditTabs01__contents" data-tab-panel="mail-admin" class="area is-contents" role="tabpanel"
            aria-label="管理者通知" hidden>
            <?php admin_c_form_block01_open(); ?>
                <input type="hidden" name="_mail_section_present[admin]" value="1">
                <div class="area is-title">
                    <?php admin_m_large_title01('管理者通知'); ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_admin_emails.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_subject_admin.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_template_admin.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_mail_template_vars.php'; ?>
                </div>
            <?php admin_c_form_block01_close(); ?>
        </div>
        <div data-target="c-formEditTabs01__contents" data-tab-panel="mail-line" class="area is-contents" role="tabpanel"
            aria-label="LINE通知" hidden>
            <?php admin_c_form_block01_open(); ?>
                <input type="hidden" name="_mail_section_present[line]" value="1">
                <div class="area is-title">
                    <?php admin_m_large_title01('LINE通知'); ?>
                </div>
                <?php if (\Core\Auth::role() !== 'admin'): ?>
                <div class="area is-field">
                    <?php admin_m_alert01('Channel access token の設定は admin のみ変更できます。編集しても保存されません。', 'info'); ?>
                </div>
                <?php endif; ?>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_line_notify_enabled.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_line_push_to_id.php'; ?>
                </div>
                <?php if (\Core\Auth::role() === 'admin'): ?>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_line_channel_access_token.php'; ?>
                </div>
                <div class="area is-field">
                    <button type="submit" class="btn" formaction="<?= e(base_path('/admin/forms/' . (int) $form['id'] . '/test-line')) ?>" formmethod="post" formnovalidate>設定を保存して LINE テスト</button>
                </div>
                <?php endif; ?>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_line_message_template.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_line_message_template_vars.php'; ?>
                </div>
            <?php admin_c_form_block01_close(); ?>
        </div>
        <div data-target="c-formEditTabs01__contents" data-tab-panel="mail-reply" class="area is-contents" role="tabpanel"
            aria-label="自動返信" hidden>
            <?php admin_c_form_block01_open(); ?>
                <input type="hidden" name="_mail_section_present[reply]" value="1">
                <div class="area is-title">
                    <?php admin_m_large_title01('自動返信'); ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_reply_enabled.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_reply_from_field_key.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_reply_subject.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_reply_template.php'; ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_reply_template_vars.php'; ?>
                </div>
            <?php admin_c_form_block01_close(); ?>
        </div>
    <?php admin_c_form_edit_section_tabs01_close(); ?>
</div>
