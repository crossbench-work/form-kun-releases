<?php
namespace Core;

use Models\Form;
use Models\FormBranchRule;
use Models\FormEmbedSetting;
use Models\FormField;
use Models\FormFieldGroup;
use Models\FormInputPage;
use Models\FormVersion;

/**
 * フォーム設定を、機密情報を除いた可搬 JSON として入出力する。
 */
class FormSettingsTransfer
{
    public const FORMAT = 'form-kun-form-settings';
    public const VERSION = 1;
    public const MAX_FILE_BYTES = 5_242_880;

    /** @return array<string, mixed> */
    public static function exportAll(): array
    {
        $items = [];
        foreach (Form::all() as $form) {
            $formId = (int) ($form['id'] ?? 0);
            if ($formId <= 0) {
                continue;
            }
            $items[] = self::exportFormItem($formId, $form, FormBundleExportOptions::defaults());
        }

        return [
            'format' => self::FORMAT,
            'version' => self::VERSION,
            'exported_at' => date(DATE_ATOM),
            'forms' => $items,
        ];
    }

    /** @return array<string, mixed> */
    public static function exportForm(int $formId, ?FormBundleExportOptions $options = null): array
    {
        $form = Form::find($formId);
        if (!$form) {
            throw new \InvalidArgumentException('フォームが見つかりません。');
        }
        $options ??= FormBundleExportOptions::defaults();

        return [
            'format' => self::FORMAT,
            'version' => self::VERSION,
            'exported_at' => date(DATE_ATOM),
            'forms' => [self::exportFormItem($formId, $form, $options)],
        ];
    }

    public static function exportFormSettingsFile(int $formId, ?FormBundleExportOptions $options = null): string
    {
        $json = json_encode(self::exportForm($formId, $options), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        if (!is_string($json)) {
            throw new \RuntimeException('フォーム設定を JSON にできませんでした。');
        }

        return $json;
    }

    /**
     * @param array<string, mixed> $formRow
     * @return array<string, mixed>
     */
    private static function exportFormItem(int $formId, array $formRow, FormBundleExportOptions $options): array
    {
        $form = self::withoutKeys($formRow, [
            'id', 'public_uuid', 'created_at', 'updated_at', 'mail_smtp_password', 'smtp_tested_at', 'smtp_test_fingerprint',
            'line_channel_access_token',
            'line_channel_secret',
        ]);
        if (!$options->includeSmtp) {
            $form = self::withoutKeys($form, FormBundleExportOptions::smtpFormKeys());
        }
        if (!$options->includeLine) {
            $form = self::withoutKeys($form, FormBundleExportOptions::lineFormKeys());
        }
        if (!$options->includeCustomAssets) {
            $form = self::withoutKeys($form, FormBundleExportOptions::customAssetFormKeys());
        }
        if (!$options->includePublishSchedule) {
            $form = self::withoutKeys($form, FormBundleExportOptions::publishScheduleFormKeys());
        }
        if (!$options->includeRetention) {
            $form = self::withoutKeys($form, FormBundleExportOptions::retentionFormKeys());
        }

        if ($options->includeEmbed) {
            $embed = FormEmbedSetting::forForm($formId, false);
            $embed = self::withoutKeys($embed, [
                'form_id', 'allowed_origins_json', 'turnstile_secret_key', 'turnstile_secret_configured',
                'recaptcha_secret_key', 'recaptcha_secret_configured', 'recaptcha_v3_secret_key',
                'recaptcha_v3_secret_configured', 'captcha_provider', 'created_at', 'updated_at',
            ]);
        } else {
            $embed = FormEmbedSetting::defaults($formId);
            $embed = self::withoutKeys($embed, ['form_id', 'captcha_provider']);
        }

        return [
            'form' => $form,
            'input_pages' => self::stripRecordKeys(FormInputPage::forForm($formId, $formRow), ['id', 'form_id', 'created_at', 'updated_at']),
            'field_groups' => self::stripRecordKeys(FormFieldGroup::forForm($formId, true), ['id', 'form_id', 'created_at', 'updated_at']),
            'fields' => self::stripRecordKeys(FormField::forForm($formId, true), ['id', 'form_id']),
            'branch_rules' => self::stripRecordKeys(FormBranchRule::forForm($formId), ['id', 'form_id', 'created_at', 'updated_at']),
            'embed_settings' => $embed,
        ];
    }

    /**
     * @return array{count:int, ids:array<int,int>}
     */
    public static function importJson(string $json, int $availableSlots, ?array $actor = null): array
    {
        try {
            $payload = json_decode($json, true, 128, JSON_THROW_ON_ERROR);
        } catch (\JsonException $e) {
            throw new \InvalidArgumentException('JSON の形式が不正です。');
        }
        if (!is_array($payload) || ($payload['format'] ?? '') !== self::FORMAT || (int) ($payload['version'] ?? 0) !== self::VERSION) {
            throw new \InvalidArgumentException('このファイルは対応しているフォーム設定ファイルではありません。');
        }
        $items = $payload['forms'] ?? null;
        if (!is_array($items) || $items === []) {
            throw new \InvalidArgumentException('インポートできるフォームが含まれていません。');
        }
        if (count($items) > $availableSlots) {
            throw new \InvalidArgumentException('フォームの作成上限を超えます。インポート可能な件数は ' . max(0, $availableSlots) . ' 件です。');
        }

        $prepared = [];
        foreach (array_values($items) as $index => $item) {
            $prepared[] = self::prepareItem($item, $index + 1);
        }

        $ids = Database::transaction(function () use ($prepared, $actor): array {
            $ids = [];
            foreach ($prepared as $item) {
                $form = $item['form'];
                $form['slug'] = self::availableSlug((string) $form['slug']);
                $form['public_uuid'] = \uuid_v4();
                $form['status'] = 'draft';
                $form['mail_smtp_password'] = null;
                $form['line_channel_access_token'] = null;
                $form['line_channel_secret'] = null;
                $form['submission_storage_mode'] = Form::STORAGE_DATABASE;
                $form['smtp_tested_at'] = null;
                $form['smtp_test_fingerprint'] = null;

                $id = Form::create($form);
                FormInputPage::replaceForForm($id, $item['input_pages'], false);
                FormFieldGroup::replaceForForm($id, $item['field_groups'], false);
                FormField::replaceStoredForForm($id, $item['fields'], false);
                FormBranchRule::replaceForForm($id, $item['branch_rules'], false);

                $embed = $item['embed_settings'];
                $embed['enabled'] = 0;
                $embed['turnstile_enabled'] = 0;
                $embed['recaptcha_enabled'] = 0;
                $embed['recaptcha_v3_enabled'] = 0;
                FormEmbedSetting::save($id, $embed);
                FormVersion::createSnapshot($id, FormVersion::ACTION_IMPORT, $actor);
                $ids[] = $id;
            }
            return $ids;
        });

        return ['count' => count($ids), 'ids' => $ids];
    }

    /** @return array<string, mixed> */
    private static function prepareItem($item, int $number): array
    {
        if (!is_array($item) || !is_array($item['form'] ?? null)) {
            throw new \InvalidArgumentException("{$number} 件目のフォーム本体が不正です。");
        }
        $form = $item['form'];
        $title = trim((string) ($form['title'] ?? ''));
        if ($title === '' || mb_strlen($title) > 200) {
            throw new \InvalidArgumentException("{$number} 件目のフォームタイトルが不正です。");
        }
        $slug = trim((string) ($form['slug'] ?? ''));
        if (!preg_match('/\A[a-zA-Z0-9_\-]{1,64}\z/', $slug)) {
            $slug = 'imported-form';
        }

        $pages = self::recordList($item, 'input_pages', 100, $number);
        $groups = self::recordList($item, 'field_groups', 1000, $number);
        $fields = self::recordList($item, 'fields', 5000, $number);
        $rules = self::recordList($item, 'branch_rules', 5000, $number);
        $pages = FormInputPage::normalizePages($pages, $form);

        $pageKeys = array_column($pages, 'page_key');
        $fieldKeys = [];
        foreach ($fields as &$field) {
            $key = trim((string) ($field['field_key'] ?? ''));
            if (!FieldKey::isValid($key) || isset($fieldKeys[$key])) {
                throw new \InvalidArgumentException("{$number} 件目のフォーム項目キーが不正または重複しています。");
            }
            $fieldKeys[$key] = true;
            $field['type'] = FormField::sanitizeType((string) ($field['type'] ?? ''));
            $field['input_page_key'] = FormField::sanitizeInputPageKey((string) ($field['input_page_key'] ?? ''));
            if (!in_array($field['input_page_key'], $pageKeys, true)) {
                throw new \InvalidArgumentException("{$number} 件目のフォーム項目が存在しない入力画面を参照しています。");
            }
        }
        unset($field);

        $groupKeys = [];
        foreach ($groups as &$group) {
            $key = FormFieldGroup::sanitizeGroupKey((string) ($group['group_key'] ?? ''));
            if ($key === '' || isset($groupKeys[$key])) {
                throw new \InvalidArgumentException("{$number} 件目の項目グループキーが不正または重複しています。");
            }
            $groupKeys[$key] = true;
            $group['group_key'] = $key;
            $group['input_page_key'] = FormField::sanitizeInputPageKey((string) ($group['input_page_key'] ?? ''));
            if (!in_array($group['input_page_key'], $pageKeys, true)) {
                throw new \InvalidArgumentException("{$number} 件目の項目グループが存在しない入力画面を参照しています。");
            }
        }
        unset($group);
        foreach ($groups as $group) {
            $parentKey = FormFieldGroup::sanitizeGroupKey((string) ($group['parent_group_key'] ?? ''));
            if ($parentKey !== '' && !isset($groupKeys[$parentKey])) {
                throw new \InvalidArgumentException("{$number} 件目の項目グループが存在しない親グループを参照しています。");
            }
        }
        foreach ($fields as $field) {
            $parentKey = FormFieldGroup::sanitizeGroupKey((string) ($field['parent_group_key'] ?? ''));
            if ($parentKey !== '' && !isset($groupKeys[$parentKey])) {
                throw new \InvalidArgumentException("{$number} 件目のフォーム項目が存在しないグループを参照しています。");
            }
        }
        $ruleErrors = FormBranchRule::validateRules($rules, $fields, $pages, $groups);
        if ($ruleErrors !== []) {
            throw new \InvalidArgumentException("{$number} 件目の分岐設定が不正です。" . (string) $ruleErrors[0]);
        }

        $embed = is_array($item['embed_settings'] ?? null) ? $item['embed_settings'] : [];
        $form = self::normalizeImportedForm($form);
        $form['title'] = $title;
        $form['slug'] = $slug;

        return [
            'form' => $form,
            'input_pages' => $pages,
            'field_groups' => $groups,
            'fields' => $fields,
            'branch_rules' => $rules,
            'embed_settings' => $embed,
        ];
    }

    /**
     * インポート値は編集画面の入力検証を通らないため、出力・送信に使う項目をここで正規化する。
     *
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    private static function normalizeImportedForm(array $form): array
    {
        $defaults = \Controllers\Admin\FormController::defaultForm();
        $form = \Controllers\Admin\FormController::applyAdminOnlyFieldPolicy($form, $defaults);

        $form['header_html'] = sanitize_rich_text_html((string) ($form['header_html'] ?? ''));
        $form['footer_html'] = sanitize_rich_text_html((string) ($form['footer_html'] ?? ''));

        foreach (['thanks_button_url', 'closed_button_url'] as $key) {
            $url = trim((string) ($form[$key] ?? ''));
            $form[$key] = ($url !== '' && is_form_button_url($url)) ? $url : '';
        }

        $emails = array_filter(
            array_map('trim', preg_split('/[,;]+/', (string) ($form['admin_emails'] ?? '')) ?: []),
            static fn(string $email): bool => $email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) !== false
        );
        $form['admin_emails'] = implode(',', $emails);

        $fromEmail = trim((string) ($form['mail_from_email'] ?? ''));
        if ($fromEmail !== '' && filter_var($fromEmail, FILTER_VALIDATE_EMAIL) === false) {
            $form['mail_from_email'] = (string) ($defaults['mail_from_email'] ?? '');
        }
        $form['mail_from_name'] = str_replace(["\r", "\n"], '', (string) ($form['mail_from_name'] ?? ''));

        $ehloHost = trim((string) ($form['mail_smtp_ehlo_host'] ?? ''));
        if ($ehloHost !== '' && !Mailer::isValidEhloHost($ehloHost)) {
            $form['mail_smtp_ehlo_host'] = '';
        }

        return $form;
    }

    /** @return array<int, array<string, mixed>> */
    private static function recordList(array $item, string $key, int $max, int $number): array
    {
        $list = $item[$key] ?? [];
        if (!is_array($list) || count($list) > $max) {
            throw new \InvalidArgumentException("{$number} 件目の {$key} が不正です。");
        }
        foreach ($list as $record) {
            if (!is_array($record)) {
                throw new \InvalidArgumentException("{$number} 件目の {$key} が不正です。");
            }
        }
        return array_values($list);
    }

    private static function availableSlug(string $source): string
    {
        $base = preg_replace('/[^a-zA-Z0-9_-]+/', '-', trim($source)) ?: 'imported-form';
        $base = trim($base, '-_') ?: 'imported-form';
        $base = mb_substr($base, 0, 64);
        if (Form::isSlugAvailable($base)) {
            return $base;
        }
        for ($i = 1; $i <= 9999; $i++) {
            $suffix = '-import-' . $i;
            $candidate = mb_substr($base, 0, 64 - strlen($suffix)) . $suffix;
            if (Form::isSlugAvailable($candidate)) {
                return $candidate;
            }
        }
        return \uuid_v4();
    }

    /** @return array<string, mixed> */
    private static function withoutKeys(array $record, array $keys): array
    {
        foreach ($keys as $key) {
            unset($record[$key]);
        }
        return $record;
    }

    /** @return array<int, array<string, mixed>> */
    private static function stripRecordKeys(array $records, array $keys): array
    {
        return array_map(static fn(array $record): array => self::withoutKeys($record, $keys), array_values($records));
    }
}
