(function () {
    'use strict';

    var TOAST_MS = 4500;
    var TOAST_LEAVE_MS = 280;

    window.formkunShowAdminToast = function (message, type) {
        type = type || 'success';
        var stack = document.getElementById('admin-toast-stack');
        if (!stack || !message) return;
        var el = document.createElement('div');
        el.setAttribute('data-module', 'c-adminToast01');
        el.className = 'is-' + type;
        el.setAttribute('role', 'status');
        el.textContent = message;
        stack.appendChild(el);
        window.requestAnimationFrame(function () {
            el.classList.add('is-visible');
        });
        window.setTimeout(function () {
            el.classList.remove('is-visible');
            el.classList.add('is-leaving');
            window.setTimeout(function () {
                if (el.parentNode) el.parentNode.removeChild(el);
            }, TOAST_LEAVE_MS);
        }, TOAST_MS);
    };

    (function initAdminFlashToasts() {
        var stack = document.getElementById('admin-toast-stack');
        if (!stack) return;
        stack.querySelectorAll('[data-admin-autotoast]').forEach(function (el) {
            window.requestAnimationFrame(function () {
                el.classList.add('is-visible');
            });
            window.setTimeout(function () {
                el.classList.remove('is-visible');
                el.classList.add('is-leaving');
                window.setTimeout(function () {
                    if (el.parentNode) el.parentNode.removeChild(el);
                }, TOAST_LEAVE_MS);
            }, TOAST_MS);
        });
    })();

    (function initCopyTags() {
        var tags = document.querySelectorAll('[data-copy-text]');
        if (!tags.length) return;

        function fallbackCopy(text) {
            var input = document.createElement('textarea');
            input.value = text;
            input.setAttribute('readonly', 'readonly');
            input.style.position = 'absolute';
            input.style.left = '-9999px';
            document.body.appendChild(input);
            input.select();
            document.execCommand('copy');
            document.body.removeChild(input);
        }

        function showCopyToast(text) {
            if (typeof window.formkunShowAdminToast === 'function') {
                var shortText = text.length > 48 ? text.slice(0, 45) + '…' : text;
                window.formkunShowAdminToast('「' + shortText + '」をコピーしました', 'success');
            }
        }

        tags.forEach(function (tag) {
            tag.addEventListener('click', function () {
                var text = tag.getAttribute('data-copy-text') || '';
                if (!text) return;
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(text).then(function () {
                        showCopyToast(text);
                    }).catch(function () {
                        fallbackCopy(text);
                        showCopyToast(text);
                    });
                    return;
                }
                fallbackCopy(text);
                showCopyToast(text);
            });
        });
    })();

    (function initLineSetupChecklist() {
        function refreshLineSetupChecklistLock(root) {
            if (!root) {
                return;
            }
            var hasUrl = (root.getAttribute('data-checklist-url') || '') !== '';
            var priorComplete = true;
            root.querySelectorAll('.list > .entry').forEach(function (li) {
                var item = li.querySelector('.item[data-item]');
                var done = !!(item && item.classList.contains('is-done'));
                var unlocked = priorComplete;
                li.classList.toggle('is-locked', !unlocked);
                var fieldset = li.querySelector('.block.is-sub.is-extra > fieldset.is-checklistExtra');
                if (fieldset) {
                    fieldset.disabled = !unlocked;
                }
                var completeBtn = li.querySelector('button[data-checklist-complete][data-item]');
                if (completeBtn) {
                    completeBtn.disabled = !hasUrl || !unlocked || done;
                }
                if (!done) {
                    priorComplete = false;
                }
            });
        }
        window.formkunRefreshLineSetupChecklistLock = refreshLineSetupChecklistLock;

        function postChecklistComplete(root, itemKey, itemRow) {
            var url = root.getAttribute('data-checklist-url') || '';
            if (url === '' || !itemRow) {
                return;
            }
            var csrfName = root.getAttribute('data-csrf-name') || '_token';
            var csrfInput = document.querySelector('input[name="' + csrfName + '"]');
            itemRow.classList.add('is-done');
            refreshLineSetupChecklistLock(root);
            var body = new FormData();
            if (csrfInput) {
                body.append(csrfName, csrfInput.value);
            }
            body.append('item', itemKey);
            body.append('checked', '1');
            fetch(url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { Accept: 'application/json' },
                body: body,
            })
                .then(function (response) {
                    return response.json().then(function (data) {
                        return { ok: response.ok, data: data };
                    });
                })
                .then(function (result) {
                    if (result.ok && result.data && result.data.ok) {
                        refreshLineSetupChecklistLock(root);
                        return;
                    }
                    throw new Error((result.data && result.data.message) || 'save failed');
                })
                .catch(function () {
                    itemRow.classList.remove('is-done');
                    refreshLineSetupChecklistLock(root);
                    if (typeof window.formkunShowAdminToast === 'function') {
                        window.formkunShowAdminToast('チェック状態を保存できませんでした', 'danger');
                    }
                });
        }

        document.querySelectorAll('[data-module="c-lineSetupChecklist01"]').forEach(function (root) {
            refreshLineSetupChecklistLock(root);
            var url = root.getAttribute('data-checklist-url') || '';
            if (url === '') {
                return;
            }
            root.addEventListener('click', function (event) {
                var completeBtn = event.target.closest('button[data-checklist-complete][data-item]');
                if (!completeBtn || !root.contains(completeBtn) || completeBtn.disabled) {
                    return;
                }
                var itemKey = completeBtn.getAttribute('data-item') || '';
                if (itemKey === '') {
                    return;
                }
                var itemRow = root.querySelector('.item[data-item="' + itemKey + '"]');
                if (!itemRow || itemRow.classList.contains('is-done')) {
                    return;
                }
                postChecklistComplete(root, itemKey, itemRow);
            });
        });
    })();

    (function initLineNotifyTestPush01() {
        document.querySelectorAll('[data-module="c-lineNotifyTestPush01"]').forEach(function (root) {
            var url = root.getAttribute('data-test-url') || '';
            if (url === '') {
                return;
            }
            var btn = root.querySelector('button.btn');
            if (!btn || btn.disabled) {
                return;
            }
            var csrfName = root.getAttribute('data-csrf-name') || '_token';
            var csrfInput = document.querySelector('input[name="' + csrfName + '"]');
            var sending = false;
            btn.addEventListener('click', function () {
                if (sending) {
                    return;
                }
                sending = true;
                btn.disabled = true;
                var body = new FormData();
                if (csrfInput) {
                    body.append(csrfName, csrfInput.value);
                }
                fetch(url, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { Accept: 'application/json' },
                    body: body,
                })
                    .then(function (response) {
                        return response.json().then(function (data) {
                            return { ok: response.ok, data: data };
                        });
                    })
                    .then(function (result) {
                        var msg =
                            result.data && result.data.message
                                ? String(result.data.message)
                                : result.ok
                                  ? 'LINE テストメッセージを送信しました。'
                                  : 'LINE テストメッセージを送信できませんでした。';
                        var type = result.ok && result.data && result.data.ok ? 'success' : 'danger';
                        if (typeof window.formkunShowAdminToast === 'function') {
                            window.formkunShowAdminToast(msg, type);
                        }
                        if (!result.ok || !result.data || !result.data.ok) {
                            throw new Error(msg);
                        }
                    })
                    .catch(function () {
                        /* toast already shown on failure */
                    })
                    .finally(function () {
                        sending = false;
                        btn.disabled = false;
                    });
            });
        });
    })();

    (function initLineImagePreviewDiagnostic01() {
        document.querySelectorAll('[data-module="c-lineImagePreviewDiagnostic01"]').forEach(function (root) {
            var url = root.getAttribute('data-test-url') || '';
            if (url === '') {
                return;
            }
            var btn = root.querySelector('button.btn');
            if (!btn) {
                return;
            }
            var resultEl = root.querySelector('[data-target="line-image-diag-result"]');
            var csrfName = root.getAttribute('data-csrf-name') || '_token';
            var csrfInput = document.querySelector('#settings-line-form input[name="' + csrfName + '"]')
                || document.querySelector('input[name="' + csrfName + '"]');
            var sending = false;
            btn.addEventListener('click', function () {
                if (sending) {
                    return;
                }
                sending = true;
                btn.disabled = true;
                if (resultEl) {
                    resultEl.hidden = true;
                    resultEl.textContent = '';
                }
                var body = new FormData();
                if (csrfInput) {
                    body.append(csrfName, csrfInput.value);
                }
                fetch(url, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { Accept: 'application/json' },
                    body: body,
                })
                    .then(function (response) {
                        return response.json().then(function (data) {
                            return { ok: response.ok, data: data };
                        });
                    })
                    .then(function (result) {
                        var msg =
                            result.data && result.data.message
                                ? String(result.data.message)
                                : result.ok
                                  ? '診断が完了しました。'
                                  : '診断に失敗しました。';
                        if (result.data && result.data.detail) {
                            msg += ' ' + String(result.data.detail);
                        }
                        if (resultEl) {
                            resultEl.hidden = false;
                            resultEl.textContent = msg;
                        }
                        var type = result.ok && result.data && result.data.ok ? 'success' : 'danger';
                        if (typeof window.formkunShowAdminToast === 'function') {
                            window.formkunShowAdminToast(msg, type);
                        }
                    })
                    .catch(function () {
                        if (typeof window.formkunShowAdminToast === 'function') {
                            window.formkunShowAdminToast('診断リクエストに失敗しました。', 'danger');
                        }
                    })
                    .finally(function () {
                        sending = false;
                        btn.disabled = false;
                    });
            });
        });
    })();

    (function initLineNotifyMessageTest01() {
        document.querySelectorAll('[data-module="c-lineNotifyMessageTest01"]').forEach(function (root) {
            var url = root.getAttribute('data-test-url') || '';
            if (url === '') {
                return;
            }
            var btn = root.querySelector('button.btn');
            if (!btn || btn.disabled) {
                return;
            }
            var csrfName = root.getAttribute('data-csrf-name') || '_token';
            var csrfInput = document.querySelector('input[name="' + csrfName + '"]');
            var templateInput = document.getElementById('line_message_template');
            var sending = false;
            btn.addEventListener('click', function () {
                if (sending) {
                    return;
                }
                sending = true;
                btn.disabled = true;
                var body = new FormData();
                if (csrfInput) {
                    body.append(csrfName, csrfInput.value);
                }
                if (templateInput) {
                    body.append('line_message_template', templateInput.value);
                }
                fetch(url, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { Accept: 'application/json' },
                    body: body,
                })
                    .then(function (response) {
                        return response.json().then(function (data) {
                            return { ok: response.ok, data: data };
                        });
                    })
                    .then(function (result) {
                        var msg =
                            result.data && result.data.message
                                ? String(result.data.message)
                                : result.ok
                                  ? 'テストメッセージを送信しました。'
                                  : 'テストメッセージを送信できませんでした。';
                        var type = result.ok && result.data && result.data.ok ? 'success' : 'danger';
                        if (typeof window.formkunShowAdminToast === 'function') {
                            window.formkunShowAdminToast(msg, type);
                        }
                        if (!result.ok || !result.data || !result.data.ok) {
                            throw new Error(msg);
                        }
                    })
                    .catch(function () {
                        /* toast already shown on failure */
                    })
                    .finally(function () {
                        sending = false;
                        btn.disabled = false;
                    });
            });
        });
    })();

    (function initLineAccountUnlink01() {
        document.querySelectorAll('[data-module="c-lineAccountUnlink01"]').forEach(function (root) {
            var url = root.getAttribute('data-reset-url') || '';
            if (url === '') {
                return;
            }
            var btn = root.querySelector('button.btn');
            if (!btn) {
                return;
            }
            var csrfName = root.getAttribute('data-csrf-name') || '_token';
            var csrfInput = document.querySelector('input[name="' + csrfName + '"]');
            btn.addEventListener('click', function () {
                if (
                    !window.confirm(
                        'アカウント連携の設定をすべて解除します。Channel secret・トークン・送信先 ID・チェックリスト・Webhook で記録した ID が消え、全フォームの LINE 通知がオフになります。よろしいですか？'
                    )
                ) {
                    return;
                }
                var form = document.createElement('form');
                form.method = 'post';
                form.action = url;
                form.style.display = 'none';
                if (csrfInput) {
                    var token = document.createElement('input');
                    token.type = 'hidden';
                    token.name = csrfName;
                    token.value = csrfInput.value;
                    form.appendChild(token);
                }
                document.body.appendChild(form);
                form.submit();
            });
        });
    })();

    (function initLineNotifyTab01() {
        var root = document.querySelector('[data-module="c-lineNotifyTab01"]');
        var checkbox = document.getElementById('line_notify_enabled');
        if (!root || !checkbox) {
            return;
        }
        var messageFields = root.querySelectorAll('[data-target="c-lineNotifyTab01__messageFields"]');
        var messageWait = root.querySelector('[data-target="c-lineNotifyTab01__messageWait"]');
        var checklistRoot = root.querySelector('[data-module="c-lineSetupChecklist01"]');
        var expectedCount = parseInt(root.getAttribute('data-checklist-item-count') || '0', 10);
        var accountLinkComplete = root.getAttribute('data-line-account-link-complete') === '1';

        function allChecklistDone() {
            if (accountLinkComplete) {
                return true;
            }
            if (!checklistRoot || expectedCount <= 0) {
                return false;
            }
            var items = checklistRoot.querySelectorAll('[data-item]');
            if (items.length !== expectedCount) {
                return false;
            }
            for (var i = 0; i < items.length; i++) {
                if (!items[i].classList.contains('is-done')) {
                    return false;
                }
            }
            return true;
        }

        function sync() {
            var enabled = checkbox.checked;
            root.hidden = !enabled;
            if (!enabled) {
                return;
            }
            var done = allChecklistDone();
            messageFields.forEach(function (el) {
                el.hidden = !done;
            });
            if (messageWait) {
                messageWait.hidden = done;
            }
        }

        checkbox.addEventListener('change', sync);
        if (checklistRoot && typeof MutationObserver !== 'undefined') {
            new MutationObserver(sync).observe(checklistRoot, {
                attributes: true,
                subtree: true,
                attributeFilter: ['class'],
            });
        }
        sync();
        window.formkunLineNotifyTabSync = sync;
    })();

    (function initLineNotifySettings01() {
        var tabRoot = document.querySelector('[data-module="c-lineNotifyTab01"]');
        var checkbox = document.getElementById('line_notify_enabled');
        var templateInput = document.getElementById('line_message_template');
        if (!tabRoot || !checkbox) {
            return;
        }
        var saveUrl = tabRoot.getAttribute('data-notify-settings-url') || '';
        if (saveUrl === '') {
            return;
        }
        var csrfName = tabRoot.getAttribute('data-csrf-name') || '_token';
        var csrfInput = document.querySelector('input[name="' + csrfName + '"]');
        var saveTimer = null;
        var saving = false;

        function messageFieldsVisible() {
            var messageWrap = tabRoot.querySelector('[data-target="c-lineNotifyTab01__messageFields"]');
            return messageWrap && !messageWrap.hidden;
        }

        function buildBody() {
            var body = new FormData();
            if (csrfInput) {
                body.append(csrfName, csrfInput.value);
            }
            if (checkbox.checked) {
                body.append('line_notify_enabled', '1');
            } else {
                body.append('line_notify_enabled', '0');
            }
            if (templateInput && messageFieldsVisible()) {
                body.append('line_message_template', templateInput.value);
            }
            return body;
        }

        function applyResponse(data) {
            if (!data || !data.ok) {
                return;
            }
            checkbox.checked = !!data.line_notify_enabled;
            if (typeof window.formkunLineNotifyTabSync === 'function') {
                window.formkunLineNotifyTabSync();
            }
        }

        function saveNow() {
            if (saving) {
                return;
            }
            saving = true;
            fetch(saveUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { Accept: 'application/json' },
                body: buildBody(),
            })
                .then(function (response) {
                    return response.json().then(function (data) {
                        return { ok: response.ok, data: data };
                    });
                })
                .then(function (result) {
                    if (result.ok && result.data && result.data.ok) {
                        applyResponse(result.data);
                        if (typeof window.formkunShowAdminToast === 'function') {
                            window.formkunShowAdminToast('LINE 通知の表示設定を保存しました', 'success');
                        }
                        return;
                    }
                    throw new Error((result.data && result.data.message) || 'save failed');
                })
                .catch(function (err) {
                    if (typeof window.formkunShowAdminToast === 'function') {
                        window.formkunShowAdminToast(
                            err && err.message ? String(err.message) : 'LINE 通知設定を保存できませんでした',
                            'danger'
                        );
                    }
                })
                .finally(function () {
                    saving = false;
                });
        }

        function scheduleSave() {
            if (saveTimer !== null) {
                clearTimeout(saveTimer);
            }
            saveTimer = setTimeout(function () {
                saveTimer = null;
                var messageWrap = tabRoot.querySelector('[data-target="c-lineNotifyTab01__messageFields"]');
                if (messageWrap && messageWrap.hidden) {
                    return;
                }
                saveNow();
            }, 600);
        }

        checkbox.addEventListener('change', function () {
            if (saveTimer !== null) {
                clearTimeout(saveTimer);
                saveTimer = null;
            }
            saveNow();
        });
        if (templateInput) {
            templateInput.addEventListener('input', scheduleSave);
        }
    })();

    (function initLineTalkSendSetupChecklistSync() {
        var setupRoot = document.querySelector('[data-module="c-lineTalkSendSetup01"]');
        if (!setupRoot) {
            return;
        }
        var syncUrl = setupRoot.getAttribute('data-sync-url') || '';
        var itemKey = setupRoot.getAttribute('data-checklist-item') || '';
        if (syncUrl === '' || itemKey === '') {
            return;
        }
        var checklistRoot = document.querySelector('[data-module="c-lineSetupChecklist01"]');
        var csrfName = checklistRoot ? checklistRoot.getAttribute('data-csrf-name') || '_token' : '_token';
        var csrfInput = document.querySelector('input[name="' + csrfName + '"]');

        function setChecklistDone(checked) {
            if (!checklistRoot) {
                return;
            }
            var row = checklistRoot.querySelector('.item[data-item="' + itemKey + '"]');
            if (!row) {
                return;
            }
            row.classList.toggle('is-done', checked);
            if (typeof window.formkunRefreshLineSetupChecklistLock === 'function') {
                window.formkunRefreshLineSetupChecklistLock(checklistRoot);
            }
        }

        function syncForPanel(panelId) {
            var panel = setupRoot.querySelector('[data-tab-panel="' + panelId + '"]');
            if (!panel) {
                return;
            }
            var hasId = panel.getAttribute('data-line-webhook-has-id') === '1';
            setChecklistDone(hasId);
            var body = new FormData();
            if (csrfInput) {
                body.append(csrfName, csrfInput.value);
            }
            body.append('panel', panelId);
            fetch(syncUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { Accept: 'application/json' },
                body: body,
            })
                .then(function (response) {
                    return response.json().then(function (data) {
                        return { ok: response.ok, data: data };
                    });
                })
                .then(function (result) {
                    if (!result.ok || !result.data || !result.data.ok) {
                        throw new Error('sync failed');
                    }
                    setChecklistDone(!!result.data.checked);
                })
                .catch(function () {
                    /* 表示は data-line-webhook-has-id に合わせたまま */
                });
        }

        document.addEventListener('formkun:form-edit-tab-activated', function (event) {
            if (!event.detail || event.detail.scope !== 'line-talk-setup') {
                return;
            }
            syncForPanel(event.detail.panelId || '');
        });
    })();

    (function initLineWebhookTargetDelete() {
        var setupRoot = document.querySelector('[data-module="c-lineTalkSendSetup01"]');
        if (!setupRoot) {
            return;
        }
        var deleteUrl = setupRoot.getAttribute('data-delete-url') || '';
        if (deleteUrl === '') {
            return;
        }
        var csrfName = setupRoot.getAttribute('data-csrf-name') || '_token';
        var csrfInput = document.querySelector('input[name="' + csrfName + '"]');
        setupRoot.addEventListener('click', function (event) {
            var btn = event.target && event.target.closest
                ? event.target.closest('[data-module="m-lineWebhookTargetDelete01"]')
                : null;
            if (!btn) {
                return;
            }
            var targetType = btn.getAttribute('data-line-target-type') || '';
            var targetId = btn.getAttribute('data-line-target-id') || '';
            if (targetType === '' || targetId === '') {
                return;
            }
            var body = new FormData();
            if (csrfInput) {
                body.append(csrfName, csrfInput.value);
            }
            body.append('target_type', targetType);
            body.append('target_id', targetId);
            btn.disabled = true;
            fetch(deleteUrl, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { Accept: 'application/json' },
                body: body,
            })
                .then(function (response) {
                    return response.json().then(function (data) {
                        return { ok: response.ok, data: data };
                    });
                })
                .then(function (result) {
                    if (result.ok && result.data && result.data.ok) {
                        window.location.reload();
                        return;
                    }
                    throw new Error('delete failed');
                })
                .catch(function () {
                    btn.disabled = false;
                    if (typeof window.formkunShowAdminToast === 'function') {
                        window.formkunShowAdminToast('ID を削除できませんでした', 'danger');
                    }
                });
        });
    })();

    (function initDetailsActionMenus() {
        var detailsActionMenuGlobalBound = false;
        var DETAILS_ACTION_MENU_SELECTOR = 'details.menu, details.c-tableActionMenu01';
        var DETAILS_ACTION_MENU_OPEN_QUERY = 'details.menu[open], details.c-tableActionMenu01[open]';
        var TABLE_ACTION_MENU_GAP_PX = 6;

        function closestDetailsActionMenu(target) {
            return target && target.closest ? target.closest(DETAILS_ACTION_MENU_SELECTOR) : null;
        }

        function isTableActionMenu(menu) {
            return menu && menu.classList && menu.classList.contains('c-tableActionMenu01');
        }

        function resetTableActionMenuPanel(menu) {
            if (!isTableActionMenu(menu)) {
                return;
            }
            var panel = menu.querySelector('.c-tableActionMenu01__menu');
            if (!panel) {
                syncTableActionMenuOpenCell(menu);
                return;
            }
            panel.style.position = '';
            panel.style.left = '';
            panel.style.right = '';
            panel.style.top = '';
            panel.style.minWidth = '';
            panel.style.zIndex = '';
            syncTableActionMenuOpenCell(menu);
        }

        function syncTableActionMenuOpenCell(menu) {
            if (!isTableActionMenu(menu)) {
                return;
            }
            var cell = menu.closest('td.is-actions');
            if (!cell) {
                return;
            }
            cell.classList.toggle('is-actionMenuOpen', menu.open);
        }

        function positionTableActionMenuPanel(menu) {
            if (!isTableActionMenu(menu) || !menu.open) {
                return;
            }
            var panel = menu.querySelector('.c-tableActionMenu01__menu');
            var summary = menu.querySelector('summary');
            if (!panel || !summary) {
                return;
            }
            var viewportMarginPx = 8;
            var rect = summary.getBoundingClientRect();
            panel.style.position = 'fixed';
            panel.style.left = rect.left + 'px';
            panel.style.right = 'auto';
            panel.style.minWidth = '160px';
            panel.style.zIndex = '200';
            panel.style.top = (rect.bottom + TABLE_ACTION_MENU_GAP_PX) + 'px';
            var panelRect = panel.getBoundingClientRect();
            if (panelRect.bottom > window.innerHeight && panelRect.height > 0) {
                var topAbove = rect.top - panelRect.height - TABLE_ACTION_MENU_GAP_PX;
                if (topAbove >= 0) {
                    panel.style.top = topAbove + 'px';
                    panelRect = panel.getBoundingClientRect();
                }
            }
            if (panelRect.right > window.innerWidth - viewportMarginPx) {
                var leftFromSummaryRight = rect.right - panelRect.width;
                panel.style.left = Math.max(viewportMarginPx, leftFromSummaryRight) + 'px';
                panelRect = panel.getBoundingClientRect();
                if (panelRect.right > window.innerWidth - viewportMarginPx) {
                    panel.style.left = (window.innerWidth - panelRect.width - viewportMarginPx) + 'px';
                }
            }
            panelRect = panel.getBoundingClientRect();
            if (panelRect.left < viewportMarginPx) {
                panel.style.left = viewportMarginPx + 'px';
            }
        }

        function closeOpenTableActionMenusOnScroll() {
            document.querySelectorAll('details.c-tableActionMenu01[open]').forEach(function (menu) {
                menu.open = false;
            });
        }

        function closeOtherDetailsActionMenus(exceptMenu) {
            document.querySelectorAll(DETAILS_ACTION_MENU_OPEN_QUERY).forEach(function (openMenu) {
                if (openMenu !== exceptMenu) {
                    openMenu.open = false;
                }
            });
        }

        function bindDetailsActionMenu(menu) {
            if (!menu || menu.getAttribute('data-details-action-menu-bound') === '1') {
                return;
            }
            if (!detailsActionMenuGlobalBound) {
                document.addEventListener('click', function (event) {
                    var currentMenu = closestDetailsActionMenu(event.target);
                    closeOtherDetailsActionMenus(currentMenu);
                });
                document.addEventListener('keydown', function (event) {
                    if (event.key !== 'Escape') {
                        return;
                    }
                    closeOtherDetailsActionMenus(null);
                });
                document.querySelectorAll('[data-module="m-tableScroll01"]').forEach(function (scrollRoot) {
                    scrollRoot.addEventListener('scroll', closeOpenTableActionMenusOnScroll, { passive: true });
                });
                window.addEventListener('resize', closeOpenTableActionMenusOnScroll, { passive: true });
                detailsActionMenuGlobalBound = true;
            }
            menu.addEventListener('click', function (event) {
                event.stopPropagation();
            });
            menu.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.stopPropagation();
                }
            });
            menu.addEventListener('toggle', function () {
                if (isTableActionMenu(menu)) {
                    if (menu.open) {
                        closeOtherDetailsActionMenus(menu);
                        positionTableActionMenuPanel(menu);
                        syncTableActionMenuOpenCell(menu);
                    } else {
                        resetTableActionMenuPanel(menu);
                    }
                    return;
                }
                if (!menu.open) {
                    return;
                }
                closeOtherDetailsActionMenus(menu);
            });
            menu.setAttribute('data-details-action-menu-bound', '1');
        }

        window.formkunBindDetailsActionMenu = bindDetailsActionMenu;

        document.querySelectorAll('details.c-tableActionMenu01').forEach(bindDetailsActionMenu);
        document.querySelectorAll('details.menu').forEach(bindDetailsActionMenu);
    })();

    window.formkunInitSubmissionBulkAction = function () {
        var forms = document.querySelectorAll('[data-module="m-submissionBulkAction01"]');
        if (!forms.length) return;

        forms.forEach(function (form) {
            if (!form.id) return;

            var actionSelect = form.querySelector('[data-target="m-submissionBulkAction01__action"]');
            var submitButton = form.querySelector('[data-target="m-submissionBulkAction01__submit"]');
            var countText = form.querySelector('[data-target="m-submissionBulkAction01__count"]');
            var toolbar = form.querySelector('[data-target="m-submissionBulkAction01__toolbar"]');
            var selectAll = document.querySelector(
                '[data-target="m-submissionBulkAction01__selectAll"][data-bulk-form="' + form.id + '"]'
            );
            var checkboxes = Array.prototype.slice.call(document.querySelectorAll(
                '[data-target="m-submissionBulkAction01__checkbox"][data-bulk-form="' + form.id + '"]'
            ));
            if (!actionSelect || !submitButton || !countText || !checkboxes.length) return;

            function selectedCount() {
                return checkboxes.filter(function (checkbox) {
                    return checkbox.checked;
                }).length;
            }

            var filenameInput = form.querySelector('[data-target="m-submissionBulkAction01__filename"]');
            var filenameWrap = filenameInput ? (filenameInput.closest('[data-module="m-input01"]') || filenameInput) : null;
            if (filenameInput) filenameInput.hidden = false;

            function syncSummary() {
                var count = selectedCount();
                countText.textContent = count + '件選択中';
                submitButton.disabled = count === 0 || !actionSelect.value;
                if (filenameWrap) {
                    filenameWrap.style.display = actionSelect.value === 'export_csv' ? '' : 'none';
                }
                if (toolbar) {
                    toolbar.hidden = count === 0;
                }
                if (!selectAll) return;
                selectAll.checked = count > 0 && count === checkboxes.length;
                selectAll.indeterminate = count > 0 && count < checkboxes.length;
            }

            if (selectAll) {
                selectAll.addEventListener('change', function () {
                    checkboxes.forEach(function (checkbox) {
                        checkbox.checked = selectAll.checked;
                    });
                    syncSummary();
                });
            }

            checkboxes.forEach(function (checkbox) {
                checkbox.addEventListener('change', syncSummary);
            });
            actionSelect.addEventListener('change', syncSummary);

            form.addEventListener('submit', function (event) {
                var action = actionSelect.value;
                var count = selectedCount();
                if (!action) {
                    event.preventDefault();
                    alert('一括操作を選択してください。');
                    return;
                }
                if (count === 0) {
                    event.preventDefault();
                    alert('送信を選択してください。');
                    return;
                }

                if (action === 'export_csv') {
                    form.action = form.getAttribute('data-export-action') || form.action;
                    return;
                }

                form.action = form.getAttribute('data-delete-action') || form.action;
                if (!confirm('選択した送信を削除しますか？')) {
                    event.preventDefault();
                }
            });

            syncSummary();
        });
    };
    window.formkunInitSubmissionBulkAction();

    (function initAutoSubmitOnChange() {
        var forms = document.querySelectorAll('form[data-auto-submit="change"]');
        if (!forms.length) return;

        forms.forEach(function (form) {
            var timer = null;
            form.addEventListener('change', function (event) {
                var input = event.target;
                if (!input || input.type !== 'date') return;
                // 年の入力途中（0002 など）で送信しないよう、空欄か 4 桁年の完全な日付だけを受け付ける。
                var value = input.value;
                if (value !== '' && !/^(19|20)\d{2}-\d{2}-\d{2}$/.test(value)) return;
                clearTimeout(timer);
                timer = setTimeout(function () {
                    form.submit();
                }, 0);
            });
        });
    })();

    (function initFormEditTabs() {
        var roots = document.querySelectorAll('[data-module="c-formEditTabs01"]');
        if (!roots.length) return;

        roots.forEach(function (root) {
            var scope = root.getAttribute('data-tab-scope') || 'main';
            function getTabs() {
                return root.querySelectorAll(
                    ':scope > .wrapper > .block.is-tabs > [data-target="c-formEditTabs01__tab"][role="tab"]'
                );
            }
            function getPanels() {
                return root.querySelectorAll(
                    ':scope > .wrapper > .block.is-contents > [data-target="c-formEditTabs01__contents"][role="tabpanel"]'
                );
            }
            var tabs = getTabs();
            var panels = getPanels();
            if (!tabs.length || !panels.length) return;
            var storageKey = 'formkun:active-tab:' + window.location.pathname + ':' + scope;

            function panelIds() {
                return Array.prototype.map.call(getPanels(), function (p) {
                    return p.getAttribute('data-tab-panel');
                });
            }

            function readStoredPanelId() {
                try {
                    var stored = window.sessionStorage.getItem(storageKey);
                    if (stored && panelIds().indexOf(stored) !== -1) {
                        return stored;
                    }
                } catch (e) {}
                return null;
            }

            function writeStoredPanelId(panelId) {
                try {
                    window.sessionStorage.setItem(storageKey, panelId);
                } catch (e) {}
            }

            function panelIdFromHash() {
                if (!window.location.hash) return null;
                var id = window.location.hash.slice(1);
                if (!id) return null;
                var target = document.getElementById(id);
                if (!target || !root.contains(target)) return null;
                var panel = target.closest('[data-target="c-formEditTabs01__contents"][role="tabpanel"]');
                return panel ? panel.getAttribute('data-tab-panel') : null;
            }

            function activate(panelId) {
                getTabs().forEach(function (tab) {
                    var pid = tab.getAttribute('data-tab-panel');
                    var sel = pid === panelId;
                    tab.setAttribute('aria-selected', sel ? 'true' : 'false');
                    tab.tabIndex = sel ? 0 : -1;
                });
                getPanels().forEach(function (p) {
                    p.hidden = p.getAttribute('data-tab-panel') !== panelId;
                });
                writeStoredPanelId(panelId);
                if ((scope === 'main' && panelId === 'screens') || (scope === 'screens' && panelId.indexOf('screen-input-') === 0)) {
                    window.setTimeout(function () {
                        if (typeof window.formkunInitFbSortable === 'function') {
                            window.formkunInitFbSortable();
                        }
                    }, 20);
                }
                document.dispatchEvent(new CustomEvent('formkun:form-edit-tab-activated', {
                    detail: {
                        scope: scope,
                        panelId: panelId
                    }
                }));
            }

            var isNested = root.classList.contains('is-nested');
            root.formkunActivateTab = activate;

            tabs.forEach(function (tab, index) {
                tab.addEventListener('click', function (event) {
                    if (event.target.closest && event.target.closest('[data-target="inputPageActionMenu"]')) {
                        return;
                    }
                    activate(tab.getAttribute('data-tab-panel'));
                });
                tab.addEventListener('keydown', function (event) {
                    if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        activate(tab.getAttribute('data-tab-panel'));
                        return;
                    }
                    var prevKey = isNested ? 'ArrowUp' : 'ArrowLeft';
                    var nextKey = isNested ? 'ArrowDown' : 'ArrowRight';
                    if (event.key !== prevKey && event.key !== nextKey) {
                        return;
                    }
                    event.preventDefault();
                    var dir = event.key === prevKey ? -1 : 1;
                    var nextIndex = (index + dir + tabs.length) % tabs.length;
                    var nextTab = tabs[nextIndex];
                    nextTab.focus();
                    activate(nextTab.getAttribute('data-tab-panel'));
                });
            });

            var initialPanelId = panelIdFromHash() || readStoredPanelId();
            if (!initialPanelId) {
                var selectedTab = Array.prototype.find.call(tabs, function (tab) {
                    return tab.getAttribute('aria-selected') === 'true';
                });
                initialPanelId = selectedTab
                    ? selectedTab.getAttribute('data-tab-panel')
                    : panels[0].getAttribute('data-tab-panel');
            }
            if (initialPanelId) {
                activate(initialPanelId);
            }
        });
    })();

    (function initFormEditPreview() {
        var form = document.getElementById('form-edit-main');
        var preview = document.querySelector('[data-module="c-previewBlock01"]');
        if (!form || !preview) return;

        var canvas = preview.querySelector('[data-target="p-formEdit01__previewCanvas"]');
        var status = preview.querySelector('[data-target="p-formEdit01__previewStatus"]');
        var refreshButton = document.querySelector('[data-target="p-formEdit01__previewRefresh"]');
        var urls = {
            input: preview.getAttribute('data-preview-input-url') || '',
            confirm: preview.getAttribute('data-preview-confirm-url') || '',
            thanks: preview.getAttribute('data-preview-thanks-url') || '',
            closed: preview.getAttribute('data-preview-closed-url') || ''
        };
        var timer = null;
        var requestNo = 0;
        var activeController = null;
        var hasRendered = false;
        var previewStorageKey = 'formkun:preview-open:' + window.location.pathname;

        function setStatus(text) {
            if (status) status.textContent = text;
        }

        function readPreviewOpen() {
            try {
                return window.sessionStorage.getItem(previewStorageKey) === '1';
            } catch (e) {
                return false;
            }
        }

        function writePreviewOpen(open) {
            try {
                window.sessionStorage.setItem(previewStorageKey, open ? '1' : '0');
            } catch (e) {}
        }

        function renderPreviewHtml(html) {
            if (!canvas) return;

            var doc = new DOMParser().parseFromString(html, 'text/html');
            var main = doc.querySelector('main');
            var customCssText = extractPreviewCustomCss(doc);
            var previewMain = document.createElement('main');
            previewMain.className = main ? main.className : 'container';
            previewMain.setAttribute('data-preview-custom-css-scope', '1');
            previewMain.innerHTML = main ? main.innerHTML : html;
            injectPreviewCustomCss(previewMain, customCssText);

            canvas.replaceChildren(previewMain);
            if (window.FormKunPublicForm && typeof window.FormKunPublicForm.init === 'function') {
                window.FormKunPublicForm.init(previewMain);
            }
            canvas.querySelectorAll('form').forEach(function (previewForm) {
                previewForm.addEventListener('submit', function (event) {
                    event.preventDefault();
                    setStatus('入力確認用');
                });
            });
        }

        function extractPreviewCustomCss(doc) {
            if (!doc) {
                return '';
            }
            var styles = doc.querySelectorAll('style[data-form-custom-css]');
            if (!styles.length) {
                return '';
            }
            return Array.prototype.map.call(styles, function (styleNode) {
                return styleNode && typeof styleNode.textContent === 'string' ? styleNode.textContent : '';
            }).join('\n');
        }

        function injectPreviewCustomCss(previewMain, cssText) {
            if (!previewMain) {
                return;
            }
            previewMain.querySelectorAll('style[data-preview-custom-css]').forEach(function (styleNode) {
                styleNode.remove();
            });
            if (typeof cssText !== 'string' || cssText.trim() === '') {
                return;
            }
            var style = document.createElement('style');
            style.setAttribute('data-preview-custom-css', '1');
            style.textContent = scopePreviewCustomCss(cssText, '[data-preview-custom-css-scope]');
            previewMain.prepend(style);
        }

        function scopePreviewCustomCss(cssText, scopeSelector) {
            if (typeof cssText !== 'string' || cssText.trim() === '') {
                return '';
            }
            if (typeof document === 'undefined' || !document.implementation) {
                return cssText;
            }
            var cssDocument = document.implementation.createHTMLDocument('');
            var style = cssDocument.createElement('style');
            style.textContent = cssText;
            cssDocument.head.appendChild(style);
            if (!style.sheet || !style.sheet.cssRules) {
                return cssText;
            }
            return scopePreviewCssRules(style.sheet.cssRules, scopeSelector);
        }

        function scopePreviewCssRules(rules, scopeSelector) {
            return Array.prototype.map.call(rules, function (rule) {
                if (!rule) {
                    return '';
                }
                if (rule.type === window.CSSRule.STYLE_RULE) {
                    return scopePreviewStyleRule(rule, scopeSelector);
                }
                if (rule.type === window.CSSRule.MEDIA_RULE) {
                    return '@media ' + rule.conditionText + ' {' + scopePreviewCssRules(rule.cssRules, scopeSelector) + '}';
                }
                if (rule.type === window.CSSRule.SUPPORTS_RULE) {
                    return '@supports ' + rule.conditionText + ' {' + scopePreviewCssRules(rule.cssRules, scopeSelector) + '}';
                }
                return rule.cssText || '';
            }).join('\n');
        }

        function scopePreviewStyleRule(rule, scopeSelector) {
            var selectorText = rule.selectorText || '';
            if (selectorText === '') {
                return rule.cssText || '';
            }
            var selectors = splitPreviewSelectorList(selectorText);
            var scopedSelectors = selectors.map(function (selector) {
                return scopePreviewSelector(selector, scopeSelector);
            }).filter(Boolean);
            if (!scopedSelectors.length) {
                return '';
            }
            return scopedSelectors.join(', ') + ' {' + rule.style.cssText + '}';
        }

        function splitPreviewSelectorList(selectorText) {
            var selectors = [];
            var token = '';
            var roundDepth = 0;
            var squareDepth = 0;
            var quote = '';

            for (var i = 0; i < selectorText.length; i += 1) {
                var char = selectorText.charAt(i);
                if (quote) {
                    token += char;
                    if (char === quote && selectorText.charAt(i - 1) !== '\\') {
                        quote = '';
                    }
                    continue;
                }
                if (char === '"' || char === "'") {
                    quote = char;
                    token += char;
                    continue;
                }
                if (char === '(') {
                    roundDepth += 1;
                    token += char;
                    continue;
                }
                if (char === ')') {
                    roundDepth = Math.max(0, roundDepth - 1);
                    token += char;
                    continue;
                }
                if (char === '[') {
                    squareDepth += 1;
                    token += char;
                    continue;
                }
                if (char === ']') {
                    squareDepth = Math.max(0, squareDepth - 1);
                    token += char;
                    continue;
                }
                if (char === ',' && roundDepth === 0 && squareDepth === 0) {
                    if (token.trim() !== '') {
                        selectors.push(token.trim());
                    }
                    token = '';
                    continue;
                }
                token += char;
            }

            if (token.trim() !== '') {
                selectors.push(token.trim());
            }

            return selectors;
        }

        function scopePreviewSelector(selector, scopeSelector) {
            if (typeof selector !== 'string') {
                return '';
            }
            var scopedSelector = selector.trim();
            while (/^(?:html|body|:root)(?=[\s.#:[>+~]|$)/i.test(scopedSelector)) {
                scopedSelector = scopedSelector.replace(/^(?:html|body|:root)(?=[\s.#:[>+~]|$)/i, '').trim();
            }
            if (scopedSelector === '') {
                return scopeSelector;
            }
            if (/^[>+~]/.test(scopedSelector)) {
                return scopeSelector + scopedSelector;
            }
            return scopeSelector + ' ' + scopedSelector;
        }

        function isPreviewOpen() {
            return !preview.hidden;
        }

        function setPreviewOpen(open) {
            preview.hidden = !open;
            writePreviewOpen(open);
            if (refreshButton) {
                refreshButton.setAttribute('aria-expanded', open ? 'true' : 'false');
                refreshButton.textContent = open ? 'プレビューを閉じる' : 'プレビュー';
            }
            if (open && !hasRendered) {
                queuePreview(0);
            }
            if (!open) {
                window.clearTimeout(timer);
                if (activeController) {
                    activeController.abort();
                    activeController = null;
                }
            }
        }

        function getSelectedPanel(scope) {
            var root = document.querySelector('[data-module="c-formEditTabs01"][data-tab-scope="' + scope + '"]');
            if (!root) return '';
            var tab = root.querySelector('[data-target="c-formEditTabs01__tab"][role="tab"][aria-selected="true"]');
            return tab ? (tab.getAttribute('data-tab-panel') || '') : '';
        }

        function getPreviewTarget() {
            var screenPanel = getSelectedPanel('screens');
            if (screenPanel === 'screen-confirm') {
                return { url: urls.confirm, pageKey: '' };
            }
            if (screenPanel === 'screen-thanks') {
                return { url: urls.thanks, pageKey: '' };
            }
            if (screenPanel === 'screen-closed') {
                return { url: urls.closed, pageKey: '' };
            }
            var inputPanel = document.querySelector('[data-tab-panel="' + screenPanel + '"]');
            var pageKeyInput = inputPanel ? inputPanel.querySelector('[data-input-page-name="page_key"]') : null;
            return {
                url: urls.input,
                pageKey: pageKeyInput ? pageKeyInput.value.trim() : ''
            };
        }

        function renderPreview() {
            if (!isPreviewOpen()) return;
            var target = getPreviewTarget();
            if (!target.url || !canvas) return;

            requestNo += 1;
            var currentRequest = requestNo;
            if (activeController) {
                activeController.abort();
            }
            activeController = typeof AbortController !== 'undefined' ? new AbortController() : null;

            var data = buildPreviewFormData(form);
            if (target.pageKey !== '') {
                data.set('preview_input_page_key', target.pageKey);
            }
            setStatus('更新中...');

            fetch(target.url, {
                method: 'POST',
                body: data,
                credentials: 'same-origin',
                signal: activeController ? activeController.signal : undefined
            }).then(function (response) {
                if (!response.ok) {
                    throw new Error('HTTP ' + response.status);
                }
                return response.text();
            }).then(function (html) {
                if (currentRequest !== requestNo) return;
                renderPreviewHtml(html);
                hasRendered = true;
                setStatus('更新済み');
            }).catch(function (error) {
                if (error && error.name === 'AbortError') return;
                if (currentRequest !== requestNo) return;
                setStatus('更新失敗');
            });
        }

        function queuePreview(delay) {
            if (!isPreviewOpen()) return;
            window.clearTimeout(timer);
            timer = window.setTimeout(renderPreview, typeof delay === 'number' ? delay : 450);
        }

        form.addEventListener('input', function () {
            queuePreview();
        });
        form.addEventListener('change', function () {
            queuePreview(120);
        });
        form.addEventListener('click', function (event) {
            var target = event.target.closest ? event.target.closest(
                '[data-target="m-formBuilder01__add"], [data-target="c-formEditor__remove"], [data-target="c-formEditorGroup__remove"], [data-target="fb-description-remove"], [data-target="c-formEditor__choiceAdd"], [data-target="c-formEditor__textMultiAdd"], [data-target="inputPageDuplicate"], [data-target="inputPageDelete"], [data-target="inputPageAdd"]'
            ) : null;
            if (target) {
                queuePreview(180);
            }
        });
        document.addEventListener('formkun:form-edit-tab-activated', function (event) {
            if (event.detail && event.detail.scope === 'screens') {
                queuePreview(80);
            }
        });
        document.addEventListener('formkun:fields-changed', function () {
            queuePreview(180);
        });
        document.addEventListener('formkun:input-pages-changed', function () {
            queuePreview(180);
        });
        if (refreshButton) {
            refreshButton.addEventListener('click', function () {
                setPreviewOpen(!isPreviewOpen());
            });
        }
        if (readPreviewOpen()) {
            setPreviewOpen(true);
        }
    })();

    var FB_REGEX_CUSTOM = '__custom__';
    var FB_REGEX_CHECKBOX_LIMIT = '__checkbox_limit__';

    function generateUuidV4() {
        var bytes = new Uint8Array(16);
        if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
            crypto.getRandomValues(bytes);
        } else {
            for (var i = 0; i < 16; i++) {
                bytes[i] = Math.floor(Math.random() * 256);
            }
        }
        bytes[6] = (bytes[6] & 0x0f) | 0x40;
        bytes[8] = (bytes[8] & 0x3f) | 0x80;
        var h = '';
        for (var j = 0; j < 16; j++) {
            h += ('0' + bytes[j].toString(16)).slice(-2);
        }
        return (
            h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' +
            h.slice(16, 20) + '-' + h.slice(20, 32)
        );
    }

    (function initUpdateUpload() {
        document.querySelectorAll('[data-module="c-updateUpload01"]').forEach(function (module) {
            var zone = module.querySelector('[data-target="c-updateUpload01__zone"]');
            var input = module.querySelector('[data-target="c-updateUpload01__input"]');
            var filenameEl = module.querySelector('[data-target="c-updateUpload01__filename"]');
            if (!zone || !input) return;

            function setFile(file) {
                if (!file) return;
                try {
                    var dt = new DataTransfer();
                    dt.items.add(file);
                    input.files = dt.files;
                } catch (e) {
                    return;
                }
                zone.classList.add('has-file');
                if (filenameEl) {
                    filenameEl.textContent = file.name;
                    filenameEl.hidden = false;
                }
            }

            zone.addEventListener('click', function () {
                input.click();
            });

            zone.addEventListener('keydown', function (event) {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    input.click();
                }
            });

            input.addEventListener('change', function () {
                if (input.files && input.files[0]) {
                    setFile(input.files[0]);
                }
            });

            ['dragenter', 'dragover'].forEach(function (type) {
                zone.addEventListener(type, function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    zone.classList.add('is-dragover');
                });
            });

            ['dragleave', 'drop'].forEach(function (type) {
                zone.addEventListener(type, function (event) {
                    event.preventDefault();
                    event.stopPropagation();
                    zone.classList.remove('is-dragover');
                });
            });

            zone.addEventListener('drop', function (event) {
                var files = event.dataTransfer && event.dataTransfer.files;
                if (!files || !files.length) return;
                var file = files[0];
                if (!/\.zip$/i.test(file.name)) {
                    alert('ZIP ファイル（.zip）のみアップロードできます。');
                    return;
                }
                setFile(file);
            });

            var form = module.tagName === 'FORM' ? module : module.closest('form');
            if (!form) return;
            var maxBytes = parseInt(
                module.getAttribute('data-max-bytes') || form.getAttribute('data-max-bytes') || '0',
                10
            );
            form.addEventListener('submit', function (event) {
                var file = input.files && input.files[0];
                if (file && maxBytes > 0 && file.size > maxBytes) {
                    event.preventDefault();
                    alert('ZIP のサイズが上限（' + formatUploadMaxBytes(maxBytes) + '）を超えています。');
                    return;
                }
                var confirmMessage = form.getAttribute('data-confirm-message') || 'ZIP の内容でアプリを更新します。よろしいですか？';
                if (!confirm(confirmMessage)) {
                    event.preventDefault();
                }
            });
        });

        function formatUploadMaxBytes(bytes) {
            if (bytes >= 1073741824) {
                return (bytes / 1073741824).toFixed(bytes % 1073741824 === 0 ? 0 : 1) + 'G';
            }
            if (bytes >= 1048576) {
                return (bytes / 1048576).toFixed(bytes % 1048576 === 0 ? 0 : 1) + 'M';
            }
            if (bytes >= 1024) {
                return (bytes / 1024).toFixed(bytes % 1024 === 0 ? 0 : 1) + 'K';
            }
            return String(bytes) + 'B';
        }
    })();

    (function initRetentionPurgeConfirm() {
        var holder = document.querySelector('[data-retention-confirm]');
        var form = holder ? holder.closest('form') : null;
        var previewUrl = holder ? holder.getAttribute('data-retention-preview-url') : '';
        if (!holder || !form || !previewUrl) return;

        var initial;
        try {
            initial = JSON.parse(holder.getAttribute('data-retention-initial') || '{}');
        } catch (e) {
            return;
        }
        var confirmed = false;
        var pending = false;

        function currentSettings() {
            var enabledEl = form.querySelector('input[name="submission_retention_enabled"]:checked');
            var actionEl = form.querySelector('input[name="submission_retention_action"]:checked');
            var daysEl = form.querySelector('input[name="submission_retention_days"]');
            return {
                enabled: enabledEl ? enabledEl.value : '1',
                days: daysEl ? String(daysEl.value).trim() : '',
                action: actionEl ? actionEl.value : 'warn'
            };
        }

        form.addEventListener('submit', function (event) {
            if (confirmed) {
                confirmed = false;
                return;
            }
            var now = currentSettings();
            var changed = now.enabled !== String(initial.enabled)
                || now.days !== String(initial.days)
                || now.action !== String(initial.action);
            if (!changed || now.enabled === '0' || now.action !== 'delete' || !/^[0-9]{1,4}$/.test(now.days)) return;

            event.preventDefault();
            event.stopImmediatePropagation();
            if (pending) return;
            pending = true;
            var submitter = event.submitter || null;
            var url = previewUrl + (previewUrl.indexOf('?') === -1 ? '?' : '&')
                + 'enabled=' + encodeURIComponent(now.enabled)
                + '&days=' + encodeURIComponent(now.days)
                + '&action=' + encodeURIComponent(now.action);

            function proceed() {
                confirmed = true;
                if (typeof form.requestSubmit === 'function') {
                    form.requestSubmit(submitter && submitter.form === form ? submitter : undefined);
                } else {
                    form.submit();
                }
            }

            fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } })
                .then(function (res) {
                    if (!res.ok) throw new Error('status ' + res.status);
                    return res.json();
                })
                .then(function (data) {
                    pending = false;
                    var count = parseInt(data && data.count, 10) || 0;
                    if (count <= 0 || confirm('保存すると ' + count.toLocaleString() + ' 件の受信履歴と添付ファイルが削除され、元に戻せません。保存しますか？')) {
                        proceed();
                    }
                })
                .catch(function () {
                    pending = false;
                    if (confirm('削除される受信履歴の件数を確認できませんでした。保存しますか？')) {
                        proceed();
                    }
                });
        }, true);
    })();

    (function initRetentionEnabledToggle() {
        var radios = document.querySelectorAll('input[name="submission_retention_enabled"]');
        var details = document.querySelectorAll('[data-retention-detail]');
        var daysInput = document.getElementById('submission_retention_days');
        if (!radios.length || !details.length) return;

        function sync() {
            var checked = document.querySelector('input[name="submission_retention_enabled"]:checked');
            var enabled = !checked || checked.value !== '0';
            Array.prototype.forEach.call(details, function (detail) {
                detail.hidden = !enabled;
            });
            if (daysInput) daysInput.required = enabled;
        }

        Array.prototype.forEach.call(radios, function (radio) {
            radio.addEventListener('change', sync);
        });
        sync();
    })();

    (function initEmbedCaptcha01() {
        document.querySelectorAll('[data-module="c-embedCaptcha01"]').forEach(function (root) {
            var select = root.querySelector('[data-target="c-embedCaptcha01__provider"]');
            var panels = root.querySelectorAll('[data-captcha-panel]');
            if (!select || !panels.length) return;

            function syncEmbedCodeHeadTab() {
                var embedTabsRoot = root.querySelector('[data-tab-scope="embed-code"]');
                if (!embedTabsRoot) {
                    return;
                }
                var headTab = embedTabsRoot.querySelector('[data-tab-panel="embed-code-head"][role="tab"]');
                var headPanel = embedTabsRoot.querySelector('[data-tab-panel="embed-code-head"][role="tabpanel"]');
                var useHead = select.value !== 'none';
                if (headTab) {
                    headTab.hidden = !useHead;
                }
                if (!useHead && headPanel && !headPanel.hidden) {
                    var htmlTab = embedTabsRoot.querySelector('[data-tab-panel="embed-code-html"][role="tab"]');
                    if (htmlTab) {
                        htmlTab.click();
                    }
                }
            }

            function sync() {
                Array.prototype.forEach.call(panels, function (panel) {
                    panel.hidden = panel.getAttribute('data-captcha-panel') !== select.value;
                });
                syncEmbedCodeHeadTab();
            }

            select.addEventListener('change', sync);
            sync();
        });
    })();

    (function initEmbedJapanOnly01() {
        document.querySelectorAll('[data-module="c-embedCaptcha01"]').forEach(function (root) {
            var select = root.querySelector('[data-target="c-embedCaptcha01__japanProvider"]');
            var panels = root.querySelectorAll('[data-japan-panel]');
            if (!select || !panels.length) return;

            function sync() {
                Array.prototype.forEach.call(panels, function (panel) {
                    panel.hidden = panel.getAttribute('data-japan-panel') !== select.value;
                });
            }

            select.addEventListener('change', sync);
            sync();
        });
    })();

    (function initInputList01() {
        document.querySelectorAll('[data-module="m-inputList01"]').forEach(function (root) {
            var rows = root.querySelector('[data-target="m-inputList01__rows"]');
            var template = root.querySelector('[data-target="m-inputList01__template"]');
            var addBtn = root.querySelector('[data-target="m-inputList01__add"]');
            if (!rows || !template || !addBtn) return;
            var max = parseInt(root.getAttribute('data-max') || '0', 10);

            function rowCount() {
                return rows.querySelectorAll('[data-target="m-inputList01__row"]').length;
            }

            function syncAdd() {
                addBtn.disabled = max > 0 && rowCount() >= max;
            }

            addBtn.addEventListener('click', function () {
                if (max > 0 && rowCount() >= max) return;
                rows.appendChild(template.content.cloneNode(true));
                var inputs = rows.querySelectorAll('[data-target="m-inputList01__row"] input');
                if (inputs.length) inputs[inputs.length - 1].focus();
                syncAdd();
            });

            rows.addEventListener('click', function (e) {
                var btn = e.target.closest('[data-target="m-inputList01__remove"]');
                if (!btn) return;
                var row = btn.closest('[data-target="m-inputList01__row"]');
                if (!row) return;
                row.remove();
                syncAdd();
            });

            syncAdd();
        });
    })();

    (function initEmbedEnabled01() {
        document.querySelectorAll('[data-module="c-embedCaptcha01"]').forEach(function (root) {
            var state = root.querySelector('[data-target="c-embedEnabled01__state"]');
            var enableWrap = root.querySelector('[data-target="c-embedEnabled01__enableWrap"]');
            var enableBtn = root.querySelector('[data-target="c-embedEnabled01__enable"]');
            var disconnectBtn = root.querySelector('[data-target="c-embedEnabled01__disconnect"]');
            var panel = root.querySelector('[data-target="c-embedEnabled01__panel"]');
            var status = document.getElementById('status');
            var hide = root.querySelector('input[name="embed_public_page_hidden"][value="1"]');
            if (!state || !panel || !enableWrap) return;

            function syncUi() {
                var on = state.checked;
                panel.hidden = !on;
                enableWrap.hidden = on;
            }

            if (enableBtn) {
                enableBtn.addEventListener('click', function () {
                    var wasOff = !state.checked;
                    state.checked = true;
                    if (wasOff) {
                        if (hide) {
                            hide.checked = true;
                        }
                        if (status) {
                            status.value = 'hidden';
                        }
                    }
                    syncUi();
                });
            }

            if (disconnectBtn) {
                disconnectBtn.addEventListener('click', function () {
                    if (!confirm('外部埋め込みの連携を解除します。保存するまで設定はデータベースに反映されません。よろしいですか？')) {
                        return;
                    }
                    state.checked = false;
                    if (status && status.value === 'hidden') {
                        status.value = 'draft';
                    }
                    if (hide) {
                        hide.checked = false;
                    }
                    syncUi();
                });
            }

            syncUi();
        });
    })();

    (function initFormHiddenStatusSync() {
        var status = document.getElementById('status');
        var hide = document.querySelector('input[name="embed_public_page_hidden"][value="1"]');
        if (!status || !hide) return;

        status.addEventListener('change', function () {
            hide.checked = status.value === 'hidden';
        });
        hide.addEventListener('change', function () {
            if (hide.checked) {
                status.value = 'hidden';
            } else if (status.value === 'hidden') {
                status.value = 'draft';
            }
        });
    })();

    (function initRetentionActionNotes() {
        var radios = document.querySelectorAll('input[name="submission_retention_action"]');
        var notes = document.querySelectorAll('[data-retention-note]');
        if (!radios.length || !notes.length) return;

        function sync() {
            var checked = document.querySelector('input[name="submission_retention_action"]:checked');
            var value = checked ? checked.value : '';
            Array.prototype.forEach.call(notes, function (note) {
                note.hidden = note.getAttribute('data-retention-note') !== value;
            });
        }

        Array.prototype.forEach.call(radios, function (radio) {
            radio.addEventListener('change', sync);
        });
        sync();
    })();

    (function initSubmissionPurgeScheduleForm() {
        var form = document.querySelector('[data-purge-schedule-form]');
        if (!form) return;

        var enabledCheckbox = form.querySelector('#submission_purge_schedule_enabled');
        var detail = form.querySelector('[data-purge-schedule-detail]');
        var modeRadios = form.querySelectorAll('input[name="submission_purge_schedule_mode"]');
        var dailyBlock = form.querySelector('[data-purge-schedule-daily]');
        var intervalBlock = form.querySelector('[data-purge-schedule-interval]');

        function syncEnabled() {
            if (!detail || !enabledCheckbox) return;
            detail.hidden = !enabledCheckbox.checked;
        }

        function syncMode() {
            var mode = 'daily';
            Array.prototype.forEach.call(modeRadios, function (radio) {
                if (radio.checked) mode = radio.value;
            });
            if (dailyBlock) dailyBlock.hidden = mode !== 'daily';
            if (intervalBlock) intervalBlock.hidden = mode !== 'interval';
        }

        if (enabledCheckbox) {
            enabledCheckbox.addEventListener('change', syncEnabled);
        }
        Array.prototype.forEach.call(modeRadios, function (radio) {
            radio.addEventListener('change', syncMode);
        });
        syncEnabled();
        syncMode();
    })();

    (function initVersionPeriodicDetailForm() {
        var form = document.querySelector('[data-version-periodic-form]');
        if (!form) return;

        var enabledCheckbox = form.querySelector('#form_version_periodic_save_enabled');
        var detail = form.querySelector('[data-version-periodic-detail]');

        function syncEnabled() {
            if (!detail || !enabledCheckbox) return;
            detail.hidden = !enabledCheckbox.checked;
        }

        if (enabledCheckbox) {
            enabledCheckbox.addEventListener('change', syncEnabled);
        }
        syncEnabled();
    })();

    function initSettingsLimitModal(openTarget, closeTargetPrefix, inputId, bodyClass) {
        var modals = document.querySelectorAll('[data-module="c-modal01"]');
        var openBtn = document.querySelector('[data-target="' + openTarget + '"]');
        if (!modals.length || !openBtn) return;

        var modal = null;
        modals.forEach(function (candidate) {
            if (candidate.querySelector('[data-target="' + closeTargetPrefix + '-close"]')) {
                modal = candidate;
            }
        });
        if (!modal) return;

        function openModal() {
            modal.hidden = false;
            document.body.classList.add(bodyClass);
            if (inputId) {
                var input = modal.querySelector('#' + inputId);
                if (input) {
                    input.focus();
                    if (typeof input.select === 'function') {
                        input.select();
                    }
                }
            }
        }

        function closeModal() {
            modal.hidden = true;
            document.body.classList.remove(bodyClass);
            openBtn.focus();
        }

        openBtn.addEventListener('click', function () {
            if (openBtn.disabled) {
                return;
            }
            openModal();
        });

        modal.querySelectorAll('[data-target="' + closeTargetPrefix + '-close"]').forEach(function (el) {
            el.addEventListener('click', function () {
                closeModal();
            });
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !modal.hidden) {
                closeModal();
            }
        });
    }

    function createHalfModalScrollLock(bodyClass) {
        var scrollY = 0;

        return {
            lock: function () {
                scrollY = window.scrollY || window.pageYOffset || 0;
                document.body.classList.add(bodyClass);
                document.body.style.position = 'fixed';
                document.body.style.top = '-' + scrollY + 'px';
                document.body.style.left = '0';
                document.body.style.right = '0';
                document.body.style.width = '100%';
            },
            unlock: function () {
                document.body.classList.remove(bodyClass);
                document.body.style.position = '';
                document.body.style.top = '';
                document.body.style.left = '';
                document.body.style.right = '';
                document.body.style.width = '';
                window.scrollTo(0, scrollY);
            },
        };
    }

    function initSubmissionSearchHalfModal() {
        var modal = null;
        document.querySelectorAll('[data-module="c-halfModal01"]').forEach(function (candidate) {
            if (candidate.querySelector('[data-target="submissions-search-close"]')) {
                modal = candidate;
            }
        });
        if (!modal) return;

        var bodyClass = 'is-submissions-search-modal-open';
        var lastOpenTrigger = null;
        var scrollLock = createHalfModalScrollLock(bodyClass);

        function openModal(trigger) {
            lastOpenTrigger = trigger || null;
            modal.hidden = false;
            scrollLock.lock();
            var input = modal.querySelector('#submissions-search-q');
            if (input) {
                input.focus();
                if (typeof input.select === 'function') {
                    input.select();
                }
            }
        }

        function closeModal() {
            modal.hidden = true;
            scrollLock.unlock();
            if (lastOpenTrigger && typeof lastOpenTrigger.focus === 'function') {
                lastOpenTrigger.focus();
            }
        }

        document.addEventListener('click', function (event) {
            var openTrigger = event.target.closest('[data-target="submissions-search-open"]');
            if (!openTrigger) return;
            event.preventDefault();
            openModal(openTrigger);
        });

        modal.querySelectorAll('[data-target="submissions-search-close"]').forEach(function (el) {
            el.addEventListener('click', function () {
                closeModal();
            });
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !modal.hidden) {
                closeModal();
            }
        });
    }

    (function initSubmissionSearchFormAutoSubmit() {
        var form = document.getElementById('submissions-search-form');
        if (!form) return;

        var keywordInput = form.querySelector('#submissions-search-q');
        var statusSelect = form.querySelector('#submissions-search-status');
        var datePattern = /^(19|20)\d{2}-\d{2}-\d{2}$/;
        var keywordTimer = null;
        var fetchController = null;

        function isValidDateValue(input) {
            if (!input || input.type !== 'date') return false;
            var value = input.value;
            return value === '' || datePattern.test(value);
        }

        function buildSubmissionSearchUrl() {
            var params = new URLSearchParams();
            var data = new FormData(form);
            ['q', 'from', 'to', 'status'].forEach(function (name) {
                var value = (data.get(name) || '').toString().trim();
                if (value !== '') {
                    params.set(name, value);
                }
            });
            var perPageSelect = document.getElementById('submissions-list-per-page');
            if (perPageSelect && perPageSelect.value) {
                params.set('per_page', perPageSelect.value);
            }
            var query = params.toString();
            return query ? form.action + '?' + query : form.action;
        }

        function bindSubmissionsListPerPageSelect() {
            var perPageSelect = document.getElementById('submissions-list-per-page');
            if (!perPageSelect || perPageSelect.dataset.perPageBound === '1') {
                return;
            }
            perPageSelect.dataset.perPageBound = '1';
            perPageSelect.addEventListener('change', function () {
                refreshSubmissionListLiveRegion();
            });
        }

        function syncSubmissionSearchModalReset() {
            var resetLink = form.querySelector('.c-halfModal01__actions.is-centered a.btn');
            if (!resetLink) return;
            var data = new FormData(form);
            var hasFilter = ['q', 'from', 'to', 'status'].some(function (name) {
                return (data.get(name) || '').toString().trim() !== '';
            });
            if (hasFilter) {
                resetLink.removeAttribute('aria-disabled');
                resetLink.removeAttribute('tabindex');
            } else {
                resetLink.setAttribute('aria-disabled', 'true');
                resetLink.setAttribute('tabindex', '-1');
            }
        }

        function refreshSubmissionListLiveRegion() {
            var url = buildSubmissionSearchUrl();
            if (fetchController) {
                fetchController.abort();
            }
            fetchController = new AbortController();

            fetch(url, {
                credentials: 'same-origin',
                headers: { Accept: 'text/html' },
                signal: fetchController.signal,
            })
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('submission search fetch failed');
                    }
                    return response.text();
                })
                .then(function (html) {
                    var doc = new DOMParser().parseFromString(html, 'text/html');
                    var nextRegion = doc.querySelector('[data-target="submissionsListLive01"]');
                    var currentRegion = document.querySelector('[data-target="submissionsListLive01"]');
                    if (!nextRegion || !currentRegion) {
                        throw new Error('submissionsListLive01 missing');
                    }
                    currentRegion.replaceWith(document.importNode(nextRegion, true));
                    history.replaceState(null, '', url);
                    syncSubmissionSearchModalReset();
                    if (typeof window.formkunInitSubmissionBulkAction === 'function') {
                        window.formkunInitSubmissionBulkAction();
                    }
                    if (typeof window.formkunBindDetailsActionMenu === 'function') {
                        document.querySelectorAll('details.c-tableActionMenu01').forEach(window.formkunBindDetailsActionMenu);
                    }
                    if (typeof window.formkunReenhanceAdminPickers === 'function') {
                        var liveRegion = document.querySelector('[data-target="submissionsListLive01"]');
                        window.formkunReenhanceAdminPickers(liveRegion || document);
                    }
                    bindSubmissionsListPerPageSelect();
                })
                .catch(function (error) {
                    if (error && error.name === 'AbortError') {
                        return;
                    }
                    form.submit();
                });
        }

        if (keywordInput) {
            keywordInput.addEventListener('input', function () {
                clearTimeout(keywordTimer);
                keywordTimer = setTimeout(refreshSubmissionListLiveRegion, 400);
            });
        }

        if (statusSelect) {
            statusSelect.addEventListener('change', refreshSubmissionListLiveRegion);
        }

        form.addEventListener('change', function (event) {
            var input = event.target;
            if (!input || input.type !== 'date') return;
            if (!isValidDateValue(input)) return;
            clearTimeout(keywordTimer);
            setTimeout(refreshSubmissionListLiveRegion, 0);
        });

        bindSubmissionsListPerPageSelect();
    })();

    window.formkunInitSubmissionsExportSelect = function () {
        var openBtn = document.querySelector('[data-target="submissions-export-open"]');
        var selectAll = document.querySelector('[data-target="submissionsExportSelect01__selectAll"]');
        var checkboxes = Array.prototype.slice.call(
            document.querySelectorAll('[data-target="submissionsExportSelect01__checkbox"]')
        );
        var modalCount = document.querySelector('[data-target="submissionsExportSelect01__modalCount"]');
        if (!openBtn) {
            return;
        }

        function selectedCount() {
            return checkboxes.filter(function (checkbox) {
                return checkbox.checked;
            }).length;
        }

        function syncExportSelection() {
            var count = selectedCount();
            if (modalCount) {
                modalCount.textContent = String(count);
            }
            var hiddenPerPage = document.querySelector('#submissions-export-modal-form input[name="per_page"]');
            var perPageSelect = document.getElementById('submissions-export-per-page');
            if (hiddenPerPage && perPageSelect) {
                hiddenPerPage.value = perPageSelect.value;
            }
            if (checkboxes.length === 0) {
                openBtn.disabled = true;
                return;
            }
            openBtn.disabled = count === 0;
            if (!selectAll) {
                return;
            }
            selectAll.checked = count > 0 && count === checkboxes.length;
            selectAll.indeterminate = count > 0 && count < checkboxes.length;
        }

        if (openBtn.dataset.exportSelectBound !== '1') {
            openBtn.dataset.exportSelectBound = '1';
            openBtn.addEventListener('click', function () {
                syncExportSelection();
            });
        }

        if (selectAll && selectAll.dataset.exportSelectBound !== '1') {
            selectAll.dataset.exportSelectBound = '1';
            selectAll.addEventListener('change', function () {
                checkboxes.forEach(function (checkbox) {
                    checkbox.checked = selectAll.checked;
                });
                syncExportSelection();
            });
        }

        checkboxes.forEach(function (checkbox) {
            if (checkbox.dataset.exportSelectBound === '1') {
                return;
            }
            checkbox.dataset.exportSelectBound = '1';
            checkbox.addEventListener('change', syncExportSelection);
        });

        syncExportSelection();
    };

    function initSubmissionsExportPeriodHalfModal() {
        var modal = null;
        document.querySelectorAll('[data-module="c-halfModal01"]').forEach(function (candidate) {
            if (candidate.querySelector('[data-target="submissions-export-period-close"]')) {
                modal = candidate;
            }
        });
        if (!modal) return;

        var bodyClass = 'is-submissions-export-period-modal-open';
        var lastOpenTrigger = null;
        var scrollLock = createHalfModalScrollLock(bodyClass);

        function openModal(trigger) {
            lastOpenTrigger = trigger || null;
            modal.hidden = false;
            scrollLock.lock();
            var input = modal.querySelector('#submissions-export-period-from');
            if (input && typeof input.focus === 'function') {
                input.focus();
            }
        }

        function closeModal() {
            modal.hidden = true;
            scrollLock.unlock();
            if (lastOpenTrigger && typeof lastOpenTrigger.focus === 'function') {
                lastOpenTrigger.focus();
            }
        }

        document.addEventListener('click', function (event) {
            var openTrigger = event.target.closest('[data-target="submissions-export-period-open"]');
            if (!openTrigger) return;
            event.preventDefault();
            openModal(openTrigger);
        });

        modal.querySelectorAll('[data-target="submissions-export-period-close"]').forEach(function (el) {
            el.addEventListener('click', function () {
                closeModal();
            });
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !modal.hidden) {
                closeModal();
            }
        });
    }

    window.formkunInitSubmissionsExportModal = function () {
        initSettingsLimitModal('submissions-export-open', 'submissions-export', 'submissions-export-filename', 'is-submissions-export-modal-open');
    };

    (function initSubmissionsExportPeriodFormAutoSubmit() {
        var form = document.getElementById('submissions-export-period-form');
        if (!form) return;

        var datePattern = /^(19|20)\d{2}-\d{2}-\d{2}$/;
        var fetchController = null;

        function isValidDateValue(input) {
            if (!input || input.type !== 'date') return false;
            var value = input.value;
            return value === '' || datePattern.test(value);
        }

        function buildExportPeriodUrl() {
            var params = new URLSearchParams();
            var data = new FormData(form);
            ['from', 'to'].forEach(function (name) {
                var value = (data.get(name) || '').toString().trim();
                if (value !== '') {
                    params.set(name, value);
                }
            });
            var perPageSelect = document.getElementById('submissions-export-per-page');
            if (perPageSelect && perPageSelect.value) {
                params.set('per_page', perPageSelect.value);
            }
            var query = params.toString();
            return query ? form.action + '?' + query : form.action;
        }

        function bindSubmissionsExportPerPageSelect() {
            var perPageSelect = document.getElementById('submissions-export-per-page');
            if (!perPageSelect || perPageSelect.dataset.perPageBound === '1') {
                return;
            }
            perPageSelect.dataset.perPageBound = '1';
            perPageSelect.addEventListener('change', function () {
                refreshSubmissionsExportLiveRegion();
            });
        }

        function syncExportPeriodModalReset() {
            var resetLink = form.querySelector('.c-halfModal01__actions.is-centered a.btn');
            if (!resetLink) return;
            var data = new FormData(form);
            var hasFilter = ['from', 'to'].some(function (name) {
                return (data.get(name) || '').toString().trim() !== '';
            });
            if (hasFilter) {
                resetLink.removeAttribute('aria-disabled');
                resetLink.removeAttribute('tabindex');
            } else {
                resetLink.setAttribute('aria-disabled', 'true');
                resetLink.setAttribute('tabindex', '-1');
            }
        }

        function refreshSubmissionsExportLiveRegion() {
            var url = buildExportPeriodUrl();
            if (fetchController) {
                fetchController.abort();
            }
            fetchController = new AbortController();

            fetch(url, {
                credentials: 'same-origin',
                headers: { Accept: 'text/html' },
                signal: fetchController.signal,
            })
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('export period fetch failed');
                    }
                    return response.text();
                })
                .then(function (html) {
                    var doc = new DOMParser().parseFromString(html, 'text/html');
                    var nextRegion = doc.querySelector('[data-target="submissionsExportLive01"]');
                    var currentRegion = document.querySelector('[data-target="submissionsExportLive01"]');
                    if (!nextRegion || !currentRegion) {
                        throw new Error('submissionsExportLive01 missing');
                    }
                    currentRegion.replaceWith(document.importNode(nextRegion, true));
                    history.replaceState(null, '', url);
                    syncExportPeriodModalReset();
                    if (typeof window.formkunInitSubmissionsExportModal === 'function') {
                        window.formkunInitSubmissionsExportModal();
                    }
                    if (typeof window.formkunInitSubmissionsExportSelect === 'function') {
                        window.formkunInitSubmissionsExportSelect();
                    }
                    if (typeof window.formkunReenhanceAdminPickers === 'function') {
                        var exportLive = document.querySelector('[data-target="submissionsExportLive01"]');
                        window.formkunReenhanceAdminPickers(exportLive || document);
                    }
                    bindSubmissionsExportPerPageSelect();
                })
                .catch(function (error) {
                    if (error && error.name === 'AbortError') {
                        return;
                    }
                    form.submit();
                });
        }

        form.addEventListener('change', function (event) {
            var input = event.target;
            if (!input || input.type !== 'date') return;
            if (!isValidDateValue(input)) return;
            setTimeout(refreshSubmissionsExportLiveRegion, 0);
        });

        syncExportPeriodModalReset();
        bindSubmissionsExportPerPageSelect();
    })();

    initSubmissionsExportPeriodHalfModal();

    initSettingsLimitModal('settings-max-forms-open', 'settings-max-forms', 'max_forms_modal', 'is-settings-max-forms-modal-open');
    initSettingsLimitModal('settings-max-storage-open', 'settings-max-storage', 'max_site_resource_mb_modal', 'is-settings-max-storage-modal-open');
    initSettingsLimitModal('settings-public-site-open', 'settings-public-site', 'public_site_url_modal', 'is-settings-public-site-modal-open');
    initSettingsLimitModal('settings-holidays-open', 'settings-holidays', 'holidays_jp_fetch_interval_days_modal', 'is-settings-holidays-modal-open');
    initSettingsLimitModal('settings-purge-schedule-open', 'settings-purge-schedule', '', 'is-settings-purge-schedule-modal-open');
    initSettingsLimitModal('settings-versioning-open', 'settings-versioning', 'form_version_interval_minutes_modal', 'is-settings-versioning-modal-open');
    initSettingsLimitModal('settings-manual-update-open', 'settings-manual-update', '', 'is-settings-manual-update-modal-open');
    initSettingsLimitModal('settings-backup-export-open', 'settings-backup-export', 'backup_password', 'is-settings-backup-export-modal-open');
    initSettingsLimitModal('settings-backup-restore-open', 'settings-backup-restore', '', 'is-settings-backup-restore-modal-open');
    initSettingsAppUpdate();
    window.formkunInitSubmissionsExportModal();
    if (typeof window.formkunInitSubmissionsExportSelect === 'function') {
        window.formkunInitSubmissionsExportSelect();
    }
    initSubmissionSearchHalfModal();

    (function initAdminHeaderMenu() {
        var header = document.querySelector('[data-module="c-adminHeader01"]');
        var toggle = document.querySelector('[data-target="c-adminHeader01__menuToggle"]');
        var panel = document.querySelector('[data-target="c-adminHeader01__menuPanel"]');
        if (!header || !toggle || !panel) return;

        function setOpen(open) {
            header.classList.toggle('is-menu-open', open);
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            toggle.setAttribute('aria-label', open ? 'メニューを閉じる' : 'メニューを開く');
            document.body.classList.toggle('is-adminHeaderMenuOpen', open);
        }

        function closeMenu() {
            setOpen(false);
        }

        toggle.addEventListener('click', function () {
            setOpen(!header.classList.contains('is-menu-open'));
        });

        panel.querySelectorAll('.area.is-nav a').forEach(function (link) {
            link.addEventListener('click', closeMenu);
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') closeMenu();
        });

        document.addEventListener('click', function (event) {
            if (!header.classList.contains('is-menu-open')) return;
            var target = event.target;
            if (header.contains(target)) return;
            closeMenu();
        });
    })();

    (function initAdminUserRoleFormGrants() {
        var roleSelect = document.getElementById('admin-user-role');
        var grantsBlock = document.getElementById('admin-user-form-grants');
        if (!roleSelect || !grantsBlock) return;

        function syncRowAccess(row) {
            var checkbox = row.querySelector('[data-target="adminUserFormGrantRow01__checkbox"]');
            var accessBlock = row.querySelector('[data-target="adminUserFormGrantRow01__access"]');
            if (!checkbox || !accessBlock) return;
            var enabled = checkbox.checked;
            accessBlock.hidden = !enabled;
            accessBlock.querySelectorAll('[data-target="adminUserFormGrantRow01__radio"]').forEach(function (radio) {
                radio.disabled = !enabled;
            });
        }

        function syncAllRows() {
            grantsBlock.querySelectorAll('[data-target="adminUserFormGrantRow01"]').forEach(syncRowAccess);
        }

        function syncVisibility() {
            grantsBlock.hidden = roleSelect.value !== 'viewer';
        }

        roleSelect.addEventListener('change', syncVisibility);
        grantsBlock.addEventListener('change', function (event) {
            var checkbox = event.target.closest('[data-target="adminUserFormGrantRow01__checkbox"]');
            if (!checkbox) return;
            var row = checkbox.closest('[data-target="adminUserFormGrantRow01"]');
            if (row) syncRowAccess(row);
        });
        syncVisibility();
        syncAllRows();
    })();

    var lists = Array.prototype.slice.call(document.querySelectorAll('[data-target="m-formBuilder01__fields"]'));
    var list = lists[0] || null;
    var createTemplate = document.querySelector('[data-target="fieldTemplateCreateTemplate"]');
    if (!list && !createTemplate) return;
    var activeList = list;

    var builderRoot = list ? list.closest('[data-module="m-formBuilder01"]') : null;
    var template = document.querySelector('[data-target="m-formBuilder01__fieldTemplate"]');
    var radioDefaultSettingsTemplate = document.querySelector('[data-target="c-formBuilder01__radioDefaultSettingsTemplate"]');
    var groupTemplate = document.querySelector('[data-target="m-formBuilder01__groupTemplate"]');
    var addButtons = Array.prototype.slice.call(document.querySelectorAll('[data-target="m-formBuilder01__add"]')).filter(function (button) {
        return !button.closest('[data-description-editor]') && !button.closest('[data-publish-schedule-editor]');
    });
    var addBtn = addButtons[0] || null;
    var typeModal = document.querySelector('[data-target="m-formBuilder01__typeModal"]');
    var descriptionTemplate = document.querySelector('[data-target="m-formBuilder01__descriptionTemplate"]');
    var descriptionEditors = Array.prototype.slice.call(document.querySelectorAll('[data-description-editor]'));
    var publishRuleTemplate = document.querySelector('[data-target="c-publishScheduleEditor01__ruleTemplate"]');
    var publishScheduleEditors = Array.prototype.slice.call(document.querySelectorAll('[data-publish-schedule-editor]'));
    var PUBLISH_WEEKDAY_ORDER = [1, 2, 3, 4, 5, 6, 0];
    var PUBLISH_WEEKDAY_LABELS = { 0: '日', 1: '月', 2: '火', 3: '水', 4: '木', 5: '金', 6: '土' };
    var mainForm = list ? list.closest('form') : null;
    var dirtyActions = mainForm ? mainForm.querySelector('[data-target="p-formEdit01__dirtyActions"]') : null;
    var dirtyCancel = mainForm ? mainForm.querySelector('[data-target="p-formEdit01__dirtyCancel"]') : null;
    var initialFormSnapshot = '';
    var dirtyStateRaf = 0;
    var dirtyStateSuppressDepth = 0;

    function getFieldItems() {
        return document.querySelectorAll('[data-target="m-formBuilder01__fields"] .c-formEditor__item[data-field-item="1"]');
    }

    function getGroupItems() {
        return document.querySelectorAll('[data-target="m-formBuilder01__fields"] .c-formEditor__item[data-group-item="1"]');
    }

    function queryOwnGroupControl(group, selector) {
        if (!group) return null;
        var controls = group.querySelectorAll(selector);
        for (var i = 0; i < controls.length; i++) {
            if (controls[i].closest('[data-group-item="1"]') === group) {
                return controls[i];
            }
        }
        return null;
    }

    function queryOwnGroupControls(group, selector) {
        if (!group) return [];
        return Array.prototype.slice.call(group.querySelectorAll(selector)).filter(function (control) {
            return control.closest('[data-group-item="1"]') === group;
        });
    }

    function getBuilderItemsForList(targetList) {
        return targetList ? Array.prototype.slice.call(targetList.children).filter(function (child) {
            return child.classList && child.classList.contains('c-formEditor__item') && (child.getAttribute('data-field-item') === '1' || child.getAttribute('data-group-item') === '1');
        }) : [];
    }

    function getFieldItemsForList(targetList) {
        return targetList ? targetList.querySelectorAll('.c-formEditor__item[data-field-item="1"]') : [];
    }

    function getActiveList() {
        return activeList || list;
    }

    function getPageKeyForList(targetList) {
        return (targetList && targetList.getAttribute('data-input-page-key')) || 'input-1';
    }

    function getParentGroupKeyForList(targetList) {
        return (targetList && targetList.getAttribute('data-parent-group-key')) || '';
    }

    function setFieldInputPageKey(li, pageKey) {
        var input = li ? li.querySelector('[data-target="c-formEditor__inputPageKey"]') : null;
        if (input) {
            input.value = pageKey || 'input-1';
        }
    }

    function setFieldParentGroupKey(li, parentGroupKey) {
        var input = li ? li.querySelector('[data-target="c-formEditor__parentGroupKey"]') : null;
        if (input) {
            input.value = parentGroupKey || '';
        }
    }

    function setGroupInputPageKey(group, pageKey) {
        var input = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__inputPageKey"]');
        if (input) {
            input.value = pageKey || 'input-1';
        }
        var childList = group ? group.querySelector('[data-target="m-formBuilder01__fields"]') : null;
        if (childList) {
            childList.setAttribute('data-input-page-key', pageKey || 'input-1');
        }
    }

    function setGroupParentGroupKey(group, parentGroupKey) {
        var input = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__parentGroupKey"]');
        if (input) {
            input.value = parentGroupKey || '';
        }
    }

    function getFieldItemsForEditor(editor) {
        var panel = editor ? editor.closest('[data-target="c-formEditTabs01__contents"][data-tab-panel^="screen-input-"]') : null;
        var targetList = panel ? panel.querySelector('[data-target="m-formBuilder01__fields"]') : null;
        return targetList ? getFieldItemsForList(targetList) : getFieldItems();
    }

    function extractDataName(name) {
        if (!name) return null;
        var m = name.match(/^fields\[\d+\]\[(.+)\]$/);
        return m ? m[1] : null;
    }

    function extractGroupName(name) {
        if (!name) return null;
        var m = name.match(/^field_groups\[\d+\]\[(.+)\]$/);
        return m ? m[1] : null;
    }

    function extractDescriptionDataName(name, prefix) {
        if (!name) return null;
        var m = name.match(new RegExp('^' + prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\[\\d+\\]\\[(.+)\\]$'));
        return m ? m[1] : null;
    }

    function getDescriptionPositionOptions(editor) {
        var mode = editor.getAttribute('data-position-mode') || 'simple';
        var options = [{ value: '0', label: '先頭' }];
        if (mode === 'input') {
            options.push({ value: String(getFieldItemsForEditor(editor).length + 1), label: '末尾' });
        } else {
            options.push({ value: '1', label: '末尾' });
        }
        return options;
    }

    function applyDescriptionPositionOptions(editor, select, preferredValue) {
        if (!select) return;
        var options = getDescriptionPositionOptions(editor);
        var nextValue = preferredValue;
        if (nextValue === undefined || nextValue === null || nextValue === '') {
            nextValue = select.value || select.getAttribute('data-value') || '0';
        }
        select.innerHTML = '';
        options.forEach(function (option) {
            var el = document.createElement('option');
            el.value = option.value;
            el.textContent = option.label;
            select.appendChild(el);
        });
        var available = options.some(function (option) { return option.value === String(nextValue); });
        select.value = available ? String(nextValue) : options[options.length - 1].value;
        select.setAttribute('data-value', select.value);
    }

    function getDescriptionList(editor) {
        return editor ? editor.querySelector('[data-description-list]') : null;
    }

    function setFieldType(li, typeValue, typeLabel) {
        if (!li) return;
        var typeInput = li.querySelector('[data-target="c-formEditor__type"]');
        var typeLabelEl = li.querySelector('[data-target="c-formEditor__typeLabel"]');
        var summaryTypeEl = li.querySelector('[data-target="c-formEditor__summaryType"]');
        if (typeInput) {
            typeInput.value = typeValue || 'text_multi';
            typeInput.setAttribute('data-type-label', typeLabel || '');
        }
        if (typeLabelEl) {
            typeLabelEl.textContent = typeLabel || '';
        }
        if (summaryTypeEl) {
            summaryTypeEl.textContent = typeLabel || '';
        }
    }

    function isDisplayOnlyFieldType(typeValue) {
        return ['heading', 'description', 'divider'].indexOf(String(typeValue || '')) !== -1;
    }

    function syncHtmlToggleEditor(editor) {
        if (!editor) return;
        var toggle = editor.querySelector('[data-target="c-htmlInputEditor01__toggle"]');
        var textarea = editor.querySelector('[data-target="c-htmlInputEditor01__textarea"]');
        var isHtmlMode = !!(toggle && toggle.checked);
        editor.classList.toggle('is-html-mode', isHtmlMode);
        if (textarea) {
            textarea.spellcheck = !isHtmlMode;
            textarea.placeholder = isHtmlMode ? '<p>説明文を入力</p>' : '説明文を入力';
        }
    }

    function syncInputModuleState(module) {
        if (!module) return;
        var control = module.querySelector('input, textarea, select');
        if (!control) return;
        var value = typeof control.value === 'string' ? control.value.trim() : '';
        var isEmpty = value === '';
        module.classList.toggle('is-empty', isEmpty);
        module.classList.toggle('is-filled', !isEmpty);
    }

    function syncInputModuleStates(root) {
        (root || document).querySelectorAll('[data-module="m-input01"]').forEach(function (module) {
            syncInputModuleState(module);
        });
    }

    function copyControlValues(source, target) {
        if (!source || !target) return;
        var sourceControls = source.querySelectorAll('input, textarea, select');
        var targetControls = target.querySelectorAll('input, textarea, select');
        sourceControls.forEach(function (control, index) {
            var clone = targetControls[index];
            if (!clone) return;
            if (control.type === 'checkbox' || control.type === 'radio') {
                clone.checked = control.checked;
                return;
            }
            clone.value = control.value;
            if (clone.tagName === 'SELECT') {
                clone.setAttribute('data-value', clone.value);
            }
        });
    }

    function resetClonedBuilderState(root) {
        if (!root) return;
        [root].concat(Array.prototype.slice.call(root.querySelectorAll('*'))).forEach(function (el) {
            el.removeAttribute('data-group-bound');
            el.removeAttribute('data-html-toggle-bound');
            el.removeAttribute('data-accordion-bound');
            el.removeAttribute('data-field-add-bound');
            el.removeAttribute('data-inline-menu-bound');
            el.removeAttribute('data-details-action-menu-bound');
            el.removeAttribute('data-fb-sortable');
        });
        root.querySelectorAll('details.menu[open], details.c-tableActionMenu01[open]').forEach(function (menu) {
            menu.removeAttribute('open');
        });
    }

    function refreshBuilderListSortable(targetList) {
        if (!targetList || targetList.dataset.fbSortable !== '1' || typeof jQuery === 'undefined') return;
        try {
            jQuery(targetList).sortable('refresh');
        } catch (e1) {}
    }

    function insertAfter(referenceNode, newNode) {
        if (!referenceNode || !referenceNode.parentNode || !newNode) return;
        referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
    }

    function bindInlineActionMenu(menu) {
        if (typeof window.formkunBindDetailsActionMenu === 'function') {
            window.formkunBindDetailsActionMenu(menu);
        }
    }

    function serializeFormSnapshot(form) {
        if (!form) return '';
        var pairs = [];
        new FormData(form).forEach(function (value, key) {
            if (key === 'builder_payload' || key.indexOf('_builder_meta[') === 0) {
                return;
            }
            pairs.push(encodeURIComponent(key) + '=' + encodeURIComponent(typeof value === 'string' ? value : String(value)));
        });
        return pairs.join('&');
    }

    function withDirtyStateSuppressed(fn) {
        dirtyStateSuppressDepth += 1;
        try {
            return fn();
        } finally {
            dirtyStateSuppressDepth -= 1;
        }
    }

    function updateDirtyState() {
        if (!mainForm || !dirtyActions) return;
        var isDirty = serializeFormSnapshot(mainForm) !== initialFormSnapshot;
        dirtyActions.hidden = !isDirty;
        document.body.classList.toggle('is-form-edit-dirty', isDirty);
    }

    function queueDirtyState() {
        if (dirtyStateSuppressDepth > 0) return;
        if (!mainForm || !dirtyActions || dirtyStateRaf) return;
        dirtyStateRaf = window.requestAnimationFrame(function () {
            dirtyStateRaf = 0;
            updateDirtyState();
        });
    }

    function bindHtmlToggleEditor(editor) {
        if (!editor || editor.getAttribute('data-html-toggle-bound') === '1') return;
        var toggle = editor.querySelector('[data-target="c-htmlInputEditor01__toggle"]');
        if (toggle) {
            toggle.addEventListener('change', function () {
                syncHtmlToggleEditor(editor);
            });
        }
        editor.setAttribute('data-html-toggle-bound', '1');
        syncHtmlToggleEditor(editor);
    }

    function updateDescriptionSummary(block) {
        if (!block) return;
        var labelInput = block.querySelector('[data-target="c-descriptionEditor__labelInput"]');
        var positionSelect = block.querySelector('.fb-description-position');
        var summaryLabel = block.querySelector('[data-target="c-descriptionEditor__summaryLabel"]');
        var summaryPosition = block.querySelector('[data-target="c-descriptionEditor__summaryPosition"]');
        if (summaryLabel) {
            var value = labelInput ? labelInput.value.trim() : '';
            summaryLabel.textContent = value;
            summaryLabel.hidden = !value;
        }
        if (summaryPosition && positionSelect) {
            var selected = positionSelect.selectedOptions && positionSelect.selectedOptions[0];
            summaryPosition.textContent = selected ? selected.textContent.trim() : '先頭';
        }
    }

    /** 項目設定・説明文の .c-formEditor__item 共通: 公開非表示なら is-editor-item-hidden + 本文 inert（c-formEditorList01 の SCSS と対。disabled は付けない）。 */
    function syncFormEditorItemPublicHidden(item) {
        if (!item || !item.classList.contains('c-formEditor__item')) return;
        var visibilityToggle = item.querySelector(
            '.c-formEditorSummary01__visibility [data-name="visible"], .c-formEditorSummary01__visibility [data-group-name="visible"], .c-descriptionEditorSummary01__visibility [data-name="visible"], .c-publishScheduleEditorSummary01__visibility [data-name="visible"]'
        );
        var body = item.querySelector('.c-formEditor__itemBody');
        if (!visibilityToggle || !body) return;
        var off = !visibilityToggle.checked;
        item.classList.toggle('is-editor-item-hidden', off);
        if ('inert' in HTMLElement.prototype) {
            body.inert = off;
        }
    }

    function reindexDescriptionBlocks(editor) {
        var descriptionList = getDescriptionList(editor);
        if (!descriptionList) return;
        var prefix = editor.getAttribute('data-name-prefix') || 'description_blocks';
        descriptionList.querySelectorAll('[data-description-block]').forEach(function (block, i) {
            block.setAttribute('data-index', String(i));
            block.querySelectorAll('input, textarea, select').forEach(function (el) {
                var name = el.getAttribute('data-name') || extractDescriptionDataName(el.getAttribute('name'), prefix);
                if (!name) return;
                el.setAttribute('name', prefix + '[' + i + '][' + name + ']');
            });
            var idInput = block.querySelector('[data-name="id"]');
            var blockId = idInput ? (idInput.value || (prefix.replace(/_blocks$/, '') + '-' + i)) : (prefix.replace(/_blocks$/, '') + '-' + i);
            var labelInput = block.querySelector('[data-target="c-descriptionEditor__labelInput"]');
            var labelLabel = labelInput ? labelInput.closest('[data-module="m-inputSet01"]').querySelector('.block.is-title label') : null;
            var positionSelect = block.querySelector('.fb-description-position');
            var positionLabel = positionSelect ? positionSelect.closest('[data-module="m-inputSet01"]').querySelector('.block.is-title label') : null;
            var textarea = block.querySelector('[data-target="c-htmlInputEditor01__textarea"]');
            var textareaLabel = textarea ? textarea.closest('[data-module="m-inputSet01"]').querySelector('.block.is-title label') : null;
            if (labelInput) {
                labelInput.id = blockId + '-label';
                if (labelLabel) labelLabel.setAttribute('for', labelInput.id);
            }
            if (positionSelect) {
                positionSelect.id = blockId + '-position';
                if (positionLabel) positionLabel.setAttribute('for', positionSelect.id);
            }
            if (textarea) {
                textarea.id = blockId + '-html';
                if (textareaLabel) textareaLabel.setAttribute('for', textarea.id);
            }
            updateDescriptionSummary(block);
            syncFormEditorItemPublicHidden(block);
        });
    }

    function refreshDescriptionPositionOptions(editor) {
        var descriptionList = getDescriptionList(editor);
        if (!descriptionList) return;
        descriptionList.querySelectorAll('.fb-description-position').forEach(function (select) {
            applyDescriptionPositionOptions(editor, select);
        });
    }

    function refreshAllDescriptionPositionOptions() {
        descriptionEditors.forEach(function (editor) {
            refreshDescriptionPositionOptions(editor);
        });
    }

    function refreshDescriptionSortable(editor) {
        var descriptionList = getDescriptionList(editor);
        if (!descriptionList || descriptionList.dataset.fbSortable !== '1' || typeof jQuery === 'undefined') return;
        try {
            jQuery(descriptionList).sortable('refresh');
        } catch (e1) {}
    }

    function initDescriptionSortable(editor) {
        var descriptionList = getDescriptionList(editor);
        if (!descriptionList || typeof jQuery === 'undefined' || !jQuery.fn.sortable) return;
        if (descriptionList.dataset.fbSortable === '1') {
            refreshDescriptionSortable(editor);
            return;
        }
        jQuery(descriptionList).sortable({
            handle: '[data-target="c-descriptionEditor__dragHandle"]',
            axis: 'y',
            items: '> .c-formEditor__item',
            placeholder: 'fb-sortable-placeholder',
            tolerance: 'pointer',
            cursor: 'grabbing',
            opacity: 0.88,
            scroll: true,
            scrollSensitivity: 48,
            scrollSpeed: 28,
            forcePlaceholderSize: true,
            delay: 0,
            distance: 4,
            zIndex: 9999,
            update: function () {
                reindexDescriptionBlocks(editor);
            }
        });
        descriptionList.dataset.fbSortable = '1';
    }

    function bindDescriptionBlock(editor, block) {
        var remove = block.querySelector('[data-target="fb-description-remove"]');
        var select = block.querySelector('.fb-description-position');
        var labelInput = block.querySelector('[data-target="c-descriptionEditor__labelInput"]');
        var visibilityToggle = block.querySelector('[data-name="visible"]');
        var header = block.querySelector('.c-formEditor__itemHeader');
        bindHtmlToggleEditor(block.querySelector('[data-html-toggle-editor]'));
        updateDescriptionSummary(block);
        if (header && header.getAttribute('data-accordion-bound') !== '1') {
            header.addEventListener('click', function (e) {
                if (e.target.closest('.area.is-move') || e.target.closest('.area.is-delete') || e.target.closest('.c-descriptionEditorSummary01__visibility')) {
                    return;
                }
                block.classList.toggle('is-collapsed');
            });
            header.setAttribute('data-accordion-bound', '1');
        }
        if (remove) {
            remove.addEventListener('click', function () {
                block.parentNode.removeChild(block);
                reindexDescriptionBlocks(editor);
                refreshDescriptionPositionOptions(editor);
                refreshDescriptionSortable(editor);
            });
        }
        if (select) {
            select.addEventListener('change', function () {
                select.setAttribute('data-value', select.value);
            });
        }
        if (labelInput) {
            labelInput.addEventListener('input', function () {
                updateDescriptionSummary(block);
            });
        }
        if (visibilityToggle) {
            visibilityToggle.addEventListener('change', function () {
                syncFormEditorItemPublicHidden(block);
                var label = visibilityToggle.closest('.c-descriptionEditorSummary01__visibility');
                if (label) {
                    label.title = visibilityToggle.checked ? '表示中' : '非表示';
                }
            });
        }
        syncFormEditorItemPublicHidden(block);
    }

    function createDescriptionBlock(editor, position) {
        if (!descriptionTemplate) return null;
        var block = descriptionTemplate.content.firstElementChild.cloneNode(true);
        var idInput = block.querySelector('[data-name="id"]');
        var select = block.querySelector('.fb-description-position');
        var prefix = editor.getAttribute('data-name-prefix') || 'description_blocks';
        if (idInput) {
            idInput.value = prefix.replace(/_blocks$/, '') + '-' + generateUuidV4();
        }
        if (select) {
            select.setAttribute('data-value', String(position || 0));
        }
        bindDescriptionBlock(editor, block);
        return block;
    }

    function getPublishRuleList(editor) {
        return editor ? editor.querySelector('[data-publish-rule-list]') : null;
    }

    function extractPublishRuleDataName(name, prefix) {
        if (!name) return '';
        var escaped = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        var match = name.match(new RegExp('^' + escaped + '\\[\\d+\\]\\[(.+)\\]$'));
        return match ? match[1] : '';
    }

    function updatePublishRuleSummary(block) {
        if (!block) return;
        var summaryDetail = block.querySelector('[data-target="c-publishScheduleEditor__summaryDetail"]');
        if (!summaryDetail) return;
        var parts = [];
        var startInput = block.querySelector('[data-target="c-publishScheduleEditor__startInput"]');
        var endInput = block.querySelector('[data-target="c-publishScheduleEditor__endInput"]');
        var startValue = startInput ? startInput.value.trim() : '';
        var endValue = endInput ? endInput.value.trim() : '';
        if (startValue || endValue) {
            if (startValue && endValue) {
                parts.push(startValue + ' 〜 ' + endValue);
            } else if (startValue) {
                parts.push(startValue + ' 以降');
            } else {
                parts.push(endValue + ' まで');
            }
        }
        var weekdayLabels = [];
        block.querySelectorAll('[data-weekday]').forEach(function (checkbox) {
            if (checkbox.checked) {
                var day = parseInt(checkbox.getAttribute('data-weekday'), 10);
                if (PUBLISH_WEEKDAY_LABELS[day]) {
                    weekdayLabels.push(PUBLISH_WEEKDAY_LABELS[day]);
                }
            }
        });
        if (weekdayLabels.length) {
            parts.push(weekdayLabels.join(''));
        }
        var holidayCheckbox = block.querySelector('[data-name="holiday"]');
        if (holidayCheckbox && holidayCheckbox.checked) {
            parts.push('祝日');
        }
        var dailyStart = block.querySelector('[data-target="c-publishScheduleEditor__dailyStartInput"]');
        var dailyEnd = block.querySelector('[data-target="c-publishScheduleEditor__dailyEndInput"]');
        var dailyStartValue = dailyStart ? dailyStart.value.trim() : '';
        var dailyEndValue = dailyEnd ? dailyEnd.value.trim() : '';
        if (dailyStartValue && dailyEndValue) {
            parts.push(dailyStartValue + '〜' + dailyEndValue);
        }
        summaryDetail.textContent = parts.length ? parts.join(' / ') : '条件未設定';
    }

    function reindexPublishRules(editor) {
        var ruleList = getPublishRuleList(editor);
        if (!ruleList) return;
        var prefix = editor.getAttribute('data-name-prefix') || 'publish_rules';
        ruleList.querySelectorAll('[data-publish-rule-block]').forEach(function (block, i) {
            block.setAttribute('data-index', String(i));
            block.querySelectorAll('input, textarea, select').forEach(function (el) {
                if (el.hasAttribute('data-weekday')) {
                    el.setAttribute('name', prefix + '[' + i + '][weekdays][]');
                    return;
                }
                var name = el.getAttribute('data-name') || extractPublishRuleDataName(el.getAttribute('name'), prefix);
                if (!name) return;
                el.setAttribute('name', prefix + '[' + i + '][' + name + ']');
            });
            var idInput = block.querySelector('[data-name="id"]');
            var blockId = idInput ? (idInput.value || ('publish-' + i)) : ('publish-' + i);
            var startInput = block.querySelector('[data-target="c-publishScheduleEditor__startInput"]');
            var endInput = block.querySelector('[data-target="c-publishScheduleEditor__endInput"]');
            var dailyStartInput = block.querySelector('[data-target="c-publishScheduleEditor__dailyStartInput"]');
            var dailyEndInput = block.querySelector('[data-target="c-publishScheduleEditor__dailyEndInput"]');
            if (startInput) startInput.id = blockId + '-start';
            if (endInput) endInput.id = blockId + '-end';
            if (dailyStartInput) dailyStartInput.id = blockId + '-daily-start';
            if (dailyEndInput) dailyEndInput.id = blockId + '-daily-end';
            var holidayInput = block.querySelector('[data-name="holiday"]');
            if (holidayInput) holidayInput.id = blockId + '-holiday';
            block.querySelectorAll('[data-weekday]').forEach(function (checkbox) {
                var day = checkbox.getAttribute('data-weekday');
                checkbox.id = blockId + '-weekday-' + day;
            });
            updatePublishRuleSummary(block);
            syncFormEditorItemPublicHidden(block);
        });
        syncPublishScheduleUi();
    }

    function publishRuleHasConfiguredDimension(block) {
        if (!block) return false;
        var startInput = block.querySelector('[data-target="c-publishScheduleEditor__startInput"]');
        var endInput = block.querySelector('[data-target="c-publishScheduleEditor__endInput"]');
        var hasPeriod = (startInput && startInput.value.trim()) || (endInput && endInput.value.trim());
        var hasWeekdays = false;
        block.querySelectorAll('[data-weekday]').forEach(function (checkbox) {
            if (checkbox.checked) {
                hasWeekdays = true;
            }
        });
        var dailyStart = block.querySelector('[data-target="c-publishScheduleEditor__dailyStartInput"]');
        var dailyEnd = block.querySelector('[data-target="c-publishScheduleEditor__dailyEndInput"]');
        var hasTimeBand = dailyStart && dailyEnd && dailyStart.value.trim() && dailyEnd.value.trim();
        var holidayCheckbox = block.querySelector('[data-name="holiday"]');
        var hasHoliday = holidayCheckbox && holidayCheckbox.checked;
        return !!(hasPeriod || hasWeekdays || hasTimeBand || hasHoliday);
    }

    function getPublishRuleTemplate(editor) {
        if (editor) {
            var local = editor.querySelector('[data-publish-rule-template]');
            if (local) return local;
        }
        return publishRuleTemplate;
    }

    function getPublishRuleIdPrefix(editor) {
        if (!editor) return 'publish';
        var prefix = editor.getAttribute('data-id-prefix');
        if (prefix) return prefix;
        var namePrefix = editor.getAttribute('data-name-prefix') || 'publish_rules';
        return namePrefix === 'unpublish_rules' ? 'unpublish' : 'publish';
    }

    function syncPublishScheduleUi() {
        var hasActiveRule = false;
        publishScheduleEditors.forEach(function (editor) {
            var ruleList = getPublishRuleList(editor);
            if (!ruleList) return;
            ruleList.querySelectorAll('[data-publish-rule-block]').forEach(function (block) {
                var visibilityToggle = block.querySelector('[data-name="visible"]');
                if (visibilityToggle && visibilityToggle.checked && publishRuleHasConfiguredDimension(block)) {
                    hasActiveRule = true;
                }
            });
        });
        var showClosedTab = hasActiveRule;
        document.querySelectorAll('[data-publish-schedule-closed-tab]').forEach(function (tab) {
            tab.hidden = !showClosedTab;
        });
        var closedPanel = document.querySelector('[data-publish-schedule-closed-panel]');
        if (closedPanel) {
            closedPanel.hidden = !showClosedTab;
        }
    }

    function initPublishRuleSortable(editor) {
        var ruleList = getPublishRuleList(editor);
        if (!ruleList || typeof jQuery === 'undefined' || !jQuery.fn.sortable) return;
        if (ruleList.dataset.fbPublishSortable === '1') {
            try {
                jQuery(ruleList).sortable('refresh');
            } catch (e1) {}
            return;
        }
        jQuery(ruleList).sortable({
            handle: '[data-target="c-publishScheduleEditor__dragHandle"]',
            axis: 'y',
            items: '> .c-formEditor__item',
            placeholder: 'fb-sortable-placeholder',
            tolerance: 'pointer',
            cursor: 'grabbing',
            opacity: 0.88,
            scroll: true,
            scrollSensitivity: 48,
            scrollSpeed: 28,
            forcePlaceholderSize: true,
            delay: 0,
            distance: 4,
            zIndex: 9999,
            update: function () {
                reindexPublishRules(editor);
            }
        });
        ruleList.dataset.fbPublishSortable = '1';
    }

    function bindPublishRuleBlock(editor, block) {
        var remove = block.querySelector('[data-target="fb-publish-rule-remove"]');
        var header = block.querySelector('.c-formEditor__itemHeader');
        var visibilityToggle = block.querySelector('[data-name="visible"]');
        updatePublishRuleSummary(block);
        if (header && header.getAttribute('data-accordion-bound') !== '1') {
            header.addEventListener('click', function (e) {
                if (e.target.closest('.area.is-move') || e.target.closest('.area.is-delete') || e.target.closest('.c-publishScheduleEditorSummary01__visibility')) {
                    return;
                }
                block.classList.toggle('is-collapsed');
            });
            header.setAttribute('data-accordion-bound', '1');
        }
        if (remove) {
            remove.addEventListener('click', function () {
                block.parentNode.removeChild(block);
                reindexPublishRules(editor);
                initPublishRuleSortable(editor);
            });
        }
        block.querySelectorAll('[data-target="c-publishScheduleEditor__startInput"], [data-target="c-publishScheduleEditor__endInput"], [data-target="c-publishScheduleEditor__dailyStartInput"], [data-target="c-publishScheduleEditor__dailyEndInput"]').forEach(function (input) {
            input.addEventListener('input', function () {
                updatePublishRuleSummary(block);
                syncPublishScheduleUi();
            });
            input.addEventListener('change', function () {
                updatePublishRuleSummary(block);
                syncPublishScheduleUi();
            });
        });
        block.querySelectorAll('[data-weekday]').forEach(function (checkbox) {
            checkbox.addEventListener('change', function () {
                updatePublishRuleSummary(block);
                syncPublishScheduleUi();
            });
        });
        block.querySelectorAll('[data-name="holiday"]').forEach(function (checkbox) {
            checkbox.addEventListener('change', function () {
                updatePublishRuleSummary(block);
                syncPublishScheduleUi();
            });
        });
        if (visibilityToggle) {
            visibilityToggle.addEventListener('change', function () {
                syncFormEditorItemPublicHidden(block);
                var label = visibilityToggle.closest('.c-publishScheduleEditorSummary01__visibility');
                if (label) {
                    label.title = visibilityToggle.checked ? '有効' : '無効';
                }
                syncPublishScheduleUi();
            });
        }
        syncFormEditorItemPublicHidden(block);
    }

    function createPublishRuleBlock(editor) {
        var template = getPublishRuleTemplate(editor);
        if (!template) return null;
        var block = template.content.firstElementChild.cloneNode(true);
        var idInput = block.querySelector('[data-name="id"]');
        var idPrefix = getPublishRuleIdPrefix(editor);
        if (idInput) {
            idInput.value = idPrefix + '-' + generateUuidV4();
        }
        bindPublishRuleBlock(editor, block);
        return block;
    }

    function syncRegexRowValue(row) {
        var sel = row.querySelector('[data-target="c-formEditor__regexKind"]');
        var hidden = row.querySelector('[data-target="c-formEditor__regexValue"]');
        var wrap = row.querySelector('.c-formEditor__regexCustom');
        var customInp = row.querySelector('[data-target="c-formEditor__regexCustomInput"]');
        var li = row.closest('.c-formEditor__item');
        var checkboxLimitEnabled = li ? li.querySelector('[data-target="c-formEditor__checkboxLimitEnabled"]') : null;
        var checkboxLimitSettings = li ? li.querySelector('.c-formEditor__checkboxLimit') : null;
        var checkboxMinInput = li ? li.querySelector('[data-name="checkbox_min_selections"], [name$="[checkbox_min_selections]"]') : null;
        var checkboxMaxInput = li ? li.querySelector('[data-name="checkbox_max_selections"], [name$="[checkbox_max_selections]"]') : null;
        if (!sel || !hidden) return;
        if (sel.value === FB_REGEX_CHECKBOX_LIMIT) {
            if (wrap) wrap.style.display = 'none';
            hidden.value = '';
            if (checkboxLimitEnabled) checkboxLimitEnabled.value = '1';
            if (checkboxLimitSettings) checkboxLimitSettings.style.display = '';
        } else if (sel.value === FB_REGEX_CUSTOM) {
            if (wrap) wrap.style.display = '';
            hidden.value = customInp ? customInp.value.trim() : '';
            if (checkboxLimitEnabled) checkboxLimitEnabled.value = '0';
            if (checkboxLimitSettings) checkboxLimitSettings.style.display = 'none';
            if (checkboxMinInput) checkboxMinInput.value = '';
            if (checkboxMaxInput) checkboxMaxInput.value = '';
        } else {
            if (wrap) wrap.style.display = 'none';
            hidden.value = sel.value;
            if (checkboxLimitEnabled) checkboxLimitEnabled.value = '0';
            if (checkboxLimitSettings) checkboxLimitSettings.style.display = 'none';
            if (checkboxMinInput) checkboxMinInput.value = '';
            if (checkboxMaxInput) checkboxMaxInput.value = '';
        }
    }

    function syncAllRegexRows() {
        getFieldItems().forEach(function (field) {
            field.querySelectorAll('.c-formEditor__regexRow').forEach(syncRegexRowValue);
        });
    }

    function syncBuilderForm(form) {
        if (!form) return;
        reindexBuilderScope(form);
        form.querySelectorAll('[data-choice-editor]').forEach(syncChoiceEditor);
        form.querySelectorAll('[data-text-multi-editor]').forEach(syncTextMultiEditor);
        form.querySelectorAll('.c-formEditor__regexRow').forEach(syncRegexRowValue);
    }

    function syncRegexOptionsForType(select, typeValue) {
        if (!select) return;
        Array.prototype.forEach.call(select.options, function (option) {
            var allow = true;
            if (typeValue === 'checkbox') {
                allow = option.value === '' || option.value === FB_REGEX_CUSTOM || option.value === FB_REGEX_CHECKBOX_LIMIT;
            } else if (typeValue === 'radio' || typeValue === 'select') {
                allow = option.value === '';
            }
            option.hidden = !allow;
            option.disabled = !allow;
        });
        if (typeValue === 'checkbox') {
            if (select.value !== '' && select.value !== FB_REGEX_CUSTOM && select.value !== FB_REGEX_CHECKBOX_LIMIT) {
                select.value = '';
            }
        } else if (typeValue === 'radio' || typeValue === 'select') {
            select.value = '';
        } else if (select.value === FB_REGEX_CHECKBOX_LIMIT) {
            select.value = '';
        }
    }

    function updateFieldSummary(li) {
        var labelInp = li.querySelector('[data-target="c-formEditor__labelInput"]');
        var typeSel = li.querySelector('[data-target="c-formEditor__type"]');
        var requiredToggle = li.querySelector('[data-target="c-formEditor__required"]');
        var visibilityToggle = li.querySelector('[data-name="visible"]');
        var regexKind = li.querySelector('[data-target="c-formEditor__regexKind"]');
        var regexCustom = li.querySelector('[data-target="c-formEditor__regexCustomInput"]');
        var labelEl = li.querySelector('[data-target="c-formEditor__summaryLabel"]');
        var typeEl = li.querySelector('[data-target="c-formEditor__summaryType"]');
        var requiredEl = li.querySelector('[data-target="c-formEditor__summaryRequired"]');
        var regexWrapEl = li.querySelector('[data-target="c-formEditor__summaryRegexWrap"]');
        var regexEl = li.querySelector('[data-target="c-formEditor__summaryRegex"]');
        var visibilityLabel = li.querySelector('.c-formEditorSummary01__visibility');
        if (!labelEl) return;
        labelEl.textContent = (labelInp && labelInp.value.trim()) ? labelInp.value.trim() : '（無題）';
        if (visibilityLabel && visibilityToggle) {
            visibilityLabel.title = visibilityToggle.checked ? '表示中' : '非表示';
        }
        if (!typeEl || !requiredEl || !regexEl || !regexWrapEl) return;
        var typeValue = typeSel ? typeSel.value : '';
        var typeLabel = typeSel ? (typeSel.getAttribute('data-type-label') || '') : '';
        typeEl.textContent = typeLabel || '—';
        if (isDisplayOnlyFieldType(typeValue)) {
            requiredEl.hidden = true;
            regexWrapEl.hidden = true;
            regexEl.textContent = 'なし';
            return;
        }
        var isRequired = !!(requiredToggle && requiredToggle.checked);
        requiredEl.textContent = '必須';
        requiredEl.hidden = !isRequired;
        var regexText = 'なし';
        if (!isRequired || !regexKind || regexKind.value === '' || typeValue === 'radio' || typeValue === 'select') {
            regexText = 'なし';
        } else if (regexKind.value === FB_REGEX_CHECKBOX_LIMIT) {
            regexText = '選択数';
        } else if (regexKind.value === FB_REGEX_CUSTOM) {
            if (!regexCustom || !regexCustom.value.trim()) {
                regexText = 'なし';
                regexEl.textContent = regexText;
                regexWrapEl.hidden = !isRequired || regexText === 'なし';
                return;
            }
            regexText = 'カスタム';
        } else {
            var regexOpt = regexKind.selectedOptions && regexKind.selectedOptions[0];
            regexText = regexOpt ? regexOpt.textContent.trim() : 'なし';
        }
        regexEl.textContent = regexText;
        regexWrapEl.hidden = !isRequired || regexText === 'なし';
    }

    function updateGroupSummary(group) {
        var labelInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__labelInput"]');
        var labelEl = group.querySelector('[data-target="c-formEditorGroup__summaryLabel"]');
        var visibilityToggle = queryOwnGroupControl(group, '[data-group-name="visible"]');
        var visibilityLabel = group.querySelector('.c-formEditorSummary01__visibility');
        if (labelEl) {
            labelEl.textContent = (labelInput && labelInput.value.trim()) ? labelInput.value.trim() : 'グループ';
        }
        if (visibilityLabel && visibilityToggle) {
            visibilityLabel.title = visibilityToggle.checked ? '表示中' : '非表示';
        }
    }

    function syncBranchGroupTargetKey(oldKey, newKey) {
        if (!oldKey || !newKey || oldKey === newKey) return;
        document.querySelectorAll('[data-branch-rule-row]').forEach(function (row) {
            var action = row.querySelector('[data-target="branchRuleActionType"]');
            var target = row.querySelector('[data-target="branchRuleTargetKey"]');
            var targetType = row.querySelector('[data-target="branchRuleTargetType"]');
            if (!target || !targetType) return;
            if (action && action.value !== 'show_field') return;
            if (targetType.value !== 'group') return;
            if (target.value !== oldKey && target.getAttribute('data-value') !== oldKey) return;
            target.value = newKey;
            target.setAttribute('data-value', newKey);
        });
    }

    function syncGroupKey(group) {
        var keyInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__groupKeyInput"]');
        var hiddenInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__groupKey"]');
        if (!keyInput || !hiddenInput) return;
        var oldKey = hiddenInput.value.trim() || group.getAttribute('data-group-key') || '';
        var newKey = keyInput.value.trim();
        hiddenInput.value = newKey;
        group.setAttribute('data-group-key', newKey);
        var childList = group.querySelector('[data-target="m-formBuilder01__fields"]');
        if (childList) {
            childList.setAttribute('data-parent-group-key', newKey);
        }
        if (oldKey && newKey && oldKey !== newKey) {
            syncBranchGroupTargetKey(oldKey, newKey);
        }
    }

    function bindGroupKeyLock(group) {
        var btn = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__groupKeyLock"]');
        var input = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__groupKeyInput"]');
        if (!btn || !input) return;
        var icClosed = btn.querySelector('[data-target="c-formEditorGroup__groupKeyLockedIcon"]');
        var icOpen = btn.querySelector('[data-target="c-formEditorGroup__groupKeyOpenIcon"]');

        function syncIcons() {
            var locked = input.readOnly;
            if (icClosed) icClosed.style.display = locked ? '' : 'none';
            if (icOpen) icOpen.style.display = locked ? 'none' : '';
            btn.setAttribute('aria-pressed', locked ? 'true' : 'false');
            btn.setAttribute('aria-label', locked ? 'UUIDを編集' : 'UUIDをロック');
            btn.setAttribute('title', locked ? '編集する' : 'ロックする');
            input.classList.toggle('is-locked', locked);
        }

        btn.addEventListener('click', function () {
            input.readOnly = !input.readOnly;
            syncIcons();
        });
        syncIcons();
    }

    function bindAccordion(li) {
        var header = li.querySelector('.c-formEditor__itemHeader');
        if (!header) return;

        header.addEventListener('click', function (e) {
            if (e.target.closest('.area.is-move') || e.target.closest('.area.is-delete') || e.target.closest('.c-formEditorSummary01__visibility')) {
                return;
            }
            li.classList.toggle('is-collapsed');
        });
    }

    function refreshFbSortable() {
        if (typeof jQuery === 'undefined') return;
        lists.forEach(function (targetList) {
            if (!targetList || targetList.dataset.fbSortable !== '1') return;
            try {
                jQuery(targetList).sortable('refresh');
            } catch (e1) {}
        });
    }

    function initFbSortable() {
        if (typeof jQuery === 'undefined' || !jQuery.fn.sortable) return;
        lists.forEach(function (targetList) {
            if (!targetList) return;
            if (targetList.dataset.fbSortable === '1') {
                try {
                    jQuery(targetList).sortable('refresh');
                } catch (e1) {}
                return;
            }
            jQuery(targetList).sortable({
                handle: '[data-target="c-formEditor__dragHandle"]',
                axis: 'y',
                items: '> .c-formEditor__item',
                placeholder: 'fb-sortable-placeholder',
                tolerance: 'pointer',
                cursor: 'grabbing',
                opacity: 0.88,
                scroll: true,
                scrollSensitivity: 48,
                scrollSpeed: 28,
                forcePlaceholderSize: true,
                delay: 0,
                distance: 4,
                zIndex: 9999,
                update: function () {
                    reindex();
                }
            });
            targetList.dataset.fbSortable = '1';
        });
    }

    window.formkunInitFbSortable = initFbSortable;

    function reindex() {
        var items = getFieldItems();
        items.forEach(function (li, i) {
            var parentList = li.closest('[data-target="m-formBuilder01__fields"]');
            var siblingItems = getBuilderItemsForList(parentList);
            var itemPosition = siblingItems.indexOf(li) + 1;
            setFieldInputPageKey(li, getPageKeyForList(parentList));
            setFieldParentGroupKey(li, getParentGroupKeyForList(parentList));
            li.querySelectorAll('input, textarea, select').forEach(function (el) {
                if (el.matches('[data-target="c-formEditor__regexCustomInput"]') ||
                    el.matches('[data-target="c-formEditor__regexKind"]') ||
                    el.matches('[data-target="c-formEditor__regexValue"]')) {
                    return;
                }
                var name = el.getAttribute('data-name') || extractDataName(el.getAttribute('name'));
                if (!name) return;
                el.setAttribute('name', 'fields[' + i + '][' + name + ']');
            });
            var rv = li.querySelector('[data-target="c-formEditor__regexValue"]');
            if (rv) {
                rv.setAttribute('name', 'fields[' + i + '][regex_pattern]');
            }
            var sortOrder = li.querySelector('[data-target="c-formEditor__sortOrder"]');
            if (sortOrder) {
                sortOrder.value = String(itemPosition || (i + 1));
            }
            var numEl = li.querySelector('[data-target="c-formEditor__summaryIndex"]');
            if (numEl) numEl.textContent = String(i + 1);
            updateFieldSummary(li);
            syncFormEditorItemPublicHidden(li);
        });
        getGroupItems().forEach(function (group, i) {
            var parentList = group.closest('[data-target="m-formBuilder01__fields"]');
            var siblingItems = getBuilderItemsForList(parentList);
            var itemPosition = siblingItems.indexOf(group) + 1;
            var pageKey = getPageKeyForList(parentList);
            var parentGroupKey = getParentGroupKeyForList(parentList);
            setGroupInputPageKey(group, pageKey);
            setGroupParentGroupKey(group, parentGroupKey);
            queryOwnGroupControls(group, 'input, textarea, select').forEach(function (el) {
                var groupName = el.getAttribute('data-group-name') || extractGroupName(el.getAttribute('name'));
                if (!groupName) return;
                el.setAttribute('name', 'field_groups[' + i + '][' + groupName + ']');
            });
            var sortOrder = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__sortOrder"]');
            if (sortOrder) {
                sortOrder.value = String(itemPosition || (i + 1));
            }
            var summaryIndex = group.querySelector('[data-target="c-formEditorGroup__summaryIndex"]');
            if (summaryIndex) summaryIndex.textContent = String(itemPosition || (i + 1));
            updateGroupSummary(group);
            syncFormEditorItemPublicHidden(group);
        });
        syncAllRegexRows();
        refreshAllDescriptionPositionOptions();
        queueDirtyState();
    }

    function reindexBuilderScope(root) {
        if (!root) return;
        var items = Array.prototype.slice.call(root.querySelectorAll('[data-target="m-formBuilder01__fields"] .c-formEditor__item[data-field-item="1"]'));
        items.forEach(function (li, i) {
            var parentList = li.closest('[data-target="m-formBuilder01__fields"]');
            var siblingItems = getBuilderItemsForList(parentList);
            var itemPosition = siblingItems.indexOf(li) + 1;
            setFieldInputPageKey(li, getPageKeyForList(parentList));
            setFieldParentGroupKey(li, getParentGroupKeyForList(parentList));
            li.querySelectorAll('input, textarea, select').forEach(function (el) {
                if (el.matches('[data-target="c-formEditor__regexCustomInput"]') ||
                    el.matches('[data-target="c-formEditor__regexKind"]') ||
                    el.matches('[data-target="c-formEditor__regexValue"]')) {
                    return;
                }
                var name = el.getAttribute('data-name') || extractDataName(el.getAttribute('name'));
                if (!name) return;
                el.setAttribute('name', 'fields[' + i + '][' + name + ']');
            });
            var rv = li.querySelector('[data-target="c-formEditor__regexValue"]');
            if (rv) {
                rv.setAttribute('name', 'fields[' + i + '][regex_pattern]');
            }
            var sortOrder = li.querySelector('[data-target="c-formEditor__sortOrder"]');
            if (sortOrder) {
                sortOrder.value = String(itemPosition || (i + 1));
            }
            var numEl = li.querySelector('[data-target="c-formEditor__summaryIndex"]');
            if (numEl) numEl.textContent = String(i + 1);
            updateFieldSummary(li);
            syncFormEditorItemPublicHidden(li);
        });
        var groups = Array.prototype.slice.call(root.querySelectorAll('[data-target="m-formBuilder01__fields"] .c-formEditor__item[data-group-item="1"]'));
        groups.forEach(function (group, i) {
            var parentList = group.closest('[data-target="m-formBuilder01__fields"]');
            var siblingItems = getBuilderItemsForList(parentList);
            var itemPosition = siblingItems.indexOf(group) + 1;
            var pageKey = getPageKeyForList(parentList);
            var parentGroupKey = getParentGroupKeyForList(parentList);
            setGroupInputPageKey(group, pageKey);
            setGroupParentGroupKey(group, parentGroupKey);
            queryOwnGroupControls(group, 'input, textarea, select').forEach(function (el) {
                var groupName = el.getAttribute('data-group-name') || extractGroupName(el.getAttribute('name'));
                if (!groupName) return;
                el.setAttribute('name', 'field_groups[' + i + '][' + groupName + ']');
            });
            var sortOrder = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__sortOrder"]');
            if (sortOrder) {
                sortOrder.value = String(itemPosition || (i + 1));
            }
            var summaryIndex = group.querySelector('[data-target="c-formEditorGroup__summaryIndex"]');
            if (summaryIndex) summaryIndex.textContent = String(itemPosition || (i + 1));
            updateGroupSummary(group);
            syncFormEditorItemPublicHidden(group);
        });
    }

    function bindRegexRow(row, li) {
        var sel = row.querySelector('[data-target="c-formEditor__regexKind"]');
        var customInp = row.querySelector('[data-target="c-formEditor__regexCustomInput"]');
        if (sel) {
            sel.addEventListener('change', function () {
                syncRegexRowValue(row);
                if (li) updateFieldSummary(li);
            });
        }
        if (customInp) {
            customInp.addEventListener('input', function () {
                syncRegexRowValue(row);
                if (li) updateFieldSummary(li);
            });
        }
        syncRegexRowValue(row);
    }

    function bindRegexBlock(li) {
        var row = li.querySelector('.c-formEditor__regexRow');
        if (row) {
            bindRegexRow(row, li);
        }
    }

    function syncChoiceEditor(box) {
        var source = box.querySelector('[data-target="c-formEditor__optionsSource"]');
        if (!source) return;
        var values = [];
        box.querySelectorAll('[data-target="c-formEditor__choiceInput"]').forEach(function (input) {
            var value = input.value.trim();
            if (value !== '') {
                values.push(value);
            }
        });
        source.value = values.join('\n');
        var item = box.closest ? box.closest('[data-field-item="1"]') : null;
        if (item) {
            syncRadioDefaultOptions(item);
        }
    }

    function getRadioDefaultSettingsMountPoint(li) {
        var displaySettings = li.querySelector('[data-target="c-formEditor__displaySettings"]');
        if (displaySettings && displaySettings.parentNode) {
            return displaySettings;
        }
        var optionsBox = li.querySelector('[data-target="c-formEditor__options"]');
        if (optionsBox) {
            var parent = optionsBox.closest('.block.is-contents');
            if (parent && parent.parentNode) {
                return parent.nextElementSibling;
            }
        }
        return null;
    }

    function persistRadioDefaultValue(li) {
        var select = li.querySelector('[data-target="c-formEditor__radioDefaultValue"]');
        if (!select) return;
        var value = select.getAttribute('data-value') || select.value || '';
        li.dataset.fbPendingRadioDefault = value;
    }

    function ensureRadioDefaultSettings(li, show) {
        var block = li.querySelector('[data-target="c-formEditor__radioDefaultSettings"]');
        if (!show) {
            if (block) {
                persistRadioDefaultValue(li);
                block.remove();
            }
            return;
        }
        if (block) return;
        if (!radioDefaultSettingsTemplate || !radioDefaultSettingsTemplate.content || !radioDefaultSettingsTemplate.content.firstElementChild) {
            return;
        }
        var mountBefore = getRadioDefaultSettingsMountPoint(li);
        if (!mountBefore || !mountBefore.parentNode) return;
        var clone = radioDefaultSettingsTemplate.content.firstElementChild.cloneNode(true);
        mountBefore.parentNode.insertBefore(clone, mountBefore);
        var select = clone.querySelector('[data-target="c-formEditor__radioDefaultValue"]');
        if (select && li.dataset.fbPendingRadioDefault !== undefined) {
            select.setAttribute('data-value', li.dataset.fbPendingRadioDefault);
        }
        syncRadioDefaultOptions(li);
    }

    function syncRadioDefaultOptions(li) {
        var select = li.querySelector('[data-target="c-formEditor__radioDefaultValue"]');
        if (!select) return;
        var current = select.getAttribute('data-value') || select.value || '';
        var options = [];
        li.querySelectorAll('[data-target="c-formEditor__choiceInput"]').forEach(function (input) {
            var value = input.value.trim();
            if (value !== '' && options.indexOf(value) === -1) {
                options.push(value);
            }
        });
        select.innerHTML = '';
        var emptyOption = document.createElement('option');
        emptyOption.value = '';
        emptyOption.textContent = '設定しない';
        select.appendChild(emptyOption);
        options.forEach(function (value) {
            var option = document.createElement('option');
            option.value = value;
            option.textContent = value;
            select.appendChild(option);
        });
        select.value = options.indexOf(current) !== -1 ? current : '';
        select.setAttribute('data-value', select.value);
    }

    function refreshChoiceSortable(box) {
        var list = box.querySelector('[data-target="c-formEditor__choiceListContents"]');
        if (!list || list.dataset.fbSortable !== '1' || typeof jQuery === 'undefined') return;
        try {
            jQuery(list).sortable('refresh');
        } catch (e1) {}
    }

    function initChoiceSortable(box) {
        var list = box.querySelector('[data-target="c-formEditor__choiceListContents"]');
        if (!list || typeof jQuery === 'undefined' || !jQuery.fn.sortable) return;
        if (list.dataset.fbSortable === '1') {
            refreshChoiceSortable(box);
            return;
        }
        jQuery(list).sortable({
            handle: '[data-target="c-formEditor__choiceDragHandle"]',
            axis: 'y',
            items: '> .area.is-contents:not([data-target="c-formEditor__choiceControls"])',
            placeholder: 'fb-sortable-placeholder',
            tolerance: 'pointer',
            cursor: 'grabbing',
            opacity: 0.88,
            scroll: true,
            scrollSensitivity: 48,
            scrollSpeed: 28,
            forcePlaceholderSize: true,
            delay: 0,
            distance: 4,
            zIndex: 9999,
            update: function () {
                syncChoiceEditor(box);
            }
        });
        list.dataset.fbSortable = '1';
    }

    function createChoiceItem(value) {
        var area = document.createElement('div');
        area.className = 'area is-contents';
        var row = document.createElement('div');
        row.className = 'c-formEditor__choiceItem';
        row.setAttribute('data-choice-item', '');
        row.innerHTML =
            '<div class="wrapper">' +
                '<div class="block is-contents">' +
                    '<div class="area is-move">' +
                        '<div class="box is-handle ui-sortable-handle" title="ドラッグして並べ替え">' +
                            '<p data-module="m-dragHandle01" data-target="c-formEditor__choiceDragHandle">' +
                        '<svg width="14" height="18" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="currentColor"><circle cx="9" cy="6" r="2"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="9" cy="18" r="2"/><circle cx="15" cy="18" r="2"/></svg>' +
                            '</p>' +
                        '</div>' +
                    '</div>' +
                    '<div class="c-formEditor__child__field">' +
                        '<div class="wrapper">' +
                            '<div class="block is-contents">' +
                                '<div class="area is-field"><div data-module="m-input01"><input type="text" data-target="c-formEditor__choiceInput" placeholder="選択肢"></div></div>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                    '<button type="button" data-module="m-deleteBtn01" data-target="c-formEditor__choiceRemove" aria-label="削除" title="削除">' +
                        '<svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 6h18"></path><path stroke-linecap="round" stroke-linejoin="round" d="M8 6V4h8v2"></path><path stroke-linecap="round" stroke-linejoin="round" d="M19 6l-1 14H6L5 6"></path><path stroke-linecap="round" stroke-linejoin="round" d="M10 11v6M14 11v6"></path></svg>' +
                    '</button>' +
                '</div>' +
            '</div>';
        area.appendChild(row);
        var input = row.querySelector('[data-target="c-formEditor__choiceInput"]');
        if (input) {
            input.value = value || '';
        }
        return area;
    }

    function bindChoiceItem(item, box) {
        var input = item.querySelector('[data-target="c-formEditor__choiceInput"]');
        var remove = item.querySelector('[data-target="c-formEditor__choiceRemove"]');
        if (input) {
            input.addEventListener('input', function () {
                syncChoiceEditor(box);
            });
            input.addEventListener('change', function () {
                syncChoiceEditor(box);
            });
        }
        if (remove) {
            remove.addEventListener('click', function () {
                var area = item.parentNode;
                if (!area || !area.parentNode) return;
                area.parentNode.removeChild(area);
                syncChoiceEditor(box);
                refreshChoiceSortable(box);
            });
        }
    }

    function bindChoiceEditor(li) {
        li.querySelectorAll('[data-choice-editor]').forEach(function (box) {
            var list = box.querySelector('[data-target="c-formEditor__choiceListContents"]');
            var add = box.querySelector('[data-target="c-formEditor__choiceAdd"]');
            if (!list || !add) return;
            list.querySelectorAll('[data-choice-item]').forEach(function (item) {
                bindChoiceItem(item, box);
            });
            initChoiceSortable(box);
            add.addEventListener('click', function () {
                var item = createChoiceItem('');
                var controls = box.querySelector('[data-target="c-formEditor__choiceControls"]');
                if (controls) {
                    list.insertBefore(item, controls);
                } else {
                    list.appendChild(item);
                }
                bindChoiceItem(item.querySelector('[data-choice-item]'), box);
                syncChoiceEditor(box);
                refreshChoiceSortable(box);
                var input = item.querySelector('[data-target="c-formEditor__choiceInput"]');
                if (input) input.focus();
            });
            syncChoiceEditor(box);
        });
    }

    function syncTextMultiEditor(box) {
        var source = box.querySelector('[data-target="c-formEditor__textMultiSource"]');
        if (!source) return;
        var items = [];
        box.querySelectorAll('[data-text-multi-item]').forEach(function (item) {
            var labelInput = item.querySelector('[data-target="c-formEditor__textMultiLabelInput"]');
            var placeholderInput = item.querySelector('[data-target="c-formEditor__textMultiPlaceholderInput"]');
            var defaultValueInput = item.querySelector('[data-target="c-formEditor__textMultiDefaultValueInput"]');
            items.push({
                label: labelInput ? labelInput.value.trim() : '',
                placeholder: placeholderInput ? placeholderInput.value.trim() : '',
                default_value: defaultValueInput ? defaultValueInput.value : ''
            });
        });
        source.value = JSON.stringify(items);
    }

    function createTextMultiItem(data) {
        var area = document.createElement('div');
        area.className = 'area is-contents';
        var item = document.createElement('div');
        item.className = 'c-formEditor__textMultiItem';
        item.setAttribute('data-text-multi-item', '');
        item.innerHTML =
            '<div class="wrapper">' +
                '<div class="block is-contents">' +
                    '<div class="c-formEditor__child__field">' +
                        '<div class="wrapper">' +
                            '<div class="block is-contents">' +
                                '<div class="area is-title"><label data-module="m-labelSmallTitle01">表示名</label></div>' +
                                '<div class="area is-field"><div data-module="m-input01"><input type="text" data-target="c-formEditor__textMultiLabelInput"></div></div>' +
                            '</div>' +
                            '<div class="block is-contents">' +
                                '<div class="area is-title"><label data-module="m-labelSmallTitle01">入力例</label></div>' +
                                '<div class="area is-field"><div data-module="m-input01"><input type="text" data-target="c-formEditor__textMultiPlaceholderInput"></div></div>' +
                            '</div>' +
                            '<div class="block is-contents">' +
                                '<div class="area is-title"><label data-module="m-labelSmallTitle01">初期値</label></div>' +
                                '<div class="area is-field"><div data-module="m-input01"><input type="text" data-target="c-formEditor__textMultiDefaultValueInput"></div></div>' +
                            '</div>' +
                        '</div>' +
                    '</div>' +
                    '<button type="button" data-module="m-deleteBtn01" data-target="c-formEditor__textMultiRemove" aria-label="削除" title="削除">' +
                        '<svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M3 6h18"/><path stroke-linecap="round" stroke-linejoin="round" d="M8 6V4h8v2"/><path stroke-linecap="round" stroke-linejoin="round" d="M19 6l-1 14H6L5 6"/><path stroke-linecap="round" stroke-linejoin="round" d="M10 11v6M14 11v6"/></svg>' +
                    '</button>' +
                '</div>' +
            '</div>';
        area.appendChild(item);
        var labelInput = item.querySelector('[data-target="c-formEditor__textMultiLabelInput"]');
        var placeholderInput = item.querySelector('[data-target="c-formEditor__textMultiPlaceholderInput"]');
        var defaultValueInput = item.querySelector('[data-target="c-formEditor__textMultiDefaultValueInput"]');
        if (labelInput) {
            labelInput.value = data && typeof data.label === 'string' ? data.label : '';
        }
        if (placeholderInput) {
            placeholderInput.value = data && typeof data.placeholder === 'string' ? data.placeholder : '';
        }
        if (defaultValueInput) {
            defaultValueInput.value = data && typeof data.default_value === 'string' ? data.default_value : '';
        }
        return area;
    }

    function bindTextMultiItem(item, box) {
        var labelInput = item.querySelector('[data-target="c-formEditor__textMultiLabelInput"]');
        var placeholderInput = item.querySelector('[data-target="c-formEditor__textMultiPlaceholderInput"]');
        var defaultValueInput = item.querySelector('[data-target="c-formEditor__textMultiDefaultValueInput"]');
        var remove = item.querySelector('[data-target="c-formEditor__textMultiRemove"]');

        function sync() {
            syncTextMultiEditor(box);
        }

        if (labelInput) {
            labelInput.addEventListener('input', sync);
            labelInput.addEventListener('change', sync);
        }
        if (placeholderInput) {
            placeholderInput.addEventListener('input', sync);
            placeholderInput.addEventListener('change', sync);
        }
        if (defaultValueInput) {
            defaultValueInput.addEventListener('input', sync);
            defaultValueInput.addEventListener('change', sync);
        }
        if (remove) {
            remove.addEventListener('click', function () {
                var area = item.parentNode;
                if (!area) return;
                var list = area.parentNode;
                if (!list) return;
                if (list.querySelectorAll('[data-text-multi-item]').length <= 1) {
                    alert('入力欄は1つ以上必要です。');
                    return;
                }
                list.removeChild(area);
                syncTextMultiEditor(box);
            });
        }
    }

    function bindTextMultiEditor(li) {
        li.querySelectorAll('[data-text-multi-editor]').forEach(function (box) {
            var list = box.querySelector('[data-target="c-formEditor__textMultiListContents"]');
            var add = box.querySelector('[data-target="c-formEditor__textMultiAdd"]');
            if (!list || !add) return;
            list.querySelectorAll('[data-text-multi-item]').forEach(function (item) {
                bindTextMultiItem(item, box);
            });
            add.addEventListener('click', function () {
                var item = createTextMultiItem();
                var controls = box.querySelector('[data-target="c-formEditor__textMultiControls"]');
                if (controls) {
                    list.insertBefore(item, controls);
                } else {
                    list.appendChild(item);
                }
                bindTextMultiItem(item.querySelector('[data-text-multi-item]'), box);
                syncTextMultiEditor(box);
                var labelInput = item.querySelector('[data-target="c-formEditor__textMultiLabelInput"]');
                if (labelInput) labelInput.focus();
            });
            syncTextMultiEditor(box);
        });
    }

    function bindFieldKeyLock(li) {
        var btn = li.querySelector('[data-target="c-formEditor__fieldKeyLock"]');
        var input = li.querySelector('[data-target="c-formEditor__fieldKeyInput"]');
        if (!btn || !input) return;
        var icClosed = btn.querySelector('[data-target="c-formEditor__fieldKeyLockedIcon"]');
        var icOpen = btn.querySelector('[data-target="c-formEditor__fieldKeyOpenIcon"]');

        function syncIcons() {
            var locked = input.readOnly;
            if (icClosed) icClosed.style.display = locked ? '' : 'none';
            if (icOpen) icOpen.style.display = locked ? 'none' : '';
            btn.setAttribute('aria-pressed', locked ? 'true' : 'false');
            btn.setAttribute('aria-label', locked ? 'キーを編集' : 'キーをロック');
            btn.setAttribute('title', locked ? '編集する' : 'ロックする');
            input.classList.toggle('is-locked', locked);
        }

        btn.addEventListener('click', function () {
            input.readOnly = !input.readOnly;
            syncIcons();
        });
        syncIcons();
    }

    function setFieldKeyValue(li, fieldKey) {
        var input = li ? li.querySelector('[data-target="c-formEditor__fieldKeyInput"]') : null;
        if (!input) return;
        input.value = fieldKey || '';
        input.readOnly = true;
        input.classList.add('is-locked');
    }

    function setGroupKeyValue(group, groupKey) {
        var keyInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__groupKeyInput"]');
        var hiddenInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__groupKey"]');
        if (keyInput) {
            keyInput.value = groupKey || '';
            keyInput.readOnly = true;
            keyInput.classList.add('is-locked');
        }
        if (hiddenInput) {
            hiddenInput.value = groupKey || '';
        }
        if (group) {
            group.setAttribute('data-group-key', groupKey || '');
        }
        var childList = group ? group.querySelector('[data-target="m-formBuilder01__fields"]') : null;
        if (childList) {
            childList.setAttribute('data-parent-group-key', groupKey || '');
        }
    }

    function remapFieldReferenceValues(root, fieldKeyMap) {
        if (!root) return;
        root.querySelectorAll('[data-target="c-formEditor__postalCodePrefectureTarget"], [data-target="c-formEditor__postalCodeCityTarget"]').forEach(function (input) {
            var current = input.value.trim();
            if (current && fieldKeyMap[current]) {
                input.value = fieldKeyMap[current];
            }
        });
    }

    function duplicateFieldItem(li) {
        if (!li) return null;
        var parentList = li.closest('[data-target="m-formBuilder01__fields"]');
        if (!parentList) return null;
        var clone = li.cloneNode(true);
        copyControlValues(li, clone);
        resetClonedBuilderState(clone);
        var originalKeyInput = li.querySelector('[data-target="c-formEditor__fieldKeyInput"]');
        var originalKey = originalKeyInput ? originalKeyInput.value.trim() : '';
        var newKey = generateUuidV4();
        var fieldKeyMap = {};
        if (originalKey) {
            fieldKeyMap[originalKey] = newKey;
        }
        setFieldKeyValue(clone, newKey);
        remapFieldReferenceValues(clone, fieldKeyMap);
        setFieldInputPageKey(clone, getPageKeyForList(parentList));
        setFieldParentGroupKey(clone, getParentGroupKeyForList(parentList));
        insertAfter(li, clone);
        bind(clone);
        reindex();
        refreshBuilderListSortable(parentList);
        document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
        syncInputModuleStates(clone);
        var labelInput = clone.querySelector('[data-target="c-formEditor__labelInput"]');
        if (labelInput) {
            labelInput.focus();
        }
        return clone;
    }

    function getGroupNodesIncludingSelf(group) {
        if (!group) return [];
        return [group].concat(Array.prototype.slice.call(group.querySelectorAll('.c-formEditor__item[data-group-item="1"]')));
    }

    function duplicateGroupItem(group) {
        if (!group) return null;
        var parentList = group.closest('[data-target="m-formBuilder01__fields"]');
        if (!parentList) return null;
        var clone = group.cloneNode(true);
        copyControlValues(group, clone);
        resetClonedBuilderState(clone);

        var pageKey = getPageKeyForList(parentList);
        var rootParentGroupKey = getParentGroupKeyForList(parentList);
        var groupKeyMap = {};
        var fieldKeyMap = {};

        getGroupNodesIncludingSelf(clone).forEach(function (groupNode) {
            var hiddenGroupKey = queryOwnGroupControl(groupNode, '[data-target="c-formEditorGroup__groupKey"]');
            var oldGroupKey = hiddenGroupKey ? hiddenGroupKey.value.trim() : (groupNode.getAttribute('data-group-key') || '').trim();
            var newGroupKey = generateUuidV4();
            if (oldGroupKey) {
                groupKeyMap[oldGroupKey] = newGroupKey;
            }
            setGroupKeyValue(groupNode, newGroupKey);
            setGroupInputPageKey(groupNode, pageKey);
        });

        clone.querySelectorAll('.c-formEditor__item[data-field-item="1"]').forEach(function (fieldNode) {
            var fieldKeyInput = fieldNode.querySelector('[data-target="c-formEditor__fieldKeyInput"]');
            var oldFieldKey = fieldKeyInput ? fieldKeyInput.value.trim() : '';
            var newFieldKey = generateUuidV4();
            if (oldFieldKey) {
                fieldKeyMap[oldFieldKey] = newFieldKey;
            }
            setFieldKeyValue(fieldNode, newFieldKey);
            setFieldInputPageKey(fieldNode, pageKey);
        });

        getGroupNodesIncludingSelf(clone).forEach(function (groupNode, index) {
            var parentInput = queryOwnGroupControl(groupNode, '[data-target="c-formEditorGroup__parentGroupKey"]');
            var oldParentKey = parentInput ? parentInput.value.trim() : '';
            var nextParentKey = index === 0 ? rootParentGroupKey : (groupKeyMap[oldParentKey] || oldParentKey);
            setGroupParentGroupKey(groupNode, nextParentKey);
        });

        clone.querySelectorAll('.c-formEditor__item[data-field-item="1"]').forEach(function (fieldNode) {
            var parentInput = fieldNode.querySelector('[data-target="c-formEditor__parentGroupKey"]');
            var oldParentKey = parentInput ? parentInput.value.trim() : '';
            setFieldParentGroupKey(fieldNode, groupKeyMap[oldParentKey] || oldParentKey);
        });

        remapFieldReferenceValues(clone, fieldKeyMap);

        insertAfter(group, clone);
        bindGroup(clone);
        clone.querySelectorAll('.c-formEditor__item[data-group-item="1"]').forEach(bindGroup);
        clone.querySelectorAll('.c-formEditor__item[data-field-item="1"]').forEach(bind);
        clone.querySelectorAll('[data-target="m-formBuilder01__add"]').forEach(function (button) {
            bindAddButton(button);
        });
        reindex();
        refreshBuilderListSortable(parentList);
        document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
        syncInputModuleStates(clone);
        var labelInput = queryOwnGroupControl(clone, '[data-target="c-formEditorGroup__labelInput"]');
        if (labelInput) {
            labelInput.focus();
        }
        return clone;
    }

    function deriveLengthLimitMode(data) {
        if (!data) return '';
        if (data.exact_length) return 'exact';
        if (data.min_length || data.max_length) return 'range';
        return '';
    }

    function syncLengthLimitMode(li) {
        var wrap = li ? li.querySelector('[data-target="c-formEditor__minMaxLength"]') : null;
        if (!wrap) return;
        var modeSelect = wrap.querySelector('[data-name="length_limit_mode"], [name$="[length_limit_mode]"]');
        var rangeWrap = wrap.querySelector('[data-target="c-formEditor__lengthRange"]');
        var exactWrap = wrap.querySelector('[data-target="c-formEditor__lengthExact"]');
        var mode = modeSelect ? String(modeSelect.value || '') : '';
        if (rangeWrap) {
            rangeWrap.style.display = mode === 'range' ? '' : 'none';
        }
        if (exactWrap) {
            exactWrap.style.display = mode === 'exact' ? '' : 'none';
        }
    }

    function clearLengthLimitValuesByMode(li, mode) {
        var wrap = li ? li.querySelector('[data-target="c-formEditor__minMaxLength"]') : null;
        if (!wrap) return;
        var minLengthInput = wrap.querySelector('[data-name="min_length"], [name$="[min_length]"]');
        var maxLengthInput = wrap.querySelector('[data-name="max_length"], [name$="[max_length]"]');
        var exactLengthInput = wrap.querySelector('[data-name="exact_length"], [name$="[exact_length]"]');
        if (mode === 'exact') {
            if (minLengthInput) minLengthInput.value = '';
            if (maxLengthInput) maxLengthInput.value = '';
        } else if (mode === 'range') {
            if (exactLengthInput) exactLengthInput.value = '';
        } else {
            if (minLengthInput) minLengthInput.value = '';
            if (maxLengthInput) maxLengthInput.value = '';
            if (exactLengthInput) exactLengthInput.value = '';
        }
    }

    function bind(li) {
        var typeSelect = li.querySelector('[data-target="c-formEditor__type"]');
        var requiredToggle = li.querySelector('[data-target="c-formEditor__required"]');
        var optionsBox = li.querySelector('[data-target="c-formEditor__options"]');
        var inputSettings = li.querySelector('[data-target="c-formEditor__inputSettings"]');
        var displaySettings = li.querySelector('[data-target="c-formEditor__displaySettings"]');
        var textMultiSettings = li.querySelector('[data-target="c-formEditor__textMultiSettings"]');
        var postalCodeSettings = li.querySelector('[data-target="c-formEditor__postalCodeSettings"]');
        var fileSettings = li.querySelector('[data-target="c-formEditor__fileSettings"]');
        var fileTypeModeInputs = li.querySelectorAll('[data-target="c-formEditor__fileTypeMode"]');
        var fileAllowedExtensionsWrap = li.querySelector('[data-target="c-formEditor__fileAllowedExtensionsWrap"]');
        var fileConvertToJpegWrap = li.querySelector('[data-target="c-formEditor__fileConvertToJpegWrap"]');
        var matrixSettings = li.querySelector('[data-target="c-formEditor__matrixSettings"]');
        var defaultValueSettings = li.querySelector('[data-target="c-formEditor__defaultValueSettings"]');
        var dateDefaultSettings = li.querySelector('[data-target="c-formEditor__dateDefaultSettings"]');
        var timeDefaultSettings = li.querySelector('[data-target="c-formEditor__timeDefaultSettings"]');
        var helpTextBlock = li.querySelector('[data-target="c-formEditor__helpTextBlock"]');
        var helpTextTitle = li.querySelector('[data-target="c-formEditor__helpTextTitle"]');
        var helpTextLabel = li.querySelector('[data-target="c-formEditor__helpTextLabel"]');
        var headingTextWrap = li.querySelector('[data-target="c-formEditor__headingTextWrap"]');
        var headingTextInput = li.querySelector('[data-target="c-formEditor__headingTextInput"]');
        var helpTextEditor = li.querySelector('[data-target="c-formEditor__helpTextEditor"]');
        var helpTextToolbar = li.querySelector('[data-target="c-formEditor__helpTextToolbar"]');
        var helpTextTextarea = helpTextEditor ? helpTextEditor.querySelector('[data-target="c-htmlInputEditor01__textarea"]') : null;
        var helpTextToggle = helpTextEditor ? helpTextEditor.querySelector('[data-target="c-htmlInputEditor01__toggle"]') : null;
        var maxLengthWrap = li.querySelector('[data-target="c-formEditor__minMaxLength"]');
        var maxLengthInput = maxLengthWrap ? maxLengthWrap.querySelector('[data-name="max_length"], [name$="[max_length]"]') : null;
        var minLengthInput = maxLengthWrap ? maxLengthWrap.querySelector('[data-name="min_length"], [name$="[min_length]"]') : null;
        var exactLengthInput = maxLengthWrap ? maxLengthWrap.querySelector('[data-name="exact_length"], [name$="[exact_length]"]') : null;
        var lengthLimitModeSelect = maxLengthWrap ? maxLengthWrap.querySelector('[data-name="length_limit_mode"], [name$="[length_limit_mode]"]') : null;
        var regexWrap = li.querySelector('[data-target="c-formEditor__regex"]');
        var regexKind = regexWrap ? regexWrap.querySelector('[data-target="c-formEditor__regexKind"]') : null;
        var visibilityToggle = li.querySelector('[data-name="visible"]');
        var placeholderWrap = li.querySelector('[data-target="c-formEditor__placeholder"]');
        var placeholderInput = placeholderWrap ? placeholderWrap.querySelector('input') : null;
        var checkboxLimitEnabled = li.querySelector('[data-target="c-formEditor__checkboxLimitEnabled"]');
        var checkboxLimitSettings = li.querySelector('.c-formEditor__checkboxLimit');
        var checkboxMinInput = li.querySelector('[data-name="checkbox_min_selections"], [name$="[checkbox_min_selections]"]');
        var checkboxMaxInput = li.querySelector('[data-name="checkbox_max_selections"], [name$="[checkbox_max_selections]"]');
        function clearRegexSettings() {
            if (!regexWrap) return;
            var regexCustom = regexWrap.querySelector('[data-target="c-formEditor__regexCustomInput"]');
            var regexValue = regexWrap.querySelector('[data-target="c-formEditor__regexValue"]');
            if (regexKind) regexKind.value = '';
            if (regexCustom) regexCustom.value = '';
            if (regexValue) regexValue.value = '';
            var regexRow = regexWrap.querySelector('.c-formEditor__regexRow');
            if (regexRow) {
                syncRegexRowValue(regexRow);
            }
        }
        function clearCheckboxLimitSettings() {
            if (checkboxLimitEnabled) checkboxLimitEnabled.value = '0';
            if (checkboxLimitSettings) checkboxLimitSettings.style.display = 'none';
            if (checkboxMinInput) checkboxMinInput.value = '';
            if (checkboxMaxInput) checkboxMaxInput.value = '';
        }
        function currentFileTypeMode() {
            var checked = Array.prototype.find.call(fileTypeModeInputs || [], function (input) {
                return input.checked;
            });
            return checked ? String(checked.value || '') : 'custom';
        }
        function syncFileSettingsUi(isFileType) {
            var isImageMode = isFileType && currentFileTypeMode() === 'image';
            if (fileAllowedExtensionsWrap) {
                fileAllowedExtensionsWrap.style.display = isFileType && !isImageMode ? '' : 'none';
            }
            if (fileConvertToJpegWrap) {
                fileConvertToJpegWrap.style.display = isImageMode ? '' : 'none';
            }
        }
        function syncTypeSpecificUi() {
            if (!typeSelect) return;
            var v = typeSelect.value;
            var isDisplayOnly = isDisplayOnlyFieldType(v);
            var isHeading = v === 'heading';
            var isDescription = v === 'description';
            var hideMaxLength = isDisplayOnly || (v === 'radio' || v === 'checkbox' || v === 'select' || v === 'file' || v === 'matrix' || v === 'postal_code');
            if (inputSettings) {
                inputSettings.style.display = isDisplayOnly ? 'none' : '';
            }
            if (displaySettings) {
                displaySettings.style.display = (!isDisplayOnly || isHeading || isDescription) ? '' : 'none';
            }
            if (helpTextTitle) {
                helpTextTitle.style.display = isDescription ? 'none' : '';
            }
            if (helpTextLabel) {
                helpTextLabel.textContent = isHeading ? '見出し' : '説明文';
            }
            if (helpTextBlock) {
                helpTextBlock.style.display = (isDisplayOnly && !isHeading && !isDescription) ? 'none' : '';
            }
            if (headingTextWrap) {
                headingTextWrap.style.display = isHeading ? '' : 'none';
            }
            if (headingTextInput) {
                if (isHeading && helpTextTextarea && !headingTextInput.value && helpTextTextarea.value) {
                    headingTextInput.value = helpTextTextarea.value;
                }
                headingTextInput.disabled = !isHeading;
            }
            if (helpTextEditor) {
                helpTextEditor.style.display = isHeading ? 'none' : '';
            }
            if (helpTextToolbar) {
                helpTextToolbar.style.display = isHeading ? 'none' : '';
            }
            if (helpTextTextarea) {
                if (!isHeading && headingTextInput && !helpTextTextarea.value && headingTextInput.value) {
                    helpTextTextarea.value = headingTextInput.value;
                }
                helpTextTextarea.disabled = isHeading;
            }
            if (helpTextToggle) {
                if (isHeading) helpTextToggle.checked = false;
                helpTextToggle.disabled = isHeading;
            }
            if (isDisplayOnly && requiredToggle) {
                requiredToggle.checked = false;
            }
            if (optionsBox) {
                optionsBox.style.display = (!isDisplayOnly && (v === 'radio' || v === 'checkbox' || v === 'select')) ? '' : 'none';
            }
            if (maxLengthWrap) {
                maxLengthWrap.style.display = hideMaxLength ? 'none' : '';
                if (hideMaxLength) {
                    if (maxLengthInput) maxLengthInput.value = '';
                    if (minLengthInput) minLengthInput.value = '';
                    if (exactLengthInput) exactLengthInput.value = '';
                    if (lengthLimitModeSelect) lengthLimitModeSelect.value = '';
                    syncLengthLimitMode(li);
                }
            }
            if (regexKind) {
                syncRegexOptionsForType(regexKind, v);
                var regexRow = regexWrap ? regexWrap.querySelector('.c-formEditor__regexRow') : null;
                if (regexRow) {
                    syncRegexRowValue(regexRow);
                }
            }
            if (regexWrap) {
                var hideRegex = isDisplayOnly || v === 'file' || v === 'matrix' || v === 'postal_code';
                regexWrap.style.display = hideRegex ? 'none' : '';
                var isRequiredChecked = requiredToggle && requiredToggle.checked;
                if (regexKind) {
                    regexKind.disabled = !isRequiredChecked || hideRegex;
                }
                var regexCustomInput = regexWrap ? regexWrap.querySelector('[data-target="c-formEditor__regexCustomInput"]') : null;
                if (regexCustomInput) {
                    regexCustomInput.disabled = !isRequiredChecked || hideRegex;
                }
                if (hideRegex) {
                    clearRegexSettings();
                    clearCheckboxLimitSettings();
                }
            }
            if (v !== 'checkbox' || isDisplayOnly) {
                clearCheckboxLimitSettings();
            }
            if (textMultiSettings) {
                textMultiSettings.style.display = (!isDisplayOnly && v === 'text_multi') ? '' : 'none';
            }
            if (postalCodeSettings) {
                postalCodeSettings.style.display = (!isDisplayOnly && v === 'postal_code') ? '' : 'none';
            }
            if (fileSettings) {
                fileSettings.style.display = (!isDisplayOnly && v === 'file') ? '' : 'none';
            }
            syncFileSettingsUi(!isDisplayOnly && v === 'file');
            if (matrixSettings) {
                matrixSettings.style.display = (!isDisplayOnly && v === 'matrix') ? '' : 'none';
            }
            if (defaultValueSettings) {
                defaultValueSettings.style.display = (!isDisplayOnly && (v === 'textarea' || v === 'number')) ? '' : 'none';
            }
            if (dateDefaultSettings) {
                dateDefaultSettings.style.display = (!isDisplayOnly && v === 'date') ? '' : 'none';
            }
            if (timeDefaultSettings) {
                timeDefaultSettings.style.display = (!isDisplayOnly && v === 'time') ? '' : 'none';
            }
            ensureRadioDefaultSettings(li, !isDisplayOnly && v === 'radio');
            if (placeholderWrap) {
                var hidePlaceholder = isDisplayOnly || v === 'text_multi' || v === 'radio' || v === 'checkbox' || v === 'select' || v === 'file' || v === 'matrix';
                placeholderWrap.style.display = hidePlaceholder ? 'none' : '';
                if (hidePlaceholder && placeholderInput) {
                    placeholderInput.value = '';
                }
            }
            syncRadioDefaultOptions(li);
        }
        if (typeSelect) {
            typeSelect.addEventListener('change', function () {
                syncTypeSpecificUi();
                updateFieldSummary(li);
            });
        }
        Array.prototype.forEach.call(fileTypeModeInputs || [], function (input) {
            input.addEventListener('change', function () {
                syncFileSettingsUi(typeSelect && typeSelect.value === 'file');
            });
        });
        if (requiredToggle) {
            requiredToggle.addEventListener('change', function () {
                syncTypeSpecificUi();
                updateFieldSummary(li);
            });
        }
        if (lengthLimitModeSelect) {
            lengthLimitModeSelect.addEventListener('change', function () {
                clearLengthLimitValuesByMode(li, String(lengthLimitModeSelect.value || ''));
                syncLengthLimitMode(li);
            });
        }
        if (visibilityToggle) {
            visibilityToggle.addEventListener('change', function () {
                syncFormEditorItemPublicHidden(li);
                updateFieldSummary(li);
            });
        }
        bindInlineActionMenu(li.querySelector('[data-target="c-formEditor__actionMenu"]'));
        var actionMenu = li.querySelector('[data-target="c-formEditor__actionMenu"]');
        var duplicate = li.querySelector('[data-target="c-formEditor__duplicate"]');
        if (duplicate) {
            duplicate.addEventListener('click', function () {
                if (actionMenu) actionMenu.open = false;
                duplicateFieldItem(li);
            });
        }
        var rm = li.querySelector('[data-target="c-formEditor__remove"]');
        if (rm) rm.addEventListener('click', function () {
            if (actionMenu) actionMenu.open = false;
            if (confirm('この項目を削除しますか？')) {
                var parentList = li.closest('[data-target="m-formBuilder01__fields"]');
                li.parentNode.removeChild(li);
                reindex();
                document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
                refreshBuilderListSortable(parentList);
            }
        });

        bindAccordion(li);
        bindFieldKeyLock(li);
        bindRegexBlock(li);
        bindChoiceEditor(li);
        bindTextMultiEditor(li);
        li.querySelectorAll('[data-html-toggle-editor]').forEach(bindHtmlToggleEditor);
        syncTypeSpecificUi();

        var labInp = li.querySelector('[data-target="c-formEditor__labelInput"]');
        if (labInp) {
            labInp.addEventListener('input', function () {
                updateFieldSummary(li);
                refreshAllDescriptionPositionOptions();
            });
            labInp.addEventListener('change', function () {
                updateFieldSummary(li);
                refreshAllDescriptionPositionOptions();
            });
        }
        syncFormEditorItemPublicHidden(li);
        updateFieldSummary(li);
        syncInputModuleStates(li);
    }

    function bindGroup(group) {
        if (!group || group.getAttribute('data-group-bound') === '1') return;
        var labelInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__labelInput"]');
        var groupKeyInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__groupKeyInput"]');
        var visibilityToggle = queryOwnGroupControl(group, '[data-group-name="visible"]');
        var remove = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__remove"]');
        var childList = group.querySelector('[data-target="m-formBuilder01__fields"]');
        if (childList && lists.indexOf(childList) === -1) {
            lists.push(childList);
        }
        group.querySelectorAll('[data-target="m-formBuilder01__add"]').forEach(function (button) {
            bindAddButton(button);
        });
        if (labelInput) {
            labelInput.addEventListener('input', function () {
                updateGroupSummary(group);
                document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
            });
            labelInput.addEventListener('change', function () {
                updateGroupSummary(group);
                document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
            });
        }
        if (groupKeyInput) {
            groupKeyInput.addEventListener('input', function () {
                syncGroupKey(group);
                reindex();
                document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
            });
            groupKeyInput.addEventListener('change', function () {
                syncGroupKey(group);
                reindex();
                document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
            });
        }
        if (visibilityToggle) {
            visibilityToggle.addEventListener('change', function () {
                syncFormEditorItemPublicHidden(group);
                updateGroupSummary(group);
                document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
            });
        }
        var actionMenu = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__actionMenu"]');
        bindInlineActionMenu(actionMenu);
        var duplicate = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__duplicate"]');
        if (duplicate) {
            duplicate.addEventListener('click', function () {
                if (actionMenu) actionMenu.open = false;
                duplicateGroupItem(group);
            });
        }
        if (remove) {
            remove.addEventListener('click', function () {
                if (actionMenu) actionMenu.open = false;
                if (confirm('このグループと中の項目を削除しますか？')) {
                    var parentList = group.closest('[data-target="m-formBuilder01__fields"]');
                    group.parentNode.removeChild(group);
                    reindex();
                    document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
                    refreshBuilderListSortable(parentList);
                }
            });
        }
        bindAccordion(group);
        bindGroupKeyLock(group);
        syncGroupKey(group);
        updateGroupSummary(group);
        syncFormEditorItemPublicHidden(group);
        group.setAttribute('data-group-bound', '1');
    }

    function applyFieldPreset(li, preset) {
        if (!preset) return;
        var labelInput = li.querySelector('[data-name="label"]');
        var typeInput = li.querySelector('[data-name="type"]');
        var requiredToggle = li.querySelector('[data-name="required"]');
        var optionsSource = li.querySelector('[data-name="options"]');
        var choiceList = li.querySelector('[data-target="c-formEditor__choiceListContents"]');
        var placeholderInput = li.querySelector('[name$="[placeholder]"]');
        var minLengthInput = li.querySelector('[data-name="min_length"], [name$="[min_length]"]');
        var maxLengthInput = li.querySelector('[data-name="max_length"], [name$="[max_length]"]');
        var exactLengthInput = li.querySelector('[data-name="exact_length"], [name$="[exact_length]"]');
        var lengthLimitModeSelect = li.querySelector('[data-name="length_limit_mode"], [name$="[length_limit_mode]"]');
        var fileTypeModeInputs = li.querySelectorAll('[data-name="file_type_mode"], [name$="[file_type_mode]"]');
        var fileConvertToJpeg = li.querySelector('[data-name="file_convert_to_jpeg"], [data-target="c-formEditor__fileConvertToJpeg"], [name$="[file_convert_to_jpeg]"]');
        var helpTextInput = li.querySelector('[data-name="help_text"]');
        var helpTextToggle = li.querySelector('[data-target="c-htmlInputEditor01__toggle"]');
        var postalPrefInput = li.querySelector('[data-target="c-formEditor__postalCodePrefectureTarget"]');
        var postalCityInput = li.querySelector('[data-target="c-formEditor__postalCodeCityTarget"]');

        if (labelInput && typeof preset.label === 'string') {
            labelInput.value = preset.label;
        }
        if (typeInput && typeof preset.type === 'string') {
            setFieldType(li, preset.type, preset.typeLabel || '');
        }
        if (requiredToggle) {
            requiredToggle.checked = !!preset.required;
        }
        if (placeholderInput && typeof preset.placeholder === 'string') {
            placeholderInput.value = preset.placeholder;
        }
        if (minLengthInput && Object.prototype.hasOwnProperty.call(preset, 'min_length')) {
            minLengthInput.value = preset.min_length || '';
        }
        if (maxLengthInput && Object.prototype.hasOwnProperty.call(preset, 'max_length')) {
            maxLengthInput.value = preset.max_length || '';
        }
        if (exactLengthInput && Object.prototype.hasOwnProperty.call(preset, 'exact_length')) {
            exactLengthInput.value = preset.exact_length || '';
        }
        if (lengthLimitModeSelect) {
            lengthLimitModeSelect.value = deriveLengthLimitMode(preset);
            syncLengthLimitMode(li);
        }
        if (Object.prototype.hasOwnProperty.call(preset, 'file_type_mode')) {
            Array.prototype.forEach.call(fileTypeModeInputs || [], function (input) {
                input.checked = input.value === String(preset.file_type_mode || 'custom');
            });
        }
        if (fileConvertToJpeg && Object.prototype.hasOwnProperty.call(preset, 'file_convert_to_jpeg')) {
            fileConvertToJpeg.checked = !!Number(preset.file_convert_to_jpeg || 0);
        }
        if (helpTextInput && typeof preset.help_text === 'string') {
            helpTextInput.value = preset.help_text;
        }
        if (helpTextToggle) {
            helpTextToggle.checked = !!Number(preset.help_text_is_html || 0);
        }
        if (choiceList && Array.isArray(preset.options)) {
            var controls = li.querySelector('[data-target="c-formEditor__choiceControls"]');
            choiceList.querySelectorAll('[data-choice-item]').forEach(function (item) {
                var area = item.parentNode;
                if (area && area.parentNode === choiceList) {
                    choiceList.removeChild(area);
                }
            });
            preset.options.forEach(function (option) {
                var item = createChoiceItem(option);
                if (controls) {
                    choiceList.insertBefore(item, controls);
                } else {
                    choiceList.appendChild(item);
                }
            });
        }
        if (optionsSource && Array.isArray(preset.options)) {
            optionsSource.value = preset.options.join('\n');
        }
        if (Object.prototype.hasOwnProperty.call(preset, 'multi_text_items')) {
            setTextMultiItems(li, preset.multi_text_items || '');
        }
        if (postalPrefInput && typeof preset.postal_target_prefecture === 'string') {
            postalPrefInput.value = preset.postal_target_prefecture;
        }
        if (postalCityInput && typeof preset.postal_target_city === 'string') {
            postalCityInput.value = preset.postal_target_city;
        }
    }

    function createFieldPreset(typeValue, typeLabel) {
        var preset = {
            type: typeValue || 'text_multi',
            typeLabel: typeLabel || '',
            label: typeLabel || '',
            required: false
        };
        if (typeValue === 'radio' || typeValue === 'checkbox' || typeValue === 'select') {
            preset.options = [''];
        }
        return preset;
    }

    var PREFECTURE_OPTIONS = [
        '北海道','青森県','岩手県','宮城県','秋田県','山形県','福島県',
        '茨城県','栃木県','群馬県','埼玉県','千葉県','東京都','神奈川県',
        '新潟県','富山県','石川県','福井県','山梨県','長野県',
        '岐阜県','静岡県','愛知県','三重県',
        '滋賀県','京都府','大阪府','兵庫県','奈良県','和歌山県',
        '鳥取県','島根県','岡山県','広島県','山口県',
        '徳島県','香川県','愛媛県','高知県',
        '福岡県','佐賀県','長崎県','熊本県','大分県','宮崎県','鹿児島県',
        '沖縄県'
    ];

    var LEGACY_FIELD_TYPE_LABELS = {
        matrix: 'マトリックス'
    };

    function fieldTypeLabel(typeValue) {
        var button = typeModal ? typeModal.querySelector('[data-target="m-formBuilder01__typeOption"][data-field-type="' + (typeValue || 'text_multi') + '"]') : null;
        if (button) {
            return button.getAttribute('data-field-type-label') || '';
        }
        return LEGACY_FIELD_TYPE_LABELS[typeValue || ''] || '';
    }

    function setControlValue(root, selector, value) {
        var el = root ? root.querySelector(selector) : null;
        if (el) {
            el.value = value == null ? '' : String(value);
        }
    }

    function setControlChecked(root, selector, checked) {
        var el = root ? root.querySelector(selector) : null;
        if (el) {
            el.checked = !!checked;
        }
    }

    function setChoicesFromText(li, text) {
        var source = li.querySelector('[data-target="c-formEditor__optionsSource"]');
        var choiceList = li.querySelector('[data-target="c-formEditor__choiceListContents"]');
        var controls = li.querySelector('[data-target="c-formEditor__choiceControls"]');
        var values = String(text || '').split(/\r?\n/);
        if (source) {
            source.value = values.join('\n');
        }
        if (!choiceList) return;
        choiceList.querySelectorAll('[data-choice-item]').forEach(function (item) {
            var area = item.parentNode;
            if (area && area.parentNode === choiceList) {
                choiceList.removeChild(area);
            }
        });
        values.forEach(function (value) {
            var item = createChoiceItem(value);
            if (controls) {
                choiceList.insertBefore(item, controls);
            } else {
                choiceList.appendChild(item);
            }
        });
    }

    function setTextMultiItems(li, raw) {
        var editor = li.querySelector('[data-text-multi-editor]');
        var list = editor ? editor.querySelector('[data-target="c-formEditor__textMultiListContents"]') : null;
        var controls = editor ? editor.querySelector('[data-target="c-formEditor__textMultiControls"]') : null;
        if (!editor || !list) return;
        var items = raw;
        if (typeof items === 'string') {
            try {
                items = JSON.parse(items);
            } catch (e) {
                items = [];
            }
        }
        if (!Array.isArray(items) || !items.length) {
            items = [{ label: '', placeholder: '', default_value: '' }];
        }
        list.querySelectorAll('[data-text-multi-item]').forEach(function (item) {
            var area = item.parentNode;
            if (area && area.parentNode === list) {
                list.removeChild(area);
            }
        });
        items.forEach(function (item) {
            var area = createTextMultiItem(item);
            if (controls) {
                list.insertBefore(area, controls);
            } else {
                list.appendChild(area);
            }
        });
        syncTextMultiEditor(editor);
    }

    function applyFieldData(li, data) {
        var typeValue = data && data.type ? String(data.type) : 'text_multi';
        setFieldType(li, typeValue, fieldTypeLabel(typeValue));
        setControlValue(li, '[data-target="c-formEditor__labelInput"]', data.label || '');
        setControlChecked(li, '[data-target="c-formEditor__required"]', !!Number(data.required || 0));
        setControlChecked(li, 'input[type="checkbox"][data-name="show_label"]', !!Number(data.show_label || 0));
        setControlChecked(li, '[data-name="visible"]', !data || !Object.prototype.hasOwnProperty.call(data, 'visible') || !!Number(data.visible || 0));
        setControlValue(li, '[name$="[placeholder]"]', data.placeholder || '');
        setControlValue(li, '[data-name="min_length"], [name$="[min_length]"]', data.min_length || '');
        setControlValue(li, '[data-name="max_length"], [name$="[max_length]"]', data.max_length || '');
        setControlValue(li, '[data-name="exact_length"], [name$="[exact_length]"]', data.exact_length || '');
        setControlValue(li, '[data-name="length_limit_mode"], [name$="[length_limit_mode]"]', deriveLengthLimitMode(data));
        syncLengthLimitMode(li);
        setControlValue(li, '[data-name="help_text"]', data.help_text || '');
        setControlValue(li, '[data-target="c-formEditor__headingTextInput"]', data.help_text || '');
        setControlChecked(li, '[data-target="c-htmlInputEditor01__toggle"]', !!Number(data.help_text_is_html || 0));
        setChoicesFromText(li, data.options || '');
        setTextMultiItems(li, data.multi_text_items || '');
        setControlValue(li, '[data-target="c-formEditor__checkboxLimitEnabled"]', Number(data.checkbox_limit_enabled || 0) ? '1' : '0');
        setControlValue(li, '[name$="[checkbox_min_selections]"]', data.checkbox_min_selections || '');
        setControlValue(li, '[name$="[checkbox_max_selections]"]', data.checkbox_max_selections || '');
        setControlValue(li, '[data-target="c-formEditor__postalCodePrefectureTarget"]', data.postal_target_prefecture || '');
        setControlValue(li, '[data-target="c-formEditor__postalCodeCityTarget"]', data.postal_target_city || '');
        setControlValue(li, '[data-target="c-formEditor__defaultValueInput"]', data.default_value || '');
        setControlValue(li, '[data-target="c-formEditor__dateDefaultMode"]', data.date_default_mode || '');
        setControlValue(li, '[data-target="c-formEditor__dateDefaultValue"]', data.date_default_value || '');
        setControlValue(li, '[data-target="c-formEditor__timeDefaultMode"]', data.time_default_mode || '');
        setControlValue(li, '[data-target="c-formEditor__timeDefaultValue"]', data.time_default_value || '');
        li.dataset.fbPendingRadioDefault = data.radio_default_value || '';
        setControlValue(li, '[data-target="c-formEditor__radioDefaultValue"]', data.radio_default_value || '');
        setControlChecked(li, 'input[type="radio"][data-name="file_type_mode"][value="image"], input[type="radio"][name$="[file_type_mode]"][value="image"]', String(data.file_type_mode || 'custom') === 'image');
        setControlChecked(li, 'input[type="radio"][data-name="file_type_mode"][value="custom"], input[type="radio"][name$="[file_type_mode]"][value="custom"]', String(data.file_type_mode || 'custom') !== 'image');
        setControlChecked(li, '[data-name="file_convert_to_jpeg"], [data-target="c-formEditor__fileConvertToJpeg"], [name$="[file_convert_to_jpeg]"]', !!Number(data.file_convert_to_jpeg || 0));
        var radioDefaultSelect = li.querySelector('[data-target="c-formEditor__radioDefaultValue"]');
        if (radioDefaultSelect) {
            radioDefaultSelect.setAttribute('data-value', data.radio_default_value || '');
        }
        setControlValue(li, '[data-target="c-formEditor__fileAllowedExtensions"]', data.file_allowed_extensions || '');
        setControlValue(li, '[data-target="c-formEditor__matrixRows"]', data.matrix_rows || '');
        setControlValue(li, '[data-target="c-formEditor__matrixColumns"]', data.matrix_columns || '');
        setControlValue(li, '[data-target="c-formEditor__matrixSelectionType"]', data.matrix_selection_type || 'radio');

        var regexKind = li.querySelector('[data-target="c-formEditor__regexKind"]');
        var regexValue = li.querySelector('[data-target="c-formEditor__regexValue"]');
        var regexCustom = li.querySelector('[data-target="c-formEditor__regexCustomInput"]');
        var regexPattern = data.regex_pattern || '';
        if (regexKind) {
            if (Number(data.checkbox_limit_enabled || 0)) {
                regexKind.value = '__checkbox_limit__';
            } else if (regexPattern && !Array.prototype.some.call(regexKind.options, function (option) { return option.value === regexPattern; })) {
                regexKind.value = '__custom__';
                if (regexCustom) regexCustom.value = regexPattern;
            } else {
                regexKind.value = regexPattern;
            }
        }
        if (regexValue) {
            regexValue.value = Number(data.checkbox_limit_enabled || 0) ? '' : regexPattern;
        }
        syncRadioDefaultOptions(li);
    }

    function appendField(preset) {
        if (!template) return null;
        var targetList = getActiveList();
        if (!targetList) return null;
        var clone = template.content.firstElementChild.cloneNode(true);
        var fkInput = clone.querySelector('[data-target="c-formEditor__fieldKeyInput"]');
        if (fkInput) {
            fkInput.value = preset && preset.field_key ? String(preset.field_key) : generateUuidV4();
            fkInput.readOnly = true;
            fkInput.classList.add('is-locked');
        }
        applyFieldPreset(clone, preset);
        setFieldInputPageKey(clone, getPageKeyForList(targetList));
        setFieldParentGroupKey(clone, getParentGroupKeyForList(targetList));
        targetList.appendChild(clone);
        bind(clone);
        reindex();
        initFbSortable();
        document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
        return clone;
    }

    function appendFieldFromTemplate(data, targetList, groupKeyMap) {
        if (!template || !targetList) return null;
        activeList = targetList;
        var clone = template.content.firstElementChild.cloneNode(true);
        var newKey = generateUuidV4();
        var fkInput = clone.querySelector('[data-target="c-formEditor__fieldKeyInput"]');
        if (fkInput) {
            fkInput.value = newKey;
            fkInput.readOnly = true;
            fkInput.classList.add('is-locked');
        }
        applyFieldData(clone, data || {});
        setFieldInputPageKey(clone, getPageKeyForList(targetList));
        var sourceParent = data && data.parent_group_key ? String(data.parent_group_key) : '';
        var mappedParent = sourceParent && groupKeyMap[sourceParent] ? groupKeyMap[sourceParent] : getParentGroupKeyForList(targetList);
        setFieldParentGroupKey(clone, mappedParent);
        targetList.appendChild(clone);
        bind(clone);
        return clone;
    }

    function appendGroup() {
        if (!groupTemplate) return null;
        var targetList = getActiveList();
        if (!targetList) return null;
        var clone = groupTemplate.content.firstElementChild.cloneNode(true);
        var groupKey = generateUuidV4();
        clone.setAttribute('data-group-key', groupKey);
        var keyInput = queryOwnGroupControl(clone, '[data-target="c-formEditorGroup__groupKey"]');
        if (keyInput) keyInput.value = groupKey;
        var groupKeyInput = queryOwnGroupControl(clone, '[data-target="c-formEditorGroup__groupKeyInput"]');
        if (groupKeyInput) groupKeyInput.value = groupKey;
        var labelInput = queryOwnGroupControl(clone, '[data-target="c-formEditorGroup__labelInput"]');
        if (labelInput) labelInput.value = 'グループ';
        var childList = clone.querySelector('[data-target="m-formBuilder01__fields"]');
        if (childList) {
            childList.setAttribute('data-parent-group-key', groupKey);
            childList.setAttribute('data-input-page-key', getPageKeyForList(targetList));
            if (lists.indexOf(childList) === -1) {
                lists.push(childList);
            }
        }
        setGroupInputPageKey(clone, getPageKeyForList(targetList));
        setGroupParentGroupKey(clone, getParentGroupKeyForList(targetList));
        targetList.appendChild(clone);
        bindGroup(clone);
        reindex();
        initFbSortable();
        document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
        return clone;
    }

    function appendAddressGroupPreset() {
        var group = appendGroup();
        if (!group) return null;
        var groupLabelInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__labelInput"]');
        if (groupLabelInput) {
            groupLabelInput.value = '住所';
        }
        updateGroupSummary(group);
        var childList = group.querySelector('[data-target="m-formBuilder01__fields"]');
        if (!childList) {
            return group;
        }
        activeList = childList;

        var prefectureKey = generateUuidV4();
        var cityKey = generateUuidV4();
        var postalField = appendField({
            type: 'postal_code',
            typeLabel: fieldTypeLabel('postal_code'),
            label: '郵便番号',
            required: false,
            field_key: generateUuidV4(),
            placeholder: '123-4567',
            postal_target_prefecture: prefectureKey,
            postal_target_city: cityKey
        });
        appendField({
            type: 'select',
            typeLabel: fieldTypeLabel('select'),
            label: '都道府県',
            required: false,
            field_key: prefectureKey,
            options: PREFECTURE_OPTIONS
        });
        appendField({
            type: 'text_multi',
            typeLabel: fieldTypeLabel('text_multi'),
            label: '市区町村',
            required: false,
            field_key: cityKey,
            multi_text_items: JSON.stringify([{ label: '', placeholder: '千代田区千代田' }])
        });
        appendField({
            type: 'text_multi',
            typeLabel: fieldTypeLabel('text_multi'),
            label: '番地',
            required: false,
            field_key: generateUuidV4(),
            multi_text_items: JSON.stringify([{ label: '', placeholder: '1-2-3' }])
        });
        appendField({
            type: 'text_multi',
            typeLabel: fieldTypeLabel('text_multi'),
            label: '建物名・部屋番号',
            required: false,
            field_key: generateUuidV4(),
            multi_text_items: JSON.stringify([{ label: '', placeholder: '○○マンション101' }])
        });
        return postalField || group;
    }

    function appendTextMultiPreset(label, items) {
        return appendField({
            type: 'text_multi',
            typeLabel: fieldTypeLabel('text_multi'),
            label: label,
            required: false,
            field_key: generateUuidV4(),
            multi_text_items: JSON.stringify(items || [])
        });
    }

    function appendNamePreset() {
        return appendTextMultiPreset('お名前', [
            { label: '姓', placeholder: '山田', default_value: '' },
            { label: '名', placeholder: '太郎', default_value: '' }
        ]);
    }

    function appendKanaNamePreset() {
        return appendTextMultiPreset('お名前（カナ）', [
            { label: '姓（カナ）', placeholder: 'ヤマダ', default_value: '' },
            { label: '名（カナ）', placeholder: 'タロウ', default_value: '' }
        ]);
    }

    function createFrequentFieldPreset(typeValue) {
        if (typeValue === '__gender__') {
            return {
                type: 'radio',
                typeLabel: fieldTypeLabel('radio'),
                label: '性別',
                required: false,
                options: ['男性', '女性']
            };
        }
        if (typeValue === '__birthdate__') {
            return {
                type: 'date',
                typeLabel: fieldTypeLabel('date'),
                label: '生年月日',
                required: false
            };
        }
        if (typeValue === '__terms__') {
            return {
                type: 'checkbox',
                typeLabel: fieldTypeLabel('checkbox'),
                label: '規約に同意する',
                required: true,
                options: ['規約に同意する'],
                help_text: '■利用目的お問い合わせへの回答の為ご記入いただきました個人情報は、法令に基づく場合を除きご本人様の承諾なしに第三者に提供致しません。入力後に内容をご確認いただき、間違いがないようでしたら確認画面へ進み【送信する】ボタンをクリックしてください。',
                help_text_is_html: 0
            };
        }

        return null;
    }

    function appendGroupFromTemplate(data, targetList, groupKeyMap) {
        if (!groupTemplate || !targetList) return null;
        activeList = targetList;
        var clone = groupTemplate.content.firstElementChild.cloneNode(true);
        var oldKey = data && data.group_key ? String(data.group_key) : '';
        var groupKey = oldKey && groupKeyMap[oldKey] ? groupKeyMap[oldKey] : generateUuidV4();
        if (oldKey) {
            groupKeyMap[oldKey] = groupKey;
        }
        clone.setAttribute('data-group-key', groupKey);
        var keyInput = queryOwnGroupControl(clone, '[data-target="c-formEditorGroup__groupKey"]');
        if (keyInput) keyInput.value = groupKey;
        var groupKeyInput = queryOwnGroupControl(clone, '[data-target="c-formEditorGroup__groupKeyInput"]');
        if (groupKeyInput) groupKeyInput.value = groupKey;
        setControlValue(clone, '[data-target="c-formEditorGroup__labelInput"]', data.label || 'グループ');
        setControlChecked(clone, 'input[type="checkbox"][data-group-name="show_label"]', !!Number(data.show_label || 0));
        setControlChecked(clone, '[data-group-name="visible"]', !data || !Object.prototype.hasOwnProperty.call(data, 'visible') || !!Number(data.visible || 0));
        setControlValue(clone, '[data-group-name="description"]', data.description || '');
        var childList = clone.querySelector('[data-target="m-formBuilder01__fields"]');
        if (childList) {
            childList.setAttribute('data-parent-group-key', groupKey);
            childList.setAttribute('data-input-page-key', getPageKeyForList(targetList));
            if (lists.indexOf(childList) === -1) {
                lists.push(childList);
            }
        }
        setGroupInputPageKey(clone, getPageKeyForList(targetList));
        setGroupParentGroupKey(clone, getParentGroupKeyForList(targetList));
        targetList.appendChild(clone);
        bindGroup(clone);
        return clone;
    }

    function applyTemplateToList(templateData, mode, targetList) {
        if (!templateData || !targetList) return;
        if (mode === 'replace') {
            lists = lists.filter(function (candidate) {
                return candidate === targetList || !targetList.contains(candidate);
            });
            targetList.replaceChildren();
        }

        var fields = Array.isArray(templateData.fields) ? templateData.fields.slice() : [];
        var groups = Array.isArray(templateData.field_groups) ? templateData.field_groups.slice() : [];
        fields.sort(function (a, b) { return Number(a.sort_order || 0) - Number(b.sort_order || 0); });
        groups.sort(function (a, b) { return Number(a.sort_order || 0) - Number(b.sort_order || 0); });

        var groupKeyMap = {};
        groups.forEach(function (group) {
            if (group && group.group_key) {
                groupKeyMap[String(group.group_key)] = generateUuidV4();
            }
        });

        function childrenFor(parentKey) {
            var parent = parentKey || '';
            var children = [];
            groups.forEach(function (group) {
                var groupParent = group && group.parent_group_key ? String(group.parent_group_key) : '';
                if (groupParent === parent) children.push({ kind: 'group', item: group });
            });
            fields.forEach(function (field) {
                var fieldParent = field && field.parent_group_key ? String(field.parent_group_key) : '';
                if (fieldParent === parent) children.push({ kind: 'field', item: field });
            });
            children.sort(function (a, b) { return Number((a.item && a.item.sort_order) || 0) - Number((b.item && b.item.sort_order) || 0); });
            return children;
        }

        function appendChildren(parentKey, listForParent) {
            childrenFor(parentKey).forEach(function (child) {
                if (child.kind === 'group') {
                    var groupNode = appendGroupFromTemplate(child.item, listForParent, groupKeyMap);
                    var childList = groupNode ? groupNode.querySelector('[data-target="m-formBuilder01__fields"]') : null;
                    appendChildren(child.item.group_key || '', childList || listForParent);
                    return;
                }
                appendFieldFromTemplate(child.item, listForParent, groupKeyMap);
            });
        }

        appendChildren('', targetList);
        reindex();
        initFbSortable();
        syncInputModuleStates(targetList);
        document.dispatchEvent(new CustomEvent('formkun:fields-changed'));
    }

    function openTypeModal() {
        if (!typeModal) return;
        typeModal.hidden = false;
        document.body.classList.add('is-field-side-area-open');
        var firstOption = typeModal.querySelector('[data-target="m-formBuilder01__typeOption"]');
        if (firstOption) {
            firstOption.focus();
        }
    }

    function closeTypeModal() {
        if (!typeModal) return;
        typeModal.hidden = true;
        document.body.classList.remove('is-field-side-area-open');
        var activePanel = getActiveList() ? getActiveList().closest('[data-module="m-formBuilder01"]') : null;
        var activeAdd = activePanel ? activePanel.querySelector('[data-target="m-formBuilder01__add"]') : addBtn;
        if (activeAdd) {
            activeAdd.focus();
        }
    }

    getGroupItems().forEach(bindGroup);
    getFieldItems().forEach(bind);
    descriptionEditors.forEach(function (editor) {
        var descriptionList = getDescriptionList(editor);
        var addButton = editor.querySelector('[data-target="m-formBuilder01__add"]');
        if (descriptionList) {
            descriptionList.querySelectorAll('[data-description-block]').forEach(function (block) {
                bindDescriptionBlock(editor, block);
            });
            initDescriptionSortable(editor);
            reindexDescriptionBlocks(editor);
        }
        if (addButton && descriptionTemplate) {
            addButton.addEventListener('click', function () {
                var options = getDescriptionPositionOptions(editor);
                var position = options[options.length - 1].value;
                var block = createDescriptionBlock(editor, position);
                if (!block || !descriptionList) return;
                descriptionList.appendChild(block);
                refreshDescriptionPositionOptions(editor);
                var select = block.querySelector('.fb-description-position');
                if (select) {
                    select.value = String(position);
                    select.setAttribute('data-value', select.value);
                }
                reindexDescriptionBlocks(editor);
                syncInputModuleStates(block);
                refreshDescriptionSortable(editor);
                var textarea = block.querySelector('[data-target="c-htmlInputEditor01__textarea"]');
                if (textarea) textarea.focus();
            });
        }
    });

    publishScheduleEditors.forEach(function (editor) {
        var ruleList = getPublishRuleList(editor);
        var addButton = editor.querySelector('.fb-publish-rule-add');
        if (ruleList) {
            ruleList.querySelectorAll('[data-publish-rule-block]').forEach(function (block) {
                bindPublishRuleBlock(editor, block);
            });
            initPublishRuleSortable(editor);
            reindexPublishRules(editor);
        }
        if (addButton && getPublishRuleTemplate(editor)) {
            addButton.addEventListener('click', function () {
                var block = createPublishRuleBlock(editor);
                if (!block || !ruleList) return;
                ruleList.appendChild(block);
                reindexPublishRules(editor);
                syncInputModuleStates(block);
                initPublishRuleSortable(editor);
                block.classList.remove('is-collapsed');
                var startInput = block.querySelector('[data-target="c-publishScheduleEditor__startInput"]');
                if (startInput) startInput.focus();
            });
        }
    });
    syncPublishScheduleUi();

    function validateFormEditRequired(form) {
        if (!form || form.id !== 'form-edit-main') return true;
        var messages = [];
        var firstInvalid = null;
        var titleInput = form.querySelector('#title');
        var slugInput = form.querySelector('#slug');
        if (titleInput && !titleInput.value.trim()) {
            messages.push('タイトルは必須です。');
            firstInvalid = firstInvalid || titleInput;
        }
        if (slugInput && !slugInput.value.trim()) {
            messages.push('公開ページは必須です。');
            firstInvalid = firstInvalid || slugInput;
        }
        if (messages.length === 0) return true;
        if (typeof window.formkunShowAdminToast === 'function') {
            window.formkunShowAdminToast(messages.join('\n'), 'danger');
        } else {
            alert(messages.join('\n'));
        }
        if (firstInvalid && typeof firstInvalid.focus === 'function') {
            firstInvalid.focus();
        }
        return false;
    }

    function setBuilderMetaValue(form, target, value) {
        if (!form) return;
        var input = form.querySelector('[data-target="' + target + '"]');
        if (input) {
            input.value = value;
        }
    }

    function isBuilderInputName(name) {
        return /^(fields|field_groups|input_pages|branch_rules)\[/.test(name || '');
    }

    function parseBuilderInputName(name) {
        if (!isBuilderInputName(name)) return null;
        return name.match(/[^[\]]+/g);
    }

    function assignBuilderPayloadValue(target, tokens, value) {
        if (!Array.isArray(tokens) || tokens.length === 0) return;
        var current = target;
        for (var i = 0; i < tokens.length - 1; i += 1) {
            var token = /^\d+$/.test(tokens[i]) ? parseInt(tokens[i], 10) : tokens[i];
            var nextToken = tokens[i + 1];
            var shouldBeArray = /^\d+$/.test(nextToken);
            if (!current[token] || typeof current[token] !== 'object') {
                current[token] = shouldBeArray ? [] : {};
            }
            current = current[token];
        }
        var lastToken = tokens[tokens.length - 1];
        var lastKey = /^\d+$/.test(lastToken) ? parseInt(lastToken, 10) : lastToken;
        current[lastKey] = value;
    }

    function buildBuilderPayload(form) {
        var payload = {
            fields: [],
            field_groups: [],
            input_pages: [],
            branch_rules: []
        };
        if (!form) return payload;
        new FormData(form).forEach(function (value, key) {
            var tokens = parseBuilderInputName(key);
            if (!tokens) return;
            assignBuilderPayloadValue(payload, tokens, typeof value === 'string' ? value : String(value));
        });
        return payload;
    }

    function syncBuilderMeta(form, payload, inputVarCount) {
        if (!form || form.id !== 'form-edit-main') return;
        var fieldKeys = Array.isArray(payload && payload.fields) ? payload.fields.map(function (field) {
            return field && field.field_key ? String(field.field_key).trim() : '';
        }).filter(function (value) {
            return value !== '';
        }) : [];
        var groupKeys = Array.isArray(payload && payload.field_groups) ? payload.field_groups.map(function (group) {
            return group && group.group_key ? String(group.group_key).trim() : '';
        }).filter(function (value) {
            return value !== '';
        }) : [];
        setBuilderMetaValue(form, 'builderMetaFieldCount', String(Array.isArray(payload && payload.fields) ? payload.fields.length : 0));
        setBuilderMetaValue(form, 'builderMetaFieldKeys', JSON.stringify(fieldKeys));
        setBuilderMetaValue(form, 'builderMetaGroupCount', String(Array.isArray(payload && payload.field_groups) ? payload.field_groups.length : 0));
        setBuilderMetaValue(form, 'builderMetaGroupKeys', JSON.stringify(groupKeys));
        setBuilderMetaValue(form, 'builderMetaInputPageCount', String(Array.isArray(payload && payload.input_pages) ? payload.input_pages.length : 0));
        setBuilderMetaValue(form, 'builderMetaBranchRuleCount', String(Array.isArray(payload && payload.branch_rules) ? payload.branch_rules.length : 0));
        setBuilderMetaValue(form, 'builderMetaInputVarCount', String(inputVarCount || 0));
    }

    function countPostableFormValues(form, ignoreBuilderInputs) {
        if (!form) return 0;
        var count = 0;
        form.querySelectorAll('input[name], textarea[name], select[name]').forEach(function (el) {
            if (!el.name || el.disabled) return;
            if (ignoreBuilderInputs && isBuilderInputName(el.name)) return;
            var tagName = el.tagName.toLowerCase();
            var type = (el.getAttribute('type') || '').toLowerCase();
            if (tagName === 'select' && el.multiple) {
                count += Array.prototype.filter.call(el.options, function (option) {
                    return option.selected;
                }).length;
                return;
            }
            if ((type === 'checkbox' || type === 'radio') && !el.checked) {
                return;
            }
            count += 1;
        });
        return count;
    }

    function setBuilderInputsDisabled(form, disabled) {
        if (!form) return;
        form.querySelectorAll('input[name], textarea[name], select[name]').forEach(function (el) {
            if (!isBuilderInputName(el.name)) return;
            if (disabled) {
                if (!el.disabled) {
                    el.disabled = true;
                    el.setAttribute('data-builder-disabled-for-submit', '1');
                }
                return;
            }
            if (el.getAttribute('data-builder-disabled-for-submit') === '1') {
                el.disabled = false;
                el.removeAttribute('data-builder-disabled-for-submit');
            }
        });
    }

    function syncBuilderPayloadInput(form, payloadJson) {
        if (!form) return;
        var input = form.querySelector('[data-target="builderPayload"]');
        if (input) {
            input.value = payloadJson;
        }
    }

    function validateBuilderPostLimit(form, payload) {
        if (!form || form.id !== 'form-edit-main') return true;
        var inputVarCount = countPostableFormValues(form, true);
        syncBuilderMeta(form, payload, inputVarCount);
        var maxInputVars = parseInt(form.getAttribute('data-max-input-vars') || '0', 10);
        if (!(maxInputVars > 0) || inputVarCount <= maxInputVars) {
            return true;
        }
        var message = 'POST 変数数が多いため保存できません。現在の POST 変数数の目安 ' + inputVarCount + ' 件がサーバー上限 ' + maxInputVars + ' 件を超えています。フォーム項目を減らすか、サーバーの max_input_vars を増やしてください。';
        if (typeof window.formkunShowAdminToast === 'function') {
            window.formkunShowAdminToast(message, 'danger');
        } else {
            alert(message);
        }
        return false;
    }

    function buildBuilderSubmission(form) {
        if (!form || form.id !== 'form-edit-main') {
            return { payload: null, payloadJson: '' };
        }
        reindexInputPages();
        syncBuilderForm(form);
        descriptionEditors.forEach(function (editor) {
            reindexDescriptionBlocks(editor);
        });
        var payload = buildBuilderPayload(form);
        var payloadJson = JSON.stringify(payload);
        syncBuilderPayloadInput(form, payloadJson);
        return {
            payload: payload,
            payloadJson: payloadJson
        };
    }

    function buildPreviewFormData(form) {
        return withDirtyStateSuppressed(function () {
            var submission = buildBuilderSubmission(form);
            var data = new FormData(form);
            var keysToDelete = [];
            data.forEach(function (value, key) {
                if (isBuilderInputName(key)) {
                    keysToDelete.push(key);
                }
            });
            keysToDelete.forEach(function (key) {
                data.delete(key);
            });
            data.set('builder_payload', submission.payloadJson);
            return data;
        });
    }

    function bindBuilderFormSubmit(form) {
        if (!form || form.getAttribute('data-builder-submit-bound') === '1') return;
        form.addEventListener('submit', function (event) {
            if (!validateFormEditRequired(form)) {
                event.preventDefault();
                return;
            }
            setBuilderInputsDisabled(form, false);
            var submission = buildBuilderSubmission(form);
            if (!validateBuilderPostLimit(form, submission.payload)) {
                event.preventDefault();
                return;
            }
            setBuilderInputsDisabled(form, true);
            if (dirtyActions) {
                dirtyActions.hidden = true;
            }
            document.body.classList.remove('is-form-edit-dirty');
        });
        form.setAttribute('data-builder-submit-bound', '1');
    }

    Array.prototype.slice.call(document.querySelectorAll('[data-target="m-formBuilder01__fields"]')).map(function (targetList) {
        return targetList.closest('form');
    }).filter(function (form, index, forms) {
        return form && forms.indexOf(form) === index;
    }).forEach(function (form) {
        bindBuilderFormSubmit(form);
    });

    if (typeModal) {
        typeModal.querySelectorAll('[data-target="m-formBuilder01__typeModalClose"]').forEach(function (button) {
            button.addEventListener('click', function () {
                closeTypeModal();
            });
        });
        typeModal.querySelectorAll('[data-target="m-formBuilder01__typeOption"]').forEach(function (button) {
            button.addEventListener('click', function () {
                var typeValue = button.getAttribute('data-field-type') || 'text_multi';
                var typeLabel = button.getAttribute('data-field-type-label') || '';
                if (typeValue === '__group__') {
                    var group = appendGroup();
                    closeTypeModal();
                    var groupLabelInput = group ? queryOwnGroupControl(group, '[data-target="c-formEditorGroup__labelInput"]') : null;
                    if (groupLabelInput) groupLabelInput.focus();
                    return;
                }
                if (typeValue === '__name__') {
                    var namePreset = appendNamePreset();
                    closeTypeModal();
                    var nameLabelInput = namePreset ? namePreset.querySelector('[data-target="c-formEditor__labelInput"]') : null;
                    if (nameLabelInput) {
                        nameLabelInput.focus();
                    }
                    return;
                }
                if (typeValue === '__name_kana__') {
                    var kanaNamePreset = appendKanaNamePreset();
                    closeTypeModal();
                    var kanaNameLabelInput = kanaNamePreset ? kanaNamePreset.querySelector('[data-target="c-formEditor__labelInput"]') : null;
                    if (kanaNameLabelInput) {
                        kanaNameLabelInput.focus();
                    }
                    return;
                }
                if (typeValue === '__address_group__') {
                    var addressPreset = appendAddressGroupPreset();
                    closeTypeModal();
                    var addressLabelInput = addressPreset ? addressPreset.querySelector('[data-target="c-formEditor__labelInput"]') : null;
                    if (addressLabelInput) {
                        addressLabelInput.focus();
                    }
                    return;
                }
                var frequentPreset = createFrequentFieldPreset(typeValue);
                if (frequentPreset) {
                    var frequentClone = appendField(frequentPreset);
                    closeTypeModal();
                    var frequentLabelInput = frequentClone ? frequentClone.querySelector('[data-target="c-formEditor__labelInput"]') : null;
                    if (frequentLabelInput) {
                        frequentLabelInput.focus();
                    }
                    return;
                }
                if (typeValue === 'matrix') {
                    closeTypeModal();
                    return;
                }
                var clone = appendField(createFieldPreset(typeValue, typeLabel));
                closeTypeModal();
                var labelInput = clone ? clone.querySelector('[data-target="c-formEditor__labelInput"]') : null;
                if (labelInput) {
                    labelInput.focus();
                }
            });
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !typeModal.hidden) {
                closeTypeModal();
            }
        });
    }

    function bindAddButton(button) {
        if (!button || button.getAttribute('data-field-add-bound') === '1' || !template) return;
        button.addEventListener('click', function () {
            var targetList = null;
            var group = button.closest('[data-group-item="1"]');
            if (group) {
                targetList = group.querySelector('[data-target="m-formBuilder01__fields"]');
            }
            var panel = button.closest('[data-module="m-formBuilder01"]');
            if (!targetList) {
                targetList = panel ? panel.querySelector('[data-target="m-formBuilder01__fields"]') : null;
            }
            if (targetList) {
                activeList = targetList;
            }
            openTypeModal();
        });
        button.setAttribute('data-field-add-bound', '1');
    }

    if (addButtons.length && template) {
        addButtons.forEach(function (button) {
            bindAddButton(button);
        });
    }

    function replaceTemplateKey(root, key) {
        if (!root || typeof root.innerHTML !== 'string') return;
        root.innerHTML = root.innerHTML.split('__templateKey__').join(key);
    }

    function bindNewBuilderScope(root) {
        if (!root) return;
        var scopedLists = Array.prototype.slice.call(root.querySelectorAll('[data-target="m-formBuilder01__fields"]'));
        scopedLists.forEach(function (targetList) {
            if (lists.indexOf(targetList) === -1) {
                lists.push(targetList);
            }
        });
        if (!activeList && scopedLists[0]) {
            activeList = scopedLists[0];
        }
        root.querySelectorAll('.c-formEditor__item[data-group-item="1"]').forEach(bindGroup);
        root.querySelectorAll('.c-formEditor__item[data-field-item="1"]').forEach(bind);
        root.querySelectorAll('[data-target="m-formBuilder01__add"]').forEach(function (button) {
            if (button.closest('[data-description-editor]')) return;
            bindAddButton(button);
        });
        var form = root.closest('form') || root.querySelector('form');
        bindBuilderFormSubmit(form);
        initFbSortable();
        reindexBuilderScope(form || root);
        syncInputModuleStates(root);
    }

    (function initFieldTemplateCreatePanel() {
        var openButton = document.querySelector('[data-target="fieldTemplateCreateOpen"]');
        var itemTemplate = document.querySelector('[data-target="fieldTemplateCreateTemplate"]');
        var actions = document.querySelector('[data-target="fieldTemplateCreateActions"]');
        if (!openButton || !itemTemplate || !actions) return;

        openButton.addEventListener('click', function () {
            var item = itemTemplate.content.firstElementChild.cloneNode(true);
            var key = 'new_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
            replaceTemplateKey(item, key);
            actions.parentNode.insertBefore(item, actions);
            item.open = true;
            bindNewBuilderScope(item);
            var titleInput = item.querySelector('#field_template_title_' + key);
            if (titleInput) {
                titleInput.focus();
            }
        });
    })();

    (function initFieldTemplateApply() {
        var modal = document.querySelector('[data-module="c-fieldTemplateApply01"]');
        if (!modal) return;
        var pendingList = null;

        function openModal(button) {
            var group = button.closest('[data-group-item="1"]');
            var panel = button.closest('[data-module="m-formBuilder01"]');
            pendingList = group
                ? group.querySelector('[data-target="m-formBuilder01__fields"]')
                : (panel ? panel.querySelector('[data-target="m-formBuilder01__fields"]') : getActiveList());
            if (pendingList) {
                activeList = pendingList;
            }
            modal.hidden = false;
            document.body.classList.add('is-field-template-apply-open');
            var first = modal.querySelector('[data-target="fieldTemplateApplyItem"]');
            if (first) first.focus();
        }

        function closeModal() {
            modal.hidden = true;
            document.body.classList.remove('is-field-template-apply-open');
        }

        document.querySelectorAll('[data-target="fieldTemplateApplyOpen"]').forEach(function (button) {
            button.addEventListener('click', function () {
                openModal(button);
            });
        });
        modal.querySelectorAll('[data-target="fieldTemplateApplyClose"]').forEach(function (button) {
            button.addEventListener('click', closeModal);
        });
        modal.querySelectorAll('[data-target="fieldTemplateApplyItem"]').forEach(function (button) {
            button.addEventListener('click', function () {
                var url = button.getAttribute('data-template-url');
                var modeInput = modal.querySelector('input[name="field_template_apply_mode"]:checked');
                var mode = modeInput ? modeInput.value : 'append';
                var targetList = pendingList || getActiveList();
                if (!url || !targetList) return;
                button.disabled = true;
                window.fetch(url, {
                    credentials: 'same-origin',
                    headers: { 'Accept': 'application/json' }
                }).then(function (response) {
                    if (!response.ok) throw new Error('テンプレートを読み込めませんでした。');
                    return response.json();
                }).then(function (json) {
                    if (!json || !json.ok || !json.template) {
                        throw new Error(json && json.message ? json.message : 'テンプレートを読み込めませんでした。');
                    }
                    applyTemplateToList(json.template, mode, targetList);
                    closeModal();
                }).catch(function (error) {
                    window.alert(error && error.message ? error.message : 'テンプレートを読み込めませんでした。');
                }).finally(function () {
                    button.disabled = false;
                });
            });
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !modal.hidden) {
                closeModal();
            }
        });
    })();

    function reindexInputPages() {
        document.querySelectorAll('[data-tab-panel^="screen-input-"]').forEach(function (panel, pageIndex) {
            panel.querySelectorAll('[data-input-page-name]').forEach(function (el) {
                var key = el.getAttribute('data-input-page-name');
                if (!key) return;
                el.setAttribute('name', 'input_pages[' + pageIndex + '][' + key + ']');
            });
            panel.querySelectorAll('[data-description-editor]').forEach(function (editor) {
                editor.setAttribute('data-name-prefix', 'input_pages[' + pageIndex + '][description_blocks]');
                reindexDescriptionBlocks(editor);
            });
        });
    }

    function bindNewInputPagePanel(panel) {
        if (!panel) return;
        var targetList = panel.querySelector('[data-target="m-formBuilder01__fields"]');
        if (targetList && lists.indexOf(targetList) === -1) {
            lists.push(targetList);
        }
        if (targetList) {
            targetList.querySelectorAll('.c-formEditor__item[data-field-item="1"]').forEach(bind);
        }
        panel.querySelectorAll('[data-target="m-formBuilder01__add"]').forEach(function (button) {
            if (button.closest('[data-description-editor]')) return;
            bindAddButton(button);
        });
        panel.querySelectorAll('[data-description-editor]').forEach(function (editor) {
            if (descriptionEditors.indexOf(editor) === -1) {
                descriptionEditors.push(editor);
            }
            var descriptionList = getDescriptionList(editor);
            if (descriptionList) {
                descriptionList.querySelectorAll('[data-description-block]').forEach(function (block) {
                    bindDescriptionBlock(editor, block);
                });
                initDescriptionSortable(editor);
                reindexDescriptionBlocks(editor);
                refreshDescriptionPositionOptions(editor);
            }
            var addButton = editor.querySelector('[data-target="m-formBuilder01__add"]');
            if (addButton && descriptionTemplate) {
                addButton.addEventListener('click', function () {
                    var options = getDescriptionPositionOptions(editor);
                    var position = options[options.length - 1].value;
                    var block = createDescriptionBlock(editor, position);
                    if (!block || !descriptionList) return;
                    descriptionList.appendChild(block);
                    refreshDescriptionPositionOptions(editor);
                    var select = block.querySelector('.fb-description-position');
                    if (select) {
                        select.value = String(position);
                        select.setAttribute('data-value', select.value);
                    }
                    reindexDescriptionBlocks(editor);
                    syncInputModuleStates(block);
                    refreshDescriptionSortable(editor);
                    var textarea = block.querySelector('[data-target="c-htmlInputEditor01__textarea"]');
                    if (textarea) textarea.focus();
                });
            }
        });
        initFbSortable();
        syncInputModuleStates(panel);
    }

    (function initInputPageAdd() {
        var addPageButton = document.querySelector('[data-target="inputPageAdd"]');
        var panelTemplate = document.querySelector('[data-target="inputPagePanelTemplate"]');
        var screensRoot = addPageButton ? addPageButton.closest('[data-module="c-formEditTabs01"]') : null;
        var tabList = screensRoot ? screensRoot.querySelector('[data-target="inputPageTabs"]') : null;
        var panelsRoot = screensRoot ? screensRoot.querySelector('[data-target="inputPagePanels"]') : null;
        if (!addPageButton || !panelTemplate || !tabList || !panelsRoot || !screensRoot) return;

        function getInputPanels() {
            return panelsRoot.querySelectorAll('[data-tab-panel^="screen-input-"]');
        }

        function setInputPageTabLabel(tab, title) {
            if (!tab) return;
            var label = tab.querySelector('[data-target="inputPageTabLabel"]');
            if (label) {
                label.textContent = title;
            } else {
                tab.textContent = title;
            }
        }

        function createInputPageTab(pageKey, title) {
            var tab = document.createElement('div');
            tab.className = 'c-inputPageTab01';
            tab.setAttribute('data-module', 'm-formEditTab01');
            tab.setAttribute('data-target', 'c-formEditTabs01__tab');
            tab.setAttribute('data-input-page-tab', '1');
            tab.setAttribute('data-tab-panel', 'screen-input-' + pageKey);
            tab.setAttribute('role', 'tab');
            tab.setAttribute('aria-selected', 'false');
            tab.tabIndex = -1;
            tab.innerHTML =
                '<span class="label" data-target="inputPageTabLabel"></span>' +
                '<details class="menu" data-target="inputPageActionMenu">' +
                    '<summary class="toggle" aria-label="入力画面操作"><span aria-hidden="true">⋯</span></summary>' +
                    '<div class="items" role="menu" aria-label="入力画面操作">' +
                        '<button type="button" data-target="inputPageDuplicate" role="menuitem">複製</button>' +
                        '<button type="button" data-target="inputPageDelete" role="menuitem">削除</button>' +
                    '</div>' +
                '</details>';
            setInputPageTabLabel(tab, title);
            bindInputPageTab(tab);
            bindInputPageActions(tab);
            return tab;
        }

        function bindInputPageTab(tab) {
            if (!tab || tab.getAttribute('data-input-page-tab-bound') === '1') return;
            tab.addEventListener('click', function (event) {
                if (event.target.closest && event.target.closest('[data-target="inputPageActionMenu"]')) {
                    return;
                }
                if (typeof screensRoot.formkunActivateTab === 'function') {
                    screensRoot.formkunActivateTab(tab.getAttribute('data-tab-panel'));
                }
            });
            tab.setAttribute('data-input-page-tab-bound', '1');
        }

        function createInputPagePanel(pageKey, title) {
            var inputPanels = getInputPanels();
            var html = panelTemplate.innerHTML
                .replace(/__INDEX__/g, String(inputPanels.length))
                .replace(/__PAGE_KEY__/g, pageKey)
                .replace(/__PAGE_TITLE__/g, title);
            var holder = document.createElement('div');
            holder.innerHTML = html.trim();
            return holder.firstElementChild;
        }

        function copyControlValues(source, target) {
            var sourceControls = source.querySelectorAll('input, textarea, select');
            var targetControls = target.querySelectorAll('input, textarea, select');
            sourceControls.forEach(function (control, index) {
                var clone = targetControls[index];
                if (!clone) return;
                if (control.type === 'checkbox' || control.type === 'radio') {
                    clone.checked = control.checked;
                    return;
                }
                clone.value = control.value;
            });
        }

        function prepareDuplicatedPanel(sourcePanel, panel, pageKey, title) {
            copyControlValues(sourcePanel, panel);
            panel.removeAttribute('hidden');
            panel.hidden = true;
            panel.setAttribute('data-tab-panel', 'screen-input-' + pageKey);
            panel.setAttribute('aria-label', title);
            panel.querySelectorAll('[data-fb-sortable], [data-html-toggle-bound], [data-accordion-bound], [data-field-add-bound]').forEach(function (el) {
                el.removeAttribute('data-fb-sortable');
                el.removeAttribute('data-html-toggle-bound');
                el.removeAttribute('data-accordion-bound');
                el.removeAttribute('data-field-add-bound');
            });
            var root = panel.querySelector('[data-module="m-formBuilder01"]');
            if (root) {
                root.setAttribute('data-input-page-key', pageKey);
            }
            var targetList = panel.querySelector('[data-target="m-formBuilder01__fields"]');
            if (targetList) {
                targetList.setAttribute('data-input-page-key', pageKey);
            }
            var keyInput = panel.querySelector('[data-input-page-name="page_key"]');
            if (keyInput) {
                keyInput.value = pageKey;
            }
            var titleInput = panel.querySelector('[data-target="inputPageTitle"]');
            if (titleInput) {
                titleInput.value = title;
            }
            panel.querySelectorAll('.c-formEditor__item[data-field-item="1"]').forEach(function (field) {
                var fieldKeyInput = field.querySelector('[data-target="c-formEditor__fieldKeyInput"]');
                if (fieldKeyInput) {
                    fieldKeyInput.value = generateUuidV4();
                }
                setFieldInputPageKey(field, pageKey);
            });
            panel.querySelectorAll('[data-description-block] [data-name="id"]').forEach(function (input) {
                input.value = 'description-' + generateUuidV4();
            });
        }

        function insertInputPage(panel, tab, pageKey) {
            if (!panel || !tab) return;
            panelsRoot.insertBefore(panel, panelsRoot.querySelector('[data-tab-panel="screen-confirm"]'));
            tabList.insertBefore(tab, tabList.querySelector('[data-tab-panel="screen-confirm"]'));
            bindInputPageTitleSync(panel, tab);
            var titleInput = panel.querySelector('[data-target="inputPageTitle"]');
            bindNewInputPagePanel(panel);
            reindexInputPages();
            reindex();
            document.dispatchEvent(new CustomEvent('formkun:input-pages-changed'));
            queueDirtyState();
            if (typeof screensRoot.formkunActivateTab === 'function') {
                screensRoot.formkunActivateTab('screen-input-' + pageKey);
            }
            if (titleInput) titleInput.focus();
        }

        function bindInputPageTitleSync(panel, tab) {
            if (!panel || !tab || tab.getAttribute('data-input-page-title-bound') === '1') return;
            var fallback = (tab.querySelector('[data-target="inputPageTabLabel"]') || tab).textContent.trim();
            var titleInput = panel.querySelector('[data-target="inputPageTitle"]');
            if (titleInput) {
                titleInput.addEventListener('input', function () {
                    setInputPageTabLabel(tab, titleInput.value.trim() || fallback || '入力画面');
                });
            }
            tab.setAttribute('data-input-page-title-bound', '1');
        }

        function panelForTab(tab) {
            var panelId = tab ? tab.getAttribute('data-tab-panel') : '';
            return panelId ? panelsRoot.querySelector('[data-tab-panel="' + panelId + '"]') : null;
        }

        function currentPageKey(panel) {
            var input = panel ? panel.querySelector('[data-input-page-name="page_key"]') : null;
            return input ? input.value.trim() : '';
        }

        function duplicateInputPage(tab) {
            var sourcePanel = panelForTab(tab);
            if (!sourcePanel) return;
            var titleInput = sourcePanel.querySelector('[data-target="inputPageTitle"]');
            var sourceTitle = titleInput && titleInput.value.trim() ? titleInput.value.trim() : '入力画面';
            var title = sourceTitle + ' のコピー';
            var pageKey = 'input-' + generateUuidV4();
            var panel = sourcePanel.cloneNode(true);
            prepareDuplicatedPanel(sourcePanel, panel, pageKey, title);
            insertInputPage(panel, createInputPageTab(pageKey, title), pageKey);
        }

        function removeBranchRulesForPage(pageKey, fieldKeys) {
            document.querySelectorAll('[data-branch-rule-row]').forEach(function (row) {
                var trigger = row.querySelector('[data-target="branchRuleTriggerPage"]');
                var source = row.querySelector('[data-target="branchRuleSourceField"]');
                var action = row.querySelector('[data-target="branchRuleActionType"]');
                var target = row.querySelector('[data-target="branchRuleTargetKey"]');
                var targetValue = target ? target.value : '';
                var remove = (trigger && trigger.value === pageKey)
                    || (source && fieldKeys.indexOf(source.value) !== -1)
                    || (action && action.value === 'go_to_screen' && targetValue === pageKey)
                    || (action && action.value === 'show_field' && fieldKeys.indexOf(targetValue) !== -1);
                if (remove && row.parentNode) {
                    row.parentNode.removeChild(row);
                }
            });
        }

        function deleteInputPage(tab) {
            var inputPanels = getInputPanels();
            if (inputPanels.length <= 1) {
                alert('入力画面は1つ以上必要です。');
                return;
            }
            var panel = panelForTab(tab);
            var pageKey = currentPageKey(panel);
            if (!panel || !pageKey) return;
            if (!confirm('この入力画面を削除します。所属する項目と関連する分岐処理も削除されます。よろしいですか？')) {
                return;
            }
            var fieldKeys = [];
            panel.querySelectorAll('.c-formEditor__item[data-field-item="1"] [data-target="c-formEditor__fieldKeyInput"]').forEach(function (input) {
                if (input.value.trim()) {
                    fieldKeys.push(input.value.trim());
                }
            });
            removeBranchRulesForPage(pageKey, fieldKeys);
            var wasActive = tab.getAttribute('aria-selected') === 'true';
            if (panel.parentNode) panel.parentNode.removeChild(panel);
            if (tab.parentNode) tab.parentNode.removeChild(tab);
            reindexInputPages();
            reindex();
            document.dispatchEvent(new CustomEvent('formkun:input-pages-changed'));
            queueDirtyState();
            if (wasActive && typeof screensRoot.formkunActivateTab === 'function') {
                var nextPanel = getInputPanels()[0];
                if (nextPanel) {
                    screensRoot.formkunActivateTab(nextPanel.getAttribute('data-tab-panel'));
                }
            }
        }

        function bindInputPageActions(tab) {
            if (!tab || tab.getAttribute('data-input-page-actions-bound') === '1') return;
            var menu = tab.querySelector('[data-target="inputPageActionMenu"]');
            var duplicate = tab.querySelector('[data-target="inputPageDuplicate"]');
            var remove = tab.querySelector('[data-target="inputPageDelete"]');
            if (menu && typeof window.formkunBindDetailsActionMenu === 'function') {
                window.formkunBindDetailsActionMenu(menu);
            }
            if (duplicate) {
                duplicate.addEventListener('click', function () {
                    if (menu) menu.open = false;
                    duplicateInputPage(tab);
                });
            }
            if (remove) {
                remove.addEventListener('click', function () {
                    if (menu) menu.open = false;
                    deleteInputPage(tab);
                });
            }
            tab.setAttribute('data-input-page-actions-bound', '1');
        }

        tabList.querySelectorAll('[data-input-page-tab="1"]').forEach(function (tab) {
            bindInputPageTab(tab);
            bindInputPageActions(tab);
            bindInputPageTitleSync(panelForTab(tab), tab);
        });

        addPageButton.addEventListener('click', function () {
            var pageNo = getInputPanels().length + 1;
            var pageKey = 'input-' + generateUuidV4();
            var title = '入力画面 ' + pageNo;
            insertInputPage(createInputPagePanel(pageKey, title), createInputPageTab(pageKey, title), pageKey);
        });
    })();

    (function initBranchRules() {
        var list = document.querySelector('[data-target="branchRuleList"]');
        var template = document.querySelector('[data-target="branchRuleTemplate"]');
        var add = document.querySelector('[data-target="branchRuleAdd"]');
        var warning = document.querySelector('[data-target="branchRuleDuplicateWarning"]');
        if (!list) return;

        function option(value, label, selectedValue) {
            var el = document.createElement('option');
            el.value = value;
            el.textContent = label;
            if (String(selectedValue || '') === value) {
                el.selected = true;
            }
            return el;
        }

        function getFieldOptions(pageKey, includeDisplayOnly) {
            var seen = {};
            var out = [];
            getFieldItems().forEach(function (field) {
                var keyInput = field.querySelector('[data-target="c-formEditor__fieldKeyInput"]');
                var labelInput = field.querySelector('[data-target="c-formEditor__labelInput"]');
                var pageInput = field.querySelector('[data-target="c-formEditor__inputPageKey"]');
                var typeInput = field.querySelector('[data-target="c-formEditor__type"]');
                var key = keyInput ? keyInput.value.trim() : '';
                var fieldPageKey = pageInput ? pageInput.value.trim() : 'input-1';
                if (pageKey && fieldPageKey !== pageKey) return;
                if (!includeDisplayOnly && isDisplayOnlyFieldType(typeInput ? typeInput.value : '')) return;
                if (!key || seen[key]) return;
                seen[key] = true;
                var label = labelInput && labelInput.value.trim() ? labelInput.value.trim() + '（' + key + '）' : key;
                out.push({ value: key, label: label });
            });
            return out;
        }

        function getGroupOptions(pageKey) {
            var seen = {};
            var out = [];
            getGroupItems().forEach(function (group) {
                var keyInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__groupKey"]');
                var labelInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__labelInput"]');
                var pageInput = queryOwnGroupControl(group, '[data-target="c-formEditorGroup__inputPageKey"]');
                var key = keyInput ? keyInput.value.trim() : '';
                var groupPageKey = pageInput ? pageInput.value.trim() : 'input-1';
                if (pageKey && groupPageKey !== pageKey) return;
                if (!key || seen[key]) return;
                seen[key] = true;
                var label = labelInput && labelInput.value.trim() ? 'グループ: ' + labelInput.value.trim() + '（' + key + '）' : 'グループ: ' + key;
                out.push({ value: key, label: label, targetType: 'group' });
            });
            return out;
        }

        function getScreenOptions(excludePageKey, inputOnly) {
            var out = [];
            document.querySelectorAll('[data-tab-panel^="screen-input-"]').forEach(function (panel) {
                var keyInput = panel.querySelector('[data-input-page-name="page_key"]');
                var titleInput = panel.querySelector('[data-target="inputPageTitle"]');
                var key = keyInput ? keyInput.value.trim() : '';
                if (!key) return;
                if (excludePageKey && key === excludePageKey) return;
                var label = titleInput && titleInput.value.trim() ? titleInput.value.trim() : key;
                out.push({ value: key, label: label });
            });
            if (inputOnly) return out;
            out.push({ value: 'confirm', label: '確認画面' });
            out.push({ value: 'thanks', label: '完了画面' });
            return out;
        }

        function syncSelect(select, options, placeholder) {
            if (!select) return;
            var current = select.value || select.getAttribute('data-value') || '';
            select.innerHTML = '';
            select.appendChild(option('', placeholder || '選択してください', current));
            options.forEach(function (item) {
                var itemOption = option(item.value, item.label, current);
                if (item.targetType) {
                    itemOption.setAttribute('data-target-type', item.targetType);
                }
                select.appendChild(itemOption);
            });
            var exists = options.some(function (item) { return item.value === current; });
            select.value = exists ? current : '';
            select.setAttribute('data-value', select.value);
        }

        function selectedLabel(select, fallback) {
            if (!select || !select.value) return fallback || '';
            var selected = select.options[select.selectedIndex];
            return selected ? selected.textContent : select.value;
        }

        function syncRowSummary(row, index) {
            var trigger = row.querySelector('[data-target="branchRuleTriggerPage"]');
            var source = row.querySelector('[data-target="branchRuleSourceField"]');
            var action = row.querySelector('[data-target="branchRuleActionType"]');
            var target = row.querySelector('[data-target="branchRuleTargetKey"]');
            var summaryIndex = row.querySelector('[data-target="branchRuleSummaryIndex"]');
            var summaryTrigger = row.querySelector('[data-target="branchRuleSummaryTriggerPage"]');
            var summarySource = row.querySelector('[data-target="branchRuleSummarySource"]');
            var summaryAction = row.querySelector('[data-target="branchRuleSummaryAction"]');
            var summaryTarget = row.querySelector('[data-target="branchRuleSummaryTargetLabel"]');
            if (summaryIndex && typeof index === 'number') summaryIndex.textContent = String(index + 1);
            if (summaryTrigger) summaryTrigger.textContent = selectedLabel(trigger, '対象ページ未選択');
            if (summarySource) summarySource.textContent = selectedLabel(source, '条件元未選択');
            if (summaryAction) summaryAction.textContent = selectedLabel(action, '処理未選択');
            if (summaryTarget) summaryTarget.textContent = selectedLabel(target, '対象未選択');
        }

        function syncRowOptions(row) {
            var trigger = row.querySelector('[data-target="branchRuleTriggerPage"]');
            var source = row.querySelector('[data-target="branchRuleSourceField"]');
            var action = row.querySelector('[data-target="branchRuleActionType"]');
            var target = row.querySelector('[data-target="branchRuleTargetKey"]');
            var targetType = row.querySelector('[data-target="branchRuleTargetType"]');
            var triggerValue = trigger ? trigger.value : 'input-1';
            syncSelect(trigger, getScreenOptions('', true), '選択してください');
            triggerValue = trigger ? trigger.value : triggerValue;
            syncSelect(source, getFieldOptions(triggerValue), '選択してください');
            var targetOptions = action && action.value === 'go_to_screen'
                ? getScreenOptions(triggerValue, false).map(function (item) {
                    item.targetType = 'screen';
                    return item;
                })
                : getFieldOptions('', true).map(function (item) {
                    item.targetType = 'field';
                    return item;
                }).concat(getGroupOptions());
            syncSelect(target, targetOptions, '選択してください');
            if (targetType) {
                var selected = target && target.selectedOptions ? target.selectedOptions[0] : null;
                var selectedType = selected ? selected.getAttribute('data-target-type') : '';
                targetType.value = selectedType === 'group' ? 'group' : 'field';
            }
            syncRowSummary(row);
        }

        function updateDuplicateWarning() {
            if (!warning) return;
            var seen = {};
            var duplicates = [];
            list.querySelectorAll('[data-branch-rule-row]').forEach(function (row) {
                var action = row.querySelector('[data-target="branchRuleActionType"]');
                var target = row.querySelector('[data-target="branchRuleTargetKey"]');
                var remove = row.querySelector('[data-target="branchRuleRemoveFlag"]');
                if (remove && remove.value === '1') return;
                var actionValue = action ? action.value : '';
                var targetValue = target ? target.value : '';
                var targetType = row.querySelector('[data-target="branchRuleTargetType"]');
                var targetTypeValue = targetType ? targetType.value : 'field';
                var trigger = row.querySelector('[data-target="branchRuleTriggerPage"]');
                var triggerValue = trigger ? trigger.value : '';
                if (!actionValue || !targetValue) return;
                var key = triggerValue + ':' + actionValue + ':' + targetTypeValue + ':' + targetValue;
                if (seen[key] && duplicates.indexOf(key) === -1) {
                    duplicates.push(key);
                }
                seen[key] = true;
            });
            if (!duplicates.length) {
                warning.hidden = true;
                warning.innerHTML = '';
                return;
            }
            warning.hidden = false;
            warning.innerHTML = duplicates.map(function (key) {
                var parts = key.split(':');
                var label = parts[1] === 'show_field' ? (parts[2] === 'group' ? 'グループ' : '項目') : 'ページ';
                return '<p>同じ' + label + '（' + parts.slice(3).join(':') + '）が複数の分岐で設定されています。</p>';
            }).join('');
        }

        function reindexBranchRules() {
            list.querySelectorAll('[data-branch-rule-row]').forEach(function (row, index) {
                row.querySelectorAll('[data-branch-rule-name]').forEach(function (el) {
                    var key = el.getAttribute('data-branch-rule-name');
                    if (!key) return;
                    el.setAttribute('name', 'branch_rules[' + index + '][' + key + ']');
                });
                syncRowOptions(row);
                syncRowSummary(row, index);
            });
            updateDuplicateWarning();
        }

        function bindRow(row) {
            if (!row || row.getAttribute('data-branch-rule-bound') === '1') return;
            var remove = row.querySelector('[data-target="branchRuleRemove"]');
            var trigger = row.querySelector('[data-target="branchRuleTriggerPage"]');
            var action = row.querySelector('[data-target="branchRuleActionType"]');
            var target = row.querySelector('[data-target="branchRuleTargetKey"]');
            var targetType = row.querySelector('[data-target="branchRuleTargetType"]');
            var header = row.querySelector('.c-formEditor__itemHeader');
            if (header && header.getAttribute('data-accordion-bound') !== '1') {
                header.addEventListener('click', function (event) {
                    if (event.target.closest('.area.is-delete')) return;
                    row.classList.toggle('is-collapsed');
                });
                header.setAttribute('data-accordion-bound', '1');
            }
            if (remove) {
                remove.addEventListener('click', function () {
                    if (confirm('この分岐を削除しますか？')) {
                        row.parentNode.removeChild(row);
                        reindexBranchRules();
                    }
                });
            }
            if (action) {
                action.addEventListener('change', function () {
                    if (target) {
                        target.setAttribute('data-value', '');
                        target.value = '';
                    }
                    syncRowOptions(row);
                    updateDuplicateWarning();
                });
            }
            if (trigger) {
                trigger.addEventListener('change', function () {
                    var source = row.querySelector('[data-target="branchRuleSourceField"]');
                    if (source) {
                        source.setAttribute('data-value', '');
                        source.value = '';
                    }
                    if (target && action && action.value === 'go_to_screen') {
                        target.setAttribute('data-value', '');
                        target.value = '';
                    }
                    syncRowOptions(row);
                    updateDuplicateWarning();
                });
            }
            row.querySelectorAll('input, select').forEach(function (el) {
                el.addEventListener('change', function () {
                    if (el.matches('select')) {
                        el.setAttribute('data-value', el.value);
                    }
                    if (el === target && targetType) {
                        var selected = target.selectedOptions ? target.selectedOptions[0] : null;
                        var selectedType = selected ? selected.getAttribute('data-target-type') : '';
                        targetType.value = selectedType === 'group' ? 'group' : 'field';
                    }
                    syncRowSummary(row);
                    updateDuplicateWarning();
                });
            });
            row.setAttribute('data-branch-rule-bound', '1');
            syncRowOptions(row);
        }

        list.querySelectorAll('[data-branch-rule-row]').forEach(bindRow);
        if (add && template) {
            add.addEventListener('click', function () {
                var index = list.querySelectorAll('[data-branch-rule-row]').length;
                var html = template.innerHTML
                    .replace(/__INDEX__/g, String(index))
                    .replace(/__RULE_KEY__/g, 'branch-' + generateUuidV4());
                var holder = document.createElement('div');
                holder.innerHTML = html.trim();
                var row = holder.firstElementChild;
                if (!row) return;
                list.appendChild(row);
                bindRow(row);
                reindexBranchRules();
                var trigger = row.querySelector('[data-target="branchRuleTriggerPage"]');
                if (trigger) trigger.focus();
            });
        }
        document.addEventListener('input', function (event) {
            if (event.target.matches('[data-target="c-formEditor__fieldKeyInput"], [data-target="c-formEditor__labelInput"], [data-target="c-formEditorGroup__groupKeyInput"], [data-target="c-formEditorGroup__labelInput"], [data-target="inputPageTitle"], [data-target="c-formEditor__inputPageKey"], [data-target="c-formEditorGroup__inputPageKey"]')) {
                reindexBranchRules();
            }
        });
        document.addEventListener('change', function (event) {
            if (event.target.matches('[data-target="c-formEditor__fieldKeyInput"], [data-target="c-formEditor__labelInput"], [data-target="c-formEditorGroup__groupKeyInput"], [data-target="c-formEditorGroup__labelInput"], [data-target="inputPageTitle"], [data-target="c-formEditor__inputPageKey"], [data-target="c-formEditorGroup__inputPageKey"]')) {
                reindexBranchRules();
            }
        });
        document.addEventListener('formkun:fields-changed', reindexBranchRules);
        document.addEventListener('formkun:input-pages-changed', reindexBranchRules);
        reindexBranchRules();
    })();

    (function () {
        var root = mainForm ? mainForm.querySelector('[data-auto-reply-recipient]') : null;
        if (!root) return;

        var listWrap = root.querySelector('[data-target="autoReplyRecipientListWrap"]');
        var emptyText = root.querySelector('[data-target="autoReplyRecipientEmptyText"]');

        if (!listWrap) return;

        function replyRecipientOptions() {
            var payload = buildBuilderPayload(mainForm);
            var pageTitles = {};
            (Array.isArray(payload && payload.input_pages) ? payload.input_pages : []).forEach(function (page, index) {
                if (!page || typeof page !== 'object') return;
                var pageKey = page.page_key ? String(page.page_key).trim() : '';
                if (!pageKey) {
                    pageKey = 'input-' + String(index + 1);
                }
                var title = page.title ? String(page.title).trim() : '';
                if (!title) {
                    title = '入力画面 ' + String(index + 1);
                }
                pageTitles[pageKey] = title;
            });
            var pageCount = Object.keys(pageTitles).length;

            return (Array.isArray(payload && payload.fields) ? payload.fields : []).map(function (field) {
                if (!field || typeof field !== 'object') {
                    return null;
                }
                var type = field.type ? String(field.type).trim() : '';
                var fieldKey = field.field_key ? String(field.field_key).trim() : '';
                var visible = String(field.visible || '') === '1';

                if (type !== 'email' || !fieldKey || !visible) {
                    return null;
                }

                var fieldLabel = field.label ? String(field.label).trim() : '';
                if (!fieldLabel) {
                    fieldLabel = fieldKey;
                }
                var label = fieldLabel === fieldKey ? fieldKey : fieldLabel + '（' + fieldKey + '）';
                if (pageCount > 1) {
                    var pageKey = field.input_page_key ? String(field.input_page_key).trim() : '';
                    var pageTitle = pageTitles[pageKey] || pageKey;
                    label = pageTitle + ' / ' + label;
                }

                return {
                    value: fieldKey,
                    label: label
                };
            }).filter(Boolean);
        }

        function selectedReplyRecipientValues() {
            var checked = Array.prototype.slice.call(root.querySelectorAll('input[name="reply_from_field_key[]"]:checked')).map(function (input) {
                return input.value;
            }).filter(Boolean);
            if (checked.length > 0) {
                return checked;
            }

            try {
                var initial = JSON.parse(root.getAttribute('data-selected') || '[]');
                return Array.isArray(initial) ? initial.map(function (value) {
                    return String(value || '').trim();
                }).filter(Boolean) : [];
            } catch (error) {
                return [];
            }
        }

        function rememberSelectedReplyRecipientValues(values) {
            root.setAttribute('data-selected', JSON.stringify(values));
        }

        function replyCheckbox(value, label, selectedValues) {
            var wrapper = document.createElement('div');
            wrapper.setAttribute('data-target', 'autoReplyRecipientItem');

            var labelElement = document.createElement('label');
            labelElement.setAttribute('data-module', 'm-checkbox01');
            var input = document.createElement('input');
            input.type = 'checkbox';
            input.name = 'reply_from_field_key[]';
            input.value = value;
            input.checked = selectedValues.indexOf(value) !== -1;
            labelElement.appendChild(input);
            var text = document.createElement('span');
            text.className = 'text';
            text.textContent = label;
            labelElement.appendChild(text);
            wrapper.appendChild(labelElement);

            return wrapper;
        }

        function syncReplyRecipient() {
            var options = replyRecipientOptions();
            var selectedValues = selectedReplyRecipientValues().filter(function (value, index, values) {
                return values.indexOf(value) === index;
            });
            var availableValues = options.map(function (item) {
                return item.value;
            });
            var filteredSelectedValues = selectedValues.filter(function (value) {
                return availableValues.indexOf(value) !== -1;
            });

            listWrap.innerHTML = '';
            options.forEach(function (item) {
                listWrap.appendChild(replyCheckbox(item.value, item.label, filteredSelectedValues));
            });
            rememberSelectedReplyRecipientValues(filteredSelectedValues);

            listWrap.hidden = options.length === 0;
            if (emptyText) {
                emptyText.hidden = options.length > 0;
            }
        }

        root.addEventListener('change', function (event) {
            if (event.target.matches('input[name="reply_from_field_key[]"]')) {
                rememberSelectedReplyRecipientValues(selectedReplyRecipientValues());
            }
        });

        document.addEventListener('input', function (event) {
            if (event.target.matches('[data-target="c-formEditor__fieldKeyInput"], [data-target="c-formEditor__labelInput"], [data-target="inputPageTitle"]')) {
                syncReplyRecipient();
            }
        });
        document.addEventListener('change', function (event) {
            if (event.target.matches('[data-target="c-formEditor__fieldKeyInput"], [data-target="c-formEditor__labelInput"], [data-target="inputPageTitle"], input[name^="fields["][name$="[visible]"]')) {
                syncReplyRecipient();
            }
        });
        document.addEventListener('formkun:fields-changed', syncReplyRecipient);
        document.addEventListener('formkun:input-pages-changed', syncReplyRecipient);
        syncReplyRecipient();
    })();

    document.addEventListener('input', function (event) {
        var module = event.target.closest ? event.target.closest('[data-module="m-input01"]') : null;
        if (module) {
            syncInputModuleState(module);
        }
        if (mainForm && mainForm.contains(event.target)) {
            queueDirtyState();
        }
    });

    document.addEventListener('change', function (event) {
        var module = event.target.closest ? event.target.closest('[data-module="m-input01"]') : null;
        if (module) {
            syncInputModuleState(module);
        }
        if (mainForm && mainForm.contains(event.target)) {
            queueDirtyState();
        }
    });

    reindex();
    descriptionEditors.forEach(function (editor) {
        reindexDescriptionBlocks(editor);
        refreshDescriptionPositionOptions(editor);
    });
    publishScheduleEditors.forEach(function (editor) {
        reindexPublishRules(editor);
    });
    syncPublishScheduleUi();
    syncInputModuleStates(document);
    if (mainForm) {
        var initialBuilderPayload = buildBuilderPayload(mainForm);
        syncBuilderMeta(mainForm, initialBuilderPayload, countPostableFormValues(mainForm, true));
    }
    if (mainForm && dirtyActions) {
        reindexInputPages();
        syncBuilderForm(mainForm);
        descriptionEditors.forEach(function (editor) {
            reindexDescriptionBlocks(editor);
        });
        initialFormSnapshot = serializeFormSnapshot(mainForm);
        updateDirtyState();
        if (dirtyCancel) {
            dirtyCancel.addEventListener('click', function () {
                window.location.reload();
            });
        }
        new MutationObserver(function () {
            if (dirtyStateSuppressDepth > 0) return;
            queueDirtyState();
        }).observe(mainForm, { childList: true, subtree: true });
    }

    var titleInput = document.getElementById('title');
    var breadcrumbCurrent = document.querySelector('[data-target="p-formEdit01__breadcrumbCurrent"]');
    if (titleInput && breadcrumbCurrent) {
        titleInput.addEventListener('input', function () {
            var nextTitle = titleInput.value.trim() || '（無題）';
            breadcrumbCurrent.textContent = nextTitle;
        });
    }

    var slugInput = document.getElementById('slug');
    var slugPreview = document.querySelector('[data-target="p-formEdit01__slugPreview"]');
    var slugLink = document.querySelector('[data-target="p-formEdit01__slugLink"]');
    if (slugInput && slugPreview) {
        slugInput.addEventListener('input', function () {
            var slugValue = slugInput.value || 'your-slug';
            slugPreview.textContent = slugValue;
            if (slugLink) {
                var base = slugLink.getAttribute('data-base-url');
                if (!base) {
                    base = slugLink.href.replace(/\/[^/]*$/, '/');
                    slugLink.setAttribute('data-base-url', base);
                }
                slugLink.href = base + slugValue;
            }
        });
    }
    function initSettingsAppUpdate() {
        var btn = document.querySelector('[data-target="settings-app-update-run"]');
        var modal = document.querySelector('[data-settings-app-update-modal]');
        if (!btn || !modal) return;

        var meta = document.querySelector('[data-target="settings-app-update-meta"]');
        var actionUrl = meta ? (meta.getAttribute('data-action-url') || '') : '';
        var tokenInput = meta ? meta.querySelector('input[name="_token"]') : null;
        var versionInput = meta ? meta.querySelector('input[name="version"]') : null;
        var csrfToken = tokenInput ? tokenInput.value : '';
        var version = btn.getAttribute('data-version') || (versionInput ? versionInput.value : '');

        var progressEl = modal.querySelector('[data-target="settings-app-update-progress"]');
        var fill = progressEl ? progressEl.querySelector('.fill') : null;
        var runningState = modal.querySelector('[data-settings-app-update-state="running"]');
        var doneState = modal.querySelector('[data-settings-app-update-state="done"]');
        var errorState = modal.querySelector('[data-settings-app-update-state="error"]');
        var errorText = modal.querySelector('[data-target="settings-app-update-error"]');
        var reloadBtns = modal.querySelectorAll('[data-target="settings-app-update-reload"]');

        var timer = null;
        var beforeUnloadHandler = null;

        function setProgress(value) {
            var v = Math.max(0, Math.min(100, value));
            if (fill) fill.style.width = v + '%';
            if (progressEl) progressEl.setAttribute('aria-valuenow', String(Math.round(v)));
        }

        function showState(name) {
            if (runningState) runningState.hidden = name !== 'running';
            if (doneState) doneState.hidden = name !== 'done';
            if (errorState) errorState.hidden = name !== 'error';
        }

        function openModal() {
            modal.hidden = false;
            document.body.classList.add('is-settings-app-update-modal-open');
            showState('running');
            setProgress(0);
            if (timer) clearInterval(timer);
            timer = setInterval(function () {
                var current = fill ? parseFloat(fill.style.width) || 0 : 0;
                if (current >= 90) return;
                setProgress(current + Math.max(0.5, (90 - current) * 0.08));
            }, 400);
            beforeUnloadHandler = function (event) {
                event.preventDefault();
                event.returnValue = '';
            };
            window.addEventListener('beforeunload', beforeUnloadHandler);
        }

        function closeModal() {
            modal.hidden = true;
            document.body.classList.remove('is-settings-app-update-modal-open');
            if (timer) { clearInterval(timer); timer = null; }
            if (beforeUnloadHandler) {
                window.removeEventListener('beforeunload', beforeUnloadHandler);
                beforeUnloadHandler = null;
            }
        }

        btn.addEventListener('click', function () {
            if (!confirm('バージョン ' + version + ' に更新します。よろしいですか？')) return;
            openModal();
            var formData = new FormData();
            formData.append('_token', csrfToken);
            formData.append('version', version);
            fetch(actionUrl, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin',
                headers: { Accept: 'application/json' },
            }).then(function (response) {
                return response.json().then(function (data) {
                    return { ok: response.ok && (data && data.ok), data: data };
                }).catch(function () {
                    return { ok: false, data: { message: '応答の解析に失敗しました。' } };
                });
            }).then(function (result) {
                if (timer) { clearInterval(timer); timer = null; }
                if (result.ok) {
                    setProgress(100);
                    showState('done');
                } else {
                    var msg = (result.data && result.data.message) ? result.data.message : 'アップデートに失敗しました。';
                    if (errorText) errorText.textContent = msg;
                    showState('error');
                }
                if (beforeUnloadHandler) {
                    window.removeEventListener('beforeunload', beforeUnloadHandler);
                    beforeUnloadHandler = null;
                }
            }).catch(function () {
                if (timer) { clearInterval(timer); timer = null; }
                if (errorText) errorText.textContent = '通信に失敗しました。';
                showState('error');
                if (beforeUnloadHandler) {
                    window.removeEventListener('beforeunload', beforeUnloadHandler);
                    beforeUnloadHandler = null;
                }
            });
        });

        Array.prototype.forEach.call(reloadBtns, function (rb) {
            rb.addEventListener('click', function () {
                window.location.reload();
            });
        });
    }

})();