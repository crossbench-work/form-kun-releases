<?php $maskedEmail = (string) ($maskedEmail ?? ''); ?>
<form method="post" action="<?= e(base_path('/admin/login/verify')) ?>" class="block is-contents" id="admin-login-verify-form">
    <?= \Core\Csrf::field() ?>
    <div class="area is-title">
        <h2 class="title">認証番号の確認</h2>
    </div>

    <div class="area is-field">
        <p data-module="m-text01" data-type="muted">登録済みのメールアドレス（<strong><?= e($maskedEmail !== '' ? $maskedEmail : '（宛先不明）') ?></strong>）宛に送信した認証番号を入力してください。認証番号の有効期限は10分です。</p>
    </div>

    <div class="area is-field">
        <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('認証番号'), 'code'); ?>
            </div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('code', [
                    'type' => 'text',
                    'id' => 'code',
                    'name' => 'code',
                    'inputmode' => 'numeric',
                    'autocomplete' => 'one-time-code',
                    'maxlength' => 6,
                    'required' => true,
                ])); ?>
                <?php admin_m_input01_close(); ?>
            </div>
        <?php admin_m_input_set01_close(); ?>
    </div>

    <div class="area is-actions">
        <?php admin_m_btn01_button_wrap('確認', ['type' => 'submit', 'class' => 'is-primary']); ?>
    </div>
</form>

<div class="block is-contents">
    <div class="area is-actions">
        <form method="post" action="<?= e(base_path('/admin/login/verify/resend')) ?>">
            <?= \Core\Csrf::field() ?>
            <?php admin_m_btn01_button_wrap('認証番号を再送', ['type' => 'submit']); ?>
        </form>
        <form method="post" action="<?= e(base_path('/admin/login/verify/cancel')) ?>">
            <?= \Core\Csrf::field() ?>
            <?php admin_m_btn01_button_wrap('ログインに戻る', ['type' => 'submit']); ?>
        </form>
    </div>
</div>
