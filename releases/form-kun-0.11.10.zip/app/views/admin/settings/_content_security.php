<?php
/**
 * 設定「セキュリティ」タブの内容（2要素認証）。スタイルは既存の設定パネルと共通。
 */
admin_c_form_block01_open();
?>
            <div class="block is-title">
                <?php admin_m_large_title01('セキュリティ'); ?>
            </div>
            <div class="block is-settingsBasic">
                <form method="post" action="<?= e(base_path('/admin/settings/two-factor')) ?>">
                    <?= \Core\Csrf::field() ?>
                    <div class="block">
                        <div class="area is-title">
                            <?php admin_m_left_border_title01(e('2要素認証'), 'two_factor_enabled'); ?>
                        </div>
                        <div class="area is-field">
                            <?php admin_m_checkbox01('2要素認証を有効にする', admin_m_input01_attrs_with_bound_label('two_factor_enabled', [
                                'name' => 'two_factor_enabled',
                                'id' => 'two_factor_enabled',
                                'value' => '1',
                                'checked' => !empty($two_factor_enabled),
                            ])); ?>
                            <p class="text is-help">有効にすると、ログイン時にメールで認証番号を送信するようになります（フェーズ2で組み込み予定）。</p>
                        </div>
                        <div class="block is-actions">
                            <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                        </div>
                    </div>
                </form>
            </div>
<?php admin_c_form_block01_close(); ?>
