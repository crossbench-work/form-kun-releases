<?php
namespace Models;

use Core\Database;

/**
 * ログイン用メール認証番号（フェーズ1: モデルのみ。ログイン処理への組み込みはフェーズ2）。
 * コードは平文で保存せず sha256 ハッシュで保持する。平文が存在するのは発行直後のメール送信用のみ。
 */
class LoginEmailCode
{
    /** 認証番号の試行回数上限（5回に達したらそのコードを無効化する） */
    public const MAX_ATTEMPTS = 5;

    public static function deleteExpired(): void
    {
        try {
            Database::execute('DELETE FROM login_email_codes WHERE expires_at < NOW()');
        } catch (\Throwable $e) {
            // テーブル未作成時は無視（マイグレーション前）
            error_log('[formkun] login_email_codes deleteExpired: ' . $e->getMessage());
        }
    }

    /**
     * 既存コードを失効させ、新しい6桁の数字コードを発行する（平文コードを返す）。
     */
    public static function issue(int $userId): string
    {
        self::deleteExpired();
        Database::execute('DELETE FROM login_email_codes WHERE user_id = ?', [$userId]);

        $raw = '';
        for ($i = 0; $i < 6; $i++) {
            $raw .= (string) random_int(0, 9);
        }
        $hash = hash('sha256', $raw);
        $ttl = (int) config('security.email_code_ttl_seconds', 600);
        $expires = date('Y-m-d H:i:s', time() + max(60, $ttl));

        Database::execute(
            'INSERT INTO login_email_codes (user_id, code_hash, expires_at, attempts, created_at) VALUES (?,?,?,?,?)',
            [$userId, $hash, $expires, 0, date('Y-m-d H:i:s')]
        );
        return $raw;
    }

    /**
     * 有効期限内かつ試行回数が上限未満の最新コードと照合する。
     * 失敗ごとに attempts を加算し、上限に達したらそのコードを無効化する。成功したらコードを削除する。
     */
    public static function verify(int $userId, string $code): bool
    {
        self::deleteExpired();
        $code = trim($code);
        if ($code === '' || !ctype_digit($code)) {
            return false;
        }

        $row = Database::fetchOne(
            'SELECT id, code_hash, attempts FROM login_email_codes
             WHERE user_id = ? AND expires_at >= NOW() AND attempts < ?',
            [$userId, self::MAX_ATTEMPTS]
        );
        if ($row === null) {
            return false;
        }

        if (!hash_equals((string) $row['code_hash'], hash('sha256', $code))) {
            $attempts = (int) $row['attempts'] + 1;
            if ($attempts >= self::MAX_ATTEMPTS) {
                Database::execute('DELETE FROM login_email_codes WHERE id = ?', [(int) $row['id']]);
            } else {
                Database::execute('UPDATE login_email_codes SET attempts = ? WHERE id = ?', [$attempts, (int) $row['id']]);
            }
            return false;
        }

        Database::execute('DELETE FROM login_email_codes WHERE id = ?', [(int) $row['id']]);
        return true;
    }

    /**
     * ユーザーに有効なコード（期限内・試行回数未達）が残っているか。
     */
    public static function hasValid(int $userId): bool
    {
        self::deleteExpired();
        try {
            $row = Database::fetchOne(
                'SELECT id FROM login_email_codes WHERE user_id = ? AND expires_at >= NOW() AND attempts < ?',
                [$userId, self::MAX_ATTEMPTS]
            );
        } catch (\Throwable $e) {
            // テーブル未作成時は無効扱い（マイグレーション前）
            return false;
        }
        return $row !== null;
    }

    /**
     * ユーザーの全コードを失効させる（メール送信に失敗したときなど）。
     */
    public static function invalidateForUser(int $userId): void
    {
        try {
            Database::execute('DELETE FROM login_email_codes WHERE user_id = ?', [$userId]);
        } catch (\Throwable $e) {
            // テーブル未作成時は無視（マイグレーション前）
            error_log('[formkun] login_email_codes invalidateForUser: ' . $e->getMessage());
        }
    }
}
