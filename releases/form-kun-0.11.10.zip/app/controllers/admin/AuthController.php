<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\Csrf;
use Core\Mailer;
use Core\View;
use Models\AppSetting;
use Models\FormVersion;
use Models\LoginEmailCode;
use Models\OperationLog;
use Models\PasswordReset;
use Models\User;

class AuthController
{
    public function loginForm(): void
    {
        if (Auth::check()) {
            redirect('/admin/');
        }
        // 初期管理者がいなければ setup へ
        if (User::count() === 0) {
            redirect('/admin/setup');
        }

        (new View())->render('admin/auth/login', [
            'title' => 'ログイン',
        ], 'admin_minimal');
    }

    public function login(): void
    {
        Csrf::verify();

        $username = trim((string) ($_POST['username'] ?? ''));
        $password = (string) ($_POST['password'] ?? '');
        $ip = client_ip();

        if (Auth::isLockedOut($ip, $username)) {
            flash('danger', '連続してログインに失敗しています。しばらく時間をおいてから再度お試しください。');
            redirect('/admin/login');
        }

        if ($username === '' || $password === '') {
            Auth::recordAttempt($ip, $username, false);
            flash('danger', 'ユーザー名とパスワードを入力してください。');
            redirect('/admin/login');
        }

        $user = User::findByUsername($username);
        if (!$user || !password_verify($password, $user['password_hash'])) {
            // タイミング攻撃緩和のため微小スリープ
            usleep(random_int(100000, 400000));
            Auth::recordAttempt($ip, $username, false);
            flash('danger', 'ユーザー名またはパスワードが正しくありません。');
            redirect('/admin/login');
        }

        // 2要素認証（メール認証番号）: 有効なら認証番号ステップへ進み、ここではログインを完了させない
        if ((AppSetting::get(AppSetting::KEY_TWO_FACTOR_ENABLED) ?? '0') === '1') {
            if (trim((string) ($user['email'] ?? '')) === '') {
                flash('danger', 'メールアドレスが登録されていないため、認証番号を送信できません。管理者にお問い合わせください。');
                redirect('/admin/login');
            }

            if ($this->issueAndSendCode($user) === null) {
                flash('danger', 'メール送信に失敗しました。メール設定やサーバ環境を確認してください。');
                redirect('/admin/login');
            }

            $_SESSION['_two_factor_pending'] = [
                'user_id'        => (int) $user['id'],
                'last_issued_at' => time(),
            ];
            redirect('/admin/login/verify');
        }

        $this->completeLogin($user, $ip, $username);
    }

    /**
     * パスワード認証（＋必要なら認証番号検証）後のログイン完了処理。両経路で共通。
     */
    private function completeLogin(array $user, string $ip, string $username): void
    {
        Auth::login($user);
        Auth::recordAttempt($ip, $username, true);
        User::recordLogin((int) $user['id']);
        FormVersion::createLifecycleSnapshots(FormVersion::ACTION_LOGIN, Auth::user());

        $usernameLog = (string) ($user['username'] ?? $username);
        OperationLog::user('auth.login', [
            'summary'     => 'ユーザー「' . $usernameLog . '」がログインしました',
            'target_type' => 'user',
            'target_id'   => (int) $user['id'],
            'target_name' => $usernameLog,
        ]);

        $intended = $_SESSION['_intended'] ?? null;
        unset($_SESSION['_intended']);

        // リダイレクト直前にセッションを確実に保存（環境によっては Cookie が欠けるのを防ぐ）
        session_write_close();

        if ($intended && is_string($intended)) {
            header('Location: ' . $intended);
            exit;
        }
        redirect('/admin/');
    }

    /**
     * 認証番号を発行して登録メールアドレス宛に送信する。
     * 成功時は平文コード、メール未登録・送信失敗時は null を返す（送信失敗時は発行済みコードを無効化する）。
     */
    private function issueAndSendCode(array $user): ?string
    {
        $email = trim((string) ($user['email'] ?? ''));
        if ($email === '' || filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            return null;
        }

        $code = LoginEmailCode::issue((int) $user['id']);
        try {
            $subject = (string) config('mail.two_factor_code_subject', '[ふぉーむくん] ログイン認証番号');
            $bodyTpl = (string) config(
                'mail.two_factor_code_body',
                "管理画面へのログイン用認証番号は次のとおりです（10分以内）。\n\n{{code}}\n\n心当たりがない場合はこのメールを無視してください。"
            );
            if (Mailer::send($email, $subject, str_replace('{{code}}', $code, $bodyTpl))) {
                return $code;
            }
        } catch (\Throwable $e) {
            error_log('[formkun] two factor code mail failed: ' . $e->getMessage());
        }
        LoginEmailCode::invalidateForUser((int) $user['id']);
        return null;
    }

    /** 認証番号の入力画面（保留状態が無ければログイン画面へ） */
    public function verifyForm(): void
    {
        if (Auth::check()) {
            redirect('/admin/');
        }
        $user = $this->pendingUser();
        if ($user === null) {
            redirect('/admin/login');
        }

        (new View())->render('admin/auth/login_verify', [
            'title'       => '認証番号の確認',
            'maskedEmail' => self::maskEmail((string) ($user['email'] ?? '')),
        ], 'admin_minimal');
    }

    /** 認証番号の検証 */
    public function verifySubmit(): void
    {
        Csrf::verify();
        if (Auth::check()) {
            redirect('/admin/');
        }
        $user = $this->pendingUser();
        if ($user === null) {
            redirect('/admin/login');
        }

        $ip = client_ip();
        $username = (string) $user['username'];

        if (Auth::isLockedOut($ip, $username)) {
            flash('danger', '連続してログインに失敗しています。しばらく時間をおいてから再度お試しください。');
            redirect('/admin/login');
        }

        $code = trim((string) ($_POST['code'] ?? ''));
        if ($code === '') {
            flash('danger', '認証番号を入力してください。');
            redirect('/admin/login/verify');
        }

        if (LoginEmailCode::verify((int) $user['id'], $code)) {
            unset($_SESSION['_two_factor_pending']);
            $this->completeLogin($user, $ip, $username);
            return;
        }

        // 検証失敗はロックアウト判定に含める
        Auth::recordAttempt($ip, $username, false);

        if (!LoginEmailCode::hasValid((int) $user['id'])) {
            flash('danger', '認証番号の有効期限が切れたか、試行回数の上限に達しました。認証番号を再送するか、最初からログインし直してください。');
        } else {
            flash('danger', '認証番号が正しくありません。メールに届いた認証番号を入力してください。');
        }
        redirect('/admin/login/verify');
    }

    /** 認証番号の再送（前回発行から60秒以上空いている場合のみ。古いコードは無効化される） */
    public function verifyResend(): void
    {
        Csrf::verify();
        if (Auth::check()) {
            redirect('/admin/');
        }
        $pending = $_SESSION['_two_factor_pending'] ?? null;
        $user = $this->pendingUser();
        if (!is_array($pending) || $user === null) {
            redirect('/admin/login');
        }

        $now = time();
        if ($now - (int) ($pending['last_issued_at'] ?? 0) < 60) {
            flash('danger', '連続して再送はできません。1分ほど待ってからもう一度お試しください。');
            redirect('/admin/login/verify');
        }

        if ($this->issueAndSendCode($user) === null) {
            unset($_SESSION['_two_factor_pending']);
            flash('danger', 'メール送信に失敗しました。メール設定やサーバ環境を確認してください。');
            redirect('/admin/login');
        }

        $_SESSION['_two_factor_pending']['last_issued_at'] = $now;
        flash('success', '認証番号を再送しました。');
        redirect('/admin/login/verify');
    }

    /** 認証番号ステップを破棄してログイン画面へ戻る */
    public function verifyCancel(): void
    {
        Csrf::verify();
        unset($_SESSION['_two_factor_pending']);
        flash('info', 'ログインを中断しました。最初からやり直してください。');
        redirect('/admin/login');
    }

    /**
     * 保留状態（認証番号待ち）のユーザーを返す。保留状態が無い・ユーザーが消えている場合は null。
     */
    private function pendingUser(): ?array
    {
        $pending = $_SESSION['_two_factor_pending'] ?? null;
        if (!is_array($pending)) {
            return null;
        }
        $user = User::find((int) ($pending['user_id'] ?? 0));
        if ($user === null) {
            unset($_SESSION['_two_factor_pending']);
            return null;
        }
        return $user;
    }

    /**
     * 表示用にメールアドレスの一部を伏せる（例: ab***@example.com）。
     */
    private static function maskEmail(string $email): string
    {
        $email = trim($email);
        $at = strpos($email, '@');
        if ($at === false || $at === 0) {
            return '';
        }
        $local = substr($email, 0, $at);
        $domain = substr($email, $at);
        return substr($local, 0, min(2, strlen($local))) . '***' . $domain;
    }

    public function logout(): void
    {
        Csrf::verify();
        $user = Auth::user();
        if ($user !== null) {
            FormVersion::createLifecycleSnapshots(FormVersion::ACTION_LOGOUT, $user);
            // Auth::logout() の前に記録する（セッションの実行者情報が必要なため）
            OperationLog::user('auth.logout', [
                'summary'     => 'ユーザー「' . (string) $user['username'] . '」がログアウトしました',
                'target_type' => 'user',
                'target_id'   => (int) $user['id'],
                'target_name' => (string) $user['username'],
            ]);
        }
        Auth::logout();
        flash('info', 'ログアウトしました。');
        redirect('/admin/login');
    }

    /** パスワード忘れ（メールで再設定） */
    public function forgotForm(): void
    {
        if (Auth::check()) {
            redirect('/admin/');
        }
        if (User::count() === 0) {
            redirect('/admin/setup');
        }
        (new View())->render('admin/auth/forgot', [
            'title' => 'パスワード再設定',
        ], 'admin_minimal');
    }

    public function forgotSubmit(): void
    {
        Csrf::verify();
        if (Auth::check()) {
            redirect('/admin/');
        }

        if (!$this->forgotThrottleOk()) {
            flash('danger', 'リクエストが多すぎます。しばらく時間をおいてから再度お試しください。');
            redirect('/admin/forgot-password');
        }

        $identifier = trim((string) ($_POST['identifier'] ?? ''));
        $genericMsg = '入力内容を確認しました。メールアドレスが登録されている場合は、再設定用のメールを送信しました。';

        if ($identifier === '') {
            flash('info', $genericMsg);
            redirect('/admin/login');
            return;
        }

        $user = User::findByUsernameOrEmail($identifier);

        // アカウント列挙を避けるため、存在しない／メール未登録でも同じ文言で終了
        if (!$user || empty($user['email'])) {
            flash('info', $genericMsg);
            redirect('/admin/login');
            return;
        }

        try {
            $token = PasswordReset::issueToken((int) $user['id']);
            $resetUrl = url('/admin/reset-password?token=' . rawurlencode($token));
            $subject = (string) config('mail.password_reset_subject', '[ふぉーむくん] パスワード再設定');
            $bodyTpl = (string) config(
                'mail.password_reset_body',
                "管理画面のパスワードを再設定するには、次のURLにアクセスしてください（1時間以内）。\n\n{{reset_url}}\n\n心当たりがない場合はこのメールを無視してください。"
            );
            $body = str_replace('{{reset_url}}', $resetUrl, $bodyTpl);
            Mailer::send($user['email'], $subject, $body);
        } catch (\Throwable $e) {
            error_log('[formkun] password reset mail failed: ' . $e->getMessage());
            flash('danger', 'メール送信に失敗しました。メール設定やサーバ環境を確認してください。');
            redirect('/admin/forgot-password');
            return;
        }

        flash('info', $genericMsg);
        OperationLog::user('auth.password_reset.issue', [
            'summary'     => 'ユーザー「' . (string) $user['username'] . '」のパスワード再設定用メールを発行しました',
            'target_type' => 'user',
            'target_id'   => (int) $user['id'],
            'target_name' => (string) $user['username'],
        ]);
        redirect('/admin/login');
    }

    public function resetForm(): void
    {
        if (Auth::check()) {
            redirect('/admin/');
        }
        $token = (string) ($_GET['token'] ?? '');
        if ($token === '' || PasswordReset::findUserIdByToken($token) === null) {
            flash('danger', 'リンクの有効期限が切れているか、無効です。お手続きをやり直してください。');
            redirect('/admin/forgot-password');
            return;
        }
        (new View())->render('admin/auth/reset_password', [
            'title'     => '新しいパスワードを設定',
            'token'     => $token,
            'errors'    => [],
        ], 'admin_minimal');
    }

    public function resetSubmit(): void
    {
        Csrf::verify();
        if (Auth::check()) {
            redirect('/admin/');
        }

        $token = (string) ($_POST['token'] ?? '');
        $pass = (string) ($_POST['password'] ?? '');
        $passConf = (string) ($_POST['password_confirm'] ?? '');

        $uid = PasswordReset::findUserIdByToken($token);
        if ($uid === null) {
            flash('danger', 'リンクが無効です。お手続きを最初からやり直してください。');
            redirect('/admin/forgot-password');
            return;
        }

        $errors = [];
        if (mb_strlen($pass) < 8) {
            $errors[] = 'パスワードは8文字以上で設定してください。';
        }
        if ($pass !== $passConf) {
            $errors[] = '確認用パスワードが一致しません。';
        }

        if (!empty($errors)) {
            (new View())->render('admin/auth/reset_password', [
                'title'  => '新しいパスワードを設定',
                'token'  => $token,
                'errors' => $errors,
            ], 'admin_minimal');
            return;
        }

        User::setPassword($uid, $pass);
        PasswordReset::consumeToken($token);

        $resetUser = User::find($uid);
        if ($resetUser !== null) {
            OperationLog::user('auth.password_reset.complete', [
                'summary'     => 'ユーザー「' . (string) $resetUser['username'] . '」がパスワードを再設定しました',
                'target_type' => 'user',
                'target_id'   => $uid,
                'target_name' => (string) $resetUser['username'],
            ]);
        }

        flash('success', 'パスワードを変更しました。ログインしてください。');
        redirect('/admin/login');
    }

    /**
     * 同一セッション単位で「パスワード忘れ」送信回数を抑える。
     */
    private function forgotThrottleOk(): bool
    {
        $max = (int) config('security.password_reset_forgot_max_per_hour', 5);
        $now = time();
        $bucket = $_SESSION['_pw_forgot_bucket'] ?? null;
        if (!is_array($bucket) || ($now - (int) ($bucket['start'] ?? 0)) > 3600) {
            $_SESSION['_pw_forgot_bucket'] = ['start' => $now, 'count' => 0];
            $bucket = $_SESSION['_pw_forgot_bucket'];
        }
        if ((int) ($bucket['count'] ?? 0) >= $max) {
            return false;
        }
        $_SESSION['_pw_forgot_bucket']['count'] = (int) $bucket['count'] + 1;
        return true;
    }
}
