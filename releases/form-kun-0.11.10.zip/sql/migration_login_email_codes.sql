-- =================================================================
-- 既存データベース向け：ログイン用メール認証番号（2要素認証）用マイグレーション
-- phpMyAdmin などで 1 回だけ実行してください。
-- =================================================================

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS login_email_codes (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT NOT NULL,
    code_hash   CHAR(64) NOT NULL,
    expires_at  DATETIME NOT NULL,
    attempts    INT NOT NULL DEFAULT 0,
    created_at  DATETIME NOT NULL,
    KEY idx_user_id (user_id),
    CONSTRAINT fk_login_email_codes_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
