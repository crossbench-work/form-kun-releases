<?php
namespace Models;

use Core\Database;

class UserFormGrant
{
    /**
     * @return int[]
     */
    public static function formIdsForUser(int $userId): array
    {
        if ($userId <= 0) {
            return [];
        }
        $rows = Database::fetchAll(
            'SELECT form_id FROM user_form_grants WHERE user_id = ? ORDER BY form_id ASC',
            [$userId]
        );
        $ids = [];
        foreach ($rows as $row) {
            $ids[] = (int) $row['form_id'];
        }
        return $ids;
    }

    /**
     * @param int[] $formIds
     */
    public static function syncForUser(int $userId, array $formIds): void
    {
        if ($userId <= 0) {
            return;
        }
        $normalized = [];
        foreach ($formIds as $id) {
            $id = (int) $id;
            if ($id > 0 && !in_array($id, $normalized, true)) {
                $normalized[] = $id;
            }
        }
        if ($normalized !== []) {
            $existing = Database::fetchAll('SELECT id FROM forms');
            $valid = [];
            foreach ($existing as $row) {
                $fid = (int) $row['id'];
                if (in_array($fid, $normalized, true)) {
                    $valid[] = $fid;
                }
            }
            $normalized = $valid;
        }

        Database::transaction(function () use ($userId, $normalized): void {
            Database::execute('DELETE FROM user_form_grants WHERE user_id = ?', [$userId]);
            foreach ($normalized as $formId) {
                Database::execute(
                    'INSERT INTO user_form_grants (user_id, form_id) VALUES (?, ?)',
                    [$userId, $formId]
                );
            }
        });
    }

    public static function clearForUser(int $userId): void
    {
        if ($userId <= 0) {
            return;
        }
        Database::execute('DELETE FROM user_form_grants WHERE user_id = ?', [$userId]);
    }
}
