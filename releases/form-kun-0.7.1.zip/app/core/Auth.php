<?php
namespace Core;

class Auth
{
    private const SESSION_USER = '_auth_user';

    private static bool $verifiedThisRequest = false;

    /**
     * セッションのログイン状態を、リクエストごとに 1 回 DB と照合する。
     * ユーザー削除・ロール変更・パスワード変更があれば既存セッションは無効になる。
     */
    public static function check(): bool
    {
        $sessionUser = $_SESSION[self::SESSION_USER] ?? null;
        if (!is_array($sessionUser)) {
            return false;
        }
        if (self::$verifiedThisRequest) {
            return true;
        }
        $row = Database::fetchOne(
            'SELECT id, username, display_name, role, password_hash FROM users WHERE id = ?',
            [(int) ($sessionUser['id'] ?? 0)]
        );
        if ($row === null
            || (string) $row['role'] !== (string) ($sessionUser['role'] ?? '')
            || !hash_equals(self::passwordFingerprint($row), (string) ($sessionUser['pw_fp'] ?? ''))
        ) {
            unset($_SESSION[self::SESSION_USER]);
            return false;
        }
        $_SESSION[self::SESSION_USER]['display_name'] = (string) ($row['display_name'] ?: $row['username']);
        self::$verifiedThisRequest = true;
        return true;
    }

    public static function user(): ?array
    {
        return self::check() ? $_SESSION[self::SESSION_USER] : null;
    }

    public static function id(): ?int
    {
        $user = self::user();
        return $user['id'] ?? null;
    }

    public static function role(): ?string
    {
        $user = self::user();
        return $user['role'] ?? null;
    }

    public static function login(array $user): void
    {
        session_regenerate_id(true);
        self::storeSessionUser($user);
        Csrf::rotate();
    }

    /**
     * 自分自身のアカウントを更新したとき、ログイン状態を保ったままセッションを DB の内容に合わせる。
     */
    public static function refreshCurrentUser(): void
    {
        $id = (int) ($_SESSION[self::SESSION_USER]['id'] ?? 0);
        $row = $id > 0 ? Database::fetchOne('SELECT * FROM users WHERE id = ?', [$id]) : null;
        if ($row === null) {
            unset($_SESSION[self::SESSION_USER]);
            return;
        }
        self::storeSessionUser($row);
        self::$verifiedThisRequest = false;
    }

    public static function logout(): void
    {
        $_SESSION = [];
        self::$verifiedThisRequest = false;
        session_regenerate_id(true);
    }

    private static function storeSessionUser(array $user): void
    {
        $_SESSION[self::SESSION_USER] = [
            'id'           => (int) $user['id'],
            'username'     => (string) $user['username'],
            'display_name' => (string) ($user['display_name'] ?? $user['username']),
            'role'         => (string) $user['role'],
            'pw_fp'        => self::passwordFingerprint($user),
        ];
    }

    private static function passwordFingerprint(array $user): string
    {
        return hash('sha256', (string) ($user['password_hash'] ?? ''));
    }

    public static function requireLogin(): void
    {
        if (!self::check()) {
            $_SESSION['_intended'] = $_SERVER['REQUEST_URI'] ?? null;
            redirect('/admin/login');
        }
    }

    public static function requireRole(string $role): void
    {
        self::requireLogin();
        if (self::role() !== $role) {
            self::denyForbidden();
        }
    }

    public static function isViewer(): bool
    {
        return self::role() === 'viewer';
    }

    public static function isAdmin(): bool
    {
        return self::role() === 'admin';
    }

    public static function roleLabel(): string
    {
        return match (self::role()) {
            'admin' => 'admin（全権限）',
            'editor' => 'editor（編集）',
            'viewer' => 'viewer（閲覧のみ）',
            default => (string) (self::role() ?? ''),
        };
    }

    /** @var int[]|null */
    private static ?array $viewerFormIdsCache = null;

    /**
     * @return int[]
     */
    public static function viewerFormIds(): array
    {
        if (!self::isViewer()) {
            return [];
        }
        if (self::$viewerFormIdsCache !== null) {
            return self::$viewerFormIdsCache;
        }
        $id = self::id();
        self::$viewerFormIdsCache = $id !== null
            ? \Models\UserFormGrant::formIdsForUser($id)
            : [];
        return self::$viewerFormIdsCache;
    }

    public static function canAccessForm(int $formId): bool
    {
        if ($formId <= 0) {
            return false;
        }
        if (!self::isViewer()) {
            return true;
        }
        return in_array($formId, self::viewerFormIds(), true);
    }

    public static function requireFormAccess(int $formId): void
    {
        self::requireLogin();
        if (!self::canAccessForm($formId)) {
            self::denyForbidden();
        }
    }

    public static function requireCanManageForms(): void
    {
        self::requireLogin();
        if (self::isViewer()) {
            self::denyForbidden();
        }
    }

    public static function requireCanWriteSubmissions(): void
    {
        self::requireLogin();
        if (self::isViewer()) {
            self::denyForbidden();
        }
    }

    public static function requireCanAccessSettings(): void
    {
        self::requireLogin();
        if (self::isViewer()) {
            self::denyForbidden();
        }
    }

    private static function denyForbidden(): void
    {
        http_response_code(403);
        echo '<!doctype html><meta charset="utf-8"><title>403</title>';
        echo '<h1>403 Forbidden</h1><p>この操作を行う権限がありません。</p>';
        exit;
    }

    public static function recordAttempt(string $ip, ?string $username, bool $success): void
    {
        $username = self::normalizeUsername($username);
        try {
            Database::execute(
                'INSERT INTO login_attempts (ip, username, success, attempted_at) VALUES (?, ?, ?, ?)',
                [$ip, $username, $success ? 1 : 0, date('Y-m-d H:i:s')]
            );
        } catch (\Throwable $e) {
            error_log('[formkun] login_attempts insert failed: ' . $e->getMessage());
        }
    }

    public static function isLockedOut(string $ip, ?string $username = null): bool
    {
        $max = max(1, (int) config('security.login_max_attempts', 5));
        $window = max(1, (int) config('security.login_lockout_seconds', 600));
        $since   = date('Y-m-d H:i:s', time() - $window);

        $row = Database::fetchOne(
            'SELECT COUNT(*) AS c FROM login_attempts WHERE ip = ? AND success = 0 AND attempted_at >= ?',
            [$ip, $since]
        );
        if (((int) ($row['c'] ?? 0)) >= $max) {
            return true;
        }

        $username = self::normalizeUsername($username);
        if ($username === null) {
            return false;
        }

        $usernameMax = max(1, (int) config('security.login_username_max_attempts', 10));
        $usernameWindow = max(1, (int) config('security.login_username_lockout_seconds', 600));
        $usernameSince = date('Y-m-d H:i:s', time() - $usernameWindow);
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS c
             FROM login_attempts
             WHERE username = ?
               AND success = 0
               AND attempted_at >= ?
               AND id > COALESCE((
                   SELECT MAX(successful.id)
                   FROM login_attempts successful
                   WHERE successful.username = ? AND successful.success = 1
               ), 0)',
            [$username, $usernameSince, $username]
        );
        return ((int) ($row['c'] ?? 0)) >= $usernameMax;
    }

    private static function normalizeUsername(?string $username): ?string
    {
        $username = strtolower(trim((string) $username));
        return $username !== '' ? $username : null;
    }
}
