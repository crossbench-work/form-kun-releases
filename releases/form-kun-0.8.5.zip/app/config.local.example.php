<?php
/**
 * ローカル開発用設定の例。
 *
 * 使い方:
 *   cp config.local.example.php config.local.php
 *   （MySQL のユーザー・パスワードやポートを自分の環境に合わせる）
 *
 * 推奨: リポジトリルートの env/local/config.local.php を編集し npm run env:local で dist へ反映。
 * config.local.php は .gitignore 済みです。
 *
 * このファイルを読み込むには WEB から bootstrap が読み込むだけなので、
 * config.local.php 側でも define は不要です。
 */
return [
    'environment' => 'local',
    'debug' => true,
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'formkun',
        'user' => 'root',
        'password' => 'secret',
    ],
    'site' => [
        // PHP ビルトインサーバーで開く URL と合わせる（ポートは環境に合わせて変更）
        'base_url'  => 'http://127.0.0.1:8080',
        'base_path' => '',
    ],
    'mail' => [
        // Mailpit / MailHog などローカル SMTP を使う場合の例
        'transport' => 'smtp',
        'smtp' => [
            'enabled' => true,
            'host' => '127.0.0.1',
            'port' => 1025,
            'secure' => '',
            'username' => '',
            'password' => '',
            'timeout' => 10,
            'ehlo_host' => 'localhost',
            'verify_peer' => false,
            'verify_peer_name' => false,
            'allow_self_signed' => true,
        ],
    ],
    // Embed API の「日本国内のIPのみ許可」で使用します。
    // 'ip_geolocation' => [
    //     'ipinfo_token' => 'IPINFO_LITE_TOKEN',
    // ],
    // LINE 通知で {{__all__}} 使用時に画像プレビュー Push する場合（本番はランダム文字列を設定）
    // 'line' => [
    //     'public_file_signing_key' => 'CHANGE_ME_RANDOM_32_CHARS_OR_MORE',
    //     'public_file_ttl_seconds' => 604800,
    // ],
    // 本番の自己更新（初回のみ。運用中は管理画面の設定からも変更可）
    // 'update' => [
    //     'enabled' => true,
    //     'manifest_url' => 'https://raw.githubusercontent.com/ORG/REPO/update/releases/manifest.json',
    // ],
];
