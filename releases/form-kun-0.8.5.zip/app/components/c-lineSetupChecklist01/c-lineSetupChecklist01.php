<?php
/**
 * LINE セットアップチェックリスト c-lineSetupChecklist01
 * スタイルは _c-lineSetupChecklist01.scss（_admin-app.scss から @use）
 */
if (!function_exists('admin_c_line_setup_checklist01_external_link_svg')) {
    function admin_c_line_setup_checklist01_external_link_svg(): string
    {
        return '<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>';
    }
}

if (!function_exists('admin_c_line_setup_checklist01')) {
    /**
     * @param list<array{key: string, label: string, help?: string, check_hint?: string, external_url?: string, external_label?: string}> $items
     * @param array<string, bool> $state
     * @param callable(string $itemKey): void|null $renderEntryExtra チェック行の help の直後に追加 UI を出す（該当 key のみ echo すること）
     */
    function admin_c_line_setup_checklist01(
        array $items,
        array $state,
        string $postUrl,
        bool $interactive,
        ?callable $renderEntryExtra = null
    ): void
    {
        $postUrl = trim($postUrl);
        echo '<div data-module="c-lineSetupChecklist01"';
        if ($postUrl !== '') {
            echo ' data-checklist-url="' . e($postUrl) . '"';
        }
        echo ' data-csrf-name="_token">';
        echo '<ul class="list">';
        foreach ($items as $item) {
            $key = (string) ($item['key'] ?? '');
            $label = (string) ($item['label'] ?? '');
            if ($key === '' || $label === '') {
                continue;
            }
            $externalUrl = trim((string) ($item['external_url'] ?? ''));
            $externalLabel = trim((string) ($item['external_label'] ?? ''));
            $help = trim((string) ($item['help'] ?? ''));
            $helpSub = trim((string) ($item['help_sub'] ?? ''));
            $checkHint = trim((string) ($item['check_hint'] ?? ''));
            $checkHintAfterExtra = !empty($item['check_hint_after_extra']);
            $manualCheck = ($item['manual_check'] ?? true) !== false;
            $done = !empty($state[$key]);
            $pressed = $done ? 'true' : 'false';
            echo '<li class="entry">';
            $itemClass = 'item' . ($done ? ' is-done' : '');
            if ($manualCheck) {
                echo '<button type="button" class="' . e($itemClass) . '" data-item="' . e($key) . '" aria-pressed="' . e($pressed) . '"';
                if (!$interactive) {
                    echo ' disabled';
                }
                echo '>';
            } else {
                echo '<div class="' . e($itemClass) . ' is-auto" data-item="' . e($key) . '">';
            }
            echo '<span class="mark is-check" aria-hidden="true">';
            echo '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
            echo '</span>';
            echo '<span class="title">' . e($label) . '</span>';
            if ($manualCheck) {
                echo '</button>';
            } else {
                echo '</div>';
            }
            if ($externalUrl !== '' && $externalLabel !== '') {
                echo '<div class="block is-sub is-followUp">';
                echo '<a class="link c-externalLink01" href="' . e($externalUrl) . '" target="_blank" rel="noopener noreferrer">';
                echo e($externalLabel);
                echo '<span class="icon is-external" aria-hidden="true">' . admin_c_line_setup_checklist01_external_link_svg() . '</span>';
                echo '</a>';
                echo '</div>';
            }
            if ($help !== '') {
                echo '<p class="text is-help is-sub">' . e($help) . '</p>';
            }
            if ($helpSub !== '') {
                echo '<p class="text is-help is-sub">' . e($helpSub) . '</p>';
            }
            if ($checkHint !== '' && !$checkHintAfterExtra) {
                echo '<p class="text is-checkHint is-sub">' . e($checkHint) . '</p>';
            }
            if ($renderEntryExtra !== null) {
                ob_start();
                $renderEntryExtra($key);
                $extraHtml = trim(ob_get_clean());
                if ($extraHtml !== '') {
                    echo '<div class="block is-sub is-extra">';
                    echo $extraHtml;
                    echo '</div>';
                }
            }
            if ($checkHint !== '' && $checkHintAfterExtra) {
                echo '<p class="text is-checkHint is-sub">' . e($checkHint) . '</p>';
            }
            echo '</li>';
        }
        echo '</ul>';
        if (!$interactive) {
            echo '<p class="text is-help">フォーム保存後にチェックを記録できます。</p>';
        }
        echo '</div>';
    }
}
