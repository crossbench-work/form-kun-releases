<?php
namespace Core;

/**
 * LINE `{{__all__}}` 画像プレビュー（署名 URL / image Push）の実行環境診断。
 */
class LineImagePreviewDiagnostic
{
    /**
     * @return array<string, mixed>
     */
    public static function statusForDisplay(): array
    {
        $baseUrl = rtrim((string) config('site.base_url', ''), '/');
        $signingKey = LinePublicFileAccess::signingKey();
        $keyPreview = self::maskSigningKey($signingKey);

        return [
            'app_version' => self::appVersion(),
            'resolver_class' => class_exists(LineNotifyFileResolver::class),
            'base_url' => $baseUrl,
            'base_url_https' => LinePublicFileAccess::isHttpsBaseUrlConfigured(),
            'signing_key_set' => $signingKey !== '',
            'signing_key_preview' => $keyPreview,
            'temp_writable' => LinePublicFileAccess::isStagedDirectoryWritable(),
            'public_staged_route_hint' => url('/api/line/public-staged/000000000000000000000000000000000000000000000000'),
        ];
    }

    /**
     * @return array{ok:bool, message:string, detail?:string}
     */
    public static function runSelfTest(): array
    {
        if (!LinePublicFileAccess::isHttpsBaseUrlConfigured()) {
            return [
                'ok' => false,
                'message' => 'site.base_url が HTTPS で設定されていません。',
                'detail' => 'config.local.php の site.base_url を https:// で指定してください。',
            ];
        }
        if (LinePublicFileAccess::signingKey() === '') {
            return [
                'ok' => false,
                'message' => 'line.public_file_signing_key が未設定です。',
                'detail' => 'config.local.php に line.public_file_signing_key を設定してください。',
            ];
        }
        if (!LinePublicFileAccess::isStagedDirectoryWritable()) {
            return [
                'ok' => false,
                'message' => '画像ステージング用 temp ディレクトリに書き込めません。',
                'detail' => 'sys_get_temp_dir() の権限を確認してください。',
            ];
        }

        $handle = LinePublicFileAccess::stageDiagnosticPng();
        if ($handle === null) {
            return [
                'ok' => false,
                'message' => '診断用画像のステージングに失敗しました。',
                'detail' => 'サーバーログの line image stage failed を確認してください。',
            ];
        }

        $signedUrl = LinePublicFileAccess::createSignedUrlForStagedHandle($handle);
        if ($signedUrl === null) {
            return [
                'ok' => false,
                'message' => '署名 URL を生成できませんでした。',
                'detail' => 'base_url または signing key の設定を確認してください。',
            ];
        }

        $fetch = self::fetchSignedUrl($signedUrl);
        if (!$fetch['ok']) {
            return [
                'ok' => false,
                'message' => '署名 URL への GET に失敗しました。',
                'detail' => $fetch['detail'] ?? '',
            ];
        }

        return [
            'ok' => true,
            'message' => '診断成功: 署名 URL から画像を取得できました。受信通知でも同じ仕組みで URL / image Push されます。',
        ];
    }

    public static function stageFailureLabel(string $code): string
    {
        return match ($code) {
            'unreadable' => '添付ファイルを読み取れませんでした。',
            'not_inline_image' => 'インライン表示できないファイル形式です（jpg/png/gif/webp のみ）。',
            'size' => 'ファイルサイズが上限外です（10MB 以下）。',
            'mkdir_failed' => 'temp ディレクトリを作成できませんでした。',
            'copy_failed' => 'ステージングへのコピーに失敗しました。',
            'signed_url' => '署名 URL を生成できませんでした。',
            default => '画像ステージングに失敗しました（' . $code . '）。',
        };
    }

    private static function appVersion(): string
    {
        $versionFile = APP_DIR . '/version.php';
        if (!is_file($versionFile)) {
            return '';
        }
        $v = require $versionFile;

        return is_string($v) ? trim($v) : '';
    }

    private static function maskSigningKey(string $key): string
    {
        $key = trim($key);
        if ($key === '') {
            return '未設定';
        }
        if (mb_strlen($key) <= 4) {
            return '****';
        }

        return mb_substr($key, 0, 4) . '…';
    }

    /**
     * @return array{ok:bool, detail?:string}
     */
    private static function fetchSignedUrl(string $url): array
    {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch === false) {
                return ['ok' => false, 'detail' => 'curl を初期化できませんでした。'];
            }
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_HTTPHEADER => ['User-Agent: form-kun-line-diagnostic/1'],
            ]);
            $body = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $contentType = (string) curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
            curl_close($ch);
            if (!is_string($body) || $code < 200 || $code >= 300) {
                return ['ok' => false, 'detail' => 'HTTP ' . $code . '（公開 URL がルーティング / 署名検証で拒否された可能性）'];
            }
            if (!str_starts_with(strtolower($contentType), 'image/')) {
                return ['ok' => false, 'detail' => 'Content-Type が image/* ではありません: ' . $contentType];
            }

            return ['ok' => true];
        }

        $ctx = stream_context_create([
            'http' => [
                'timeout' => 15,
                'header' => "User-Agent: form-kun-line-diagnostic/1\r\n",
            ],
        ]);
        $body = @file_get_contents($url, false, $ctx);
        if (!is_string($body) || $body === '') {
            return ['ok' => false, 'detail' => 'file_get_contents で取得できませんでした（allow_url_fopen / 外向き通信）'];
        }

        return ['ok' => true];
    }
}
