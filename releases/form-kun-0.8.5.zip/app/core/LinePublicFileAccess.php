<?php
namespace Core;

use Models\Submission;

/**
 * LINE image メッセージ用の期限付き公開ファイル URL（HMAC 署名）。
 */
class LinePublicFileAccess
{
    /** LINE Messaging API の画像サイズ上限（bytes） */
    public const LINE_IMAGE_MAX_BYTES = 10 * 1024 * 1024;

    /** 1 通知あたりの image Push 上限 */
    public const MAX_IMAGES_PER_NOTIFY = 20;

    public static function signingKey(): string
    {
        return trim((string) config('line.public_file_signing_key', ''));
    }

    public static function ttlSeconds(): int
    {
        $ttl = (int) config('line.public_file_ttl_seconds', 604800);

        return max(60, min(86400 * 30, $ttl));
    }

    public static function isHttpsBaseUrlConfigured(): bool
    {
        $baseUrl = rtrim((string) config('site.base_url', ''), '/');
        if ($baseUrl === '') {
            return false;
        }

        return str_starts_with(strtolower($baseUrl), 'https://');
    }

    /**
     * @return string|null 絶対 HTTPS URL。鍵未設定・base_url 非 HTTPS のとき null
     */
    public static function createSignedUrl(int $fileId): ?string
    {
        if ($fileId <= 0 || self::signingKey() === '' || !self::isHttpsBaseUrlConfigured()) {
            return null;
        }
        $exp = time() + self::ttlSeconds();
        $token = self::encodeToken($fileId, $exp);
        if ($token === null) {
            return null;
        }

        return url('/api/line/public-files/' . $fileId . '?t=' . rawurlencode($token));
    }

    /**
     * @return array{file_id:int, exp:int}|null
     */
    public static function verifyToken(int $fileId, string $token): ?array
    {
        if ($fileId <= 0 || self::signingKey() === '') {
            return null;
        }
        $token = trim($token);
        if ($token === '' || !str_contains($token, '.')) {
            return null;
        }
        [$payloadB64, $sigB64] = explode('.', $token, 2);
        $payload = self::base64UrlDecode($payloadB64);
        if ($payload === null) {
            return null;
        }
        if (!preg_match('/^(\d+)\|(\d+)$/', $payload, $m)) {
            return null;
        }
        $tokenFileId = (int) $m[1];
        $exp = (int) $m[2];
        if ($tokenFileId !== $fileId || $exp < time()) {
            return null;
        }
        $expectedSig = self::signPayload($payload);
        $sig = self::base64UrlDecode($sigB64);
        if ($sig === null || !hash_equals($expectedSig, $sig)) {
            return null;
        }

        return ['file_id' => $fileId, 'exp' => $exp];
    }

    /**
     * @return list<array<string, mixed>>
     */
    public static function inlineImageFilesForSubmission(int $submissionId): array
    {
        if ($submissionId <= 0) {
            return [];
        }
        $files = Submission::filesFor($submissionId);
        $images = [];
        foreach ($files as $file) {
            if (!is_safe_inline_submission_file($file)) {
                continue;
            }
            $size = (int) ($file['size'] ?? 0);
            if ($size > self::LINE_IMAGE_MAX_BYTES) {
                continue;
            }
            $images[] = $file;
        }

        return $images;
    }

    /**
     * メール送信のみモード: 一時添付を LINE 取得用にコピーし handle を返す。
     *
     * @param array<string, mixed> $attachment TemporaryAttachmentStorage のメタ
     */
    public static function stageMailAttachmentForLinePush(array $attachment): ?string
    {
        self::pruneStagedMaybe();
        if (!TemporaryAttachmentStorage::isReadableAttachment($attachment)) {
            self::logStageFailure('unreadable');

            return null;
        }
        if (!is_safe_inline_submission_file($attachment)) {
            self::logStageFailure('not_inline_image');

            return null;
        }
        $size = (int) ($attachment['size'] ?? 0);
        if ($size <= 0 || $size > self::LINE_IMAGE_MAX_BYTES) {
            self::logStageFailure('size');

            return null;
        }
        $src = (string) ($attachment['stored_path'] ?? '');
        if ($src === '' || !is_file($src) || !is_readable($src)) {
            self::logStageFailure('unreadable');

            return null;
        }

        $handle = bin2hex(random_bytes(24));
        $dir = self::stagedDirectory();
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            self::logStageFailure('mkdir_failed');

            return null;
        }
        $dest = $dir . DIRECTORY_SEPARATOR . $handle;
        if (!@copy($src, $dest)) {
            self::logStageFailure('copy_failed');

            return null;
        }
        @chmod($dest, 0600);

        return $handle;
    }

    public static function isStagedDirectoryWritable(): bool
    {
        $dir = self::stagedDirectory();
        if (is_dir($dir) && is_writable($dir)) {
            return true;
        }
        if (is_dir($dir)) {
            return false;
        }

        return @mkdir($dir, 0700, true) || is_dir($dir);
    }

    /**
     * @return string|null 絶対 HTTPS URL
     */
    public static function createSignedUrlForStagedHandle(string $handle): ?string
    {
        if (!self::isValidStagedHandle($handle) || self::signingKey() === '' || !self::isHttpsBaseUrlConfigured()) {
            return null;
        }
        $exp = time() + self::ttlSeconds();
        $token = self::encodeStagedToken($handle, $exp);
        if ($token === null) {
            return null;
        }

        return url('/api/line/public-staged/' . $handle . '?t=' . rawurlencode($token));
    }

    /**
     * @return array{handle:string, exp:int}|null
     */
    public static function verifyStagedToken(string $handle, string $token): ?array
    {
        if (!self::isValidStagedHandle($handle) || self::signingKey() === '') {
            return null;
        }
        $token = trim($token);
        if ($token === '' || !str_contains($token, '.')) {
            return null;
        }
        [$payloadB64, $sigB64] = explode('.', $token, 2);
        $payload = self::base64UrlDecode($payloadB64);
        if ($payload === null) {
            return null;
        }
        if (!preg_match('/^staged\|([a-f0-9]{48})\|(\d+)$/', $payload, $m)) {
            return null;
        }
        $tokenHandle = $m[1];
        $exp = (int) $m[2];
        if (!hash_equals($handle, $tokenHandle) || $exp < time()) {
            return null;
        }
        $expectedSig = self::signPayload($payload);
        $sig = self::base64UrlDecode($sigB64);
        if ($sig === null || !hash_equals($expectedSig, $sig)) {
            return null;
        }

        return ['handle' => $handle, 'exp' => $exp];
    }

    public static function stagedAbsolutePath(string $handle): ?string
    {
        if (!self::isValidStagedHandle($handle)) {
            return null;
        }
        $path = self::stagedDirectory() . DIRECTORY_SEPARATOR . $handle;
        if (!is_file($path) || !is_readable($path)) {
            return null;
        }
        $dir = realpath(self::stagedDirectory());
        $real = realpath($path);
        if ($dir === false || $real === false || !str_starts_with($real, $dir . DIRECTORY_SEPARATOR)) {
            return null;
        }

        return $real;
    }

    public static function pruneStaged(): void
    {
        $dir = self::stagedDirectory();
        if (!is_dir($dir)) {
            return;
        }
        $cutoff = time() - self::ttlSeconds();
        foreach (glob($dir . DIRECTORY_SEPARATOR . '[0-9a-f][0-9a-f]*') ?: [] as $path) {
            if (is_file($path) && (int) filemtime($path) < $cutoff) {
                @unlink($path);
            }
        }
    }

    /** 管理画面診断用 1×1 PNG をステージング */
    public static function stageDiagnosticPng(): ?string
    {
        self::pruneStagedMaybe();
        $png = "\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x6a\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-\xdb\x00\x00\x00\x00IEND\xaeB`\x82";
        $handle = bin2hex(random_bytes(24));
        $dir = self::stagedDirectory();
        if (!is_dir($dir) && !@mkdir($dir, 0700, true) && !is_dir($dir)) {
            self::logStageFailure('mkdir_failed');

            return null;
        }
        $dest = $dir . DIRECTORY_SEPARATOR . $handle;
        if (@file_put_contents($dest, $png) === false) {
            self::logStageFailure('copy_failed');

            return null;
        }
        @chmod($dest, 0600);

        return $handle;
    }

    private static function logStageFailure(string $reason): void
    {
        error_log('[formkun] line image stage failed: ' . $reason);
    }

    private static function isValidStagedHandle(string $handle): bool
    {
        return preg_match('/^[a-f0-9]{48}$/', $handle) === 1;
    }

    private static function stagedDirectory(): string
    {
        $installationKey = substr(hash('sha256', PUBLIC_DIR), 0, 16);

        return rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
            . DIRECTORY_SEPARATOR . 'form-kun-line-public-' . $installationKey;
    }

    private static function pruneStagedMaybe(): void
    {
        if (random_int(1, 20) === 1) {
            self::pruneStaged();
        }
    }

    private static function encodeStagedToken(string $handle, int $exp): ?string
    {
        if (!self::isValidStagedHandle($handle)) {
            return null;
        }
        $payload = 'staged|' . $handle . '|' . $exp;
        $sig = self::signPayload($payload);

        return self::base64UrlEncode($payload) . '.' . self::base64UrlEncode($sig);
    }

    private static function encodeToken(int $fileId, int $exp): ?string
    {
        $payload = $fileId . '|' . $exp;
        $sig = self::signPayload($payload);

        return self::base64UrlEncode($payload) . '.' . self::base64UrlEncode($sig);
    }

    private static function signPayload(string $payload): string
    {
        return hash_hmac('sha256', $payload, self::signingKey(), true);
    }

    private static function base64UrlEncode(string $binary): string
    {
        return rtrim(strtr(base64_encode($binary), '+/', '-_'), '=');
    }

    private static function base64UrlDecode(string $encoded): ?string
    {
        $pad = strlen($encoded) % 4;
        if ($pad > 0) {
            $encoded .= str_repeat('=', 4 - $pad);
        }
        $decoded = base64_decode(strtr($encoded, '-_', '+/'), true);

        return $decoded === false ? null : $decoded;
    }
}
