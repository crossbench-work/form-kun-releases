<?php
namespace Core;

class LineSubmissionNotifier
{
    private const MAX_TEXT_LENGTH = 5000;

    /**
     * @param array<string, mixed> $form
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    public static function notify(array $form, array $fields, array $values, ?int $submissionId): void
    {
        try {
            self::notifyInternal($form, $fields, $values, $submissionId);
        } catch (\Throwable $e) {
            error_log('[formkun] line notify failed for form ' . (int) ($form['id'] ?? 0));
        }
    }

    /** @param array<string, mixed> $form */
    public static function sendTest(array $form): bool
    {
        unset($form);
        $token = LineSiteConfig::channelAccessToken();
        $to = LineSiteConfig::pushToId();
        if ($token === '' || $to === '') {
            return false;
        }

        $text = "[ふぉーむくん] LINE通知テスト\nこのメッセージを受信できた場合、現在の設定で LINE Push できます。";

        return LineMessagingClient::pushText($token, $to, $text);
    }

    /**
     * 表示設定テンプレートをサンプル値でレンダリングして Push（テスト用）。
     *
     * @param array<string, mixed> $form DB 行（token / push_to_id 含む）
     * @param array<int, array<string, mixed>> $fields
     * @param string $templateFromRequest 画面上のテンプレ（空なら DB / デフォルトへフォールバック）
     */
    public static function sendMessageTest(array $form, array $fields, string $templateFromRequest): bool
    {
        $token = LineSiteConfig::channelAccessToken();
        $to = LineSiteConfig::pushToId();
        if ($token === '' || $to === '') {
            return false;
        }

        $values = self::sampleValuesForLineMessageTest($fields);
        $text = self::buildPushText($form, $fields, $values, null, $templateFromRequest);
        if ($text === '') {
            return false;
        }

        return LineMessagingClient::pushText($token, $to, $text);
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<string, mixed>
     */
    public static function sampleValuesForLineMessageTest(array $fields): array
    {
        $values = [];
        foreach ($fields as $field) {
            $type = (string) ($field['type'] ?? '');
            if (\Models\FormField::isDisplayOnlyType($type)) {
                continue;
            }
            $key = (string) ($field['field_key'] ?? '');
            if ($key === '') {
                continue;
            }
            if ($type === 'checkbox') {
                $values[$key] = ['（サンプル）'];
            } elseif ($type === 'file') {
                $values[$key] = 'sample.txt';
            } else {
                $values[$key] = '（サンプル）';
            }
        }

        return $values;
    }

    /**
     * @param array<string, mixed> $form
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    private static function buildPushText(
        array $form,
        array $fields,
        array $values,
        ?int $submissionId,
        ?string $templateOverride = null
    ): string {
        $formId = (int) ($form['id'] ?? 0);
        $submissionUrl = self::submissionUrl($formId, $submissionId);

        $context = [
            'submitted_at' => date('Y-m-d H:i:s'),
            'form_title' => (string) ($form['title'] ?? ''),
            'ip' => client_ip(),
        ];

        $template = $templateOverride !== null ? trim($templateOverride) : '';
        if ($template === '') {
            $template = trim((string) ($form['line_message_template'] ?? ''));
        }
        if ($template === '') {
            $template = trim((string) ($form['mail_template_admin'] ?? ''));
        }
        if ($template === '') {
            $template = \Models\Form::defaultAdminMailTemplate();
        }

        $text = Mailer::renderTemplate($template, $fields, $values, $context);
        $text = str_replace('{{__submission_url__}}', $submissionUrl, $text);
        if (mb_strlen($text) > self::MAX_TEXT_LENGTH) {
            $text = mb_substr($text, 0, self::MAX_TEXT_LENGTH);
        }

        return $text;
    }

    /**
     * @param array<string, mixed> $form
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    private static function notifyInternal(array $form, array $fields, array $values, ?int $submissionId): void
    {
        if (empty($form['line_notify_enabled'])) {
            return;
        }

        if (!\Models\Form::lineSetupChecklistIsCompleteForFormRow($form)) {
            return;
        }

        $token = LineSiteConfig::channelAccessToken();
        $to = LineSiteConfig::pushToId();
        if ($token === '' || $to === '') {
            return;
        }

        $formId = (int) ($form['id'] ?? 0);
        $text = self::buildPushText($form, $fields, $values, $submissionId, null);
        if ($text === '') {
            return;
        }

        if (!LineMessagingClient::pushText($token, $to, $text)) {
            error_log('[formkun] line push rejected for form ' . $formId);
        }
    }

    private static function submissionUrl(int $formId, ?int $submissionId): string
    {
        if ($formId <= 0) {
            return '';
        }
        if ($submissionId !== null && $submissionId > 0) {
            return url('/admin/forms/submissions/' . $submissionId);
        }

        return url('/admin/forms/' . $formId . '/submissions');
    }
}
