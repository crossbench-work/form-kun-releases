<?php
namespace Core;

/**
 * 1 回の LINE 受信通知内で、公開署名 URL と image Push を field_key 単位で解決する。
 */
class LineNotifyFileResolver
{
    /** @var array<string, string> */
    private array $urlByFieldKey = [];

    /** @var array<string, string> staged handle（メールのみ） */
    private array $stagedHandleByFieldKey = [];

    /** @var array<string, mixed> field_key => attachment meta */
    private array $mailOnlyAttachmentsByKey;

    public function __construct(private ?int $submissionId, array $mailOnlyAttachmentsByKey)
    {
        $this->mailOnlyAttachmentsByKey = [];
        foreach ($mailOnlyAttachmentsByKey as $key => $attachment) {
            if (is_string($key) && $key !== '' && is_array($attachment)) {
                $this->mailOnlyAttachmentsByKey[$key] = $attachment;
            }
        }
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<string, string> field_key => HTTPS URL
     */
    public function publicUrlsByFieldKey(array $fields): array
    {
        if (LinePublicFileAccess::signingKey() === '' || !LinePublicFileAccess::isHttpsBaseUrlConfigured()) {
            return [];
        }

        foreach ($fields as $field) {
            if ((string) ($field['type'] ?? '') !== 'file') {
                continue;
            }
            $fieldKey = (string) ($field['field_key'] ?? '');
            if ($fieldKey === '') {
                continue;
            }
            $url = $this->resolveUrlForFieldKey($fieldKey);
            if ($url !== '') {
                $this->urlByFieldKey[$fieldKey] = $url;
            }
        }

        return $this->urlByFieldKey;
    }

    /**
     * @return list<array{type:string, originalContentUrl:string, previewImageUrl:string}>
     */
    public function imageMessages(): array
    {
        $messages = [];
        foreach ($this->urlByFieldKey as $url) {
            if (count($messages) >= LinePublicFileAccess::MAX_IMAGES_PER_NOTIFY) {
                break;
            }
            $messages[] = [
                'type' => 'image',
                'originalContentUrl' => $url,
                'previewImageUrl' => $url,
            ];
        }

        return $messages;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     */
    public function hasInlineCandidates(array $fields): bool
    {
        unset($fields);
        $submissionId = $this->submissionId ?? 0;
        if ($submissionId > 0 && LinePublicFileAccess::inlineImageFilesForSubmission($submissionId) !== []) {
            return true;
        }

        foreach ($this->mailOnlyAttachmentsByKey as $attachment) {
            if (!is_array($attachment)) {
                continue;
            }
            if (!is_safe_inline_submission_file($attachment)) {
                continue;
            }
            $size = (int) ($attachment['size'] ?? 0);
            if ($size <= 0 || $size > LinePublicFileAccess::LINE_IMAGE_MAX_BYTES) {
                continue;
            }
            if (TemporaryAttachmentStorage::isReadableAttachment($attachment)) {
                return true;
            }
        }

        return false;
    }

    private function resolveUrlForFieldKey(string $fieldKey): string
    {
        if (isset($this->urlByFieldKey[$fieldKey])) {
            return $this->urlByFieldKey[$fieldKey];
        }

        $submissionId = $this->submissionId ?? 0;
        if ($submissionId > 0) {
            foreach (LinePublicFileAccess::inlineImageFilesForSubmission($submissionId) as $file) {
                if ((string) ($file['field_key'] ?? '') !== $fieldKey) {
                    continue;
                }
                $fileId = (int) ($file['id'] ?? 0);
                $url = LinePublicFileAccess::createSignedUrl($fileId);

                return $url ?? '';
            }
        }

        $attachment = $this->mailOnlyAttachmentsByKey[$fieldKey] ?? null;
        if (!is_array($attachment)) {
            return '';
        }

        if (isset($this->stagedHandleByFieldKey[$fieldKey])) {
            return LinePublicFileAccess::createSignedUrlForStagedHandle($this->stagedHandleByFieldKey[$fieldKey]) ?? '';
        }

        $handle = LinePublicFileAccess::stageMailAttachmentForLinePush($attachment);
        if ($handle === null) {
            return '';
        }
        $this->stagedHandleByFieldKey[$fieldKey] = $handle;
        $url = LinePublicFileAccess::createSignedUrlForStagedHandle($handle);

        return $url ?? '';
    }
}
