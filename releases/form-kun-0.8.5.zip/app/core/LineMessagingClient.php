<?php
namespace Core;

/**
 * LINE Messaging API（Push message）の薄いクライアント。
 */
class LineMessagingClient
{
    private const PUSH_URL = 'https://api.line.me/v2/bot/message/push';

    public static function pushText(string $channelAccessToken, string $to, string $text): bool
    {
        $token = trim($channelAccessToken);
        $to = trim($to);
        $text = (string) $text;
        if ($token === '' || $to === '' || $text === '') {
            return false;
        }

        $payload = json_encode([
            'to' => $to,
            'messages' => [
                ['type' => 'text', 'text' => $text],
            ],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($payload)) {
            return false;
        }

        $raw = self::httpPostJson(self::PUSH_URL, $payload, $token);
        if ($raw === null) {
            return false;
        }

        $decoded = json_decode($raw, true);
        if (is_array($decoded) && isset($decoded['message']) && is_string($decoded['message'])) {
            return false;
        }

        return true;
    }

    private static function httpPostJson(string $url, string $jsonBody, string $bearerToken): ?string
    {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch !== false) {
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_POST           => true,
                    CURLOPT_POSTFIELDS     => $jsonBody,
                    CURLOPT_TIMEOUT        => 15,
                    CURLOPT_HTTPHEADER     => [
                        'Content-Type: application/json',
                        'Authorization: Bearer ' . $bearerToken,
                        'User-Agent: form-kun/1',
                    ],
                ]);
                $raw = curl_exec($ch);
                $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
                curl_close($ch);
                if (is_string($raw) && $code >= 200 && $code < 300) {
                    return $raw;
                }
                return null;
            }
        }

        return null;
    }
}
