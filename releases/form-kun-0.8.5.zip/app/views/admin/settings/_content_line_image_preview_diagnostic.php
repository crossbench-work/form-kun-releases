<?php /** 設定 → LINE 連携: {{__all__}} 画像プレビュー診断 */
use Core\LineImagePreviewDiagnostic;

$lineImageDiag = LineImagePreviewDiagnostic::statusForDisplay();
$lineImageDiagUrl = base_path('/admin/settings/line/diagnose-image-preview');
$okMark = static fn(bool $ok): string => $ok ? 'OK' : '要確認';
?>
<div class="block is-lineImagePreviewDiagnostic">
    <div class="area is-title">
        <?php admin_m_bold_title01('LINE 画像プレビュー診断（{{__all__}}）'); ?>
    </div>
    <div class="area is-field">
        <p class="text is-help">受信 LINE に画像 URL / image メッセージを載せるには、<strong>config.local.php</strong> の HTTPS <code>site.base_url</code> と <code>line.public_file_signing_key</code> が必要です（ZIP 更新だけでは自動設定されません）。</p>
        <p class="text is-help">アプリ版: <?= e((string) ($lineImageDiag['app_version'] ?? '')) ?> / LineNotifyFileResolver: <?= e($okMark(!empty($lineImageDiag['resolver_class']))) ?> / temp 書込: <?= e($okMark(!empty($lineImageDiag['temp_writable']))) ?></p>
        <p class="text is-help">site.base_url: <?= e((string) ($lineImageDiag['base_url'] ?? '') !== '' ? (string) $lineImageDiag['base_url'] : '未設定') ?>（HTTPS: <?= e($okMark(!empty($lineImageDiag['base_url_https']))) ?>）</p>
        <p class="text is-help">line.public_file_signing_key: <?= e((string) ($lineImageDiag['signing_key_preview'] ?? '')) ?></p>
        <p class="text is-help">公開ルート例（未署名のため 404 で正常）: <code><?= e((string) ($lineImageDiag['public_staged_route_hint'] ?? '')) ?></code></p>
        <div data-module="c-lineImagePreviewDiagnostic01" data-test-url="<?= e($lineImageDiagUrl) ?>" data-csrf-name="_token">
            <div class="area is-actions">
                <?php
                admin_m_btn01_button_wrap('診断実行', [
                    'type' => 'button',
                    'class' => 'is-primary',
                ]);
                ?>
            </div>
            <p class="text is-help" data-target="line-image-diag-result" hidden></p>
        </div>
    </div>
</div>
