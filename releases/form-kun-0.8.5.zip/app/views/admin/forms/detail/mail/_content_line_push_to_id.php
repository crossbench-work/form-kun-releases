<?php
/**
 * LINE通知 — 送信先 ID（name=line_push_to_id）
 *
 * @var array<string, mixed> $form
 * @var bool $linePushToIdHideTitle チェックリスト内など見出しを省略する
 * @var bool $linePushToIdHideHelp help 段落を省略する
 * @var bool $linePushToIdInlineSave 入力横に保存ボタン（Channel secret 同型）
 */
$linePushToIdHideTitle = !empty($linePushToIdHideTitle);
$linePushToIdHideHelp = !empty($linePushToIdHideHelp);
$linePushToIdInlineSave = !empty($linePushToIdInlineSave);
$linePushToIdContext = (string) ($linePushToIdContext ?? 'form');
$formId = (int) ($form['id'] ?? 0);
if ($linePushToIdContext === 'site') {
    $linePushToIdSaveAction = base_path('/admin/settings/line/push-to-id');
} else {
    $linePushToIdSaveAction = $formId > 0
        ? base_path('/admin/forms/' . $formId . '/line/step-2')
        : '';
}
?>
    <?php admin_m_input_set01_open(); ?>
    <?php if (!$linePushToIdHideTitle): ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('送信先 ID（userId / groupId / roomId）'), 'line_push_to_id'); ?>
    </div>
    <?php endif; ?>
    <div class="area is-field">
        <?php if ($linePushToIdInlineSave): ?>
        <div class="c-lineCredentialRow01">
        <?php endif; ?>
        <?php admin_m_input01_open(); ?>
        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('line_push_to_id', [
            'type' => 'text',
            'id' => 'line_push_to_id',
            'name' => 'line_push_to_id',
            'value' => (string) ($form['line_push_to_id'] ?? ''),
            'autocomplete' => 'off',
            'maxlength' => 64,
        ])); ?>
        <?php admin_m_input01_close(); ?>
        <?php if ($linePushToIdInlineSave && $linePushToIdSaveAction !== ''): ?>
            <button type="submit" class="btn is-small"
                formaction="<?= e($linePushToIdSaveAction) ?>"
                formmethod="post" formnovalidate>保存</button>
        <?php endif; ?>
        <?php if ($linePushToIdInlineSave): ?>
        </div>
        <?php endif; ?>
        <?php if (!$linePushToIdHideHelp): ?>
        <p class="text is-help">Messaging API の Push 先です。友だち追加した userId、Bot を招待した groupId、複数人トークの roomId を指定できます。上の一覧から「送信先に使う」で入力欄に反映できます（反映後はフォームを保存してください）。</p>
        <?php endif; ?>
    </div>
    <?php admin_m_input_set01_close(); ?>
