<?php
/** c-formBlock01 / チェックリスト is-extra: LINE通知 — Webhook URL（表示のみ） */
/** @var bool $lineWebhookHideTitle チェックリスト内など見出しを省略する */
$lineWebhookHideTitle = !empty($lineWebhookHideTitle);
?>
    <?php admin_m_input_set01_open(); ?>
    <?php if (!$lineWebhookHideTitle): ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('Webhook URL')); ?>
    </div>
    <?php endif; ?>
    <div class="area is-field">
        <?php
        $webhookUrl = \Core\LineSiteConfig::webhookUrl();
        ?>
        <?php admin_c_copy_tag_list01([$webhookUrl]); ?>
        <p class="text is-help is-sub">サイト設定の base URL（HTTPS）を LINE Developers の Webhook URL に登録してください。</p>
    </div>
    <?php admin_m_input_set01_close(); ?>
