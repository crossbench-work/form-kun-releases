<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — 使用可能な変数一覧 */ ?>
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('件名・本文で使用可能な変数')); ?>
    </div>
    <div class="area is-field">
        <?php admin_c_copy_tag_list01(['{{field_key}}', '{{__all__}}', '{{__form_title__}}', '{{__submitted_at__}}', '{{__ip__}}']); ?>
        <p class="text is-help"><code>{{__all__}}</code> 使用時、画像ファイル項目は LINE でもプレビュー送信されます（DB 保存・メール送信のみのいずれも可。<strong>site.base_url（HTTPS）</strong> と <code>config.local.php</code> の <code>line.public_file_signing_key</code> が未設定のときはファイル名のみ）。メールのみはサーバーの PHP temp ディレクトリへの書き込みも必要です。設定済みのとき、画像は <strong>ファイル名の次行に署名 URL</strong> が付き、続けて image メッセージも送られます（<code>{{__all__}}</code> は閉じ <code>}}</code> まで正確に）。</p>
    </div>
    <?php admin_m_input_set01_close(); ?>
