<?php

$showManifestUi = !empty($show_manifest_ui);
$latest = is_array($manifest ?? null) ? (string) ($manifest['latest'] ?? '') : '';
$releases = is_array($manifest ?? null) ? ($manifest['releases'] ?? []) : [];
$requirements = is_array($requirements ?? null) ? $requirements : [];
$releasesPageUrl = (string) ($releases_page_url ?? update_releases_page_url());
$manualUploadMaxBytes = (int) ($manual_upload_max_bytes ?? \Core\AppUpdater::manualUploadMaxBytes());
?>
<div id="app-update">
<?php if ($showManifestUi): ?>
<?php admin_c_form_block01_open(); ?>
            <div class="area is-title">
                <?php admin_m_large_title01('アプリ更新'); ?>
            </div>
            <div class="area is-field">
                <form method="post" action="<?= e(base_path('/admin/settings/update-config')) ?>">
                    <?= \Core\Csrf::field() ?>
                    <dl class="admin-settings-dl">
                        <dt>自己更新</dt>
                        <dd>
                            <label>
                                <input type="checkbox" name="update_enabled" value="1"<?= !empty($update_enabled) ? ' checked' : '' ?>>
                                有効にする
                            </label>
                            <?php if (empty($update_enabled_db_set)): ?>
                                <p class="text is-help">未保存のときは config.local.php の <code>update.enabled</code> が使われます。</p>
                            <?php endif; ?>
                        </dd>
                        <dt>manifest URL</dt>
                        <dd>
                            <?php admin_m_input01_open(); ?>
                                <?php admin_m_input01_input([
                                    'type' => 'url',
                                    'name' => 'update_manifest_url',
                                    'id' => 'update_manifest_url',
                                    'value' => (string) ($update_manifest_url ?? ''),
                                    'placeholder' => 'https://raw.githubusercontent.com/.../manifest.json',
                                    'autocomplete' => 'off',
                                ]); ?>
                            <?php admin_m_input01_close(); ?>
                            <?php if (empty($update_manifest_url_db_set)): ?>
                                <p class="text is-help">未保存のときは config.local.php の <code>update.manifest_url</code> が使われます。</p>
                            <?php endif; ?>
                        </dd>
                    </dl>
                    <p class="text is-help">HTTPS の manifest のみ利用できます。ZIP には環境設定を含めません。</p>
                    <p style="margin-top:1rem;">
                        <button type="submit" class="btn is-primary">更新設定を保存</button>
                    </p>
                </form>
            </div>
<?php admin_c_form_block01_close(); ?>

<?php admin_c_form_block01_open(); ?>
            <div class="area is-title">
                <?php admin_m_large_title01('リリース'); ?>
            </div>
            <div class="area is-field">
                <dl class="admin-settings-dl">
                    <dt>現在のバージョン</dt>
                    <dd><code><?= e((string) ($currentVersion ?? '')) ?></code></dd>
                    <?php if ($latest !== '' && $latest !== ($currentVersion ?? '')): ?>
                        <dt>最新リリース</dt>
                        <dd><code><?= e($latest) ?></code></dd>
                    <?php endif; ?>
                    <dt>ZipArchive</dt>
                    <dd><?= !empty($requirements['zip']) ? '利用可' : '不可（サーバー拡張が必要）' ?></dd>
                </dl>

                <?php if (($manifestError ?? '') !== ''): ?>
                    <p class="text is-danger"><?= e($manifestError) ?></p>
                <?php endif; ?>

                <?php if (is_array($manifest) && $releases !== []): ?>
                    <h3 class="title is-sm">利用可能なリリース（channel: <?= e((string) ($manifest['channel'] ?? '')) ?>）</h3>
                    <table class="m-table01">
                        <thead>
                            <tr><th>版</th><th>日付</th><th>メモ</th><th></th></tr>
                        </thead>
                        <tbody>
                            <?php foreach ($releases as $row): ?>
                                <?php if (!is_array($row)) continue; ?>
                                <tr>
                                    <td><code><?= e((string) ($row['version'] ?? '')) ?></code></td>
                                    <td><?= e((string) ($row['released_at'] ?? '')) ?></td>
                                    <td><?= e((string) ($row['notes'] ?? '')) ?></td>
                                    <td>
                                        <?php if (!empty($requirements['enabled']) && !empty($requirements['zip']) && ($row['version'] ?? '') !== ($currentVersion ?? '')): ?>
                                            <form method="post" action="<?= e(base_path('/admin/settings/update')) ?>" onsubmit="return confirm('バージョン <?= e((string) $row['version']) ?> に更新します。よろしいですか？');">
                                                <?= \Core\Csrf::field() ?>
                                                <input type="hidden" name="version" value="<?= e((string) $row['version']) ?>">
                                                <button type="submit" class="btn is-primary is-sm">この版に更新</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text is-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php elseif (!empty($requirements['enabled']) && ($manifestError ?? '') === ''): ?>
                    <p class="text is-muted">manifest を取得できませんでした。</p>
                <?php elseif (empty($requirements['enabled'])): ?>
                    <p class="text is-muted">自己更新を有効にし manifest URL を保存すると、リリース一覧を表示します。</p>
                <?php endif; ?>
            </div>
<?php admin_c_form_block01_close(); ?>
<?php endif; ?>

<div id="app-update-manual">
<?php admin_c_form_block01_open(); ?>
            <div class="area is-title">
                <?php admin_m_large_title01('アプリ更新'); ?>
            </div>
            <div class="area is-field">
                <dl class="admin-settings-dl">
                    <dt>現在のバージョン</dt>
                    <dd><code><?= e((string) ($currentVersion ?? '')) ?></code></dd>
                    <dt>ZipArchive</dt>
                    <dd><?= !empty($requirements['zip']) ? '利用可' : '不可（サーバー拡張が必要）' ?></dd>
                    <?php if ($releasesPageUrl !== ''): ?>
                        <dt>リリースのダウンロード</dt>
                        <dd><a href="<?= e($releasesPageUrl) ?>" target="_blank" rel="noopener noreferrer">バージョン一覧ページ</a></dd>
                    <?php endif; ?>
                </dl>
                <?php if (empty($requirements['zip'])): ?>
                    <p class="text is-danger">ZipArchive 拡張が無効のため、手動アップロードは利用できません。</p>
                <?php else: ?>
                    <form method="post" action="<?= e(base_path('/admin/settings/update-upload')) ?>" enctype="multipart/form-data" data-module="c-updateUpload01" data-max-bytes="<?= (int) $manualUploadMaxBytes ?>">
                        <?= \Core\Csrf::field() ?>
                        <?php admin_c_update_upload01_zone(); ?>
                        <p style="margin-top:1rem;">
                            <button type="submit" class="btn is-primary" data-target="c-updateUpload01__submit">ZIP を適用して更新</button>
                        </p>
                    </form>
                <?php endif; ?>
            </div>
<?php admin_c_form_block01_close(); ?>
</div>
</div>
