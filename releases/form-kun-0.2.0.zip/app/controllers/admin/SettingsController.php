<?php
namespace Controllers\Admin;

use Core\AppUpdater;
use Core\Auth;
use Core\Csrf;
use Core\View;
use Models\AppSetting;
use Models\Form;

class SettingsController
{
    public function index(): void
    {
        Auth::requireLogin();

        $data = [
            'title'      => '設定',
            'form_count' => Form::count(),
            'max_forms'  => effective_max_forms(),
        ];

        if (Auth::role() === 'admin') {
            $showManifestUi = (bool) config('update.show_manifest_ui', false);
            $manifest = null;
            $manifestError = '';
            if ($showManifestUi && AppUpdater::isEnabled()) {
                $result = AppUpdater::fetchManifest();
                if ($result['ok']) {
                    $manifest = $result['manifest'];
                } else {
                    $manifestError = $result['message'];
                }
            }

            $data['show_manifest_ui'] = $showManifestUi;
            $data['currentVersion'] = AppUpdater::currentVersion();
            $data['requirements'] = AppUpdater::requirements();
            $data['manifest'] = $manifest;
            $data['manifestError'] = $manifestError;
            $data['update_enabled'] = effective_update_enabled();
            $data['update_manifest_url'] = effective_update_manifest_url();
            $data['update_enabled_db_set'] = self::appSettingIsSet(AppSetting::KEY_UPDATE_ENABLED);
            $data['update_manifest_url_db_set'] = self::appSettingIsSet(AppSetting::KEY_UPDATE_MANIFEST_URL);
            $data['releases_page_url'] = update_releases_page_url();
            $data['manual_upload_max_bytes'] = AppUpdater::manualUploadMaxBytes();
        }

        (new View())->render('admin/settings/index', $data, 'admin');
    }

    public function update(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $raw = trim((string) ($_POST['max_forms'] ?? ''));
        $v = filter_var($raw, FILTER_VALIDATE_INT);
        if ($v === false || $v < 1 || $v > 999999) {
            flash('danger', 'フォームの作成上限は 1 から 999999 までの整数で入力してください。');
            redirect('/admin/settings');
        }

        AppSetting::set(AppSetting::KEY_MAX_FORMS, (string) $v);
        flash('success', 'フォームの作成上限を保存しました。');
        redirect('/admin/settings');
    }

    public function updateUpdateConfig(): void
    {
        Auth::requireRole('admin');
        Csrf::verify();

        $enabled = isset($_POST['update_enabled']) && (string) $_POST['update_enabled'] === '1';
        $manifestUrl = trim((string) ($_POST['update_manifest_url'] ?? ''));

        if ($enabled && $manifestUrl === '') {
            flash('danger', '自己更新を有効にする場合は manifest URL を入力してください。');
            redirect('/admin/settings#app-update');
        }

        if ($manifestUrl !== '' && filter_var($manifestUrl, FILTER_VALIDATE_URL) === false) {
            flash('danger', 'manifest URL の形式が正しくありません。');
            redirect('/admin/settings#app-update');
        }

        if ($manifestUrl !== '' && parse_url($manifestUrl, PHP_URL_SCHEME) !== 'https') {
            flash('danger', 'manifest URL は HTTPS のみ利用できます。');
            redirect('/admin/settings#app-update');
        }

        AppSetting::set(AppSetting::KEY_UPDATE_ENABLED, $enabled ? '1' : '0');
        AppSetting::set(AppSetting::KEY_UPDATE_MANIFEST_URL, $manifestUrl);

        flash('success', 'アプリ更新の設定を保存しました。');
        redirect('/admin/settings#app-update');
    }

    private static function appSettingIsSet(string $key): bool
    {
        $raw = AppSetting::get($key);
        return $raw !== null && $raw !== '';
    }
}
