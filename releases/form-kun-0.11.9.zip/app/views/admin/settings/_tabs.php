<?php
/**
 * 設定系ページ共通のタブ並び（c-formEditTabs01 の .block.is-tabs）。
 *
 * $settingsTabsActive:
 *   - 'settings'（既定）… 設定ページ。パネル切替タブを描画し、「操作ログ」は設定配下の操作ログページへのリンク。
 *   - 'operation-logs' … 操作ログページ。各タブは設定ページの該当パネル（location.hash）へのリンクで、「操作ログ」を選択状態にする。
 *
 * リンク側のタブは既存のタブ切替 JS（data-target="c-formEditTabs01__tab" のセレクタ）に引っかからないよう
 * <a> 要素で data-target / role を付けずに描画する。
 */
$settingsTabsActive = $settingsTabsActive ?? 'settings';
$settingsTabsIsAdmin = \Core\Auth::role() === 'admin';
$settingsTabsLogsUrl = base_path('/admin/settings/operation-logs');
$settingsTabsPanelUrls = [
    'basic'     => base_path('/admin/settings#settings-basic'),
    'config'    => base_path('/admin/settings#settings-config'),
    'templates' => base_path('/admin/settings#settings-templates'),
    'line'      => base_path('/admin/settings#line-settings'),
    'backup'    => base_path('/admin/settings#settings-backup'),
];

$settingsTabsTab = static function (string $panel, string $label, bool $selected): void {
    ?>
    <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
        data-tab-panel="<?= e($panel) ?>" role="tab"
        aria-selected="<?= $selected ? 'true' : 'false' ?>"
        tabindex="<?= $selected ? '0' : '-1' ?>"><?= e($label) ?></div>
    <?php
};
$settingsTabsLink = static function (string $href, string $label, bool $selected): void {
    ?>
    <a href="<?= e($href) ?>" data-module="m-formEditTab01"<?= $selected ? ' aria-selected="true" aria-current="page"' : '' ?>><?= e($label) ?></a>
    <?php
};
?>
<?php if ($settingsTabsActive === 'settings'): ?>
<div class="block is-tabs" role="tablist" aria-orientation="vertical" aria-label="設定メニュー">
    <?php $settingsTabsTab('settings-basic', '基本情報', true); ?>
    <?php $settingsTabsTab('settings-config', '詳細情報', false); ?>
    <?php $settingsTabsTab('settings-templates', 'テンプレート', false); ?>
    <?php if ($settingsTabsIsAdmin): ?>
        <?php $settingsTabsTab('settings-line', 'LINE 連携', false); ?>
        <?php $settingsTabsTab('settings-backup', 'バックアップ', false); ?>
        <?php $settingsTabsLink($settingsTabsLogsUrl, '操作ログ', false); ?>
    <?php endif; ?>
</div>
<?php else: ?>
<div class="block is-tabs">
    <?php $settingsTabsLink($settingsTabsPanelUrls['basic'], '基本情報', false); ?>
    <?php $settingsTabsLink($settingsTabsPanelUrls['config'], '詳細情報', false); ?>
    <?php $settingsTabsLink($settingsTabsPanelUrls['templates'], 'テンプレート', false); ?>
    <?php if ($settingsTabsIsAdmin): ?>
        <?php $settingsTabsLink($settingsTabsPanelUrls['line'], 'LINE 連携', false); ?>
        <?php $settingsTabsLink($settingsTabsPanelUrls['backup'], 'バックアップ', false); ?>
        <?php $settingsTabsLink($settingsTabsLogsUrl, '操作ログ', true); ?>
    <?php endif; ?>
</div>
<?php endif; ?>
