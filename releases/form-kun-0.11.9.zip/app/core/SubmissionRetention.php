<?php
namespace Core;

use Models\Form;
use Models\Submission;

/**
 * 保存期間を過ぎた送信の件数確認と削除（CLI の定期処理・設定変更時の即時削除で共用）。
 * 対象は保存期間を「設定する」かつ、期間を過ぎた履歴を「削除する」にしたフォームだけ。
 */
class SubmissionRetention
{
    private const BATCH_SIZE = 500;

    /**
     * @param array<string, mixed> $form
     * @return array<string, mixed>
     */
    public static function purgeTarget(array $form): bool
    {
        return Form::retentionEnabled($form) && Form::retentionDeletes($form);
    }

    /**
     * フォーム一覧・ダッシュボードの受信セルに表示する削除設定マーカー。
     * - メール送信のみモード（Form::isMailOnly）: null（マーカーなしで件数を表示）
     * - 保存しない（Form::retentionNeverStore）: ['type' => 'never', 'text' => '']（「-」のみ表示）
     * - 保存期間「設定する」かつ「削除する」: ['type' => 'purge', 'text' => ツールチップ文言]
     *   （定期削除が無効な場合は「定期削除が設定されていないので自動削除は実行されません」）
     * それ以外は null（件数のみ表示）。
     *
     * 件数は $purgeNextRunAt を基準に保存期間を過ぎた履歴を数える（nextRunAt が null の場合は現在時刻基準）。
     *
     * @param array<string, mixed> $form
     * @return array{type: string, text: string}|null
     */
    public static function markerFor(array $form, bool $purgeEnabled, ?int $purgeNextRunAt): ?array
    {
        if (Form::isMailOnly($form)) {
            return null;
        }
        if (Form::retentionNeverStore($form)) {
            return ['type' => 'never', 'text' => ''];
        }
        // 定期削除 cron（submission_retention_enabled = 1 かつ削除）と同じ条件のフォームだけ時計アイコンを出す
        if ((int) ($form['submission_retention_enabled'] ?? 0) !== 1 || !Form::retentionDeletes($form)) {
            return null;
        }
        if (!$purgeEnabled) {
            return [
                'type' => 'purge',
                'text' => '定期削除が設定されていないので自動削除は実行されません',
            ];
        }

        $expiredCount = self::countExpired($form, $purgeNextRunAt);
        if ($purgeNextRunAt === null) {
            return [
                'type' => 'purge',
                'text' => '次回の定期削除で' . number_format($expiredCount) . '件削除される予定です',
            ];
        }

        return [
            'type' => 'purge',
            'text' => date('G', $purgeNextRunAt) . '時' . sprintf('%02d', (int) date('i', $purgeNextRunAt))
                . '分に' . number_format($expiredCount) . '件削除される予定です',
        ];
    }

    /**
     * @param array<string, mixed> $form
     */
    public static function countExpired(array $form, ?int $now = null): int
    {
        if (!self::purgeTarget($form)) {
            return 0;
        }
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS c FROM submissions WHERE form_id = ? AND submitted_at < ?',
            [(int) $form['id'], Form::retentionCutoff($form, $now)]
        );
        return (int) ($row['c'] ?? 0);
    }

    /**
     * 期間を過ぎた送信を添付ファイルとともに削除し、削除件数を返す。
     *
     * @param array<string, mixed> $form
     */
    public static function purgeExpired(array $form, ?int $now = null): int
    {
        if (!self::purgeTarget($form)) {
            return 0;
        }
        $formId = (int) $form['id'];
        $cutoff = Form::retentionCutoff($form, $now);
        $deleted = 0;
        while (true) {
            $rows = Database::fetchAll(
                'SELECT id FROM submissions WHERE form_id = ? AND submitted_at < ? ORDER BY id ASC LIMIT ' . self::BATCH_SIZE,
                [$formId, $cutoff]
            );
            if ($rows === []) {
                break;
            }
            Submission::bulkDelete(array_map(static fn(array $r): int => (int) $r['id'], $rows));
            $deleted += count($rows);
            if (count($rows) < self::BATCH_SIZE) {
                break;
            }
        }
        return $deleted;
    }
}
