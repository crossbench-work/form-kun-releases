<?php
/** フォーム編集:「外部連携」タブパネル */
$embedSettings = is_array($embedSettings ?? null) ? $embedSettings : \Models\FormEmbedSetting::defaults((int) ($form['id'] ?? 0));
$allowedOriginsInput = (string) ($embedSettings['allowed_origins_input'] ?? implode("\n", (array) ($embedSettings['allowed_origins'] ?? [])));
$publicUuid = trim((string) ($form['public_uuid'] ?? ''));
$embedApiUrl = $publicUuid !== '' ? url('/api/public/forms/' . $publicUuid . '/submit') : '';
$siteKey = trim((string) ($embedSettings['turnstile_site_key'] ?? 'YOUR_TURNSTILE_SITE_KEY'));
if ($siteKey === '') {
    $siteKey = 'YOUR_TURNSTILE_SITE_KEY';
}
$recaptchaSiteKey = trim((string) ($embedSettings['recaptcha_site_key'] ?? 'YOUR_RECAPTCHA_SITE_KEY'));
if ($recaptchaSiteKey === '') {
    $recaptchaSiteKey = 'YOUR_RECAPTCHA_SITE_KEY';
}
$recaptchaV3SiteKey = trim((string) ($embedSettings['recaptcha_v3_site_key'] ?? 'YOUR_RECAPTCHA_V3_SITE_KEY'));
if ($recaptchaV3SiteKey === '') {
    $recaptchaV3SiteKey = 'YOUR_RECAPTCHA_V3_SITE_KEY';
}
$captchaProvider = (string) ($embedSettings['captcha_provider'] ?? \Models\FormEmbedSetting::captchaProvider($embedSettings));
$fetchSample = $embedApiUrl !== '' ? <<<'JS'
const form = document.querySelector('#contact-form');
let deliveryId = crypto.randomUUID();

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const formData = new FormData(form);
  formData.set('delivery_id', deliveryId);
  const response = await fetch(__API_URL__, {
    method: 'POST',
    body: formData,
  });
  const result = await response.json();

  if (!response.ok) {
    window.turnstile?.reset();
    window.grecaptcha?.reset();
    console.error(result.message, result.errors ?? {});
    return;
  }
  if (result.redirect_url) {
    window.location.assign(result.redirect_url);
    return;
  }
  deliveryId = crypto.randomUUID();
  form.reset();
  window.turnstile?.reset();
  window.grecaptcha?.reset();
});
JS : '';
$recaptchaV3FetchSample = $embedApiUrl !== '' ? <<<'JS'
const form = document.querySelector('#contact-form');
let deliveryId = crypto.randomUUID();

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  await new Promise((resolve) => grecaptcha.ready(resolve));
  const token = await grecaptcha.execute(__SITE_KEY__, { action: 'submit' });
  const formData = new FormData(form);
  formData.set('delivery_id', deliveryId);
  formData.set('g-recaptcha-response', token);
  const response = await fetch(__API_URL__, {
    method: 'POST',
    body: formData,
  });
  const result = await response.json();

  if (!response.ok) {
    console.error(result.message, result.errors ?? {});
    return;
  }
  if (result.redirect_url) {
    window.location.assign(result.redirect_url);
    return;
  }
  deliveryId = crypto.randomUUID();
  form.reset();
});
JS : '';
$fetchSample = str_replace('__API_URL__', json_encode($embedApiUrl, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $fetchSample);
$recaptchaV3FetchSample = str_replace(
    ['__API_URL__', '__SITE_KEY__'],
    [
        json_encode($embedApiUrl, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        json_encode($recaptchaV3SiteKey, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ],
    $recaptchaV3FetchSample
);
if ($captchaProvider === \Models\FormEmbedSetting::CAPTCHA_RECAPTCHA_V3) {
    $fetchSample = $recaptchaV3FetchSample;
}
$turnstileSample = '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>' . "\n"
    . '<div class="cf-turnstile" data-sitekey="' . $siteKey . '"></div>';
$recaptchaSample = '<script src="https://www.google.com/recaptcha/api.js" async defer></script>' . "\n"
    . '<div class="g-recaptcha" data-sitekey="' . $recaptchaSiteKey . '"></div>';
$recaptchaV3Sample = '<script src="https://www.google.com/recaptcha/api.js?render=' . rawurlencode($recaptchaV3SiteKey) . '" async defer></script>';
?>
<div data-target="c-formEditTabs01__contents" data-tab-panel="external" class="area is-contents" role="tabpanel"
    aria-label="外部連携" hidden>
    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title">
            <?php admin_m_large_title01('Embed API'); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('APIの公開'); ?></div>
                <div class="area is-field">
                    <input type="hidden" name="embed_enabled" value="0">
                    <?php admin_m_checkbox01('外部HTMLからの送信を許可する', [
                        'name' => 'embed_enabled',
                        'value' => '1',
                        'checked' => !empty($embedSettings['enabled']),
                    ]); ?>
                    <p class="text is-help">有効化後も、下記の許可Originと完全に一致するブラウザだけが送信できます。</p>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('公開ページの表示'); ?></div>
                <div class="area is-field">
                    <input type="hidden" name="embed_public_page_hidden" value="0">
                    <?php admin_m_checkbox01('フォームくんの公開ページを表示しない', [
                        'name' => 'embed_public_page_hidden',
                        'value' => '1',
                        'checked' => !empty($embedSettings['public_page_hidden']),
                    ]); ?>
                    <p class="text is-help">有効にすると /f/{slug} の入力・確認・送信画面を404にし、公開フォーム一覧にも表示しません。Embed APIには影響しません。Embed APIも無効な場合は、どちらからも送信できません。</p>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('API URL'); ?></div>
                <div class="area is-field">
                    <?php if ($embedApiUrl !== ''): ?>
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input([
                            'type' => 'text',
                            'value' => $embedApiUrl,
                            'readonly' => true,
                            'aria-label' => 'Embed API URL',
                        ]); ?>
                        <?php admin_m_input01_close(); ?>
                    <?php else: ?>
                        <p class="text is-help">フォーム作成後にAPI URLが発行されます。</p>
                    <?php endif; ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('許可Origin', 'embed_allowed_origins'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_textarea(admin_m_input01_attrs_with_bound_label('embed_allowed_origins', [
                        'id' => 'embed_allowed_origins',
                        'name' => 'embed_allowed_origins',
                        'rows' => 5,
                        'placeholder' => "https://example.com\nhttps://staging.example.com:8443",
                    ]), $allowedOriginsInput); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">scheme・host・portを含むOriginを1行に1件入力します。パス、ワイルドカード、サブドメインの自動許可は使用できません。</p>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('送信完了画面URL', 'embed_completion_url'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_completion_url', [
                        'type' => 'url',
                        'id' => 'embed_completion_url',
                        'name' => 'embed_completion_url',
                        'value' => (string) ($embedSettings['completion_url'] ?? ''),
                        'placeholder' => 'https://example.com/thanks.html',
                    ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">送信成功時、APIのJSONにこのURLを返し、設置サンプルのJavaScriptが完了画面へ移動します。空欄の場合は画面遷移しません。</p>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('送信元の国制限'); ?></div>
                <div class="area is-field">
                    <input type="hidden" name="embed_japan_only_enabled" value="0">
                    <?php admin_m_checkbox01('日本国内のIPからだけ送信を許可する', [
                        'name' => 'embed_japan_only_enabled',
                        'value' => '1',
                        'checked' => !empty($embedSettings['japan_only_enabled']),
                    ]); ?>
                    <p class="text is-help">送信元IPをIPinfo Liteへ送信して国を判定します。海外・判定不能・サービス障害時は送信を拒否します。利用にはconfig.local.phpへのIPinfo Liteトークン設定が必要です。</p>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
    <?php admin_c_form_block01_close(); ?>

    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title"><?php admin_m_large_title01('不正送信対策'); ?></div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('使用する方式'); ?></div>
                <div class="area is-field">
                    <?php foreach ([
                        \Models\FormEmbedSetting::CAPTCHA_NONE => '使用しない',
                        \Models\FormEmbedSetting::CAPTCHA_TURNSTILE => 'Cloudflare Turnstile',
                        \Models\FormEmbedSetting::CAPTCHA_RECAPTCHA_V2 => 'Google reCAPTCHA v2チェックボックス',
                        \Models\FormEmbedSetting::CAPTCHA_RECAPTCHA_V3 => 'Google reCAPTCHA v3スコア判定',
                    ] as $providerValue => $providerLabel): ?>
                        <?php admin_m_radiobtn01($providerLabel, [
                            'name' => 'embed_captcha_provider',
                            'value' => $providerValue,
                            'checked' => $captchaProvider === $providerValue,
                        ]); ?>
                    <?php endforeach; ?>
                    <p class="text is-help">フォームごとに1方式を選択します。reCAPTCHA v2とv3のキーは別々に発行してください。</p>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
    <?php admin_c_form_block01_close(); ?>

    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title"><?php admin_m_large_title01('Turnstile'); ?></div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('サイトキー', 'embed_turnstile_site_key'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_turnstile_site_key', [
                        'type' => 'text', 'id' => 'embed_turnstile_site_key', 'name' => 'embed_turnstile_site_key',
                        'value' => (string) ($embedSettings['turnstile_site_key'] ?? ''), 'autocomplete' => 'off',
                    ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('シークレットキー', 'embed_turnstile_secret_key'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_turnstile_secret_key', [
                        'type' => 'password', 'id' => 'embed_turnstile_secret_key', 'name' => 'embed_turnstile_secret_key',
                        'value' => '', 'placeholder' => !empty($embedSettings['turnstile_secret_configured']) ? '●●●●●●●●' : '',
                        'autocomplete' => 'new-password',
                    ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">空欄のまま保存すると現在の値を保持します。<?= !empty($embedSettings['turnstile_secret_configured']) ? '現在は設定済みです。' : '現在は未設定です。' ?></p>
                    <?php if (!empty($embedSettings['turnstile_secret_configured'])): ?>
                        <input type="hidden" name="embed_turnstile_secret_clear" value="0">
                        <?php admin_m_checkbox01('保存済みのシークレットキーを削除する', [
                            'name' => 'embed_turnstile_secret_clear', 'value' => '1',
                            'checked' => !empty($embedSettings['turnstile_secret_clear']),
                        ]); ?>
                    <?php endif; ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
    <?php admin_c_form_block01_close(); ?>

    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title"><?php admin_m_large_title01('Google reCAPTCHA v2'); ?></div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('サイトキー', 'embed_recaptcha_site_key'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_recaptcha_site_key', [
                        'type' => 'text', 'id' => 'embed_recaptcha_site_key', 'name' => 'embed_recaptcha_site_key',
                        'value' => (string) ($embedSettings['recaptcha_site_key'] ?? ''), 'autocomplete' => 'off',
                    ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('シークレットキー', 'embed_recaptcha_secret_key'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_recaptcha_secret_key', [
                        'type' => 'password', 'id' => 'embed_recaptcha_secret_key', 'name' => 'embed_recaptcha_secret_key',
                        'value' => '', 'placeholder' => !empty($embedSettings['recaptcha_secret_configured']) ? '●●●●●●●●' : '',
                        'autocomplete' => 'new-password',
                    ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">空欄のまま保存すると現在の値を保持します。<?= !empty($embedSettings['recaptcha_secret_configured']) ? '現在は設定済みです。' : '現在は未設定です。' ?></p>
                    <?php if (!empty($embedSettings['recaptcha_secret_configured'])): ?>
                        <input type="hidden" name="embed_recaptcha_secret_clear" value="0">
                        <?php admin_m_checkbox01('保存済みのシークレットキーを削除する', [
                            'name' => 'embed_recaptcha_secret_clear', 'value' => '1',
                            'checked' => !empty($embedSettings['recaptcha_secret_clear']),
                        ]); ?>
                    <?php endif; ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
    <?php admin_c_form_block01_close(); ?>

    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title"><?php admin_m_large_title01('Google reCAPTCHA v3'); ?></div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('サイトキー', 'embed_recaptcha_v3_site_key'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_recaptcha_v3_site_key', [
                        'type' => 'text', 'id' => 'embed_recaptcha_v3_site_key', 'name' => 'embed_recaptcha_v3_site_key',
                        'value' => (string) ($embedSettings['recaptcha_v3_site_key'] ?? ''), 'autocomplete' => 'off',
                    ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('シークレットキー', 'embed_recaptcha_v3_secret_key'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_recaptcha_v3_secret_key', [
                        'type' => 'password', 'id' => 'embed_recaptcha_v3_secret_key', 'name' => 'embed_recaptcha_v3_secret_key',
                        'value' => '', 'placeholder' => !empty($embedSettings['recaptcha_v3_secret_configured']) ? '●●●●●●●●' : '',
                        'autocomplete' => 'new-password',
                    ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">空欄のまま保存すると現在の値を保持します。<?= !empty($embedSettings['recaptcha_v3_secret_configured']) ? '現在は設定済みです。' : '現在は未設定です。' ?></p>
                    <?php if (!empty($embedSettings['recaptcha_v3_secret_configured'])): ?>
                        <input type="hidden" name="embed_recaptcha_v3_secret_clear" value="0">
                        <?php admin_m_checkbox01('保存済みのシークレットキーを削除する', [
                            'name' => 'embed_recaptcha_v3_secret_clear', 'value' => '1',
                            'checked' => !empty($embedSettings['recaptcha_v3_secret_clear']),
                        ]); ?>
                    <?php endif; ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('合格スコア', 'embed_recaptcha_v3_min_score'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_recaptcha_v3_min_score', [
                        'type' => 'number', 'id' => 'embed_recaptcha_v3_min_score', 'name' => 'embed_recaptcha_v3_min_score',
                        'value' => (string) ($embedSettings['recaptcha_v3_min_score'] ?? 0.5),
                        'min' => '0', 'max' => '1', 'step' => '0.01',
                    ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">0.0〜1.0で設定します。既定値は0.5です。actionはsubmit固定です。</p>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
    <?php admin_c_form_block01_close(); ?>

    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title"><?php admin_m_large_title01('送信回数制限'); ?></div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('上限回数', 'embed_rate_limit_count'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_rate_limit_count', [
                        'type' => 'number', 'id' => 'embed_rate_limit_count', 'name' => 'embed_rate_limit_count',
                        'value' => (string) ($embedSettings['rate_limit_count'] ?? 10), 'min' => 1, 'max' => 1000,
                    ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('制限期間（秒）', 'embed_rate_limit_window_seconds'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_rate_limit_window_seconds', [
                        'type' => 'number', 'id' => 'embed_rate_limit_window_seconds', 'name' => 'embed_rate_limit_window_seconds',
                        'value' => (string) ($embedSettings['rate_limit_window_seconds'] ?? 600), 'min' => 60, 'max' => 86400,
                    ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">フォームと送信元IPの組み合わせごとに制限します。</p>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
    <?php admin_c_form_block01_close(); ?>

    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title"><?php admin_m_large_title01('設置サンプル'); ?></div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('Turnstile HTML'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_textarea(['rows' => 3, 'readonly' => true, 'aria-label' => 'Turnstile HTMLサンプル'], $turnstileSample); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('reCAPTCHA v2 HTML'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_textarea(['rows' => 3, 'readonly' => true, 'aria-label' => 'reCAPTCHA v2 HTMLサンプル'], $recaptchaSample); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('reCAPTCHA v3 HTML'); ?></div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_textarea(['rows' => 3, 'readonly' => true, 'aria-label' => 'reCAPTCHA v3 HTMLサンプル'], $recaptchaV3Sample); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('fetch JavaScript'); ?></div>
                <div class="area is-field">
                    <?php if ($fetchSample !== ''): ?>
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_textarea(['rows' => 18, 'readonly' => true, 'aria-label' => 'fetch JavaScriptサンプル'], $fetchSample); ?>
                        <?php admin_m_input01_close(); ?>
                    <?php else: ?>
                        <p class="text is-help">フォーム作成後にfetchサンプルが表示されます。</p>
                    <?php endif; ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
    <?php admin_c_form_block01_close(); ?>
</div>
