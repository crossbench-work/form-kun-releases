<?php
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/c-breadcrumb01/c-breadcrumb01.php';
require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php';
$FB_REGEX_CUSTOM = '__custom__';
$FB_REGEX_CHECKBOX_LIMIT = '__checkbox_limit__';
$regexPresetChoices = [
    '' => 'なし',
    '/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/u' => 'メールアドレス',
    '/\A(?:\+?\d[\d\-() ]*)\z/u' => '電話番号',
    '/\A[0-9]+\z/u' => '半角数字のみ',
    '/\A[a-zA-Z0-9]+\z/u' => '半角英数字のみ',
    '/\A[ぁ-んー]+\z/u' => 'ひらがなのみ',
    '/\A[ァ-ヶー　]+\z/u' => 'カタカナのみ（全角スペース可）',
    '/\A[a-zA-Z]+\z/u' => '半角英字のみ',
    $FB_REGEX_CUSTOM => 'カスタム（正規表現を入力）',
];
$breadcrumbTitle = trim((string) ($form['title'] ?? '')) !== '' ? (string) $form['title'] : '（無題）';
$slugPreviewValue = trim((string) ($form['slug'] ?? '')) !== '' ? (string) $form['slug'] : 'your-slug';
$publicPageUrl = url('/f/' . $slugPreviewValue);
$publicPageHidden = !empty($embedSettings['public_page_hidden']);
$publicPageAction = '';
ob_start();
admin_c_btn_set01_open();
echo '<div class="area is-contents">';
if (($form['status'] ?? '') === 'active' && trim((string) ($form['slug'] ?? '')) !== '' && !$publicPageHidden) {
    admin_m_btn01_link_wrap('公開ページ', $publicPageUrl, [
        'class' => 'is-sm',
        'target' => '_blank',
        'rel' => 'noopener noreferrer',
    ]);
} else {
    admin_m_btn01_button_wrap($publicPageHidden ? '公開ページ（非表示）' : '公開ページ', [
        'type' => 'button',
        'class' => 'is-sm',
        'disabled' => true,
        'aria-disabled' => 'true',
    ]);
}
echo '</div>';
echo '<div class="area is-contents">';
admin_m_btn01_button_wrap('プレビュー', [
    'type' => 'button',
    'class' => 'is-sm',
    'data-target' => 'p-formEdit01__previewRefresh',
    'aria-expanded' => 'false',
]);
echo '</div>';
admin_c_btn_set01_close();
$publicPageAction = (string) ob_get_clean();
$descriptionBlocks = $form['description_blocks'] ?? [['id' => 'description-0', 'label' => '', 'html' => '', 'position' => 0, 'visible' => 1, 'is_html' => 0]];
$confirmBlocks = $form['confirm_blocks'] ?? [['id' => 'confirm-0', 'label' => '', 'html' => '', 'position' => 0, 'visible' => 1, 'is_html' => 0]];
$thanksBlocks = $form['thanks_blocks'] ?? [['id' => 'thanks-0', 'label' => '', 'html' => '', 'position' => 0, 'visible' => 1, 'is_html' => 0]];
$publishRules = $form['publish_rules'] ?? [];
$unpublishRules = $form['unpublish_rules'] ?? [];
$closedBlocks = $form['closed_blocks'] ?? [['id' => 'closed-0', 'label' => '', 'html' => '', 'position' => 0, 'visible' => 1, 'is_html' => 0]];
$showClosedScreenTab = form_has_visible_schedule_rules($form);
$maxInputVars = (int) ini_get('max_input_vars');
if ($maxInputVars <= 0) {
    $maxInputVars = 1000;
}
?>

<?php admin_c_breadcrumb01([
    ['label' => 'フォーム', 'href' => base_path('/admin/forms')],
    ['label' => $breadcrumbTitle, 'current' => true],
], $publicPageAction); ?>

<?php admin_c_form_edit01_open([
    'method' => 'post',
    'action' => $isNew ? base_path('/admin/forms') : base_path('/admin/forms/' . (int) $form['id']),
    'id' => 'form-edit-main',
    'data-max-input-vars' => $maxInputVars,
]); ?>
    <?= \Core\Csrf::field() ?>
    <?php if (!$isNew): ?>
    <input type="hidden" name="_form_id" value="<?= (int) $form['id'] ?>">
    <?php endif; ?>
    <input type="hidden" name="builder_payload" value="" data-target="builderPayload">
    <input type="hidden" name="_builder_meta[field_count]" value="" data-target="builderMetaFieldCount">
    <input type="hidden" name="_builder_meta[field_keys]" value="" data-target="builderMetaFieldKeys">
    <input type="hidden" name="_builder_meta[group_count]" value="" data-target="builderMetaGroupCount">
    <input type="hidden" name="_builder_meta[group_keys]" value="" data-target="builderMetaGroupKeys">
    <input type="hidden" name="_builder_meta[input_page_count]" value="" data-target="builderMetaInputPageCount">
    <input type="hidden" name="_builder_meta[branch_rule_count]" value="" data-target="builderMetaBranchRuleCount">
    <input type="hidden" name="_builder_meta[input_var_count]" value="" data-target="builderMetaInputVarCount">
    <?php admin_c_form_edit01_floating_actions($isNew); ?>
    <div class="wrapper">
        <div class="block is-contents">
            <?php if (!empty($errors)): ?>
                <?php admin_c_alert01_open(); ?>
                    <ul>
                        <?php foreach ($errors as $msg): ?>
                            <li><?= e($msg) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php admin_c_alert01_close(); ?>
            <?php endif; ?>

            <?php admin_c_form_edit_tabs01_open(); ?>
            <?php require __DIR__ . '/basic/index.php'; ?>
            <?php require __DIR__ . '/screens/index.php'; ?>
            <?php require __DIR__ . '/screens/branch_rules.php'; ?>
            <?php require __DIR__ . '/mail/index.php'; ?>
            <?php require __DIR__ . '/external/index.php'; ?>
            <?php admin_c_form_edit_tabs01_close(); ?>

            <div class="block bottom">
                <?php admin_c_btn_set01_open(); ?>
                    <div class="area is-contents">
                        <?php admin_m_btn01_button_wrap($isNew ? '作成する' : '保存する', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    </div>
                    <div class="area is-contents">
                        <?php admin_m_btn01_link_wrap('キャンセル', base_path('/admin/forms')); ?>
                    </div>
                <?php admin_c_btn_set01_close(); ?>
            </div>
        </div>
    </div>
<?php admin_c_form_edit01_close(); ?>

<?php if (!empty($fieldTemplates ?? [])): ?>
<div class="c-fieldTemplateApply01" data-module="c-fieldTemplateApply01" hidden>
    <div class="c-fieldTemplateApply01__backdrop" data-target="fieldTemplateApplyClose"></div>
    <div class="c-fieldTemplateApply01__dialog" role="dialog" aria-modal="true" aria-labelledby="field-template-apply-title">
        <div class="c-fieldTemplateApply01__header">
            <h2 id="field-template-apply-title">テンプレートを使用</h2>
            <button type="button" class="btn is-sm" data-target="fieldTemplateApplyClose">閉じる</button>
        </div>
        <div class="c-fieldTemplateApply01__body">
            <div class="c-fieldTemplateApply01__list">
                <?php foreach ($fieldTemplates as $tpl): ?>
                    <button type="button" class="c-fieldTemplateApply01__item"
                        data-target="fieldTemplateApplyItem"
                        data-template-url="<?= e(base_path('/admin/settings/templates/' . rawurlencode((string) $tpl['id']) . '/json')) ?>">
                        <?= e((string) ($tpl['title'] ?? '')) ?>
                    </button>
                <?php endforeach; ?>
            </div>
            <div class="c-fieldTemplateApply01__mode">
                <label><input type="radio" name="field_template_apply_mode" value="append" checked> 末尾に追加</label>
                <label><input type="radio" name="field_template_apply_mode" value="replace"> 現在の項目を置き換え</label>
            </div>
            <p data-module="m-text01" data-type="muted">置き換えを選ぶと、現在の入力画面にある項目とグループを削除してからテンプレートを挿入します。</p>
        </div>
    </div>
</div>
<?php endif; ?>

<?php ob_start(); ?>
<?php admin_c_preview_block01(
    base_path('/admin/forms/preview-input'),
    base_path('/admin/forms/preview-confirm'),
    base_path('/admin/forms/preview-thanks'),
    base_path('/admin/forms/preview-closed')
); ?>
<?php $GLOBALS['formkun_admin_container_after_main'] = (string) ob_get_clean(); ?>

<?php admin_c_field_type_modal01(); ?>

<?php admin_m_form_builder01_description_template(); ?>

<?php admin_m_form_builder01_field_template(); ?>

<?php admin_m_form_builder01_group_template(); ?>
