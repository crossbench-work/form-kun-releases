<?php
namespace Controllers\Api;

use Core\FormPublishSchedule;
use Core\IpCountryResolver;
use Core\PublicApiRateLimiter;
use Core\PublicFormSubmissionService;
use Core\RecaptchaVerifier;
use Core\RecaptchaV3Verifier;
use Core\SiteResource;
use Core\TurnstileVerifier;
use Models\Form;
use Models\FormEmbedSetting;

class PublicFormController
{
    public function preflight(string $publicUuid): void
    {
        try {
            $context = $this->authorizedContext($publicUuid);
            if ($context === null) {
                return;
            }
            $this->cors((string) $context['origin']);
            http_response_code(204);
        } catch (\Throwable $e) {
            error_log('[formkun] public embed API preflight failed');
            if (!headers_sent()) {
                $this->json(500, false, 'サーバ内部でエラーが発生しました。時間をおいて再度お試しください。', 'server_error');
            }
        }
    }

    public function submit(string $publicUuid): void
    {
        try {
            $context = $this->authorizedContext($publicUuid);
            if ($context === null) {
                return;
            }
            $origin = (string) $context['origin'];
            $form = $context['form'];
            $settings = $context['settings'];
            $this->cors($origin);

            $contentType = strtolower(trim((string) ($_SERVER['CONTENT_TYPE'] ?? '')));
            if (!str_starts_with($contentType, 'multipart/form-data')) {
                $this->json(415, false, 'multipart/form-data で送信してください。', 'unsupported_media_type');
                return;
            }
            if (!FormPublishSchedule::isOpen($form)) {
                $this->json(403, false, '現在、このフォームは受け付けていません。', 'form_unavailable');
                return;
            }
            if (SiteResource::isExceeded()) {
                $this->json(503, false, '現在、フォームを受け付けできません。', 'service_unavailable');
                return;
            }

            $rate = PublicApiRateLimiter::consume(
                (int) $form['id'],
                client_ip(),
                (int) $settings['rate_limit_count'],
                (int) $settings['rate_limit_window_seconds']
            );
            if (!$rate['allowed']) {
                header('Retry-After: ' . $rate['retry_after']);
                $this->json(429, false, '送信回数が上限に達しました。時間をおいて再度お試しください。', 'rate_limited', [
                    'retry_after' => $rate['retry_after'],
                ]);
                return;
            }

            if (!empty($settings['japan_only_enabled'])) {
                $countryCode = IpCountryResolver::resolve(client_ip());
                if ($countryCode === null) {
                    $this->json(503, false, '送信元の国を確認できませんでした。時間をおいて再度お試しください。', 'country_lookup_unavailable');
                    return;
                }
                if ($countryCode !== 'JP') {
                    $this->json(403, false, 'このフォームは日本国内からのみ送信できます。', 'country_forbidden');
                    return;
                }
            }

            if (!empty($settings['turnstile_enabled'])) {
                $hostname = (string) (parse_url($origin, PHP_URL_HOST) ?: '');
                $verification = TurnstileVerifier::verify(
                    (string) ($settings['turnstile_secret_key'] ?? ''),
                    (string) ($_POST['cf-turnstile-response'] ?? ''),
                    client_ip(),
                    $hostname
                );
                if ($verification === TurnstileVerifier::UNAVAILABLE) {
                    $this->json(503, false, '不正送信対策の確認を完了できませんでした。時間をおいて再度お試しください。', 'verification_unavailable');
                    return;
                }
                if ($verification !== TurnstileVerifier::VALID) {
                    $this->json(403, false, '不正送信対策の確認に失敗しました。', 'turnstile_invalid');
                    return;
                }
            }
            if (!empty($settings['recaptcha_enabled'])) {
                $hostname = (string) (parse_url($origin, PHP_URL_HOST) ?: '');
                $verification = RecaptchaVerifier::verify(
                    (string) ($settings['recaptcha_secret_key'] ?? ''),
                    (string) ($_POST['g-recaptcha-response'] ?? ''),
                    client_ip(),
                    $hostname
                );
                if ($verification === RecaptchaVerifier::UNAVAILABLE) {
                    $this->json(503, false, '不正送信対策の確認を完了できませんでした。時間をおいて再度お試しください。', 'verification_unavailable');
                    return;
                }
                if ($verification !== RecaptchaVerifier::VALID) {
                    $this->json(403, false, '不正送信対策の確認に失敗しました。', 'recaptcha_invalid');
                    return;
                }
            }
            if (!empty($settings['recaptcha_v3_enabled'])) {
                $hostname = (string) (parse_url($origin, PHP_URL_HOST) ?: '');
                $verification = RecaptchaV3Verifier::verify(
                    (string) ($settings['recaptcha_v3_secret_key'] ?? ''),
                    (string) ($_POST['g-recaptcha-response'] ?? ''),
                    client_ip(),
                    $hostname,
                    (float) ($settings['recaptcha_v3_min_score'] ?? FormEmbedSetting::DEFAULT_RECAPTCHA_V3_MIN_SCORE)
                );
                if ($verification === RecaptchaV3Verifier::UNAVAILABLE) {
                    $this->json(503, false, '不正送信対策の確認を完了できませんでした。時間をおいて再度お試しください。', 'verification_unavailable');
                    return;
                }
                if ($verification !== RecaptchaV3Verifier::VALID) {
                    $this->json(403, false, '不正送信対策の確認に失敗しました。', 'recaptcha_v3_invalid');
                    return;
                }
            }

            $input = $_POST;
            unset($input['cf-turnstile-response']);
            unset($input['g-recaptcha-response']);
            $result = PublicFormSubmissionService::submit($form, $input, $_FILES);
            if (!$result['success']) {
                if (!empty($result['delivery_error'])) {
                    $this->json(503, false, 'メールを送信できませんでした。時間をおいて再度お試しください。', 'mail_delivery_failed');
                    return;
                }
                $this->json(422, false, '入力内容を確認してください。', 'validation_error', [
                    'errors' => $result['errors'] ?? [],
                ]);
                return;
            }
            $completionUrl = FormEmbedSetting::normalizeCompletionUrl((string) ($settings['completion_url'] ?? ''));
            $this->json(200, true, '送信が完了しました。', null, $completionUrl !== null ? [
                'redirect_url' => $completionUrl,
            ] : []);
        } catch (\Throwable $e) {
            error_log('[formkun] public embed API failed');
            if (!headers_sent()) {
                $this->json(500, false, 'サーバ内部でエラーが発生しました。時間をおいて再度お試しください。', 'server_error');
            }
        }
    }

    /** @return array{form: array<string, mixed>, settings: array<string, mixed>, origin: string}|null */
    private function authorizedContext(string $publicUuid): ?array
    {
        $form = Form::findActiveByPublicUuid($publicUuid);
        if ($form === null) {
            $this->json(404, false, 'フォームが見つかりません。', 'not_found');
            return null;
        }
        $settings = FormEmbedSetting::forForm((int) $form['id'], true);
        if (empty($settings['enabled'])) {
            $this->json(404, false, 'フォームが見つかりません。', 'not_found');
            return null;
        }
        $origin = FormEmbedSetting::normalizeOrigin((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
        if ($origin === null || !in_array($origin, (array) $settings['allowed_origins'], true)) {
            $this->json(403, false, 'この送信元からは利用できません。', 'origin_forbidden');
            return null;
        }
        return ['form' => $form, 'settings' => $settings, 'origin' => $origin];
    }

    private function cors(string $origin): void
    {
        header('Access-Control-Allow-Origin: ' . $origin);
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        header('Access-Control-Max-Age: 600');
        header('Vary: Origin');
    }

    /** @param array<string, mixed> $extra */
    private function json(int $status, bool $success, string $message, ?string $code = null, array $extra = []): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        $body = ['success' => $success, 'message' => $message];
        if ($code !== null) {
            $body['code'] = $code;
        }
        echo json_encode(array_merge($body, $extra), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
