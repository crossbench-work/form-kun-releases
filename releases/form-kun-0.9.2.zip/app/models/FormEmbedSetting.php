<?php
namespace Models;

use Core\Database;

class FormEmbedSetting
{
    public const DEFAULT_RATE_LIMIT_COUNT = 10;
    public const DEFAULT_RATE_LIMIT_WINDOW_SECONDS = 600;
    public const DEFAULT_RECAPTCHA_V3_MIN_SCORE = 0.5;
    public const CAPTCHA_NONE = 'none';
    public const CAPTCHA_TURNSTILE = 'turnstile';
    public const CAPTCHA_RECAPTCHA_V2 = 'recaptcha_v2';
    public const CAPTCHA_RECAPTCHA_V3 = 'recaptcha_v3';

    /** @return array<string, mixed> */
    public static function defaults(int $formId): array
    {
        return [
            'form_id' => $formId,
            'enabled' => 0,
            'public_page_hidden' => 0,
            'allowed_origins' => [],
            'completion_url' => '',
            'japan_only_enabled' => 0,
            'turnstile_enabled' => 0,
            'turnstile_site_key' => '',
            'turnstile_secret_key' => '',
            'turnstile_secret_configured' => 0,
            'recaptcha_enabled' => 0,
            'recaptcha_site_key' => '',
            'recaptcha_secret_key' => '',
            'recaptcha_secret_configured' => 0,
            'recaptcha_v3_enabled' => 0,
            'recaptcha_v3_site_key' => '',
            'recaptcha_v3_secret_key' => '',
            'recaptcha_v3_secret_configured' => 0,
            'recaptcha_v3_min_score' => self::DEFAULT_RECAPTCHA_V3_MIN_SCORE,
            'captcha_provider' => self::CAPTCHA_NONE,
            'rate_limit_count' => self::DEFAULT_RATE_LIMIT_COUNT,
            'rate_limit_window_seconds' => self::DEFAULT_RATE_LIMIT_WINDOW_SECONDS,
        ];
    }

    /** @return array<string, mixed> */
    public static function forForm(int $formId, bool $includeSecret = false): array
    {
        $row = Database::fetchOne('SELECT * FROM form_embed_settings WHERE form_id = ?', [$formId]);
        if ($row === null) {
            return self::defaults($formId);
        }
        $row['allowed_origins'] = self::decodeOrigins($row['allowed_origins_json'] ?? null);
        $row['enabled'] = !empty($row['enabled']) ? 1 : 0;
        $row['public_page_hidden'] = !empty($row['public_page_hidden']) ? 1 : 0;
        $row['japan_only_enabled'] = !empty($row['japan_only_enabled']) ? 1 : 0;
        $row['turnstile_enabled'] = !empty($row['turnstile_enabled']) ? 1 : 0;
        $row['turnstile_secret_configured'] = trim((string) ($row['turnstile_secret_key'] ?? '')) !== '' ? 1 : 0;
        $row['recaptcha_enabled'] = !empty($row['recaptcha_enabled']) ? 1 : 0;
        $row['recaptcha_secret_configured'] = trim((string) ($row['recaptcha_secret_key'] ?? '')) !== '' ? 1 : 0;
        $row['recaptcha_v3_enabled'] = !empty($row['recaptcha_v3_enabled']) ? 1 : 0;
        $row['recaptcha_v3_secret_configured'] = trim((string) ($row['recaptcha_v3_secret_key'] ?? '')) !== '' ? 1 : 0;
        $row['recaptcha_v3_min_score'] = self::normalizeRecaptchaV3MinScore($row['recaptcha_v3_min_score'] ?? null);
        $row['captcha_provider'] = self::captchaProvider($row);
        $row['rate_limit_count'] = self::normalizeRateCount($row['rate_limit_count'] ?? null);
        $row['rate_limit_window_seconds'] = self::normalizeRateWindow($row['rate_limit_window_seconds'] ?? null);
        if (!$includeSecret) {
            $row['turnstile_secret_key'] = '';
            $row['recaptcha_secret_key'] = '';
            $row['recaptcha_v3_secret_key'] = '';
        }
        return array_merge(self::defaults($formId), $row);
    }

    /** @param array<string, mixed> $data */
    public static function save(int $formId, array $data): void
    {
        $stored = self::forForm($formId, true);
        $secret = trim((string) ($data['turnstile_secret_key'] ?? ''));
        if (!empty($data['turnstile_secret_clear'])) {
            $secret = '';
        } elseif ($secret === '') {
            $secret = (string) ($stored['turnstile_secret_key'] ?? '');
        }
        $recaptchaSecret = trim((string) ($data['recaptcha_secret_key'] ?? ''));
        if (!empty($data['recaptcha_secret_clear'])) {
            $recaptchaSecret = '';
        } elseif ($recaptchaSecret === '') {
            $recaptchaSecret = (string) ($stored['recaptcha_secret_key'] ?? '');
        }
        $recaptchaV3Secret = trim((string) ($data['recaptcha_v3_secret_key'] ?? ''));
        if (!empty($data['recaptcha_v3_secret_clear'])) {
            $recaptchaV3Secret = '';
        } elseif ($recaptchaV3Secret === '') {
            $recaptchaV3Secret = (string) ($stored['recaptcha_v3_secret_key'] ?? '');
        }
        $origins = self::normalizeOrigins($data['allowed_origins'] ?? []);
        $now = date('Y-m-d H:i:s');
        Database::execute(
            'INSERT INTO form_embed_settings (
                form_id, enabled, public_page_hidden, allowed_origins_json, japan_only_enabled,
                completion_url,
                turnstile_enabled, turnstile_site_key, turnstile_secret_key,
                recaptcha_enabled, recaptcha_site_key, recaptcha_secret_key,
                recaptcha_v3_enabled, recaptcha_v3_site_key, recaptcha_v3_secret_key, recaptcha_v3_min_score,
                rate_limit_count, rate_limit_window_seconds, created_at, updated_at
             ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
             ON DUPLICATE KEY UPDATE
                enabled = VALUES(enabled), public_page_hidden = VALUES(public_page_hidden),
                allowed_origins_json = VALUES(allowed_origins_json),
                completion_url = VALUES(completion_url),
                japan_only_enabled = VALUES(japan_only_enabled),
                turnstile_enabled = VALUES(turnstile_enabled), turnstile_site_key = VALUES(turnstile_site_key),
                turnstile_secret_key = VALUES(turnstile_secret_key), rate_limit_count = VALUES(rate_limit_count),
                recaptcha_enabled = VALUES(recaptcha_enabled), recaptcha_site_key = VALUES(recaptcha_site_key),
                recaptcha_secret_key = VALUES(recaptcha_secret_key),
                recaptcha_v3_enabled = VALUES(recaptcha_v3_enabled), recaptcha_v3_site_key = VALUES(recaptcha_v3_site_key),
                recaptcha_v3_secret_key = VALUES(recaptcha_v3_secret_key), recaptcha_v3_min_score = VALUES(recaptcha_v3_min_score),
                rate_limit_window_seconds = VALUES(rate_limit_window_seconds), updated_at = VALUES(updated_at)',
            [
                $formId,
                !empty($data['enabled']) ? 1 : 0,
                !empty($data['public_page_hidden']) ? 1 : 0,
                json_encode($origins, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                !empty($data['japan_only_enabled']) ? 1 : 0,
                trim((string) ($data['completion_url'] ?? '')),
                !empty($data['turnstile_enabled']) ? 1 : 0,
                trim((string) ($data['turnstile_site_key'] ?? '')),
                $secret,
                !empty($data['recaptcha_enabled']) ? 1 : 0,
                trim((string) ($data['recaptcha_site_key'] ?? '')),
                $recaptchaSecret,
                !empty($data['recaptcha_v3_enabled']) ? 1 : 0,
                trim((string) ($data['recaptcha_v3_site_key'] ?? '')),
                $recaptchaV3Secret,
                self::normalizeRecaptchaV3MinScore($data['recaptcha_v3_min_score'] ?? null),
                self::normalizeRateCount($data['rate_limit_count'] ?? null),
                self::normalizeRateWindow($data['rate_limit_window_seconds'] ?? null),
                $now,
                $now,
            ]
        );
    }

    /** @param array<string, mixed> $settings */
    public static function captchaProvider(array $settings): string
    {
        if (!empty($settings['turnstile_enabled'])) {
            return self::CAPTCHA_TURNSTILE;
        }
        if (!empty($settings['recaptcha_enabled'])) {
            return self::CAPTCHA_RECAPTCHA_V2;
        }
        if (!empty($settings['recaptcha_v3_enabled'])) {
            return self::CAPTCHA_RECAPTCHA_V3;
        }
        return self::CAPTCHA_NONE;
    }

    public static function normalizeRecaptchaV3MinScore($value): float
    {
        if (!is_numeric($value)) {
            return self::DEFAULT_RECAPTCHA_V3_MIN_SCORE;
        }
        $score = (float) $value;
        return $score >= 0.0 && $score <= 1.0
            ? round($score, 2)
            : self::DEFAULT_RECAPTCHA_V3_MIN_SCORE;
    }

    public static function normalizeCompletionUrl(string $value): ?string
    {
        $value = trim($value);
        if ($value === '' || mb_strlen($value) > 500 || !filter_var($value, FILTER_VALIDATE_URL)) {
            return null;
        }
        $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));
        return in_array($scheme, ['http', 'https'], true) ? $value : null;
    }

    /** @param mixed $raw @return list<string> */
    public static function normalizeOrigins($raw): array
    {
        if (is_string($raw)) {
            $raw = preg_split('/\R/u', $raw) ?: [];
        }
        if (!is_array($raw)) {
            return [];
        }
        $origins = [];
        foreach ($raw as $value) {
            $origin = self::normalizeOrigin((string) $value);
            if ($origin !== null && !in_array($origin, $origins, true)) {
                $origins[] = $origin;
            }
        }
        return $origins;
    }

    public static function normalizeOrigin(string $value): ?string
    {
        $value = trim($value);
        if ($value === '' || str_contains($value, '*')) {
            return null;
        }
        $parts = parse_url($value);
        if (!is_array($parts) || !isset($parts['scheme'], $parts['host'])) {
            return null;
        }
        if (isset($parts['user'], $parts['pass'], $parts['query'], $parts['fragment'])) {
            return null;
        }
        if (isset($parts['path']) && $parts['path'] !== '' && $parts['path'] !== '/') {
            return null;
        }
        $scheme = strtolower((string) $parts['scheme']);
        if (!in_array($scheme, ['http', 'https'], true)) {
            return null;
        }
        $host = strtolower(rtrim((string) $parts['host'], '.'));
        if ($host === '') {
            return null;
        }
        if (str_contains($host, ':') && $host[0] !== '[') {
            $host = '[' . $host . ']';
        }
        $port = isset($parts['port']) ? (int) $parts['port'] : null;
        if (($scheme === 'https' && $port === 443) || ($scheme === 'http' && $port === 80)) {
            $port = null;
        }
        return $scheme . '://' . $host . ($port !== null ? ':' . $port : '');
    }

    /** @param mixed $raw @return list<string> */
    private static function decodeOrigins($raw): array
    {
        $decoded = json_decode((string) $raw, true);
        return self::normalizeOrigins(is_array($decoded) ? $decoded : []);
    }

    private static function normalizeRateCount($value): int
    {
        $value = filter_var($value, FILTER_VALIDATE_INT);
        return $value !== false && $value >= 1 && $value <= 1000
            ? (int) $value
            : self::DEFAULT_RATE_LIMIT_COUNT;
    }

    private static function normalizeRateWindow($value): int
    {
        $value = filter_var($value, FILTER_VALIDATE_INT);
        return $value !== false && $value >= 60 && $value <= 86400
            ? (int) $value
            : self::DEFAULT_RATE_LIMIT_WINDOW_SECONDS;
    }
}
