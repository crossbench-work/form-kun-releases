<?php
/**
 * フォーム編集画面のタブシェル c-formEditTabs01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _c-formEditTabs01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_form_edit_tabs01_open')) {
    function admin_c_form_edit_tabs01_open(): void
    {
        $tabs = [
            ['panel' => 'basic', 'label' => '基本', 'selected' => true],
            ['panel' => 'screens', 'label' => '画面', 'selected' => false],
            ['panel' => 'branch', 'label' => '分岐処理', 'selected' => false],
            ['panel' => 'mail', 'label' => '通知', 'selected' => false],
            ['panel' => 'external', 'label' => '外部連携', 'selected' => false],
        ];
        ?>
        <div data-module="c-formEditTabs01" data-tab-scope="main">
            <div class="wrapper">
                <div class="block is-tabs" role="tablist" aria-orientation="horizontal" aria-label="フォーム設定のセクション">
                    <?php foreach ($tabs as $tab): ?>
                        <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                            data-tab-panel="<?= e($tab['panel']) ?>" role="tab"
                            aria-selected="<?= !empty($tab['selected']) ? 'true' : 'false' ?>"
                            tabindex="<?= !empty($tab['selected']) ? '0' : '-1' ?>"><?= e($tab['label']) ?></div>
                    <?php endforeach; ?>
                </div>
                <div class="block is-contents">
        <?php
    }

    function admin_c_form_edit_tabs01_close(): void
    {
        echo '</div></div></div>';
    }

    /**
     * メインタブ内の区分サブタブ（複数 c-formBlock01 を切り替え）。
     *
     * @param list<array{panel: string, label: string, selected?: bool}> $tabs
     */
    function admin_c_form_edit_section_tabs01_open(string $scopeId, array $tabs, string $ariaLabel): void
    {
        ?>
        <div data-module="c-formEditTabs01" class="is-nested" data-tab-scope="<?= e($scopeId) ?>">
            <div class="wrapper">
                <div class="block is-tabs" role="tablist" aria-orientation="vertical" aria-label="<?= e($ariaLabel) ?>">
                    <?php foreach ($tabs as $tab): ?>
                        <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                            data-tab-panel="<?= e($tab['panel']) ?>" role="tab"
                            aria-selected="<?= !empty($tab['selected']) ? 'true' : 'false' ?>"
                            tabindex="<?= !empty($tab['selected']) ? '0' : '-1' ?>"><?= e($tab['label']) ?></div>
                    <?php endforeach; ?>
                </div>
                <div class="block is-contents">
        <?php
    }

    function admin_c_form_edit_section_tabs01_close(): void
    {
        echo '</div></div></div>';
    }
}
