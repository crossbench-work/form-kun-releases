<?php
/**
 * 管理画面の左線付き見出し m-leftBorderTitle01（ブロックの区切りを示す）。
 * スタイルは同ディレクトリの _m-leftBorderTitle01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_left_border_title01')) {
    function admin_m_left_border_title01(string $text): void
    {
        echo '<p data-module="m-leftBorderTitle01">' . e($text) . '</p>';
    }
}
