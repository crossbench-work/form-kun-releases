<?php
namespace Core;

class IpCountryResolver
{
    private const API_BASE = 'https://api.ipinfo.io/lite/';

    public static function resolve(string $ip): ?string
    {
        $ip = trim($ip);
        if (filter_var($ip, FILTER_VALIDATE_IP) === false) {
            return null;
        }
        $ttl = max(300, min(604800, (int) config('ip_geolocation.cache_ttl_seconds', 86400)));
        $cached = Database::fetchOne('SELECT country_code, checked_at FROM ip_country_cache WHERE ip = ?', [$ip]);
        if ($cached !== null && strtotime((string) $cached['checked_at']) >= time() - $ttl) {
            return self::normalizeCountryCode((string) $cached['country_code']);
        }

        $token = trim((string) config('ip_geolocation.ipinfo_token', ''));
        if ($token === '' || str_contains($token, "\r") || str_contains($token, "\n")) {
            error_log('[formkun] IP country lookup is not configured');
            return null;
        }
        $timeout = max(1, min(10, (int) config('ip_geolocation.timeout_seconds', 5)));
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => "Accept: application/json\r\nAuthorization: Bearer " . $token . "\r\n",
                'timeout' => $timeout,
                'ignore_errors' => true,
            ],
        ]);
        $response = @file_get_contents(self::API_BASE . rawurlencode($ip), false, $context);
        if ($response === false || self::responseStatus($http_response_header ?? []) !== 200) {
            error_log('[formkun] IP country lookup request failed');
            return null;
        }
        $decoded = json_decode($response, true);
        $countryCode = is_array($decoded) ? self::normalizeCountryCode((string) ($decoded['country_code'] ?? '')) : null;
        if ($countryCode === null) {
            error_log('[formkun] IP country lookup returned an invalid response');
            return null;
        }
        Database::execute(
            'INSERT INTO ip_country_cache (ip, country_code, checked_at) VALUES (?,?,?)
             ON DUPLICATE KEY UPDATE country_code = VALUES(country_code), checked_at = VALUES(checked_at)',
            [$ip, $countryCode, date('Y-m-d H:i:s')]
        );
        if (random_int(1, 100) === 1) {
            Database::execute('DELETE FROM ip_country_cache WHERE checked_at < ?', [date('Y-m-d H:i:s', time() - 604800)]);
        }
        return $countryCode;
    }

    private static function normalizeCountryCode(string $value): ?string
    {
        $value = strtoupper(trim($value));
        return preg_match('/\A[A-Z]{2}\z/', $value) === 1 ? $value : null;
    }

    /** @param list<string> $headers */
    private static function responseStatus(array $headers): int
    {
        foreach ($headers as $header) {
            if (preg_match('/\AHTTP\/\S+\s+(\d{3})\b/i', $header, $matches)) {
                return (int) $matches[1];
            }
        }
        return 0;
    }
}
