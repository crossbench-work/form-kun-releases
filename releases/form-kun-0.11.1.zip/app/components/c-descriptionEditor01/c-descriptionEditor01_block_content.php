<?php
/**
 * 説明文ブロック1件分の「種別＋本文」マークアップ（エディタ行・追加テンプレート共通）。
 *
 * @param string $namePrefix
 * @param int|null $index null のときはテンプレート（name は reindex 前は data-name のみ）
 * @param array<string, mixed> $block
 * @param bool $imageUploadEnabled 保存済みフォームのみ true（新規は false）
 */
if (!function_exists('admin_c_description_editor01_block_content')) {
    function admin_c_description_editor01_block_content(
        string $namePrefix,
        ?int $index,
        array $block,
        bool $imageUploadEnabled = true
    ): void {
        $blockId = trim((string) ($block['id'] ?? 'description-0'));
        $contentType = ((string) ($block['content_type'] ?? '')) === 'image' ? 'image' : 'text';
        $contentSectionId = $blockId . '-content-section';
        $contentTypeId = $blockId . '-content-type';
        $htmlInputId = $blockId . '-html';
        $imagePath = trim((string) ($block['image_path'] ?? ''));
        $nameSuffix = $index !== null ? '[' . $index . ']' : '';
        $nameBase = $namePrefix . $nameSuffix;

        ?>
        <div class="block is-field">
            <?php admin_m_input_set01_open(); ?>
            <div class="area is-title">
                <?php admin_m_bold_title01(e('説明文'), $contentSectionId); ?>
            </div>
            <div class="area is-field">
                <div class="area is-field">
                    <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title">
                        <?php admin_m_bold_title01(e('種類'), $contentTypeId); ?>
                    </div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php
                        $contentTypeAttrs = [
                            'id' => $contentTypeId,
                            'class' => 'fb-description-content-type',
                            'data-name' => 'content_type',
                            'data-target' => 'c-descriptionEditor__contentType',
                            'aria-label' => '説明文の種類',
                        ];
                        if ($index !== null) {
                            $contentTypeAttrs['name'] = $nameBase . '[content_type]';
                        }
                        admin_m_input01_select_open(admin_m_input01_attrs_with_bound_label($contentTypeId, $contentTypeAttrs));
                        admin_m_input01_option('text', 'テキスト', $contentType === 'text');
                        admin_m_input01_option('image', '画像', $contentType === 'image');
                        admin_m_input01_select_close();
                        ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                    <?php admin_m_input_set01_close(); ?>
                </div>
                <div class="block is-contents" data-description-content-panels>
                    <div data-description-body="text"<?= $contentType === 'image' ? ' hidden' : '' ?>>
                        <?php admin_c_html_input_editor01_open(['data-html-toggle-editor' => true]); ?>
                        <div class="block is-editor">
                            <?php admin_m_input01_open(); ?>
                            <?php
                            $htmlAttrs = [
                                'id' => $htmlInputId,
                                'rows' => 6,
                                'data-name' => 'html',
                                'data-target' => 'c-htmlInputEditor01__textarea',
                            ];
                            if ($index !== null) {
                                $htmlAttrs['name'] = $nameBase . '[html]';
                            }
                            admin_m_input01_textarea(
                                admin_m_input01_attrs_with_bound_label($htmlInputId, $htmlAttrs),
                                (string) ($block['html'] ?? '')
                            );
                            ?>
                            <?php admin_m_input01_close(); ?>
                        </div>
                        <div class="block is-toolbar">
                            <?php
                            $isHtmlAttrs = [
                                'data-name' => 'is_html',
                                'checked' => !empty($block['is_html']),
                            ];
                            if ($index !== null) {
                                $isHtmlAttrs['name'] = $nameBase . '[is_html]';
                            }
                            admin_c_html_input_editor01_toggle($isHtmlAttrs);
                            ?>
                        </div>
                        <?php admin_c_html_input_editor01_close(); ?>
                    </div>
                    <div data-description-body="image"<?= $contentType === 'text' ? ' hidden' : '' ?>>
                        <div data-module="c-descriptionImageUpload01" data-max-bytes="2097152"<?= !$imageUploadEnabled ? ' data-upload-disabled="1"' : '' ?>>
                            <?php
                            $previewSrc = $imagePath !== '' ? base_path($imagePath) : '';
                            ?>
                            <img class="img is-preview" data-target="c-descriptionEditor__imagePreview"
                                src="<?= $previewSrc !== '' ? e($previewSrc) : '' ?>"
                                alt=""<?= $previewSrc === '' ? ' hidden' : '' ?>>
                            <?php
                            $pathAttrs = [
                                'data-name' => 'image_path',
                                'value' => $imagePath,
                            ];
                            if ($index !== null) {
                                $pathAttrs['name'] = $nameBase . '[image_path]';
                            }
                            admin_m_input01_input(array_merge(['type' => 'hidden'], $pathAttrs));
                            ?>
                            <div data-module="c-updateUpload01">
                                <div class="c-updateUpload01__zone" data-target="c-updateUpload01__zone"
                                    data-accept="image/jpeg,image/png,image/webp,image/gif,.jpg,.jpeg,.png,.webp,.gif"
                                    tabindex="0" role="button" aria-label="画像ファイルを選択"<?= !$imageUploadEnabled ? ' aria-disabled="true"' : '' ?>>
                                    <p class="c-updateUpload01__hint">画像をドラッグ＆ドロップ、またはクリックして選択</p>
                                    <p class="c-updateUpload01__filename" data-module="m-text01" data-type="muted"
                                        data-target="c-updateUpload01__filename" hidden></p>
                                    <input type="file" accept="image/jpeg,image/png,image/webp,image/gif,.jpg,.jpeg,.png,.webp,.gif"
                                        data-target="c-descriptionEditor__imageFile" hidden>
                                </div>
                            </div>
                            <p class="text is-help" data-target="c-descriptionEditor__imageUploadHint"<?= $imageUploadEnabled ? ' hidden' : '' ?>>画像はフォーム保存後にアップロードできます。2MB、500px×500px 以下（JPEG / PNG / WebP / GIF）。</p>
                            <p class="text is-help" data-target="c-descriptionEditor__imageUploadLimits"<?= !$imageUploadEnabled ? ' hidden' : '' ?>>2MB、500px×500px 以下（JPEG / PNG / WebP / GIF）。</p>
                        </div>
                    </div>
                </div>
            </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <?php
    }
}
