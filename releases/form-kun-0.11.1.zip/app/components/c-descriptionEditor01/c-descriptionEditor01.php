<?php
/**
 * 説明文エディタ c-descriptionEditor01 のマークアップヘルパー。
 * 本体は `c-descriptionEditor01_editor.php`。
 */
require_once __DIR__ . '/c-descriptionEditor01_block_content.php';

if (!function_exists('admin_c_description_editor01')) {
    /**
     * @param string $namePrefix フォーム name の接頭辞（例: description_blocks）
     * @param array<int, array<string, mixed>> $blocks 説明文ブロック配列
     * @param string $positionMode data-position-mode 属性値（input | simple）
     * @param bool|null $imageUploadEnabled 省略時は保存済みフォーム（`$form['id']` あり）のみ true
     */
    function admin_c_description_editor01(string $namePrefix, array $blocks, string $positionMode, ?bool $imageUploadEnabled = null): void
    {
        if ($imageUploadEnabled === null) {
            global $form;
            $imageUploadEnabled = !empty($form['id'] ?? 0);
        }
        $descriptionImageUploadEnabled = $imageUploadEnabled;
        require __DIR__ . '/c-descriptionEditor01_editor.php';
    }
}
