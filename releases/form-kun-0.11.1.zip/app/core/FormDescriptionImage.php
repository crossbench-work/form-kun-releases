<?php

declare(strict_types=1);

namespace Core;

/**
 * フォーム説明文ブロック用の画像アップロード（サイトロゴと同上限）。
 */
final class FormDescriptionImage
{
    public const MAX_BYTES = 2 * 1024 * 1024;

    public const MAX_DIMENSION = 500;

    /** @var list<string> */
    private const ALLOWED_MIMES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

    public static function relativeDir(int $formId): string
    {
        return 'forms/' . $formId . '/description';
    }

    public static function publicPathPrefix(int $formId): string
    {
        return '/uploads/' . self::relativeDir($formId) . '/';
    }

    public static function isAllowedPublicPath(int $formId, string $path): bool
    {
        $path = trim($path);
        if ($path === '' || $path[0] !== '/') {
            return false;
        }
        $expected = self::publicPathPrefix($formId);
        if (!str_starts_with($path, $expected)) {
            return false;
        }
        $tail = substr($path, strlen($expected));
        return $tail !== '' && preg_match('/\A[a-zA-Z0-9][a-zA-Z0-9\-]*\.[a-z0-9]+\z/', $tail) === 1;
    }

    public static function normalizeBlockId(string $blockId): ?string
    {
        $blockId = trim($blockId);
        if ($blockId === '' || strlen($blockId) > 120) {
            return null;
        }
        if (preg_match('/\A[a-zA-Z0-9][a-zA-Z0-9\-]*\z/', $blockId) !== 1) {
            return null;
        }

        return $blockId;
    }

    /**
     * @return array{image_path:string,mime:string}
     */
    public static function storeFromUploadedFile(int $formId, string $blockId, string $tmpPath, ?string $previousPublicPath = null): array
    {
        if ($tmpPath === '' || !is_uploaded_file($tmpPath)) {
            throw new \InvalidArgumentException('アップロードファイルが不正です。');
        }

        $size = filesize($tmpPath);
        if ($size === false || $size > self::MAX_BYTES) {
            throw new \InvalidArgumentException('画像サイズは 2MB 以下にしてください。');
        }

        $info = @getimagesize($tmpPath);
        if ($info === false) {
            throw new \InvalidArgumentException('画像ファイルではありません。');
        }

        $mime = (string) ($info['mime'] ?? '');
        if (!in_array($mime, self::ALLOWED_MIMES, true)) {
            throw new \InvalidArgumentException('JPEG / PNG / WebP / GIF のみ対応しています。');
        }

        $w = (int) ($info[0] ?? 0);
        $h = (int) ($info[1] ?? 0);
        if ($w < 1 || $h < 1 || $w > self::MAX_DIMENSION || $h > self::MAX_DIMENSION) {
            throw new \InvalidArgumentException('画像は 500px x 500px 以下にしてください。');
        }

        $ext = match ($mime) {
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
            default => null,
        };
        if ($ext === null) {
            throw new \InvalidArgumentException('JPEG / PNG / WebP / GIF のみ対応しています。');
        }

        $dir = UPLOADS_DIR . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, self::relativeDir($formId));
        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new \RuntimeException('保存先を作成できませんでした。');
        }

        $safeBlockId = self::normalizeBlockId($blockId);
        if ($safeBlockId === null) {
            throw new \InvalidArgumentException('ブロック ID が不正です。');
        }

        $filename = $safeBlockId . '.' . $ext;
        $abs = $dir . DIRECTORY_SEPARATOR . $filename;
        $publicPath = self::publicPathPrefix($formId) . $filename;

        if ($previousPublicPath !== null && $previousPublicPath !== '' && self::isAllowedPublicPath($formId, $previousPublicPath)) {
            self::deletePublicPath($formId, $previousPublicPath);
        }

        $binary = self::readValidatedBinary($tmpPath, $mime);
        if (@file_put_contents($abs, $binary) === false) {
            throw new \RuntimeException('画像を保存できませんでした。');
        }

        return ['image_path' => $publicPath, 'mime' => $mime];
    }

    public static function deletePublicPath(int $formId, string $publicPath): void
    {
        if (!self::isAllowedPublicPath($formId, $publicPath)) {
            return;
        }
        $rel = 'forms/' . $formId . '/description/' . basename($publicPath);
        $abs = UPLOADS_DIR . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
        if (is_file($abs)) {
            @unlink($abs);
        }
    }

    private static function readValidatedBinary(string $tmpPath, string $mime): string
    {
        if (extension_loaded('gd')) {
            $img = null;
            if ($mime === 'image/jpeg' && function_exists('imagecreatefromjpeg')) {
                $img = @imagecreatefromjpeg($tmpPath);
            } elseif ($mime === 'image/png' && function_exists('imagecreatefrompng')) {
                $img = @imagecreatefrompng($tmpPath);
            } elseif ($mime === 'image/webp' && function_exists('imagecreatefromwebp')) {
                $img = @imagecreatefromwebp($tmpPath);
            } elseif ($mime === 'image/gif' && function_exists('imagecreatefromgif')) {
                $img = @imagecreatefromgif($tmpPath);
            }

            if ($img instanceof \GdImage || is_resource($img)) {
                ob_start();
                $ok = false;
                if ($mime === 'image/jpeg') {
                    $ok = imagejpeg($img, null, 82);
                } elseif ($mime === 'image/png') {
                    $ok = imagepng($img, null, 6);
                } elseif ($mime === 'image/webp') {
                    $ok = imagewebp($img, null, 82);
                } elseif ($mime === 'image/gif') {
                    $ok = imagegif($img);
                }
                $buf = ob_get_clean();
                if (is_resource($img) || $img instanceof \GdImage) {
                    imagedestroy($img);
                }
                if ($ok && $buf !== '') {
                    return $buf;
                }
            }
        }

        $raw = file_get_contents($tmpPath);
        if ($raw === false) {
            throw new \RuntimeException('画像を読み込めませんでした。');
        }

        return $raw;
    }
}
