<?php
/** フォーム編集:「入力画面」タブパネル
 * _content_*.php … c-formBlock01 直下 .area.is-field の内側。説明文エディタはコンポーネント呼び出しのまま本ファイルに残す。
 */
$inputPages = \Models\FormInputPage::normalizePages($inputPages ?? [], $form ?? []);
$fieldTemplates = is_array($fieldTemplates ?? null) ? $fieldTemplates : [];
$descriptionImageUploadEnabled = ((int) ($form['id'] ?? 0)) > 0;
$descriptionImageFormId = (int) ($form['id'] ?? 0);
$renderInputPagePanel = static function (array $inputPage, $pageIndex, array $fields, array $fieldGroups, array $fieldTemplates = [], bool $hidden = false) use ($descriptionImageUploadEnabled, $descriptionImageFormId): void {
    $pageKey = (string) ($inputPage['page_key'] ?? \Models\FormInputPage::DEFAULT_KEY);
    $pageFields = \Models\FormField::forInputPage($fields, $pageKey);
    $descriptionBlocks = $inputPage['description_blocks'] ?? [];
    if (!is_array($descriptionBlocks)) {
        $descriptionBlocks = [];
    }
    ?>
    <div data-target="c-formEditTabs01__contents" data-tab-panel="screen-input-<?= e($pageKey) ?>" class="area is-contents"
        role="tabpanel" aria-label="<?= e($inputPage['title'] ?? '入力画面') ?>"<?= $hidden ? ' hidden' : '' ?>>
        <?php admin_c_form_block01_open(['data-module' => 'm-formBuilder01', 'data-input-page-key' => $pageKey]); ?>
            <div class="area is-title">
                <?php admin_m_large_title01('入力画面'); ?>
            </div>
            <input type="hidden" name="input_pages[<?= e((string) $pageIndex) ?>][page_key]" value="<?= e($pageKey) ?>" data-input-page-name="page_key">
            <?php admin_c_description_editor01('input_pages[' . $pageIndex . '][description_blocks]', $descriptionBlocks, 'input', $descriptionImageUploadEnabled, $descriptionImageFormId, 'top'); ?>
            <div class="block">
                <div class="area is-title">
                    <?php admin_m_left_border_title01(e('項目設定')); ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/../form/_content_items.php'; ?>
                </div>
            </div>
            <div class="block">
                <div class="area is-title">
                    <?php admin_m_left_border_title01(e('ボタン')); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_input_set01_open(); ?>
                        <div class="area is-title">
                            <?php admin_m_bold_title01(e('次へボタンテキスト')); ?>
                        </div>
                        <div class="area is-field">
                            <?php admin_m_input01_open(); ?>
                                <?php admin_m_input01_input([
                                    'type' => 'text',
                                    'name' => 'input_pages[' . $pageIndex . '][button_text]',
                                    'value' => (string) ($inputPage['button_text'] ?? ''),
                                    'data-input-page-name' => 'button_text',
                                ]); ?>
                            <?php admin_m_input01_close(); ?>
                        </div>
                    <?php admin_m_input_set01_close(); ?>
                    <?php admin_m_input_set01_open(); ?>
                        <div class="area is-title">
                            <?php admin_m_bold_title01(e('戻るボタンテキスト')); ?>
                        </div>
                        <div class="area is-field">
                            <?php admin_m_input01_open(); ?>
                                <?php admin_m_input01_input([
                                    'type' => 'text',
                                    'name' => 'input_pages[' . $pageIndex . '][back_button_text]',
                                    'value' => (string) ($inputPage['back_button_text'] ?? '戻る'),
                                    'data-input-page-name' => 'back_button_text',
                                ]); ?>
                            <?php admin_m_input01_close(); ?>
                        </div>
                    <?php admin_m_input_set01_close(); ?>
                </div>
            </div>
            <?php admin_c_description_editor01('input_pages[' . $pageIndex . '][description_blocks]', $descriptionBlocks, 'input', $descriptionImageUploadEnabled, $descriptionImageFormId, 'bottom'); ?>
        <?php admin_c_form_block01_close(); ?>
    </div>
    <?php
};
?>
<?php foreach ($inputPages as $pageIndex => $inputPage): ?>
    <?php $renderInputPagePanel($inputPage, (int) $pageIndex, $fields, $fieldGroups ?? [], $fieldTemplates, $pageIndex !== 0); ?>
<?php endforeach; ?>
<template data-target="inputPagePanelTemplate">
    <?php $renderInputPagePanel([
        'page_key' => '__PAGE_KEY__',
        'title' => '__PAGE_TITLE__',
        'show_title' => 1,
        'description_blocks' => [form_description_title_block('__PAGE_TITLE__', true, 'description-title-__PAGE_KEY__')],
        'button_text' => '次へ',
        'back_button_text' => '戻る',
    ], '__INDEX__', [], [], $fieldTemplates, true); ?>
</template>
