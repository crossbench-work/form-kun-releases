<?php
namespace Core;

use DateTimeImmutable;
use DateTimeInterface;
use DateTimeZone;

class FormPublishSchedule
{
    public static function isOpen(array $form, ?DateTimeInterface $now = null): bool
    {
        if (empty($form['publish_schedule_enabled'])) {
            return true;
        }

        $now = self::normalizeNow($now);
        $publishRules = self::activeRules(decode_form_publish_rules($form['publish_rules'] ?? null));
        $unpublishRules = self::activeRules(decode_form_unpublish_rules($form['unpublish_rules'] ?? null));

        if ($publishRules === [] && $unpublishRules === []) {
            return true;
        }

        if ($publishRules === []) {
            $open = true;
        } else {
            $open = self::anyRuleMatches($publishRules, $now);
        }

        if (!$open) {
            return false;
        }

        if ($unpublishRules !== [] && self::anyRuleMatches($unpublishRules, $now)) {
            return false;
        }

        return true;
    }

    /**
     * @param array<string, mixed> $rule
     */
    public static function ruleMatches(array $rule, ?DateTimeInterface $now = null): bool
    {
        $now = self::normalizeNow($now);
        $checks = [];
        if (self::hasPeriod($rule)) {
            $checks[] = self::matchesPeriod($rule, $now);
        }
        if (self::hasWeekdays($rule)) {
            $checks[] = self::matchesWeekdays($rule, $now);
        }
        if (self::hasTimeBand($rule)) {
            $checks[] = self::matchesTimeBand($rule, $now);
        }
        if (self::hasHoliday($rule)) {
            $checks[] = self::matchesHoliday($rule, $now);
        }
        if ($checks === []) {
            return false;
        }

        return !in_array(false, $checks, true);
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     */
    private static function activeRules(array $rules): array
    {
        return array_values(array_filter(
            $rules,
            static fn(array $rule): bool => !empty($rule['visible']) && self::hasConfiguredDimension($rule)
        ));
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     */
    private static function anyRuleMatches(array $rules, DateTimeInterface $now): bool
    {
        foreach ($rules as $rule) {
            if (self::ruleMatches($rule, $now)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param array<string, mixed> $rule
     */
    public static function hasConfiguredDimension(array $rule): bool
    {
        return self::hasPeriod($rule) || self::hasWeekdays($rule) || self::hasTimeBand($rule) || self::hasHoliday($rule);
    }

    /**
     * @param array<string, mixed> $rule
     */
    public static function hasPeriod(array $rule): bool
    {
        return trim((string) ($rule['start_at'] ?? '')) !== ''
            || trim((string) ($rule['end_at'] ?? '')) !== '';
    }

    /**
     * @param array<string, mixed> $rule
     */
    public static function hasWeekdays(array $rule): bool
    {
        $mask = $rule['weekdays'] ?? null;
        return $mask !== null && (int) $mask > 0;
    }

    /**
     * @param array<string, mixed> $rule
     */
    public static function hasTimeBand(array $rule): bool
    {
        return trim((string) ($rule['daily_start_time'] ?? '')) !== ''
            && trim((string) ($rule['daily_end_time'] ?? '')) !== '';
    }

    /**
     * @param array<string, mixed> $rule
     */
    public static function hasHoliday(array $rule): bool
    {
        return !empty($rule['holiday']);
    }

    /**
     * @param array<string, mixed> $rule
     */
    private static function matchesPeriod(array $rule, DateTimeInterface $now): bool
    {
        $startRaw = trim((string) ($rule['start_at'] ?? ''));
        $endRaw = trim((string) ($rule['end_at'] ?? ''));
        if ($startRaw !== '') {
            $start = form_publish_period_boundary($startRaw, false);
            if ($start && $now < $start) {
                return false;
            }
        }
        if ($endRaw !== '') {
            $end = form_publish_period_boundary($endRaw, true);
            if ($end && $now > $end) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param array<string, mixed> $rule
     */
    private static function matchesWeekdays(array $rule, DateTimeInterface $now): bool
    {
        $mask = (int) ($rule['weekdays'] ?? 0);
        $weekday = (int) $now->format('w');
        return form_publish_weekdays_has_day($mask, $weekday);
    }

    /**
     * @param array<string, mixed> $rule
     */
    private static function matchesTimeBand(array $rule, DateTimeInterface $now): bool
    {
        $start = self::parseTime((string) $rule['daily_start_time']);
        $end = self::parseTime((string) $rule['daily_end_time']);
        if ($start === null || $end === null) {
            return false;
        }

        $current = (int) $now->format('H') * 3600 + (int) $now->format('i') * 60 + (int) $now->format('s');
        $startSec = $start[0] * 3600 + $start[1] * 60 + $start[2];
        $endSec = $end[0] * 3600 + $end[1] * 60 + $end[2];

        if ($startSec <= $endSec) {
            return $current >= $startSec && $current <= $endSec;
        }

        return $current >= $startSec || $current <= $endSec;
    }

    /**
     * @param array<string, mixed> $rule
     */
    private static function matchesHoliday(array $rule, DateTimeInterface $now): bool
    {
        return japanese_holidays_is_holiday($now->format('Y-m-d'));
    }

    private static function normalizeNow(?DateTimeInterface $now): DateTimeInterface
    {
        if ($now instanceof DateTimeInterface) {
            return $now;
        }

        $tz = new DateTimeZone((string) effective_site_timezone());
        return new DateTimeImmutable('now', $tz);
    }

    /**
     * @return array{0:int,1:int,2:int}|null
     */
    private static function parseTime(string $raw): ?array
    {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }
        if (preg_match('/\A(\d{2}):(\d{2})(?::(\d{2}))?\z/', $raw, $m) !== 1) {
            return null;
        }

        return [(int) $m[1], (int) $m[2], isset($m[3]) ? (int) $m[3] : 0];
    }
}
