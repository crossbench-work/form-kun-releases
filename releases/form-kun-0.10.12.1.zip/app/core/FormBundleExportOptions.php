<?php
namespace Core;

/**
 * フォームバンドル ZIP エクスポート時に含める範囲。
 */
final class FormBundleExportOptions
{
    public function __construct(
        public readonly bool $includeSubmissions = true,
        public readonly bool $includeAttachmentFiles = true,
        public readonly bool $includeSmtp = true,
        public readonly bool $includeLine = true,
        public readonly bool $includeEmbed = false,
        public readonly bool $includeCustomAssets = false,
        public readonly bool $includePublishSchedule = true,
        public readonly bool $includeRetention = false,
    ) {
    }

    public static function defaults(): self
    {
        return new self();
    }

    /** @param array<string, mixed> $input */
    public static function fromRequest(array $input): self
    {
        $includeSubmissions = self::checkbox($input, 'include_submissions', true);
        $includeAttachmentFiles = self::checkbox($input, 'include_attachment_files', true);
        if (!$includeSubmissions) {
            $includeAttachmentFiles = false;
        }

        return new self(
            includeSubmissions: $includeSubmissions,
            includeAttachmentFiles: $includeAttachmentFiles,
            includeSmtp: self::checkbox($input, 'include_smtp', true),
            includeLine: self::checkbox($input, 'include_line', true),
            includeEmbed: self::checkbox($input, 'include_embed', false),
            includeCustomAssets: self::checkbox($input, 'include_custom_assets', false),
            includePublishSchedule: self::checkbox($input, 'include_publish_schedule', true),
            includeRetention: self::checkbox($input, 'include_retention', false),
        );
    }

    /** @return array<string, bool> */
    public function toMetaArray(): array
    {
        return [
            'include_submissions' => $this->includeSubmissions,
            'include_attachment_files' => $this->includeAttachmentFiles,
            'include_smtp' => $this->includeSmtp,
            'include_line' => $this->includeLine,
            'include_embed' => $this->includeEmbed,
            'include_custom_assets' => $this->includeCustomAssets,
            'include_publish_schedule' => $this->includePublishSchedule,
            'include_retention' => $this->includeRetention,
        ];
    }

    /** @return list<string> */
    public static function smtpFormKeys(): array
    {
        return [
            'admin_emails',
            'mail_subject_admin',
            'mail_template_admin',
            'mail_transport',
            'mail_from_email',
            'mail_from_name',
            'mail_smtp_host',
            'mail_smtp_port',
            'mail_smtp_secure',
            'mail_smtp_username',
            'mail_smtp_timeout',
            'mail_smtp_ehlo_host',
            'mail_smtp_verify_peer',
            'mail_smtp_verify_peer_name',
            'mail_smtp_allow_self_signed',
            'reply_enabled',
            'reply_from_field_key',
            'reply_subject',
            'reply_template',
        ];
    }

    /** @return list<string> */
    public static function lineFormKeys(): array
    {
        return [
            'line_notify_enabled',
            'line_push_to_id',
            'line_message_template',
            'line_notify_include_images',
        ];
    }

    /** @return list<string> */
    public static function customAssetFormKeys(): array
    {
        return [
            'meta_html',
            'custom_css',
            'custom_js',
        ];
    }

    /** @return list<string> */
    public static function publishScheduleFormKeys(): array
    {
        return [
            'publish_schedule_enabled',
            'publish_rules',
            'unpublish_rules',
            'closed_page_title',
            'show_closed_page_title',
            'closed_message',
            'closed_button_text',
            'closed_button_url',
        ];
    }

    /** @return list<string> */
    public static function retentionFormKeys(): array
    {
        return [
            'submission_retention_days',
            'submission_retention_action',
            'submission_retention_enabled',
            'submission_storage_mode',
            'mail_attachment_max_bytes',
        ];
    }

    /** @param array<string, mixed> $input */
    private static function checkbox(array $input, string $name, bool $default): bool
    {
        if (!array_key_exists($name, $input)) {
            return $default;
        }

        return !empty($input[$name]);
    }
}
