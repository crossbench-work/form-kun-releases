<?php
namespace Core;

use Core\Database;
use Models\Form;
use Models\LineWebhookTarget;

/**
 * LINE アカウント連携の「サイト共通」と「フォーム個別」の切り替え。
 */
final class LineAccountScope
{
    private const SITE_FORM_ID = 0;

    private bool $isSite;

    /** サイト: AppSetting、フォーム: forms 行 */
    private function __construct(private ?array $formRow)
    {
        $this->isSite = $formRow === null;
    }

    public static function site(): self
    {
        return new self(null);
    }

    /**
     * @param array<string, mixed> $formRow forms 行（id, public_uuid, line_*）
     */
    public static function form(array $formRow): self
    {
        return new self($formRow);
    }

    /**
     * 通知に使う連携（line_custom_enabled がオンのときはフォームのみ）。
     *
     * @param array<string, mixed> $form forms 行
     */
    public static function forNotification(array $form): self
    {
        if (!empty($form['line_custom_enabled'])) {
            return self::form($form);
        }

        return self::site();
    }

    public function isSite(): bool
    {
        return $this->isSite;
    }

    public function formId(): int
    {
        if ($this->isSite) {
            return self::SITE_FORM_ID;
        }

        return (int) ($this->formRow['id'] ?? 0);
    }

    public function channelSecret(): string
    {
        if ($this->isSite) {
            return LineSiteConfig::channelSecret();
        }

        return trim((string) ($this->formRow['line_channel_secret'] ?? ''));
    }

    public function channelAccessToken(): string
    {
        if ($this->isSite) {
            return LineSiteConfig::channelAccessToken();
        }

        return trim((string) ($this->formRow['line_channel_access_token'] ?? ''));
    }

    public function pushToId(): string
    {
        if ($this->isSite) {
            return LineSiteConfig::pushToId();
        }

        return trim((string) ($this->formRow['line_push_to_id'] ?? ''));
    }

    public function setChannelSecret(string $value): void
    {
        $value = trim($value);
        if ($this->isSite) {
            LineSiteConfig::setChannelSecret($value);

            return;
        }
        $id = $this->formId();
        if ($id <= 0) {
            return;
        }
        Database::execute(
            'UPDATE forms SET line_channel_secret = ?, updated_at = ? WHERE id = ?',
            [$value !== '' ? $value : null, date('Y-m-d H:i:s'), $id]
        );
    }

    public function setChannelAccessToken(string $value): void
    {
        $value = trim($value);
        if ($this->isSite) {
            LineSiteConfig::setChannelAccessToken($value);

            return;
        }
        $id = $this->formId();
        if ($id <= 0) {
            return;
        }
        Database::execute(
            'UPDATE forms SET line_channel_access_token = ?, updated_at = ? WHERE id = ?',
            [$value !== '' ? $value : null, date('Y-m-d H:i:s'), $id]
        );
    }

    public function setPushToId(string $value): void
    {
        $value = trim($value);
        if ($this->isSite) {
            LineSiteConfig::setPushToId($value);

            return;
        }
        $id = $this->formId();
        if ($id <= 0) {
            return;
        }
        Database::execute(
            'UPDATE forms SET line_push_to_id = ?, updated_at = ? WHERE id = ?',
            [$value !== '' ? $value : null, date('Y-m-d H:i:s'), $id]
        );
    }

    public function webhookUrl(): string
    {
        if ($this->isSite) {
            return LineSiteConfig::webhookUrl();
        }
        $uuid = trim((string) ($this->formRow['public_uuid'] ?? ''));
        if ($uuid === '') {
            return url('/api/line/webhook');
        }

        return url('/api/line/webhook/' . $uuid);
    }

    /**
     * @return array<string, bool>
     */
    public function lineSetupChecklistStateForDisplay(): array
    {
        if ($this->isSite) {
            return LineSiteConfig::lineSetupChecklistStateForDisplay();
        }
        $fid = $this->formId();
        $form = $fid > 0 ? (Form::find($fid) ?? $this->formRow) : $this->formRow;
        $display = $form;
        $display['line_channel_secret_configured'] = trim((string) ($form['line_channel_secret'] ?? '')) !== '' ? 1 : 0;
        $display['line_channel_access_token_configured'] = trim((string) ($form['line_channel_access_token'] ?? '')) !== '' ? 1 : 0;
        $display['line_push_to_id_configured'] = trim((string) ($form['line_push_to_id'] ?? '')) !== '' ? 1 : 0;

        return Form::lineSetupChecklistStateForDisplay($display);
    }

    public function isSetupComplete(): bool
    {
        $state = $this->lineSetupChecklistStateForDisplay();

        return Form::lineSetupChecklistIsComplete($state);
    }

    public function updateLineSetupChecklistItem(string $itemKey, bool $checked): void
    {
        if ($this->isSite) {
            LineSiteConfig::updateLineSetupChecklistItem($itemKey, $checked);

            return;
        }
        Form::updateLineSetupChecklistItem($this->formId(), $itemKey, $checked);
    }

    /**
     * @param list<string> $types
     */
    public function syncLineTalkSendSetupChecklistForTypes(array $types): void
    {
        if ($this->isSite) {
            LineSiteConfig::syncLineTalkSendSetupChecklistForTypes($types);

            return;
        }
        Form::syncLineTalkSendSetupChecklistForFormTypes($this->formId(), $types);
    }

    /**
     * @param 'line-talk-user'|'line-talk-group' $panelId
     */
    public function syncLineTalkSendSetupChecklistForPanel(string $panelId): bool
    {
        if ($this->isSite) {
            return LineSiteConfig::syncLineTalkSendSetupChecklistForPanel($panelId);
        }

        return Form::syncLineTalkSendSetupChecklistForFormPanel($this->formId(), $panelId);
    }

    public function resetAccountLink(): void
    {
        if ($this->isSite) {
            LineSiteConfig::resetAccountLink();

            return;
        }
        $id = $this->formId();
        if ($id <= 0) {
            return;
        }
        Database::transaction(function () use ($id): void {
            LineWebhookTarget::deleteAllForForm($id);
            Database::execute(
                'UPDATE forms SET line_channel_secret = NULL, line_channel_access_token = NULL, line_push_to_id = NULL, line_setup_checklist = NULL, updated_at = ? WHERE id = ?',
                [date('Y-m-d H:i:s'), $id]
            );
        });
    }

    /**
     * @return array<string, string>
     */
    public function adminUrls(): array
    {
        if ($this->isSite) {
            $base = '/admin/settings/line';

            return [
                'channel_secret_save' => base_path($base . '/channel-secret'),
                'channel_secret_delete' => base_path($base . '/channel-secret/delete'),
                'channel_access_token_save' => base_path($base . '/channel-access-token'),
                'channel_access_token_delete' => base_path($base . '/channel-access-token/delete'),
                'push_to_id_save' => base_path($base . '/push-to-id'),
                'setup_checklist' => base_path($base . '/setup-checklist'),
                'talk_setup_checklist' => base_path($base . '/talk-setup-checklist'),
                'webhook_target_delete' => base_path($base . '/webhook-targets/delete'),
                'test_line' => base_path($base . '/test-line'),
                'account_unlink' => base_path($base . '/account-unlink'),
            ];
        }
        $fid = $this->formId();
        $prefix = '/admin/forms/' . $fid . '/line';

        return [
            'channel_secret_save' => base_path($prefix . '/channel-secret'),
            'channel_secret_delete' => base_path($prefix . '/channel-secret/delete'),
            'channel_access_token_save' => base_path($prefix . '/channel-access-token'),
            'channel_access_token_delete' => base_path($prefix . '/channel-access-token/delete'),
            'push_to_id_save' => base_path($prefix . '/push-to-id'),
            'setup_checklist' => base_path($prefix . '/setup-checklist'),
            'talk_setup_checklist' => base_path($prefix . '/talk-setup-checklist'),
            'webhook_target_delete' => base_path($prefix . '/webhook-targets/delete'),
            'test_line' => base_path($prefix . '/test-line'),
            'account_unlink' => base_path($prefix . '/account-unlink'),
        ];
    }

    /**
     * @return array<string, mixed> ビュー用（credential の *_configured など）
     */
    public function viewContext(): array
    {
        if ($this->isSite) {
            return LineSiteConfig::viewContext();
        }
        $form = $this->formId() > 0 ? (Form::find($this->formId()) ?? $this->formRow) : $this->formRow;

        return [
            'line_channel_secret_configured' => trim((string) ($form['line_channel_secret'] ?? '')) !== '' ? 1 : 0,
            'line_channel_access_token_configured' => trim((string) ($form['line_channel_access_token'] ?? '')) !== '' ? 1 : 0,
            'line_push_to_id' => trim((string) ($form['line_push_to_id'] ?? '')),
            'line_push_to_id_configured' => trim((string) ($form['line_push_to_id'] ?? '')) !== '' ? 1 : 0,
        ];
    }
}
