<?php
/**
 * 管理画面の左固定ヘッダー c-adminHeader01。
 * スタイルは同ディレクトリの _c-adminHeader01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_admin_header01')) {
    function admin_c_admin_header01(): void
    {
        $nav = admin_relative_path();
        $navForms = str_starts_with($nav, '/forms') || str_starts_with($nav, '/files');
        $navUsers = str_starts_with($nav, '/users');
        $navSettings = str_starts_with($nav, '/settings');
        $navAccount = str_starts_with($nav, '/account');
        $user = \Core\Auth::user();
        $isViewer = \Core\Auth::isViewer();
        ?>
        <header data-module="c-adminHeader01">
            <div class="wrapper">
                <div class="block is-contents">
                    <div class="area is-topBar">
                        <div class="area is-logo">
                            <a href="<?= e(base_path($isViewer ? '/admin/forms' : '/admin/')) ?>">
                                <img class="img" src="<?= e(effective_site_logo_src()) ?>" alt="<?= e(effective_site_admin_name()) ?>">
                            </a>
                        </div>
                        <button type="button"
                                class="c-adminHeader01__menuToggle"
                                data-target="c-adminHeader01__menuToggle"
                                aria-controls="c-adminHeader01-nav"
                                aria-expanded="false"
                                aria-label="メニューを開く">
                            <span class="c-adminHeader01__menuToggleBar" aria-hidden="true"></span>
                            <span class="c-adminHeader01__menuToggleBar" aria-hidden="true"></span>
                            <span class="c-adminHeader01__menuToggleBar" aria-hidden="true"></span>
                        </button>
                    </div>
                    <div class="area is-menuPanel" id="c-adminHeader01-nav" data-target="c-adminHeader01__menuPanel">
                        <nav class="area is-nav">
                            <a href="<?= e(base_path('/admin/forms')) ?>" class="<?= $navForms ? 'is-active' : '' ?>"<?= $navForms ? ' aria-current="page"' : '' ?>>フォーム</a>
                            <?php if (\Core\Auth::role() === 'admin'): ?>
                                <a href="<?= e(base_path('/admin/users')) ?>" class="<?= $navUsers ? 'is-active' : '' ?>"<?= $navUsers ? ' aria-current="page"' : '' ?>>ユーザー</a>
                            <?php endif; ?>
                            <?php if (!$isViewer): ?>
                            <a href="<?= e(base_path('/admin/settings')) ?>" class="<?= $navSettings ? 'is-active' : '' ?>"<?= $navSettings ? ' aria-current="page"' : '' ?>>設定</a>
                            <?php endif; ?>
                        </nav>
                        <div class="area is-user">
                            <?php if ($user): ?>
                                <a class="name<?= $navAccount ? ' is-active' : '' ?>" href="<?= e(base_path('/admin/account')) ?>"<?= $navAccount ? ' aria-current="page"' : '' ?>><?= e($user['username']) ?></a>
                                <form method="post" action="<?= e(base_path('/admin/logout')) ?>">
                                    <?= \Core\Csrf::field() ?>
                                    <?php admin_m_btn01_button_wrap('ログアウト', ['type' => 'submit', 'class' => 'is-danger is-sm']); ?>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <?php
    }
}
