<?php
/**
 * 管理画面の手動 ZIP アップロード c-updateUpload01。
 */
if (!function_exists('admin_c_update_upload01_zone')) {
    function admin_c_update_upload01_zone(string $inputName = 'update_zip', string $accept = '.zip,application/zip', string $hint = 'ZIP をドラッグ＆ドロップ、またはクリックして選択'): void
    {
        echo '<div class="c-updateUpload01__zone" data-target="c-updateUpload01__zone" data-accept="' . e($accept) . '" tabindex="0" role="button" aria-label="ファイルを選択">';
        echo '<p class="c-updateUpload01__hint">' . e($hint) . '</p>';
        echo '<p class="c-updateUpload01__filename" data-module="m-text01" data-type="muted" data-target="c-updateUpload01__filename" hidden></p>';
        echo '<input type="file" name="' . e($inputName) . '" accept="' . e($accept) . '" data-target="c-updateUpload01__input" hidden required>';
        echo '</div>';
    }
}
