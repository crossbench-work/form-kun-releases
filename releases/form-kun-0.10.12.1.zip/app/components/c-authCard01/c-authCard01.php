<?php
/**
 * 認証画面カード c-authCard01 のマークアップヘルパー。
 * スタイルは同ディレクトリの _c-authCard01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_c_auth_card01_open')) {
    function admin_c_auth_card01_open(): void
    {
        echo '<div data-module="c-authCard01"><div class="wrapper">';
    }

    function admin_c_auth_card01_title(string $title): void
    {
        echo '<div class="block is-title"><h1 class="title"><img class="img" src="' . e(effective_site_logo_src()) . '" alt="' . e($title) . '"></h1></div>';
    }

    function admin_c_auth_card01_close(): void
    {
        echo '</div></div>';
    }
}
