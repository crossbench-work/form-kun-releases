<?php
/** @var array<string, mixed> $lineSiteForm */
/** @var array<string, list<string>> $lineCredentialErrors */

$lineScope = \Core\LineAccountScope::site();
require APP_DIR . '/views/admin/line/_account_link_linked_compact.php';
