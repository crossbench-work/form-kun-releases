<?php admin_c_form_block01_open(); ?>
            <div class="block is-title">
                <?php admin_m_large_title01('バックアップ'); ?>
            </div>
            <div class="block is-settingsBasic">
                <?php
                $exportAction = admin_settings_button_html01('復元データの作成', [
                    'type' => 'button',
                    'class' => 'is-primary',
                    'data-target' => 'settings-backup-export-open',
                ]);
                admin_settings_left_border_value01(
                    '復元データの作成',
                    'settings_backup_export',
                    'フォーム・送信・添付ファイル・ユーザー・サイト設定をすべて含む ZIP を作成します。',
                    '',
                    $exportAction
                );
                $restoreAction = admin_settings_button_html01('サイトを復元する', [
                    'type' => 'button',
                    'class' => 'is-primary',
                    'data-target' => 'settings-backup-restore-open',
                ]);
                admin_settings_left_border_value01(
                    'サイトの復元',
                    'settings_backup_restore',
                    '現在のデータ（フォーム・送信・添付ファイル・ユーザー・サイト設定）はすべてバックアップの内容に置き換わります。',
                    '',
                    $restoreAction
                );
                ?>
            </div>
<?php admin_c_form_block01_close(); ?>
