<?php
require_once APP_COMPONENTS_DIR . '/m-table01/m-table01.php';
require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php';
require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php';
?>
<div data-module="m-toolbar01">
    <h1 class="title" style="margin:0;">ダッシュボード</h1>
    <div class="spacer"></div>
    <?php if (!empty($storage_resource) && is_array($storage_resource)): ?>
        <?php admin_c_progress01_resource_summary($storage_resource); ?>
    <?php endif; ?>
</div>

<?php if (!empty($storage_exceeded)): ?>
    <?php admin_m_alert01('使用リソースの上限に達しています。公開フォームは利用できません。設定から上限を変更するか、不要なデータを削除してください。', 'danger'); ?>
<?php elseif (!empty($storage_warning)): ?>
    <?php admin_m_alert01('使用リソースが上限に近づいています（' . number_format((float) $storage_percent, 1) . '%）。', 'warning'); ?>
<?php endif; ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_large_title01('フォーム一覧'); ?>
                            </div>
                            <div class="area is-field">
                                <?php if (empty($forms)): ?>
                                    <p data-module="m-text01" data-type="muted">まだフォームがありません。<?php if (empty($at_form_limit)): ?><?php endif; ?></p>
                                <?php else: ?>
                                    <?php admin_m_table01_open('is-formList'); ?>
                                    <?php admin_m_table01_thead([
                                        ['label' => 'タイトル'],
                                        ['label' => 'URL'],
                                        ['label' => '状態', 'class' => 'is-workflow-status'],
                                        ['label' => '受信', 'class' => 'num is-reception-count'],
                                        ['label' => '更新日時', 'class' => 'is-updated-at'],
                                        ['label' => '', 'class' => 'is-actions'],
                                    ]); ?>
                                        <tbody>
                                        <?php foreach ($forms as $r): ?>
                                            <tr>
                                                <td class="is-formList-title">
                                                    <a href="<?= e(base_path('/admin/forms/' . $r['id'] . '/submissions')) ?>">
                                                        <strong><?= e($r['title']) ?></strong>
                                                    </a>
                                                </td>
                                                <td class="is-url is-formList-url">
                                                    <?php if (in_array((string) $r['status'], ['hidden', 'draft'], true)): ?>
                                                        <code><?= e($r['slug']) ?></code>
                                                    <?php else: ?>
                                                        <a href="<?= e(base_path('/f/' . $r['slug'])) ?>" target="_blank" rel="noopener noreferrer">
                                                            <code><?= e($r['slug']) ?></code>
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                                <td class="is-workflow-status" data-sp-label="状態"><?php admin_m_badge01(\Models\Form::statusLabel((string) $r['status']), (string) $r['status']); ?></td>
                                                <td class="num is-reception-count" data-sp-label="受信">
                                                    <?= number_format((int) ($r['cnt'] ?? 0)) ?>
                                                </td>
                                                <td class="is-updated-at" data-sp-label="更新日時"><?= e($r['updated_at']) ?></td>
                                                <td class="is-actions">
                                                    <details class="c-tableActionMenu01">
                                                        <summary class="c-tableActionMenu01__toggle" aria-label="操作">
                                                            <span aria-hidden="true">⋯</span>
                                                        </summary>
                                                        <div class="c-tableActionMenu01__menu" role="menu" aria-label="操作">
                                                            <a role="menuitem" href="<?= e(base_path('/admin/forms/' . $r['id'] . '/edit')) ?>">編集</a>
                                                            <a role="menuitem" href="<?= e(base_path('/admin/forms/' . $r['id'] . '/submissions')) ?>">送信履歴</a>
                                                            <form method="post"
                                                                action="<?= e(base_path('/admin/forms/' . $r['id'] . '/delete')) ?>"
                                                                onsubmit="return confirm('本当に削除しますか？関連する送信履歴も削除されます。');">
                                                                <?= \Core\Csrf::field() ?>
                                                                <?php admin_m_delete_btn01('admin-form-delete-' . $r['id'], '削除', '削除', 'submit', '削除'); ?>
                                                            </form>
                                                        </div>
                                                    </details>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    <?php admin_m_table01_close(); ?>
                                <?php endif; ?>
                            </div>
<?php admin_c_form_block01_close(); ?>

<?php admin_c_form_block01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_large_title01('最新の受信履歴'); ?>
                            </div>
                            <div class="area is-field">
                                <?php if (empty($recent)): ?>
                                    <p data-module="m-text01" data-type="muted">まだ送信はありません。</p>
                                <?php else: ?>
                                    <?php admin_m_table01_open('is-recentSubmissionList'); ?>
                                    <?php admin_m_table01_thead([
                                        ['label' => '受信日時', 'class' => 'is-submitted-at'],
                                        ['label' => '状態', 'class' => 'is-workflow-status'],
                                        ['label' => 'フォーム'],
                                        ['label' => '', 'class' => 'is-actions'],
                                    ]); ?>
                                        <tbody>
                                        <?php foreach ($recent as $r):
                                            $workflowStatus = (string) ($r['workflow_status'] ?? \Models\Submission::WORKFLOW_PENDING);
                                        ?>
                                            <tr>
                                                <td class="is-submitted-at" data-sp-label="受信日時"><?= e($r['submitted_at']) ?></td>
                                                <td class="is-workflow-status" data-sp-label="状態">
                                                    <?php admin_m_badge01(\Models\Submission::workflowStatusLabel($workflowStatus), $workflowStatus); ?>
                                                </td>
                                                <td class="is-recentSubmissionList-form" data-sp-label="フォーム"><?= e($r['form_title']) ?></td>
                                                <td class="is-actions">
                                                    <details class="c-tableActionMenu01">
                                                        <summary class="c-tableActionMenu01__toggle" aria-label="操作">
                                                            <span aria-hidden="true">⋯</span>
                                                        </summary>
                                                        <div class="c-tableActionMenu01__menu" role="menu" aria-label="操作">
                                                            <a role="menuitem" href="<?= e(base_path('/admin/forms/submissions/' . $r['id'])) ?>">詳細</a>
                                                        </div>
                                                    </details>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                        </tbody>
                                    <?php admin_m_table01_close(); ?>
                                <?php endif; ?>
                            </div>
<?php admin_c_form_block01_close(); ?>
