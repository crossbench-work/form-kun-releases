<?php /** c-formBlock01 直下 .area.is-field の内側: LINE通知 — 本文テンプレート（name=line_message_template） */
$formId = (int) ($form['id'] ?? 0);
$lineMessageTestUrl = $formId > 0
    ? base_path('/admin/forms/' . $formId . '/line/test-message')
    : '';
$canLineMessageTest = \Core\LineSiteConfig::isChannelAccessTokenConfigured()
    && \Core\LineSiteConfig::isPushToIdConfigured()
    && \Core\LineSiteConfig::isSetupComplete();
?>
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('表示設定'), 'line_message_template'); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input01_open(); ?>
        <?php admin_m_input01_textarea(admin_m_input01_attrs_with_bound_label('line_message_template', [
            'id' => 'line_message_template',
            'name' => 'line_message_template',
            'rows' => 6,
        ]), (string) ($form['line_message_template_effective'] ?? $form['line_message_template'] ?? '')); ?>
        <?php admin_m_input01_close(); ?>
    </div>
    <div class="area is-field">
        <input type="hidden" name="line_notify_include_images" value="0">
        <?php admin_m_checkbox01('画像をメッセージに含める', [
            'id' => 'line_notify_include_images',
            'name' => 'line_notify_include_images',
            'value' => '1',
            'checked' => !empty($form['line_notify_include_images']),
        ]); ?>
        <p class="text is-help">オンにすると、<code>{{__all__}}</code> またはファイル項目の変数で、画像の次行に署名付き URL を付け、続けて LINE に画像も送信します。オフのときはファイル名のみです。</p>
    </div>
    <div data-module="c-lineNotifyMessageTest01"<?= $lineMessageTestUrl !== '' ? ' data-test-url="' . e($lineMessageTestUrl) . '"' : '' ?> data-csrf-name="_token">
        <div class="area is-actions">
            <?php
            admin_m_btn01_button_wrap('メッセージをテスト送信する', [
                'type' => 'button',
                'class' => 'is-primary',
                'disabled' => $canLineMessageTest ? null : true,
            ]);
            ?>
        </div>
    </div>
    <?php admin_m_input_set01_close(); ?>
