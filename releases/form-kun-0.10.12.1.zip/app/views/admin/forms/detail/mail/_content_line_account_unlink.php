<?php /** LINE 連携: アカウント連携の解除 */
$lineAccountUnlinkUrl = (string) ($lineAccountUnlinkUrl ?? '');
$lineAccountUnlinkContext = (string) ($lineAccountUnlinkContext ?? 'site');
if ($lineAccountUnlinkUrl === '') {
    $formId = (int) ($form['id'] ?? 0);
    $lineAccountUnlinkUrl = $lineAccountUnlinkContext === 'site'
        ? base_path('/admin/settings/line/account-unlink')
        : ($formId > 0 ? base_path('/admin/forms/' . $formId . '/line/account-unlink') : '');
}
$unlinkConfirm = $lineAccountUnlinkContext === 'site'
    ? 'Channel secret・トークン・送信先 ID・チェックリスト・Webhook で記録した ID を消去し、個別連携を使っていないフォームの LINE 通知をオフにします。よろしいですか？'
    : 'このフォームの Channel secret・トークン・送信先 ID・チェックリスト・Webhook で記録した ID を消去します。よろしいですか？';
$unlinkHelp = $lineAccountUnlinkContext === 'site'
    ? 'Channel secret・トークン・送信先 ID・チェックリスト・Webhook で記録した ID を消去し、個別連携を使っていないフォームの LINE 通知をオフにします。各フォームの通知メッセージ本文は残ります。'
    : 'このフォームの Channel secret・トークン・送信先 ID・チェックリスト・Webhook で記録した ID を消去します。通知メッセージの本文は残ります。';
?>
<div data-module="c-lineAccountUnlink01"<?= $lineAccountUnlinkUrl !== '' ? ' data-reset-url="' . e($lineAccountUnlinkUrl) . '"' : '' ?> data-csrf-name="_token" data-confirm="<?= e($unlinkConfirm) ?>">
    <p class="text is-help"><?= e($unlinkHelp) ?></p>
    <div class="area is-actions">
        <?php
        admin_m_btn01_button_wrap('アカウント連携を解除', [
            'type' => 'button',
            'class' => 'is-danger',
            'data-target' => 'c-lineAccountUnlink01__submit',
        ]);
        ?>
    </div>
</div>
