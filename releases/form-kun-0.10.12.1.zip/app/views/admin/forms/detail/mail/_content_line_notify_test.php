<?php /** チェックリスト is-extra: LINEトークへの通知テスト */
$lineNotifyTestContext = (string) ($lineNotifyTestContext ?? 'form');
$formId = (int) ($form['id'] ?? 0);
if ($lineNotifyTestContext === 'site') {
    $lineNotifyTestUrl = base_path('/admin/settings/line/test-line');
    $canTest = \Core\LineSiteConfig::isPushToIdConfigured()
        && \Core\LineSiteConfig::isChannelAccessTokenConfigured();
} else {
    $lineNotifyTestUrl = $formId > 0
        ? base_path('/admin/forms/' . $formId . '/line/test-line')
        : '';
    $scope = !empty($form['line_custom_enabled'])
        ? \Core\LineAccountScope::form($form)
        : \Core\LineAccountScope::site();
    $canTest = trim((string) $scope->pushToId()) !== ''
        && trim((string) $scope->channelAccessToken()) !== '';
}
?>
<div data-module="c-lineNotifyTestPush01"<?= $lineNotifyTestUrl !== '' ? ' data-test-url="' . e($lineNotifyTestUrl) . '"' : '' ?> data-csrf-name="_token">
    <div class="area is-actions">
        <?php
        admin_m_btn01_button_wrap('テスト送信', [
            'type' => 'button',
            'class' => 'is-primary',
            'disabled' => $canTest ? null : true,
        ]);
        ?>
    </div>
</div>
