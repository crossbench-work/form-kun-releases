<?php /** チェックリスト is-extra: LINEトークへの送信先ID取得（ユーザー / グループタブ + Webhook ID 一覧） */
use Models\Form;
use Models\LineWebhookTarget;

$lineTalkSetupContext = (string) ($lineTalkSetupContext ?? 'site');
$lineTalkSetupCompact = !empty($lineTalkSetupCompact);
$lineWebhookFormId = isset($lineWebhookFormId) ? (int) $lineWebhookFormId : 0;
$userHasWebhookId = LineWebhookTarget::existsForForm($lineWebhookFormId, ['user']);
$groupHasWebhookId = LineWebhookTarget::existsForForm($lineWebhookFormId, ['group', 'room']);
if (!isset($lineTalkSetupChecklistSyncUrl)) {
    $lineTalkSetupChecklistSyncUrl = base_path('/admin/settings/line/talk-setup-checklist');
}
if (!isset($lineWebhookTargetDeleteUrl)) {
    $lineWebhookTargetDeleteUrl = base_path('/admin/settings/line/webhook-targets/delete');
}
$lineWebhookTargetsReady = true;
?>
<div data-module="c-lineTalkSendSetup01"<?= $lineTalkSetupChecklistSyncUrl !== '' ? ' data-sync-url="' . e($lineTalkSetupChecklistSyncUrl) . '"' : '' ?><?= $lineWebhookTargetDeleteUrl !== '' ? ' data-delete-url="' . e($lineWebhookTargetDeleteUrl) . '"' : '' ?> data-checklist-item="<?= e(Form::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP) ?>" data-csrf-name="_token">
<?php
admin_c_form_edit_section_tabs01_open('line-talk-setup', [
    ['panel' => 'line-talk-user', 'label' => 'ユーザーで作成', 'selected' => true],
    ['panel' => 'line-talk-group', 'label' => 'グループで作成'],
], 'LINEトークへの送信方法');
?>
        <div data-target="c-formEditTabs01__contents" data-tab-panel="line-talk-user" class="area is-contents" role="tabpanel" aria-label="ユーザーで作成" data-line-webhook-has-id="<?= $userHasWebhookId ? '1' : '0' ?>">
            <p class="text is-help">LINEアプリから作成したLINE公式アカウントを「友だち追加」してください。既に友達に追加している場合は一度「ブロック」した後に「ブロックを解除してください」</p>
            <?php if (!$lineTalkSetupCompact): ?>
            <p class="text is-checkHint is-sub">友達追加後に「ページを更新する」をクリックしてください</p>
            <div class="area is-actions">
                <?php admin_m_btn01_button_wrap('ページを更新する', ['type' => 'button', 'class' => 'is-primary', 'onclick' => 'window.location.reload()']); ?>
            </div>
            <?php endif; ?>
            <?php
            $lineWebhookTargetTypeFilter = ['user'];
            $lineWebhookHideLongEmptyHelp = true;
            $lineWebhookShowMissingHint = true;
            if ($lineTalkSetupCompact) {
                $lineWebhookHideTitle = true;
            }
            require __DIR__ . '/_content_line_webhook_targets.php';
            ?>
        </div>
        <div data-target="c-formEditTabs01__contents" data-tab-panel="line-talk-group" class="area is-contents" role="tabpanel" aria-label="グループで作成" hidden data-line-webhook-has-id="<?= $groupHasWebhookId ? '1' : '0' ?>">
            <?php if (!$lineTalkSetupCompact): ?>
            <p class="text is-help">LINEアプリでグループを作成した後に作成したLINE公式アカウントをグループに追加してください</p>
            <?php endif; ?>
            <?php if (!$lineTalkSetupCompact): ?>
            <p class="text is-checkHint is-sub">グループに追加後に「ページを更新する」をクリックしてください</p>
            <div class="area is-actions">
                <?php admin_m_btn01_button_wrap('ページを更新する', ['type' => 'button', 'class' => 'is-primary', 'onclick' => 'window.location.reload()']); ?>
            </div>
            <?php endif; ?>
            <?php
            $lineWebhookTargetTypeFilter = ['group', 'room'];
            $lineWebhookHideLongEmptyHelp = true;
            $lineWebhookShowMissingHint = true;
            if ($lineTalkSetupCompact) {
                $lineWebhookHideTitle = true;
            }
            require __DIR__ . '/_content_line_webhook_targets.php';
            ?>
        </div>
<?php
admin_c_form_edit_section_tabs01_close();
?>
</div>
