<!doctype html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=0.9">
<meta name="robots" content="noindex,nofollow">
<title><?= e($title ?? '管理画面') ?> | <?= e(effective_site_admin_name()) ?></title>
<link rel="stylesheet" href="<?= e(base_path('/assets/css/admin.css')) ?>">
</head>
<body <?= admin_l_auth_minimal01_body_attrs() ?>>
<?php admin_l_auth_card01_open(); ?>
    <?php admin_c_auth_card01_open(); ?>
        <?php admin_c_auth_card01_title((string) effective_site_admin_name()); ?>

        <?php foreach ((flash() ?? []) as $f): ?>
            <div data-module="m-alert01" class="is-<?= e($f['type']) ?>"><?= e($f['message']) ?></div>
        <?php endforeach; ?>

        <?= $content ?? '' ?>
    <?php admin_c_auth_card01_close(); ?>
<?php admin_l_auth_card01_close(); ?>
</body>
</html>
