<?php
namespace Controllers\Admin;

use Core\Auth;
use Core\Csrf;
use Core\LineSiteConfig;
use Core\View;
use Models\Form;

class LineSettingsController
{
    public function __construct()
    {
        Auth::requireRole('admin');
    }

    /**
     * @param 'secret'|'delete_secret'|'token'|'delete_token' $action
     */
    public function saveCredential(string $action): void
    {
        Csrf::verify();
        $lineCredentialErrors = [
            'line_channel_secret' => [],
            'line_channel_access_token' => [],
        ];
        if ($action === 'secret') {
            $value = trim((string) ($_POST['line_channel_secret'] ?? ''));
            if ($value === '') {
                $lineCredentialErrors['line_channel_secret'][] = 'Channel secret を入力してください。';
            } elseif (mb_strlen($value) > 255) {
                $lineCredentialErrors['line_channel_secret'][] = 'Channel secret が長すぎます。';
            } else {
                LineSiteConfig::setChannelSecret($value);
                LineSiteConfig::updateLineSetupChecklistItem(
                    Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_SECRET,
                    true
                );
                flash('success', 'Channel secret を保存しました。');
            }
        } elseif ($action === 'delete_secret') {
            LineSiteConfig::setChannelSecret('');
            LineSiteConfig::updateLineSetupChecklistItem(
                Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_SECRET,
                false
            );
            flash('success', 'Channel secret を削除しました。');
        } elseif ($action === 'token') {
            $value = trim((string) ($_POST['line_channel_access_token'] ?? ''));
            if ($value === '') {
                $lineCredentialErrors['line_channel_access_token'][] = 'Channel access token を入力してください。';
            } elseif (mb_strlen($value) > 512) {
                $lineCredentialErrors['line_channel_access_token'][] = 'Channel access token が長すぎます。';
            } else {
                LineSiteConfig::setChannelAccessToken($value);
                LineSiteConfig::updateLineSetupChecklistItem(
                    Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_ACCESS_TOKEN,
                    true
                );
                flash('success', 'Channel access token を保存しました。');
            }
        } elseif ($action === 'delete_token') {
            LineSiteConfig::setChannelAccessToken('');
            LineSiteConfig::updateLineSetupChecklistItem(
                Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_ACCESS_TOKEN,
                false
            );
            flash('success', 'Channel access token を削除しました。');
        }

        if ($lineCredentialErrors['line_channel_secret'] !== []
            || $lineCredentialErrors['line_channel_access_token'] !== []) {
            $_SESSION['formkun_line_credential_errors'] = $lineCredentialErrors;
            redirect('/admin/settings#line-settings');

            return;
        }

        redirect('/admin/settings#line-settings');
    }

    public function savePushToId(): void
    {
        Csrf::verify();
        $value = trim((string) ($_POST['line_push_to_id'] ?? ''));
        if ($value === '') {
            flash('danger', '送信先 ID を入力してください。');
            redirect('/admin/settings#line-settings');

            return;
        }
        if (mb_strlen($value) > 64) {
            flash('danger', '送信先 ID が長すぎます。');
            redirect('/admin/settings#line-settings');

            return;
        }
        LineSiteConfig::setPushToId($value);
        LineSiteConfig::updateLineSetupChecklistItem(
            Form::LINE_SETUP_CHECKLIST_SET_LINE_PUSH_TO_ID,
            true
        );
        flash('success', '送信先 ID を保存しました。');
        redirect('/admin/settings#line-settings');
    }

    public function testLine(): void
    {
        Csrf::verify();
        if (LineSiteConfig::pushToId() === '') {
            $this->jsonError('送信先 ID が未設定です。', 400);

            return;
        }
        if (LineSiteConfig::channelAccessToken() === '') {
            $this->jsonError('Channel access token が未設定です。', 400);

            return;
        }
        $sent = \Core\LineSubmissionNotifier::sendTest([]);
        if ($sent) {
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
            echo json_encode(['ok' => true, 'message' => 'LINE テストメッセージを送信しました。'], JSON_UNESCAPED_UNICODE);

            return;
        }
        $this->jsonError(
            'LINE テストメッセージを送信できませんでした。トークン・送信先 ID を確認してください。',
            502
        );
    }

    public function diagnoseImagePreview(): void
    {
        Csrf::verify();
        $result = \Core\LineImagePreviewDiagnostic::runSelfTest();
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        if (!$result['ok']) {
            http_response_code(502);
        }
        echo json_encode([
            'ok' => (bool) $result['ok'],
            'message' => (string) ($result['message'] ?? ''),
            'detail' => (string) ($result['detail'] ?? ''),
        ], JSON_UNESCAPED_UNICODE);
    }

    public function resetAccountLink(): void
    {
        Csrf::verify();
        LineSiteConfig::resetAccountLink();
        flash('success', 'アカウント連携の設定を解除しました。');
        redirect('/admin/settings#line-settings');
    }

    public function updateLineSetupChecklist(): void
    {
        Csrf::verify();
        $item = trim((string) ($_POST['item'] ?? ''));
        $checked = (string) ($_POST['checked'] ?? '0') === '1';
        if (!in_array($item, LineSiteConfig::siteChecklistItemKeys(), true)) {
            $this->jsonError('不正なチェック項目です。', 400);

            return;
        }
        if (!LineSiteConfig::siteChecklistItemIsManual($item)) {
            $this->jsonError('この項目は手動でチェックできません。', 400);

            return;
        }
        try {
            LineSiteConfig::updateLineSetupChecklistItem($item, $checked);
        } catch (\InvalidArgumentException $e) {
            $this->jsonError('不正なチェック項目です。', 400);

            return;
        }
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        echo json_encode(['ok' => true, 'item' => $item, 'checked' => $checked], JSON_UNESCAPED_UNICODE);
    }

    public function syncLineTalkSendSetupChecklist(): void
    {
        Csrf::verify();
        $panelId = trim((string) ($_POST['panel'] ?? ''));
        if (!in_array($panelId, ['line-talk-user', 'line-talk-group'], true)) {
            $this->jsonError('不正なタブです。', 400);

            return;
        }
        try {
            $checked = LineSiteConfig::syncLineTalkSendSetupChecklistForPanel($panelId);
        } catch (\InvalidArgumentException $e) {
            $this->jsonError('チェック状態を保存できません。', 400);

            return;
        }
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        echo json_encode([
            'ok' => true,
            'item' => Form::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP,
            'checked' => $checked,
        ], JSON_UNESCAPED_UNICODE);
    }

    public function deleteLineWebhookTarget(): void
    {
        Csrf::verify();
        $targetType = trim((string) ($_POST['target_type'] ?? ''));
        $targetId = trim((string) ($_POST['target_id'] ?? ''));
        if (!in_array($targetType, ['user', 'group', 'room'], true) || $targetId === '') {
            $this->jsonError('不正な ID です。', 400);

            return;
        }
        \Models\LineWebhookTarget::remove($targetType, $targetId, 0);
        $types = in_array($targetType, ['group', 'room'], true) ? ['group', 'room'] : ['user'];
        LineSiteConfig::syncLineTalkSendSetupChecklistForTypes($types);
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
    }

    private function jsonError(string $message, int $status): void
    {
        header('Content-Type: application/json; charset=UTF-8');
        header('Cache-Control: no-store');
        http_response_code($status);
        echo json_encode(['ok' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
    }
}
