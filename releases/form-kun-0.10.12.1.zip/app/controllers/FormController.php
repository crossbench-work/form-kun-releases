<?php
namespace Controllers;

use Core\Csrf;
use Core\FileStorage;
use Core\FormPublishSchedule;
use Core\PublicApiRateLimiter;
use Core\SiteResource;
use Core\SubmissionDeliveryService;
use Core\TemporaryAttachmentStorage;
use Core\Validator;
use Core\View;
use Models\Form;
use Models\FormBranchRule;
use Models\FormField;
use Models\FormFieldGroup;
use Models\FormInputPage;

class FormController
{
    private View $view;

    public function __construct()
    {
        $this->view = new View();
    }

    public function show(string $slug): void
    {
        $form = Form::findActiveBySlug($slug);
        if (!$form) {
            $this->notFound();
            return;
        }
        self::rememberPublicFormReturn($form);
        $fields = FormField::forForm((int) $form['id'], true);
        $fieldGroups = FormFieldGroup::forForm((int) $form['id'], true);
        $inputPages = FormInputPage::forForm((int) $form['id'], $form);
        $branchRules = FormBranchRule::forForm((int) $form['id']);
        if ($this->isSiteResourceBlocked()) {
            $this->renderShowBlocked($form, $fields, [], $inputPages[0] ?? null, $inputPages, $branchRules, $fieldGroups);
            return;
        }
        if (!FormPublishSchedule::isOpen($form)) {
            $this->renderClosed($form);
            return;
        }

        $pending = $_SESSION['_pending_submission'] ?? null;
        if (is_array($pending) && (int) ($pending['form_id'] ?? 0) === (int) $form['id']) {
            self::discardFileMetas((array) ($pending['file_metas'] ?? []));
            unset($_SESSION['_pending_submission']);
        }
        $this->renderShow($form, $fields, [], [], $inputPages[0] ?? null, $inputPages, $branchRules, $fieldGroups);
    }

    public function confirm(string $slug): void
    {
        $form = Form::findActiveBySlug($slug);
        if (!$form) { $this->notFound(); return; }
        self::rememberPublicFormReturn($form);

        Csrf::verify();
        if (!$this->consumeRateLimit($form)) { return; }
        FileStorage::pruneOrphansMaybe();
        $fields = FormField::forForm((int) $form['id'], true);
        $fieldGroups = FormFieldGroup::forForm((int) $form['id'], true);
        $inputPages = FormInputPage::forForm((int) $form['id'], $form);
        $branchRules = FormBranchRule::forForm((int) $form['id']);
        $firstPage = $inputPages[0] ?? FormInputPage::defaultPage($form);
        $postedPageKey = FormInputPage::sanitizePageKey((string) ($_POST['input_page_key'] ?? ''));
        if ($postedPageKey === '' || FormInputPage::findPage($inputPages, $postedPageKey) === null) {
            $postedPageKey = (string) $firstPage['page_key'];
        }
        $inputPage = FormInputPage::findPage($inputPages, $postedPageKey) ?? $firstPage;
        if ($this->isSiteResourceBlocked()) {
            $this->renderShowBlocked($form, $fields, [], $inputPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }
        if (!FormPublishSchedule::isOpen($form)) {
            $this->renderClosed($form);
            return;
        }
        $pageFields = FormField::forInputPage($fields, (string) $inputPage['page_key']);
        $pending = $_SESSION['_pending_submission'] ?? null;
        $pendingValues = (is_array($pending) && (int) ($pending['form_id'] ?? 0) === (int) $form['id'])
            ? (array) ($pending['values'] ?? [])
            : [];
        $pendingFileMetas = (is_array($pending) && (int) ($pending['form_id'] ?? 0) === (int) $form['id'])
            ? (array) ($pending['file_metas'] ?? [])
            : [];
        $submittedFieldKeys = (is_array($pending) && (int) ($pending['form_id'] ?? 0) === (int) $form['id'])
            ? (array) ($pending['submitted_field_keys'] ?? [])
            : [];
        $pageHistory = (is_array($pending) && (int) ($pending['form_id'] ?? 0) === (int) $form['id'])
            ? array_values(array_filter(array_map('strval', (array) ($pending['page_history'] ?? [])), static fn($key): bool => $key !== ''))
            : [];
        if (!empty($_POST['_back_input'])) {
            $previousPageKey = array_pop($pageHistory);
            $previousPage = $previousPageKey !== null ? FormInputPage::findPage($inputPages, $previousPageKey) : null;
            if ($previousPage === null) {
                $previousPage = $firstPage;
                $pageHistory = [];
            }
            $_SESSION['_pending_submission'] = [
                'form_id' => (int) $form['id'],
                'values' => $pendingValues,
                'file_metas' => $pendingFileMetas,
                'submitted_field_keys' => $submittedFieldKeys,
                'last_page_key' => (string) ($previousPage['page_key'] ?? FormInputPage::DEFAULT_KEY),
                'page_history' => $pageHistory,
                'created_at' => is_array($pending) ? (int) ($pending['created_at'] ?? time()) : time(),
                'delivery_id' => is_array($pending) && is_uuid_v4((string) ($pending['delivery_id'] ?? ''))
                    ? (string) $pending['delivery_id'] : uuid_v4(),
            ];
            Csrf::rotate();
            $this->renderShow($form, $fields, $pendingValues, [], $previousPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }
        $candidateValues = array_merge($pendingValues, $_POST);
        $currentPageKey = (string) ($inputPage['page_key'] ?? FormInputPage::DEFAULT_KEY);
        $visibleFields = self::visibleFields(self::applyBranchVisibility($pageFields, $branchRules, $candidateValues, $currentPageKey, $fieldGroups));

        // バリデーション
        $validator = new Validator();
        $files = self::buildFileMap($visibleFields);
        $result = $validator->validate($visibleFields, $_POST, $files);
        $mergedValues = array_merge($pendingValues, $result['values']);

        if (!empty($result['errors'])) {
            $this->renderShow($form, $fields, $mergedValues, $result['errors'], $inputPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }

        // DB保存モードは従来の保存領域へ、メール送信のみモードは確認画面用の専用一時領域へ保持する。
        $formUuid = Form::requirePublicUuid($form);
        $fileMetas = [];
        $uploadErrors = [];
        foreach ($files as $key => $entry) {
            if (!$entry || $entry['error'] === UPLOAD_ERR_NO_FILE) {
                if (isset($pendingFileMetas[$key])) {
                    $fileMetas[$key] = $pendingFileMetas[$key];
                }
                continue;
            }
            try {
                if (isset($pendingFileMetas[$key]['stored_path'])) {
                    if (Form::isMailOnly($form)) {
                        TemporaryAttachmentStorage::delete($pendingFileMetas[$key]);
                    } else {
                        FileStorage::delete($pendingFileMetas[$key]['stored_path']);
                    }
                }
                $field = null;
                foreach ($visibleFields as $candidate) {
                    if (($candidate['field_key'] ?? '') === $key) {
                        $field = $candidate;
                        break;
                    }
                }
                $allowedExtensions = $field !== null
                    ? \Models\FormField::decodeFileSettings($field['options_json'] ?? null)
                    : [];
                $meta = Form::isMailOnly($form)
                    ? TemporaryAttachmentStorage::store($entry)
                    : FileStorage::store($entry, $formUuid, $allowedExtensions);
                if ($meta) {
                    $fileMetas[$key] = $meta;
                }
            } catch (\RuntimeException $e) {
                $field = null;
                foreach ($visibleFields as $f) {
                    if (($f['field_key'] ?? '') === $key) {
                        $field = $f;
                        break;
                    }
                }
                $label = (string) ($field['label'] ?? $key);
                $uploadErrors[$key][] = $label . 'を保存できませんでした。' . $e->getMessage();
            }
        }
        if ($uploadErrors !== []) {
            $this->renderShow($form, $fields, $mergedValues, $uploadErrors, $inputPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }

        $mergedFileMetas = array_merge($pendingFileMetas, $fileMetas);
        if (Form::isMailOnly($form) && !SubmissionDeliveryService::attachmentsWithinLimit($form, $mergedFileMetas)) {
            TemporaryAttachmentStorage::deleteAll($mergedFileMetas);
            unset($_SESSION['_pending_submission']);
            $uploadErrors['_attachments'][] = '添付ファイルの合計サイズがメール添付上限を超えています。';
            $this->renderShow($form, $fields, $mergedValues, $uploadErrors, $inputPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }
        $branchEvaluation = FormBranchRule::evaluate($branchRules, $mergedValues, $currentPageKey);
        $controlledKeys = self::branchControlledFieldKeys($branchRules, $currentPageKey);
        $hiddenGroupKeys = self::hiddenControlledGroupKeys($fieldGroups, self::branchControlledGroupKeys($branchRules, $currentPageKey), $branchEvaluation['visible_group_keys']);
        foreach ($pageFields as $pageField) {
            $fieldKey = (string) ($pageField['field_key'] ?? '');
            if ($fieldKey !== '' && self::fieldBelongsToGroup($pageField, $hiddenGroupKeys, $fieldGroups)) {
                $controlledKeys[] = $fieldKey;
            }
        }
        foreach ($controlledKeys as $controlledKey) {
            if (in_array($controlledKey, $branchEvaluation['visible_field_keys'], true)) {
                continue;
            }
            if (isset($mergedFileMetas[$controlledKey]) && is_array($mergedFileMetas[$controlledKey])) {
                self::discardFileMetas([$mergedFileMetas[$controlledKey]]);
            }
            unset($mergedValues[$controlledKey], $mergedFileMetas[$controlledKey]);
            $submittedFieldKeys = array_values(array_filter($submittedFieldKeys, static function ($key) use ($controlledKey): bool {
                return (string) $key !== $controlledKey;
            }));
        }
        $nextPageKey = $branchEvaluation['next_screen_key']
            ?? FormInputPage::nextPageKey($inputPages, (string) $inputPage['page_key']);
        $submittedFieldKeys = array_values(array_unique(array_merge(
            array_map('strval', $submittedFieldKeys),
            array_map(static fn($field): string => (string) ($field['field_key'] ?? ''), $visibleFields)
        )));
        if ($pageHistory === [] || end($pageHistory) !== $currentPageKey) {
            $pageHistory[] = $currentPageKey;
        }
        // セッションに値を保管
        $_SESSION['_pending_submission'] = [
            'form_id'    => (int) $form['id'],
            'values'     => $mergedValues,
            'file_metas' => $mergedFileMetas,
            'submitted_field_keys' => $submittedFieldKeys,
            'last_page_key' => $currentPageKey,
            'page_history' => $pageHistory,
            'created_at' => time(),
            'delivery_id' => is_array($pending) && is_uuid_v4((string) ($pending['delivery_id'] ?? ''))
                ? (string) $pending['delivery_id'] : uuid_v4(),
        ];
        Csrf::rotate();

        if ($nextPageKey === FormBranchRule::SCREEN_THANKS) {
            $submittedFields = self::fieldsByKeys($fields, $submittedFieldKeys);
            $delivery = SubmissionDeliveryService::deliver(
                $form, $submittedFields, $mergedValues, $mergedFileMetas, 'public', (string) $_SESSION['_pending_submission']['delivery_id']
            );
            if (!$delivery['success']) {
                $this->renderShow($form, $fields, $mergedValues, ['_delivery' => ['メールを送信できませんでした。時間をおいて再度お試しください。']], $inputPage, $inputPages, $branchRules, $fieldGroups);
                return;
            }
            unset($_SESSION['_pending_submission']);
            if (Form::isMailOnly($form)) { TemporaryAttachmentStorage::deleteAll($mergedFileMetas); }
            $this->view->render('front/form/thanks', [
                'title' => trim((string) ($form['thanks_page_title'] ?? '')) !== ''
                    ? (string) $form['thanks_page_title']
                    : '送信が完了しました',
                'form'  => $form,
                'submissionId' => $delivery['submission_id'],
            ], 'public');
            return;
        }

        if ($nextPageKey !== null && $nextPageKey !== FormBranchRule::SCREEN_CONFIRM) {
            $nextPage = FormInputPage::findPage($inputPages, $nextPageKey);
            if ($nextPage !== null) {
                $this->renderShow($form, $fields, $mergedValues, [], $nextPage, $inputPages, $branchRules, $fieldGroups);
                return;
            }
        }

        $orderedFields = FormField::orderedSubmittableForForm((int) $form['id'], true);
        $submittedFields = self::fieldsByKeys($orderedFields, $submittedFieldKeys);
        $this->view->render('front/form/confirm', [
            'title'  => trim((string) ($form['confirm_page_title'] ?? '')) !== ''
                ? (string) $form['confirm_page_title']
                : '入力内容のご確認',
            'form'   => $form,
            'fields' => $submittedFields,
            'values' => $mergedValues,
            'fileMetas' => $mergedFileMetas,
        ], 'public');
    }

    public function submit(string $slug): void
    {
        $form = Form::findActiveBySlug($slug);
        if (!$form) { $this->notFound(); return; }
        self::rememberPublicFormReturn($form);

        Csrf::verify();
        if (!$this->consumeRateLimit($form)) { return; }
        if (!FormPublishSchedule::isOpen($form)) {
            $this->renderClosed($form);
            return;
        }
        $fields = FormField::forForm((int) $form['id'], true);
        $fieldGroups = FormFieldGroup::forForm((int) $form['id'], true);
        $inputPages = FormInputPage::forForm((int) $form['id'], $form);
        $branchRules = FormBranchRule::forForm((int) $form['id']);
        $blocked = $this->isSiteResourceBlocked();
        $pending = $_SESSION['_pending_submission'] ?? null;
        if (!$pending || (int) $pending['form_id'] !== (int) $form['id']) {
            // セッション切れ
            redirect('/f/' . $slug);
        }
        // 30分以上経過したら破棄
        if (time() - (int) $pending['created_at'] > 60 * 30) {
            self::discardFileMetas((array) ($pending['file_metas'] ?? []));
            unset($_SESSION['_pending_submission']);
            redirect('/f/' . $slug);
        }

        $visibleFields = self::visibleFields($fields);
        $submittedFieldKeys = array_map('strval', (array) ($pending['submitted_field_keys'] ?? []));
        $orderedFields = FormField::orderedSubmittableForForm((int) $form['id'], true);
        $submittedFields = $submittedFieldKeys !== []
            ? self::fieldsByKeys($orderedFields, $submittedFieldKeys)
            : self::fieldsByKeys($orderedFields, array_map(static fn(array $field): string => (string) ($field['field_key'] ?? ''), $visibleFields));

        if ($blocked && empty($_POST['_back'])) {
            $this->renderConfirmBlocked($form, $orderedFields, $pending);
            return;
        }

        // 戻るで再編集
        if (!empty($_POST['_back'])) {
            $values = $pending['values'];
            // 確認画面でアップ済みのファイルは戻ったらクリアする
            foreach ($pending['file_metas'] ?? [] as $meta) {
                if (Form::isMailOnly($form)) { TemporaryAttachmentStorage::delete($meta); }
                else { FileStorage::delete($meta['stored_path']); }
            }
            unset($_SESSION['_pending_submission']);
            $backPage = FormInputPage::findPage($inputPages, (string) ($pending['last_page_key'] ?? ''))
                ?? ($inputPages[count($inputPages) - 1] ?? null);
            if ($blocked) {
                $this->renderShowBlocked($form, $fields, $values, $backPage, $inputPages, $branchRules, $fieldGroups);
                return;
            }
            $this->renderShow($form, $fields, $values, [], $backPage, $inputPages, $branchRules, $fieldGroups);
            return;
        }

        if ($blocked) {
            $this->renderConfirmBlocked($form, $orderedFields, $pending);
            return;
        }

        $deliveryId = is_uuid_v4((string) ($pending['delivery_id'] ?? '')) ? (string) $pending['delivery_id'] : uuid_v4();
        $delivery = SubmissionDeliveryService::deliver($form, $submittedFields, $pending['values'], $pending['file_metas'] ?? [], 'public', $deliveryId);
        if (!$delivery['success']) {
            Csrf::rotate();
            $this->view->render('front/form/confirm', [
                'title' => '入力内容のご確認', 'form' => $form, 'fields' => $submittedFields,
                'values' => $pending['values'], 'fileMetas' => $pending['file_metas'] ?? [],
                'deliveryError' => 'メールを送信できませんでした。時間をおいて再度お試しください。',
            ], 'public');
            return;
        }
        unset($_SESSION['_pending_submission']);
        Csrf::rotate();
        if (Form::isMailOnly($form)) { TemporaryAttachmentStorage::deleteAll($pending['file_metas'] ?? []); }

        $this->view->render('front/form/thanks', [
            'title' => trim((string) ($form['thanks_page_title'] ?? '')) !== ''
                ? (string) $form['thanks_page_title']
                : '送信が完了しました',
            'form'  => $form,
            'submissionId' => $delivery['submission_id'],
        ], 'public');
    }

    /**
     * $_FILES の整形。
     */
    private static function buildFileMap(array $fields): array
    {
        $map = [];
        foreach ($fields as $f) {
            if ($f['type'] !== 'file') continue;
            $key = $f['field_key'];
            if (isset($_FILES[$key])) {
                $map[$key] = $_FILES[$key];
            }
        }
        return $map;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @return array<int, array<string, mixed>>
     */
    private static function visibleFields(array $fields): array
    {
        return array_values(array_filter($fields, static function ($field): bool {
            return !empty($field['visible']);
        }));
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $rules
     * @param array<string, mixed> $values
     * @return array<int, array<string, mixed>>
     */
    private static function applyBranchVisibility(array $fields, array $rules, array $values, ?string $triggerPageKey = null, array $groups = []): array
    {
        $controlledKeys = self::branchControlledFieldKeys($rules, $triggerPageKey);
        $controlledGroupKeys = self::branchControlledGroupKeys($rules, $triggerPageKey);
        if ($controlledKeys === [] && $controlledGroupKeys === []) {
            return $fields;
        }
        $evaluation = FormBranchRule::evaluate($rules, $values, $triggerPageKey);
        $visibleKeys = $evaluation['visible_field_keys'];
        $hiddenGroupKeys = self::hiddenControlledGroupKeys($groups, $controlledGroupKeys, $evaluation['visible_group_keys']);
        return array_values(array_filter($fields, static function ($field) use ($controlledKeys, $visibleKeys, $hiddenGroupKeys, $groups): bool {
            $key = (string) ($field['field_key'] ?? '');
            if (in_array($key, $controlledKeys, true) && !in_array($key, $visibleKeys, true)) {
                return false;
            }
            return !self::fieldBelongsToGroup($field, $hiddenGroupKeys, $groups);
        }));
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, string>
     */
    private static function branchControlledFieldKeys(array $rules, ?string $triggerPageKey = null): array
    {
        $keys = [];
        foreach (FormBranchRule::normalizeRules($rules) as $rule) {
            if ($triggerPageKey !== null && (string) $rule['trigger_page_key'] !== $triggerPageKey) {
                continue;
            }
            if (!empty($rule['enabled']) && $rule['action_type'] === FormBranchRule::ACTION_SHOW_FIELD) {
                if (($rule['target_type'] ?? FormBranchRule::TARGET_FIELD) !== FormBranchRule::TARGET_FIELD) {
                    continue;
                }
                $keys[] = (string) $rule['target_key'];
            }
        }
        return array_values(array_unique($keys));
    }

    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, string>
     */
    private static function branchControlledGroupKeys(array $rules, ?string $triggerPageKey = null): array
    {
        $keys = [];
        foreach (FormBranchRule::normalizeRules($rules) as $rule) {
            if ($triggerPageKey !== null && (string) $rule['trigger_page_key'] !== $triggerPageKey) {
                continue;
            }
            if (
                !empty($rule['enabled'])
                && $rule['action_type'] === FormBranchRule::ACTION_SHOW_FIELD
                && ($rule['target_type'] ?? FormBranchRule::TARGET_FIELD) === FormBranchRule::TARGET_GROUP
            ) {
                $keys[] = (string) $rule['target_key'];
            }
        }
        return array_values(array_unique($keys));
    }

    /**
     * @param array<int, array<string, mixed>> $groups
     * @param array<int, string> $controlledGroupKeys
     * @param array<int, string> $visibleGroupKeys
     * @return array<int, string>
     */
    private static function hiddenControlledGroupKeys(array $groups, array $controlledGroupKeys, array $visibleGroupKeys): array
    {
        $hidden = [];
        foreach ($controlledGroupKeys as $groupKey) {
            if (!in_array($groupKey, $visibleGroupKeys, true)) {
                $hidden[] = $groupKey;
            }
        }
        foreach ($groups as $group) {
            if (empty($group['visible'])) {
                $hidden[] = (string) ($group['group_key'] ?? '');
            }
        }
        $hidden = array_values(array_unique(array_filter($hidden, static fn($key): bool => $key !== '')));
        $changed = true;
        while ($changed) {
            $changed = false;
            foreach ($groups as $group) {
                $groupKey = (string) ($group['group_key'] ?? '');
                $parentGroupKey = (string) ($group['parent_group_key'] ?? '');
                if ($groupKey !== '' && $parentGroupKey !== '' && in_array($parentGroupKey, $hidden, true) && !in_array($groupKey, $hidden, true)) {
                    $hidden[] = $groupKey;
                    $changed = true;
                }
            }
        }
        return $hidden;
    }

    /**
     * @param array<string, mixed> $field
     * @param array<int, string> $hiddenGroupKeys
     * @param array<int, array<string, mixed>> $groups
     */
    private static function fieldBelongsToGroup(array $field, array $hiddenGroupKeys, array $groups): bool
    {
        $parentGroupKey = (string) ($field['parent_group_key'] ?? '');
        if ($parentGroupKey === '') {
            return false;
        }
        if (in_array($parentGroupKey, $hiddenGroupKeys, true)) {
            return true;
        }
        $parentByGroup = [];
        foreach ($groups as $group) {
            $groupKey = (string) ($group['group_key'] ?? '');
            if ($groupKey !== '') {
                $parentByGroup[$groupKey] = (string) ($group['parent_group_key'] ?? '');
            }
        }
        $seen = [];
        while ($parentGroupKey !== '') {
            if (isset($seen[$parentGroupKey])) {
                return false;
            }
            $seen[$parentGroupKey] = true;
            if (in_array($parentGroupKey, $hiddenGroupKeys, true)) {
                return true;
            }
            $parentGroupKey = (string) ($parentByGroup[$parentGroupKey] ?? '');
        }
        return false;
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, string> $keys
     * @return array<int, array<string, mixed>>
     */
    private static function fieldsByKeys(array $fields, array $keys): array
    {
        $keyMap = array_flip(array_filter(array_map('strval', $keys), static fn($key): bool => $key !== ''));
        return array_values(array_filter($fields, static function ($field) use ($keyMap): bool {
            $key = (string) ($field['field_key'] ?? '');
            return isset($keyMap[$key]) && !empty($field['visible']);
        }));
    }

    private function sendMails(array $form, array $fields, array $values, array $fileMetas): void
    {
        SubmissionNotifier::send($form, $fields, $values);
    }

    private function isSiteResourceBlocked(): bool
    {
        return SiteResource::isExceeded();
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     * @param array<string, list<string>> $errors
     */
    private function renderShow(array $form, array $fields, array $values = [], array $errors = [], ?array $inputPage = null, ?array $inputPages = null, ?array $branchRules = null, ?array $fieldGroups = null): void
    {
        $inputPages = $inputPages ?? FormInputPage::forForm((int) ($form['id'] ?? 0), $form);
        $branchRules = $branchRules ?? FormBranchRule::forForm((int) ($form['id'] ?? 0));
        $fieldGroups = $fieldGroups ?? FormFieldGroup::forForm((int) ($form['id'] ?? 0), true);
        $inputPage = $inputPage ?? ($inputPages[0] ?? FormInputPage::defaultPage($form));
        $inputPageTitle = trim((string) ($inputPage['title'] ?? '')) !== ''
            ? (string) $inputPage['title']
            : (string) ($form['title'] ?? 'フォーム');
        $inputPageKey = (string) ($inputPage['page_key'] ?? FormInputPage::DEFAULT_KEY);
        $firstPageKey = (string) (($inputPages[0]['page_key'] ?? null) ?: FormInputPage::DEFAULT_KEY);
        $inputPageFields = FormField::forInputPage($fields, $inputPageKey);
        $inputPageGroups = FormFieldGroup::forInputPage($fieldGroups, $inputPageKey);
        $branchEvaluation = FormBranchRule::evaluate($branchRules, $values, $inputPageKey);
        $pending = $_SESSION['_pending_submission'] ?? null;
        $canBackInput = is_array($pending)
            && (int) ($pending['form_id'] ?? 0) === (int) ($form['id'] ?? 0)
            && $inputPageKey !== $firstPageKey
            && count((array) ($pending['page_history'] ?? [])) > 0;

        $this->view->render('front/form/show', [
            'title'      => $inputPageTitle,
            'form'       => $form,
            'fields'     => $fields,
            'inputPages' => $inputPages,
            'inputPage'  => $inputPage,
            'inputPageFields' => $inputPageFields,
            'fieldGroups' => $fieldGroups,
            'inputPageGroups' => $inputPageGroups,
            'branchRules' => $branchRules,
            'branchControlledFieldKeys' => self::branchControlledFieldKeys($branchRules, $inputPageKey),
            'branchControlledGroupKeys' => self::branchControlledGroupKeys($branchRules, $inputPageKey),
            'branchVisibleFieldKeys' => $branchEvaluation['visible_field_keys'],
            'branchVisibleGroupKeys' => $branchEvaluation['visible_group_keys'],
            'canBackInput' => $canBackInput,
            'values'     => $values,
            'errors'     => $errors,
        ], 'public');
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $values
     */
    private function renderShowBlocked(array $form, array $fields, array $values = [], ?array $inputPage = null, ?array $inputPages = null, ?array $branchRules = null, ?array $fieldGroups = null): void
    {
        $inputPages = $inputPages ?? FormInputPage::forForm((int) ($form['id'] ?? 0), $form);
        $branchRules = $branchRules ?? FormBranchRule::forForm((int) ($form['id'] ?? 0));
        $fieldGroups = $fieldGroups ?? FormFieldGroup::forForm((int) ($form['id'] ?? 0), true);
        $inputPage = $inputPage ?? ($inputPages[0] ?? FormInputPage::defaultPage($form));
        $inputPageTitle = trim((string) ($inputPage['title'] ?? '')) !== ''
            ? (string) $inputPage['title']
            : (string) ($form['title'] ?? 'フォーム');
        $inputPageKey = (string) ($inputPage['page_key'] ?? FormInputPage::DEFAULT_KEY);
        $firstPageKey = (string) (($inputPages[0]['page_key'] ?? null) ?: FormInputPage::DEFAULT_KEY);
        $inputPageFields = FormField::forInputPage($fields, $inputPageKey);
        $inputPageGroups = FormFieldGroup::forInputPage($fieldGroups, $inputPageKey);
        $branchEvaluation = FormBranchRule::evaluate($branchRules, $values, $inputPageKey);
        $pending = $_SESSION['_pending_submission'] ?? null;
        $canBackInput = is_array($pending)
            && (int) ($pending['form_id'] ?? 0) === (int) ($form['id'] ?? 0)
            && $inputPageKey !== $firstPageKey
            && count((array) ($pending['page_history'] ?? [])) > 0;

        $this->view->render('front/form/show', [
            'title'                 => $inputPageTitle,
            'form'                  => $form,
            'fields'                => $fields,
            'inputPages'            => $inputPages,
            'inputPage'             => $inputPage,
            'inputPageFields'       => $inputPageFields,
            'fieldGroups'           => $fieldGroups,
            'inputPageGroups'       => $inputPageGroups,
            'branchRules'           => $branchRules,
            'branchControlledFieldKeys' => self::branchControlledFieldKeys($branchRules, $inputPageKey),
            'branchControlledGroupKeys' => self::branchControlledGroupKeys($branchRules, $inputPageKey),
            'branchVisibleFieldKeys' => $branchEvaluation['visible_field_keys'],
            'branchVisibleGroupKeys' => $branchEvaluation['visible_group_keys'],
            'canBackInput'            => $canBackInput,
            'values'                => $values,
            'errors'                => [],
            'site_resource_blocked' => true,
        ], 'public');
    }

    /**
     * @param array<int, array<string, mixed>> $fields
     * @param array<string, mixed> $pending
     */
    private function renderClosed(array $form): void
    {
        $this->view->render('front/form/closed', [
            'title' => trim((string) ($form['closed_page_title'] ?? '')) !== ''
                ? (string) $form['closed_page_title']
                : '現在、フォームをご利用いただけません',
            'form'  => $form,
        ], 'public');
    }

    private function renderConfirmBlocked(array $form, array $fields, array $pending): void
    {
        $this->view->render('front/form/confirm', [
            'title'                 => trim((string) ($form['confirm_page_title'] ?? '')) !== ''
                ? (string) $form['confirm_page_title']
                : '入力内容のご確認',
            'form'                  => $form,
            'fields'                => $fields,
            'values'                => $pending['values'] ?? [],
            'fileMetas'             => $pending['file_metas'] ?? [],
            'site_resource_blocked' => true,
        ], 'public');
    }

    /**
     * 送信完了前に破棄される添付を削除する。一時領域のものと、DB 保存モードで uploads/ に置いたものの両方を扱う。
     *
     * @param array<int|string, mixed> $fileMetas
     */
    private static function discardFileMetas(array $fileMetas): void
    {
        foreach ($fileMetas as $meta) {
            if (!is_array($meta)) {
                continue;
            }
            if (!empty($meta['temporary'])) {
                TemporaryAttachmentStorage::delete($meta);
            } elseif (!empty($meta['file_uuid']) && !empty($meta['stored_path'])) {
                FileStorage::delete((string) $meta['stored_path']);
            }
        }
    }

    /**
     * 公開フォームの confirm / submit を IP 単位で制限する。超過時は 429 を描画して false を返す。
     */
    private function consumeRateLimit(array $form): bool
    {
        // Embed API と同じテーブルを使うため、ip 列に接頭辞を付けて計数を分ける。
        $rate = PublicApiRateLimiter::consume(
            (int) $form['id'],
            'html:' . client_ip(),
            (int) config('security.public_form_rate_limit_count', 20),
            (int) config('security.public_form_rate_limit_window_seconds', 600)
        );
        if (!empty($rate['allowed'])) {
            return true;
        }
        http_response_code(429);
        header('Retry-After: ' . max(1, (int) ($rate['retry_after'] ?? 60)));
        $this->view->render('front/429', ['title' => '送信が集中しています', 'form' => $form], 'public');
        return false;
    }

    /**
     * @param array<string, mixed> $form
     */
    private static function rememberPublicFormReturn(array $form): void
    {
        $slug = trim((string) ($form['slug'] ?? ''));
        if ($slug !== '') {
            remember_public_form_return_path($slug);
        }
    }

    private function notFound(): void
    {
        http_response_code(404);
        (new View())->render('front/404', ['title' => 'Not Found'], 'public');
    }
}
