<?php
namespace Controllers;

use Core\LineSiteConfig;
use Core\LineWebhookSignature;
use Core\LineWebhookSourceTarget;
use Models\Form;
use Models\LineWebhookTarget;

class LineWebhookController
{
    public function handleSite(): void
    {
        header('Content-Type: application/json; charset=utf-8');

        $secret = LineSiteConfig::channelSecret();
        if ($secret === '') {
            http_response_code(503);
            echo '{}';

            return;
        }

        if (!self::verifyAndProcess($secret, 0)) {
            return;
        }

        http_response_code(200);
        echo '{}';
    }

    public function handle(string $publicUuid): void
    {
        header('Content-Type: application/json; charset=utf-8');

        $form = Form::findByPublicUuid($publicUuid);
        if ($form === null) {
            http_response_code(404);
            echo '{}';

            return;
        }
        if (empty($form['line_custom_enabled'])) {
            http_response_code(410);
            echo '{}';

            return;
        }

        $secret = trim((string) ($form['line_channel_secret'] ?? ''));
        if ($secret === '') {
            http_response_code(503);
            echo '{}';

            return;
        }

        if (!self::verifyAndProcess($secret, (int) ($form['id'] ?? 0))) {
            return;
        }

        http_response_code(200);
        echo '{}';
    }

    private static function verifyAndProcess(string $secret, int $formId): bool
    {
        $rawBody = (string) file_get_contents('php://input');
        $signature = (string) ($_SERVER['HTTP_X_LINE_SIGNATURE'] ?? '');
        if (!LineWebhookSignature::isValid($secret, $rawBody, $signature)) {
            http_response_code(401);
            echo '{}';

            return false;
        }

        $payload = json_decode($rawBody, true);
        if (!is_array($payload)) {
            return true;
        }

        $events = $payload['events'] ?? [];
        if (is_array($events)) {
            foreach ($events as $event) {
                if (is_array($event)) {
                    self::processEvent($event, $formId);
                }
            }
        }

        return true;
    }

    /** @param array<string, mixed> $event */
    private static function processEvent(array $event, int $formId = 0): void
    {
        $type = (string) ($event['type'] ?? '');
        $source = $event['source'] ?? [];
        if (!is_array($source)) {
            $source = [];
        }

        if ($type === 'follow') {
            $userId = trim((string) ($source['userId'] ?? ''));
            if ($userId !== '') {
                LineWebhookTarget::upsert('user', $userId, null, $formId);
                if ($formId > 0) {
                    Form::syncLineTalkSendSetupChecklistForFormTypes($formId, ['user']);
                } else {
                    LineSiteConfig::syncLineTalkSendSetupChecklistForTypes(['user']);
                }
            }

            return;
        }

        if ($type === 'unfollow') {
            $userId = trim((string) ($source['userId'] ?? ''));
            if ($userId !== '') {
                LineWebhookTarget::remove('user', $userId, $formId);
                if ($formId > 0) {
                    Form::syncLineTalkSendSetupChecklistForFormTypes($formId, ['user']);
                } else {
                    LineSiteConfig::syncLineTalkSendSetupChecklistForTypes(['user']);
                }
            }

            return;
        }

        if ($type === 'join' || $type === 'memberJoined' || $type === 'message' || $type === 'postback') {
            $resolved = LineWebhookSourceTarget::resolveForPush($source);
            if ($resolved !== null) {
                LineWebhookTarget::upsert($resolved['type'], $resolved['id'], null, $formId);
                $types = in_array($resolved['type'], ['group', 'room'], true) ? ['group', 'room'] : ['user'];
                if ($formId > 0) {
                    Form::syncLineTalkSendSetupChecklistForFormTypes($formId, $types);
                } else {
                    LineSiteConfig::syncLineTalkSendSetupChecklistForTypes($types);
                }
            }

            return;
        }

        if ($type === 'leave' || $type === 'memberLeft') {
            $resolved = LineWebhookSourceTarget::resolveForPush($source);
            if ($resolved !== null) {
                LineWebhookTarget::remove($resolved['type'], $resolved['id'], $formId);
                $types = in_array($resolved['type'], ['group', 'room'], true) ? ['group', 'room'] : ['user'];
                if ($formId > 0) {
                    Form::syncLineTalkSendSetupChecklistForFormTypes($formId, $types);
                } else {
                    LineSiteConfig::syncLineTalkSendSetupChecklistForTypes($types);
                }
            }
        }
    }
}
