<?php
namespace Controllers\Api;

use Core\EmbedCodeSample;
use Models\Form;
use Models\FormBranchRule;
use Models\FormEmbedSetting;
use Models\FormField;
use Models\FormFieldGroup;
use Models\FormInputPage;

class EmbedAssetController
{
    public function script(string $publicUuid): void
    {
        $form = Form::findActiveByPublicUuid($publicUuid);
        $settings = $form ? FormEmbedSetting::forForm((int) $form['id']) : [];
        if (!$form || empty($settings['enabled'])) {
            $this->respondText("console.warn('form-kun: embed is not available for this form.');", 'application/javascript; charset=UTF-8', $publicUuid . '-disabled');
            return;
        }

        $formId = (int) $form['id'];
        $fields = FormField::forForm($formId);
        $fieldGroups = FormFieldGroup::forForm($formId, true);
        $inputPages = FormInputPage::forForm($formId, $form);
        $branchRules = FormBranchRule::forForm($formId);

        $siteKey = trim((string) ($settings['turnstile_site_key'] ?? ''));
        if ($siteKey === '') {
            $siteKey = 'YOUR_TURNSTILE_SITE_KEY';
        }
        $recaptchaSiteKey = trim((string) ($settings['recaptcha_site_key'] ?? ''));
        if ($recaptchaSiteKey === '') {
            $recaptchaSiteKey = 'YOUR_RECAPTCHA_SITE_KEY';
        }
        $recaptchaV3SiteKey = trim((string) ($settings['recaptcha_v3_site_key'] ?? ''));
        if ($recaptchaV3SiteKey === '') {
            $recaptchaV3SiteKey = 'YOUR_RECAPTCHA_V3_SITE_KEY';
        }
        $captchaProvider = (string) ($settings['captcha_provider'] ?? FormEmbedSetting::captchaProvider($settings));
        $captchaContext = [
            'turnstile_site_key' => $siteKey,
            'recaptcha_site_key' => $recaptchaSiteKey,
        ];
        $apiUrl = url('/api/public/forms/' . $publicUuid . '/submit');

        $code = EmbedCodeSample::generateLoaderScript(
            $fields,
            $fieldGroups,
            $inputPages,
            $branchRules,
            $captchaProvider,
            $apiUrl,
            $captchaContext,
            is_array($form) ? $form : [],
            $recaptchaV3SiteKey,
            $publicUuid
        );
        if ($code === '') {
            $code = "console.warn('form-kun: embed is not available for this form.');";
        }

        $this->respondText($code, 'application/javascript; charset=UTF-8', md5($code));
    }

    public function style(): void
    {
        $code = EmbedCodeSample::generateCss();
        $this->respondText($code, 'text/css; charset=UTF-8', md5($code));
    }

    private function respondText(string $body, string $contentType, string $etagSeed): void
    {
        $etag = '"' . md5($etagSeed . '|' . $body) . '"';
        header('Content-Type: ' . $contentType);
        header('Cache-Control: no-cache, must-revalidate');
        header('ETag: ' . $etag);

        $ifNoneMatch = (string) ($_SERVER['HTTP_IF_NONE_MATCH'] ?? '');
        if ($ifNoneMatch !== '' && trim($ifNoneMatch) === $etag) {
            http_response_code(304);
            return;
        }

        echo $body;
    }
}
