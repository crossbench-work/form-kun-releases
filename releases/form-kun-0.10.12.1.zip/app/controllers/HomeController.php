<?php
namespace Controllers;

use Core\View;

class HomeController
{
    public function index(): void
    {
        $publicSiteUrl = settings_public_site_url();
        if ($publicSiteUrl !== '') {
            header('Location: ' . resolve_form_button_url($publicSiteUrl), true, 302);
            exit;
        }

        $returnPath = remembered_public_form_return_path();
        if ($returnPath !== '') {
            header('Location: ' . $returnPath, true, 302);
            exit;
        }

        $this->notFound();
    }

    private function notFound(): void
    {
        http_response_code(404);
        (new View())->render('front/404', ['title' => 'Not Found'], 'public');
    }
}
