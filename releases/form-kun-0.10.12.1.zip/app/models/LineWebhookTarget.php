<?php
namespace Models;

use Core\Database;
use Core\LineWebhookSourceTarget;

class LineWebhookTarget
{
    public static function upsert(string $targetType, string $targetId, ?string $label = null, int $formId = 0): void
    {
        $targetType = LineWebhookSourceTarget::normalizeTargetType($targetType);
        $targetId = trim($targetId);
        if ($targetId === '' || strlen($targetId) > 64) {
            return;
        }
        $formId = max(0, $formId);
        $now = date('Y-m-d H:i:s');
        $label = $label !== null && trim($label) !== '' ? mb_substr(trim($label), 0, 200) : null;
        Database::execute(
            'INSERT INTO line_webhook_targets (form_id, target_type, target_id, label, last_seen_at)
             VALUES (?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE label = COALESCE(VALUES(label), label), last_seen_at = VALUES(last_seen_at)',
            [$formId, $targetType, $targetId, $label, $now]
        );
    }

    public static function remove(string $targetType, string $targetId, int $formId = 0): void
    {
        $targetType = LineWebhookSourceTarget::normalizeTargetType($targetType);
        $targetId = trim($targetId);
        if ($targetId === '') {
            return;
        }
        $formId = max(0, $formId);
        Database::execute(
            'DELETE FROM line_webhook_targets WHERE form_id = ? AND target_type = ? AND target_id = ?',
            [$formId, $targetType, $targetId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public static function listRecent(int $limit = 20): array
    {
        return self::listRecentForForm(0, $limit);
    }

    /**
     * @param list<string> $types
     * @return array<int, array<string, mixed>>
     */
    public static function listRecentForTypes(array $types, int $limit = 20): array
    {
        return self::listRecentForFormAndTypes(0, $types, $limit);
    }

    /**
     * @param list<string> $types
     * @return array<int, array<string, mixed>>
     */
    public static function listRecentForForm(int $formId, int $limit = 20): array
    {
        $formId = max(0, $formId);
        $limit = max(1, min(50, $limit));

        return Database::fetchAll(
            'SELECT * FROM line_webhook_targets WHERE form_id = ? ORDER BY last_seen_at DESC LIMIT ' . $limit,
            [$formId]
        );
    }

    /**
     * @param list<string> $types
     * @return array<int, array<string, mixed>>
     */
    public static function listRecentForFormAndTypes(int $formId, array $types, int $limit = 20): array
    {
        if ($types === []) {
            return [];
        }
        $allowed = [];
        foreach ($types as $type) {
            $normalized = LineWebhookSourceTarget::normalizeTargetType((string) $type);
            if ($normalized !== '') {
                $allowed[$normalized] = true;
            }
        }
        if ($allowed === []) {
            return [];
        }
        $formId = max(0, $formId);
        $limit = max(1, min(50, $limit));
        $placeholders = implode(',', array_fill(0, count($allowed), '?'));
        $params = array_merge([$formId], array_keys($allowed));

        return Database::fetchAll(
            'SELECT * FROM line_webhook_targets WHERE form_id = ? AND target_type IN ('
            . $placeholders
            . ') ORDER BY last_seen_at DESC LIMIT '
            . $limit,
            $params
        );
    }

    /**
     * @param list<string> $types
     */
    public static function existsForSite(array $types): bool
    {
        return self::existsForForm(0, $types);
    }

    /**
     * @param list<string> $types
     */
    public static function existsForForm(int $formId, array $types): bool
    {
        if ($types === []) {
            return false;
        }
        $allowed = [];
        foreach ($types as $type) {
            $normalized = LineWebhookSourceTarget::normalizeTargetType((string) $type);
            if ($normalized !== '') {
                $allowed[$normalized] = true;
            }
        }
        if ($allowed === []) {
            return false;
        }
        $formId = max(0, $formId);
        $placeholders = implode(',', array_fill(0, count($allowed), '?'));
        $params = array_merge([$formId], array_keys($allowed));
        $row = Database::fetchOne(
            'SELECT 1 AS ok FROM line_webhook_targets WHERE form_id = ? AND target_type IN ('
            . $placeholders
            . ') LIMIT 1',
            $params
        );

        return $row !== null;
    }

    public static function deleteAll(): void
    {
        Database::execute('DELETE FROM line_webhook_targets WHERE form_id = 0');
    }

    public static function deleteAllForForm(int $formId): void
    {
        $formId = max(0, $formId);
        Database::execute('DELETE FROM line_webhook_targets WHERE form_id = ?', [$formId]);
    }
}
