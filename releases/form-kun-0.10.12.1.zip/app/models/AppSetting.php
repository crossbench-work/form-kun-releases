<?php
namespace Models;

use Core\Database;

class AppSetting
{
    public const KEY_MAX_FORMS = 'max_forms';
    public const KEY_MAX_SITE_RESOURCE_BYTES = 'max_site_resource_bytes';
    public const KEY_UPDATE_ENABLED = 'update_enabled';
    public const KEY_UPDATE_MANIFEST_URL = 'update_manifest_url';
    public const KEY_FORM_VERSION_INTERVAL_MINUTES = 'form_version_interval_minutes';
    public const KEY_FORM_VERSION_PERIODIC_SAVE_ENABLED = 'form_version_periodic_save_enabled';
    public const KEY_FORM_VERSION_SAVE_ON_SAVE = 'form_version_save_on_save';
    public const KEY_FORM_VERSION_SAVE_ON_LOGIN = 'form_version_save_on_login';
    public const KEY_FORM_VERSION_SAVE_ON_LOGOUT = 'form_version_save_on_logout';
    public const KEY_FORM_VERSION_RETENTION_LIMIT = 'form_version_retention_limit';
    public const KEY_SHOW_ACTIVE_FORMS_LIST = 'show_active_forms_list';
    public const KEY_ACTIVE_FORMS_LIST_REDIRECT_URL = 'active_forms_list_redirect_url';
    public const KEY_HOLIDAYS_JP_JSON = 'holidays_jp_json';
    public const KEY_HOLIDAYS_JP_FETCHED_AT = 'holidays_jp_fetched_at';
    public const KEY_HOLIDAYS_JP_FETCH_INTERVAL_DAYS = 'holidays_jp_fetch_interval_days';
    public const KEY_HOLIDAYS_JP_LAST_ERROR = 'holidays_jp_last_error';
    public const KEY_SUBMISSION_PURGE_SCHEDULE_ENABLED = 'submission_purge_schedule_enabled';
    public const KEY_SUBMISSION_PURGE_SCHEDULE_MODE = 'submission_purge_schedule_mode';
    public const KEY_SUBMISSION_PURGE_SCHEDULE_DAILY_HOUR = 'submission_purge_schedule_daily_hour';
    public const KEY_SUBMISSION_PURGE_SCHEDULE_INTERVAL_HOURS = 'submission_purge_schedule_interval_hours';
    public const KEY_SUBMISSION_PURGE_SCHEDULE_LAST_RUN_AT = 'submission_purge_schedule_last_run_at';
    public const KEY_LINE_CHANNEL_SECRET = 'line_channel_secret';
    public const KEY_LINE_CHANNEL_ACCESS_TOKEN = 'line_channel_access_token';
    public const KEY_LINE_SETUP_CHECKLIST = 'line_setup_checklist';
    public const KEY_LINE_PUSH_TO_ID = 'line_push_to_id';
    public const KEY_LINE_SITE_FORM_IMPORT_DONE = 'line_site_form_import_done';
    public const KEY_LINE_PUBLIC_FILE_SIGNING_KEY = 'line_public_file_signing_key';
    public const KEY_SITE_ADMIN_NAME = 'site_admin_name';
    public const KEY_SITE_TIMEZONE = 'site_timezone';
    public const KEY_SITE_LOGO = 'site_logo';

    public static function get(string $key): ?string
    {
        $row = Database::fetchOne(
            'SELECT setting_value FROM app_settings WHERE setting_key = ?',
            [$key]
        );
        if ($row === null) {
            return null;
        }
        return (string) ($row['setting_value'] ?? '');
    }

    public static function set(string $key, string $value): void
    {
        $now = date('Y-m-d H:i:s');
        Database::execute(
            'INSERT INTO app_settings (setting_key, setting_value, created_at, updated_at) VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = VALUES(updated_at)',
            [$key, $value, $now, $now]
        );
    }
}
