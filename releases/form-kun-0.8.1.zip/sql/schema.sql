-- =================================================================
-- フォーム管理システム データベーススキーマ
-- MySQL 5.7+ / MariaDB 10.2+
-- 文字コード: utf8mb4
-- =================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 管理ユーザー
CREATE TABLE IF NOT EXISTS users (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(64) UNIQUE NOT NULL,
    password_hash   VARCHAR(255) NOT NULL,
    display_name    VARCHAR(100) DEFAULT NULL,
    email           VARCHAR(255) DEFAULT NULL,
    role            ENUM('admin','editor','viewer') NOT NULL DEFAULT 'editor',
    last_login_at   DATETIME DEFAULT NULL,
    created_at      DATETIME NOT NULL,
    updated_at      DATETIME NOT NULL,
    UNIQUE KEY uk_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- パスワード再設定トークン（メールリンク用）
CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    token_hash      CHAR(64) NOT NULL,
    expires_at      DATETIME NOT NULL,
    created_at      DATETIME NOT NULL,
    UNIQUE KEY uk_token_hash (token_hash),
    KEY idx_user_id (user_id),
    CONSTRAINT fk_pwreset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- WebAuthn パスキー（管理画面ログイン）
CREATE TABLE IF NOT EXISTS user_webauthn_credentials (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    credential_id   VARBINARY(1024) NOT NULL,
    public_key      BLOB NOT NULL,
    user_handle     VARBINARY(64) NOT NULL,
    sign_count      INT UNSIGNED NOT NULL DEFAULT 0,
    transports      JSON DEFAULT NULL,
    name            VARCHAR(100) DEFAULT NULL,
    created_at      DATETIME NOT NULL,
    last_used_at    DATETIME DEFAULT NULL,
    UNIQUE KEY uk_webauthn_credential_id (credential_id),
    KEY idx_webauthn_user (user_id),
    CONSTRAINT fk_webauthn_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- フォーム本体
CREATE TABLE IF NOT EXISTS forms (
    id                      INT AUTO_INCREMENT PRIMARY KEY,
    slug                    VARCHAR(64) UNIQUE NOT NULL,
    public_uuid             CHAR(36) NOT NULL,
    title                   VARCHAR(200) NOT NULL,
    meta_html               TEXT DEFAULT NULL,
    custom_css              TEXT DEFAULT NULL,
    custom_js               TEXT DEFAULT NULL,
    header_html             TEXT DEFAULT NULL,
    footer_html             TEXT DEFAULT NULL,
    input_page_title        VARCHAR(200) DEFAULT NULL,
    show_input_page_title   TINYINT(1) NOT NULL DEFAULT 1,
    description             TEXT DEFAULT NULL,
    show_title              TINYINT(1) NOT NULL DEFAULT 1,
    show_description        TINYINT(1) NOT NULL DEFAULT 1,
    confirm_page_title      VARCHAR(200) DEFAULT NULL,
    show_confirm_page_title TINYINT(1) NOT NULL DEFAULT 1,
    confirm_button_text     VARCHAR(200) DEFAULT NULL,
    submit_button_text      VARCHAR(200) DEFAULT NULL,
    back_button_text        VARCHAR(200) DEFAULT NULL,
    confirm_message         TEXT DEFAULT NULL,
    thanks_page_title       VARCHAR(200) DEFAULT NULL,
    show_thanks_page_title  TINYINT(1) NOT NULL DEFAULT 1,
    thanks_message          TEXT DEFAULT NULL,
    thanks_button_text      VARCHAR(200) DEFAULT NULL,
    thanks_button_url       VARCHAR(500) DEFAULT NULL,
    admin_emails            VARCHAR(500) DEFAULT NULL,
    mail_subject_admin      VARCHAR(200) DEFAULT NULL,
    mail_template_admin     TEXT DEFAULT NULL,
    mail_transport          VARCHAR(10) DEFAULT NULL,
    mail_from_email         VARCHAR(255) DEFAULT NULL,
    mail_from_name          VARCHAR(255) DEFAULT NULL,
    mail_smtp_host          VARCHAR(255) DEFAULT NULL,
    mail_smtp_port          INT DEFAULT NULL,
    mail_smtp_secure        VARCHAR(10) DEFAULT NULL,
    mail_smtp_username      VARCHAR(255) DEFAULT NULL,
    mail_smtp_password      VARCHAR(255) DEFAULT NULL,
    mail_smtp_timeout       INT DEFAULT NULL,
    mail_smtp_ehlo_host     VARCHAR(255) DEFAULT NULL,
    mail_smtp_verify_peer   TINYINT(1) NOT NULL DEFAULT 1,
    mail_smtp_verify_peer_name TINYINT(1) NOT NULL DEFAULT 1,
    mail_smtp_allow_self_signed TINYINT(1) NOT NULL DEFAULT 0,
    submission_storage_mode VARCHAR(20) NOT NULL DEFAULT 'database',
    mail_attachment_max_bytes INT NOT NULL DEFAULT 10485760,
    submission_retention_days INT NOT NULL DEFAULT 14,
    submission_retention_action VARCHAR(10) NOT NULL DEFAULT 'warn',
    submission_retention_enabled TINYINT(1) NOT NULL DEFAULT 1,
    smtp_tested_at DATETIME DEFAULT NULL,
    smtp_test_fingerprint CHAR(64) DEFAULT NULL,
    reply_enabled           TINYINT(1) NOT NULL DEFAULT 0,
    reply_from_field_key    TEXT DEFAULT NULL,
    reply_subject           VARCHAR(200) DEFAULT NULL,
    reply_template          TEXT DEFAULT NULL,
    publish_schedule_enabled TINYINT(1) NOT NULL DEFAULT 0,
    publish_rules           TEXT DEFAULT NULL,
    unpublish_rules         TEXT DEFAULT NULL,
    closed_page_title       VARCHAR(200) DEFAULT NULL,
    show_closed_page_title  TINYINT(1) NOT NULL DEFAULT 1,
    closed_message          TEXT DEFAULT NULL,
    closed_button_text      VARCHAR(200) DEFAULT NULL,
    closed_button_url       VARCHAR(500) DEFAULT NULL,
    status                  ENUM('active','draft','archived') NOT NULL DEFAULT 'draft',
    created_at              DATETIME NOT NULL,
    updated_at              DATETIME NOT NULL,
    UNIQUE KEY uk_forms_public_uuid (public_uuid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- viewer ロールが閲覧できるフォーム（admin がユーザー編集で付与）
CREATE TABLE IF NOT EXISTS user_form_grants (
    user_id       INT NOT NULL,
    form_id       INT NOT NULL,
    access_level  ENUM('view','edit') NOT NULL DEFAULT 'view',
    PRIMARY KEY (user_id, form_id),
    KEY idx_user_form_grants_form (form_id),
    CONSTRAINT fk_user_form_grants_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_user_form_grants_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- フォームの入力画面
CREATE TABLE IF NOT EXISTS form_input_pages (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    form_id         INT NOT NULL,
    page_key        VARCHAR(64) NOT NULL,
    sort_order      INT NOT NULL DEFAULT 0,
    title           VARCHAR(200) DEFAULT NULL,
    show_title      TINYINT(1) NOT NULL DEFAULT 1,
    description     TEXT DEFAULT NULL,
    button_text     VARCHAR(200) DEFAULT NULL,
    back_button_text VARCHAR(200) DEFAULT NULL,
    created_at      DATETIME NOT NULL,
    updated_at      DATETIME NOT NULL,
    UNIQUE KEY uk_form_input_page (form_id, page_key),
    KEY idx_form_input_page_sort (form_id, sort_order),
    CONSTRAINT fk_form_input_pages_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- フォームの項目
CREATE TABLE IF NOT EXISTS form_fields (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    form_id         INT NOT NULL,
    input_page_key  VARCHAR(64) NOT NULL DEFAULT 'input-1',
    parent_group_key VARCHAR(64) DEFAULT NULL,
    sort_order      INT NOT NULL DEFAULT 0,
    field_key       VARCHAR(64) NOT NULL,
    label           VARCHAR(200) NOT NULL,
    show_label      TINYINT(1) NOT NULL DEFAULT 1,
    visible         TINYINT(1) NOT NULL DEFAULT 1,
    type            ENUM(
        'text','textarea','email','tel','number','postal_code','address','text_pair','text_multi','matrix',
        'radio','checkbox','select','date','time','file',
        'heading','description','divider'
    ) NOT NULL,
    required        TINYINT(1) NOT NULL DEFAULT 0,
    min_length      INT DEFAULT NULL,
    max_length      INT DEFAULT NULL,
    exact_length    INT DEFAULT NULL,
    regex           TEXT DEFAULT NULL,
    help_text       VARCHAR(500) DEFAULT NULL,
    placeholder     VARCHAR(255) DEFAULT NULL,
    options_json    TEXT DEFAULT NULL,
    UNIQUE KEY uk_form_field (form_id, field_key),
    KEY idx_form_sort (form_id, input_page_key, sort_order),
    CONSTRAINT fk_form_fields_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- フォーム項目のグループ
CREATE TABLE IF NOT EXISTS form_field_groups (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    form_id          INT NOT NULL,
    input_page_key   VARCHAR(64) NOT NULL DEFAULT 'input-1',
    parent_group_key VARCHAR(64) DEFAULT NULL,
    sort_order       INT NOT NULL DEFAULT 0,
    group_key        VARCHAR(64) NOT NULL,
    label            VARCHAR(200) NOT NULL,
    show_label       TINYINT(1) NOT NULL DEFAULT 1,
    description      VARCHAR(500) DEFAULT NULL,
    visible          TINYINT(1) NOT NULL DEFAULT 1,
    created_at       DATETIME NOT NULL,
    updated_at       DATETIME NOT NULL,
    UNIQUE KEY uk_form_field_group (form_id, group_key),
    KEY idx_form_field_group_sort (form_id, input_page_key, parent_group_key, sort_order),
    CONSTRAINT fk_form_field_groups_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- フォーム項目テンプレート
CREATE TABLE IF NOT EXISTS form_field_templates (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    title               VARCHAR(200) NOT NULL,
    fields_json         MEDIUMTEXT NOT NULL,
    field_groups_json   MEDIUMTEXT NOT NULL,
    created_at          DATETIME NOT NULL,
    updated_at          DATETIME NOT NULL,
    KEY idx_form_field_templates_updated (updated_at, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- フォームの版履歴
CREATE TABLE IF NOT EXISTS form_versions (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    form_id             INT NOT NULL,
    version_number      INT NOT NULL,
    action_type         VARCHAR(32) NOT NULL,
    created_by_user_id  INT DEFAULT NULL,
    created_by_name     VARCHAR(100) DEFAULT NULL,
    snapshot_json       MEDIUMTEXT NOT NULL,
    created_at          DATETIME NOT NULL,
    pinned              TINYINT(1) NOT NULL DEFAULT 0,
    UNIQUE KEY uk_form_versions_number (form_id, version_number),
    KEY idx_form_versions_created (form_id, created_at, id),
    KEY idx_form_versions_user (created_by_user_id),
    CONSTRAINT fk_form_versions_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE,
    CONSTRAINT fk_form_versions_user FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- フォームの分岐ルール
CREATE TABLE IF NOT EXISTS form_branch_rules (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    form_id             INT NOT NULL,
    rule_key            VARCHAR(64) NOT NULL,
    sort_order          INT NOT NULL DEFAULT 0,
    trigger_page_key    VARCHAR(64) NOT NULL DEFAULT 'input-1',
    source_field_key    VARCHAR(64) NOT NULL,
    operator            VARCHAR(32) NOT NULL DEFAULT 'equals',
    expected_value      VARCHAR(255) NOT NULL,
    action_type         VARCHAR(32) NOT NULL,
    target_type         VARCHAR(16) NOT NULL DEFAULT 'field',
    target_key          VARCHAR(64) NOT NULL,
    enabled             TINYINT(1) NOT NULL DEFAULT 1,
    created_at          DATETIME NOT NULL,
    updated_at          DATETIME NOT NULL,
    UNIQUE KEY uk_form_branch_rule (form_id, rule_key),
    KEY idx_form_branch_sort (form_id, sort_order),
    KEY idx_form_branch_page_sort (form_id, trigger_page_key, sort_order),
    KEY idx_form_branch_source (form_id, source_field_key),
    CONSTRAINT fk_form_branch_rules_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 送信履歴
CREATE TABLE IF NOT EXISTS submissions (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    form_id          INT NOT NULL,
    ip               VARCHAR(45) DEFAULT NULL,
    user_agent       VARCHAR(255) DEFAULT NULL,
    submitted_at     DATETIME NOT NULL,
    workflow_status  VARCHAR(32) NOT NULL DEFAULT 'pending',
    storage_mode     VARCHAR(20) NOT NULL DEFAULT 'database',
    delivery_route   VARCHAR(16) DEFAULT NULL,
    mail_delivery_status VARCHAR(16) DEFAULT NULL,
    mail_error_code  VARCHAR(64) DEFAULT NULL,
    attachment_count INT UNSIGNED NOT NULL DEFAULT 0,
    attachment_total_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    KEY idx_form_submitted (form_id, submitted_at),
    KEY idx_form_workflow (form_id, workflow_status, submitted_at),
    CONSTRAINT fk_submissions_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 外部HTML向け Embed API 設定（フォーム版管理とは分離）
CREATE TABLE IF NOT EXISTS form_embed_settings (
    form_id                    INT NOT NULL PRIMARY KEY,
    enabled                    TINYINT(1) NOT NULL DEFAULT 0,
    public_page_hidden         TINYINT(1) NOT NULL DEFAULT 0,
    allowed_origins_json       TEXT DEFAULT NULL,
    completion_url             VARCHAR(500) DEFAULT NULL,
    japan_only_enabled         TINYINT(1) NOT NULL DEFAULT 0,
    turnstile_enabled          TINYINT(1) NOT NULL DEFAULT 0,
    turnstile_site_key         VARCHAR(255) DEFAULT NULL,
    turnstile_secret_key       VARCHAR(255) DEFAULT NULL,
    recaptcha_enabled          TINYINT(1) NOT NULL DEFAULT 0,
    recaptcha_site_key         VARCHAR(255) DEFAULT NULL,
    recaptcha_secret_key       VARCHAR(255) DEFAULT NULL,
    recaptcha_v3_enabled       TINYINT(1) NOT NULL DEFAULT 0,
    recaptcha_v3_site_key      VARCHAR(255) DEFAULT NULL,
    recaptcha_v3_secret_key    VARCHAR(255) DEFAULT NULL,
    recaptcha_v3_min_score     DECIMAL(3,2) NOT NULL DEFAULT 0.50,
    rate_limit_count           INT NOT NULL DEFAULT 10,
    rate_limit_window_seconds  INT NOT NULL DEFAULT 600,
    created_at                 DATETIME NOT NULL,
    updated_at                 DATETIME NOT NULL,
    CONSTRAINT fk_form_embed_settings_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 送信元IPの国判定キャッシュ（IPinfo Lite）
CREATE TABLE IF NOT EXISTS ip_country_cache (
    ip            VARCHAR(45) NOT NULL PRIMARY KEY,
    country_code  CHAR(2) NOT NULL,
    checked_at    DATETIME NOT NULL,
    KEY idx_ip_country_checked (checked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Embed API のフォーム×IP固定窓レート制限
CREATE TABLE IF NOT EXISTS public_api_rate_limits (
    form_id            INT NOT NULL,
    ip                 VARCHAR(45) NOT NULL,
    window_started_at  INT UNSIGNED NOT NULL,
    attempt_count      INT UNSIGNED NOT NULL DEFAULT 0,
    updated_at         DATETIME NOT NULL,
    PRIMARY KEY (form_id, ip),
    KEY idx_public_api_rate_updated (updated_at),
    CONSTRAINT fk_public_api_rate_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- メール送信のみモードの匿名配送監査（入力値・IP・宛先・ファイル名は保存しない）
CREATE TABLE IF NOT EXISTS mail_delivery_audits (
    id                     BIGINT AUTO_INCREMENT PRIMARY KEY,
    form_id                INT NOT NULL,
    route                  VARCHAR(16) NOT NULL,
    delivery_status        VARCHAR(16) NOT NULL,
    error_code             VARCHAR(64) DEFAULT NULL,
    attachment_count       INT UNSIGNED NOT NULL DEFAULT 0,
    attachment_total_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_at             DATETIME NOT NULL,
    KEY idx_mail_audit_created (created_at),
    KEY idx_mail_audit_form_created (form_id, created_at),
    CONSTRAINT fk_mail_delivery_audits_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 送信内容（縦持ち）
CREATE TABLE IF NOT EXISTS submission_values (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    submission_id   INT NOT NULL,
    field_key       VARCHAR(64) NOT NULL,
    value           MEDIUMTEXT,
    KEY idx_sub_key (submission_id, field_key),
    CONSTRAINT fk_subval_submission FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- アップロードファイル
CREATE TABLE IF NOT EXISTS submission_files (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    submission_id   INT NOT NULL,
    field_key       VARCHAR(64) NOT NULL,
    file_uuid       CHAR(36) DEFAULT NULL,
    original_name   VARCHAR(255) NOT NULL,
    stored_path     VARCHAR(500) NOT NULL,
    mime_type       VARCHAR(100) DEFAULT NULL,
    size            INT DEFAULT NULL,
    KEY idx_subfile_submission (submission_id),
    UNIQUE KEY uk_submission_files_file_uuid (file_uuid),
    CONSTRAINT fk_subfile_submission FOREIGN KEY (submission_id) REFERENCES submissions(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- アプリ設定（キー・値。例: フォーム作成数上限）
CREATE TABLE IF NOT EXISTS app_settings (
    setting_key   VARCHAR(64) NOT NULL PRIMARY KEY,
    setting_value TEXT NOT NULL,
    created_at    DATETIME NOT NULL,
    updated_at    DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ログイン試行ログ（ブルートフォース対策）
CREATE TABLE IF NOT EXISTS login_attempts (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    ip              VARCHAR(45) NOT NULL,
    username        VARCHAR(64) DEFAULT NULL,
    success         TINYINT(1) NOT NULL DEFAULT 0,
    attempted_at    DATETIME NOT NULL,
    KEY idx_ip_time (ip, attempted_at),
    KEY idx_username_time (username, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
