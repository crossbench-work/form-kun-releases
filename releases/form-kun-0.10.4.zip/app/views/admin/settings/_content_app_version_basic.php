<?php

$showManifestUi = !empty($show_manifest_ui);
$latest = is_array($manifest ?? null) ? (string) ($manifest['latest'] ?? '') : '';
$requirements = is_array($requirements ?? null) ? $requirements : [];
$currentVersionStr = (string) ($currentVersion ?? '');
$serverUpdateAllowed = !empty($requirements['server_update']);
$hasZip = !empty($requirements['zip']);
$canConfirmUpdate = $showManifestUi && $serverUpdateAllowed && $hasZip;
$applyVersion = trim((string) ($update_apply_version ?? ''));
$showApplyButton = $applyVersion !== '' && $canConfirmUpdate;

$versionHelp = '';
if ($latest !== '' && $latest !== $currentVersionStr) {
    $versionHelp .= '<p class="text is-help">最新リリース: ' . e($latest) . '</p>';
}

$versionActionHtml = '';
ob_start();
if ($canConfirmUpdate || ($hasZip && $showManifestUi)) {
    if ($canConfirmUpdate): ?>
        <form method="post" action="<?= e(base_path('/admin/settings/update-check')) ?>">
            <?= \Core\Csrf::field() ?>
            <?php admin_m_btn01_button_wrap('更新確認', ['type' => 'submit', 'class' => 'is-primary']); ?>
        </form>
    <?php endif;
    if ($hasZip) {
        admin_m_btn01_button_wrap('手動更新', [
            'type' => 'button',
            'class' => 'is-outline',
            'data-target' => 'settings-manual-update-open',
        ]);
    }
} elseif ($hasZip && !$showManifestUi) {
    admin_m_btn01_button_wrap('手動更新', [
        'type' => 'button',
        'class' => 'is-outline',
        'data-target' => 'settings-manual-update-open',
    ]);
}
$versionActionHtml = trim((string) ob_get_clean());

?>
<span id="app-update-manual" hidden aria-hidden="true"></span>
<p class="text is-value" id="settings_update_current_version"><?= e($currentVersionStr) ?></p>
<?php if ($versionHelp !== ''): ?>
    <div class="area is-help"><?= $versionHelp ?></div>
<?php endif; ?>
<?php if ($versionActionHtml !== ''): ?>
    <div class="area is-actions"><?= $versionActionHtml ?></div>
<?php endif; ?>

    <?php if ($showManifestUi && ($manifestError ?? '') !== ''): ?>
        <p data-module="m-text01" data-type="danger"><?= e($manifestError) ?></p>
    <?php endif; ?>

    <?php if ($showManifestUi && !$serverUpdateAllowed): ?>
        <p data-module="m-text01" data-type="muted">サーバーからの更新は無効です。<code>config.local.php</code> の <code>update.enabled</code> を確認してください。</p>
    <?php elseif ($showManifestUi && !$hasZip): ?>
        <p data-module="m-text01" data-type="danger">ZipArchive 拡張が無効のため、サーバーからの更新は利用できません。</p>
    <?php endif; ?>

    <?php if ($showApplyButton): ?>
        <div class="block is-actions">
            <form method="post" action="<?= e(base_path('/admin/settings/update')) ?>" onsubmit="return confirm('バージョン <?= e($applyVersion) ?> に更新します。よろしいですか？');">
                <?= \Core\Csrf::field() ?>
                <input type="hidden" name="version" value="<?= e($applyVersion) ?>">
                <?php admin_m_btn01_button_wrap('アップデート', ['type' => 'submit', 'class' => 'is-success']); ?>
            </form>
        </div>
        <p class="text is-help">ZIP には環境設定を含めません。更新前にバックアップを推奨します。</p>
    <?php endif; ?>
