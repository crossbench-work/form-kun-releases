<?php
namespace Core;

use Core\Validator;
use Models\FormBranchRule;
use Models\FormEmbedSetting;
use Models\FormField;
use Models\FormInputPage;

class EmbedCodeSample
{
    public static function generateCss(): string
    {
        return <<<'CSS'
.embed-form {
  max-width: 640px;
  margin: 0 auto;
  font-family: -apple-system, BlinkMacSystemFont, "Hiragino Sans", "Noto Sans JP", sans-serif;
  line-height: 1.6;
  color: #1d2430;
}
.embed-form .field {
  margin-bottom: 16px;
}
.embed-form label {
  display: block;
  font-weight: 600;
  font-size: 14px;
  margin-bottom: 4px;
}
.embed-form .req {
  color: #c0392b;
  font-weight: 400;
  font-size: 12px;
  margin-left: 4px;
}
.embed-form input[type="text"],
.embed-form input[type="email"],
.embed-form input[type="tel"],
.embed-form input[type="url"],
.embed-form input[type="number"],
.embed-form input[type="date"],
.embed-form input[type="time"],
.embed-form textarea,
.embed-form select {
  width: 100%;
  padding: 8px 10px;
  border: 1px solid #d9dde3;
  border-radius: 6px;
  font: inherit;
  font-size: 14px;
  box-sizing: border-box;
}
.embed-form textarea {
  min-height: 100px;
  resize: vertical;
}
.embed-form .choices {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 16px;
}
.embed-form .choices label {
  font-weight: 400;
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0;
}
.embed-form [hidden] {
  display: none !important;
}
.embed-form .embed-step {
  margin: 0;
  padding: 0;
  border: 0;
  min-width: 0;
}
.embed-form .embed-step legend,
.embed-form .embed-step h2 {
  margin: 0 0 16px;
  padding: 0;
  font-size: 18px;
  font-weight: 700;
}
.embed-form .embed-confirm {
  margin: 0 0 20px;
  border-top: 1px solid #d9dde3;
}
.embed-form .embed-confirm dt {
  padding: 10px 0 2px;
  font-size: 13px;
  font-weight: 600;
  color: #667085;
}
.embed-form .embed-confirm dd {
  margin: 0;
  padding: 0 0 10px;
  border-bottom: 1px solid #d9dde3;
  white-space: pre-wrap;
  word-break: break-word;
}
.embed-form .embed-errors {
  margin: 0 0 16px;
  padding: 10px 12px 10px 28px;
  border: 1px solid #f1c0ba;
  border-radius: 6px;
  background: #fdf0ee;
  color: #c0392b;
  font-size: 13px;
}
.embed-form .embed-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 20px;
}
.embed-form .embed-actions button {
  font: inherit;
  font-size: 14px;
  padding: 9px 18px;
  border-radius: 6px;
  border: 1px solid #2f6fd0;
  background: #2f6fd0;
  color: #fff;
  cursor: pointer;
}
.embed-form .embed-actions button.is-back {
  background: #fff;
  color: #2f6fd0;
}
.embed-form .embed-actions button:disabled {
  opacity: 0.55;
  cursor: progress;
}
CSS;
    }

    /**
     * 入力画面ごとのステップ（次へ / 戻る）と確認ステップを持つ埋め込み HTML。
     *
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $fieldGroups
     * @param array<int, array<string, mixed>> $inputPages
     * @param array<string, string> $captchaContext turnstile_site_key, recaptcha_site_key
     * @param array<string, mixed> $form 確認画面の見出し・文言・ボタン名
     */
    public static function generateFormHtml(
        array $fields,
        array $fieldGroups,
        array $inputPages,
        string $captchaProvider,
        array $captchaContext = [],
        array $form = []
    ): string {
        $ordered = self::embeddableFields($fields, $fieldGroups, $inputPages);
        if ($ordered === []) {
            return '';
        }

        $pageTitles = self::pageTitleMap($inputPages, $fields, $fieldGroups);
        $pageKeys = array_keys($pageTitles);
        $multiPage = count($pageKeys) > 1;
        $pageMeta = self::pageMetaMap($inputPages);
        $groupParents = self::groupParentMap($fieldGroups);

        $fieldsByPage = [];
        foreach ($ordered as $field) {
            $pageKey = FormField::sanitizeInputPageKey((string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
            $fieldsByPage[$pageKey][] = $field;
        }

        $lines = [
            '<form id="contact-form" class="embed-form" method="post" action="#" novalidate>',
            '  <ul class="embed-errors" data-target="errors" hidden></ul>',
        ];

        foreach ($pageKeys as $index => $pageKey) {
            $lines[] = '';
            $lines[] = '  <fieldset class="embed-step" data-step="' . self::escapeHtml((string) $pageKey) . '"' . ($index > 0 ? ' hidden disabled' : '') . '>';
            if ($multiPage) {
                $lines[] = '    <legend>' . self::escapeHtml($pageTitles[$pageKey]) . '</legend>';
            }
            foreach ($fieldsByPage[$pageKey] ?? [] as $field) {
                foreach (self::stepFieldLines($field, $groupParents) as $line) {
                    $lines[] = '  ' . $line;
                }
            }
            $buttonText = trim((string) ($pageMeta[$pageKey]['button_text'] ?? ''));
            $backText = trim((string) ($pageMeta[$pageKey]['back_button_text'] ?? ''));
            $lines[] = '    <div class="embed-actions">';
            if ($index > 0) {
                $lines[] = '      <button type="button" class="is-back" data-action="back">' . self::escapeHtml($backText !== '' ? $backText : '戻る') . '</button>';
            }
            $lines[] = '      <button type="button" data-action="next">' . self::escapeHtml($buttonText !== '' ? $buttonText : '次へ') . '</button>';
            $lines[] = '    </div>';
            $lines[] = '  </fieldset>';
        }

        $confirmTitle = trim((string) ($form['confirm_page_title'] ?? ''));
        $submitText = trim((string) ($form['submit_button_text'] ?? ''));
        $backText = trim((string) ($form['back_button_text'] ?? ''));
        $lines[] = '';
        $lines[] = '  <section class="embed-step" data-step="confirm" hidden>';
        $lines[] = '    <h2>' . self::escapeHtml($confirmTitle !== '' ? $confirmTitle : '入力内容のご確認') . '</h2>';
        foreach (self::confirmMessages($form) as $message) {
            $lines[] = '    <p>' . self::escapeHtml($message) . '</p>';
        }
        $lines[] = '    <dl class="embed-confirm" data-target="confirm-list"></dl>';
        $captchaBlock = self::captchaBlock($captchaProvider, $captchaContext);
        if ($captchaBlock !== '') {
            $lines[] = '  ' . $captchaBlock;
        }
        $lines[] = '    <div class="embed-actions">';
        $lines[] = '      <button type="button" class="is-back" data-action="back">' . self::escapeHtml($backText !== '' ? $backText : '入力に戻る') . '</button>';
        $lines[] = '      <button type="submit">' . self::escapeHtml($submitText !== '' ? $submitText : '送信する') . '</button>';
        $lines[] = '    </div>';
        $lines[] = '  </section>';
        $lines[] = '</form>';

        return implode("\n", $lines);
    }

    /**
     * 埋め込み HTML と同じ画面順・分岐ルール・ラベルを使って送信用 JavaScript を組み立てる。
     *
     * @param array<int, array<string, mixed>> $fields
     * @param array<int, array<string, mixed>> $fieldGroups
     * @param array<int, array<string, mixed>> $inputPages
     * @param array<int, array<string, mixed>> $branchRules
     */
    public static function generateScript(
        array $fields,
        array $fieldGroups,
        array $inputPages,
        array $branchRules,
        string $captchaProvider,
        string $apiUrl,
        string $recaptchaV3SiteKey = ''
    ): string {
        $ordered = self::embeddableFields($fields, $fieldGroups, $inputPages);
        if ($apiUrl === '' || $ordered === []) {
            return '';
        }

        $labels = [];
        foreach ($ordered as $field) {
            $key = trim((string) ($field['field_key'] ?? ''));
            if ($key !== '') {
                $label = trim((string) ($field['label'] ?? ''));
                $labels[$key] = $label !== '' ? $label : $key;
            }
        }
        $rules = [];
        foreach (FormBranchRule::normalizeRules($branchRules) as $rule) {
            if (empty($rule['enabled'])) {
                continue;
            }
            $rules[] = [
                'page' => (string) $rule['trigger_page_key'],
                'source' => (string) $rule['source_field_key'],
                'expected' => (string) $rule['expected_value'],
                'action' => (string) $rule['action_type'],
                'targetType' => (string) $rule['target_type'],
                'target' => (string) $rule['target_key'],
            ];
        }
        $config = [
            'pages' => array_keys(self::pageTitleMap($inputPages, $fields, $fieldGroups)),
            'rules' => $rules,
            'labels' => $labels,
        ];
        $json = static fn($value): string => (string) json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $resetCaptcha = match ($captchaProvider) {
            FormEmbedSetting::CAPTCHA_TURNSTILE => "  window.turnstile?.reset();\n",
            FormEmbedSetting::CAPTCHA_RECAPTCHA_V2 => "  window.grecaptcha?.reset();\n",
            default => '',
        };
        $widgetCaptcha = in_array($captchaProvider, [FormEmbedSetting::CAPTCHA_TURNSTILE, FormEmbedSetting::CAPTCHA_RECAPTCHA_V2], true);
        $tokenLines = '';
        if ($captchaProvider === FormEmbedSetting::CAPTCHA_RECAPTCHA_V3) {
            $tokenLines = "    await new Promise((resolve) => grecaptcha.ready(resolve));\n"
                . '    const token = await grecaptcha.execute(' . $json($recaptchaV3SiteKey) . ", { action: 'submit' });\n";
        }
        $tokenSet = $tokenLines !== '' ? "    formData.set('g-recaptcha-response', token);\n" : '';

        $script = <<<'JS'
const FORMKUN = __CONFIG__;
const API_URL = __API_URL__;
const WIDGET_CAPTCHA = __WIDGET_CAPTCHA__;

const form = document.querySelector('#contact-form');
const steps = Array.from(form.querySelectorAll('.embed-step'));
const errorsBox = form.querySelector('[data-target="errors"]');
let deliveryId = crypto.randomUUID();
let trail = [FORMKUN.pages[0]];

const current = () => trail[trail.length - 1];
const stepOf = (key) => steps.find((step) => step.dataset.step === key);

function values() {
  const out = {};
  new FormData(form).forEach((value, name) => {
    const key = name.replace(/\[.*$/, '');
    (out[key] ??= []).push(value instanceof File ? value.name : String(value).trim());
  });
  return out;
}

function matches(rule, vals) {
  return (vals[rule.source] || []).includes(rule.expected);
}

function syncDisabled() {
  steps.forEach((step) => {
    if (step.tagName === 'FIELDSET') {
      step.disabled = !trail.includes(step.dataset.step);
    }
  });
}

function applyVisibility() {
  const vals = values();
  FORMKUN.pages.forEach((page) => {
    const rules = FORMKUN.rules.filter((rule) => rule.page === page && rule.action === 'show_field');
    if (!rules.length) return;
    const controlled = { field: new Set(), group: new Set() };
    const shown = { field: new Set(), group: new Set() };
    rules.forEach((rule) => {
      const type = rule.targetType === 'group' ? 'group' : 'field';
      controlled[type].add(rule.target);
      if (matches(rule, vals)) shown[type].add(rule.target);
    });
    stepOf(page)?.querySelectorAll('[data-field-key]').forEach((el) => {
      const groups = (el.dataset.groups || '').split(' ').filter(Boolean);
      const hidden = (controlled.field.has(el.dataset.fieldKey) && !shown.field.has(el.dataset.fieldKey))
        || groups.some((group) => controlled.group.has(group) && !shown.group.has(group));
      el.hidden = hidden;
      el.querySelectorAll('input, select, textarea').forEach((input) => { input.disabled = hidden; });
    });
  });
}

function renderConfirm() {
  const list = form.querySelector('[data-target="confirm-list"]');
  const vals = values();
  list.replaceChildren();
  Object.entries(FORMKUN.labels).forEach(([key, label]) => {
    if (!(key in vals)) return;
    const filled = vals[key].filter((value) => value !== '');
    const dt = document.createElement('dt');
    const dd = document.createElement('dd');
    dt.textContent = label;
    dd.textContent = filled.length ? filled.join('、') : '（未入力）';
    list.append(dt, dd);
  });
}

function show(key, scroll = true) {
  syncDisabled();
  applyVisibility();
  steps.forEach((step) => { step.hidden = step.dataset.step !== key; });
  if (key === 'confirm') renderConfirm();
  if (scroll) form.scrollIntoView({ block: 'start', behavior: 'smooth' });
}

function nextStepKey(page) {
  const vals = values();
  const jump = FORMKUN.rules.find((rule) => rule.page === page && rule.action === 'go_to_screen' && rule.target !== page && matches(rule, vals));
  if (jump && (FORMKUN.pages.includes(jump.target) || jump.target === 'thanks')) return jump.target;
  if (jump) return 'confirm';
  return FORMKUN.pages[FORMKUN.pages.indexOf(page) + 1] ?? 'confirm';
}

function goNext() {
  const page = current();
  const fields = Array.from(stepOf(page).querySelectorAll('input, select, textarea'));
  if (!fields.every((field) => field.reportValidity())) return;
  const next = nextStepKey(page);
  if (next === 'thanks' && !WIDGET_CAPTCHA) {
    send();
    return;
  }
  trail.push(next === 'thanks' ? 'confirm' : next);
  show(current());
}

function goBack() {
  if (trail.length > 1) trail.pop();
  show(current());
}

function showErrors(result) {
  const messages = [];
  const keys = [];
  const walk = (value, key) => {
    if (typeof value === 'string') {
      messages.push(value);
      keys.push(key);
    } else if (value && typeof value === 'object') {
      Object.values(value).forEach((item) => walk(item, key));
    }
  };
  Object.entries(result.errors ?? {}).forEach(([key, value]) => walk(value, key));
  if (!messages.length && result.message) messages.push(result.message);
  errorsBox.replaceChildren(...messages.map((message) => Object.assign(document.createElement('li'), { textContent: message })));
  errorsBox.hidden = !messages.length;
  const target = keys.map((key) => form.querySelector(`[data-field-key="${CSS.escape(key)}"]`)).find(Boolean);
  const step = target?.closest('.embed-step')?.dataset.step;
  if (step && trail.includes(step)) {
    trail = trail.slice(0, trail.indexOf(step) + 1);
  }
  show(current());
}

async function send() {
  const submitButton = form.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  try {
    syncDisabled();
__TOKEN_LINES__    const formData = new FormData(form);
    formData.set('delivery_id', deliveryId);
__TOKEN_SET__    const response = await fetch(API_URL, {
      method: 'POST',
      body: formData,
    });
    const result = await response.json();

    if (!response.ok) {
__RESET_INNER__      showErrors(result);
      return;
    }
    if (result.redirect_url) {
      window.location.assign(result.redirect_url);
      return;
    }
    deliveryId = crypto.randomUUID();
    form.reset();
__RESET_INNER__    errorsBox.hidden = true;
    trail = [FORMKUN.pages[0]];
    show(current());
  } catch (error) {
    console.error(error);
    showErrors({ message: '送信できませんでした。時間をおいて再度お試しください。' });
  } finally {
    submitButton.disabled = false;
  }
}

form.addEventListener('click', (event) => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  if (button.dataset.action === 'next') goNext();
  if (button.dataset.action === 'back') goBack();
});
form.addEventListener('input', applyVisibility);
form.addEventListener('change', applyVisibility);
form.addEventListener('submit', (event) => {
  event.preventDefault();
  if (current() === 'confirm') {
    send();
  } else {
    goNext();
  }
});

show(current(), false);
JS;

        $resetInner = $resetCaptcha !== '' ? '    ' . $resetCaptcha : '';
        return str_replace(
            ['__CONFIG__', '__API_URL__', '__WIDGET_CAPTCHA__', '__TOKEN_LINES__', '__TOKEN_SET__', '__RESET_INNER__'],
            [$json($config), $json($apiUrl), $widgetCaptcha ? 'true' : 'false', $tokenLines, $tokenSet, $resetInner],
            $script
        );
    }

    /**
     * 公開時に表示される入力項目（非表示の項目・グループ配下を除く）。
     *
     * @return array<int, array<string, mixed>>
     */
    private static function embeddableFields(array $fields, array $fieldGroups, array $inputPages): array
    {
        $hiddenGroups = [];
        foreach ($fieldGroups as $group) {
            if (empty($group['visible'])) {
                $hiddenGroups[(string) ($group['group_key'] ?? '')] = true;
            }
        }
        $groupParents = self::groupParentMap($fieldGroups);
        $out = [];
        foreach (FormField::orderedSubmittable($fields, $fieldGroups, $inputPages, false) as $field) {
            foreach (self::groupChain($field, $groupParents) as $groupKey) {
                if (isset($hiddenGroups[$groupKey])) {
                    continue 2;
                }
            }
            $out[] = $field;
        }
        return $out;
    }

    /** @return array<string, string> group_key => parent_group_key */
    private static function groupParentMap(array $fieldGroups): array
    {
        $map = [];
        foreach ($fieldGroups as $group) {
            $key = (string) ($group['group_key'] ?? '');
            if ($key !== '') {
                $map[$key] = (string) ($group['parent_group_key'] ?? '');
            }
        }
        return $map;
    }

    /** @return list<string> 項目が属するグループ（親を含む） */
    private static function groupChain(array $field, array $groupParents): array
    {
        $chain = [];
        $key = (string) ($field['parent_group_key'] ?? '');
        while ($key !== '' && !in_array($key, $chain, true)) {
            $chain[] = $key;
            $key = $groupParents[$key] ?? '';
        }
        return $chain;
    }

    /** @return array<string, array<string, mixed>> */
    private static function pageMetaMap(array $inputPages): array
    {
        $map = [];
        foreach ($inputPages as $page) {
            $pageKey = FormInputPage::sanitizePageKey((string) ($page['page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($pageKey !== '') {
                $map[$pageKey] = $page;
            }
        }
        return $map;
    }

    /** @return list<string> */
    private static function confirmMessages(array $form): array
    {
        if (!function_exists('decode_form_description_blocks')) {
            return [];
        }
        $messages = [];
        foreach (decode_form_description_blocks($form['confirm_message'] ?? '', true) as $block) {
            if (is_array($block) && array_key_exists('visible', $block) && empty($block['visible'])) {
                continue;
            }
            $text = trim(html_entity_decode(strip_tags((string) ($block['html'] ?? '')), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
            if ($text !== '') {
                $messages[] = $text;
            }
        }
        return $messages;
    }

    /** @return list<string> */
    private static function stepFieldLines(array $field, array $groupParents): array
    {
        $lines = self::fieldLines($field);
        if ($lines === []) {
            return [];
        }
        $attrs = ' data-field-key="' . self::escapeHtml(trim((string) ($field['field_key'] ?? ''))) . '"';
        $groups = self::groupChain($field, $groupParents);
        if ($groups !== []) {
            $attrs .= ' data-groups="' . self::escapeHtml(implode(' ', $groups)) . '"';
        }
        $lines[0] = str_replace('<div class="field">', '<div class="field"' . $attrs . '>', $lines[0]);
        return $lines;
    }

    /** @param array<int, array<string, mixed>> $inputPages @return array<string, string> */
    private static function pageTitleMap(array $inputPages, array $fields, array $fieldGroups): array
    {
        $titles = [];
        foreach ($inputPages as $index => $page) {
            $pageKey = FormInputPage::sanitizePageKey((string) ($page['page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($pageKey === '') {
                continue;
            }
            $title = trim((string) ($page['title'] ?? ''));
            $titles[$pageKey] = $title !== '' ? $title : '入力画面 ' . ((int) $index + 1);
        }
        foreach ($fields as $field) {
            $pageKey = FormField::sanitizeInputPageKey((string) ($field['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($pageKey !== '' && !isset($titles[$pageKey])) {
                $titles[$pageKey] = $pageKey;
            }
        }
        foreach ($fieldGroups as $group) {
            $pageKey = FormField::sanitizeInputPageKey((string) ($group['input_page_key'] ?? FormInputPage::DEFAULT_KEY));
            if ($pageKey !== '' && !isset($titles[$pageKey])) {
                $titles[$pageKey] = $pageKey;
            }
        }
        return $titles;
    }

    /** @param array<string, string> $captchaContext */
    private static function captchaBlock(string $captchaProvider, array $captchaContext): string
    {
        if ($captchaProvider === FormEmbedSetting::CAPTCHA_TURNSTILE) {
            $siteKey = trim((string) ($captchaContext['turnstile_site_key'] ?? 'YOUR_TURNSTILE_SITE_KEY'));
            if ($siteKey === '') {
                $siteKey = 'YOUR_TURNSTILE_SITE_KEY';
            }
            return '  <div class="cf-turnstile" data-sitekey="' . self::escapeHtml($siteKey) . '"></div>';
        }
        if ($captchaProvider === FormEmbedSetting::CAPTCHA_RECAPTCHA_V2) {
            $siteKey = trim((string) ($captchaContext['recaptcha_site_key'] ?? 'YOUR_RECAPTCHA_SITE_KEY'));
            if ($siteKey === '') {
                $siteKey = 'YOUR_RECAPTCHA_SITE_KEY';
            }
            return '  <div class="g-recaptcha" data-sitekey="' . self::escapeHtml($siteKey) . '"></div>';
        }
        return '';
    }

    /** @param array<string, mixed> $field @return list<string> */
    private static function fieldLines(array $field): array
    {
        $key = trim((string) ($field['field_key'] ?? ''));
        if ($key === '') {
            return [];
        }
        $type = FormField::normalizeType((string) ($field['type'] ?? 'text'));
        $label = trim((string) ($field['label'] ?? $key));
        $req = !empty($field['required']);
        $reqMark = $req ? ' <span class="req">(必須)</span>' : '';
        $ph = self::escapeHtml(trim((string) ($field['placeholder'] ?? '')));
        $reqAttr = $req ? ' required' : '';

        $open = '  <div class="field">';
        $labelLine = '    <label for="f_' . self::escapeHtml($key) . '">' . self::escapeHtml($label) . $reqMark . '</label>';

        $simpleInputTypes = ['text', 'email', 'tel', 'url', 'number', 'time'];
        if (in_array($type, $simpleInputTypes, true)) {
            $inputType = $type === 'url' ? 'url' : $type;
            return [
                $open,
                $labelLine,
                '    <input type="' . self::escapeHtml($inputType) . '" id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '"' . ($ph !== '' ? ' placeholder="' . $ph . '"' : '') . $reqAttr . '>',
                '  </div>',
            ];
        }

        if ($type === 'date') {
            return [
                $open,
                $labelLine,
                '    <input type="date" id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '"' . $reqAttr . '>',
                '  </div>',
            ];
        }

        if ($type === 'textarea') {
            return [
                $open,
                $labelLine,
                '    <textarea id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '" rows="6"' . ($ph !== '' ? ' placeholder="' . $ph . '"' : '') . $reqAttr . '></textarea>',
                '  </div>',
            ];
        }

        if ($type === 'select') {
            $opts = Validator::decodeOptions($field['options_json'] ?? null);
            $lines = [$open, $labelLine, '    <select id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '"' . $reqAttr . '>'];
            $lines[] = '      <option value="">選択してください</option>';
            foreach ($opts as $opt) {
                $opt = (string) $opt;
                $lines[] = '      <option value="' . self::escapeHtml($opt) . '">' . self::escapeHtml($opt) . '</option>';
            }
            $lines[] = '    </select>';
            $lines[] = '  </div>';
            return $lines;
        }

        if ($type === 'radio') {
            $settings = FormField::decodeChoiceSettings($field['options_json'] ?? null);
            $opts = is_array($settings['options'] ?? null) ? $settings['options'] : [];
            $lines = [$open, '    <span class="label">' . self::escapeHtml($label) . $reqMark . '</span>', '    <div class="choices">'];
            foreach ($opts as $opt) {
                $opt = (string) $opt;
                $lines[] = '      <label><input type="radio" name="' . self::escapeHtml($key) . '" value="' . self::escapeHtml($opt) . '"> ' . self::escapeHtml($opt) . '</label>';
            }
            $lines[] = '    </div>';
            $lines[] = '  </div>';
            return $lines;
        }

        if ($type === 'checkbox') {
            $settings = FormField::decodeCheckboxSettings($field['options_json'] ?? null);
            $opts = is_array($settings['options'] ?? null) ? $settings['options'] : [];
            $lines = [$open, '    <span class="label">' . self::escapeHtml($label) . $reqMark . '</span>', '    <div class="choices">'];
            foreach ($opts as $opt) {
                $opt = (string) $opt;
                $lines[] = '      <label><input type="checkbox" name="' . self::escapeHtml($key) . '[]" value="' . self::escapeHtml($opt) . '"> ' . self::escapeHtml($opt) . '</label>';
            }
            $lines[] = '    </div>';
            $lines[] = '  </div>';
            return $lines;
        }

        if ($type === 'text_multi') {
            $items = FormField::decodeTextMultiItems($field['options_json'] ?? null, true);
            $count = max(1, count($items));
            $lines = [$open, $labelLine];
            for ($i = 0; $i < $count; $i++) {
                $lines[] = '    <input type="text" id="f_' . self::escapeHtml($key) . '_' . $i . '" name="' . self::escapeHtml($key) . '[items][]"' . $reqAttr . '>';
            }
            $lines[] = '  </div>';
            return $lines;
        }

        if ($type === 'file') {
            $fileSettings = FormField::decodeFileSettings($field['options_json'] ?? null);
            $exts = is_array($fileSettings['allowed_extensions'] ?? null) ? $fileSettings['allowed_extensions'] : [];
            $accept = $exts !== [] ? ' accept="' . self::escapeHtml('.' . implode(',.', array_map('strval', $exts))) . '"' : '';
            return [
                $open,
                $labelLine,
                '    <input type="file" id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '"' . $accept . $reqAttr . '>',
                '  </div>',
            ];
        }

        if (in_array($type, ['address', 'text_pair', FormField::TYPE_POSTAL_CODE, FormField::TYPE_MATRIX], true)) {
            $typeLabel = $type;
            return [
                $open,
                '    <!-- タイプ ' . self::escapeHtml($typeLabel) . ': 公開フォームのマークアップを参照 -->',
                $labelLine,
                '    <input type="text" id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '" placeholder="（サンプル）"' . $reqAttr . '>',
                '  </div>',
            ];
        }

        return [
            $open,
            $labelLine,
            '    <input type="text" id="f_' . self::escapeHtml($key) . '" name="' . self::escapeHtml($key) . '"' . $reqAttr . '>',
            '  </div>',
        ];
    }

    private static function escapeHtml(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
