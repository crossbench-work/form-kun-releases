<?php
// app/core/helpers.php

if (!function_exists('e')) {
    /**
     * HTML エスケープ。
     */
    function e($value): string
    {
        if ($value === null) {
            return '';
        }
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('uuid_v4')) {
    function uuid_v4(): string
    {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
        $hex = bin2hex($data);

        return substr($hex, 0, 8) . '-'
            . substr($hex, 8, 4) . '-'
            . substr($hex, 12, 4) . '-'
            . substr($hex, 16, 4) . '-'
            . substr($hex, 20, 12);
    }
}

if (!function_exists('is_uuid_v4')) {
    function is_uuid_v4(string $value): bool
    {
        return preg_match(
            '/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i',
            $value
        ) === 1;
    }
}

if (!function_exists('config')) {
    /**
     * ドット区切りで設定を取得。
     */
    function config(string $key, $default = null)
    {
        $cfg = FORMKUN_CONFIG;
        foreach (explode('.', $key) as $k) {
            if (is_array($cfg) && array_key_exists($k, $cfg)) {
                $cfg = $cfg[$k];
            } else {
                return $default;
            }
        }
        return $cfg;
    }
}

if (!function_exists('effective_max_forms')) {
    /**
     * 作成できるフォーム数の上限。
     * 管理画面の設定で DB に保存した値が有効ならそれを使い、なければ config の limits.max_forms（既定 50）。
     */
    function effective_max_forms(): int
    {
        $fallback = (int) config('limits.max_forms', 50);
        if ($fallback < 1) {
            $fallback = 50;
        }
        $raw = \Models\AppSetting::get(\Models\AppSetting::KEY_MAX_FORMS);
        if ($raw !== null && $raw !== '') {
            $n = (int) $raw;
            if ($n >= 1) {
                return min($n, 999999);
            }
        }
        return min($fallback, 999999);
    }
}

if (!function_exists('effective_max_site_resource_bytes')) {
    /**
     * サイトリソース（添付ファイル + DB）の使用量上限（bytes）。
     * 管理画面の設定で DB に保存した値が有効ならそれを使い、なければ config の limits.max_site_resource_bytes。
     */
    function effective_max_site_resource_bytes(): int
    {
        $min = 1024 * 1024;
        $max = 1024 * 1024 * 1024 * 1024;
        $fallback = (int) config('limits.max_site_resource_bytes', 2 * 1024 * 1024 * 1024);
        if ($fallback < $min) {
            $fallback = $min;
        }
        $raw = \Models\AppSetting::get(\Models\AppSetting::KEY_MAX_SITE_RESOURCE_BYTES);
        if ($raw !== null && $raw !== '') {
            $n = (int) $raw;
            if ($n >= $min) {
                return min($n, $max);
            }
        }
        return min($fallback, $max);
    }
}

if (!function_exists('settings_show_active_forms_list')) {
    /**
     * @deprecated 公開中フォーム一覧は廃止。常に false。
     */
    function settings_show_active_forms_list(): bool
    {
        return false;
    }
}

if (!function_exists('settings_active_forms_list_redirect_url')) {
    /**
     * 公開サイト URL（/ へアクセスしたときの 302 先）。未設定時は空文字。
     */
    function settings_active_forms_list_redirect_url(): string
    {
        $raw = \Models\AppSetting::get(\Models\AppSetting::KEY_ACTIVE_FORMS_LIST_REDIRECT_URL);
        return $raw !== null ? trim($raw) : '';
    }
}

if (!function_exists('settings_public_site_url')) {
    function settings_public_site_url(): string
    {
        return settings_active_forms_list_redirect_url();
    }
}

if (!function_exists('remember_public_form_return_path')) {
    /**
     * 公開フォーム入力中の戻り先（/ 未設定時）をセッションに記録する。
     */
    function remember_public_form_return_path(string $slug): void
    {
        $slug = trim($slug);
        if ($slug === '') {
            return;
        }
        $path = base_path('/f/' . $slug);
        if (!is_public_form_return_path($path)) {
            return;
        }
        $_SESSION['formkun_public_form_return_path'] = $path;
    }
}

if (!function_exists('remembered_public_form_return_path')) {
    /**
     * 記録済みの公開フォーム URL。不正な値は破棄して空を返す。
     */
    function remembered_public_form_return_path(): string
    {
        $path = trim((string) ($_SESSION['formkun_public_form_return_path'] ?? ''));
        if ($path === '') {
            return '';
        }
        if (!is_public_form_return_path($path)) {
            unset($_SESSION['formkun_public_form_return_path']);
            return '';
        }
        return $path;
    }
}

if (!function_exists('is_public_form_return_path')) {
    function is_public_form_return_path(string $path): bool
    {
        $path = trim($path);
        if ($path === '') {
            return false;
        }
        $prefix = base_path('/f/');
        if ($prefix === '' || strpos($path, $prefix) !== 0) {
            return false;
        }
        $rest = substr($path, strlen($prefix));
        if ($rest === '' || str_contains($rest, '..') || str_contains($rest, '//')) {
            return false;
        }
        return (bool) preg_match('#^[\w\-]+$#', $rest);
    }
}

if (!function_exists('effective_holidays_jp_fetch_interval_days')) {
    function effective_holidays_jp_fetch_interval_days(): int
    {
        $raw = \Models\AppSetting::get(\Models\AppSetting::KEY_HOLIDAYS_JP_FETCH_INTERVAL_DAYS);
        if ($raw !== null && $raw !== '') {
            $n = (int) $raw;
            if ($n >= 1 && $n <= 3650) {
                return $n;
            }
        }

        return 365;
    }
}

if (!function_exists('japanese_holidays_map')) {
    /**
     * @return array<string, string>
     */
    function japanese_holidays_map(): array
    {
        return \Core\JapaneseHolidays::load();
    }
}

if (!function_exists('japanese_holidays_is_holiday')) {
    function japanese_holidays_is_holiday(string $dateYmd): bool
    {
        $dateYmd = trim($dateYmd);
        if ($dateYmd === '') {
            return false;
        }

        return array_key_exists($dateYmd, japanese_holidays_map());
    }
}

if (!function_exists('effective_update_enabled')) {
    /**
     * アプリ自己更新の有効フラグ。DB（app_settings）があれば優先、なければ config（config.local 含む）。
     */
    function effective_update_enabled(): bool
    {
        return (bool) config('update.enabled', true);
    }
}

if (!function_exists('effective_update_manifest_url')) {
    /**
     * manifest.json の URL（config / config.local のみ）。
     */
    function effective_update_manifest_url(): string
    {
        return trim((string) config('update.manifest_url', ''));
    }
}

if (!function_exists('update_releases_page_url')) {
    /** GitHub Pages のリリース一覧 URL */
    function update_releases_page_url(): string
    {
        $url = trim((string) config('update.releases_page_url', ''));
        return $url !== '' ? $url : 'https://crossbench-work.github.io/form-kun-releases/';
    }
}

if (!function_exists('is_image_mime_type')) {
    function is_image_mime_type(?string $mime): bool
    {
        $mime = strtolower(trim((string) $mime));
        return $mime !== '' && str_starts_with($mime, 'image/');
    }
}

if (!function_exists('submission_file_extension')) {
    /** @param array<string, mixed> $file */
    function submission_file_extension(array $file): string
    {
        foreach (['stored_path', 'path', 'original_name'] as $key) {
            $ext = strtolower(pathinfo((string) ($file[$key] ?? ''), PATHINFO_EXTENSION));
            if ($ext !== '') {
                return $ext;
            }
        }
        return '';
    }
}

if (!function_exists('is_safe_inline_submission_file')) {
    /** @param array<string, mixed> $file */
    function is_safe_inline_submission_file(array $file): bool
    {
        $extension = submission_file_extension($file);
        if ($extension === '') {
            return false;
        }
        $mime = trim((string) ($file['mime_type'] ?? ''));
        if ($mime !== '' && \Core\FileTypePolicy::isSafeInlineImage($extension, $mime)) {
            return true;
        }
        return \Core\FileTypePolicy::expectedInlineImageMime($extension) !== null;
    }
}

if (!function_exists('submission_file_serving_mime')) {
    /**
     * 添付ファイル配信用 MIME と inline 可否（DB 保存 MIME を finfo 弱い場合のフォールバックに使う）。
     *
     * @param array<string, mixed> $file submission_files 行または同等
     * @return array{mime: string, inline_ok: bool, mime_matches: bool}
     */
    function submission_file_serving_mime(array $file, string $absolutePath): array
    {
        $extension = strtolower(pathinfo((string) ($file['stored_path'] ?? ''), PATHINFO_EXTENSION));
        if ($extension === '') {
            $extension = submission_file_extension($file);
        }
        $detected = \Core\FileTypePolicy::detectMime($absolutePath);
        $stored = trim((string) ($file['mime_type'] ?? ''));

        $mime = $detected;
        $mimeMatches = false;
        if ($extension !== '') {
            if (\Core\FileTypePolicy::isMimeAllowedForExtension($extension, $detected)) {
                $mime = $detected;
                $mimeMatches = true;
            } elseif ($stored !== '' && \Core\FileTypePolicy::isMimeAllowedForExtension($extension, $stored)) {
                $mime = $stored;
                $mimeMatches = true;
            }
        }

        $inlineOk = $mimeMatches && \Core\FileTypePolicy::isSafeInlineImage($extension, $mime);
        if (!$inlineOk && $extension !== '' && $stored !== ''
            && \Core\FileTypePolicy::expectedInlineImageMime($extension) !== null
            && \Core\FileTypePolicy::isSafeInlineImage($extension, $stored)) {
            $mime = $stored;
            $mimeMatches = true;
            $inlineOk = true;
        }

        if (!$mimeMatches && $extension !== '' && !\Core\FileTypePolicy::isKnownExtension($extension)) {
            $mime = 'application/octet-stream';
        }

        return [
            'mime' => $mime,
            'inline_ok' => $inlineOk,
            'mime_matches' => $mimeMatches,
        ];
    }
}

if (!function_exists('admin_submission_file_url')) {
    /** 管理画面の添付ファイル URL（inline でブラウザ表示） */
    function admin_submission_file_url(int $fileId, bool $inline = true): string
    {
        $path = '/admin/files/' . $fileId;
        if ($inline) {
            $path .= '?inline=1';
        }
        return base_path($path);
    }
}

if (!function_exists('admin_import_preview_file_url')) {
    /** インポートプレビュー中の ZIP 内添付 URL */
    function admin_import_preview_file_url(int $formId, string $token, int $index, int $fileIndex, bool $inline = true): string
    {
        $path = '/admin/forms/' . $formId . '/submissions/import/' . $token
            . '/submissions/' . $index . '/files/' . $fileIndex;
        if ($inline) {
            $path .= '?inline=1';
        }
        return base_path($path);
    }
}

if (!function_exists('base_path')) {
    /**
     * サブディレクトリ運用に対応したベースパス + 任意のパス。
     */
    function base_path(string $path = ''): string
    {
        $base = rtrim((string) config('site.base_path', ''), '/');
        if ($path !== '' && $path[0] !== '/') {
            $path = '/' . $path;
        }
        return $base . $path;
    }
}

if (!function_exists('url')) {
    /**
     * 絶対URLが必要なケース用。base_url が設定されていれば使う。
     */
    function url(string $path = ''): string
    {
        $baseUrl = rtrim((string) config('site.base_url', ''), '/');
        if ($baseUrl !== '') {
            return $baseUrl . base_path($path);
        }
        return base_path($path);
    }
}

if (!function_exists('redirect')) {
    function redirect(string $path): void
    {
        header('Location: ' . base_path($path));
        exit;
    }
}

if (!function_exists('admin_relative_path')) {
    /**
     * 管理画面ルーターと同じ基準のパス（/admin プレフィックス除去後）。
     * 例: '/', '/forms', '/forms/1/edit', '/settings'
     */
    function admin_relative_path(): string
    {
        if (isset($_GET['path']) && $_GET['path'] !== '') {
            $path = '/' . ltrim((string) $_GET['path'], '/');
        } else {
            $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
        }
        $base = rtrim((string) config('site.base_path', ''), '/');
        if ($base !== '' && strpos($path, $base) === 0) {
            $path = substr($path, strlen($base));
        }
        $path = '/' . ltrim((string) $path, '/');
        $prefix = '/admin';
        if ($prefix !== '' && strpos($path, $prefix) === 0) {
            $path = substr($path, strlen($prefix));
            if ($path === '' || $path === false) {
                $path = '/';
            }
        }
        if ($path !== '/' && substr($path, -1) === '/') {
            $path = rtrim($path, '/');
        }

        return $path;
    }
}

if (!function_exists('is_form_button_url')) {
    /**
     * 完了画面ボタンに指定できるURLか判定する。
     */
    function is_form_button_url(string $value): bool
    {
        $value = trim($value);
        if ($value === '') {
            return false;
        }
        if (strpos($value, '/') === 0) {
            return strpos($value, '//') !== 0;
        }
        if (!filter_var($value, FILTER_VALIDATE_URL)) {
            return false;
        }
        $scheme = strtolower((string) parse_url($value, PHP_URL_SCHEME));
        return in_array($scheme, ['http', 'https'], true);
    }
}

if (!function_exists('resolve_form_button_url')) {
    /**
     * 完了画面ボタン用のURLを公開URLへ解決する。
     */
    function resolve_form_button_url(string $value): string
    {
        $value = trim($value);
        if (strpos($value, '/') === 0 && strpos($value, '//') !== 0) {
            return base_path($value);
        }
        return $value;
    }
}

if (!function_exists('flash')) {
    /**
     * フラッシュメッセージ取得 or 設定。
     */
    function flash(?string $type = null, ?string $message = null)
    {
        if ($type === null) {
            $messages = $_SESSION['_flash'] ?? [];
            unset($_SESSION['_flash']);
            return $messages;
        }
        $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
    }
}

if (!function_exists('old')) {
    /**
     * 直前の入力値（バリデーションエラー時の再表示用）。
     */
    function old(string $key, $default = '')
    {
        $old = $_SESSION['_old'] ?? [];
        return $old[$key] ?? $default;
    }
}

if (!function_exists('client_ip')) {
    function client_ip(): string
    {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        return substr($ip, 0, 45);
    }
}

if (!function_exists('sanitize_rich_text_html')) {
    /**
     * 軽量 WYSIWYG 用の許可タグだけを残して HTML を整形する。
     */
    function sanitize_rich_text_html($html): string
    {
        $html = trim((string) $html);
        if ($html === '') {
            return '';
        }
        // 閉じ「>」のない断片も後続テンプレートの「>」でタグとして成立するため、「<」を含むものはすべて DOM で検査する。
        if (!str_contains($html, '<')) {
            return $html;
        }

        $globalAttrs = ['class'];
        $allowedTags = [
            'a' => array_merge(['href'], $globalAttrs),
            'b' => $globalAttrs,
            'br' => $globalAttrs,
            'div' => $globalAttrs,
            'em' => $globalAttrs,
            'footer' => $globalAttrs,
            'h1' => $globalAttrs,
            'h2' => $globalAttrs,
            'h3' => $globalAttrs,
            'h4' => $globalAttrs,
            'h5' => $globalAttrs,
            'h6' => $globalAttrs,
            'header' => $globalAttrs,
            'i' => $globalAttrs,
            'img' => array_merge(['src', 'alt', 'width', 'height'], $globalAttrs),
            'li' => $globalAttrs,
            'ol' => $globalAttrs,
            'p' => $globalAttrs,
            'span' => $globalAttrs,
            'strong' => $globalAttrs,
            'u' => $globalAttrs,
            'ul' => $globalAttrs,
        ];
        $dropTags = ['script', 'style', 'iframe', 'object', 'embed'];

        $previous = libxml_use_internal_errors(true);
        $dom = new \DOMDocument('1.0', 'UTF-8');
        $wrappedHtml = '<div id="__rich_text_root__">' . $html . '</div>';
        $dom->loadHTML(
            mb_encode_numericentity($wrappedHtml, [0x80, 0x10FFFF, 0, 0xFFFFFF], 'UTF-8'),
            LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
        );
        libxml_clear_errors();
        libxml_use_internal_errors($previous);

        $xpath = new \DOMXPath($dom);
        $root = $xpath->query('//*[@id="__rich_text_root__"]')->item(0);
        if (!$root instanceof \DOMElement) {
            return strip_tags($html);
        }

        $sanitizeUrl = static function (string $url): string {
            $url = trim($url);
            if ($url === '') {
                return '';
            }
            if (preg_match('/^(https?:|mailto:|tel:|\/|#)/i', $url) === 1) {
                return $url;
            }
            return '';
        };
        $sanitizeClass = static function (string $class): string {
            $tokens = preg_split('/\s+/', trim($class)) ?: [];
            $safeTokens = [];
            foreach ($tokens as $token) {
                if ($token === '' || mb_strlen($token) > 64) {
                    continue;
                }
                if (preg_match('/^[A-Za-z0-9_-]+$/', $token) !== 1) {
                    continue;
                }
                $safeTokens[] = $token;
            }
            return implode(' ', array_values(array_unique($safeTokens)));
        };

        $sanitizeNode = static function (\DOMNode $node) use (&$sanitizeNode, $allowedTags, $dropTags, $sanitizeUrl, $sanitizeClass): void {
            if ($node instanceof \DOMText) {
                return;
            }

            if (!($node instanceof \DOMElement)) {
                if ($node->parentNode) {
                    $node->parentNode->removeChild($node);
                }
                return;
            }

            $tagName = strtolower($node->tagName);
            if (in_array($tagName, $dropTags, true)) {
                if ($node->parentNode) {
                    $node->parentNode->removeChild($node);
                }
                return;
            }

            if (!array_key_exists($tagName, $allowedTags)) {
                if ($node->parentNode) {
                    while ($node->firstChild) {
                        $node->parentNode->insertBefore($node->firstChild, $node);
                    }
                    $node->parentNode->removeChild($node);
                }
                return;
            }

            $allowedAttrs = $allowedTags[$tagName];
            if ($node->hasAttributes()) {
                $removeAttrs = [];
                foreach ($node->attributes as $attr) {
                    $attrName = strtolower($attr->nodeName);
                    if (!in_array($attrName, $allowedAttrs, true)) {
                        $removeAttrs[] = $attrName;
                    }
                }
                foreach ($removeAttrs as $attrName) {
                    $node->removeAttribute($attrName);
                }
            }

            if ($tagName === 'a' && $node->hasAttribute('href')) {
                $safeHref = $sanitizeUrl((string) $node->getAttribute('href'));
                if ($safeHref === '') {
                    $node->removeAttribute('href');
                } else {
                    $node->setAttribute('href', $safeHref);
                }
            }
            if ($tagName === 'img') {
                if ($node->hasAttribute('src')) {
                    $safeSrc = $sanitizeUrl((string) $node->getAttribute('src'));
                    if ($safeSrc === '') {
                        $node->removeAttribute('src');
                    } else {
                        $node->setAttribute('src', $safeSrc);
                    }
                }
                foreach (['width', 'height'] as $sizeAttr) {
                    if (!$node->hasAttribute($sizeAttr)) {
                        continue;
                    }
                    $sizeValue = trim((string) $node->getAttribute($sizeAttr));
                    if (preg_match('/^[1-9][0-9]{0,3}$/', $sizeValue) !== 1) {
                        $node->removeAttribute($sizeAttr);
                    }
                }
            }
            if ($node->hasAttribute('class')) {
                $safeClass = $sanitizeClass((string) $node->getAttribute('class'));
                if ($safeClass === '') {
                    $node->removeAttribute('class');
                } else {
                    $node->setAttribute('class', $safeClass);
                }
            }

            for ($child = $node->firstChild; $child !== null; $child = $next) {
                $next = $child->nextSibling;
                $sanitizeNode($child);
            }
        };

        for ($child = $root->firstChild; $child !== null; $child = $next) {
            $next = $child->nextSibling;
            $sanitizeNode($child);
        }

        $out = '';
        foreach ($root->childNodes as $child) {
            $out .= $dom->saveHTML($child);
        }

        return trim($out);
    }
}

if (!function_exists('render_rich_text_html')) {
    /**
     * 旧プレーンテキストと WYSIWYG 保存 HTML の両方を安全に表示する。
     */
    function render_rich_text_html($html): string
    {
        $html = trim((string) $html);
        if ($html === '') {
            return '';
        }
        if (preg_match('/<\s*\/?[a-zA-Z][^>]*>/', $html) !== 1) {
            return nl2br(e($html));
        }

        return sanitize_rich_text_html($html);
    }
}

if (!function_exists('decode_form_description_blocks')) {
    /**
     * @return array<int, array{id:string,label:string,html:string,position:int,visible:int,is_html:int}>
     */
    function decode_form_description_blocks($stored, bool $legacyVisible = true): array
    {
        $stored = trim((string) $stored);
        if ($stored === '') {
            return [];
        }

        $normalizeBlockContent = static function ($value, bool $isHtml): string {
            $content = trim((string) $value);
            if ($content === '') {
                return '';
            }

            return $isHtml ? sanitize_rich_text_html($content) : $content;
        };
        $resolveIsHtml = static function (array $item, string $content): bool {
            if (array_key_exists('is_html', $item)) {
                return !empty($item['is_html']);
            }

            return preg_match('/<\s*\/?[a-zA-Z][^>]*>/', $content) === 1;
        };

        $decoded = json_decode($stored, true);
        if (is_array($decoded) && ($decoded === [] || array_keys($decoded) === range(0, count($decoded) - 1))) {
            $looksLikeBlocks = false;
            foreach ($decoded as $item) {
                if (is_array($item) && array_key_exists('html', $item)) {
                    $looksLikeBlocks = true;
                    break;
                }
            }
            if ($looksLikeBlocks) {
                $blocks = [];
                foreach ($decoded as $i => $item) {
                    if (!is_array($item)) {
                        continue;
                    }
                    $rawContent = trim((string) ($item['html'] ?? ''));
                    $labelTrim = trim((string) ($item['label'] ?? ''));
                    $isHtml = $resolveIsHtml($item, $rawContent);
                    $html = $normalizeBlockContent($rawContent, $isHtml);
                    if ($html === '' && $labelTrim === '') {
                        continue;
                    }
                    $position = isset($item['position']) && is_numeric($item['position'])
                        ? max(0, (int) $item['position'])
                        : 0;
                    $visible = !empty($item['visible']) ? 1 : 0;
                    $id = trim((string) ($item['id'] ?? ''));
                    if ($id === '') {
                        $id = 'description-' . $i;
                    }
                    $blocks[] = [
                        'id' => $id,
                        'label' => $labelTrim,
                        'html' => $html,
                        'position' => $position,
                        'visible' => $visible,
                        'is_html' => $isHtml ? 1 : 0,
                    ];
                }
                return $blocks;
            }
        }

        $isHtml = preg_match('/<\s*\/?[a-zA-Z][^>]*>/', $stored) === 1;
        $html = $normalizeBlockContent($stored, $isHtml);
        if ($html === '') {
            return [];
        }

        return [[
            'id' => 'description-0',
            'label' => '',
            'html' => $html,
            'position' => 0,
            'visible' => $legacyVisible ? 1 : 0,
            'is_html' => $isHtml ? 1 : 0,
        ]];
    }
}

if (!function_exists('encode_form_description_blocks')) {
    /**
     * @param array<int, array<string, mixed>> $blocks
     */
    function encode_form_description_blocks(array $blocks): ?string
    {
        $out = [];
        foreach ($blocks as $i => $block) {
            if (!is_array($block)) {
                continue;
            }
            $isHtml = !empty($block['is_html']);
            $html = trim((string) ($block['html'] ?? ''));
            if ($isHtml) {
                $html = sanitize_rich_text_html($html);
            }
            $labelTrim = trim((string) ($block['label'] ?? ''));
            if ($html === '' && $labelTrim === '') {
                continue;
            }
            $position = isset($block['position']) && is_numeric($block['position'])
                ? max(0, (int) $block['position'])
                : 0;
            $id = trim((string) ($block['id'] ?? ''));
            if ($id === '') {
                $id = 'description-' . $i;
            }
            $out[] = [
                'id' => $id,
                'label' => $labelTrim,
                'html' => $html,
                'position' => $position,
                'visible' => !empty($block['visible']) ? 1 : 0,
                'is_html' => $isHtml ? 1 : 0,
            ];
        }

        if ($out === []) {
            return null;
        }

        return json_encode($out, JSON_UNESCAPED_UNICODE);
    }
}

if (!function_exists('form_publish_weekday_ui_order')) {
    /**
     * @return array<int, int> 月〜日の PHP date('w') 値
     */
    function form_publish_weekday_ui_order(): array
    {
        return [1, 2, 3, 4, 5, 6, 0];
    }
}

if (!function_exists('form_publish_weekday_label')) {
    function form_publish_weekday_label(int $weekday): string
    {
        return match ($weekday) {
            0 => '日',
            1 => '月',
            2 => '火',
            3 => '水',
            4 => '木',
            5 => '金',
            6 => '土',
            default => '',
        };
    }
}

if (!function_exists('form_publish_weekdays_from_post')) {
    /**
     * @param mixed $raw
     */
    function form_publish_weekdays_from_post($raw): ?int
    {
        if (!is_array($raw)) {
            return null;
        }
        $mask = 0;
        foreach ($raw as $value) {
            $day = (int) $value;
            if ($day < 0 || $day > 6) {
                continue;
            }
            $mask |= (1 << $day);
        }
        return $mask > 0 ? $mask : null;
    }
}

if (!function_exists('form_publish_weekdays_has_day')) {
    function form_publish_weekdays_has_day(?int $mask, int $weekday): bool
    {
        if ($mask === null || $mask <= 0) {
            return false;
        }
        return ($mask & (1 << $weekday)) !== 0;
    }
}

if (!function_exists('normalize_form_schedule_rules')) {
    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, array<string, mixed>>
     */
    function normalize_form_schedule_rules(array $rules, string $idPrefix = 'publish'): array
    {
        $normalized = [];
        foreach (array_values($rules) as $i => $rule) {
            if (!is_array($rule)) {
                continue;
            }
            $id = trim((string) ($rule['id'] ?? ''));
            if ($id === '') {
                $id = $idPrefix . '-' . $i;
            }
            $startAt = trim((string) ($rule['start_at'] ?? ''));
            $endAt = trim((string) ($rule['end_at'] ?? ''));
            $dailyStart = trim((string) ($rule['daily_start_time'] ?? ''));
            $dailyEnd = trim((string) ($rule['daily_end_time'] ?? ''));
            $weekdays = $rule['weekdays'] ?? null;
            if (is_array($weekdays)) {
                $weekdays = form_publish_weekdays_from_post($weekdays);
            } elseif ($weekdays !== null && $weekdays !== '') {
                $weekdays = (int) $weekdays;
                if ($weekdays <= 0) {
                    $weekdays = null;
                }
            } else {
                $weekdays = null;
            }
            $holiday = !empty($rule['holiday']) ? 1 : 0;
            $normalized[] = [
                'id' => $id,
                'visible' => !empty($rule['visible']) ? 1 : 0,
                'position' => isset($rule['position']) && is_numeric($rule['position']) ? max(0, (int) $rule['position']) : $i,
                'start_at' => $startAt !== '' ? $startAt : null,
                'end_at' => $endAt !== '' ? $endAt : null,
                'weekdays' => $weekdays,
                'holiday' => $holiday,
                'daily_start_time' => $dailyStart !== '' ? $dailyStart : null,
                'daily_end_time' => $dailyEnd !== '' ? $dailyEnd : null,
            ];
        }
        usort($normalized, static fn(array $a, array $b): int => ((int) ($a['position'] ?? 0)) <=> ((int) ($b['position'] ?? 0)));
        return $normalized;
    }
}

if (!function_exists('normalize_form_publish_rules')) {
    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, array<string, mixed>>
     */
    function normalize_form_publish_rules(array $rules): array
    {
        return normalize_form_schedule_rules($rules, 'publish');
    }
}

if (!function_exists('normalize_form_unpublish_rules')) {
    /**
     * @param array<int, array<string, mixed>> $rules
     * @return array<int, array<string, mixed>>
     */
    function normalize_form_unpublish_rules(array $rules): array
    {
        return normalize_form_schedule_rules($rules, 'unpublish');
    }
}

if (!function_exists('decode_form_publish_rules')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function decode_form_publish_rules($stored): array
    {
        if (is_array($stored)) {
            return normalize_form_publish_rules($stored);
        }
        $stored = trim((string) $stored);
        if ($stored === '') {
            return [];
        }
        $decoded = json_decode($stored, true);
        if (!is_array($decoded)) {
            return [];
        }
        return normalize_form_publish_rules($decoded);
    }
}

if (!function_exists('encode_form_publish_rules')) {
    /**
     * @param array<int, array<string, mixed>> $rules
     */
    function encode_form_publish_rules(array $rules): ?string
    {
        $normalized = normalize_form_publish_rules($rules);
        if ($normalized === []) {
            return null;
        }
        return json_encode($normalized, JSON_UNESCAPED_UNICODE);
    }
}

if (!function_exists('decode_form_unpublish_rules')) {
    /**
     * @return array<int, array<string, mixed>>
     */
    function decode_form_unpublish_rules($stored): array
    {
        if (is_array($stored)) {
            return normalize_form_unpublish_rules($stored);
        }
        $stored = trim((string) $stored);
        if ($stored === '') {
            return [];
        }
        $decoded = json_decode($stored, true);
        if (!is_array($decoded)) {
            return [];
        }
        return normalize_form_unpublish_rules($decoded);
    }
}

if (!function_exists('encode_form_unpublish_rules')) {
    /**
     * @param array<int, array<string, mixed>> $rules
     */
    function encode_form_unpublish_rules(array $rules): ?string
    {
        $normalized = normalize_form_unpublish_rules($rules);
        if ($normalized === []) {
            return null;
        }
        return json_encode($normalized, JSON_UNESCAPED_UNICODE);
    }
}

if (!function_exists('form_publish_date_input_value')) {
    function form_publish_date_input_value(?string $stored): string
    {
        $stored = trim((string) $stored);
        if ($stored === '') {
            return '';
        }
        if (preg_match('/\A(\d{4}-\d{2}-\d{2})/', $stored, $m) === 1) {
            return $m[1];
        }

        return '';
    }
}

if (!function_exists('form_publish_date_from_input')) {
    function form_publish_date_from_input(string $raw): ?string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }
        if (preg_match('/\A\d{4}-\d{2}-\d{2}\z/', $raw) !== 1) {
            return null;
        }

        return $raw;
    }
}

if (!function_exists('form_publish_period_boundary')) {
    /**
     * @return \DateTimeImmutable|null
     */
    function form_publish_period_boundary(string $stored, bool $isEnd)
    {
        $stored = trim($stored);
        if ($stored === '') {
            return null;
        }
        $tz = new \DateTimeZone((string) config('site.timezone', 'Asia/Tokyo'));
        if (preg_match('/\A\d{4}-\d{2}-\d{2}\z/', $stored) === 1) {
            $dt = \DateTimeImmutable::createFromFormat('Y-m-d', $stored, $tz);
            if (!$dt) {
                return null;
            }

            return $isEnd ? $dt->setTime(23, 59, 59) : $dt->setTime(0, 0, 0);
        }
        $dt = \DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $stored, $tz)
            ?: \DateTimeImmutable::createFromFormat('Y-m-d H:i', $stored, $tz);
        return $dt ?: null;
    }
}

if (!function_exists('form_publish_time_from_input')) {
    function form_publish_time_from_input(string $raw): ?string
    {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }
        if (preg_match('/\A\d{2}:\d{2}\z/', $raw) === 1) {
            $raw .= ':00';
        }
        if (preg_match('/\A\d{2}:\d{2}:\d{2}\z/', $raw) !== 1) {
            return null;
        }
        return $raw;
    }
}

if (!function_exists('form_publish_rule_summary')) {
    /**
     * @param array<string, mixed> $rule
     */
    function form_publish_rule_summary(array $rule): string
    {
        $parts = [];
        $startAt = form_publish_date_input_value($rule['start_at'] ?? null);
        $endAt = form_publish_date_input_value($rule['end_at'] ?? null);
        if ($startAt !== '' || $endAt !== '') {
            if ($startAt !== '' && $endAt !== '') {
                $parts[] = $startAt . ' 〜 ' . $endAt;
            } elseif ($startAt !== '') {
                $parts[] = $startAt . ' 以降';
            } else {
                $parts[] = $endAt . ' まで';
            }
        }
        $weekdays = $rule['weekdays'] ?? null;
        if ($weekdays !== null && (int) $weekdays > 0) {
            $labels = [];
            foreach (form_publish_weekday_ui_order() as $day) {
                if (form_publish_weekdays_has_day((int) $weekdays, $day)) {
                    $labels[] = form_publish_weekday_label($day);
                }
            }
            if ($labels !== []) {
                $parts[] = implode('', $labels);
            }
        }
        if (!empty($rule['holiday'])) {
            $parts[] = '祝日';
        }
        $dailyStart = trim((string) ($rule['daily_start_time'] ?? ''));
        $dailyEnd = trim((string) ($rule['daily_end_time'] ?? ''));
        if ($dailyStart !== '' && $dailyEnd !== '') {
            $parts[] = substr($dailyStart, 0, 5) . '〜' . substr($dailyEnd, 0, 5);
        }
        return $parts !== [] ? implode(' / ', $parts) : '条件未設定';
    }
}

if (!function_exists('form_has_visible_schedule_rules')) {
    function form_has_visible_schedule_rules(array $form): bool
    {
        foreach (decode_form_publish_rules($form['publish_rules'] ?? null) as $rule) {
            if (!empty($rule['visible']) && \Core\FormPublishSchedule::hasConfiguredDimension($rule)) {
                return true;
            }
        }
        foreach (decode_form_unpublish_rules($form['unpublish_rules'] ?? null) as $rule) {
            if (!empty($rule['visible']) && \Core\FormPublishSchedule::hasConfiguredDimension($rule)) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('form_has_visible_publish_rules')) {
    function form_has_visible_publish_rules(array $form): bool
    {
        return form_has_visible_schedule_rules($form);
    }
}

if (!function_exists('render_form_description_blocks_at')) {
    /**
     * @param array<int, array{id:string,html:string,position:int,visible:int,is_html?:int}> $blocks
     */
    function render_form_description_blocks_at(array $blocks, int $position): string
    {
        $html = '';
        foreach ($blocks as $block) {
            if ((int) ($block['position'] ?? 0) !== $position || empty($block['visible']) || empty($block['html'])) {
                continue;
            }
            $content = !empty($block['is_html'])
                ? render_rich_text_html($block['html'])
                : nl2br(e((string) $block['html']));
            $html .= '<div class="block is-lead">' . $content . '</div>';
        }
        return $html;
    }
}

if (!function_exists('first_form_description_block_html')) {
    function first_form_description_block_html($stored, bool $legacyVisible = true): string
    {
        $blocks = decode_form_description_blocks($stored, $legacyVisible);
        foreach ($blocks as $block) {
            if (!empty($block['visible']) && !empty($block['html'])) {
                return !empty($block['is_html'])
                    ? render_rich_text_html($block['html'])
                    : nl2br(e((string) $block['html']));
            }
        }
        return '';
    }
}

if (!function_exists('address_errors_normalize')) {
    /**
     * 住所フィールドのエラーを表示用に整形（ネスト or 従来の文字列リスト）。
     *
     * @param mixed $err
     * @return array{_root:string[],postal:string[],prefecture:string[],city:string[],number:string[],combined:string[]}
     */
    function address_errors_normalize($err): array
    {
        $defaults = [
            '_root'       => [],
            'postal'      => [],
            'prefecture'  => [],
            'city'        => [],
            'number'      => [],
            'combined'    => [],
        ];
        if (!is_array($err) || $err === []) {
            return $defaults;
        }
        $first = array_key_first($err);
        $looksNested = isset($err['prefecture']) || isset($err['postal']) || isset($err['city'])
            || isset($err['number']) || isset($err['combined']) || isset($err['_root']);
        if (!$looksNested && $first !== null) {
            foreach ($err as $m) {
                if (is_string($m)) {
                    $defaults['combined'][] = $m;
                }
            }
            return $defaults;
        }
        foreach (['_root', 'postal', 'prefecture', 'city', 'number', 'combined'] as $k) {
            if (!empty($err[$k]) && is_array($err[$k])) {
                foreach ($err[$k] as $m) {
                    if (is_string($m)) {
                        $defaults[$k][] = $m;
                    }
                }
            }
        }
        return $defaults;
    }
}

if (!function_exists('address_errors_any')) {
    /** @param array{_root?:string[],postal?:string[],prefecture?:string[],city?:string[],number?:string[],combined?:string[]} $parts */
    function address_errors_any(array $parts): bool
    {
        foreach ($parts as $msgs) {
            if (!empty($msgs)) {
                return true;
            }
        }
        return false;
    }
}

if (!function_exists('text_pair_errors_normalize')) {
    /**
     * @param mixed $err
     * @return array{_root:string[],left:string[],right:string[]}
     */
    function text_pair_errors_normalize($err): array
    {
        $defaults = [
            '_root' => [],
            'left' => [],
            'right' => [],
        ];
        if (!is_array($err) || $err === []) {
            return $defaults;
        }
        $looksNested = isset($err['left']) || isset($err['right']) || isset($err['_root']);
        if (!$looksNested) {
            foreach ($err as $m) {
                if (is_string($m)) {
                    $defaults['_root'][] = $m;
                }
            }
            return $defaults;
        }
        foreach (['_root', 'left', 'right'] as $k) {
            if (!empty($err[$k]) && is_array($err[$k])) {
                foreach ($err[$k] as $m) {
                    if (is_string($m)) {
                        $defaults[$k][] = $m;
                    }
                }
            }
        }
        return $defaults;
    }
}

if (!function_exists('text_multi_errors_normalize')) {
    /**
     * @param mixed $err
     * @return array{_root:string[],items:array<int, array<int, string>>}
     */
    function text_multi_errors_normalize($err): array
    {
        $defaults = [
            '_root' => [],
            'items' => [],
        ];
        if (!is_array($err) || $err === []) {
            return $defaults;
        }
        $looksNested = isset($err['items']) || isset($err['_root']);
        if (!$looksNested) {
            foreach ($err as $m) {
                if (is_string($m)) {
                    $defaults['_root'][] = $m;
                }
            }
            return $defaults;
        }
        if (!empty($err['_root']) && is_array($err['_root'])) {
            foreach ($err['_root'] as $m) {
                if (is_string($m)) {
                    $defaults['_root'][] = $m;
                }
            }
        }
        if (!empty($err['items']) && is_array($err['items'])) {
            foreach ($err['items'] as $index => $messages) {
                if (!is_array($messages)) {
                    continue;
                }
                $normalized = [];
                foreach ($messages as $m) {
                    if (is_string($m)) {
                        $normalized[] = $m;
                    }
                }
                if ($normalized !== []) {
                    $defaults['items'][(int) $index] = $normalized;
                }
            }
        }
        return $defaults;
    }
}

if (!function_exists('japanese_prefectures')) {
    /**
     * @return string[] 都道府県名（47）
     */
    function japanese_prefectures(): array
    {
        return [
            '北海道', '青森県', '岩手県', '宮城県', '秋田県', '山形県', '福島県',
            '茨城県', '栃木県', '群馬県', '埼玉県', '千葉県', '東京都', '神奈川県',
            '新潟県', '富山県', '石川県', '福井県', '山梨県', '長野県',
            '岐阜県', '静岡県', '愛知県', '三重県',
            '滋賀県', '京都府', '大阪府', '兵庫県', '奈良県', '和歌山県',
            '鳥取県', '島根県', '岡山県', '広島県', '山口県',
            '徳島県', '香川県', '愛媛県', '高知県',
            '福岡県', '佐賀県', '長崎県', '熊本県', '大分県', '宮崎県', '鹿児島県', '沖縄県',
        ];
    }
}

if (!function_exists('address_split_legacy_line1')) {
    /**
     * 旧フォーマット（line1 に都道府県+市区町村が連結）から都道府県と市区町村へ分割。
     *
     * @return array{0:string,1:string} [都道府県, 市区町村]
     */
    function address_split_legacy_line1(string $line1): array
    {
        foreach (japanese_prefectures() as $pref) {
            if ($pref !== '' && mb_strpos($line1, $pref, 0, 'UTF-8') === 0) {
                $rest = trim(mb_substr($line1, mb_strlen($pref, 'UTF-8'), null, 'UTF-8'));
                return [$pref, $rest];
            }
        }
        return ['', $line1];
    }
}

if (!function_exists('format_address_parts')) {
    /**
     * 旧フォーマット（postal + line1 + line2）を表示用テキストに整形。
     *
     * @return string 改行区切り（空なら空文字）
     */
    function format_address_parts(string $postal, string $line1, string $line2): string
    {
        $lines = [];
        if ($postal !== '') {
            $d = preg_replace('/\D/', '', $postal);
            $lines[] = (strlen($d) === 7)
                ? ('〒' . substr($d, 0, 3) . '-' . substr($d, 3))
                : ('〒' . $postal);
        }
        if ($line1 !== '') {
            $lines[] = $line1;
        }
        if ($line2 !== '') {
            $lines[] = $line2;
        }
        return implode("\n", $lines);
    }
}

if (!function_exists('format_address_parts_v2')) {
    /**
     * 中間フォーマット（番地・建物が1フィールド street にまとまっている場合）。
     */
    function format_address_parts_v2(string $postal, string $prefecture, string $city, string $street): string
    {
        $lines = [];
        if ($postal !== '') {
            $d = preg_replace('/\D/', '', $postal);
            $lines[] = (strlen($d) === 7)
                ? ('〒' . substr($d, 0, 3) . '-' . substr($d, 3))
                : ('〒' . $postal);
        }
        if ($prefecture !== '') {
            $lines[] = $prefecture;
        }
        if ($city !== '') {
            $lines[] = $city;
        }
        if ($street !== '') {
            $lines[] = $street;
        }
        return implode("\n", $lines);
    }
}

if (!function_exists('format_address_parts_v3')) {
    /**
     * 現行フォーマット（番地・建物を分割）。
     */
    function format_address_parts_v3(string $postal, string $prefecture, string $city, string $number, string $building): string
    {
        $lines = [];
        if ($postal !== '') {
            $d = preg_replace('/\D/', '', $postal);
            $lines[] = (strlen($d) === 7)
                ? ('〒' . substr($d, 0, 3) . '-' . substr($d, 3))
                : ('〒' . $postal);
        }
        if ($prefecture !== '') {
            $lines[] = $prefecture;
        }
        if ($city !== '') {
            $lines[] = $city;
        }
        if ($number !== '') {
            $lines[] = $number;
        }
        if ($building !== '') {
            $lines[] = $building;
        }
        return implode("\n", $lines);
    }
}

if (!function_exists('format_address_value_display')) {
    /**
     * 送信値・DB保存値（JSON 文字列含む）を確認画面・メール用の表示文に変換。
     *
     * @param array|string $value
     */
    function format_address_value_display($value): string
    {
        if (is_array($value)) {
            return format_address_array_for_display($value);
        }
        $s = (string) $value;
        if ($s === '') {
            return '';
        }
        $decoded = json_decode($s, true);
        if (is_array($decoded) && (array_key_exists('postal', $decoded) || array_key_exists('line1', $decoded)
            || array_key_exists('prefecture', $decoded) || array_key_exists('city', $decoded)
            || array_key_exists('number', $decoded) || array_key_exists('building', $decoded))) {
            return format_address_array_for_display($decoded);
        }
        return $s;
    }
}

if (!function_exists('format_text_pair_value_display')) {
    /**
     * @param array|string $value
     * @param array{left_label?:string,right_label?:string}|null $labels
     */
    function format_text_pair_value_display($value, ?array $labels = null): string
    {
        $labels = $labels ?? [];
        $leftLabel = trim((string) ($labels['left_label'] ?? ''));
        $rightLabel = trim((string) ($labels['right_label'] ?? ''));
        $left = '';
        $right = '';

        if (is_array($value)) {
            $left = trim((string) ($value['left'] ?? ''));
            $right = trim((string) ($value['right'] ?? ''));
        } else {
            $s = trim((string) $value);
            if ($s === '') {
                return '';
            }
            $decoded = json_decode($s, true);
            if (is_array($decoded) && (isset($decoded['left']) || isset($decoded['right']))) {
                $left = trim((string) ($decoded['left'] ?? ''));
                $right = trim((string) ($decoded['right'] ?? ''));
            } else {
                $parts = preg_split('/\r\n|\r|\n/', $s) ?: [];
                $left = trim((string) ($parts[0] ?? ''));
                $right = trim((string) ($parts[1] ?? ''));
            }
        }

        $lines = [];
        if ($left !== '') {
            $lines[] = ($leftLabel !== '' ? $leftLabel . ': ' : '') . $left;
        }
        if ($right !== '') {
            $lines[] = ($rightLabel !== '' ? $rightLabel . ': ' : '') . $right;
        }
        return implode("\n", $lines);
    }
}

if (!function_exists('submission_list_preview_display_line')) {
    /**
     * 受信履歴一覧 SP カード用: プレビュー値を 1 行表示に整形（詳細用 formatter は変更しない）。
     */
    function submission_list_preview_display_line(string $value): string
    {
        $s = preg_replace('/\r\n|\r|\n|\x{2028}|\x{2029}/u', ' ', $value) ?? $value;
        $s = preg_replace('/\s+/u', ' ', trim($s)) ?? $s;
        $nbsp = "\u{00A0}";
        $replaced = preg_replace('/([:：])\s+/u', '$1' . $nbsp, $s);

        return is_string($replaced) ? $replaced : $s;
    }
}

if (!function_exists('submission_list_preview_title_attr')) {
    /**
     * 受信履歴一覧 SP カード用: title 属性向け（改行を除き 1 行の全文）。
     */
    function submission_list_preview_title_attr(string $value): string
    {
        $s = preg_replace('/\r\n|\r|\n|\x{2028}|\x{2029}/u', ' ', $value) ?? $value;
        $s = preg_replace('/\s+/u', ' ', trim($s)) ?? $s;

        return $s;
    }
}

if (!function_exists('format_text_multi_value_display')) {
    /**
     * @param array|string $value
     * @param array<int, array{label?:string,placeholder?:string}>|null $items
     */
    function format_text_multi_value_display($value, ?array $items = null): string
    {
        $items = is_array($items) ? array_values($items) : [];
        $values = [];

        if (is_array($value)) {
            if (isset($value['items']) && is_array($value['items'])) {
                $values = array_values(array_map(static fn($item): string => trim((string) $item), $value['items']));
            } else {
                $values = array_values(array_map(static fn($item): string => trim((string) $item), $value));
            }
        } else {
            $s = trim((string) $value);
            if ($s === '') {
                return '';
            }
            $decoded = json_decode($s, true);
            if (is_array($decoded)) {
                if (isset($decoded['items']) && is_array($decoded['items'])) {
                    $values = array_values(array_map(static fn($item): string => trim((string) $item), $decoded['items']));
                } elseif (isset($decoded['left']) || isset($decoded['right'])) {
                    $values = [
                        trim((string) ($decoded['left'] ?? '')),
                        trim((string) ($decoded['right'] ?? '')),
                    ];
                } else {
                    $values = array_values(array_map(static fn($item): string => trim((string) $item), $decoded));
                }
            } else {
                $values = preg_split('/\r\n|\r|\n/', $s) ?: [];
                $values = array_values(array_map(static fn($item): string => trim((string) $item), $values));
            }
        }

        $lines = [];
        $hasSingleUnnamedItem = count($items) === 1 && trim((string) ($items[0]['label'] ?? '')) === '';
        foreach ($values as $index => $itemValue) {
            if ($itemValue === '') {
                continue;
            }
            $label = trim((string) ($items[$index]['label'] ?? ''));
            if ($hasSingleUnnamedItem) {
                $lines[] = $itemValue;
                continue;
            }
            if ($label === '') {
                $label = \Models\FormField::textMultiItemDisplayLabel($items[$index] ?? null, $index, '内容');
            }
            $lines[] = $label . ': ' . $itemValue;
        }

        return implode("\n", $lines);
    }
}

if (!function_exists('matrix_value_rows_normalize')) {
    /**
     * @param array|string $value
     * @return array<string, string>
     */
    function matrix_value_rows_normalize($value): array
    {
        if (is_array($value)) {
            $rows = $value['rows'] ?? $value;
        } else {
            $decoded = json_decode((string) $value, true);
            $rows = is_array($decoded) ? ($decoded['rows'] ?? $decoded) : [];
        }

        if (!is_array($rows)) {
            return [];
        }

        $normalized = [];
        foreach ($rows as $rowKey => $selectedValue) {
            $rowKey = trim((string) $rowKey);
            if ($rowKey === '') {
                continue;
            }
            $normalized[$rowKey] = trim((string) $selectedValue);
        }

        return $normalized;
    }
}

if (!function_exists('format_matrix_value_display')) {
    /**
     * @param array|string $value
     * @param array{rows?:array<int,string>,columns?:array<int,string>}|null $settings
     */
    function format_matrix_value_display($value, ?array $settings = null): string
    {
        $settings = $settings ?? [];
        $rows = is_array($settings['rows'] ?? null) ? array_values($settings['rows']) : [];
        $columns = is_array($settings['columns'] ?? null) ? array_values($settings['columns']) : [];
        $selectedByRow = matrix_value_rows_normalize($value);

        $lines = [];
        foreach ($rows as $rowIndex => $rowLabel) {
            $rowLabel = trim((string) $rowLabel);
            if ($rowLabel === '') {
                continue;
            }
            $selected = trim((string) ($selectedByRow[$rowLabel] ?? ''));
            if ($selected === '' && array_key_exists((string) $rowIndex, $selectedByRow)) {
                $selected = trim((string) $selectedByRow[(string) $rowIndex]);
            }
            if ($selected === '') {
                continue;
            }
            if ($columns !== [] && !in_array($selected, $columns, true)) {
                continue;
            }
            $lines[] = $rowLabel . ': ' . $selected;
        }

        return implode("\n", $lines);
    }
}

if (!function_exists('format_address_array_for_display')) {
    /**
     * @param array<string, mixed> $a
     */
    function format_address_array_for_display(array $a): string
    {
        $postal = (string) ($a['postal'] ?? '');
        $hasLegacyOnly = (array_key_exists('line1', $a) || array_key_exists('line2', $a))
            && !array_key_exists('prefecture', $a) && !array_key_exists('city', $a)
            && !array_key_exists('street', $a) && !array_key_exists('number', $a) && !array_key_exists('building', $a);
        if ($hasLegacyOnly) {
            return format_address_parts($postal, (string) ($a['line1'] ?? ''), (string) ($a['line2'] ?? ''));
        }

        $pref = (string) ($a['prefecture'] ?? '');
        $city = (string) ($a['city'] ?? '');
        $num = (string) ($a['number'] ?? '');
        $bld = (string) ($a['building'] ?? '');
        $street = (string) ($a['street'] ?? '');

        if (array_key_exists('number', $a) || array_key_exists('building', $a)) {
            return format_address_parts_v3($postal, $pref, $city, $num, $bld);
        }

        return format_address_parts_v2($postal, $pref, $city, $street);
    }
}

if (!function_exists('json_request_body')) {
    /**
     * @return array<string, mixed>|null
     */
    function json_request_body(): ?array
    {
        static $cached = null;
        static $parsed = false;
        if ($parsed) {
            return $cached;
        }
        $parsed = true;
        $raw = file_get_contents('php://input');
        if (!is_string($raw) || trim($raw) === '') {
            $cached = null;

            return null;
        }
        $decoded = json_decode($raw, true);
        $cached = is_array($decoded) ? $decoded : null;

        return $cached;
    }
}

if (!function_exists('json_response')) {
    /**
     * @param array<string, mixed> $data
     */
    function json_response(array $data, int $status = 200): void
    {
        if (!headers_sent()) {
            http_response_code($status);
            header('Content-Type: application/json; charset=UTF-8');
            header('Cache-Control: no-store');
        }
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }
}
