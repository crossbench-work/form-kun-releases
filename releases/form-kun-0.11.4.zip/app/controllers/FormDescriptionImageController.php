<?php

declare(strict_types=1);

namespace Controllers;

use Core\FormDescriptionImage;
use Models\Form;

/**
 * 公開フォーム向け: 説明文ブロック画像の配信（uploads 直アクセスは拒否）。
 */
final class FormDescriptionImageController
{
    public function servePublic(int $formId, string $basename): void
    {
        $form = Form::find($formId);
        if (!$form) {
            $this->notFound();
            return;
        }

        $publicPath = FormDescriptionImage::publicPathFromBasename($formId, $basename);
        if ($publicPath === null) {
            $this->notFound();
            return;
        }

        FormDescriptionImage::streamInline($formId, $publicPath);
    }

    private function notFound(): void
    {
        http_response_code(404);
        echo 'Not found';
        exit;
    }
}
