<?php
/**
 * 管理画面の左線付き見出し m-leftBorderTitle01（ブロックの区切りを示す）。
 * スタイルは同ディレクトリの _m-leftBorderTitle01.scss（_admin-app.scss から @use）。
 */
if (!function_exists('admin_m_left_border_title01')) {
    /**
     * $boundInputId を渡すと admin_m_input01_attrs_with_bound_label() の aria-labelledby が参照する id を付ける。
     */
    function admin_m_left_border_title01(string $innerHtml, ?string $boundInputId = null): void
    {
        echo '<p data-module="m-leftBorderTitle01"';
        $labelId = function_exists('admin_m_bold_title01_label_element_id')
            ? admin_m_bold_title01_label_element_id($boundInputId)
            : null;
        if ($labelId !== null) {
            echo ' id="' . $labelId . '"';
        }
        echo '>' . $innerHtml . '</p>';
    }
}
