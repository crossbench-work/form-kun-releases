<?php
/**
 * 説明文ブロック追加時の種類選択 UI c-descriptionTypeModal01 のマークアップヘルパー。
 * 表示は c-fieldSideArea01 のサイドエリアで描画する。
 */
if (!function_exists('admin_c_description_type_modal01')) {
    function admin_c_description_type_modal01(): void
    {
        require __DIR__ . '/c-descriptionTypeModal01_markup.php';
    }
}
