<?php
$descriptionTypeOptions = [
    ['type' => 'title', 'label' => 'タイトル'],
    ['type' => 'text', 'label' => 'テキスト'],
    ['type' => 'image', 'label' => '画像'],
    ['type' => 'divider', 'label' => '罫線'],
];
?>
<?php admin_c_field_side_area01_open([
    'data-target' => 'c-descriptionTypeModal01',
    'hidden' => true,
]); ?>
    <?php admin_c_field_side_area01_backdrop('c-descriptionTypeModal01__close'); ?>
    <?php admin_c_field_side_area01_panel_open('description-type-modal-title'); ?>
        <?php admin_c_field_side_area01_header_open(); ?>
            <h2 id="description-type-modal-title">項目を追加</h2>
            <button type="button" class="btn is-sm" data-target="c-descriptionTypeModal01__close">閉じる</button>
        <?php admin_c_field_side_area01_header_close(); ?>
        <?php admin_c_field_side_area01_body_open(); ?>
            <section class="c-fieldSideArea01__group">
                <h3 class="c-fieldSideArea01__groupTitle">説明文</h3>
                <div class="c-fieldSideArea01__optionList">
                    <?php foreach ($descriptionTypeOptions as $option): ?>
                        <button
                            type="button"
                            class="c-fieldSideArea01__option"
                            data-target="c-descriptionTypeModal01__option"
                            data-description-type="<?= e($option['type']) ?>"
                        >
                            <?= e($option['label']) ?>
                        </button>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php admin_c_field_side_area01_body_close(); ?>
    <?php admin_c_field_side_area01_panel_close(); ?>
<?php admin_c_field_side_area01_close(); ?>
