<?php
/**
 * 説明文エディタ c-descriptionEditor01 のマークアップヘルパー。
 * 本体は `c-descriptionEditor01_editor.php`。
 */
require_once __DIR__ . '/c-descriptionEditor01_block_content.php';
require_once __DIR__ . '/c-descriptionEditor01_block.php';

if (!function_exists('admin_c_description_editor01')) {
    /**
     * @param string $namePrefix フォーム name の接頭辞（例: description_blocks）
     * @param array<int, array<string, mixed>> $blocks 説明文ブロック配列
     * @param string $positionMode data-position-mode 属性値（input | simple）
     * @param bool|null $imageUploadEnabled 保存済みフォームのみ true。省略時は false（呼び出し元で `!$isNew` を渡すこと）
     * @param int $formIdForImages 画像プレビュー・配信 URL 用のフォーム ID（新規は 0）
     * @param string $part all | top | bottom。bottom は同じタブパネル内の top（本体）と一体で動く
     */
    function admin_c_description_editor01(string $namePrefix, array $blocks, string $positionMode, ?bool $imageUploadEnabled = null, int $formIdForImages = 0, string $part = 'all'): void
    {
        if ($imageUploadEnabled === null) {
            $imageUploadEnabled = false;
        }
        $descriptionImageUploadEnabled = $imageUploadEnabled;
        $descriptionImageFormId = $formIdForImages;
        require __DIR__ . '/c-descriptionEditor01_editor.php';
    }
}
