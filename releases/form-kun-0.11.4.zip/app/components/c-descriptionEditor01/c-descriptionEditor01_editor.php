<?php
/** @var string $namePrefix */
/** @var array<int, array<string, mixed>> $blocks */
/** @var string $positionMode */
/** @var bool $descriptionImageUploadEnabled */
/** @var int $descriptionImageFormId */
/** @var string $part all | top | bottom */
$descriptionSections = [
    'top' => ['title' => '先頭のコンテンツ', 'blocks' => []],
    'bottom' => ['title' => '末尾のコンテンツ', 'blocks' => []],
];
foreach ($blocks as $block) {
    $sectionKey = (int) ($block['position'] ?? 0) === 0 ? 'top' : 'bottom';
    $descriptionSections[$sectionKey]['blocks'][] = $block;
}
$descriptionBlockIndex = 0;
if ($part === 'top') {
    unset($descriptionSections['bottom']);
} elseif ($part === 'bottom') {
    $descriptionBlockIndex = count($descriptionSections['top']['blocks']);
    unset($descriptionSections['top']);
}
?>
<div class="area is-field">
        <?php if ($part === 'bottom'): ?>
        <div data-module="c-descriptionEditor01" data-description-editor-part="bottom">
        <?php else: ?>
        <div data-module="c-descriptionEditor01" data-description-editor data-name-prefix="<?= e($namePrefix) ?>"
            data-position-mode="<?= e($positionMode) ?>">
        <?php endif; ?>
            <div class="wrapper">
                <?php foreach ($descriptionSections as $sectionKey => $section): ?>
                <div class="block is-section" data-description-section-wrap="<?= e($sectionKey) ?>">
                    <div class="area is-title">
                        <?php admin_m_left_border_title01(e($section['title'])); ?>
                    </div>
                    <div class="area is-contents">
                        <div class="c-formEditor c-formEditorList01" data-module="c-formEditorList01">
                            <div class="wrapper">
                                <div class="block is-contents" data-description-list
                                    data-description-section="<?= e($sectionKey) ?>">
                                    <?php foreach ($section['blocks'] as $block): ?>
                                        <?php admin_c_description_editor01_block(
                                            $namePrefix,
                                            $descriptionBlockIndex,
                                            $block,
                                            $descriptionImageUploadEnabled,
                                            $descriptionImageFormId
                                        ); ?>
                                        <?php $descriptionBlockIndex++; ?>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="area is-actions">
                        <?php admin_m_btn01_button_wrap('＋ 項目を追加', [
                            'type' => 'button',
                            'data-target' => 'm-formBuilder01__add',
                            'class' => 'fb-description-add',
                            'data-description-add' => $sectionKey,
                        ]); ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
</div>
