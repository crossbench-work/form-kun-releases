<?php /** SMTPテスト・Mailpit 補足（smtp / smtp_local で表示） */
    $mt = $form['mail_transport'] ?? null;
    if ($mt === null || $mt === '') {
        $mailTransportForSmtpTest = 'none';
    } else {
        $mailTransportForSmtpTest = (string) $mt;
    }
    $showSmtpTestBlock = empty($isNew) && \Core\Auth::role() === 'admin' && in_array($mailTransportForSmtpTest, ['smtp', 'smtp_local'], true);
?>
<?php if (empty($isNew) && \Core\Auth::role() === 'admin'): ?>
<div class="area is-field" data-module="c-mailSmtpTestButton01"<?= $showSmtpTestBlock ? '' : ' hidden' ?>>
    <?php admin_m_btn01_button_wrap('SMTPをテストする', [
        'type' => 'submit',
        'class' => 'is-sm',
        'formaction' => base_path('/admin/forms/' . (int) $form['id'] . '/test-smtp'),
        'formmethod' => 'post',
        'formnovalidate' => true,
    ]); ?>
    <p class="text is-help" data-mail-smtp-test-mailpit-hint<?= $mailTransportForSmtpTest === 'smtp_local' ? '' : ' hidden' ?>>Dockerのローカル環境では、ホスト <code>mailpit</code>、ポート <code>1025</code>、暗号化なし、認証なしでテストできます。受信確認は <a href="http://localhost:8025" target="_blank" rel="noopener noreferrer">Mailpit</a> を開いてください。</p>
</div>
<?php endif; ?>
