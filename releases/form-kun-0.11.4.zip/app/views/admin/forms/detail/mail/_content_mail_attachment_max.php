<?php /** メール設定 — メール添付の合計上限 */ ?>
<?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01('メール添付の合計上限', 'mail_attachment_max_mb'); ?>
    </div>
    <div class="area is-field">
        <?php admin_m_input01_open(); ?>
            <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('mail_attachment_max_mb', [
                'type' => 'number', 'name' => 'mail_attachment_max_mb', 'id' => 'mail_attachment_max_mb',
                'min' => 1, 'max' => 25, 'step' => 1,
                'value' => (string) max(1, (int) round((int) ($form['mail_attachment_max_bytes'] ?? 10485760) / 1024 / 1024)),
                'required' => true,
            ])); ?>
        <?php admin_m_input01_close(); ?>
        <p class="text is-help">MB（1〜25MB）。SMTPではMIME変換により実際のメールサイズが約1.4倍になります。</p>
    </div>
<?php admin_m_input_set01_close(); ?>

<?php if (!empty($form['smtp_test_is_current'])): ?>
<div data-module="m-alert01" class="is-success">
    <span data-module="m-text01">
        <?= '現在のSMTP設定はテスト済みです（' . e((string) ($form['smtp_tested_at'] ?? '')) . '）。' ?>
    </span>
</div>
<?php endif; ?>
