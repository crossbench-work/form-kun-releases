<?php /** c-formBlock01 直下 .area.is-field の内側: 通知設定 — SMTPパスワード（name=mail_smtp_password） */
$smtpPasswordMask = '********';
?>
    <?php admin_m_input_set01_open(); ?>
    <div class="area is-title">
        <?php admin_m_bold_title01(e('SMTPパスワード'), 'mail_smtp_password'); ?>
    </div>
    <div class="area is-field">
        <?php if (!empty($form['mail_smtp_password_configured'])): ?>
        <?php admin_m_input01_open(); ?>
        <?php admin_m_input01_input([
            'type' => 'text',
            'id' => 'mail_smtp_password_masked',
            'value' => $smtpPasswordMask,
            'readonly' => true,
            'autocomplete' => 'off',
            'aria-label' => '保存済みのSMTPパスワード',
        ]); ?>
        <?php admin_m_input01_close(); ?>
        <?php endif; ?>
        <?php admin_m_input01_open(); ?>
        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('mail_smtp_password', [
            'type' => 'password',
            'id' => 'mail_smtp_password',
            'name' => 'mail_smtp_password',
            'value' => '',
            'autocomplete' => 'new-password',
            'placeholder' => !empty($form['mail_smtp_password_configured']) ? '変更する場合のみ入力' : '',
        ])); ?>
        <?php admin_m_input01_close(); ?>
        <?php if (!empty($form['mail_smtp_password_configured'])): ?>
            <input type="hidden" name="mail_smtp_clear_password" value="0">
            <?php admin_m_checkbox01('保存済みのSMTPパスワードを削除する', [
                'name' => 'mail_smtp_clear_password',
                'value' => '1',
                'checked' => !empty($form['mail_smtp_clear_password']),
            ]); ?>
        <?php endif; ?>
    </div>
    <?php admin_m_input_set01_close(); ?>
