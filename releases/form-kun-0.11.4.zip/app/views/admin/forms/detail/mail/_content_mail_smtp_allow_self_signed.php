<?php /** 通知設定 — 自己署名（mail/none/smtp/smtp_local で送るフィールドを切替） */
    $mt = $form['mail_transport'] ?? null;
    if ($mt === null || $mt === '') {
        $mailTransportForSelfSigned = 'none';
    } else {
        $mailTransportForSelfSigned = (string) $mt;
    }
    $allowSelfSigned = !empty($form['mail_smtp_allow_self_signed']);
?>
<div class="area is-field" data-module="c-mailSmtpSelfSignedBranches01"
    data-smtp-allow-self-signed="<?= $allowSelfSigned ? '1' : '0' ?>">
    <div data-mail-smtp-selfsigned-branch="mail"<?= ($mailTransportForSelfSigned === 'mail' || $mailTransportForSelfSigned === 'none') ? '' : ' hidden' ?>>
        <input type="hidden" name="mail_smtp_allow_self_signed" value="0"<?= ($mailTransportForSelfSigned === 'mail' || $mailTransportForSelfSigned === 'none') ? '' : ' disabled' ?>>
    </div>
    <div data-mail-smtp-selfsigned-branch="smtp"<?= $mailTransportForSelfSigned === 'smtp' ? '' : ' hidden' ?>>
        <input type="hidden" name="mail_smtp_allow_self_signed" value="<?= $allowSelfSigned ? '1' : '0' ?>"<?= $mailTransportForSelfSigned === 'smtp' ? '' : ' disabled' ?>>
    </div>
    <div data-mail-smtp-selfsigned-branch="smtp_local"<?= $mailTransportForSelfSigned === 'smtp_local' ? '' : ' hidden' ?>>
        <?php admin_m_checkbox01('自己署名証明書を許可する', [
            'name' => 'mail_smtp_allow_self_signed',
            'value' => '1',
            'checked' => $allowSelfSigned,
            'id' => 'mail_smtp_allow_self_signed_local',
            'disabled' => $mailTransportForSelfSigned !== 'smtp_local',
        ]); ?>
        <p class="text is-help">ローカル開発や検証用 SMTP のみで使ってください。</p>
    </div>
</div>
