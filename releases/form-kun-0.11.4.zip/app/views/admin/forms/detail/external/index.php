<?php
/** フォーム編集:「外部連携」タブパネル */
$embedSettings = is_array($embedSettings ?? null) ? $embedSettings : \Models\FormEmbedSetting::defaults((int) ($form['id'] ?? 0));
$allowedOriginsInput = (string) ($embedSettings['allowed_origins_input'] ?? implode("\n", (array) ($embedSettings['allowed_origins'] ?? [])));
$allowedOriginRows = array_values(array_filter(array_map('trim', preg_split('/\R/u', $allowedOriginsInput) ?: []), static fn(string $value): bool => $value !== ''));
if ($allowedOriginRows === []) {
    $allowedOriginRows = [''];
}
$renderOriginRow = static function (string $value, bool $removable = true): void {
    echo '<div class="area is-row" data-target="m-inputList01__row">';
    admin_m_input01_open();
    admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_allowed_origins', [
        'type' => 'text',
        'name' => 'embed_allowed_origins[]',
        'value' => $value,
        'placeholder' => 'https://example.com',
    ]));
    admin_m_input01_close();
    if ($removable) {
        admin_m_delete_btn01('m-inputList01__remove', 'この公開サイトを削除', '削除', 'button', '-');
    }
    echo '</div>';
};
$publicUuid = trim((string) ($form['public_uuid'] ?? ''));
$embedApiUrl = $publicUuid !== '' ? url('/api/public/forms/' . $publicUuid . '/submit') : '';
$siteKey = trim((string) ($embedSettings['turnstile_site_key'] ?? 'YOUR_TURNSTILE_SITE_KEY'));
if ($siteKey === '') {
    $siteKey = 'YOUR_TURNSTILE_SITE_KEY';
}
$recaptchaSiteKey = trim((string) ($embedSettings['recaptcha_site_key'] ?? 'YOUR_RECAPTCHA_SITE_KEY'));
if ($recaptchaSiteKey === '') {
    $recaptchaSiteKey = 'YOUR_RECAPTCHA_SITE_KEY';
}
$recaptchaV3SiteKey = trim((string) ($embedSettings['recaptcha_v3_site_key'] ?? 'YOUR_RECAPTCHA_V3_SITE_KEY'));
if ($recaptchaV3SiteKey === '') {
    $recaptchaV3SiteKey = 'YOUR_RECAPTCHA_V3_SITE_KEY';
}
$captchaProvider = (string) ($embedSettings['captcha_provider'] ?? \Models\FormEmbedSetting::captchaProvider($embedSettings));
$japanOnlyProvider = (string) ($embedSettings['japan_only_provider'] ?? \Models\FormEmbedSetting::japanOnlyProvider($embedSettings));
$japanProviderLabels = [
    \Models\FormEmbedSetting::JAPAN_PROVIDER_NONE => '使用しない',
    \Models\FormEmbedSetting::JAPAN_PROVIDER_IPINFO_LITE => 'IPinfo Lite',
];
$captchaProviderLabels = [
    \Models\FormEmbedSetting::CAPTCHA_NONE => '使用しない',
    \Models\FormEmbedSetting::CAPTCHA_TURNSTILE => 'Cloudflare Turnstile',
    \Models\FormEmbedSetting::CAPTCHA_RECAPTCHA_V2 => 'Google reCAPTCHA v2チェックボックス',
    \Models\FormEmbedSetting::CAPTCHA_RECAPTCHA_V3 => 'Google reCAPTCHA v3スコア判定',
];
$embedFields = is_array($fields ?? null) ? $fields : [];
$embedFieldGroups = is_array($fieldGroups ?? null) ? $fieldGroups : [];
$embedInputPages = is_array($inputPages ?? null) ? $inputPages : [];
$embedCaptchaContext = [
    'turnstile_site_key' => $siteKey,
    'recaptcha_site_key' => $recaptchaSiteKey,
];
$embedBranchRules = is_array($branchRules ?? null) ? $branchRules : [];
$embedCssSample = \Core\EmbedCodeSample::generateCss();
$embedHtmlSamples = [];
$embedScriptSamples = [];
foreach (array_keys($captchaProviderLabels) as $embedProvider) {
    $embedHtmlSamples[$embedProvider] = \Core\EmbedCodeSample::generateFormHtml(
        $embedFields,
        $embedFieldGroups,
        $embedInputPages,
        $embedProvider,
        $embedCaptchaContext,
        is_array($form ?? null) ? $form : []
    );
    $embedScriptSamples[$embedProvider] = \Core\EmbedCodeSample::generateScript(
        $embedFields,
        $embedFieldGroups,
        $embedInputPages,
        $embedBranchRules,
        $embedProvider,
        $embedApiUrl,
        $recaptchaV3SiteKey
    );
}

$embedLoaderSample = \Core\EmbedCodeSample::generateLoaderScript(
    $embedFields,
    $embedFieldGroups,
    $embedInputPages,
    $embedBranchRules,
    $captchaProvider,
    $embedApiUrl,
    $embedCaptchaContext,
    is_array($form ?? null) ? $form : [],
    $recaptchaV3SiteKey,
    $publicUuid
);
$renderEmbedReadonlyCode = static function (string $code, int $rows, string $ariaLabel, string $emptyHelp = 'フォーム作成後に表示されます。'): void {
    if ($code === '') {
        echo '<p class="text is-help">' . e($emptyHelp) . '</p>';
        return;
    }
    admin_m_input01_open();
    admin_m_input01_textarea(['rows' => $rows, 'readonly' => true, 'aria-label' => $ariaLabel], $code);
    admin_m_input01_close();
};
$turnstileHeadSample = '<script src="https://challenges.cloudflare.com/turnstile/v0/api.js" async defer></script>';
$recaptchaV2HeadSample = '<script src="https://www.google.com/recaptcha/api.js" async defer></script>';
$recaptchaV3HeadSample = '<script src="https://www.google.com/recaptcha/api.js?render=' . rawurlencode($recaptchaV3SiteKey) . '" async defer></script>';
?>
<div data-target="c-formEditTabs01__contents" data-tab-panel="external" class="area is-contents" role="tabpanel"
    aria-label="外部連携" hidden>
    <?php admin_c_form_block01_open(['data-module' => 'c-embedCaptcha01']); ?>
        <div class="area is-title">
            <?php admin_m_large_title01('外部埋め込み機能'); ?>
        </div>
        <div class="area is-field">
            <input type="hidden" name="embed_enabled" value="0">
            <input type="checkbox" name="embed_enabled" value="1" hidden data-target="c-embedEnabled01__state"<?= !empty($embedSettings['enabled']) ? ' checked' : '' ?>>
            <div data-target="c-embedEnabled01__enableWrap"<?= !empty($embedSettings['enabled']) ? ' hidden' : '' ?>>
                <?php admin_m_btn01_open(); ?>
                    <?php admin_m_btn01_button('外部HTMLからの送信を許可する', [
                        'type' => 'button',
                        'class' => 'is-primary',
                        'data-target' => 'c-embedEnabled01__enable',
                    ]); ?>
                <?php admin_m_btn01_close(); ?>
            </div>
        </div>
        <div data-target="c-embedEnabled01__panel"<?= empty($embedSettings['enabled']) ? ' hidden' : '' ?>>
        <div class="area is-field">
            <input type="hidden" name="embed_public_page_hidden" value="0">
            <?php admin_m_checkbox01('フォームを非表示にする', [
                'name' => 'embed_public_page_hidden',
                'value' => '1',
                'checked' => ($form['status'] ?? '') === 'hidden',
            ]); ?>
            <p class="text is-help">有効にすると入力・確認・送信画面が非公開になります。</p>
        </div>
        <div class="area is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title"><?php admin_m_bold_title01('公開サイト', 'embed_allowed_origins'); ?></div>
                <div class="area is-field">
                    <div data-module="m-inputList01" data-max="50">
                        <div class="block is-rows" data-target="m-inputList01__rows">
                            <?php foreach ($allowedOriginRows as $originIndex => $originRow): ?>
                                <?php $renderOriginRow($originRow, $originIndex > 0); ?>
                            <?php endforeach; ?>
                        </div>
                        <template data-target="m-inputList01__template"><?php $renderOriginRow(''); ?></template>
                        <div class="block is-add">
                            <?php admin_m_btn01_open(); ?>
                                <?php admin_m_btn01_button('＋ 追加', [
                                    'type' => 'button',
                                    'data-target' => 'm-inputList01__add',
                                    'disabled' => count($allowedOriginRows) >= 50,
                                ]); ?>
                            <?php admin_m_btn01_close(); ?>
                        </div>
                    </div>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="block">
            <div class="area is-title"><?php admin_m_left_border_title01(e('送信完了画面'), 'embed_completion_url'); ?></div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_completion_url', [
                    'type' => 'url',
                    'id' => 'embed_completion_url',
                    'name' => 'embed_completion_url',
                    'value' => (string) ($embedSettings['completion_url'] ?? ''),
                    'placeholder' => 'https://example.com/thanks.html',
                ])); ?>
                <?php admin_m_input01_close(); ?>
                <p class="text is-help">送信成功時に設定されたURLへ遷移します。空欄の場合は画面遷移しません。</p>
            </div>
        </div>
        <div class="block">
            <div class="area is-title"><?php admin_m_left_border_title01(e('国外送信対策'), 'embed_japan_only_provider'); ?></div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                    <select id="embed_japan_only_provider" name="embed_japan_only_provider" data-target="c-embedCaptcha01__japanProvider"<?= admin_m_bold_title01_aria_labelledby_attr('embed_japan_only_provider') ?>>
                        <?php foreach ($japanProviderLabels as $providerValue => $providerLabel): ?>
                            <option value="<?= e($providerValue) ?>"<?= $japanOnlyProvider === $providerValue ? ' selected' : '' ?>><?= e($providerLabel) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php admin_m_input01_close(); ?>
            </div>
            <div class="area is-field" data-japan-panel="ipinfo_lite"<?= $japanOnlyProvider !== \Models\FormEmbedSetting::JAPAN_PROVIDER_IPINFO_LITE ? ' hidden' : '' ?>>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title"><?php admin_m_bold_title01('トークン', 'embed_ipinfo_lite_token'); ?></div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_ipinfo_lite_token', [
                            'type' => 'password', 'id' => 'embed_ipinfo_lite_token', 'name' => 'embed_ipinfo_lite_token',
                            'value' => '', 'placeholder' => !empty($embedSettings['ipinfo_lite_token_configured']) ? '●●●●●●●●' : '',
                            'autocomplete' => 'new-password',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                        <p class="text is-help">空欄のまま保存すると現在の値を保持します。<?= !empty($embedSettings['ipinfo_lite_token_configured']) ? '現在は設定済みです。' : '現在は未設定です。' ?></p>
                        <?php if (!empty($embedSettings['ipinfo_lite_token_configured'])): ?>
                            <input type="hidden" name="embed_ipinfo_lite_token_clear" value="0">
                            <?php admin_m_checkbox01('保存済みのトークンを削除する', [
                                'name' => 'embed_ipinfo_lite_token_clear', 'value' => '1',
                                'checked' => !empty($embedSettings['ipinfo_lite_token_clear']),
                            ]); ?>
                        <?php endif; ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
            </div>
        </div>
        <div class="block">
            <div class="area is-title"><?php admin_m_left_border_title01(e('不正送信対策'), 'embed_captcha_provider'); ?></div>
            <div class="area is-field">
                <?php admin_m_input01_open(); ?>
                    <select id="embed_captcha_provider" name="embed_captcha_provider" data-target="c-embedCaptcha01__provider"<?= admin_m_bold_title01_aria_labelledby_attr('embed_captcha_provider') ?>>
                        <?php foreach ($captchaProviderLabels as $providerValue => $providerLabel): ?>
                            <option value="<?= e($providerValue) ?>"<?= $captchaProvider === $providerValue ? ' selected' : '' ?>><?= e($providerLabel) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php admin_m_input01_close(); ?>
            </div>
            <div class="area is-field" data-captcha-panel="turnstile"<?= $captchaProvider !== 'turnstile' ? ' hidden' : '' ?>>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title"><?php admin_m_bold_title01('サイトキー', 'embed_turnstile_site_key'); ?></div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_turnstile_site_key', [
                            'type' => 'text', 'id' => 'embed_turnstile_site_key', 'name' => 'embed_turnstile_site_key',
                            'value' => (string) ($embedSettings['turnstile_site_key'] ?? ''), 'autocomplete' => 'off',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title"><?php admin_m_bold_title01('シークレットキー', 'embed_turnstile_secret_key'); ?></div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_turnstile_secret_key', [
                            'type' => 'password', 'id' => 'embed_turnstile_secret_key', 'name' => 'embed_turnstile_secret_key',
                            'value' => '', 'placeholder' => !empty($embedSettings['turnstile_secret_configured']) ? '●●●●●●●●' : '',
                            'autocomplete' => 'new-password',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                        <p class="text is-help">空欄のまま保存すると現在の値を保持します。<?= !empty($embedSettings['turnstile_secret_configured']) ? '現在は設定済みです。' : '現在は未設定です。' ?></p>
                        <?php if (!empty($embedSettings['turnstile_secret_configured'])): ?>
                            <input type="hidden" name="embed_turnstile_secret_clear" value="0">
                            <?php admin_m_checkbox01('保存済みのシークレットキーを削除する', [
                                'name' => 'embed_turnstile_secret_clear', 'value' => '1',
                                'checked' => !empty($embedSettings['turnstile_secret_clear']),
                            ]); ?>
                        <?php endif; ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
            </div>
            <div class="area is-field" data-captcha-panel="recaptcha_v2"<?= $captchaProvider !== 'recaptcha_v2' ? ' hidden' : '' ?>>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title"><?php admin_m_bold_title01('サイトキー', 'embed_recaptcha_site_key'); ?></div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_recaptcha_site_key', [
                            'type' => 'text', 'id' => 'embed_recaptcha_site_key', 'name' => 'embed_recaptcha_site_key',
                            'value' => (string) ($embedSettings['recaptcha_site_key'] ?? ''), 'autocomplete' => 'off',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title"><?php admin_m_bold_title01('シークレットキー', 'embed_recaptcha_secret_key'); ?></div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_recaptcha_secret_key', [
                            'type' => 'password', 'id' => 'embed_recaptcha_secret_key', 'name' => 'embed_recaptcha_secret_key',
                            'value' => '', 'placeholder' => !empty($embedSettings['recaptcha_secret_configured']) ? '●●●●●●●●' : '',
                            'autocomplete' => 'new-password',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                        <p class="text is-help">空欄のまま保存すると現在の値を保持します。<?= !empty($embedSettings['recaptcha_secret_configured']) ? '現在は設定済みです。' : '現在は未設定です。' ?></p>
                        <?php if (!empty($embedSettings['recaptcha_secret_configured'])): ?>
                            <input type="hidden" name="embed_recaptcha_secret_clear" value="0">
                            <?php admin_m_checkbox01('保存済みのシークレットキーを削除する', [
                                'name' => 'embed_recaptcha_secret_clear', 'value' => '1',
                                'checked' => !empty($embedSettings['recaptcha_secret_clear']),
                            ]); ?>
                        <?php endif; ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
            </div>
            <div class="area is-field" data-captcha-panel="recaptcha_v3"<?= $captchaProvider !== 'recaptcha_v3' ? ' hidden' : '' ?>>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title"><?php admin_m_bold_title01('サイトキー', 'embed_recaptcha_v3_site_key'); ?></div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_recaptcha_v3_site_key', [
                            'type' => 'text', 'id' => 'embed_recaptcha_v3_site_key', 'name' => 'embed_recaptcha_v3_site_key',
                            'value' => (string) ($embedSettings['recaptcha_v3_site_key'] ?? ''), 'autocomplete' => 'off',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title"><?php admin_m_bold_title01('シークレットキー', 'embed_recaptcha_v3_secret_key'); ?></div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_recaptcha_v3_secret_key', [
                            'type' => 'password', 'id' => 'embed_recaptcha_v3_secret_key', 'name' => 'embed_recaptcha_v3_secret_key',
                            'value' => '', 'placeholder' => !empty($embedSettings['recaptcha_v3_secret_configured']) ? '●●●●●●●●' : '',
                            'autocomplete' => 'new-password',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                        <p class="text is-help">空欄のまま保存すると現在の値を保持します。<?= !empty($embedSettings['recaptcha_v3_secret_configured']) ? '現在は設定済みです。' : '現在は未設定です。' ?></p>
                        <?php if (!empty($embedSettings['recaptcha_v3_secret_configured'])): ?>
                            <input type="hidden" name="embed_recaptcha_v3_secret_clear" value="0">
                            <?php admin_m_checkbox01('保存済みのシークレットキーを削除する', [
                                'name' => 'embed_recaptcha_v3_secret_clear', 'value' => '1',
                                'checked' => !empty($embedSettings['recaptcha_v3_secret_clear']),
                            ]); ?>
                        <?php endif; ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title"><?php admin_m_bold_title01('合格スコア', 'embed_recaptcha_v3_min_score'); ?></div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_recaptcha_v3_min_score', [
                            'type' => 'number', 'id' => 'embed_recaptcha_v3_min_score', 'name' => 'embed_recaptcha_v3_min_score',
                            'value' => (string) ($embedSettings['recaptcha_v3_min_score'] ?? 0.5),
                            'min' => '0', 'max' => '1', 'step' => '0.01',
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                        <p class="text is-help">0.0〜1.0で設定します。既定値は0.5です。actionはsubmit固定です。</p>
                    </div>
                <?php admin_m_input_set01_close(); ?>
            </div>
        </div>
        <div class="block">
            <div class="area is-title"><?php admin_m_left_border_title01(e('埋め込みコード')); ?></div>
            <div class="area is-field">
                <div data-module="c-embedCodeTabs01">
                <?php admin_m_input01_open(); ?>
                    <?php admin_m_input01_select_open(['data-target' => 'c-embedCodeTabs01__method']); ?>
                        <?php admin_m_input01_option('load', '読み込み', true); ?>
                        <?php admin_m_input01_option('embed', '埋め込み'); ?>
                    <?php admin_m_input01_select_close(); ?>
                <?php admin_m_input01_close(); ?>
                    <div data-embed-method-panel="load">
                        <?php admin_c_form_edit_section_tabs01_open('embed-code-load', [
                            ['panel' => 'embed-code-load-head', 'label' => 'head', 'selected' => true],
                            ['panel' => 'embed-code-load-body', 'label' => 'body'],
                        ], '埋め込みコード'); ?>
                            <div data-target="c-formEditTabs01__contents" data-tab-panel="embed-code-load-head" class="area is-contents" role="tabpanel" aria-label="head">
                                <div class="area is-field">
                                    <?php admin_m_bold_title01('head', 'embed_loader_head'); ?>
                                    <?php admin_m_input01_open(); ?>
                                        <?php admin_m_input01_textarea(['rows' => 3, 'readonly' => true, 'aria-label' => '読み込み方式 head'], "<link rel=\"stylesheet\" href=\"" . e(url('/embed/form-kun.css')) . "\">\n<script src=\"" . e(url('/embed/forms/' . $publicUuid . '/form-kun.js')) . "\" defer></script>"); ?>
                                    <?php admin_m_input01_close(); ?>
                                </div>
                            </div>
                            <div data-target="c-formEditTabs01__contents" data-tab-panel="embed-code-load-body" class="area is-contents" role="tabpanel" aria-label="body" hidden>
                                <div class="area is-field">
                                    <?php admin_m_bold_title01('body', 'embed_loader_body'); ?>
                                    <?php admin_m_input01_open(); ?>
                                        <?php admin_m_input01_textarea(['rows' => 2, 'readonly' => true, 'aria-label' => '読み込み方式 body'], "<form id=\"contact-form\" data-formkun=\"" . e($publicUuid) . "\"></form>"); ?>
                                    <?php admin_m_input01_close(); ?>
                                </div>
                            </div>
                        <?php admin_c_form_edit_section_tabs01_close(); ?>
                        <p class="text is-help">CSP がある場合は form-kun のドメインを script-src / style-src / connect-src に許可してください。</p>
                    </div>
                    <div data-embed-method-panel="embed" hidden>
                        <?php
                        $embedTabs = [];
                        if ($captchaProvider !== \Models\FormEmbedSetting::CAPTCHA_NONE) {
                            $embedTabs[] = ['panel' => 'embed-code-head', 'label' => 'head', 'selected' => true];
                        }
                        $embedTabs[] = ['panel' => 'embed-code-html', 'label' => 'html', 'selected' => $captchaProvider === \Models\FormEmbedSetting::CAPTCHA_NONE];
                        $embedTabs[] = ['panel' => 'embed-code-css', 'label' => 'css'];
                        $embedTabs[] = ['panel' => 'embed-code-javascript', 'label' => 'javascript'];
                        ?>
                        <?php admin_c_form_edit_section_tabs01_open('embed-code', $embedTabs, '埋め込みコード'); ?>
                            <div data-target="c-formEditTabs01__contents" data-tab-panel="embed-code-head" class="area is-contents" role="tabpanel" aria-label="head"<?= $captchaProvider === \Models\FormEmbedSetting::CAPTCHA_NONE ? ' hidden' : '' ?>>
                                <div class="area is-field" data-captcha-panel="turnstile"<?= $captchaProvider !== 'turnstile' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode($turnstileHeadSample, 3, '埋め込みコード head（Turnstile）'); ?>
                                </div>
                                <div class="area is-field" data-captcha-panel="recaptcha_v2"<?= $captchaProvider !== 'recaptcha_v2' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode($recaptchaV2HeadSample, 3, '埋め込みコード head（reCAPTCHA v2）'); ?>
                                </div>
                                <div class="area is-field" data-captcha-panel="recaptcha_v3"<?= $captchaProvider !== 'recaptcha_v3' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode($recaptchaV3HeadSample, 3, '埋め込みコード head（reCAPTCHA v3）'); ?>
                                </div>
                            </div>
                            <div data-target="c-formEditTabs01__contents" data-tab-panel="embed-code-html" class="area is-contents" role="tabpanel" aria-label="html"<?= $captchaProvider !== \Models\FormEmbedSetting::CAPTCHA_NONE ? ' hidden' : '' ?>>
                                <div class="area is-field" data-captcha-panel="none"<?= $captchaProvider !== 'none' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode(
                                        $embedHtmlSamples[\Models\FormEmbedSetting::CAPTCHA_NONE],
                                        22,
                                        '埋め込みコード html',
                                        '入力項目を追加すると HTML が表示されます。'
                                    ); ?>
                                </div>
                                <div class="area is-field" data-captcha-panel="turnstile"<?= $captchaProvider !== 'turnstile' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode(
                                        $embedHtmlSamples[\Models\FormEmbedSetting::CAPTCHA_TURNSTILE],
                                        22,
                                        '埋め込みコード html',
                                        '入力項目を追加すると HTML が表示されます。'
                                    ); ?>
                                </div>
                                <div class="area is-field" data-captcha-panel="recaptcha_v2"<?= $captchaProvider !== 'recaptcha_v2' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode(
                                        $embedHtmlSamples[\Models\FormEmbedSetting::CAPTCHA_RECAPTCHA_V2],
                                        22,
                                        '埋め込みコード html',
                                        '入力項目を追加すると HTML が表示されます。'
                                    ); ?>
                                </div>
                                <div class="area is-field" data-captcha-panel="recaptcha_v3"<?= $captchaProvider !== 'recaptcha_v3' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode(
                                        $embedHtmlSamples[\Models\FormEmbedSetting::CAPTCHA_RECAPTCHA_V3],
                                        22,
                                        '埋め込みコード html',
                                        '入力項目を追加すると HTML が表示されます。'
                                    ); ?>
                                </div>
                            </div>
                            <div data-target="c-formEditTabs01__contents" data-tab-panel="embed-code-css" class="area is-contents" role="tabpanel" aria-label="css" hidden>
                                <?php $renderEmbedReadonlyCode($embedCssSample, 22, '埋め込みコード css'); ?>
                            </div>
                            <div data-target="c-formEditTabs01__contents" data-tab-panel="embed-code-javascript" class="area is-contents" role="tabpanel" aria-label="javascript" hidden>
                                <div class="area is-field" data-captcha-panel="none"<?= $captchaProvider !== 'none' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode($embedScriptSamples[\Models\FormEmbedSetting::CAPTCHA_NONE], 22, '埋め込みコード javascript'); ?>
                                </div>
                                <div class="area is-field" data-captcha-panel="turnstile"<?= $captchaProvider !== 'turnstile' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode($embedScriptSamples[\Models\FormEmbedSetting::CAPTCHA_TURNSTILE], 22, '埋め込みコード javascript'); ?>
                                </div>
                                <div class="area is-field" data-captcha-panel="recaptcha_v2"<?= $captchaProvider !== 'recaptcha_v2' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode($embedScriptSamples[\Models\FormEmbedSetting::CAPTCHA_RECAPTCHA_V2], 22, '埋め込みコード javascript'); ?>
                                </div>
                                <div class="area is-field" data-captcha-panel="recaptcha_v3"<?= $captchaProvider !== 'recaptcha_v3' ? ' hidden' : '' ?>>
                                    <?php $renderEmbedReadonlyCode($embedScriptSamples[\Models\FormEmbedSetting::CAPTCHA_RECAPTCHA_V3], 22, '埋め込みコード javascript'); ?>
                                </div>
                            </div>
                        <?php admin_c_form_edit_section_tabs01_close(); ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="block">
            <div class="area is-title"><?php admin_m_left_border_title01(e('送信回数制限')); ?></div>
            <div class="area is-field">
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title"><?php admin_m_bold_title01('上限回数', 'embed_rate_limit_count'); ?></div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_rate_limit_count', [
                            'type' => 'number', 'id' => 'embed_rate_limit_count', 'name' => 'embed_rate_limit_count',
                            'value' => (string) ($embedSettings['rate_limit_count'] ?? 10), 'min' => 1, 'max' => 1000,
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title"><?php admin_m_bold_title01('制限期間（秒）', 'embed_rate_limit_window_seconds'); ?></div>
                    <div class="area is-field">
                        <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('embed_rate_limit_window_seconds', [
                            'type' => 'number', 'id' => 'embed_rate_limit_window_seconds', 'name' => 'embed_rate_limit_window_seconds',
                            'value' => (string) ($embedSettings['rate_limit_window_seconds'] ?? 600), 'min' => 60, 'max' => 86400,
                        ])); ?>
                        <?php admin_m_input01_close(); ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
            </div>
        </div>
        <div class="area is-field" data-target="c-embedEnabled01__disconnectWrap">
            <?php admin_m_btn01_open(); ?>
                <?php admin_m_btn01_button('連携解除', [
                    'type' => 'button',
                    'data-target' => 'c-embedEnabled01__disconnect',
                ]); ?>
            <?php admin_m_btn01_close(); ?>
        </div>
        </div>
    <?php admin_c_form_block01_close(); ?>
</div>
