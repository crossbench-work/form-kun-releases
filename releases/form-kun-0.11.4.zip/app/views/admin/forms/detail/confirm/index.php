<?php
/** フォーム編集:「確認画面」タブパネル
 * _content_*.php … c-formBlock01 直下 .area.is-field の内側。説明文は confirm_blocks エディタを本ファイルに残す。
 */
?>
<div data-target="c-formEditTabs01__contents" data-tab-panel="screen-confirm" class="area is-contents" role="tabpanel"
    aria-label="確認画面" hidden>
    <?php admin_c_form_block01_open(); ?>
        <div class="area is-title">
            <?php admin_m_large_title01('確認画面'); ?>
        </div>
        <?php admin_c_description_editor01('confirm_blocks', $confirmBlocks, 'simple', !$isNew, (int) ($form['id'] ?? 0), 'top'); ?>
        <div class="block">
            <div class="area is-title">
                <?php admin_m_left_border_title01(e('ボタン')); ?>
            </div>
            <div class="area is-field">
                <?php require __DIR__ . '/_content_confirm_buttons.php'; ?>
            </div>
        </div>
        <?php admin_c_description_editor01('confirm_blocks', $confirmBlocks, 'simple', !$isNew, (int) ($form['id'] ?? 0), 'bottom'); ?>
    <?php admin_c_form_block01_close(); ?>
</div>
