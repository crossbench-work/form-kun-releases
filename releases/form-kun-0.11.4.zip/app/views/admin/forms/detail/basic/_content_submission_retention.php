<?php /** c-formBlock01 直下 .area.is-field の内側: 基本設定ブロック — 履歴の保存期間（name=submission_retention_enabled / submission_retention_days / submission_retention_action） */ ?>
<?php
$retentionEditable = \Core\Auth::role() === 'admin';
$retentionEnabled = \Models\Form::retentionEnabled($form);
$retentionDays = (string) \Models\Form::normalizeRetentionDays($form['submission_retention_days'] ?? \Models\Form::DEFAULT_RETENTION_DAYS);
$retentionDeletes = \Models\Form::normalizeRetentionAction($form['submission_retention_action'] ?? '') === \Models\Form::RETENTION_DELETE;
$retentionConfirmAttrs = [];
$retentionStoredForm = $retentionEditable && !empty($form['id']) ? \Models\Form::find((int) $form['id']) : null;
if ($retentionStoredForm !== null) {
    $retentionConfirmAttrs = [
        'data-retention-confirm' => true,
        'data-retention-preview-url' => base_path('/admin/forms/' . (int) $retentionStoredForm['id'] . '/retention-preview'),
        'data-retention-initial' => json_encode([
            'enabled' => \Models\Form::retentionEnabled($retentionStoredForm) ? '1' : '0',
            'days' => (string) \Models\Form::retentionDays($retentionStoredForm),
            'action' => \Models\Form::retentionDeletes($retentionStoredForm) ? \Models\Form::RETENTION_DELETE : \Models\Form::RETENTION_WARN,
        ]),
    ];
}
?>
        <?php admin_m_input_set01_open($retentionConfirmAttrs); ?>
        <div class="area is-title">
            <?php admin_m_left_border_title01(e('履歴の保存期間')); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_radiobtn01('設定する', [
                'name' => 'submission_retention_enabled', 'value' => '1',
                'checked' => $retentionEnabled,
                'disabled' => !$retentionEditable,
            ]); ?>
            <?php admin_m_radiobtn01('設定しない', [
                'name' => 'submission_retention_enabled', 'value' => '0',
                'checked' => !$retentionEnabled,
                'disabled' => !$retentionEditable,
            ]); ?>
            <div data-retention-detail<?= $retentionEnabled ? '' : ' hidden' ?>>
                <?php admin_m_input01_open('is-inline'); ?>
                    <?php admin_m_input01_input([
                        'type' => 'number',
                        'id' => 'submission_retention_days',
                        'name' => 'submission_retention_days',
                        'min' => \Models\Form::MIN_RETENTION_DAYS,
                        'max' => \Models\Form::MAX_RETENTION_DAYS,
                        'step' => 1,
                        'value' => $retentionDays,
                        'required' => $retentionEnabled,
                        'disabled' => !$retentionEditable,
                        'aria-label' => '保存期間（日）',
                        'style' => 'width:120px',
                    ]); ?>
                    <span class="text is-unit">日</span>
                <?php admin_m_input01_close(); ?>
            </div>
            <?php if (!$retentionEditable): ?>
                <p class="text is-help">保存期間の設定は admin のみ変更できます。</p>
            <?php endif; ?>
        </div>
        <?php admin_m_input_set01_close(); ?>
        <?php admin_m_input_set01_open(['data-retention-detail' => true, 'hidden' => !$retentionEnabled]); ?>
        <div class="area is-title">
            <?php admin_m_left_border_title01(e('期間を過ぎた履歴')); ?>
        </div>
        <div class="area is-field">
            <?php admin_m_radiobtn01('削除せずに警告を出す', [
                'name' => 'submission_retention_action', 'value' => \Models\Form::RETENTION_WARN,
                'checked' => !$retentionDeletes,
                'disabled' => !$retentionEditable,
            ]); ?>
            <?php admin_m_radiobtn01('削除する', [
                'name' => 'submission_retention_action', 'value' => \Models\Form::RETENTION_DELETE,
                'checked' => $retentionDeletes,
                'disabled' => !$retentionEditable,
            ]); ?>
            <p class="text is-help" data-retention-note="<?= e(\Models\Form::RETENTION_WARN) ?>"<?= $retentionDeletes ? ' hidden' : '' ?>>保存期間を過ぎた受信履歴には警告マークが表示されます</p>
            <p class="text is-help" data-retention-note="<?= e(\Models\Form::RETENTION_DELETE) ?>"<?= $retentionDeletes ? '' : ' hidden' ?>>保存期間を過ぎた受信履歴と添付ファイルは削除され元に戻せません</p>
        </div>
        <?php admin_m_input_set01_close(); ?>
