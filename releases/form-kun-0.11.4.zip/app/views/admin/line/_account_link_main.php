<?php
/**
 * LINE 連携のメイン UI（設定 → LINE 連携 / フォームの個別連携で共通）
 *
 * @var \Core\LineAccountScope $lineScope
 * @var array<string, list<string>> $lineCredentialErrors
 * @var bool $lineAccountLinkComplete
 */
use Models\Form;

$lineUrls = $lineScope->adminUrls();
$lineSetupChecklistPostUrl = $lineUrls['setup_checklist'];
$lineTalkSetupChecklistSyncUrl = $lineUrls['talk_setup_checklist'];
$lineWebhookTargetDeleteUrl = $lineUrls['webhook_target_delete'];
$lineWebhookFormId = $lineScope->isSite() ? 0 : $lineScope->formId();
?>
<?php if (!$lineAccountLinkComplete): ?>
<div class="area is-title">
    <?php admin_m_left_border_title01(e('アカウント連携の設定')); ?>
</div>
<?php endif; ?>
<div class="area is-field">
<?php
if ($lineAccountLinkComplete) {
    require __DIR__ . '/_account_link_linked_compact.php';
} else {
    $checklistDefs = $lineScope->isSite()
        ? \Core\LineSiteConfig::siteChecklistItemDefinitions()
        : Form::lineSetupChecklistItemDefinitions();
    admin_c_line_setup_checklist01(
        $checklistDefs,
        $lineScope->lineSetupChecklistStateForDisplay(),
        $lineSetupChecklistPostUrl,
        true,
        static function (string $itemKey) use ($lineSiteForm, $lineCredentialErrors, $lineScope): void {
            if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_SECRET) {
                $lineCredentialHideTitle = true;
                $lineCredentialContext = $lineScope->isSite() ? 'site' : 'form';
                $form = $lineSiteForm;
                require APP_DIR . '/views/admin/forms/detail/mail/_content_line_channel_secret.php';

                return;
            }
            if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_CHANNEL_ACCESS_TOKEN) {
                $lineCredentialHideTitle = true;
                $lineCredentialContext = $lineScope->isSite() ? 'site' : 'form';
                $form = $lineSiteForm;
                require APP_DIR . '/views/admin/forms/detail/mail/_content_line_channel_access_token.php';

                return;
            }
            if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_WEBHOOK_URL) {
                $lineWebhookHideTitle = true;
                $lineWebhookScope = $lineScope;
                require APP_DIR . '/views/admin/forms/detail/mail/_content_line_webhook_url.php';

                return;
            }
            if ($itemKey === Form::LINE_SETUP_CHECKLIST_LINE_TALK_SEND_SETUP) {
                $lineTalkSetupContext = $lineScope->isSite() ? 'site' : 'form';
                require APP_DIR . '/views/admin/forms/detail/mail/_content_line_talk_setup.php';

                return;
            }
            if ($itemKey === Form::LINE_SETUP_CHECKLIST_SET_LINE_PUSH_TO_ID) {
                $linePushToIdHideTitle = true;
                $linePushToIdHideHelp = true;
                $linePushToIdInlineSave = true;
                $linePushToIdContext = $lineScope->isSite() ? 'site' : 'form';
                $form = $lineSiteForm;
                require APP_DIR . '/views/admin/forms/detail/mail/_content_line_push_to_id.php';

                return;
            }
            if ($itemKey === Form::LINE_SETUP_CHECKLIST_LINE_TALK_NOTIFY_TEST) {
                $lineNotifyTestContext = $lineScope->isSite() ? 'site' : 'form';
                $form = $lineSiteForm;
                require APP_DIR . '/views/admin/forms/detail/mail/_content_line_notify_test.php';

                return;
            }
        }
    );
}
?>
</div>
