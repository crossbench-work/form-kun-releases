<?php /** 設定 → LINE 連携（サイト共通） */
use Core\LineAccountScope;
use Core\LineSiteConfig;

$lineSiteForm = array_merge(['id' => 0], LineSiteConfig::viewContext());
$lineCredentialErrors = $line_credential_errors ?? [];
$lineScope = LineAccountScope::site();
$lineAccountLinkComplete = LineSiteConfig::isSetupComplete();
?>
<form method="post" action="#" id="settings-line-form">
    <?= \Core\Csrf::field() ?>
    <?php admin_c_form_block01_open(); ?>
    <div class="area is-title">
        <?php admin_m_large_title01('LINE 連携'); ?>
    </div>
    <div class="block is-lineAccountLink">
        <?php require APP_DIR . '/views/admin/line/_account_link_main.php'; ?>
    </div>
    <div class="block is-lineAccountUnlink">
    <div class="area is-title">
        <?php admin_m_left_border_title01(e('アカウント連携の解除')); ?>
    </div>
    <div class="area is-field">
        <?php
        $lineAccountUnlinkUrl = base_path('/admin/settings/line/account-unlink');
        $lineAccountUnlinkContext = 'site';
        require APP_DIR . '/views/admin/forms/detail/mail/_content_line_account_unlink.php';
        ?>
    </div>
    </div>
    <?php admin_c_form_block01_close(); ?>
</form>
