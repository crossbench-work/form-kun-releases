<?php require_once APP_COMPONENTS_DIR . '/c-formBlock01/c-formBlock01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-largeTitle01/m-largeTitle01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-inputSet01/m-inputSet01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-input01/m-input01.php'; ?>
<?php require_once APP_COMPONENTS_DIR . '/m-boldTitle01/m-boldTitle01.php'; ?>
<?php
$FB_REGEX_CUSTOM = '__custom__';
$FB_REGEX_CHECKBOX_LIMIT = '__checkbox_limit__';
$regexPresetChoices = [
    '' => 'なし',
    '/\A[^\s@]+@[^\s@]+\.[^\s@]+\z/u' => 'メールアドレス',
    '/\A(?:\+?\d[\d\-() ]*)\z/u' => '電話番号',
    '/\A[0-9]+\z/u' => '半角数字のみ',
    '/\A[a-zA-Z0-9]+\z/u' => '半角英数字のみ',
    '/\A[ぁ-んー]+\z/u' => 'ひらがなのみ',
    '/\A[ァ-ヶー　]+\z/u' => 'カタカナのみ（全角スペース可）',
    '/\A[a-zA-Z]+\z/u' => '半角英字のみ',
    $FB_REGEX_CUSTOM => 'カスタム（正規表現を入力）',
];
$renderTemplateEditor = static function (?array $template, string $action, string $titleId): void {
    $fields = is_array($template['fields'] ?? null) ? $template['fields'] : [];
    $fieldGroups = is_array($template['field_groups'] ?? null) ? $template['field_groups'] : [];
    $pageFields = $fields;
    $fieldTemplates = [];
    $inputPage = [
        'page_key' => \Models\FormInputPage::DEFAULT_KEY,
        'title' => '入力画面',
    ];
    ?>
    <form method="post" action="<?= e($action) ?>" data-template-editor-form="1">
        <?= \Core\Csrf::field() ?>
        <div class="block is-field">
            <?php admin_m_input_set01_open(); ?>
                <div class="area is-title">
                    <?php admin_m_bold_title01('ラベル', $titleId); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input([
                            'type' => 'text',
                            'name' => 'title',
                            'id' => $titleId,
                            'value' => (string) ($template['title'] ?? ''),
                            'required' => true,
                            'maxlength' => 200,
                        ]); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
            <?php admin_m_input_set01_close(); ?>
        </div>
        <div class="block is-title">
            <p data-module="m-borderTitle01">項目設定</p>
        </div>
        <div class="block is-field" data-module="m-formBuilder01">
            <?php include APP_DIR . '/views/admin/forms/detail/form/_content_items.php'; ?>
        </div>
        <div class="block is-field">
            <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary'], 'center'); ?>
        </div>
    </form>
    <?php
};
$renderBuiltinTemplatePreview = static function (array $template): void {
    $fields = is_array($template['fields'] ?? null) ? $template['fields'] : [];
    $fieldGroups = is_array($template['field_groups'] ?? null) ? $template['field_groups'] : [];
    $pageFields = $fields;
    $fieldTemplates = [];
    $isReadOnlyTemplatePreview = true;
    $inputPage = [
        'page_key' => \Models\FormInputPage::DEFAULT_KEY,
        'title' => '入力画面',
    ];
    ?>
    <p data-module="m-text01" data-type="muted">このテンプレートは編集・削除できません。フォーム編集画面の項目設定で使用できます。</p>
    <div class="block is-title">
        <p data-module="m-borderTitle01">項目設定</p>
    </div>
    <div class="block is-field" data-module="m-formBuilder01">
        <fieldset class="c-fieldTemplateList01__readonly" disabled>
            <?php include APP_DIR . '/views/admin/forms/detail/form/_content_items.php'; ?>
        </fieldset>
    </div>
    <?php
};
if (!function_exists('admin_settings_value_text01')) {
    function admin_settings_value_text01(string $label, string $id, string $value, string $helpHtml = '', string $actionHtml = ''): void
    {
        admin_m_input_set01_open();
        echo '<div class="area is-title">';
        admin_m_bold_title01(e($label), $id);
        echo '</div>';
        echo '<div class="area is-field">';
        echo '<p class="text is-value" id="' . e($id) . '">' . e($value) . '</p>';
        echo '</div>';
        if ($helpHtml !== '') {
            echo '<div class="area is-help">' . $helpHtml . '</div>';
        }
        if ($actionHtml !== '') {
            echo '<div class="area is-actions">' . $actionHtml . '</div>';
        }
        admin_m_input_set01_close();
    }
}

if (!function_exists('admin_settings_left_border_value01')) {
    function admin_settings_left_border_value01(string $label, string $id, string $value, string $helpHtml = '', string $actionHtml = ''): void
    {
        echo '<div class="block">';
        echo '<div class="area is-title">';
        admin_m_left_border_title01(e($label), $id);
        echo '</div>';
        echo '<div class="area is-field">';
        echo '<p class="text is-value" id="' . e($id) . '">' . e($value) . '</p>';
        if ($helpHtml !== '') {
            echo '<div class="area is-help">' . $helpHtml . '</div>';
        }
        if ($actionHtml !== '') {
            echo '<div class="area is-actions">' . $actionHtml . '</div>';
        }
        echo '</div></div>';
    }
}

if (!function_exists('admin_settings_button_html01')) {
    /**
     * admin_settings_value_text01() の actionHtml に渡す m-btn01 ボタンを組み立てる。
     *
     * @param array<string, string|int|float|bool|null> $attrs
     */
    function admin_settings_button_html01(string $label, array $attrs): string
    {
        ob_start();
        admin_m_btn01_button_wrap($label, $attrs);
        return (string) ob_get_clean();
    }
}
?>
<div data-module="m-toolbar01">
    <h1 class="title" style="margin:0;">設定</h1>
    <div class="spacer"></div>
    <?php if (!empty($storage_resource) && is_array($storage_resource)): ?>
        <?php admin_c_progress01_resource_summary($storage_resource); ?>
    <?php endif; ?>
</div>

<div data-module="c-formEditTabs01" class="is-nested" data-tab-scope="settings">
    <div class="wrapper">
        <div class="block is-tabs" role="tablist" aria-orientation="vertical" aria-label="設定メニュー">
            <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                data-tab-panel="settings-basic" role="tab" aria-selected="true" tabindex="0">基本情報</div>
            <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                data-tab-panel="settings-config" role="tab" aria-selected="false" tabindex="-1">詳細情報</div>
            <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                data-tab-panel="settings-templates" role="tab" aria-selected="false" tabindex="-1">テンプレート</div>
            <?php if (\Core\Auth::role() === 'admin'): ?>
                <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                    data-tab-panel="settings-line" role="tab" aria-selected="false" tabindex="-1">LINE 連携</div>
                <div data-module="m-formEditTab01" data-target="c-formEditTabs01__tab"
                    data-tab-panel="settings-backup" role="tab" aria-selected="false" tabindex="-1">バックアップ</div>
            <?php endif; ?>
        </div>
        <div class="block is-contents">
            <div data-target="c-formEditTabs01__contents" data-tab-panel="settings-basic" class="area is-contents" role="tabpanel"
                aria-label="基本情報">
<?php admin_c_form_block01_open(); ?>
            <div class="block is-title">
                                <?php admin_m_large_title01('基本情報'); ?>
            </div>
            <div class="block is-settingsBasic">
            <?php
            $baseUrl = (string) config('site.base_url', '');
            $adminNameAction = \Core\Auth::role() === 'admin'
                ? admin_settings_button_html01('編集', [
                    'type' => 'button',
                    'class' => 'is-primary',
                    'data-target' => 'settings-admin-name-open',
                ])
                : '';
            admin_settings_left_border_value01('管理画面の表示名', 'settings_site_admin_name', effective_site_admin_name(), '', $adminNameAction);
            $logoAction = \Core\Auth::role() === 'admin'
                ? admin_settings_button_html01('編集', [
                    'type' => 'button',
                    'class' => 'is-primary',
                    'data-target' => 'settings-logo-open',
                ])
                : '';
            echo '<div class="block">';
            echo '<div class="area is-title">';
            admin_m_left_border_title01(e('ロゴマーク'), 'settings_site_logo');
            echo '</div>';
            echo '<div class="area is-field">';
            echo '<img src="' . e(effective_site_logo_src()) . '" alt="" style="max-width:160px;height:auto;display:block;">';
            if ($logoAction !== '') {
                echo '<div class="area is-actions">' . $logoAction . '</div>';
            }
            echo '</div></div>';
            admin_settings_left_border_value01(
                '公開サイトのベース URL',
                'settings_site_base_url',
                $baseUrl !== '' ? $baseUrl : '未設定（相対パスのみ）'
            );
            admin_settings_left_border_value01(
                'サブディレクトリ（base_path）',
                'settings_site_base_path',
                (string) config('site.base_path', ''),
                '<p class="text is-help">空ならドキュメントルート直下です。</p>'
            );
            $tzChoices = site_timezone_choices();
            $tzValue = $tzChoices[effective_site_timezone()] ?? effective_site_timezone();
            $tzAction = \Core\Auth::role() === 'admin'
                ? admin_settings_button_html01('編集', [
                    'type' => 'button',
                    'class' => 'is-primary',
                    'data-target' => 'settings-timezone-open',
                ])
                : '';
            admin_settings_left_border_value01('タイムゾーン', 'settings_site_timezone', $tzValue, '', $tzAction);
            $storageHelp = '';
            if (!empty($storage_exceeded)) {
                $storageHelp .= '<p data-module="m-text01" data-type="danger">上限に達しています。公開フォームは利用できません。</p>';
            } elseif (!empty($storage_warning)) {
                $storageHelp .= '<p data-module="m-text01" data-type="warning">上限に近づいています。</p>';
            }
            if (\Core\Auth::role() !== 'admin') {
                $storageHelp .= '<p data-module="m-text01" data-type="muted">上限の変更は管理者のみ行えます。</p>';
            }
            $storageAction = \Core\Auth::role() === 'admin'
                ? admin_settings_button_html01('編集', [
                    'type' => 'button',
                    'class' => 'is-primary',
                    'data-target' => 'settings-max-storage-open',
                ])
                : '';
            echo '<div class="block">';
            echo '<div class="area is-title">';
            admin_m_left_border_title01(e('使用リソース'), 'settings_storage_total');
            echo '</div>';
            echo '<div class="area is-field">';
            echo '<p class="text is-value" id="settings_storage_uploads">添付ファイル: ' . e(\Core\Validator::formatBytes((int) $storage_used_uploads)) . '</p>';
            echo '<p class="text is-value" id="settings_storage_db">データベース: ' . e(\Core\Validator::formatBytes((int) $storage_used_db)) . '</p>';
            echo '<p class="text is-value" id="settings_storage_total">合計: ' . e(\Core\Validator::formatBytes((int) $storage_used_total)) . '</p>';
            if ($storageHelp !== '') {
                echo '<div class="area is-help">' . $storageHelp . '</div>';
            }
            if ($storageAction !== '') {
                echo '<div class="area is-actions">' . $storageAction . '</div>';
            }
            echo '</div></div>';
            $formLimitHelp = \Core\Auth::role() !== 'admin'
                ? '<p data-module="m-text01" data-type="muted">作成上限の変更は管理者のみ行えます。</p>'
                : '';
            $formLimitAction = \Core\Auth::role() === 'admin'
                ? admin_settings_button_html01('編集', [
                    'type' => 'button',
                    'class' => 'is-primary',
                    'data-target' => 'settings-max-forms-open',
                ])
                : '';
            admin_settings_left_border_value01(
                '現在のフォーム数',
                'settings_form_count',
                (int) $form_count . ' 件 / 上限 ' . (int) $max_forms . ' 件',
                $formLimitHelp,
                $formLimitAction
            );
            ?>
            <?php if (\Core\Auth::role() === 'admin'): ?>
            <div class="block" id="app-update">
                <div class="area is-title">
                    <?php admin_m_left_border_title01(e('バージョン'), 'settings_update_current_version'); ?>
                </div>
                <div class="area is-field">
                    <?php require __DIR__ . '/_content_app_version_basic.php'; ?>
                </div>
            </div>
            <?php endif; ?>
            </div>
<?php admin_c_form_block01_close(); ?>
            </div>

            <div data-target="c-formEditTabs01__contents" data-tab-panel="settings-config" class="area is-contents" role="tabpanel"
                aria-label="詳細情報" hidden>
                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('詳細情報'); ?>
                            </div>
                            <div class="block is-settingsBasic">
                                <div class="block">
                                    <div class="area is-title">
                                        <?php admin_m_left_border_title01(e('公開サイト')); ?>
                                    </div>
                                    <div class="area is-field">
                                    <?php
                                    $publicSiteUrl = settings_public_site_url();
                                    $publicSiteUrlDisplay = $publicSiteUrl !== '' ? $publicSiteUrl : '未設定';
                                    $publicSiteAction = \Core\Auth::role() === 'admin'
                                        ? admin_settings_button_html01('編集', [
                                            'type' => 'button',
                                            'class' => 'is-primary',
                                            'data-target' => 'settings-public-site-open',
                                        ])
                                        : '';
                                    admin_settings_value_text01(
                                        '公開サイトURL',
                                        'settings_public_site_url',
                                        $publicSiteUrlDisplay,
                                        '',
                                        $publicSiteAction
                                    );
                                    ?>
                                    </div>
                                </div>

                                <div class="block">
                                    <div class="area is-title">
                                        <?php admin_m_left_border_title01(e('祝日情報')); ?>
                                    </div>
                                    <?php
                                    $holidaysStatus = (string) ($holidays_status ?? 'missing');
                                    $holidaysStatusMessage = trim((string) ($holidays_status_message ?? ''));
                                    if ($holidaysStatusMessage !== ''): ?>
                                    <div class="area is-field">
                                        <?php
                                        $holidaysAlertType = $holidaysStatus === 'error' ? 'danger' : 'warning';
                                        admin_m_alert01($holidaysStatusMessage, $holidaysAlertType);
                                        ?>
                                    </div>
                                    <?php endif; ?>
                                    <div class="area is-field">
                                    <?php
                                    $holidaysFetchedAt = trim((string) ($holidays_fetched_at ?? ''));
                                    admin_settings_value_text01(
                                        '最終取得日時',
                                        'settings_holidays_fetched_at',
                                        $holidaysFetchedAt !== '' ? $holidaysFetchedAt : '未取得'
                                    );
                                    admin_settings_value_text01(
                                        '登録件数',
                                        'settings_holidays_count',
                                        (int) ($holidays_count ?? 0) . ' 件'
                                    );
                                    $holidaysIntervalDays = (int) ($holidays_fetch_interval_days ?? 365);
                                    $holidaysActions = '';
                                    if (\Core\Auth::role() === 'admin') {
                                        $holidaysActions = admin_settings_button_html01('編集', [
                                            'type' => 'button',
                                            'class' => 'is-primary',
                                            'data-target' => 'settings-holidays-open',
                                        ]);
                                        ob_start();
                                        ?>
                                        <form method="post" action="<?= e(base_path('/admin/settings/holidays/fetch')) ?>" style="display:inline">
                                            <?= \Core\Csrf::field() ?>
                                            <?php admin_m_btn01_button_wrap('祝日情報を取得', ['type' => 'submit']); ?>
                                        </form>
                                        <?php
                                        $holidaysActions .= (string) ob_get_clean();
                                    }
                                    admin_settings_value_text01(
                                        '自動取得間隔',
                                        'settings_holidays_interval',
                                        $holidaysIntervalDays . ' 日',
                                        '',
                                        $holidaysActions
                                    );
                                    ?>
                                    </div>
                                </div>

                                <?php if (\Core\Auth::role() === 'admin'): ?>
                                <?php
                                $purgeScheduleEnabled = !empty($submission_purge_schedule_enabled);
                                $purgeScheduleMode = (string) ($submission_purge_schedule_mode ?? \Core\SubmissionPurgeSchedule::MODE_DAILY);
                                $purgeScheduleDaily = (int) ($submission_purge_schedule_daily_hour ?? \Core\SubmissionPurgeSchedule::DEFAULT_DAILY_HOUR);
                                $purgeScheduleInterval = (int) ($submission_purge_schedule_interval_hours ?? \Core\SubmissionPurgeSchedule::DEFAULT_INTERVAL_HOURS);
                                $purgeScheduleLastRun = trim((string) ($submission_purge_schedule_last_run_at ?? ''));
                                ?>
                                <div class="block">
                                    <div class="area is-title">
                                        <?php admin_m_left_border_title01(e('受信履歴の定期削除')); ?>
                                    </div>
                                    <div class="area is-field">
                                        <?php
                                        $purgeEditAction = admin_settings_button_html01('編集', [
                                            'type' => 'button',
                                            'class' => 'is-primary',
                                            'data-target' => 'settings-purge-schedule-open',
                                        ]);
                                        admin_settings_value_text01(
                                            '定期削除',
                                            'settings_submission_purge_enabled',
                                            $purgeScheduleEnabled ? '有効' : '無効'
                                        );
                                        if ($purgeScheduleEnabled) {
                                            admin_settings_value_text01(
                                                '最終実行日時',
                                                'settings_submission_purge_last_run_at',
                                                $purgeScheduleLastRun !== '' ? $purgeScheduleLastRun : '未実行'
                                            );
                                            $purgeModeLabel = $purgeScheduleMode === \Core\SubmissionPurgeSchedule::MODE_INTERVAL
                                                ? '一定時間ごと'
                                                : '毎日';
                                            admin_settings_value_text01(
                                                '実行間隔',
                                                'settings_submission_purge_mode',
                                                $purgeModeLabel
                                            );
                                            if ($purgeScheduleMode === \Core\SubmissionPurgeSchedule::MODE_INTERVAL) {
                                                admin_settings_value_text01(
                                                    '実行間隔（時間）',
                                                    'settings_submission_purge_interval_hours',
                                                    $purgeScheduleInterval . ' 時間'
                                                );
                                            } else {
                                                admin_settings_value_text01(
                                                    '実行時刻',
                                                    'settings_submission_purge_daily_hour',
                                                    $purgeScheduleDaily . ' 時'
                                                );
                                            }
                                        }
                                        ?>
                                        <div class="block is-actions">
                                            <?= $purgeEditAction ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <div class="block">
                                    <div class="area is-title">
                                        <?php admin_m_left_border_title01(e('バージョン管理')); ?>
                                    </div>
                                    <div class="area is-field">
                                        <?php
                                        $versionPeriodicEnabled = !empty($form_version_periodic_save_enabled);
                                        $versionIntervalMinutes = (int) ($form_version_interval_minutes ?? \Models\FormVersion::DEFAULT_INTERVAL_MINUTES);
                                        $versionTimingOnOff = static fn (bool $enabled): string => $enabled ? 'on' : 'off';
                                        admin_settings_value_text01(
                                            '定期保存',
                                            'settings_form_version_periodic',
                                            $versionPeriodicEnabled ? '有効' : '無効'
                                        );
                                        if ($versionPeriodicEnabled) {
                                            admin_settings_value_text01(
                                                '保存間隔',
                                                'settings_form_version_interval',
                                                $versionIntervalMinutes . ' 分'
                                            );
                                        }
                                        ?>
                                        <?php admin_m_input_set01_open(); ?>
                                            <div class="area is-title">
                                                <?php admin_m_bold_title01('保存タイミング', 'settings_form_version_timing'); ?>
                                            </div>
                                            <div class="area is-field is-settingsTimingValues">
                                                <p class="text is-value" id="settings_form_version_save_on_save">保存時：<?= e($versionTimingOnOff(!empty($form_version_save_on_save))) ?></p>
                                                <p class="text is-value" id="settings_form_version_save_on_login">ログイン時：<?= e($versionTimingOnOff(!empty($form_version_save_on_login))) ?></p>
                                                <p class="text is-value" id="settings_form_version_save_on_logout">ログアウト時：<?= e($versionTimingOnOff(!empty($form_version_save_on_logout))) ?></p>
                                            </div>
                                        <?php admin_m_input_set01_close(); ?>
                                        <?php
                                        admin_settings_value_text01(
                                            '保存回数',
                                            'settings_form_version_retention_limit',
                                            (int) ($form_version_retention_limit ?? \Models\FormVersion::DEFAULT_RETENTION_LIMIT) . ' 回'
                                        );
                                        if (\Core\Auth::role() === 'admin') {
                                            $versionEditAction = admin_settings_button_html01('編集', [
                                                'type' => 'button',
                                                'class' => 'is-primary',
                                                'data-target' => 'settings-versioning-open',
                                            ]);
                                            ?>
                                            <div class="block is-actions">
                                                <?= $versionEditAction ?>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                <?php admin_c_form_block01_close(); ?>
            </div>

            <div id="line-settings" data-target="c-formEditTabs01__contents" data-tab-panel="settings-line" class="area is-contents" role="tabpanel"
                aria-label="LINE 連携" hidden>
                <?php require __DIR__ . '/_content_line.php'; ?>
            </div>

            <div id="settings-templates" data-target="c-formEditTabs01__contents" data-tab-panel="settings-templates" class="area is-contents" role="tabpanel"
                aria-label="テンプレート" hidden>
                <?php admin_c_form_block01_open(); ?>
                            <div class="block is-title">
                                <?php admin_m_large_title01('テンプレート'); ?>
                            </div>
                            <div class="block is-field">
                                <?php admin_c_field_template_list01_open(); ?>
                                    <?php if (!empty($field_templates)): ?>
                                        <?php foreach ($field_templates as $tpl): ?>
                                            <?php
                                            $isBuiltinTemplate = !empty($tpl['is_builtin']);
                                            $templateId = (string) ($tpl['id'] ?? '');
                                            $templateDbId = (int) $templateId;
                                            $templateTitle = trim((string) ($tpl['title'] ?? '')) !== '' ? (string) $tpl['title'] : '無題のテンプレート';
                                            ?>
                                            <details class="c-fieldTemplateList01__item">
                                                <summary class="summary">
                                                    <span class="title"><?= e($templateTitle) ?></span>
                                                    <?php if ($isBuiltinTemplate): ?>
                                                        <span class="text">標準テンプレート</span>
                                                    <?php else: ?>
                                                        <details class="menu">
                                                            <summary aria-label="テンプレート操作">…</summary>
                                                            <div class="menuBody">
                                                                <form method="post" action="<?= e(base_path('/admin/settings/templates/' . $templateDbId . '/delete')) ?>" onsubmit="return confirm('このテンプレートを削除しますか？');">
                                                                    <?= \Core\Csrf::field() ?>
                                                                    <button type="submit">削除</button>
                                                                </form>
                                                            </div>
                                                        </details>
                                                    <?php endif; ?>
                                                </summary>
                                                <div class="body">
                                                    <?php if ($isBuiltinTemplate): ?>
                                                        <?php $renderBuiltinTemplatePreview($tpl); ?>
                                                    <?php else: ?>
                                                        <?php $renderTemplateEditor($tpl, base_path('/admin/settings/templates/' . $templateDbId), 'field_template_title_' . $templateDbId); ?>
                                                    <?php endif; ?>
                                                </div>
                                            </details>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                    <div class="c-fieldTemplateList01__add" data-target="fieldTemplateCreateActions">
                                        <?php admin_m_btn01_open(); ?>
                                            <?php admin_m_btn01_button('＋ テンプレートを追加', [
                                                'type' => 'button',
                                                'class' => 'fb-description-add',
                                                'data-target' => 'fieldTemplateCreateOpen',
                                            ]); ?>
                                        <?php admin_m_btn01_close(); ?>
                                    </div>
                                    <template data-target="fieldTemplateCreateTemplate">
                                        <details class="c-fieldTemplateList01__item is-new">
                                            <summary class="summary">
                                                <span class="title">新規テンプレート</span>
                                            </summary>
                                            <div class="body">
                                                <?php $renderTemplateEditor(null, base_path('/admin/settings/templates'), 'field_template_title___templateKey__'); ?>
                                            </div>
                                        </details>
                                    </template>
                                <?php admin_c_field_template_list01_close(); ?>
                            </div>
                <?php admin_c_form_block01_close(); ?>
            </div>

            <?php if (\Core\Auth::role() === 'admin'): ?>
                <div id="settings-backup" data-target="c-formEditTabs01__contents" data-tab-panel="settings-backup" class="area is-contents" role="tabpanel"
                    aria-label="バックアップ" hidden>
                    <?php require __DIR__ . '/_content_backup.php'; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php admin_c_field_type_modal01(); ?>
<?php admin_m_form_builder01_field_template(); ?>
<?php admin_m_form_builder01_group_template(); ?>

<?php if (\Core\Auth::role() === 'admin'): ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-max-forms-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-max-forms-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('フォームの作成上限', 'h2', 'settings-max-forms-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('フォームの作成上限'), 'max_forms_modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('max_forms_modal', [
                            'type' => 'number',
                            'name' => 'max_forms',
                            'id' => 'max_forms_modal',
                            'min' => 1,
                            'max' => 999999,
                            'step' => 1,
                            'value' => (string) (int) $max_forms,
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">1 以上の整数を指定してください。保存後、一覧の新規作成やこの上限を超える作成はできません。</p>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-max-forms-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-max-storage-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-max-storage-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('使用リソースの上限', 'h2', 'settings-max-storage-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/site-resource')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('使用リソースの上限（MB）'), 'max_site_resource_mb_modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('max_site_resource_mb_modal', [
                            'type' => 'number',
                            'name' => 'max_site_resource_mb',
                            'id' => 'max_site_resource_mb_modal',
                            'min' => 1,
                            'max' => 1048576,
                            'step' => 1,
                            'value' => (string) (int) $storage_max_mb,
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <p class="text is-help">添付ファイルとデータベースの合計使用量の上限です。1 以上の整数（MB）を指定してください。</p>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('保存', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-max-storage-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php
$manualUploadMaxBytesModal = (int) ($manual_upload_max_bytes ?? \Core\AppUpdater::manualUploadMaxBytes());
?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-manual-update-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-manual-update-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('手動で更新', 'h2', 'settings-manual-update-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/update-upload')) ?>" enctype="multipart/form-data" data-module="c-updateUpload01" data-max-bytes="<?= $manualUploadMaxBytesModal ?>">
                <?= \Core\Csrf::field() ?>
                <?php admin_c_update_upload01_zone(); ?>
                <?php
                $releasesPageUrlModal = trim((string) ($releases_page_url ?? update_releases_page_url()));
                if ($releasesPageUrlModal !== ''): ?>
                    <p class="text is-help"><a href="<?= e($releasesPageUrlModal) ?>" target="_blank" rel="noopener noreferrer">バージョン一覧ページを開く</a></p>
                <?php endif; ?>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('更新', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-manual-update-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-public-site-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-public-site-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('公開サイト', 'h2', 'settings-public-site-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/display')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('公開サイトURL'), 'public_site_url_modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('public_site_url_modal', [
                            'type' => 'text',
                            'name' => 'public_site_url',
                            'id' => 'public_site_url_modal',
                            'value' => settings_public_site_url(),
                            'placeholder' => '/ または https://example.com/',
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('更新', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-public-site-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-admin-name-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-admin-name-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('管理画面の表示名', 'h2', 'settings-admin-name-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/admin-name')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('名前'), 'site_admin_name_modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('site_admin_name_modal', [
                            'type' => 'text',
                            'name' => 'site_admin_name',
                            'id' => 'site_admin_name_modal',
                            'value' => effective_site_admin_name(),
                            'maxlength' => 100,
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('更新', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-admin-name-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-timezone-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-timezone-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('タイムゾーン', 'h2', 'settings-timezone-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/timezone')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('タイムゾーン'), 'site_timezone_modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <select id="site_timezone_modal" name="site_timezone"<?= admin_m_bold_title01_aria_labelledby_attr('site_timezone_modal') ?>>
                            <?php foreach (site_timezone_choices() as $tzValue => $tzLabel): ?>
                                <option value="<?= e($tzValue) ?>"<?= effective_site_timezone() === $tzValue ? ' selected' : '' ?>><?= e($tzLabel) ?></option>
                            <?php endforeach; ?>
                        </select>
                    <?php admin_m_input01_close(); ?>
                </div>
                <p class="text is-help">変更前に記録された日時は変換されません。</p>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('更新', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-timezone-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-logo-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-logo-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('ロゴマーク', 'h2', 'settings-logo-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/logo')) ?>" enctype="multipart/form-data" data-module="c-updateUpload01" data-max-bytes="2097152" data-confirm-message="ロゴマークを更新します。よろしいですか？">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <img id="settings-logo-preview" src="<?= e(effective_site_logo_src()) ?>" alt="" style="max-width:200px;height:auto;display:block;margin:0 auto 12px;">
                    <?php admin_c_update_upload01_zone('site_logo', 'image/jpeg,image/png,image/webp,image/gif,.jpg,.jpeg,.png,.webp,.gif', '画像をドラッグ＆ドロップ、またはクリックして選択'); ?>
                </div>
                <p class="text is-help">2MB、500px x 500px 以下の画像までアップロードできます。</p>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('更新', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-logo-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
            <?php if (site_logo_is_custom()): ?>
            <form method="post" action="<?= e(base_path('/admin/settings/logo/reset')) ?>" onsubmit="return confirm('初期画像に戻します。よろしいですか？');">
                <?= \Core\Csrf::field() ?>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <button type="submit" class="c-modal01__cancelLink">初期画像に戻す</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
            <?php endif; ?>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<script>
(function () {
    var input = document.querySelector('input[name="site_logo"]');
    var preview = document.getElementById('settings-logo-preview');
    if (!input || !preview) return;
    input.addEventListener('change', function () {
        var file = input.files && input.files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function (e) { preview.src = e.target.result; };
        reader.readAsDataURL(file);
    });
})();
</script>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-holidays-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-holidays-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('祝日情報', 'h2', 'settings-holidays-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/holidays')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <?php admin_m_bold_title01(e('自動取得間隔'), 'holidays_jp_fetch_interval_days_modal'); ?>
                    <?php admin_m_input01_open(); ?>
                        <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('holidays_jp_fetch_interval_days_modal', [
                            'type' => 'number',
                            'name' => 'holidays_jp_fetch_interval_days',
                            'id' => 'holidays_jp_fetch_interval_days_modal',
                            'min' => 1,
                            'max' => 3650,
                            'step' => 1,
                            'value' => (string) (int) ($holidays_fetch_interval_days ?? 365),
                            'required' => true,
                        ])); ?>
                    <?php admin_m_input01_close(); ?>
                    <span class="text is-help">日</span>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('更新', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-holidays-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php
$purgeScheduleEnabledModal = !empty($submission_purge_schedule_enabled);
$purgeScheduleModeModal = (string) ($submission_purge_schedule_mode ?? \Core\SubmissionPurgeSchedule::MODE_DAILY);
$purgeScheduleDailyModal = (int) ($submission_purge_schedule_daily_hour ?? \Core\SubmissionPurgeSchedule::DEFAULT_DAILY_HOUR);
$purgeScheduleIntervalModal = (int) ($submission_purge_schedule_interval_hours ?? \Core\SubmissionPurgeSchedule::DEFAULT_INTERVAL_HOURS);
?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-purge-schedule-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-purge-schedule-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('受信履歴の定期削除', 'h2', 'settings-purge-schedule-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/submission-purge-schedule')) ?>" data-purge-schedule-form="1">
                <?= \Core\Csrf::field() ?>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title">
                        <?php admin_m_bold_title01('定期削除', 'submission_purge_schedule_enabled'); ?>
                    </div>
                    <div class="area is-field">
                        <?php admin_m_checkbox01('定期削除を有効にする', admin_m_input01_attrs_with_bound_label('submission_purge_schedule_enabled', [
                            'name' => 'submission_purge_schedule_enabled',
                            'id' => 'submission_purge_schedule_enabled',
                            'value' => '1',
                            'checked' => $purgeScheduleEnabledModal,
                        ])); ?>
                        <p class="text is-help">定期削除を有効にするにはサーバーにcronの設定が必要になります。</p>
                    </div>
                <?php admin_m_input_set01_close(); ?>
                <div data-purge-schedule-detail<?= $purgeScheduleEnabledModal ? '' : ' hidden' ?>>
                    <?php admin_m_input_set01_open(); ?>
                        <div class="area is-title">
                            <?php admin_m_bold_title01('実行間隔', 'submission_purge_schedule_mode'); ?>
                        </div>
                        <div class="area is-field">
                            <?php admin_m_radiobtn01('毎日', [
                                'name' => 'submission_purge_schedule_mode',
                                'value' => \Core\SubmissionPurgeSchedule::MODE_DAILY,
                                'checked' => $purgeScheduleModeModal !== \Core\SubmissionPurgeSchedule::MODE_INTERVAL,
                            ]); ?>
                            <?php admin_m_radiobtn01('一定時間ごと', [
                                'name' => 'submission_purge_schedule_mode',
                                'value' => \Core\SubmissionPurgeSchedule::MODE_INTERVAL,
                                'checked' => $purgeScheduleModeModal === \Core\SubmissionPurgeSchedule::MODE_INTERVAL,
                            ]); ?>
                        </div>
                    <?php admin_m_input_set01_close(); ?>
                    <div data-purge-schedule-daily<?= $purgeScheduleModeModal === \Core\SubmissionPurgeSchedule::MODE_INTERVAL ? ' hidden' : '' ?>>
                        <?php admin_m_input_set01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_bold_title01('実行時刻', 'submission_purge_schedule_daily_hour'); ?>
                            </div>
                            <div class="area is-field">
                                <?php admin_m_input01_open('is-inline'); ?>
                                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submission_purge_schedule_daily_hour', [
                                        'type' => 'number',
                                        'name' => 'submission_purge_schedule_daily_hour',
                                        'id' => 'submission_purge_schedule_daily_hour',
                                        'min' => \Core\SubmissionPurgeSchedule::MIN_DAILY_HOUR,
                                        'max' => \Core\SubmissionPurgeSchedule::MAX_DAILY_HOUR,
                                        'step' => 1,
                                        'value' => (string) $purgeScheduleDailyModal,
                                        'required' => true,
                                    ])); ?>
                                <?php admin_m_input01_close(); ?>
                                <span class="text is-help">時（0〜23、サーバーのタイムゾーン）</span>
                            </div>
                        <?php admin_m_input_set01_close(); ?>
                    </div>
                    <div data-purge-schedule-interval<?= $purgeScheduleModeModal === \Core\SubmissionPurgeSchedule::MODE_INTERVAL ? '' : ' hidden' ?>>
                        <?php admin_m_input_set01_open(); ?>
                            <div class="area is-title">
                                <?php admin_m_bold_title01('実行間隔', 'submission_purge_schedule_interval_hours'); ?>
                            </div>
                            <div class="area is-field">
                                <?php admin_m_input01_open('is-inline'); ?>
                                    <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('submission_purge_schedule_interval_hours', [
                                        'type' => 'number',
                                        'name' => 'submission_purge_schedule_interval_hours',
                                        'id' => 'submission_purge_schedule_interval_hours',
                                        'min' => \Core\SubmissionPurgeSchedule::MIN_INTERVAL_HOURS,
                                        'max' => \Core\SubmissionPurgeSchedule::MAX_INTERVAL_HOURS,
                                        'step' => 1,
                                        'value' => (string) $purgeScheduleIntervalModal,
                                        'required' => true,
                                    ])); ?>
                                <?php admin_m_input01_close(); ?>
                                <span class="text is-help">時間（1〜168）</span>
                            </div>
                        <?php admin_m_input_set01_close(); ?>
                    </div>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('更新', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-purge-schedule-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php
$versionPeriodicEnabledModal = !empty($form_version_periodic_save_enabled);
$versionIntervalMinutesModal = (int) ($form_version_interval_minutes ?? \Models\FormVersion::DEFAULT_INTERVAL_MINUTES);
$versionRetentionModal = (int) ($form_version_retention_limit ?? \Models\FormVersion::DEFAULT_RETENTION_LIMIT);
?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-versioning-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-versioning-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('バージョン管理', 'h2', 'settings-versioning-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/versioning')) ?>" data-version-periodic-form="1">
                <?= \Core\Csrf::field() ?>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title">
                        <?php admin_m_bold_title01('定期保存', 'form_version_periodic_save_enabled'); ?>
                    </div>
                    <div class="area is-field">
                        <?php admin_m_checkbox01('定期保存する', admin_m_input01_attrs_with_bound_label('form_version_periodic_save_enabled', [
                            'name' => 'form_version_periodic_save_enabled',
                            'id' => 'form_version_periodic_save_enabled',
                            'value' => '1',
                            'checked' => $versionPeriodicEnabledModal,
                        ])); ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
                <div data-version-periodic-detail<?= $versionPeriodicEnabledModal ? '' : ' hidden' ?>>
                    <?php admin_m_input_set01_open(); ?>
                        <div class="area is-title">
                            <?php admin_m_bold_title01('保存間隔', 'form_version_interval_minutes_modal'); ?>
                        </div>
                        <div class="area is-field">
                            <?php admin_m_input01_open(); ?>
                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('form_version_interval_minutes_modal', [
                                    'type' => 'number',
                                    'name' => 'form_version_interval_minutes',
                                    'id' => 'form_version_interval_minutes_modal',
                                    'min' => 1,
                                    'max' => 10080,
                                    'step' => 1,
                                    'value' => (string) $versionIntervalMinutesModal,
                                    'required' => true,
                                ])); ?>
                            <?php admin_m_input01_close(); ?>
                            <span class="text is-help">分</span>
                        </div>
                    <?php admin_m_input_set01_close(); ?>
                </div>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title">
                        <?php admin_m_bold_title01('保存タイミング', 'settings_form_version_timing_modal'); ?>
                    </div>
                    <div class="area is-field">
                        <?php admin_m_checkbox01('保存時', admin_m_input01_attrs_with_bound_label('form_version_save_on_save_modal', [
                            'name' => 'form_version_save_on_save',
                            'id' => 'form_version_save_on_save_modal',
                            'value' => '1',
                            'checked' => !empty($form_version_save_on_save),
                        ])); ?>
                        <?php admin_m_checkbox01('ログイン時', admin_m_input01_attrs_with_bound_label('form_version_save_on_login_modal', [
                            'name' => 'form_version_save_on_login',
                            'id' => 'form_version_save_on_login_modal',
                            'value' => '1',
                            'checked' => !empty($form_version_save_on_login),
                        ])); ?>
                        <?php admin_m_checkbox01('ログアウト時', admin_m_input01_attrs_with_bound_label('form_version_save_on_logout_modal', [
                            'name' => 'form_version_save_on_logout',
                            'id' => 'form_version_save_on_logout_modal',
                            'value' => '1',
                            'checked' => !empty($form_version_save_on_logout),
                        ])); ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
                <?php admin_m_input_set01_open(); ?>
                    <div class="area is-title">
                        <?php admin_m_bold_title01('保存回数', 'form_version_retention_limit_modal'); ?>
                    </div>
                    <div class="area is-field">
                        <?php admin_m_input01_open('is-inline'); ?>
                            <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('form_version_retention_limit_modal', [
                                'type' => 'number',
                                'name' => 'form_version_retention_limit',
                                'id' => 'form_version_retention_limit_modal',
                                'min' => 1,
                                'max' => 10000,
                                'step' => 1,
                                'value' => (string) $versionRetentionModal,
                                'required' => true,
                                'style' => 'width:120px',
                            ])); ?>
                            <span class="text is-unit">回</span>
                        <?php admin_m_input01_close(); ?>
                    </div>
                <?php admin_m_input_set01_close(); ?>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('更新', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-versioning-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-backup-export-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-backup-export-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('復元データの作成', 'h2', 'settings-backup-export-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/backup/export')) ?>">
                <?= \Core\Csrf::field() ?>
                <div class="area is-field">
                    <p class="text is-help">復元データの作成にはパスワードの設定が必要になります。</p>
                </div>
                <div class="area is-field">
                    <?php admin_m_input_set01_open(); ?>
                        <div class="area is-title">
                            <?php admin_m_bold_title01(e('パスワード') . ' <span data-module="m-required01" data-type="required">必須</span>', 'backup_password'); ?>
                        </div>
                        <div class="area is-field">
                            <?php admin_m_input01_open(); ?>
                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('backup_password', [
                                    'type' => 'password',
                                    'name' => 'backup_password',
                                    'id' => 'backup_password',
                                    'autocomplete' => 'new-password',
                                    'required' => true,
                                ])); ?>
                            <?php admin_m_input01_close(); ?>
                        </div>
                    <?php admin_m_input_set01_close(); ?>
                </div>
                <div class="area is-field">
                    <?php admin_m_input_set01_open(); ?>
                        <div class="area is-title">
                            <?php admin_m_bold_title01(e('確認') . ' <span data-module="m-required01" data-type="required">必須</span>', 'backup_password_confirm'); ?>
                        </div>
                        <div class="area is-field">
                            <?php admin_m_input01_open(); ?>
                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('backup_password_confirm', [
                                    'type' => 'password',
                                    'name' => 'backup_password_confirm',
                                    'id' => 'backup_password_confirm',
                                    'autocomplete' => 'new-password',
                                    'required' => true,
                                ])); ?>
                            <?php admin_m_input01_close(); ?>
                        </div>
                    <?php admin_m_input_set01_close(); ?>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('復元データの作成', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-backup-export-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php
$backupRestoreMaxBytes = (int) max(1, (int) config('submissions.import_max_bytes', 500 * 1024 * 1024));
?>
<?php admin_c_modal01_open(['hidden' => true]); ?>
    <?php admin_c_modal01_backdrop('settings-backup-restore-close'); ?>
    <?php admin_c_modal01_dialog_open('settings-backup-restore-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('サイトの復元', 'h2', 'settings-backup-restore-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <form method="post" action="<?= e(base_path('/admin/settings/backup/import')) ?>" enctype="multipart/form-data" data-module="c-updateUpload01" data-max-bytes="<?= $backupRestoreMaxBytes ?>" data-confirm-message="現在のデータはすべて削除され、バックアップの内容に置き換わります。元に戻せません。復元後はログアウトします。よろしいですか？">
                <?= \Core\Csrf::field() ?>
                <?php admin_c_update_upload01_zone('backup_file'); ?>
                <p class="text is-help">上限 <?= number_format((int) floor($backupRestoreMaxBytes / 1048576)) ?>MB。</p>
                <div class="area is-field">
                    <?php admin_m_input_set01_open(); ?>
                        <div class="area is-title">
                            <?php admin_m_bold_title01(e('パスワード') . ' <span data-module="m-required01" data-type="required">必須</span>', 'restore_password'); ?>
                        </div>
                        <div class="area is-field">
                            <?php admin_m_input01_open(); ?>
                                <?php admin_m_input01_input(admin_m_input01_attrs_with_bound_label('restore_password', [
                                    'type' => 'password',
                                    'name' => 'restore_password',
                                    'id' => 'restore_password',
                                    'autocomplete' => 'off',
                                    'required' => true,
                                ])); ?>
                            <?php admin_m_input01_close(); ?>
                        </div>
                    <?php admin_m_input_set01_close(); ?>
                </div>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('サイトを復元する', ['type' => 'submit', 'class' => 'is-primary']); ?>
                    <button type="button" class="c-modal01__cancelLink" data-target="settings-backup-restore-close">キャンセル</button>
                <?php admin_c_modal01_actions_close(); ?>
            </form>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php if (!empty($showApplyButton ?? false)): ?>
<?php admin_c_modal01_open(['hidden' => true, 'data-settings-app-update-modal' => true]); ?>
    <div class="c-modal01__backdrop"></div>
    <?php admin_c_modal01_dialog_open('settings-app-update-modal-title'); ?>
        <?php admin_c_modal01_header_open('is-title-center'); ?>
            <?php admin_m_large_title01('アップデート', 'h2', 'settings-app-update-modal-title'); ?>
        <?php admin_c_modal01_header_close(); ?>
        <?php admin_c_modal01_body_open(); ?>
            <div data-settings-app-update-state="running">
                <p class="text is-help" style="text-align:center;">アップデート中</p>
                <div data-module="c-progress01" data-target="settings-app-update-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                    <span class="bar"><span class="fill" style="width: 0%"></span></span>
                </div>
            </div>
            <div data-settings-app-update-state="done" hidden>
                <p class="text is-help" style="text-align:center;">アップデートが完了しました</p>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('ページを更新する', ['type' => 'button', 'class' => 'is-primary', 'data-target' => 'settings-app-update-reload']); ?>
                <?php admin_c_modal01_actions_close(); ?>
            </div>
            <div data-settings-app-update-state="error" hidden>
                <p class="text is-help" data-target="settings-app-update-error" style="text-align:center;"></p>
                <?php admin_c_modal01_actions_open('is-stack-center'); ?>
                    <?php admin_m_btn01_button_wrap('ページを更新する', ['type' => 'button', 'class' => 'is-primary', 'data-target' => 'settings-app-update-reload']); ?>
                <?php admin_c_modal01_actions_close(); ?>
            </div>
        <?php admin_c_modal01_body_close(); ?>
    <?php admin_c_modal01_dialog_close(); ?>
<?php admin_c_modal01_close(); ?>
<?php endif; ?>
<?php endif; ?>
