<?php $closedBlocks = decode_form_description_blocks($form['closed_message'] ?? '', true); ?>
<?php $hasClosedContent = false; ?>
<?php foreach ($closedBlocks as $closedBlock): ?>
    <?php if (!empty($closedBlock['visible']) && !empty($closedBlock['html']) && ($closedBlock['content_type'] ?? '') !== 'title'): ?>
        <?php $hasClosedContent = true; ?>
        <?php break; ?>
    <?php endif; ?>
<?php endforeach; ?>
<?php $closedButtonText = trim((string) ($form['closed_button_text'] ?? '')) !== '' ? (string) $form['closed_button_text'] : 'トップへ戻る'; ?>
<?php $closedButtonUrl = trim((string) ($form['closed_button_url'] ?? '')) !== '' ? (string) $form['closed_button_url'] : '/'; ?>
<section class="l-formWrapper01" data-form-step="closed">
    <?= render_form_description_blocks_at($closedBlocks, 0, (int) ($form['id'] ?? 0)) ?>

<div data-module="c-formSet01">
    <div class="wrapper">
<?php if (!$hasClosedContent): ?>
        <p class="text">現在、フォームをご利用いただけません。<br>
        公開時間内に再度お試しください。</p>
<?php endif; ?>

        <div class="area is-actions is-centered">
            <a class="btn is-primary" href="<?= e(resolve_form_button_url($closedButtonUrl)) ?>"><?= e($closedButtonText) ?></a>
        </div>
    </div>
</div>
<?= render_form_description_blocks_at($closedBlocks, 1, (int) ($form['id'] ?? 0)) ?>
</section>
