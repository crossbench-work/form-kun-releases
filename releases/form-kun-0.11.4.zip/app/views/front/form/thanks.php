<?php $thanksBlocks = decode_form_description_blocks($form['thanks_message'] ?? '', true); ?>
<?php $storagePrefix = 'formkun-public:' . (string) ($form['slug'] ?? '') . ':'; ?>
<?php $hasThanksContent = false; ?>
<?php foreach ($thanksBlocks as $thanksBlock): ?>
    <?php if (!empty($thanksBlock['visible']) && !empty($thanksBlock['html']) && ($thanksBlock['content_type'] ?? '') !== 'title'): ?>
        <?php $hasThanksContent = true; ?>
        <?php break; ?>
    <?php endif; ?>
<?php endforeach; ?>
<?php $thanksButtonText = trim((string) ($form['thanks_button_text'] ?? '')) !== '' ? (string) $form['thanks_button_text'] : 'トップへ戻る'; ?>
<?php $thanksButtonUrl = trim((string) ($form['thanks_button_url'] ?? '')) !== '' ? (string) $form['thanks_button_url'] : '/'; ?>
<section class="l-formWrapper01" data-form-storage-clear-prefix="<?= e($storagePrefix) ?>" data-form-step="thanks">
    <?= render_form_description_blocks_at($thanksBlocks, 0, (int) ($form['id'] ?? 0)) ?>

<div data-module="c-formSet01">
    <div class="wrapper">
<?php if (!$hasThanksContent): ?>
        <p class="text">お問い合わせいただきありがとうございました。<br>
        内容を確認のうえ、追ってご連絡いたします。</p>
<?php endif; ?>

        <div class="area is-actions is-centered">
            <a class="btn is-primary" href="<?= e(resolve_form_button_url($thanksButtonUrl)) ?>"><?= e($thanksButtonText) ?></a>
        </div>
    </div>
</div>
<?= render_form_description_blocks_at($thanksBlocks, 1, (int) ($form['id'] ?? 0)) ?>
</section>
