<?php
namespace Core;

/**
 * 旧 DB（schema.sql 追加前に作成されたデータベース）向けの軽量マイグレーション。
 * 初回リクエスト時に不足列・不足テーブルを補います。
 */
class SchemaPatch
{
    private static bool $done = false;

    public static function ensureLatest(): void
    {
        if (self::$done) {
            return;
        }
        self::$done = true;

        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasEmail = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'users', 'email']
            );
            if ((int) ($hasEmail['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE users ADD COLUMN email VARCHAR(255) DEFAULT NULL AFTER display_name'
                );
            }

            self::tryAlterUniqueEmail();

            self::ensureFormFieldsRegexText();

            self::ensureFormFieldsTypeEnumAddress();

            self::ensureFormFieldsTypeEnumTextPair();

            self::ensureFormFieldsTypeEnumTextMulti();
            self::ensureFormFieldsTypeEnumMatrix();
            self::ensureFormFieldsTypeEnumPostalCode();
            self::ensureFormFieldsTypeEnumDisplayItems();
            self::ensureFormFieldsVisible();
            self::ensureFormFieldsMinLength();
            self::ensureFormFieldsExactLength();

            self::ensureFormsDisplayFlags();

            self::ensureFormsPageTitles();
            self::ensureFormInputPages();
            self::ensureFormFieldsInputPageKey();
            self::ensureFormFieldGroups();
            self::ensureFormFieldTemplates();
            self::ensureFormVersions();
            self::ensureFieldLabelDisplayFlags();
            self::ensureFormBranchRules();
            self::ensureFormBranchRuleTargetType();
            self::ensureFormsMetaSettings();
            self::ensureFormsMailSettings();
            self::ensureMailOnlySubmission();
            self::ensureLineMessagingNotification();
            self::ensureLineWebhookTargets();
            self::migrateLineSiteChannelAndWebhookTargets();
            self::ensureLineWebhookTargetsFormId();
            self::ensureFormsLineCustomEnabled();
            self::ensureLineNotifyIncludeImages();
            self::ensureLineSetupChecklist();
            self::ensureFormsReplyFieldKeyStorage();
            self::ensureFormsPublishSchedule();
            self::ensureFormsUnpublishRules();

            self::ensureAppSettingsTable();
            self::ensureAppSettingsCreatedAtColumn();

            self::ensureLoginAttemptsUsernameIndex();

            self::ensureFormsPublicUuid();
            self::ensureSubmissionFilesFileUuid();
            self::ensureSubmissionsWorkflowStatus();
            self::ensureMailOnlySubmissionMetadata();
            self::ensureFormEmbedApiTables();
            self::ensureFormsStatusHidden();
            self::ensureFormsSubmissionRetention();

            self::ensureUsersRoleViewer();
            self::ensureUserFormGrantsTable();
            self::ensureUserFormGrantsAccessLevel();
            self::ensureUserWebauthnCredentialsTable();
            self::repairImportedBinImageFiles();
            self::migrateScreenTitlesToBlocks();

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'password_reset_tokens']
            );
            if ((int) ($hasTbl['c'] ?? 0) === 0) {
                Database::execute(
                    'CREATE TABLE password_reset_tokens (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL,
                        token_hash CHAR(64) NOT NULL,
                        expires_at DATETIME NOT NULL,
                        created_at DATETIME NOT NULL,
                        UNIQUE KEY uk_token_hash (token_hash),
                        KEY idx_user_id (user_id),
                        CONSTRAINT fk_pwreset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch failed: ' . $e->getMessage());
        }
    }

    /**
     * ZIP インポートで .bin 保存になった画像添付を、実ファイルの MIME に合う拡張子へリネームする（1 回のみ）。
     */
    private static function repairImportedBinImageFiles(): void
    {
        $flagKey = 'repair_imported_bin_images_v1';
        try {
            if (\Models\AppSetting::get($flagKey) !== null) {
                return;
            }
            $rows = Database::fetchAll(
                "SELECT id, stored_path FROM submission_files WHERE stored_path LIKE '%.bin'"
            );
            foreach ($rows as $row) {
                $storedPath = (string) ($row['stored_path'] ?? '');
                $abs = FileStorage::absolutePath($storedPath);
                if (!is_file($abs)) {
                    continue;
                }
                $mime = FileTypePolicy::detectMime($abs);
                $ext = FileTypePolicy::extensionForMime($mime);
                if ($ext === null || !FileTypePolicy::isSafeInlineImage($ext, $mime)) {
                    continue;
                }
                $newStoredPath = substr($storedPath, 0, -strlen('.bin')) . '.' . $ext;
                $newAbs = FileStorage::absolutePath($newStoredPath);
                if (is_file($newAbs) || !@rename($abs, $newAbs)) {
                    continue;
                }
                Database::execute(
                    'UPDATE submission_files SET stored_path = ?, mime_type = ? WHERE id = ?',
                    [$newStoredPath, $mime, (int) $row['id']]
                );
            }
            \Models\AppSetting::set($flagKey, date('Y-m-d H:i:s'));
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch repairImportedBinImageFiles: ' . $e->getMessage());
        }
    }

    /**
     * 画面タイトル（*_page_title / form_input_pages.title）を説明文の「タイトル」ブロックへ移す（1 回のみ）。
     */
    private static function migrateScreenTitlesToBlocks(): void
    {
        $flagKey = 'migration_screen_title_blocks';
        try {
            if (\Models\AppSetting::get($flagKey) !== null) {
                return;
            }
            $withTitle = static function ($stored, string $title, $visible, string $id): ?string {
                $blocks = decode_form_description_blocks($stored, true);
                if (form_description_blocks_have_title($blocks)) {
                    return null;
                }
                return encode_form_description_blocks(
                    form_description_blocks_with_title($blocks, $title, !empty($visible), $id)
                );
            };
            $titleOr = static function ($value, string $fallback): string {
                $value = trim((string) $value);
                return $value !== '' ? $value : $fallback;
            };

            $forms = Database::fetchAll(
                'SELECT id, title, input_page_title, show_input_page_title, description,
                        confirm_page_title, show_confirm_page_title, confirm_message,
                        thanks_page_title, show_thanks_page_title, thanks_message,
                        closed_page_title, show_closed_page_title, closed_message
                   FROM forms'
            );
            foreach ($forms as $form) {
                $updates = [];
                $screens = [
                    'description' => [$titleOr($form['input_page_title'] ?? '', $titleOr($form['title'] ?? '', '入力画面')), $form['show_input_page_title'] ?? 1, 'description-title'],
                    'confirm_message' => [$titleOr($form['confirm_page_title'] ?? '', form_default_screen_title('confirm')), $form['show_confirm_page_title'] ?? 1, 'confirm-title'],
                    'thanks_message' => [$titleOr($form['thanks_page_title'] ?? '', form_default_screen_title('thanks')), $form['show_thanks_page_title'] ?? 1, 'thanks-title'],
                    'closed_message' => [$titleOr($form['closed_page_title'] ?? '', form_default_screen_title('closed')), $form['show_closed_page_title'] ?? 1, 'closed-title'],
                ];
                foreach ($screens as $column => [$title, $visible, $id]) {
                    $encoded = $withTitle($form[$column] ?? '', $title, $visible, $id);
                    if ($encoded !== null) {
                        $updates[$column] = $encoded;
                    }
                }
                if ($updates !== []) {
                    $sets = implode(', ', array_map(static fn ($c) => $c . ' = ?', array_keys($updates)));
                    Database::execute(
                        'UPDATE forms SET ' . $sets . ' WHERE id = ?',
                        array_merge(array_values($updates), [(int) $form['id']])
                    );
                }
            }

            $pages = Database::fetchAll(
                'SELECT p.id, p.sort_order, p.title, p.show_title, p.description, f.title AS form_title
                   FROM form_input_pages p
                   JOIN forms f ON f.id = p.form_id'
            );
            foreach ($pages as $page) {
                $fallback = (int) ($page['sort_order'] ?? 1) <= 1
                    ? $titleOr($page['form_title'] ?? '', '入力画面')
                    : '入力画面 ' . (int) $page['sort_order'];
                $encoded = $withTitle(
                    $page['description'] ?? '',
                    $titleOr($page['title'] ?? '', $fallback),
                    $page['show_title'] ?? 1,
                    'description-title-' . (int) $page['id']
                );
                if ($encoded !== null) {
                    Database::execute(
                        'UPDATE form_input_pages SET description = ? WHERE id = ?',
                        [$encoded, (int) $page['id']]
                    );
                }
            }

            \Models\AppSetting::set($flagKey, date('Y-m-d H:i:s'));
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch migrateScreenTitlesToBlocks: ' . $e->getMessage());
        }
    }

    private static function tryAlterUniqueEmail(): void
    {
        try {
            Database::execute('ALTER TABLE users ADD UNIQUE KEY uk_users_email (email)');
        } catch (\Throwable $e) {
            $m = $e->getMessage();
            if (stripos($m, 'Duplicate') !== false || stripos($m, '1061') !== false || stripos($m, 'already exists') !== false) {
                return;
            }
            error_log('[formkun] SchemaPatch uk_users_email: ' . $m);
        }
    }

    /**
     * form_fields.regex を複数パターン（JSON）格納用に TEXT へ拡張。
     */
    public static function ensureFormFieldsRegexText(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT DATA_TYPE AS t FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'regex']
            );
            if (!$col) {
                return;
            }
            $type = strtolower((string) ($col['t'] ?? ''));
            if ($type === 'varchar') {
                Database::execute('ALTER TABLE form_fields MODIFY regex TEXT DEFAULT NULL');
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.regex: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に address（住所）を追加。
     */
    public static function ensureFormFieldsTypeEnumAddress(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || strpos($ct, 'address') !== false) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','address',
                    'radio','checkbox','select','date','time','file'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type address: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に text_pair（1行テキスト2入力）を追加。
     */
    public static function ensureFormFieldsTypeEnumTextPair(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || strpos($ct, 'text_pair') !== false) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','address','text_pair',
                    'radio','checkbox','select','date','time','file'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type text_pair: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に text_multi（1行テキスト複数入力）を追加。
     */
    public static function ensureFormFieldsTypeEnumTextMulti(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || strpos($ct, 'text_multi') !== false) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','address','text_pair','text_multi',
                    'radio','checkbox','select','date','time','file'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type text_multi: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に matrix を追加。
     */
    public static function ensureFormFieldsTypeEnumMatrix(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || strpos($ct, 'matrix') !== false) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','address','text_pair','text_multi','matrix',
                    'radio','checkbox','select','date','time','file',
                    'heading','description','divider'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type matrix: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に postal_code を追加。
     */
    public static function ensureFormFieldsTypeEnumPostalCode(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || strpos($ct, 'postal_code') !== false) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','postal_code','address','text_pair','text_multi','matrix',
                    'radio','checkbox','select','date','time','file',
                    'heading','description','divider'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type postal_code: ' . $e->getMessage());
        }
    }

    /**
     * form_fields.type ENUM に表示専用項目（見出し・説明文・罫線）を追加。
     */
    public static function ensureFormFieldsTypeEnumDisplayItems(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'type']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || (strpos($ct, 'heading') !== false && strpos($ct, 'description') !== false && strpos($ct, 'divider') !== false)) {
                return;
            }
            Database::execute(
                "ALTER TABLE form_fields MODIFY COLUMN type ENUM(
                    'text','textarea','email','tel','number','postal_code','address','text_pair','text_multi','matrix',
                    'radio','checkbox','select','date','time','file',
                    'heading','description','divider'
                ) NOT NULL"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.type display_items: ' . $e->getMessage());
        }
    }

    /**
     * form_fields に visible 列を追加。
     */
    public static function ensureFormFieldsVisible(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasVisible = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'visible']
            );
            if ((int) ($hasVisible['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE form_fields ADD COLUMN visible TINYINT(1) NOT NULL DEFAULT 1 AFTER label'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.visible: ' . $e->getMessage());
        }
    }

    public static function ensureFormFieldsMinLength(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'min_length']
            );
            if ((int) ($col['c'] ?? 0) > 0) {
                return;
            }
            Database::execute('ALTER TABLE form_fields ADD COLUMN min_length INT DEFAULT NULL AFTER required');
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.min_length: ' . $e->getMessage());
        }
    }

    public static function ensureFormFieldsExactLength(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'exact_length']
            );
            if ((int) ($col['c'] ?? 0) > 0) {
                return;
            }
            Database::execute('ALTER TABLE form_fields ADD COLUMN exact_length INT DEFAULT NULL AFTER max_length');
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.exact_length: ' . $e->getMessage());
        }
    }

    /**
     * forms に公開フォーム側のタイトル・説明文表示フラグを追加。
     */
    public static function ensureFormsDisplayFlags(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasShowTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'show_title']
            );
            if ((int) ($hasShowTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN show_title TINYINT(1) NOT NULL DEFAULT 1 AFTER description'
                );
            }

            $hasShowDescription = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'show_description']
            );
            if ((int) ($hasShowDescription['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN show_description TINYINT(1) NOT NULL DEFAULT 1 AFTER show_title'
                );
            }

            $hasConfirmButtonText = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'confirm_button_text']
            );
            if ((int) ($hasConfirmButtonText['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN confirm_button_text VARCHAR(200) DEFAULT NULL AFTER show_description'
                );
            }

            $hasSubmitButtonText = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'submit_button_text']
            );
            if ((int) ($hasSubmitButtonText['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN submit_button_text VARCHAR(200) DEFAULT NULL AFTER confirm_button_text'
                );
            }

            $hasBackButtonText = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'back_button_text']
            );
            if ((int) ($hasBackButtonText['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN back_button_text VARCHAR(200) DEFAULT NULL AFTER submit_button_text'
                );
            }

            $hasConfirmMessage = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'confirm_message']
            );
            if ((int) ($hasConfirmMessage['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN confirm_message TEXT DEFAULT NULL AFTER back_button_text'
                );
            }

            $hasThanksButtonText = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'thanks_button_text']
            );
            if ((int) ($hasThanksButtonText['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN thanks_button_text VARCHAR(200) DEFAULT NULL AFTER thanks_message'
                );
            }

            $hasThanksButtonUrl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'thanks_button_url']
            );
            if ((int) ($hasThanksButtonUrl['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN thanks_button_url VARCHAR(500) DEFAULT NULL AFTER thanks_button_text'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms display flags: ' . $e->getMessage());
        }
    }

    /**
     * forms に入力 / 確認 / 完了画面ごとのタイトル列を追加。
     */
    public static function ensureFormsPageTitles(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasInputPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'input_page_title']
            );
            if ((int) ($hasInputPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN input_page_title VARCHAR(200) DEFAULT NULL AFTER title'
                );
            }

            $hasShowInputPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'show_input_page_title']
            );
            if ((int) ($hasShowInputPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN show_input_page_title TINYINT(1) NOT NULL DEFAULT 1 AFTER input_page_title'
                );
            }

            $hasConfirmPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'confirm_page_title']
            );
            if ((int) ($hasConfirmPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN confirm_page_title VARCHAR(200) DEFAULT NULL AFTER show_description'
                );
            }

            $hasShowConfirmPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'show_confirm_page_title']
            );
            if ((int) ($hasShowConfirmPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN show_confirm_page_title TINYINT(1) NOT NULL DEFAULT 1 AFTER confirm_page_title'
                );
            }

            $hasThanksPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'thanks_page_title']
            );
            if ((int) ($hasThanksPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN thanks_page_title VARCHAR(200) DEFAULT NULL AFTER confirm_message'
                );
            }

            $hasShowThanksPageTitle = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'show_thanks_page_title']
            );
            if ((int) ($hasShowThanksPageTitle['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN show_thanks_page_title TINYINT(1) NOT NULL DEFAULT 1 AFTER thanks_page_title'
                );
            }

            Database::execute(
                "UPDATE forms
                    SET input_page_title = title
                  WHERE (input_page_title IS NULL OR input_page_title = '')
                    AND title IS NOT NULL AND title <> ''"
            );
            Database::execute(
                "UPDATE forms
                    SET show_input_page_title = 1
                  WHERE show_input_page_title IS NULL OR show_input_page_title NOT IN (0, 1)"
            );
            Database::execute(
                "UPDATE forms
                    SET confirm_page_title = '入力内容のご確認'
                  WHERE confirm_page_title IS NULL OR confirm_page_title = ''"
            );
            Database::execute(
                "UPDATE forms
                    SET show_confirm_page_title = 1
                  WHERE show_confirm_page_title IS NULL OR show_confirm_page_title NOT IN (0, 1)"
            );
            Database::execute(
                "UPDATE forms
                    SET thanks_page_title = '送信が完了しました'
                  WHERE thanks_page_title IS NULL OR thanks_page_title = ''"
            );
            Database::execute(
                "UPDATE forms
                    SET show_thanks_page_title = 1
                  WHERE show_thanks_page_title IS NULL OR show_thanks_page_title NOT IN (0, 1)"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms page titles: ' . $e->getMessage());
        }
    }

    /**
     * forms に公開フォーム用の meta 情報列を追加。
     */
    public static function ensureFormsMetaSettings(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasMetaHtml = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'meta_html']
            );
            if ((int) ($hasMetaHtml['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN meta_html TEXT DEFAULT NULL AFTER title'
                );
            }

            $hasCustomCss = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'custom_css']
            );
            if ((int) ($hasCustomCss['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN custom_css TEXT DEFAULT NULL AFTER meta_html'
                );
            }

            $hasCustomJs = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'custom_js']
            );
            if ((int) ($hasCustomJs['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN custom_js TEXT DEFAULT NULL AFTER custom_css'
                );
            }

            $hasHeaderHtml = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'header_html']
            );
            if ((int) ($hasHeaderHtml['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN header_html TEXT DEFAULT NULL AFTER custom_js'
                );
            }

            $hasFooterHtml = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'footer_html']
            );
            if ((int) ($hasFooterHtml['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN footer_html TEXT DEFAULT NULL AFTER header_html'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms meta settings: ' . $e->getMessage());
        }
    }

    /**
     * forms にフォーム単位の通知メール設定列を追加。
     */
    public static function ensureFormsMailSettings(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $columns = [
                'mail_transport' => 'ALTER TABLE forms ADD COLUMN mail_transport VARCHAR(10) DEFAULT NULL AFTER mail_template_admin',
                'mail_from_email' => 'ALTER TABLE forms ADD COLUMN mail_from_email VARCHAR(255) DEFAULT NULL AFTER mail_transport',
                'mail_from_name' => 'ALTER TABLE forms ADD COLUMN mail_from_name VARCHAR(255) DEFAULT NULL AFTER mail_from_email',
                'mail_smtp_host' => 'ALTER TABLE forms ADD COLUMN mail_smtp_host VARCHAR(255) DEFAULT NULL AFTER mail_from_name',
                'mail_smtp_port' => 'ALTER TABLE forms ADD COLUMN mail_smtp_port INT DEFAULT NULL AFTER mail_smtp_host',
                'mail_smtp_secure' => 'ALTER TABLE forms ADD COLUMN mail_smtp_secure VARCHAR(10) DEFAULT NULL AFTER mail_smtp_port',
                'mail_smtp_username' => 'ALTER TABLE forms ADD COLUMN mail_smtp_username VARCHAR(255) DEFAULT NULL AFTER mail_smtp_secure',
                'mail_smtp_password' => 'ALTER TABLE forms ADD COLUMN mail_smtp_password VARCHAR(255) DEFAULT NULL AFTER mail_smtp_username',
                'mail_smtp_timeout' => 'ALTER TABLE forms ADD COLUMN mail_smtp_timeout INT DEFAULT NULL AFTER mail_smtp_password',
                'mail_smtp_ehlo_host' => 'ALTER TABLE forms ADD COLUMN mail_smtp_ehlo_host VARCHAR(255) DEFAULT NULL AFTER mail_smtp_timeout',
                'mail_smtp_verify_peer' => 'ALTER TABLE forms ADD COLUMN mail_smtp_verify_peer TINYINT(1) NOT NULL DEFAULT 1 AFTER mail_smtp_ehlo_host',
                'mail_smtp_verify_peer_name' => 'ALTER TABLE forms ADD COLUMN mail_smtp_verify_peer_name TINYINT(1) NOT NULL DEFAULT 1 AFTER mail_smtp_verify_peer',
                'mail_smtp_allow_self_signed' => 'ALTER TABLE forms ADD COLUMN mail_smtp_allow_self_signed TINYINT(1) NOT NULL DEFAULT 0 AFTER mail_smtp_verify_peer_name',
            ];

            foreach ($columns as $column => $sql) {
                $hasColumn = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'forms', $column]
                );
                if ((int) ($hasColumn['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms mail settings: ' . $e->getMessage());
        }
    }

    public static function ensureFormsReplyFieldKeyStorage(): void
    {
        try {
            $column = Database::fetchOne("SHOW COLUMNS FROM forms LIKE 'reply_from_field_key'");
            $type = strtolower((string) ($column['Type'] ?? ''));
            if ($type !== '' && strpos($type, 'text') === false) {
                Database::execute('ALTER TABLE forms MODIFY reply_from_field_key TEXT DEFAULT NULL');
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms reply field key storage: ' . $e->getMessage());
        }
    }

    public static function ensureFormsPublishSchedule(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $columns = [
                'publish_schedule_enabled' => 'ALTER TABLE forms ADD COLUMN publish_schedule_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER reply_template',
                'publish_rules' => 'ALTER TABLE forms ADD COLUMN publish_rules TEXT DEFAULT NULL AFTER publish_schedule_enabled',
                'closed_page_title' => 'ALTER TABLE forms ADD COLUMN closed_page_title VARCHAR(200) DEFAULT NULL AFTER publish_rules',
                'show_closed_page_title' => 'ALTER TABLE forms ADD COLUMN show_closed_page_title TINYINT(1) NOT NULL DEFAULT 1 AFTER closed_page_title',
                'closed_message' => 'ALTER TABLE forms ADD COLUMN closed_message TEXT DEFAULT NULL AFTER show_closed_page_title',
                'closed_button_text' => 'ALTER TABLE forms ADD COLUMN closed_button_text VARCHAR(200) DEFAULT NULL AFTER closed_message',
                'closed_button_url' => 'ALTER TABLE forms ADD COLUMN closed_button_url VARCHAR(500) DEFAULT NULL AFTER closed_button_text',
            ];

            foreach ($columns as $column => $sql) {
                $hasColumn = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'forms', $column]
                );
                if ((int) ($hasColumn['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms publish schedule: ' . $e->getMessage());
        }
    }

    public static function ensureFormsUnpublishRules(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasColumn = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'unpublish_rules']
            );
            if ((int) ($hasColumn['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN unpublish_rules TEXT DEFAULT NULL AFTER publish_rules'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms unpublish rules: ' . $e->getMessage());
        }
    }

    private static function ensureAppSettingsTable(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'app_settings']
            );
            if ((int) ($hasTbl['c'] ?? 0) > 0) {
                return;
            }

            Database::execute(
                'CREATE TABLE app_settings (
                    setting_key VARCHAR(64) NOT NULL PRIMARY KEY,
                    setting_value TEXT NOT NULL,
                    created_at DATETIME NOT NULL,
                    updated_at DATETIME NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch app_settings: ' . $e->getMessage());
        }
    }

    private static function ensureFormInputPages(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'form_input_pages']
            );
            if ((int) ($hasTbl['c'] ?? 0) === 0) {
                Database::execute(
                    'CREATE TABLE form_input_pages (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        form_id INT NOT NULL,
                        page_key VARCHAR(64) NOT NULL,
                        sort_order INT NOT NULL DEFAULT 0,
                        title VARCHAR(200) DEFAULT NULL,
                        show_title TINYINT(1) NOT NULL DEFAULT 1,
                        description TEXT DEFAULT NULL,
                        button_text VARCHAR(200) DEFAULT NULL,
                        back_button_text VARCHAR(200) DEFAULT NULL,
                        created_at DATETIME NOT NULL,
                        updated_at DATETIME NOT NULL,
                        UNIQUE KEY uk_form_input_page (form_id, page_key),
                        KEY idx_form_input_page_sort (form_id, sort_order),
                        CONSTRAINT fk_form_input_pages_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
                );
            }

            $hasBackButtonText = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_input_pages', 'back_button_text']
            );
            if ((int) ($hasBackButtonText['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE form_input_pages ADD COLUMN back_button_text VARCHAR(200) DEFAULT NULL AFTER button_text'
                );
            }

            $now = date('Y-m-d H:i:s');
            $forms = Database::fetchAll(
                'SELECT id, input_page_title, show_input_page_title, description, confirm_button_text FROM forms'
            );
            foreach ($forms as $form) {
                $exists = Database::fetchOne(
                    'SELECT id FROM form_input_pages WHERE form_id = ? AND page_key = ?',
                    [(int) $form['id'], 'input-1']
                );
                if ($exists !== null) {
                    continue;
                }
                Database::execute(
                    'INSERT INTO form_input_pages (
                        form_id, page_key, sort_order, title, show_title, description, button_text, back_button_text, created_at, updated_at
                     ) VALUES (?,?,?,?,?,?,?,?,?,?)',
                    [
                        (int) $form['id'],
                        'input-1',
                        1,
                        $form['input_page_title'] ?? null,
                        !array_key_exists('show_input_page_title', $form) || !empty($form['show_input_page_title']) ? 1 : 0,
                        $form['description'] ?? null,
                        $form['confirm_button_text'] ?? null,
                        '戻る',
                        $now,
                        $now,
                    ]
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_input_pages: ' . $e->getMessage());
        }
    }

    private static function ensureFormFieldsInputPageKey(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'input_page_key']
            );
            if ((int) ($hasCol['c'] ?? 0) === 0) {
                Database::execute(
                    "ALTER TABLE form_fields ADD COLUMN input_page_key VARCHAR(64) NOT NULL DEFAULT 'input-1' AFTER form_id"
                );
            }
            Database::execute("UPDATE form_fields SET input_page_key = 'input-1' WHERE input_page_key = ''");

            $hasIdx = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ?',
                [$schema, 'form_fields', 'idx_form_sort']
            );
            if ((int) ($hasIdx['c'] ?? 0) > 0) {
                try {
                    Database::execute('ALTER TABLE form_fields DROP KEY idx_form_sort');
                } catch (\Throwable) {
                }
            }
            try {
                Database::execute('ALTER TABLE form_fields ADD KEY idx_form_sort (form_id, input_page_key, sort_order)');
            } catch (\Throwable $e) {
                $m = $e->getMessage();
                if (stripos($m, 'Duplicate') === false && stripos($m, '1061') === false && stripos($m, 'already exists') === false) {
                    error_log('[formkun] SchemaPatch idx_form_sort input_page_key: ' . $m);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_fields.input_page_key: ' . $e->getMessage());
        }
    }

    private static function ensureFormFieldGroups(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasParentGroup = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_fields', 'parent_group_key']
            );
            if ((int) ($hasParentGroup['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE form_fields ADD COLUMN parent_group_key VARCHAR(64) DEFAULT NULL AFTER input_page_key'
                );
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'form_field_groups']
            );
            if ((int) ($hasTbl['c'] ?? 0) === 0) {
                Database::execute(
                    "CREATE TABLE form_field_groups (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        form_id INT NOT NULL,
                        input_page_key VARCHAR(64) NOT NULL DEFAULT 'input-1',
                        parent_group_key VARCHAR(64) DEFAULT NULL,
                        sort_order INT NOT NULL DEFAULT 0,
                        group_key VARCHAR(64) NOT NULL,
                        label VARCHAR(200) NOT NULL,
                        show_label TINYINT(1) NOT NULL DEFAULT 1,
                        description VARCHAR(500) DEFAULT NULL,
                        visible TINYINT(1) NOT NULL DEFAULT 1,
                        created_at DATETIME NOT NULL,
                        updated_at DATETIME NOT NULL,
                        UNIQUE KEY uk_form_field_group (form_id, group_key),
                        KEY idx_form_field_group_sort (form_id, input_page_key, parent_group_key, sort_order),
                        CONSTRAINT fk_form_field_groups_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_field_groups: ' . $e->getMessage());
        }
    }

    private static function ensureFieldLabelDisplayFlags(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $targets = [
                'form_fields' => 'label',
                'form_field_groups' => 'label',
            ];
            foreach ($targets as $table => $afterColumn) {
                $hasCol = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, $table, 'show_label']
                );
                if ((int) ($hasCol['c'] ?? 0) === 0) {
                    Database::execute(
                        sprintf('ALTER TABLE %s ADD COLUMN show_label TINYINT(1) NOT NULL DEFAULT 1 AFTER %s', $table, $afterColumn)
                    );
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch field show_label: ' . $e->getMessage());
        }
    }

    private static function ensureFormBranchRules(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'form_branch_rules']
            );
            if ((int) ($hasTbl['c'] ?? 0) > 0) {
                $hasTriggerPageKey = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'form_branch_rules', 'trigger_page_key']
                );
                if ((int) ($hasTriggerPageKey['c'] ?? 0) === 0) {
                    Database::execute(
                        "ALTER TABLE form_branch_rules ADD COLUMN trigger_page_key VARCHAR(64) NOT NULL DEFAULT 'input-1' AFTER sort_order"
                    );
                }
                try {
                    Database::execute('ALTER TABLE form_branch_rules ADD KEY idx_form_branch_page_sort (form_id, trigger_page_key, sort_order)');
                } catch (\Throwable $e) {
                    $m = $e->getMessage();
                    if (stripos($m, 'Duplicate') === false && stripos($m, '1061') === false && stripos($m, 'already exists') === false) {
                        error_log('[formkun] SchemaPatch idx_form_branch_page_sort: ' . $m);
                    }
                }
                return;
            }

            Database::execute(
                "CREATE TABLE form_branch_rules (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    form_id INT NOT NULL,
                    rule_key VARCHAR(64) NOT NULL,
                    sort_order INT NOT NULL DEFAULT 0,
                    trigger_page_key VARCHAR(64) NOT NULL DEFAULT 'input-1',
                    source_field_key VARCHAR(64) NOT NULL,
                    operator VARCHAR(32) NOT NULL DEFAULT 'equals',
                    expected_value VARCHAR(255) NOT NULL,
                    action_type VARCHAR(32) NOT NULL,
                    target_type VARCHAR(16) NOT NULL DEFAULT 'field',
                    target_key VARCHAR(64) NOT NULL,
                    enabled TINYINT(1) NOT NULL DEFAULT 1,
                    created_at DATETIME NOT NULL,
                    updated_at DATETIME NOT NULL,
                    UNIQUE KEY uk_form_branch_rule (form_id, rule_key),
                    KEY idx_form_branch_sort (form_id, sort_order),
                    KEY idx_form_branch_page_sort (form_id, trigger_page_key, sort_order),
                    KEY idx_form_branch_source (form_id, source_field_key),
                    CONSTRAINT fk_form_branch_rules_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_branch_rules: ' . $e->getMessage());
        }
    }

    private static function ensureFormFieldTemplates(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'form_field_templates']
            );
            if ((int) ($hasTbl['c'] ?? 0) > 0) {
                return;
            }

            Database::execute(
                'CREATE TABLE form_field_templates (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    title VARCHAR(200) NOT NULL,
                    fields_json MEDIUMTEXT NOT NULL,
                    field_groups_json MEDIUMTEXT NOT NULL,
                    created_at DATETIME NOT NULL,
                    updated_at DATETIME NOT NULL,
                    KEY idx_form_field_templates_updated (updated_at, id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_field_templates: ' . $e->getMessage());
        }
    }

    private static function ensureFormVersions(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'form_versions']
            );
            if ((int) ($hasTbl['c'] ?? 0) === 0) {
                Database::execute(
                    'CREATE TABLE form_versions (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        form_id INT NOT NULL,
                        version_number INT NOT NULL,
                        action_type VARCHAR(32) NOT NULL,
                        created_by_user_id INT DEFAULT NULL,
                        created_by_name VARCHAR(100) DEFAULT NULL,
                        snapshot_json MEDIUMTEXT NOT NULL,
                        created_at DATETIME NOT NULL,
                        pinned TINYINT(1) NOT NULL DEFAULT 0,
                        UNIQUE KEY uk_form_versions_number (form_id, version_number),
                        KEY idx_form_versions_created (form_id, created_at, id),
                        KEY idx_form_versions_user (created_by_user_id),
                        CONSTRAINT fk_form_versions_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE,
                        CONSTRAINT fk_form_versions_user FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
                );
            }

            $hasPinned = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_versions', 'pinned']
            );
            if ((int) ($hasPinned['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE form_versions ADD COLUMN pinned TINYINT(1) NOT NULL DEFAULT 0 AFTER created_at'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_versions: ' . $e->getMessage());
        }
    }

    private static function ensureFormBranchRuleTargetType(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $hasTargetType = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'form_branch_rules', 'target_type']
            );
            if ((int) ($hasTargetType['c'] ?? 0) === 0) {
                Database::execute(
                    "ALTER TABLE form_branch_rules ADD COLUMN target_type VARCHAR(16) NOT NULL DEFAULT 'field' AFTER action_type"
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form_branch_rules.target_type: ' . $e->getMessage());
        }
    }

    /**
     * 旧定義の app_settings（created_at が無い 3 列のみ）に created_at を追加する。
     */
    private static function ensureAppSettingsCreatedAtColumn(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'app_settings']
            );
            if ((int) ($hasTbl['c'] ?? 0) === 0) {
                return;
            }

            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'app_settings', 'created_at']
            );
            if ((int) ($hasCol['c'] ?? 0) > 0) {
                return;
            }

            Database::execute(
                'ALTER TABLE app_settings ADD COLUMN created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP AFTER setting_value'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch app_settings created_at: ' . $e->getMessage());
        }
    }

    private static function ensureFormsPublicUuid(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'public_uuid']
            );
            if ((int) ($hasCol['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN public_uuid CHAR(36) DEFAULT NULL AFTER slug'
                );
            }

            $rows = Database::fetchAll('SELECT id, public_uuid FROM forms');
            foreach ($rows as $row) {
                $current = trim((string) ($row['public_uuid'] ?? ''));
                if ($current !== '' && is_uuid_v4($current)) {
                    continue;
                }
                Database::execute(
                    'UPDATE forms SET public_uuid = ? WHERE id = ?',
                    [\uuid_v4(), (int) $row['id']]
                );
            }

            try {
                Database::execute(
                    'ALTER TABLE forms MODIFY public_uuid CHAR(36) NOT NULL'
                );
            } catch (\Throwable $e) {
                error_log('[formkun] SchemaPatch forms.public_uuid NOT NULL: ' . $e->getMessage());
            }

            try {
                Database::execute('ALTER TABLE forms ADD UNIQUE KEY uk_forms_public_uuid (public_uuid)');
            } catch (\Throwable $e) {
                $m = $e->getMessage();
                if (stripos($m, 'Duplicate') === false && stripos($m, '1061') === false && stripos($m, 'already exists') === false) {
                    error_log('[formkun] SchemaPatch uk_forms_public_uuid: ' . $m);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms.public_uuid: ' . $e->getMessage());
        }
    }

    private static function ensureSubmissionFilesFileUuid(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'submission_files', 'file_uuid']
            );
            if ((int) ($hasCol['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE submission_files ADD COLUMN file_uuid CHAR(36) DEFAULT NULL AFTER field_key'
                );
            }

            try {
                Database::execute(
                    'ALTER TABLE submission_files ADD UNIQUE KEY uk_submission_files_file_uuid (file_uuid)'
                );
            } catch (\Throwable $e) {
                $m = $e->getMessage();
                if (stripos($m, 'Duplicate') === false && stripos($m, '1061') === false && stripos($m, 'already exists') === false) {
                    error_log('[formkun] SchemaPatch uk_submission_files_file_uuid: ' . $m);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch submission_files.file_uuid: ' . $e->getMessage());
        }
    }

    private static function ensureSubmissionsWorkflowStatus(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'submissions', 'workflow_status']
            );
            if ((int) ($hasCol['c'] ?? 0) === 0) {
                Database::execute(
                    "ALTER TABLE submissions ADD COLUMN workflow_status VARCHAR(32) NOT NULL DEFAULT 'pending' AFTER submitted_at"
                );
            }

            $hasIdx = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ?',
                [$schema, 'submissions', 'idx_form_workflow']
            );
            if ((int) ($hasIdx['c'] ?? 0) === 0) {
                try {
                    Database::execute(
                        'ALTER TABLE submissions ADD KEY idx_form_workflow (form_id, workflow_status, submitted_at)'
                    );
                } catch (\Throwable $e) {
                    $m = $e->getMessage();
                    if (stripos($m, 'Duplicate') === false && stripos($m, '1061') === false && stripos($m, 'already exists') === false) {
                        error_log('[formkun] SchemaPatch idx_form_workflow: ' . $m);
                    }
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch submissions.workflow_status: ' . $e->getMessage());
        }
    }

    private static function ensureMailOnlySubmissionMetadata(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $columns = [
                'storage_mode' => "ALTER TABLE submissions ADD COLUMN storage_mode VARCHAR(20) NOT NULL DEFAULT 'database' AFTER workflow_status",
                'delivery_route' => 'ALTER TABLE submissions ADD COLUMN delivery_route VARCHAR(16) DEFAULT NULL AFTER storage_mode',
                'mail_delivery_status' => 'ALTER TABLE submissions ADD COLUMN mail_delivery_status VARCHAR(16) DEFAULT NULL AFTER delivery_route',
                'mail_error_code' => 'ALTER TABLE submissions ADD COLUMN mail_error_code VARCHAR(64) DEFAULT NULL AFTER mail_delivery_status',
                'attachment_count' => 'ALTER TABLE submissions ADD COLUMN attachment_count INT UNSIGNED NOT NULL DEFAULT 0 AFTER mail_error_code',
                'attachment_total_bytes' => 'ALTER TABLE submissions ADD COLUMN attachment_total_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER attachment_count',
            ];
            foreach ($columns as $column => $sql) {
                $exists = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'submissions', $column]
                );
                if ((int) ($exists['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch mail-only submission metadata failed');
        }
    }

    private static function ensureLoginAttemptsUsernameIndex(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $exists = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ?',
                [$schema, 'login_attempts', 'idx_username_time']
            );
            if ((int) ($exists['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE login_attempts ADD KEY idx_username_time (username, attempted_at)'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch login_attempts username index: ' . $e->getMessage());
        }
    }

    private static function ensureFormEmbedApiTables(): void
    {
        try {
            Database::execute(
                'CREATE TABLE IF NOT EXISTS form_embed_settings (
                    form_id INT NOT NULL PRIMARY KEY,
                    enabled TINYINT(1) NOT NULL DEFAULT 0,
                    public_page_hidden TINYINT(1) NOT NULL DEFAULT 0,
                    allowed_origins_json TEXT DEFAULT NULL,
                    completion_url VARCHAR(500) DEFAULT NULL,
                    japan_only_enabled TINYINT(1) NOT NULL DEFAULT 0,
                    ipinfo_lite_token VARCHAR(255) DEFAULT NULL,
                    turnstile_enabled TINYINT(1) NOT NULL DEFAULT 0,
                    turnstile_site_key VARCHAR(255) DEFAULT NULL,
                    turnstile_secret_key VARCHAR(255) DEFAULT NULL,
                    recaptcha_enabled TINYINT(1) NOT NULL DEFAULT 0,
                    recaptcha_site_key VARCHAR(255) DEFAULT NULL,
                    recaptcha_secret_key VARCHAR(255) DEFAULT NULL,
                    recaptcha_v3_enabled TINYINT(1) NOT NULL DEFAULT 0,
                    recaptcha_v3_site_key VARCHAR(255) DEFAULT NULL,
                    recaptcha_v3_secret_key VARCHAR(255) DEFAULT NULL,
                    recaptcha_v3_min_score DECIMAL(3,2) NOT NULL DEFAULT 0.50,
                    rate_limit_count INT NOT NULL DEFAULT 10,
                    rate_limit_window_seconds INT NOT NULL DEFAULT 600,
                    created_at DATETIME NOT NULL,
                    updated_at DATETIME NOT NULL,
                    CONSTRAINT fk_form_embed_settings_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            $columns = [
                'public_page_hidden' => 'ALTER TABLE form_embed_settings ADD COLUMN public_page_hidden TINYINT(1) NOT NULL DEFAULT 0 AFTER enabled',
                'completion_url' => 'ALTER TABLE form_embed_settings ADD COLUMN completion_url VARCHAR(500) DEFAULT NULL AFTER allowed_origins_json',
                'japan_only_enabled' => 'ALTER TABLE form_embed_settings ADD COLUMN japan_only_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER allowed_origins_json',
                'ipinfo_lite_token' => 'ALTER TABLE form_embed_settings ADD COLUMN ipinfo_lite_token VARCHAR(255) DEFAULT NULL AFTER japan_only_enabled',
                'recaptcha_enabled' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER turnstile_secret_key',
                'recaptcha_site_key' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_site_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_enabled',
                'recaptcha_secret_key' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_secret_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_site_key',
                'recaptcha_v3_enabled' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_v3_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER recaptcha_secret_key',
                'recaptcha_v3_site_key' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_v3_site_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_v3_enabled',
                'recaptcha_v3_secret_key' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_v3_secret_key VARCHAR(255) DEFAULT NULL AFTER recaptcha_v3_site_key',
                'recaptcha_v3_min_score' => 'ALTER TABLE form_embed_settings ADD COLUMN recaptcha_v3_min_score DECIMAL(3,2) NOT NULL DEFAULT 0.50 AFTER recaptcha_v3_secret_key',
            ];
            foreach ($columns as $column => $sql) {
                $exists = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'form_embed_settings', $column]
                );
                if ((int) ($exists['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
            Database::execute(
                'CREATE TABLE IF NOT EXISTS ip_country_cache (
                    ip VARCHAR(45) NOT NULL PRIMARY KEY,
                    country_code CHAR(2) NOT NULL,
                    checked_at DATETIME NOT NULL,
                    KEY idx_ip_country_checked (checked_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
            Database::execute(
                'CREATE TABLE IF NOT EXISTS public_api_rate_limits (
                    form_id INT NOT NULL,
                    ip VARCHAR(45) NOT NULL,
                    window_started_at INT UNSIGNED NOT NULL,
                    attempt_count INT UNSIGNED NOT NULL DEFAULT 0,
                    updated_at DATETIME NOT NULL,
                    PRIMARY KEY (form_id, ip),
                    KEY idx_public_api_rate_updated (updated_at),
                    CONSTRAINT fk_public_api_rate_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch form embed API tables: ' . $e->getMessage());
        }
    }

    /**
     * forms.status ENUM に hidden（非表示）を追加し、public_page_hidden=1 のフォームを移行する。
     */
    private static function ensureFormsStatusHidden(): void
    {
        try {
            $dbRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($dbRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $col = Database::fetchOne(
                'SELECT COLUMN_TYPE AS ct FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'status']
            );
            $ct = strtolower((string) ($col['ct'] ?? ''));
            if ($ct === '' || str_contains($ct, "'hidden'")) {
                return;
            }
            Database::execute(
                "ALTER TABLE forms MODIFY COLUMN status ENUM('active','draft','hidden','archived') NOT NULL DEFAULT 'draft'"
            );
            Database::execute(
                'UPDATE forms f
                 INNER JOIN form_embed_settings fes ON fes.form_id = f.id
                 SET f.status = \'hidden\'
                 WHERE fes.public_page_hidden = 1'
            );
            Database::execute(
                'UPDATE form_embed_settings fes
                 INNER JOIN forms f ON f.id = fes.form_id
                 SET fes.public_page_hidden = 1
                 WHERE f.status = \'hidden\''
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms.status hidden: ' . $e->getMessage());
        }
    }

    private static function ensureMailOnlySubmission(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $columns = [
                'submission_storage_mode' => "ALTER TABLE forms ADD COLUMN submission_storage_mode VARCHAR(20) NOT NULL DEFAULT 'database' AFTER mail_smtp_allow_self_signed",
                'mail_attachment_max_bytes' => 'ALTER TABLE forms ADD COLUMN mail_attachment_max_bytes INT NOT NULL DEFAULT 10485760 AFTER submission_storage_mode',
                'smtp_tested_at' => 'ALTER TABLE forms ADD COLUMN smtp_tested_at DATETIME DEFAULT NULL AFTER mail_attachment_max_bytes',
                'smtp_test_fingerprint' => 'ALTER TABLE forms ADD COLUMN smtp_test_fingerprint CHAR(64) DEFAULT NULL AFTER smtp_tested_at',
            ];
            foreach ($columns as $column => $sql) {
                $exists = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'forms', $column]
                );
                if ((int) ($exists['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
            Database::execute(
                'CREATE TABLE IF NOT EXISTS mail_delivery_audits (
                    id BIGINT AUTO_INCREMENT PRIMARY KEY,
                    form_id INT NOT NULL,
                    route VARCHAR(16) NOT NULL,
                    delivery_status VARCHAR(16) NOT NULL,
                    error_code VARCHAR(64) DEFAULT NULL,
                    attachment_count INT UNSIGNED NOT NULL DEFAULT 0,
                    attachment_total_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
                    created_at DATETIME NOT NULL,
                    KEY idx_mail_audit_created (created_at),
                    KEY idx_mail_audit_form_created (form_id, created_at),
                    CONSTRAINT fk_mail_delivery_audits_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
            Database::execute(
                "UPDATE form_versions
                 SET snapshot_json = JSON_REMOVE(snapshot_json, '$.form.mail_smtp_password')
                 WHERE JSON_VALID(snapshot_json) = 1
                   AND JSON_CONTAINS_PATH(snapshot_json, 'one', '$.form.mail_smtp_password') = 1"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch mail-only submission failed');
        }
    }

    private static function ensureLineMessagingNotification(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $columns = [
                'line_notify_enabled' => 'ALTER TABLE forms ADD COLUMN line_notify_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER reply_template',
                'line_channel_access_token' => 'ALTER TABLE forms ADD COLUMN line_channel_access_token VARCHAR(512) DEFAULT NULL AFTER line_notify_enabled',
                'line_push_to_id' => 'ALTER TABLE forms ADD COLUMN line_push_to_id VARCHAR(64) DEFAULT NULL AFTER line_channel_access_token',
                'line_message_template' => 'ALTER TABLE forms ADD COLUMN line_message_template TEXT DEFAULT NULL AFTER line_push_to_id',
            ];
            foreach ($columns as $column => $sql) {
                $exists = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'forms', $column]
                );
                if ((int) ($exists['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
            Database::execute(
                "UPDATE form_versions
                 SET snapshot_json = JSON_REMOVE(snapshot_json, '$.form.line_channel_access_token')
                 WHERE JSON_VALID(snapshot_json) = 1
                   AND JSON_CONTAINS_PATH(snapshot_json, 'one', '$.form.line_channel_access_token') = 1"
            );
            Database::execute(
                "UPDATE form_versions
                 SET snapshot_json = JSON_REMOVE(snapshot_json, '$.form.line_channel_secret')
                 WHERE JSON_VALID(snapshot_json) = 1
                   AND JSON_CONTAINS_PATH(snapshot_json, 'one', '$.form.line_channel_secret') = 1"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch LINE messaging notification: ' . $e->getMessage());
        }
    }

    private static function ensureLineWebhookTargets(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $secretCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'line_channel_secret']
            );
            if ((int) ($secretCol['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN line_channel_secret VARCHAR(255) DEFAULT NULL AFTER line_channel_access_token'
                );
            }
            Database::execute(
                'CREATE TABLE IF NOT EXISTS line_webhook_targets (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    form_id INT NOT NULL DEFAULT 0,
                    target_type ENUM(\'user\',\'group\',\'room\') NOT NULL,
                    target_id VARCHAR(64) NOT NULL,
                    label VARCHAR(200) DEFAULT NULL,
                    last_seen_at DATETIME NOT NULL,
                    UNIQUE KEY uk_line_webhook_target_form (form_id, target_type, target_id),
                    KEY idx_line_webhook_form_seen (form_id, last_seen_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
            $targetTypeCol = Database::fetchOne(
                'SELECT COLUMN_TYPE AS t FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'line_webhook_targets', 'target_type']
            );
            $targetTypeDef = (string) ($targetTypeCol['t'] ?? '');
            if ($targetTypeDef !== '' && stripos($targetTypeDef, 'room') === false) {
                Database::execute(
                    'ALTER TABLE line_webhook_targets MODIFY target_type ENUM(\'user\',\'group\',\'room\') NOT NULL'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch LINE webhook targets: ' . $e->getMessage());
        }
    }

    private static function migrateLineSiteChannelAndWebhookTargets(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }

            $hasFormId = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'line_webhook_targets', 'form_id']
            );
            if ((int) ($hasFormId['c'] ?? 0) > 0) {
                $hasPerFormRow = Database::fetchOne('SELECT 1 AS ok FROM line_webhook_targets WHERE form_id <> 0 LIMIT 1');
                if ($hasPerFormRow === null) {
                    return;
                }
                $rows = Database::fetchAll('SELECT form_id, target_type, target_id, label, last_seen_at FROM line_webhook_targets');
                $best = [];
                foreach ($rows as $row) {
                    $type = (string) ($row['target_type'] ?? '');
                    $id = (string) ($row['target_id'] ?? '');
                    if ($type === '' || $id === '') {
                        continue;
                    }
                    $key = $type . "\0" . $id;
                    $seen = (string) ($row['last_seen_at'] ?? '');
                    if (!isset($best[$key]) || $seen > (string) ($best[$key]['last_seen_at'] ?? '')) {
                        $best[$key] = $row;
                    }
                }
                Database::execute('DROP TABLE line_webhook_targets');
                Database::execute(
                    'CREATE TABLE line_webhook_targets (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        target_type ENUM(\'user\',\'group\',\'room\') NOT NULL,
                        target_id VARCHAR(64) NOT NULL,
                        label VARCHAR(200) DEFAULT NULL,
                        last_seen_at DATETIME NOT NULL,
                        UNIQUE KEY uk_line_webhook_target (target_type, target_id),
                        KEY idx_line_webhook_seen (last_seen_at)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
                );
                foreach ($best as $row) {
                    Database::execute(
                        'INSERT INTO line_webhook_targets (target_type, target_id, label, last_seen_at) VALUES (?, ?, ?, ?)',
                        [
                            (string) $row['target_type'],
                            (string) $row['target_id'],
                            $row['label'] !== null && trim((string) $row['label']) !== '' ? (string) $row['label'] : null,
                            (string) ($row['last_seen_at'] ?? date('Y-m-d H:i:s')),
                        ]
                    );
                }
            }

            $lineFormImportDone = trim((string) (\Models\AppSetting::get(\Models\AppSetting::KEY_LINE_SITE_FORM_IMPORT_DONE) ?? '')) === '1';
            if (!$lineFormImportDone) {
                $secretEmpty = trim((string) (\Models\AppSetting::get(\Models\AppSetting::KEY_LINE_CHANNEL_SECRET) ?? '')) === '';
                $tokenEmpty = trim((string) (\Models\AppSetting::get(\Models\AppSetting::KEY_LINE_CHANNEL_ACCESS_TOKEN) ?? '')) === '';
                if ($secretEmpty || $tokenEmpty) {
                    $donor = Database::fetchOne(
                        'SELECT line_channel_secret, line_channel_access_token, line_setup_checklist FROM forms
                         WHERE TRIM(COALESCE(line_channel_secret, \'\')) <> \'\' OR TRIM(COALESCE(line_channel_access_token, \'\')) <> \'\'
                         ORDER BY id ASC LIMIT 1'
                    );
                    if ($donor !== null) {
                        if ($secretEmpty && trim((string) ($donor['line_channel_secret'] ?? '')) !== '') {
                            \Models\AppSetting::set(
                                \Models\AppSetting::KEY_LINE_CHANNEL_SECRET,
                                trim((string) $donor['line_channel_secret'])
                            );
                        }
                        if ($tokenEmpty && trim((string) ($donor['line_channel_access_token'] ?? '')) !== '') {
                            \Models\AppSetting::set(
                                \Models\AppSetting::KEY_LINE_CHANNEL_ACCESS_TOKEN,
                                trim((string) $donor['line_channel_access_token'])
                            );
                        }
                        $siteChecklistEmpty = trim((string) (\Models\AppSetting::get(\Models\AppSetting::KEY_LINE_SETUP_CHECKLIST) ?? '')) === '';
                        $rawFormChecklist = $donor['line_setup_checklist'] ?? null;
                        if ($siteChecklistEmpty && $rawFormChecklist !== null && $rawFormChecklist !== '') {
                            $decoded = is_string($rawFormChecklist) ? json_decode($rawFormChecklist, true) : $rawFormChecklist;
                            if (is_array($decoded)) {
                                $siteKeys = array_fill_keys(\Core\LineSiteConfig::siteChecklistItemKeys(), true);
                                $siteState = [];
                                foreach ($decoded as $k => $v) {
                                    $k = (string) $k;
                                    if (isset($siteKeys[$k]) && $v) {
                                        $siteState[$k] = true;
                                    }
                                }
                                if ($siteState !== []) {
                                    \Models\AppSetting::set(
                                        \Models\AppSetting::KEY_LINE_SETUP_CHECKLIST,
                                        json_encode($siteState, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                                    );
                                }
                            }
                        }
                    }
                }

                $pushEmpty = trim((string) (\Models\AppSetting::get(\Models\AppSetting::KEY_LINE_PUSH_TO_ID) ?? '')) === '';
                if ($pushEmpty) {
                    $pushDonor = Database::fetchOne(
                        'SELECT line_push_to_id FROM forms
                         WHERE TRIM(COALESCE(line_push_to_id, \'\')) <> \'\'
                         ORDER BY updated_at DESC, id DESC LIMIT 1'
                    );
                    if ($pushDonor !== null && trim((string) ($pushDonor['line_push_to_id'] ?? '')) !== '') {
                        \Models\AppSetting::set(
                            \Models\AppSetting::KEY_LINE_PUSH_TO_ID,
                            trim((string) $pushDonor['line_push_to_id'])
                        );
                    }
                }

                $siteState = \Core\LineSiteConfig::decodeLineSetupChecklist(
                    \Models\AppSetting::get(\Models\AppSetting::KEY_LINE_SETUP_CHECKLIST)
                );
                $formChecklistKeys = [
                    \Models\Form::LINE_SETUP_CHECKLIST_SET_LINE_PUSH_TO_ID => true,
                    \Models\Form::LINE_SETUP_CHECKLIST_LINE_TALK_NOTIFY_TEST => true,
                ];
                $needsMerge = !isset($siteState[\Models\Form::LINE_SETUP_CHECKLIST_LINE_TALK_NOTIFY_TEST])
                    || !isset($siteState[\Models\Form::LINE_SETUP_CHECKLIST_SET_LINE_PUSH_TO_ID]);
                if ($needsMerge) {
                    $formRows = Database::fetchAll(
                        'SELECT line_setup_checklist FROM forms WHERE line_setup_checklist IS NOT NULL AND line_setup_checklist <> \'\''
                    );
                    foreach ($formRows as $formRow) {
                        $raw = $formRow['line_setup_checklist'] ?? null;
                        $decoded = is_string($raw) ? json_decode($raw, true) : $raw;
                        if (!is_array($decoded)) {
                            continue;
                        }
                        foreach ($decoded as $k => $v) {
                            $k = (string) $k;
                            if (isset($formChecklistKeys[$k]) && $v) {
                                $siteState[$k] = true;
                            }
                        }
                    }
                    if ($siteState !== []) {
                        \Models\AppSetting::set(
                            \Models\AppSetting::KEY_LINE_SETUP_CHECKLIST,
                            json_encode($siteState, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
                        );
                    }
                }

                \Models\AppSetting::set(\Models\AppSetting::KEY_LINE_SITE_FORM_IMPORT_DONE, '1');
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch LINE site channel migration: ' . $e->getMessage());
        }
    }

    private static function ensureFormsLineCustomEnabled(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $exists = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'line_custom_enabled']
            );
            if ((int) ($exists['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN line_custom_enabled TINYINT(1) NOT NULL DEFAULT 0 AFTER line_notify_enabled'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch forms line_custom_enabled: ' . $e->getMessage());
        }
    }

    /**
     * line_webhook_targets に form_id（0 = サイト共通）を持たせ、複数フォームで送信先 ID を区別する。
     */
    private static function ensureLineWebhookTargetsFormId(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $hasFormId = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'line_webhook_targets', 'form_id']
            );
            if ((int) ($hasFormId['c'] ?? 0) > 0) {
                return;
            }
            $tableExists = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'line_webhook_targets']
            );
            if ((int) ($tableExists['c'] ?? 0) === 0) {
                return;
            }
            Database::execute(
                'ALTER TABLE line_webhook_targets ADD COLUMN form_id INT NOT NULL DEFAULT 0 AFTER id'
            );
            $ukRow = Database::fetchOne(
                'SELECT INDEX_NAME AS n, NON_UNIQUE AS nu FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ?',
                [$schema, 'line_webhook_targets', 'uk_line_webhook_target']
            );
            if ($ukRow !== null && (int) ($ukRow['nu'] ?? 1) === 0) {
                Database::execute('ALTER TABLE line_webhook_targets DROP INDEX uk_line_webhook_target');
            }
            Database::execute(
                'ALTER TABLE line_webhook_targets ADD UNIQUE KEY uk_line_webhook_target_form (form_id, target_type, target_id)'
            );
            Database::execute(
                'ALTER TABLE line_webhook_targets ADD KEY idx_line_webhook_form_seen (form_id, last_seen_at)'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch line_webhook_targets form_id: ' . $e->getMessage());
        }
    }

    private static function ensureLineNotifyIncludeImages(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $exists = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'line_notify_include_images']
            );
            if ((int) ($exists['c'] ?? 0) === 0) {
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN line_notify_include_images TINYINT(1) NOT NULL DEFAULT 0 AFTER line_message_template'
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch line_notify_include_images: ' . $e->getMessage());
        }
    }

    private static function ensureLineSetupChecklist(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $exists = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'forms', 'line_setup_checklist']
            );
            if ((int) ($exists['c'] ?? 0) === 0) {
                $after = 'line_message_template';
                $hasInclude = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'forms', 'line_notify_include_images']
                );
                if ((int) ($hasInclude['c'] ?? 0) > 0) {
                    $after = 'line_notify_include_images';
                }
                Database::execute(
                    'ALTER TABLE forms ADD COLUMN line_setup_checklist JSON DEFAULT NULL AFTER ' . $after
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch line_setup_checklist: ' . $e->getMessage());
        }
    }

    private static function ensureFormsSubmissionRetention(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $columns = [
                'submission_retention_days' => 'ALTER TABLE forms ADD COLUMN submission_retention_days INT NOT NULL DEFAULT 14 AFTER mail_attachment_max_bytes',
                'submission_retention_action' => "ALTER TABLE forms ADD COLUMN submission_retention_action VARCHAR(10) NOT NULL DEFAULT 'warn' AFTER submission_retention_days",
                'submission_retention_enabled' => 'ALTER TABLE forms ADD COLUMN submission_retention_enabled TINYINT(1) NOT NULL DEFAULT 1 AFTER submission_retention_action',
            ];
            foreach ($columns as $column => $sql) {
                $exists = Database::fetchOne(
                    'SELECT COUNT(*) AS c FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                    [$schema, 'forms', $column]
                );
                if ((int) ($exists['c'] ?? 0) === 0) {
                    Database::execute($sql);
                }
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch submission retention failed: ' . $e->getMessage());
        }
    }

    private static function ensureUsersRoleViewer(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $row = Database::fetchOne(
                'SELECT COLUMN_TYPE AS t FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'users', 'role']
            );
            $type = (string) ($row['t'] ?? '');
            if ($type !== '' && stripos($type, 'viewer') === false) {
                Database::execute(
                    "ALTER TABLE users MODIFY role ENUM('admin','editor','viewer') NOT NULL DEFAULT 'editor'"
                );
            }
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch users.role viewer: ' . $e->getMessage());
        }
    }

    private static function ensureUserFormGrantsTable(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'user_form_grants']
            );
            if ((int) ($hasTbl['c'] ?? 0) > 0) {
                return;
            }
            Database::execute(
                'CREATE TABLE user_form_grants (
                    user_id INT NOT NULL,
                    form_id INT NOT NULL,
                    access_level ENUM(\'view\',\'edit\') NOT NULL DEFAULT \'view\',
                    PRIMARY KEY (user_id, form_id),
                    KEY idx_user_form_grants_form (form_id),
                    CONSTRAINT fk_user_form_grants_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                    CONSTRAINT fk_user_form_grants_form FOREIGN KEY (form_id) REFERENCES forms(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch user_form_grants: ' . $e->getMessage());
        }
    }

    private static function ensureUserFormGrantsAccessLevel(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $hasCol = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?',
                [$schema, 'user_form_grants', 'access_level']
            );
            if ((int) ($hasCol['c'] ?? 0) > 0) {
                return;
            }
            Database::execute(
                "ALTER TABLE user_form_grants ADD COLUMN access_level ENUM('view','edit') NOT NULL DEFAULT 'view' AFTER form_id"
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch user_form_grants.access_level: ' . $e->getMessage());
        }
    }

    private static function ensureUserWebauthnCredentialsTable(): void
    {
        try {
            $schemaRow = Database::fetchOne('SELECT DATABASE() AS n');
            $schema = (string) ($schemaRow['n'] ?? '');
            if ($schema === '') {
                return;
            }
            $hasTbl = Database::fetchOne(
                'SELECT COUNT(*) AS c FROM information_schema.TABLES
                 WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?',
                [$schema, 'user_webauthn_credentials']
            );
            if ((int) ($hasTbl['c'] ?? 0) > 0) {
                return;
            }
            Database::execute(
                'CREATE TABLE user_webauthn_credentials (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    user_id INT NOT NULL,
                    credential_id VARBINARY(1024) NOT NULL,
                    public_key BLOB NOT NULL,
                    user_handle VARBINARY(64) NOT NULL,
                    sign_count INT UNSIGNED NOT NULL DEFAULT 0,
                    transports JSON DEFAULT NULL,
                    name VARCHAR(100) DEFAULT NULL,
                    created_at DATETIME NOT NULL,
                    last_used_at DATETIME DEFAULT NULL,
                    UNIQUE KEY uk_webauthn_credential_id (credential_id),
                    KEY idx_webauthn_user (user_id),
                    CONSTRAINT fk_webauthn_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
            );
        } catch (\Throwable $e) {
            error_log('[formkun] SchemaPatch user_webauthn_credentials: ' . $e->getMessage());
        }
    }
}
